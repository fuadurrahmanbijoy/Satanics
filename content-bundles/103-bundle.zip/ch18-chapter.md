:chapter XVIII | Partnership Accounts
:mood Who receives what when three people share one business?
:desc This chapter shows how the books of a business with several owners are kept. It explains each partner's capital, the rules for sharing profit, the admission of a new partner, and the ending of the business by liquidation. Each method is worked by hand, from small numbers to a realistic case.
:plate ch18-plate.svg | A solicitor and three partners study the deed that governs their business

:box YOU WILL NEED
Chapter 9, 'Financial Statements and Closing Entries', section 9.1 'The Three Statements'; Chapter 5, 'The Journal and the Ledger', section 5.2 'The Journal'; Appendix A1, 'Maths You Will Use'.

> Three friends earn one profit from one stall, and each believes a different split is fair.
Three friends run a market stall together. Anwar paid for most of the first goods, but he visits only on Sundays. Babita paid very little, yet she works at the stall every day. Chandra paid a middle sum and keeps the accounts. At the end of the first month the stall has earned a profit of Tk 30,000. How should the three friends divide it?

> Equal shares and shares by money both seem unfair, so a better rule is needed.
Divide it into three equal parts, and Anwar feels cheated, because his money carried most of the risk. Divide it by the money each person paid in, and Babita feels cheated, because her daily work counts for nothing. Both friends have a fair point. Neither rule is wrong in itself; each is incomplete. Friends who sit together can argue until they agree. A business that lasts for years cannot rely on memory and goodwill, so its owners write the agreement down, and the accountant keeps books that follow it.

> This chapter answers four questions about people who own one business together.
Accountants have a standard answer to the puzzle, and this chapter teaches it step by step. You will learn how the money each owner contributes is recorded, how profit is divided in layers so that both money and work are rewarded, what changes in the books when a new owner joins, and how the business is closed and the owners are paid when it ends. We begin, as the friends must, with the question of who owns what.

* * *

## 18.1 Forming a Partnership

> A business with several owners raises three questions that a single owner never faces.
A business with one owner is easy to describe. The owner puts money in, takes profit out, and the books show one amount, the owner's equity. That amount is also called capital, net worth or proprietorship, and this book uses the term owner's equity. When two or more people own a business together, three questions arise at once. How much has each person put in? How will the profit be divided? Who answers for the debts? The owners must agree on these answers before the first sale is recorded.

@ Partnership | A business owned by two or more people who agree to share its profit and loss.
> A partnership is a business with two or more owners who share profit and loss.
The law gives a name to such an arrangement. A **partnership** is a business owned by two or more people who agree to share its profit and loss. Each owner is called a partner. Three friends who open a bookshop together, and agree to share what it earns and loses, form a partnership. In many countries the law holds every partner personally responsible for the firm's debts, so the choice of partners is a serious one.^1

@ Partnership deed | A written agreement setting out each partner's capital, duties and share of profit.
> A deed puts the partners' agreement in writing so that nobody must rely on memory.
Partners protect themselves by writing their agreement down. A **partnership deed** is a written agreement setting out each partner's capital, duties and share of profit. A deed might say, for example, that one partner pays in money while another pays in nothing but works full time in the shop. If the partners make no agreement on a point, the law of the place decides it. In the United Kingdom, the Partnership Act 1890 divides profit equally between partners, whatever each one paid in. Partners who contribute unequally usually want a different rule, which is the reason deeds exist.

@ Capital | Word in use. In daily life, a sum of money, or the main city of a country. In accounting, the amount owners have put into the business and left there.
> Each partner's capital account records what that one partner has put into the firm.
Now consider the books. When one person owns a business, one account records the owner's equity. When several people own it, the accountant keeps one account for each person. This account is called the partner's capital. It shows the amount that partner has put into the firm and left there, as a credit balance, which is a balance on the right-hand side of the account. When a partner pays in cash, we debit Cash and credit that partner's capital. When a partner brings an asset other than cash, such as a delivery van, we debit that asset instead of Cash. The capital of all the partners together makes up the owners' equity of the firm.

> A lender reads the deed to learn who owns the firm and how much capital stands behind it.
Different readers use the same records in different ways. A partner reads the capital accounts to see what share of the firm is his or her own. A bank that lends to the firm reads them to learn how much owners' money stands behind the loan. An employee has less interest in them, but may still ask whether the owners are able to pay wages in a poor year.

> Recall: balance sheet, Chapter 9, section 9.1 'The Three Statements'.
> The case file records three partners and the capital each one contributed.
:case Case file, illustrative. A partnership deed is dated 1 July 2026. It records capital of Tk 2,500,000 from Nurul, Tk 1,000,000 from Rafiq and Tk 600,000 from Tariq. The three capital accounts together total Tk 4,100,000. The deed also fixes how profit is shared; section 18.2, 'Sharing Profit', explains the rule. On the balance sheet each of the three amounts appears on its own line.

> Three ideas carry forward: the partnership, its deed and the capital accounts.
*Before moving on.* A partnership is a business owned by two or more people who share profit and loss. The partnership deed records their agreement; without a deed, the law of the place decides. Each partner has a separate capital account, and the accounts together form the owners' equity of the firm.

* * *

## 18.2 Sharing Profit

> The two friends' puzzle is solved by dividing profit in two layers.
The three friends of the opening can settle their puzzle in two layers. In the first layer, each friend is paid a reward for the money put in, so the largest lender gains most. In the second layer, the profit that remains is divided in a fixed proportion that reflects the work each friend does. Accountants use the same two layers, and each layer has a name.

@ Share | Word in use. In daily life, a part of something divided among people. In accounting, a partner's part of the profit; in a company, a unit of ownership, taught in Chapter 19.
@ Profit-sharing ratio | The fixed proportion in which partners divide profit and loss.
> A ratio cuts profit into equal parts and gives each partner a fixed number of them.
We begin with the second layer. A **profit-sharing ratio** is the fixed proportion in which partners divide profit and loss. A ratio of 5:3:2 cuts the amount into ten equal parts: five go to the first partner, three to the second and two to the third. Of Tk 100, those partners receive Tk 50, Tk 30 and Tk 20. In symbols, a partner's share is S = (p ÷ P) × R, where p is that partner's number of parts, P is the total number of parts, and R is the amount to be divided.

> The ratio need not match the capital, and it also shares losses.
Many students expect the ratio to match the capital. It need not. A partner may hold the smallest capital and the largest ratio, because the ratio rewards work and responsibility as well as money. Losses are shared in the profit-sharing ratio too, unless the deed says otherwise.

@ Interest on capital | A payment credited to partners for their capital before the remaining profit is divided.
> Interest on capital rewards money in proportion to the capital each partner contributed.
The first layer rewards money. **Interest on capital** is a payment credited to partners for their capital before the remaining profit is divided. A partner with capital of Tk 100,000 and a rate of 10% a year is credited Tk 10,000 for a full year. In words, interest equals capital times rate times time. In symbols, I = C × r × t, where C is the capital, r is the yearly rate and t is the time in years. Six months is half a year, so t = 6 ÷ 12.

> Interest on capital divides profit; it is not a cost paid to an outsider.
Interest on capital is a way of dividing profit. It is not a cost paid to an outsider, and no cash need leave the firm. It exists only if the deed provides for it. We also assume that the profit is large enough to cover all the interest; a deed must say what happens if it is not.

:pause 18.p1 | A partner has capital of Tk 200,000. The deed allows interest at 5% a year. How much interest is credited for six months?

> The appropriation account shows profit being divided, layer by layer, in one place.
Both layers are recorded in an appropriation account. The word *appropriation* means setting money aside for a stated use. This account begins with the profit from the income statement. It takes out interest on capital, divides the remainder by the profit-sharing ratio, and ends with the total credited to each partner. In this way the account shows who received what, and why, in one place.

> Example 1 uses small round numbers so that the method is the only thing to learn.
Example 1 uses small, round numbers. Work through each row of the table in order; every line of arithmetic is shown.

:table Example 1: dividing one year's profit in two layers
| Part | Working |
| Given | Capital: A Tk 100,000, B Tk 50,000. Interest 10% a year. Ratio 2:1. Profit for the year Tk 30,000. |
| Find | The total profit credited to A and to B. |
| Formula | In words: interest = capital × rate × time; share = (parts ÷ total parts) × remainder. In symbols: I = C × r × t and S = (p ÷ P) × R. |
| Step 1 | Interest for A = 100,000 × 10% × 1 = Tk 10,000. |
| Step 2 | Interest for B = 50,000 × 10% × 1 = Tk 5,000. |
| Step 3 | Remainder R = 30,000 − (10,000 + 5,000) = Tk 15,000. |
| Step 4 | A's share = (2 ÷ 3) × 15,000 = Tk 10,000. B's share = (1 ÷ 3) × 15,000 = Tk 5,000. |
| Answer | A is credited Tk 20,000 (10,000 + 10,000). B is credited Tk 10,000 (5,000 + 5,000). |
| Check | 20,000 + 10,000 = Tk 30,000, which equals the profit. |

> Three common slips are a wrong period, a wrong order of layers and a wrong divisor.
Three slips are common. First, students forget that the rate is yearly and credit a full year of interest for a shorter period. Second, they divide the profit by the ratio before taking out interest, which reverses the layers. Third, they divide by one part of the ratio instead of its total: with a ratio of 2:1 the divisor is 3, not 2.

> Two layers, interest first and ratio second, are the core of this section.
*Before moving on.* A profit-sharing ratio divides profit and loss in fixed parts. Interest on capital pays each partner for money put in, and it comes out of profit first. The appropriation account records both layers and ends with each partner's total.

^1: Partnership law differs by country. In the United Kingdom the Partnership Act 1890 supplies rules for partners who have not agreed their own; in Bangladesh the Partnership Act 1932 has the same purpose. Read the law of your own country before applying any rule from this chapter.

* * *

## 18.3 Admission of a Partner

> A new partner changes who owns the firm, so the agreement and the records must both change.
What must be agreed, and what must be recorded, when a fourth person asks to join a firm of three? The two questions have different answers, and many students mix them up. The first belongs to the partners and their deed. The second belongs to the accountant and the journal.

> Admission of a partner means a new person becomes an owner, usually after new terms are agreed.
When a new partner is admitted, the people who own the firm change. In many places the law treats the firm before and after the change as two different partnerships. For this reason the partners agree new terms: the date, the new partner's capital and the profit-sharing ratio that applies from then on. The deed is rewritten or added to. The accountant records the new capital only when it actually arrives.

> The case file records Nusrat Meghna joining on 1 January 2027 with cash.
:case Case file, illustrative. On 1 January 2027, Nusrat Meghna is admitted as a partner. She pays in cash of Tk 700,000, which is credited as her capital. The case file gives no new profit-sharing ratio, so none is used in this chapter.

> Recall: journal, Chapter 5, section 5.2 'The Journal'.
> Recording a new partner's capital follows the rule for any cash paid in: debit Cash, credit capital.
Recording the new capital uses the rule from section 18.1. Cash comes in, so we debit Cash. The new partner's claim on the firm grows, so we credit her capital. Each journal entry has a date, the accounts, the amounts and a short narration. The table shows the entry for the case.

:table Journal entry for the admission of Nusrat Meghna
| Date | Account | Debit (Tk) | Credit (Tk) |
| 1 January 2027 | Cash | 700,000 | |
| | Nusrat Meghna, Capital | | 700,000 |
| | Cash paid in by the new partner on admission | | |

> Debits equal credits, and the existing partners' accounts do not change.
Check the entry in two ways. The debit of Tk 700,000 equals the credit of Tk 700,000, as every entry requires. The capital accounts of Nurul, Rafiq and Tariq are untouched, because their claims did not change on that day. If the new partner brings a delivery van instead of cash, the debit goes to the van, and the credit to her capital stays the same.

> New terms are agreed by the partners; new capital is recorded by the accountant.
*Before moving on.* Admission of a partner changes the owners, so the partners agree new terms. The accountant records only the new capital: debit Cash, or the asset brought, and credit the new partner's capital. Existing capital accounts stay as they were.

* * *

## 18.4 Liquidation

> Ending a business means turning assets into cash, paying debts and sharing what is left.
Every business ends one day. How does an owner recover money from a shop full of shelves, counters and unsold books? The answer is to sell everything, pay what is owed and divide what remains. Accountants give a name to this process and to its first step.

@ Liquidation | The process of selling a business's assets, paying its debts and sharing what remains among the owners.
> Liquidation is the whole process of closing a business and paying everyone.
**Liquidation** is the process of selling a business's assets, paying its debts and sharing what remains among the owners. A shop that sells its books and fittings, repays its suppliers and bank, and gives the balance to its owners is in liquidation. Debts to outsiders come first. The owners receive only what is left, because their claim comes after every other claim.

@ Realisation | The sale of assets, in liquidation, and the gain or loss on that sale.
> Realisation is the sale of the assets and the gain or loss that results.
The first step has its own name. **Realisation** is the sale of assets, in liquidation, and the gain or loss on that sale. If an asset with a book amount of Tk 100 sells for Tk 80, the realisation loss is Tk 20. The book amount is the amount at which the asset stands in the accounts. The partners share a loss on realisation in the profit-sharing ratio, as section 18.2 explained, unless the deed says otherwise.

> The case file records the sale of all assets at a loss and the payment of debts and partners.
:case Case file, illustrative. The liquidation takes place on 31 December 2027. The assets, at a book amount of Tk 5,300,000, are sold for Tk 4,400,000. The liabilities are Tk 1,200,000. The loss of Tk 900,000 is shared as Tk 450,000, Tk 270,000 and Tk 180,000. Cash of Tk 3,200,000 remains after the debts and is paid to the partners as Tk 2,050,000, Tk 730,000 and Tk 420,000.

> Paying the partners follows four steps in a fixed order: sell, share the loss, pay debts, pay partners.
Paying the partners comes last, and the order matters. First, sell the assets and find the loss. Second, share the loss in the ratio 5:3:2 by reducing each partner's capital. Third, pay the liabilities to outsiders from the cash received. Fourth, pay each partner the capital that remains. A realisation account collects the assets sold and the cash received, so that its balance shows the loss. The table records the four steps.

:table Entries for the liquidation, 31 December 2027
| Step | Debit | Credit | Tk |
| 1 | Cash | Realisation | 4,400,000 |
| 1 | Realisation | Assets | 5,300,000 |
| 2 | Capital: Nurul 450,000, Rafiq 270,000, Tariq 180,000 | Realisation | 900,000 |
| 3 | Liabilities | Cash | 1,200,000 |
| 4 | Capital: Nurul 2,050,000, Rafiq 730,000, Tariq 420,000 | Cash | 3,200,000 |

> Example 2 works the liquidation arithmetic in the standard order.
Example 2 works the arithmetic. The case file implies that each partner's capital on 31 December 2027 equals the amount in the deed, and the working uses those amounts.

:table Example 2: paying the partners at liquidation
| Part | Working |
| Given | Capital: Nurul Tk 2,500,000, Rafiq Tk 1,000,000, Tariq Tk 600,000. Ratio 5:3:2. Assets, book amount Tk 5,300,000, sold for Tk 4,400,000. Liabilities Tk 1,200,000. |
| Find | The loss on realisation, each partner's share of it, and the cash paid to each partner. |
| Formula | In words: loss = book amount − amount received; payment = capital − share of loss. In symbols: L = B − A and X = C − D, where B is the book amount, A is the amount received, C is the capital and D is the partner's share of the loss. |
| Step 1 | Loss L = 5,300,000 − 4,400,000 = Tk 900,000. |
| Step 2 | Shares of loss: Nurul (5 ÷ 10) × 900,000 = Tk 450,000. Rafiq (3 ÷ 10) × 900,000 = Tk 270,000. Tariq (2 ÷ 10) × 900,000 = Tk 180,000. |
| Step 3 | Payments X: Nurul 2,500,000 − 450,000 = Tk 2,050,000. Rafiq 1,000,000 − 270,000 = Tk 730,000. Tariq 600,000 − 180,000 = Tk 420,000. |
| Step 4 | Cash after debts = 4,400,000 − 1,200,000 = Tk 3,200,000. |
| Answer | The loss is Tk 900,000. Nurul receives Tk 2,050,000, Rafiq Tk 730,000 and Tariq Tk 420,000. |
| Check | 2,050,000 + 730,000 + 420,000 = Tk 3,200,000, which equals the cash after debts. |

> Paying partners before debts, or sharing the loss by capital, are the two usual slips.
Two slips are usual. Some students pay the partners before the outside debts, which is wrong, because outsiders have the first claim. Others share the loss in proportion to capital instead of the profit-sharing ratio. Capital and ratio are different things, and the deed names the ratio.

> A partner whose capital falls below zero must pay in the shortage.
Occasionally a loss is larger than a partner's capital. That partner's capital account then has a debit balance, which means the partner owes the firm the shortage. The partner must pay it in before the final payments are made. The case file has no such partner, because each capital is larger than that partner's share of the loss.

> Sell, share the loss, pay debts, then pay the partners: this order is the technique of liquidation.
*Before moving on.* Liquidation sells the assets, pays the debts and shares what remains. Realisation is the sale and its gain or loss, which the partners share in the ratio. Outsiders are paid before partners, and each partner receives capital less his or her share of the loss.

* * *

## Worked Case: Dividing Six Months of Profit

> The first six months of the case give a realistic division over a period shorter than a year.
Section 18.2 used a full year. The case file is messier, because the profit covers only six months. Read the figure below from top to bottom. The top bar is the whole profit. The dashed layer shows interest on capital, and the dotted layer shows the remainder divided by the ratio. The bottom layer gives each partner's total. The words in each layer carry the same meaning as the shading, so the figure reads in grey as well.

:fig Profit shared in two layers: interest on capital first, then the ratio | ch18-fig01.svg

> The case file records the profit for the first six months and the rules that divide it.
:case Case file, illustrative. The deed is dated 1 July 2026. Capital: Nurul Tk 2,500,000, Rafiq Tk 1,000,000 and Tariq Tk 600,000. The profit-sharing ratio is 5:3:2 and interest on capital is 6% a year. The profit from 1 July to 31 December 2026 is Tk 420,000.

> Example 3 divides the case-file profit in standard order, including the change of period.
Example 3 divides this profit. Notice the period: 1 July to 31 December is six months, so t = 6 ÷ 12 = 0.5 year. Many students find this step confusing, because the rate is stated for a year while the profit covers half of one. The table keeps both facts in view.

:table Example 3: dividing six months of profit
| Part | Working |
| Given | Capital: Nurul Tk 2,500,000, Rafiq Tk 1,000,000, Tariq Tk 600,000. Interest 6% a year. Ratio 5:3:2. Profit for six months Tk 420,000. |
| Find | The total profit credited to each partner. |
| Formula | In words: interest = capital × rate × time; share = (parts ÷ total parts) × remainder. In symbols: I = C × r × t and S = (p ÷ P) × R. |
| Step 1 | Interest: Nurul 2,500,000 × 6% × 0.5 = Tk 75,000. Rafiq 1,000,000 × 6% × 0.5 = Tk 30,000. Tariq 600,000 × 6% × 0.5 = Tk 18,000. |
| Step 2 | Total interest = 75,000 + 30,000 + 18,000 = Tk 123,000. |
| Step 3 | Remainder R = 420,000 − 123,000 = Tk 297,000. |
| Step 4 | Shares of R: Nurul (5 ÷ 10) × 297,000 = Tk 148,500. Rafiq (3 ÷ 10) × 297,000 = Tk 89,100. Tariq (2 ÷ 10) × 297,000 = Tk 59,400. |
| Step 5 | Totals: Nurul 75,000 + 148,500 = Tk 223,500. Rafiq 30,000 + 89,100 = Tk 119,100. Tariq 18,000 + 59,400 = Tk 77,400. |
| Answer | Nurul is credited Tk 223,500, Rafiq Tk 119,100 and Tariq Tk 77,400. |
| Check | 223,500 + 119,100 + 77,400 = Tk 420,000, which equals the profit. |

> The appropriation account sets out the same figures in the form accountants use.
The appropriation account shows the same figures in the form that accountants use. Read each column downward: a partner's interest, then the share of the remainder, then the total.

:table Appropriation account for the six months ended 31 December 2026 (Tk)
| Item | Nurul | Rafiq | Tariq | Total |
| Profit for the period | | | | 420,000 |
| Interest on capital | 75,000 | 30,000 | 18,000 | 123,000 |
| Remainder, shared 5:3:2 | 148,500 | 89,100 | 59,400 | 297,000 |
| Total credited to partners | 223,500 | 119,100 | 77,400 | 420,000 |

> Charging a full year of interest gives wrong totals, even though the arithmetic looks neat.
A common slip is to charge a full year of interest. The interest would then be 150,000, 60,000 and 36,000, a total of Tk 246,000, and the remainder would fall to Tk 174,000. Every total would be wrong. Always ask first: how long is the period?

> Each partner sees the two layers differently, and both layers serve a purpose.
Tariq holds the smallest capital. Interest gives him Tk 18,000, and the ratio gives him a fifth of the remainder. Nurul holds the largest capital, and for him the interest layer protects the reward for his money. The ratio then gives him half of what remains, as the deed provides.

* * *

## Summary

> A partnership shares profit and loss by agreement and records each partner's capital separately.
A partnership is a business owned by two or more people who share profit and loss under a deed. Each partner has a capital account. Profit is divided in two layers, interest on capital and then the remainder by the profit-sharing ratio, and both are recorded in the appropriation account. A new partner's capital is recorded by debiting Cash and crediting that partner's capital. In liquidation, the assets are realised, the loss is shared by the ratio, debts are paid first, and each partner receives capital less his or her share of the loss.

## Think It Through

:q 18.t1 | Tariq adds Tk 400,000 to his capital, and the ratio stays 5:3:2. What changes in his share of the remainder, and what changes in his interest at 6% a year?
:q 18.t2 | After a firm sells all its assets, its cash is smaller than its debts. Who is paid first, and what happens to the partners' capital?

## Where People Go Wrong

> A larger capital does not give a larger ratio; the deed sets the ratio.
*Belief:* the partner with the most capital must have the biggest share of profit. *Correction:* the ratio is fixed by the deed and need not match the capital. Interest on capital rewards money separately, in the first layer.

> Interest on capital divides profit; it is not an expense paid to an outsider.
*Belief:* interest on capital is a cost of the firm, like rent. *Correction:* it is a way of dividing profit among the partners, so it appears in the appropriation account and not in the income statement.

> Owners are paid last in liquidation, because outsiders hold the first claim.
*Belief:* the owners are paid first, because they own the firm. *Correction:* suppliers, banks and other outsiders are paid before the partners receive anything.

> A loss on realisation is shared by the ratio, not by capital.
*Belief:* a loss follows the size of each partner's capital. *Correction:* unless the deed says otherwise, the loss follows the profit-sharing ratio, exactly as profit does.

## In History

> Goldman Sachs, a New York firm founded in 1869, was owned by its partners for 130 years.
Marcus Goldman, a German immigrant, founded Goldman Sachs in New York City in 1869. The firm grew into one of the best-known financial firms in the United States, and for 130 years its owners were partners. In the 1990s the partners debated for years whether to change this. Some feared the loss of the partnership's special culture; others wanted permanent capital to fund the firm's growth.

> On 4 May 1999 the firm sold shares to the public and its partners became shareholders.
The partners voted to make the change. On 4 May 1999 the firm's shares began to trade, in what was then the second-largest first public sale of shares in United States history. The lesson for this chapter is that a partner's capital belongs to named people, who may take it back when they leave, while money raised from shares stays in the business. Chapter 19, 'Company Accounts: Shares', section 19.1 'Share Capital', teaches that second form.

## Review Questions

:q 18.1 | Two partners share profit in the ratio 3:1 and the deed gives no interest on capital. The profit is Tk 80,000. How much does each partner receive?
:q 18.2 | A new deed gives Mira capital of Tk 450,000 and Naveed capital of Tk 300,000. Interest on capital is 8% a year, and the ratio is 3:2. The profit for the year is Tk 211,000. Find the total credited to each partner.
:q 18.3 | Under the same deed as question 18.2, the profit of Tk 180,000 is for nine months. Find the total credited to each partner.
:q 18.4 | On 1 April 2028 a new partner, Priya, pays Tk 300,000 by cheque into the firm's bank account, and the amount is credited as her capital. Journalise the admission.
:q 18.5 | Partners P and Q have capital of Tk 400,000 and Tk 200,000 and share profit and loss 2:1. Their assets, at a book amount of Tk 850,000, are sold for Tk 700,000, and the liabilities are Tk 250,000. Find the loss, each partner's share of it, and the payment to each partner.
