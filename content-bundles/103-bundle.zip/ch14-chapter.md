:chapter XIV | Costing Inventory: FIFO, LIFO and Weighted Average
:mood Two identical items were bought at different prices. Which cost did the customer take away?
:desc This chapter teaches three rules for deciding which purchase costs leave inventory when goods are sold. You will apply each rule to one set of figures, compare the results, and see how the choice changes profit and the value of the goods still on hand.
:plate ch14-plate.svg | A cellar of casks in rows, with a cooper marking the oldest

:box YOU WILL NEED
You will need the difference between a perpetual record and a periodic record from Chapter 13 'Inventory: Meaning and Measurement', section 13.3 'Recording Inventory', and the idea of cost of goods sold from Chapter 10 'Accounts of a Merchandising Company', section 10.1 'Sales, Purchases and Returns'. Appendix A1 'Maths You Will Use' covers averages and rounding, which section 14.4 uses.

> A shopkeeper holds two identical sacks of rice bought at different prices, and a customer buys one.

Picture a shopkeeper in a market. In the first week she buys one sack of rice for Tk 100. In the second week the price rises, and she buys a second sack for Tk 120. The two sacks stand side by side. They look the same, they weigh the same, and no label shows the week of purchase. A customer arrives and buys one sack for Tk 150.

> The profit on the sale is Tk 50 or Tk 30, depending on which cost we say the customer took away.

Now the shopkeeper wants to know her profit. If the customer took the cheaper sack, the profit is Tk 150 less Tk 100, which is Tk 50. If the customer took the dearer sack, the profit is Tk 150 less Tk 120, which is Tk 30. Both answers are reasonable, and the sacks cannot tell us which is true. Many students find this puzzling at first, because they expect a fact to settle the matter. Here no physical fact can settle it. The business must choose a rule.

> The choice looks small for one sack, but it grows large when thousands of units are sold.

For one sack the difference is Tk 20. For a bookshop that buys thousands of books at changing prices, the difference can reach hundreds of thousands of taka. The owner, the tax collector and the bank that lends money to the business all read the profit figure. A rule that changes the profit changes what each of them sees. For that reason accountants name the possible rules, apply them carefully, and use one rule consistently.

> This chapter teaches the three rules one at a time, using one set of figures throughout.

Section 14.1 explains the problem and builds the vocabulary. Section 14.2 teaches the first rule, section 14.3 the second, and section 14.4 the third, with a comparison. A worked case then shows what happens when prices fall instead of rise. Go slowly. Each section finishes one idea before the next begins, and the same figures return every time so that only the rule changes.

* * *

## The Problem of Changing Prices

@! Go slowly here.

> Prices of goods change, so units that look alike can carry different costs.

> Recall: perpetual and periodic records, Chapter 13, 'Inventory: Meaning and Measurement', section 13.3 'Recording Inventory'.

A business rarely buys all its goods at one price. A supplier raises or lowers a price, a season ends, or a change in the exchange rate makes imported goods dearer. The business therefore holds goods that look the same but cost different amounts. Chapter 13 explained that the business records the goods it holds as inventory, and that it may count them at the end of the period or record every movement. In this chapter we count at the end of the period, and we apply each rule to the whole period at once. That choice keeps the arithmetic short while we learn the ideas.^1

^1: Where each unit can be told apart, for example a car with its own serial number, a business may use the actual cost of that unit. This chapter treats only goods that cannot be told apart. The same rules also apply to raw materials and work in process, which face the same problem.

> The word layer helps us picture goods bought at different times and prices.

@ Layer | Word in use. In daily life, a thickness of material lying over another. In accounting, a group of units bought at one time at one cost.

Imagine the goods as a pile, built up as purchases arrive. Each purchase adds a **layer** of its own: a group of units that were bought at one time and at one unit cost. The opening inventory, which is the goods held when the period began, is the first layer. The sack bought for Tk 100 is one layer. The sack bought for Tk 120 is a second layer, placed on top of the first. When goods are sold, we must decide which layer the sold units are taken from.

> A cost flow assumption is a rule that names which layers are treated as sold.

@ Flow | Word in use. In daily life, water or traffic moving along a path. In accounting, the order in which costs are treated as leaving inventory, which need not match the movement of the goods.

@ Cost flow assumption | A rule that decides which purchase costs are treated as sold and which remain in inventory.

A **cost flow assumption** is a rule that decides which purchase costs are treated as sold and which remain in inventory. Suppose a shop sells goods from a pile with two layers. The rule says which layer's cost goes to cost of goods sold first. The word flow refers to the order of costs, not to the movement of goods on the shelf. A shop may hand out its newest dictionary first, yet still assume that its oldest cost was sold first. We call it an assumption because we choose it, and no one proves it.

> A tiny calculation with two sacks shows that each rule gives a different profit.

We now test the idea with the smallest numbers possible. *Given.* One unit bought at Tk 10 and one unit bought at Tk 12, both on hand. One unit is sold for Tk 20. *Find.* The cost of goods sold, the cost of the unit left, and the gross profit, under each of two rules: the oldest cost is sold first, or the newest cost is sold first. *Formula.* Gross profit equals net sales minus cost of goods sold. In symbols, GP = S − C, where GP is gross profit, S is net sales and C is cost of goods sold. *Steps.* If the oldest cost is sold first, C = Tk 10, the unit left costs Tk 12, and GP = Tk 20 − Tk 10 = Tk 10. If the newest cost is sold first, C = Tk 12, the unit left costs Tk 10, and GP = Tk 20 − Tk 12 = Tk 8. *Answer.* The profit is Tk 10 under the first rule and Tk 8 under the second. *Check.* In both cases the cost of goods sold plus the cost of the unit left equals Tk 22, the cost of both units.

> Ending inventory is the cost of the goods still on hand when the period closes.

@ Ending inventory | The cost of goods still on hand at the end of the period.

The unit left in the tiny calculation has a name. **Ending inventory** is the cost of goods still on hand at the end of the period. The second sack in our opening puzzle, if the customer took the first, is the ending inventory, valued at Tk 120. Ending inventory appears as an asset in the balance sheet. It is also the opening inventory of the next period, so an error in one period carries into the next.

> Every cost the business could sell ends up either in cost of goods sold or in ending inventory.

The tiny calculation shows a rule that never changes. The cost of goods available for sale is the opening inventory plus the purchases of the period. Each unit of that cost is either sold or left. In words: cost of goods available equals cost of goods sold plus ending inventory. In symbols, A = C + E, where A is the cost of goods available, C is the cost of goods sold and E is the ending inventory. A cost flow assumption does not change A. It decides only how A is divided between C and E.

> The method matters because it moves cost between the income statement and the balance sheet.

@! Go slowly here.

Consider why the choice matters, from four viewpoints. The owner sees a higher or lower profit, and so a higher or lower reward for the year. The tax collector sees a larger or smaller amount on which tax is due, in countries where tax follows profit. The bank sees a higher or lower value for the goods that support its loan. The manager compares this year with last year, and a change of rule would spoil the comparison. A rule that gives a larger cost of goods sold gives a smaller gross profit and a smaller ending inventory. A rule that gives a smaller cost of goods sold does the opposite. Over the whole life of a business the total cost is the same; the rules differ in the timing of the cost.

> The case file provides the figures used in the next three sections.

:case Case file, illustrative. Meghna and Sons sells boxed dictionary sets. At the start of the period it held an opening inventory of 20 sets at Tk 300 a set, a cost of Tk 6,000. It then bought 30 sets at Tk 320 a set, a cost of Tk 9,600, and later bought 50 sets at Tk 340 a set, a cost of Tk 17,000. During the period it sold 70 sets at Tk 500 a set, net sales of Tk 35,000.

> The table lists the three layers in order, with the cost of each layer.

The table below shows the layers in the order in which they arrived. Read each row from left to right: the layer, the number of units, the unit cost and the total cost of that layer. The last row adds the units and the costs.

:table Layers of boxed dictionary sets available for sale
| Layer | Units | Unit cost (Tk) | Total cost (Tk) |
| Opening inventory | 20 | 300 | 6,000 |
| First purchase | 30 | 320 | 9,600 |
| Second purchase | 50 | 340 | 17,000 |
| Available for sale | 100 | | 32,600 |

> The cost of goods available is Tk 32,600, and 30 sets remain after 70 are sold.

*Given.* The three layers in the table. *Find.* The units and the cost available for sale, and the units left after the sale. *Formula.* Cost available equals the sum of the layer costs. In symbols, A = L₁ + L₂ + L₃, where A is the cost available and L₁, L₂ and L₃ are the layer costs. *Steps.* Tk 6,000 + Tk 9,600 = Tk 15,600. Then Tk 15,600 + Tk 17,000 = Tk 32,600. Units: 20 + 30 + 50 = 100, and 100 − 70 = 30. *Answer.* Cost available is Tk 32,600, and 30 sets remain. *Check.* Each layer cost equals its units times its unit cost: 20 × 300, 30 × 320 and 50 × 340.

> Recap: a cost flow assumption divides the cost available between cost of goods sold and ending inventory.

*Before moving on.* Goods bought at different prices form layers. A cost flow assumption decides which layers are treated as sold, and ending inventory is the cost that remains. Cost of goods sold plus ending inventory always equals the cost available. You should now be able to say why two businesses with identical goods can report different profits.

* * *

## First-In First-Out

@! Go slowly here.

> A queue at a canteen shows the idea: the first person to arrive is the first to be served.

Think of a queue at a canteen. The person who arrived first is served first, and the person who arrived last waits longest. Many shops follow the same order with their goods. They sell the oldest goods first, because old goods may spoil or fall out of fashion. A cellar of casks works in this way too: the cooper marks the oldest cask, and that cask is opened first.

> First-in first-out treats the oldest costs as sold first.

@ First-in first-out | A method that treats the oldest costs as sold first, leaving the newest costs in inventory.

The **first-in first-out** method, often written FIFO, is a method that treats the oldest costs as sold first, leaving the newest costs in inventory. In our pile, the opening layer is the oldest, so its cost leaves first. Then the cost of the first purchase leaves, and so on, until the number of units sold is reached. What remains is made of the newest layers.

> We take 70 units from the oldest layers, and 30 units at Tk 340 remain.

We apply the method to the case. *Given.* The layers in the table of section 14.1, and a sale of 70 units for Tk 35,000. *Find.* The ending inventory, the cost of goods sold and the gross profit. *Formula.* Ending inventory equals the units left times the unit cost of the newest layer. Cost of goods sold equals cost available minus ending inventory. Gross profit equals net sales minus cost of goods sold. In symbols, E = n × u, C = A − E and GP = S − C, where n is the number of units left and u is the unit cost of the newest layer. *Steps.* The oldest 70 units are 20 + 30 + 20 from the second purchase. The 30 units left all come from the second purchase, so E = 30 × Tk 340 = Tk 10,200. Then C = Tk 32,600 − Tk 10,200 = Tk 22,400. Then GP = Tk 35,000 − Tk 22,400 = Tk 12,600. *Answer.* Under FIFO, ending inventory is Tk 10,200, cost of goods sold is Tk 22,400 and gross profit is Tk 12,600. *Check.* Directly: 20 × 300 + 30 × 320 + 20 × 340 = 6,000 + 9,600 + 6,800 = Tk 22,400.

> Pause and check that you can take costs from the oldest layers first.

:pause 14.p1 | Suppose Meghna and Sons had sold only 60 sets. Using FIFO, find the ending inventory, the cost of goods sold, and check that they add to Tk 32,600.

> When prices rise, FIFO gives the lowest cost of goods sold and the highest ending inventory.

Exceptions and limits need attention. FIFO is an assumption about costs, not a statement about which dictionary left the shelf. In our case the prices rise from Tk 300 to Tk 340. FIFO charges the cheap, old costs to the sale, so cost of goods sold is low and profit is high. The ending inventory carries the newest, dearest costs, so the asset in the balance sheet is close to what the goods cost now. When prices fall, the effects reverse. The worked case in this chapter shows this.

> Recap: FIFO sells the oldest costs first and leaves the newest costs in inventory.

*Before moving on.* First-in first-out takes the oldest layers for cost of goods sold and keeps the newest layers as ending inventory. For the dictionary sets, it gives Tk 22,400 and Tk 10,200. You should now be able to say which layers remain after a sale under FIFO.

* * *

## Last-In First-Out

@! Go slowly here.

> A stack of plates shows the idea: the plate placed last is the plate taken first.

Think of a stack of plates in a kitchen. A cook adds clean plates on top, and takes the top plate when one is needed. The plate placed last is taken first. The bottom plate may stay in the stack for months. A pile of coal or sand in a yard behaves in the same way, because the newest load lies on top and is taken first.

> Last-in first-out treats the newest costs as sold first.

@ Last-in first-out | A method that treats the newest costs as sold first, leaving the oldest costs in inventory.

The **last-in first-out** method, often written LIFO, is a method that treats the newest costs as sold first, leaving the oldest costs in inventory. The method reverses the order of FIFO. In our pile, the newest layer is the second purchase, so its cost leaves first. Then the first purchase, and then the opening layer, if more units must be taken.

> We take 70 units from the newest layers, and 30 units of older cost remain.

We apply the method to the same case. *Given.* The same layers and the same sale of 70 units for Tk 35,000. *Find.* The ending inventory, the cost of goods sold and the gross profit. *Formula.* The formulas are the same as for FIFO: C = A − E and GP = S − C, but E is now built from the oldest layers. *Steps.* The newest 70 units are 50 from the second purchase and 20 from the first purchase. The 30 units left are 20 from the opening layer and 10 from the first purchase. So E = 20 × Tk 300 + 10 × Tk 320 = Tk 6,000 + Tk 3,200 = Tk 9,200. Then C = Tk 32,600 − Tk 9,200 = Tk 23,400. Then GP = Tk 35,000 − Tk 23,400 = Tk 11,600. *Answer.* Under LIFO, ending inventory is Tk 9,200, cost of goods sold is Tk 23,400 and gross profit is Tk 11,600. *Check.* Directly: 50 × 340 + 20 × 320 = 17,000 + 6,400 = Tk 23,400.

> When prices rise, LIFO gives the highest cost of goods sold and the lowest profit.

Again we must state the limits. LIFO charges the newest, dearest costs to the sale, so cost of goods sold is high and gross profit is low. Ending inventory is valued at old prices, so the asset in the balance sheet may be far below what the goods would cost today. A business that uses LIFO in a time of rising prices reports less profit, and where tax follows profit it may owe less tax. Rules on this differ by country. The history section of this chapter describes the position in the United States and under international standards.

> Recap: LIFO sells the newest costs first and leaves the oldest costs in inventory.

*Before moving on.* Last-in first-out takes the newest layers for cost of goods sold and keeps the oldest layers as ending inventory. For the dictionary sets, it gives Tk 23,400 and Tk 9,200. You should now be able to say why LIFO gives a lower profit than FIFO when prices rise.

* * *

## Weighted Average Cost

@! Go slowly here.

> Mixing tea of different prices in one jar shows the idea: the jar has one average price.

Think of a tea seller who pours tea bought at different prices into one large jar. After the pouring, no one can say which tea came from which purchase. Every spoonful of the mixture has the same average cost. The seller prices and counts the tea by that single figure. The third method treats the goods in the same way.

> Weighted average cost gives every unit the average cost of all units available.

@ Weighted average cost | A method that gives every unit the average cost of all units available.

The **weighted average cost** method is a method that gives every unit the average cost of all units available. The word weighted means that each layer counts in proportion to its number of units. A layer of 50 units has more effect on the average than a layer of 20 units. The method needs no choice of oldest or newest layer, because every unit receives the same cost.

> The unit cost is the total cost available divided by the total units available.

We apply the method to the case. *Given.* Cost available Tk 32,600 for 100 units, and a sale of 70 units for Tk 35,000. *Find.* The unit cost, the ending inventory, the cost of goods sold and the gross profit. *Formula.* Unit cost equals cost available divided by units available. In symbols, u = A ÷ N, where u is the unit cost, A is the cost available and N is the number of units available. Then E = n × u and C = x × u, where n is the units left, x is the units sold, and GP = S − C. *Steps.* u = Tk 32,600 ÷ 100 = Tk 326 a unit. E = 30 × Tk 326 = Tk 9,780. C = 70 × Tk 326 = Tk 22,820. GP = Tk 35,000 − Tk 22,820 = Tk 12,180. *Answer.* Under weighted average cost, ending inventory is Tk 9,780, cost of goods sold is Tk 22,820 and gross profit is Tk 12,180. *Check.* Tk 22,820 + Tk 9,780 = Tk 32,600, the cost available. The unit cost Tk 326 lies between Tk 300 and Tk 340, as an average must.

> Pause and check that you can find the average cost of the units available.

:pause 14.p2 | Using the unit cost found above, what is the cost of goods sold by weighted average if only 25 sets are sold from the 100 available?

> The figure shows how each method takes cost from the pile of layers.

The first figure shows the pile of Meghna and Sons as a column of three layers. The height of each block is in proportion to its number of units. Read a column from the bottom, where the oldest layer lies, to the top, where the newest layer lies. Hatched blocks show costs treated as sold. Blank blocks show costs that remain in ending inventory. In the third column all units are mixed, so the pile is one block at the average cost.

:fig Three methods as layers of cost leaving a pile | ch14-fig01.svg

> Comparing the three methods shows that weighted average cost lies between the other two.

The table collects the results. Read each column down for one method, and each row across to compare the methods. In every column the cost of goods sold plus the ending inventory equals Tk 32,600. Notice also that the weighted average figures lie between the FIFO and LIFO figures. This is no accident, because an average of the costs must lie between the lowest and the highest.

:table Results of the three methods for the dictionary sets
| Measure | First-in first-out | Last-in first-out | Weighted average |
| Cost of goods sold (Tk) | 22,400 | 23,400 | 22,820 |
| Ending inventory (Tk) | 10,200 | 9,200 | 9,780 |
| Gross profit (Tk) | 12,600 | 11,600 | 12,180 |

> The second figure shows the results of the three methods side by side.

The second figure is a bar chart of the results for Meghna and Sons. Each group of bars belongs to one method. The vertical axis shows taka in thousands, and the height of a bar shows the size of that measure. In each group the three bars are cost of goods sold, ending inventory and gross profit, in that order. The bars are marked by different hatching, so the chart reads in grey as well as in colour. Notice how little the bars differ between methods: the choice moves a small share of the cost.

:fig Results of the three methods side by side | ch14-fig02.svg

> Recap: weighted average cost uses one unit cost, and its results lie between the other two methods.

*Before moving on.* Weighted average cost divides the cost available by the units available and gives every unit that cost. For the dictionary sets the unit cost is Tk 326. You should now be able to say why its profit lies between the profits of FIFO and LIFO.

* * *

## Worked Case: Prices That Fall

> This worked case repeats the method with prices that fall, to show that the ranking reverses.

*Situation.* A different shop sells identical goods. It held 20 units at Tk 340, bought 30 units at Tk 320, and later bought 50 units at Tk 300. It sold 70 units at Tk 500, net sales Tk 35,000. These figures are for practice, and are not part of the case file. The prices fall from Tk 340 to Tk 300. *Question.* What are ending inventory, cost of goods sold and gross profit under each method?

> The reasoning first finds the cost available, and then applies each rule in turn.

*Reasoning.* The cost available is 20 × 340 + 30 × 320 + 50 × 300 = 6,800 + 9,600 + 15,000 = Tk 31,400, for 100 units. Under FIFO, the 30 units left are the newest, all at Tk 300, so E = Tk 9,000, C = Tk 22,400 and GP = Tk 12,600. Under LIFO, the 30 units left are the oldest: 20 at Tk 340 and 10 at Tk 320, so E = 6,800 + 3,200 = Tk 10,000, C = Tk 21,400 and GP = Tk 13,600. Under weighted average, u = 31,400 ÷ 100 = Tk 314, so E = 30 × 314 = Tk 9,420, C = 70 × 314 = Tk 21,980 and GP = Tk 13,020.

> The conclusion is that the ranking reverses when prices fall, while the cost available never changes.

*Conclusion.* When prices fell, LIFO gave the highest profit, Tk 13,600, and FIFO the lowest, Tk 12,600. When prices rose, as in the case file, the order was the reverse. Weighted average lay between the two in both situations. *Check.* In each method, cost of goods sold plus ending inventory is Tk 31,400: 22,400 + 9,000, then 21,400 + 10,000, then 21,980 + 9,420.

> Three slips occur often in this work, and each one can be prevented.

Common slips deserve a warning. The first is to take the sold units from the wrong end of the pile, which swaps the results of FIFO and LIFO. The second is to average the three unit costs, Tk 300, Tk 320 and Tk 340, instead of dividing the total cost by the total units. That error gives Tk 320, not Tk 326, because it ignores the number of units in each layer. The third is to forget that cost of goods sold and ending inventory must add to the cost available. Test every answer with that addition.

* * *

## Summary

> The summary restates the whole chapter in a few lines.

Goods bought at different prices form layers, and a cost flow assumption decides which layers are treated as sold. First-in first-out sells the oldest costs first. Last-in first-out sells the newest costs first. Weighted average cost gives every unit the same average cost. For Meghna and Sons, with rising prices, gross profit was Tk 12,600, Tk 11,600 and Tk 12,180 under the three methods, and ending inventory was Tk 10,200, Tk 9,200 and Tk 9,780. In every method, cost of goods sold plus ending inventory equals the cost available, Tk 32,600.

## Think It Through

:q 14.t1 | Prices rise during the period. Rank the three methods from the highest to the lowest gross profit, and explain the ranking in a few sentences.

:q 14.t2 | Prices fall during the period. How does the ranking change? What stays the same for all three methods?

## Where People Go Wrong

> Five common misunderstandings are stated here, each with its correction.

Some students believe that FIFO describes which goods leave the shelf. It describes only the order of costs, and the goods may leave in any order. Others believe that LIFO always gives the lowest profit. That is true when prices rise, but when prices fall LIFO gives the highest profit. A third belief is that the weighted average is the plain average of the unit costs. It is the total cost divided by the total units, which gives larger layers more weight. A fourth belief is that a method can create profit. A method only moves cost between periods; the total cost over the life of the business does not change. Last, students sometimes change the method each year to suit the result. A business should use one method consistently, so that profits can be compared.

## In History

> The United States allowed LIFO for tax in 1939, while international standards now bar it.

The choice of cost flow assumption is a matter of law and standards as well as of arithmetic. In the United States, the Revenue Act of 1939 allowed LIFO for income tax. A rule known as LIFO conformity requires a business that uses LIFO for its tax return to use it in its financial reports as well.^2 In a time of rising prices, LIFO gives a higher cost of goods sold, a lower profit and a lower tax bill, which explains why many American businesses chose it.

^2: The Revenue Act of 1939 and the conformity rule are described in articles in The Tax Adviser, a journal of the American Institute of Certified Public Accountants.

> Under international rules the position differs, because International Accounting Standard 2 bars LIFO.

Other countries follow the standards of the International Accounting Standards Board, a body based in London that issues International Financial Reporting Standards. Its International Accounting Standard 2, which deals with inventories, bars LIFO and allows FIFO and weighted average cost for goods that cannot be told apart. The board gave as one reason that tax considerations do not offer a sound basis for choosing an accounting method. A student must therefore ask which country and which standards apply before choosing a method.

## Review Questions

:q 14.1 | A shop has an opening inventory of 10 units at Tk 10 and buys 10 units at Tk 12. It sells 10 units for Tk 20 each, net sales Tk 200. Find ending inventory, cost of goods sold and gross profit under FIFO, LIFO and weighted average cost.

:q 14.2 | A shop has an opening inventory of 40 units at Tk 45. It buys 60 units at Tk 48 and then 100 units at Tk 52. It sells 130 units at Tk 80 each, net sales Tk 10,400. Find ending inventory, cost of goods sold and gross profit under all three methods, and check each result.

:q 14.3 | Prices fall. A shop has an opening inventory of 25 boxes at Tk 80 and buys 25 boxes at Tk 70. It sells 30 boxes at Tk 100 each, net sales Tk 3,000. Find ending inventory, cost of goods sold and gross profit under all three methods, and state which method gives the highest profit.

:q 14.4 | Use your answers to question 14.2. Express each gross profit as a percentage of net sales, to one decimal place. Then state which method gives the highest ending inventory and explain why.
