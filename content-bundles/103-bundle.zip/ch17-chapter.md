:chapter XVII | Accounts of Clubs and Sole Traders
:mood The treasurer says the box holds more money than last year: is the club better off?
:desc This chapter shows how organisations that do not aim at profit keep their accounts, and how their yearly cash record is turned into a fair statement of surplus or deficit. It then turns to a small trader who has kept no full books, and shows how to find the year's profit from the change in owner's equity. The same principles of Chapters 7 and 9 apply throughout.
:plate ch17-plate.svg | A village reading room, with the committee table and the treasurer's box

> A small puzzle: the cash grew, but the members are not sure the club is better off.

Imagine a village reading room, run by its members. They pay a yearly fee, and with the money they rent a room, buy newspapers and heat the room in winter. At the end of the year the treasurer opens the cash box and announces good news. A year ago it held Tk 4,000. Today it holds Tk 8,000. The cash has doubled.

> The puzzle asks what the cash figure leaves out.

A member asks three questions. Some members have not yet paid this year's fee; does that not count? Some members paid next year's fee early; is that money really this year's? The club bought a new table for Tk 10,000; is that a cost of this year only, or something that will serve for years? The treasurer's cash figure answers none of these questions. It records money moving in and out. It does not say whether the club has done well. This chapter shows how to answer with the tools you already know, in a new setting where nobody takes a profit.

> The chapter has two settings, and both use the principles you know.

There is a second puzzle, in a different setting. A small trader has kept no full books for a year. She has no journal, no ledger and no income statement. She knows only what she owns and owes at the start and at the end. Can she find her profit? She can, and the method is a pleasant surprise: it needs only two lists and some subtraction.

:box YOU WILL NEED
This chapter uses the three statements from Chapter 9 'Financial Statements and Closing Entries', section 9.1 'The Three Statements'. It also uses the accrual basis from Chapter 7 'Adjusting the Accounts', section 7.1 'Why Adjust'. The arithmetic is addition and subtraction; Appendix A1 'Maths You Will Use' holds a short reference.

* * *

## 17.1 Non-Trading Organisations

> Most of this book has described businesses that exist to earn a profit, and some organisations do not.

Until now this book has described businesses that are run to earn profit for an owner. Many organisations exist for another reason. A village reading room, a sports club, a school parents' association and a charity are examples. Nobody puts money in to take profit out. The members join to enjoy something together, or the donors give to help others.

> The accounting name for this group describes its purpose.
@ Non-trading organisation | An organisation, such as a club or charity, that exists to serve its members or a cause rather than to earn profit.

The accounting name for this group is **non-trading organisation**. A non-trading organisation is an organisation, such as a club or charity, that exists to serve its members or a cause rather than to earn profit. For example, the village reading room serves its members by providing newspapers and a quiet place to read. The name does not mean that the organisation never sells anything. A club may sell tea or tickets. It means that the main aim is not profit.

> The accounts follow the same principles, but some names change to suit the purpose.
@ Surplus | Word in use. In daily life, an amount left over or more than needed. In a non-trading organisation, the amount by which income exceeds expenditure in a period; if expenditure is larger, the result is a deficit.

Because no owner takes profit, some words change. The result of a year is not called profit but *surplus* when income is larger than expenditure, and *deficit* when it is smaller. A surplus is not a gain for an owner. It is money kept for the use of the members in the future. The owner's equity of a business has a counterpart in the club: the *accumulated fund*, which is the total of all past surpluses plus any starting fund. It is the equity of the members as a group. The principles are the same as for any business: assets, liabilities, income, expenditure and the matching of the two.

> The main source of money is the regular fee paid by members.
@ Subscription | A regular payment made by a member for belonging to an organisation.
@ Subscription | Word in use. In daily life, a payment to receive a newspaper or a service for a period. In a club, the yearly or monthly fee that a member pays for belonging to it.

The main income of most clubs is the **subscription**. A subscription is a regular payment made by a member for belonging to an organisation. For example, each member of the reading room pays Tk 500 a year. Other income comes from donations, from the entry fees of new members and from events such as an annual dinner. A subscription needs special care because members may pay late, on time or early. We shall return to this in section 17.2.

> A club keeps simple records, and its first summary is of cash only.
@ Receipts and payments account | A summary of all cash received and paid in a period, with opening and closing balances.

Small clubs usually keep little more than a cash book, and the treasurer's first report is a summary of it. This summary is called the **receipts and payments account**. A receipts and payments account is a summary of all cash received and paid in a period, with opening and closing balances. For example, the account of the reading room lists every taka that came into the cash box and every taka that went out during the year. The cash balance at the start is added on the receipts side, and the balance at the end is found by subtraction.

> The account has the same two-sided form as a cash book.

The account has two sides. The left side lists the receipts, beginning with the opening cash balance. The right side lists the payments, ending with the closing cash balance, which makes both sides equal. We now build a small account with clean numbers, so that the method is the only thing to learn. *Given.* The reading room had cash of Tk 4,000 on 1 January 2025. During 2025 it received subscriptions of Tk 30,000, donations of Tk 5,000 and Tk 8,000 from sales of tickets to an annual dinner. It paid rent of Tk 12,000, newspapers of Tk 9,000, dinner costs of Tk 6,000, repairs of Tk 2,000 and Tk 10,000 for a new table. *Find.* The closing cash balance.

> The steps add each side and subtract to find the closing balance.

*Steps.* Receipts: 4,000 + 30,000 + 5,000 + 8,000 = Tk 47,000. Payments: 12,000 + 9,000 + 6,000 + 2,000 + 10,000 = Tk 39,000. Closing cash: 47,000 − 39,000 = Tk 8,000. *Answer.* The cash on 31 December 2025 is Tk 8,000. *Check.* The treasurer said Tk 8,000, so the account agrees with the box.

:table Receipts and payments account for the year ended 31 December 2025
| Receipts | Tk | Payments | Tk |
| --- | --- | --- | --- |
| Opening cash | 4,000 | Rent | 12,000 |
| Subscriptions | 30,000 | Newspapers | 9,000 |
| Donations | 5,000 | Dinner costs | 6,000 |
| Dinner tickets | 8,000 | Repairs | 2,000 |
| | | New table | 10,000 |
| | | Closing cash | 8,000 |
| Total | 47,000 | Total | 47,000 |

> The account has strengths, and also limits that explain the rest of the chapter.

The receipts and payments account is useful. It is easy to prepare, and it proves that the cash is in the box. But it has three limits, and they match the member's questions in the puzzle. It shows cash only, so it ignores fees that are owed but not yet paid. It does not separate this year's money from money paid in advance for the next year. And it mixes everyday costs with the purchase of a table that will last for years. A profit-seeking business could not rely on such a record, and a club should not either.

> Before moving on, we collect the ideas of this section.

*Before moving on.* A non-trading organisation exists to serve members or a cause, not to earn profit. Its result is a surplus or a deficit, and its equity is the accumulated fund. A subscription is a regular payment by a member. The receipts and payments account summarises the cash only, so it cannot say whether the year went well. You should now be able to say what the account shows and the three things it leaves out.

## 17.2 Income and Expenditure Account

> The remedy is to apply the accrual basis, and the result has its own name.
@ Income and expenditure account | The non-trading organisation's equivalent of an income statement, showing surplus or deficit on an accrual basis.

The remedy for the three limits is a different statement, the **income and expenditure account**. An income and expenditure account is the non-trading organisation's equivalent of an income statement, showing surplus or deficit on an accrual basis. For example, it records the fees that belong to 2025, whether they were paid in 2025 or not. The accrual basis, which you met in Chapter 7, section 7.1 'Why Adjust', counts income and expense in the period to which they belong. The matching principle then puts the two together.

> The figure shows how the cash record is turned into the accrual record, step by step.

The figure below shows the change. Read it from left to right. The left box holds the receipts and payments account, which counts cash. The arrows mark the three changes you make: adjust for fees owed or paid early, adjust for costs owed or paid early, and take out the purchase of lasting assets. The right box holds the income and expenditure account, which counts what belongs to the year.

:fig Receipts and payments account turned into income and expenditure | ch17-fig01.svg

> The first change adjusts items that belong to a different period from the cash.

The first change deals with accrued and prepaid items. An accrued item belongs to this period but has not been paid in cash. A prepaid item has been paid in cash but belongs to a later period. Take subscriptions as the main example. Suppose some members owe fees for the year; those fees are income of the year, though no cash has come in. Suppose some members paid next year's fee; that cash is not income of this year. Suppose some members paid last year's arrears this year; that cash belongs to the earlier year. A single rule covers all three. In words: income for the year equals cash received, less arrears from earlier years received this year, less amounts received in advance for later years, plus amounts still owed for this year.

> The same idea applies to costs such as rent and newspapers.

The same idea applies to costs. Rent paid in advance for January of the next year is not an expense of this year. A newspaper bill that is owed at the year end is an expense of this year, though it has not been paid. Expense for the year equals cash paid, less amounts paid in advance, plus amounts still owed. This is exactly the method of Chapter 7, now applied to a club.

> The second change removes the purchase of a lasting asset.

The second change deals with the table. A table bought for Tk 10,000 will serve for years, so its cost is not an expense of this year alone. It is an asset, and it appears on the balance sheet. Chapter 15 'Plant Assets' deals with such assets, and Chapter 16 'Depreciation' teaches how a share of the cost is charged to each year of use. In this chapter we do not charge depreciation, so that the principle of conversion stands out.

> Events that earn money are shown by their net result.

A third matter concerns events. When the club holds a dinner, it receives money from tickets and pays for food. It is clearer to show only the difference, the surplus or deficit on the dinner, than to list both amounts among the other items. For the dinner of the example, tickets of Tk 8,000 less costs of Tk 6,000 give a surplus of Tk 2,000.

> The club also draws up a balance sheet, which uses the same form as any other.

The club also prepares a balance sheet at the year end. It lists the assets: the table, the cash, the fees still owed by members and the rent paid in advance. It lists the liabilities: the fees paid in advance by members and the unpaid newspaper bill. It ends with the accumulated fund, which equals assets less liabilities. The fund at the end equals the fund at the start plus the surplus for the year, or less the deficit.

:pause 17.p1 | A club receives Tk 1,000 in January for the year that begins in the following April. Is it income of the year in which it is received? Give a reason.

> Before moving on, we collect the ideas of this section.

*Before moving on.* The income and expenditure account applies the accrual basis to a non-trading organisation. It adjusts the cash record for amounts owed and amounts paid early, removes the purchase of lasting assets and shows the result as a surplus or a deficit. The balance sheet ends with the accumulated fund. You should now be able to say how cash received for subscriptions becomes income for the year.

## 17.3 The Sole Trader from Incomplete Records

> Some small traders keep no full books, yet they still need to know their profit.

Now we turn to the second puzzle. A sole trader is one person who owns and runs a business alone. Many small traders do not keep a journal and a ledger. They keep a cash box, a few bills and a memory. At the year end they, or a bank, or the tax office, want to know the profit. Records are incomplete, but two facts can be found by counting: what the business owns and owes at the start, and what it owns and owes at the end.

> A list of assets and liabilities at one date is the tool, and it has a name.
@ Statement of affairs | A list of a business's assets and liabilities at one date, used to find capital when records are incomplete.

That list is called the **statement of affairs**. A statement of affairs is a list of a business's assets and liabilities at one date, used to find capital when records are incomplete. For example, the trader counts her tools, her goods, the money customers owe her and the cash in her box, and then lists what she owes to suppliers. The assets less the liabilities give the owner's equity at that date. The statement of affairs looks like a balance sheet, but it is built from counting and memory, not from ledger accounts.

> The profit is found from the change in owner's equity, after two corrections.

How can profit come from two lists? Think of the owner's equity as a tank of water. Profit pours water in. The owner's own withdrawals for private use pour water out. Money the owner brings into the business from outside also pours water in. At the end of the year the level of the tank is known, because the statement of affairs gives it. So the profit is the change in the level, corrected for the two other flows. In words: profit equals closing owner's equity, less opening owner's equity, plus withdrawals, less new money brought in by the owner. In symbols, with E₂ for closing equity, E₁ for opening equity, W for withdrawals and N for new money: profit = E₂ − E₁ + W − N.

> A first example with small numbers shows the method.

*Given.* At 1 January the trader owned equipment Tk 20,000, goods Tk 12,000, money owed by customers Tk 6,000 and cash Tk 2,000, and she owed suppliers Tk 8,000. At 31 December she owned equipment Tk 18,000, goods Tk 15,000, money owed by customers Tk 7,000 and cash Tk 5,000, and she owed suppliers Tk 6,000. During the year she took Tk 10,000 for private use and brought in Tk 5,000 of her own savings. *Find.* The profit for the year.

> The steps build the two statements of affairs and then apply the formula.

*Steps.* Opening assets: 20,000 + 12,000 + 6,000 + 2,000 = Tk 40,000. Opening owner's equity: 40,000 − 8,000 = Tk 32,000. Closing assets: 18,000 + 15,000 + 7,000 + 5,000 = Tk 45,000. Closing owner's equity: 45,000 − 6,000 = Tk 39,000. Profit = 39,000 − 32,000 + 10,000 − 5,000 = Tk 12,000. *Answer.* The profit for the year is Tk 12,000. *Check.* Start from Tk 32,000, add the profit of Tk 12,000 and the new money of Tk 5,000, and subtract withdrawals of Tk 10,000: the result is Tk 39,000, which equals the closing owner's equity.

> The final accounts are then built with the profit as the balancing figure.

The trader can now prepare her final accounts. The balance sheet at 31 December lists the closing assets and liabilities from the statement of affairs, and its owner's equity is the opening owner's equity plus profit and new money, less withdrawals. The income statement shows the profit of Tk 12,000 as one figure. If she also has records of cash received and paid, she can show sales and expenses in more detail, by the methods of this chapter and Chapter 7. When she does not, the profit alone is the best result available.

> The method has limits, and an honest accountant states them.

The method has limits. It gives the amount of profit but not how it arose: you cannot see sales, expenses or gross profit. It depends on honest counting, since a missed asset or an unrecorded debt changes the answer. It also depends on correct figures for withdrawals, which small traders often do not record. For these reasons the result is an estimate that rests on the lists, and a trader should keep fuller records as the business grows. Reports that rely on such figures should state how they were prepared.

> A deficit is not always a failure, and a surplus is not always a success.

A word of judgement is useful here. A deficit in one year may be planned, for example when a club spends savings from earlier years on repairs. A surplus may be a warning, for example when a club saves money by delaying repairs that must be made later. The members of a club, the donors to a charity and the officials who inspect them read the accounts for these reasons. The figure matters less than the story behind it, and the accounts help the reader to find that story.

> Before moving on, we collect the ideas of this section.

*Before moving on.* A statement of affairs lists the assets and liabilities at one date, and the difference is the owner's equity. Profit equals the change in owner's equity, plus withdrawals, less new money brought in. The method gives profit but not its parts. You should now be able to find a trader's profit from two statements of affairs and two further facts.

## Worked Example: From Cash Record to Accrual Accounts

> The reading room's cash record is converted in full, with each adjustment shown.

*Given.* The receipts and payments account of the reading room for 2025 is in the table of section 17.1. Four further facts are known. First, members owed Tk 1,500 for 2024 at 1 January 2025, and this was paid in 2025. Second, Tk 2,000 of the subscriptions received in 2025 was paid in advance for 2026. Third, at 31 December 2025 members owed Tk 3,000 for 2025. Fourth, the rent paid includes Tk 1,000 for January 2026, and a bill of Tk 500 for newspapers was unpaid on 31 December 2025.

> The task is to find the income and expenditure for the year and the accumulated fund at the end.

*Find.* The income and expenditure account for 2025, the surplus, and the balance sheet at 31 December 2025.

> The subscriptions come first, because they need the longest calculation.

*Formula.* In words: subscriptions for the year equal cash received, less arrears of the earlier year, less advance receipts for the next year, plus arrears at the end of this year. In symbols, with R for cash received, A₁ for earlier arrears, P for advance receipts and A₂ for closing arrears: income = R − A₁ − P + A₂.

> The steps are shown one line at a time.

*Steps.* Subscriptions: 30,000 − 1,500 − 2,000 + 3,000 = Tk 29,500. Rent: 12,000 − 1,000 = Tk 11,000. Newspapers: 9,000 + 500 = Tk 9,500. Dinner surplus: 8,000 − 6,000 = Tk 2,000. The table of Tk 10,000 is an asset and is not an expense. Repairs stay at Tk 2,000.

:table Income and expenditure account for the year ended 31 December 2025
| Income | Tk | Expenditure | Tk |
| --- | --- | --- | --- |
| Subscriptions | 29,500 | Rent | 11,000 |
| Donations | 5,000 | Newspapers | 9,500 |
| Surplus on annual dinner | 2,000 | Repairs | 2,000 |
| | | Surplus for the year | 14,000 |
| Total | 36,500 | Total | 36,500 |

> The balance sheet shows what the club owns and owes at the end of the year.

At 1 January 2025 the club held cash of Tk 4,000 and was owed Tk 1,500, and it owed nothing, so its accumulated fund was Tk 5,500. The year added a surplus of Tk 14,000, so the fund at the end is 5,500 + 14,000 = Tk 19,500. The assets are the table, Tk 10,000; cash, Tk 8,000; fees owed by members, Tk 3,000; and rent paid in advance, Tk 1,000. The total is Tk 22,000. The liabilities are fees paid in advance, Tk 2,000, and the unpaid newspaper bill, Tk 500, a total of Tk 2,500.

> The answer and the check show that the two statements agree.

*Answer.* The surplus for 2025 is Tk 14,000 and the accumulated fund at the end is Tk 19,500. *Check.* Assets less liabilities are 22,000 − 2,500 = Tk 19,500, which equals the fund. The agreement proves that the adjustments are consistent. The surplus of Tk 14,000 is larger than the rise in cash of Tk 4,000 because of the new table (Tk 10,000 of cash that is not an expense) and the other adjustments.

> Common slips: using cash for subscriptions, treating the table as an expense, and the wrong sign on an adjustment.

Three slips are common. The first is to use the cash figure for subscriptions without adjusting. The second is to charge the table as an expense, which would turn a healthy surplus into a small one. The third is to add arrears of the earlier year instead of subtracting them. The formula protects you: earlier arrears and advance receipts are subtracted, and closing arrears are added.

## Summary

> The chapter's ideas in a few lines.

A non-trading organisation exists to serve members or a cause. Its first summary is the receipts and payments account, which shows cash only. The income and expenditure account applies the accrual basis, adjusts subscriptions and costs for amounts owed and paid early, leaves out lasting assets and ends in a surplus or a deficit. A sole trader with incomplete records builds a statement of affairs at the start and the end, and finds profit from the change in owner's equity, plus withdrawals, less new money.

## Think It Through

:q 17.t1 | A club reports a deficit in a year in which its cash balance rose. Give two reasons, using the ideas of this chapter, why both can be true.
:q 17.t2 | A trader's owner's equity fell from Tk 50,000 to Tk 46,000 during a year in which she took Tk 9,000 for private use and brought in no new money. Was her business profitable? Explain.

## Where People Go Wrong

> Belief: the closing cash balance shows how well the club has done.

Cash shows only money that moved. It leaves out fees owed, fees paid early and the cost of lasting assets, so it can mislead in either direction.

> Belief: a surplus means the club has made a profit for an owner.

A surplus belongs to the members as a group. It is added to the accumulated fund and used for the purposes of the club.

> Belief: all payments in the receipts and payments account become expenditure.

Payments for lasting assets, such as a table, become assets in the balance sheet. Only the costs that belong to the year appear in the income and expenditure account.

> Belief: the profit of a sole trader equals the rise in owner's equity.

The rise must be corrected. Withdrawals reduced the equity and new money raised it, so both must be put back or taken out before profit appears.

> Belief: a statement of affairs is a balance sheet from the ledger.

It is built by counting and by memory when no ledger exists. It looks like a balance sheet, but it is less exact, because nothing proves it.

## In History

> A famous charity began with a committee that needed to account for money received and spent.

On 5 October 1942, during the Second World War, a group of citizens met in the Old Library of the University Church in Oxford, England, and formed the Oxford Committee for Famine Relief. Its aim was to help civilians starving in Greece under occupation. The committee later became known as Oxfam. Its first big appeal, held in Oxford in 1943, raised £12,700 for the Greek Red Cross, and £2,300 of that came from a temporary gift shop.

> The case shows why a charity measures income and spending and not profit.

A charity such as this one has no owner who takes profit. Its accounts show money received from donors and money spent on its cause, which is the pattern of the receipts and payments account and the income and expenditure account of this chapter. Its test of success is not profit but how much of the money reaches the people it was raised for.

## Review Questions

:q 17.1 | A club began 2026 with cash of Tk 6,000. It received subscriptions of Tk 40,000 and donations of Tk 3,000, and paid rent of Tk 15,000, wages of Tk 12,000 and Tk 8,000 for a new cupboard. Prepare its receipts and payments account and find the closing cash.
:q 17.2 | In question 17.1 members owed Tk 2,000 of fees for 2025 at 1 January 2026, and these were paid in 2026. Tk 1,500 was received in 2026 for 2027. At 31 December 2026 members owed Tk 3,500 for 2026. Wages of Tk 1,000 were unpaid at the end of 2026. Find subscriptions income, wages expenditure and the surplus for 2026.
:q 17.3 | A trader had assets of Tk 60,000 and liabilities of Tk 15,000 at the start of a year, and assets of Tk 72,000 and liabilities of Tk 18,000 at the end. She withdrew Tk 20,000 for private use and brought in Tk 8,000 of savings. Find the profit.
:q 17.4 | A club bought a piano for Tk 30,000 in the year. Explain where this appears in the receipts and payments account, and in the income and expenditure account and balance sheet.

:read Horngren, Harrison and Oliver, Accounting, 2012
