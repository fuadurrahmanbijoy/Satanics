:chapter II | What Accounting Is
:mood Who needs to know how a shop is doing, and why should they believe the answer?
:desc Accounting turns the daily events of a business into reports that other people can read and trust. This chapter explains what accounting is, which people use its reports, and which basic rules keep its numbers fair. It is the map for the rest of the book.
:plate ch02-plate.svg | Auditors examining ledgers by lamplight

:box YOU WILL NEED
Chapter 1 'Business Activity and Companies', section 1.1 'What Businesses Do'; Chapter 1 'Business Activity and Companies', section 1.3 'Why Records Are Needed'.

> A family notebook can answer several questions for several readers.

Think of a family that writes every payment in one notebook: rent, food, school fees, bus fares. At the end of the month, the mother opens the notebook and asks one question: did we save anything? The same notebook can answer other questions. The landlord may want proof that the rent was paid. A bank, before lending money for a repair, may want to know whether the family can repay it. There is one notebook, but there are three readers and three questions. The notebook is useful only if every reader believes what it says.

> The shop in the running case has five readers and one set of records.

:case Case file, illustrative. Meghna and Sons is a family-run bookshop in Dhanmondi, Dhaka, owned by Nurul Meghna. Five parties read its records for 2025. Nurul reads the profit of Tk 750,000. The bank reads the loan of Tk 600,000. The publishers, who supply the books, read the Tk 1,150,000 owed to them. The tax authority reads the profit return. The staff read the wages of Tk 2,940,000.

> Five readers ask five different questions, which creates a puzzle for one set of records.

Notice that the five readers do not ask the same question. Nurul asks whether the shop earned a fair reward for the work put into it. The bank asks whether the loan will be repaid. The publishers ask whether they will be paid for their books. The tax authority asks whether the profit has been reported honestly. The staff ask whether the shop is secure enough to keep them employed. If each reader demanded a private set of records, the sets would disagree, and nobody would trust any of them. How can one business keep one set of records that serves all five readers? And why should any of them believe it? This chapter answers both questions. It also states the purpose of the whole book, because every later chapter teaches one step of the process described here.

* * *

## 2.1 The Idea of Accounting

> A market seller already performs the three actions of accounting.

@! Go slowly here.

Picture a woman who sells vegetables at a market stall. Each morning she buys sacks of produce. During the day she sells by the kilogram. In the evening she counts the money in her tin and writes three numbers in a notebook: what she spent, what she received, and what is left. She has done three things without naming them. She has noticed events, written them down, and drawn a conclusion. Accounting is these same actions, performed in an orderly way for many readers.

> Accounting means recording, sorting and reporting the money effects of events.

@ Accounting | The process of recording, sorting and reporting the money effects of a business's events to people who need them.

The name for the whole process is **accounting**. Accounting is the process of recording, sorting and reporting the money effects of a business's events to people who need them. An event is anything that changes the money position of a business, such as buying books, selling a novel or paying a wage. Recording means writing the event down. Sorting means placing like events together, so that all sales stand in one place. Reporting means presenting the sorted totals to a reader in a form the reader can use. When Meghna and Sons sells a novel, accounting records the sale, sorts it with the other sales, and reports the total.

> The word account has an everyday meaning and a special accounting meaning.

@ Account | Word in use. In daily life, a record of money in a bank. In accounting, a named record of one kind of item, such as Cash or Sales.

You may know the word *account* from a bank, where it means a record of the money you hold there. Accountants use the word in a related but different way. In their sense, an account is a named record of one kind of item, such as Cash or Sales. Chapter 4, 'Accounts, Debits and Credits', teaches accounts in detail. For now, remember only that accounting is built from such named records.

> A flow chart shows events becoming records, then reports, then decisions by readers.

The figure that follows shows the whole process on one page. Read the top row from left to right. Each box is a stage, and each arrow shows the direction in which information moves. The first box holds the events. The second holds the records made from them. The third holds the reports built from the records. The lines that leave the third box lead to the readers in the bottom row, who are the subject of the next section.

:fig Accounting as a flow from events to reports to users | ch02-fig01.svg

> Bookkeeping is the recording stage; accounting is the whole process.

@ Bookkeeping | The recording part of accounting: writing down each transaction in the right book.

People often use the words accounting and bookkeeping as if they meant the same thing, but they do not. **Bookkeeping** is the recording part of accounting: writing down each transaction in the right book. A transaction is one event that can be measured in money, such as the sale of one novel. The bookkeeper records. The accountant also sorts, checks and reports, and decides how a doubtful item should be treated. An everyday bridge helps here. The person who writes each shopping payment in the family notebook is keeping books. The person who studies the notebook to plan next month's spending is doing accounting.

> Accounting divides into branches according to the readers it serves.

Accounting divides into branches, and the readers decide the division. Think first of Nurul, who wants a weekly report to decide which books to order. Think next of the bank, which wants a formal report once a year. These two readers need different reports, prepared in different ways. That difference gives us the two main branches of accounting.

> Financial accounting serves outsiders, and its reports follow written rules.

@ Financial accounting | Accounting that prepares reports for outsiders, such as lenders, owners and tax authorities.

**Financial accounting** is accounting that prepares reports for outsiders, such as lenders, owners and tax authorities. An owner who takes no part in managing the business is also an outsider. The bank's yearly report and the tax authority's profit return come from financial accounting. Its reports follow written rules, which section 2.3 explains, so that outsiders can compare one business with another.

> Management accounting serves managers, and its reports follow no outside rule.

@ Management accounting | Accounting that prepares reports inside the business to help managers plan and control.

**Management accounting** is accounting that prepares reports inside the business to help managers plan and control. Nurul's weekly report on which books sell fastest is management accounting. No outside rule governs such a report; the manager designs it to answer whatever question needs an answer. The chapters that follow concentrate on financial accounting. Management accounting is named here so that you know it exists.

:pause 2.p2 | A school employs a clerk who writes each fee payment into the fee book. Is the clerk's work bookkeeping or accounting? Give one reason.

> A short review of the ideas in this section.

*Before moving on.* Accounting is the process of recording, sorting and reporting the money effects of events to people who need them. Bookkeeping is one part of that process, the recording part. Financial accounting serves outsiders by written rules, and management accounting serves managers without outside rules.

> A sentence the reader can test against the section.

You should now be able to say: accounting is the whole journey from an event to a report, and bookkeeping is only its first stage.

* * *

## 2.2 Who Uses Accounting Information

> One question sorts the readers into an inside group and an outside group.

Return to the five readers of the shop's records. Is there a way to sort them? One question gives a useful sorting: does this reader help to run the business from day to day? Nurul does. The bank, the publishers and the tax authority do not. Readers who help to run the business are called internal users, and those who do not are called external users. Internal users are people inside the business, such as managers and owner-managers, who use information to plan and control. External users are people outside it who have a claim on it or an interest in it.

> Each external user wants to know something different about the business.

@! Go slowly here.

Take the external users one at a time, and imagine each person's point of view. A bank that has lent money asks whether the shop can repay the loan on the agreed dates. A publisher that has delivered books not yet paid for asks whether the shop will pay what it owes. A tax authority asks whether the profit has been reported honestly, because the tax due depends on it. An owner who does not manage the business asks whether the profit is worth the money invested. A customer rarely reads accounting reports at all, but cares whether the shop will still be open next year to order a special book.

> Staff are a borderline group, and this book treats them as external users.

Staff are a harder case, and many students find them confusing, because staff work inside the shop yet do not run it. In this book we treat them as external users. They read finished reports, not the working records, and they cannot change what the reports say. Their question is whether the wages of Tk 2,940,000 recorded for them are safe and whether the shop will continue to employ them. Other books may place employees among the internal users, so the grouping is a convention, not a law of nature.

> A table lays out each reader beside the question that reader asks.

The table that follows gathers the five readers of the case. Read each row from left to right: the reader, the group, the question that reader asks, and the figure from the case file that answers part of that question. For example, the row for the bank says that the bank is an external user, that it asks whether the loan can be repaid, and that the loan of Tk 600,000 is the figure that matters to it.

:table What each reader of the shop's records asks
| Reader | Group | Question asked | Figure from the case |
| Nurul | Internal | Did the shop earn enough profit? | Profit Tk 750,000 |
| The bank | External | Can the loan be repaid? | Loan Tk 600,000 |
| The publishers | External | Will the shop pay for the books? | Owed Tk 1,150,000 |
| The tax authority | External | Is the profit honestly reported? | Profit return |
| Staff | External (see text) | Are wages and jobs safe? | Wages Tk 2,940,000 |

> One set of records can answer many questions because the questions share the same facts.

Now the puzzle from the start of the chapter can be partly answered. The five questions differ, but the facts behind them are the same: what the shop earned, what it owes, what it holds. One set of records can serve all five readers when every reader receives reports built from the same events and the same rules. Section 2.3 explains the rules. Notice also the viewpoint of the owner, who is both a reader and a person who must answer to the others: Nurul needs honest reports precisely because the bank, the publishers and the tax authority will test them.

> The same five kinds of reader exist whatever kind of business is studied.

> Recall: merchandising business, service business, manufacturing business, Chapter 1, section 1.1.

Remember that Meghna and Sons is a merchandising business: it buys books and sells them again. A service business, such as a tailor who sells stitching, and a manufacturing business, such as a printing works that makes books, have the same kinds of reader. The figures differ, but the questions are alike. A lender always asks about repayment, a supplier about payment, and a tax authority about honest profit.

> A short review of the readers and their questions.

*Before moving on.* Internal users run the business and use information to plan and control. External users stand outside it and ask about repayment, payment, honest profit, return on money invested, or security of work. One set of records serves them all when the reports share the same facts and rules.

> A sentence the reader can test against the section.

You should now be able to say: an internal user helps to run the business, an external user does not, and each external user asks a different question of the same records.

* * *

## 2.3 Rules and Concepts

> Reports can be trusted only if every business follows the same rules.

Suppose two bookshops each report a profit. The first records its books at the price it paid for them. The second records them at the price it hopes to receive one day. The two profits cannot be compared, and a bank reading both reports would not know which to believe. To prevent this, accountants agree on rules before the records are made. This section presents the rules that give accounting its trustworthiness: written standards, then three basic ideas about what is being recorded, then the reports that result.

> An accounting standard is a written rule that makes businesses report alike.

@ Accounting standard | A written rule about how to record and report items, so that different businesses report in the same way.

@ Standard | Word in use. In daily life, a level of quality, as in a high standard of service. In accounting, a written rule about how to record and report items.

An **accounting standard** is a written rule about how to record and report items, so that different businesses report in the same way. For example, a standard may say how the cost of goods held for sale must be measured. In daily speech, the word *standard* means a level of quality, as in "a high standard of service". Here it means a rule, not a level of quality. Which standards apply depends on the place. Many countries, including Bangladesh, use the International Financial Reporting Standards, while others use national standards of their own.^1

^1: The International Financial Reporting Standards are published by the International Accounting Standards Board, which replaced the committee described in the history section on 1 April 2001.

> The first basic idea keeps the shop's money apart from the owner's own money.

@! Go slowly here.

Begin with a household example. A father who runs a small shop takes money from the till to pay the family electricity bill. If the shop's records show that payment as a shop cost, the shop will look less profitable than it is. The bank, reading the report, will form a false picture of the shop. The remedy is to keep two sets of money, the family's and the shop's, and to write only the shop's events in the shop's records.

> The business entity rule treats the business as separate from its owner.

@ Business entity | The rule that a business is treated as separate from its owner when records are kept.

This remedy is the rule of the **business entity**. The business entity rule says that a business is treated as separate from its owner when records are kept. Nurul's household spending does not appear in the records of Meghna and Sons. The rule also applies between two businesses of one owner. Meghna Binding Service, a book-binding workshop that began on 1 January 2026, keeps its own separate set of books, even though Nurul owns both businesses.

> The business entity rule is an accounting rule, which may differ from the law.

The rule has an exception that causes confusion. In law, a sole trader, meaning one person who owns a business alone, is often not a separate person from the business. A company, in contrast, is a separate person in law. The accounting rule does not wait for the law: it treats every business as separate from its owner, whether or not the law agrees. The rule serves the readers, who ask about the business and not about the family.

:pause 2.p1 | Nurul takes a book from the shop shelf as a gift for a relative. Using the business entity rule, explain why the shop's records should show this event.

> A short review of the first basic idea.

*Before moving on.* The business entity rule keeps the shop's records free of the owner's private spending, and it applies between two businesses of one owner. You should now be able to say: the shop's records describe the shop, not the family.

> The second basic idea assumes that the business will continue.

@ Going concern | The assumption that a business will continue to operate for the foreseeable future.

Consider a farmer who plants fruit trees. The farmer expects to pick fruit for many years, so the trees are valued by what they will bear, not by the timber they would give if cut down today. Accounting makes a similar choice. The **going concern** assumption is that a business will continue to operate for the foreseeable future. Under this assumption, the shelves and counter of the bookshop are treated as items that the shop will use for years, not as items that must be sold tomorrow.

> The going concern assumption fails when a business is about to close.

The assumption has a clear limit. If a business is about to close, it will not use its shelves for years; it will sell them. In that case the records must show what the items would fetch when sold, and the going concern assumption no longer holds. Staff and lenders watch for this danger, because it changes the meaning of every number in the report.

> The third basic idea records items at the price actually paid.

@ Historical cost | The rule of recording an asset at the price paid for it, not at its present value.

Suppose the shop buys a display shelf. A year later, a neighbour says the shelf would sell for more than the shop paid. Which number should the records show? The rule of **historical cost** is the rule of recording an asset at the price paid for it, not at its present value. The word *asset* means something of value that the business owns, such as a shelf or a book; Chapter 3, 'The Accounting Equation', studies assets properly.

> Historical cost is reliable because the price paid can be proved.

The reason for the rule is trust. The price paid is a fact that an invoice or a receipt can prove. A present value is an opinion, and two honest people may hold different opinions. A bank would prefer the fact. There is an exception: some accounting standards allow certain items to be shown at present value, and later chapters show how the cost of an item is lowered over time. This book first teaches the plain rule of historical cost, because it is the base on which the exceptions stand.

> A short review of the three basic ideas.

*Before moving on.* Business entity keeps the owner's money apart from the shop's. Going concern assumes the shop will continue. Historical cost records items at the price paid. You should now be able to say: each idea protects the reader from a misleading number.

> Financial statements are the formal reports at the end of the process.

@ Financial statement | A formal report of a business's results or position, prepared at the end of a period.

The reports that result from these rules are called financial statements. A **financial statement** is a formal report of a business's results or position, prepared at the end of a period. A period may be a month, a quarter or a year. The yearly reports of Meghna and Sons for 2025 are financial statements. They carry the profit of Tk 750,000 that Nurul, the bank and the tax authority read.

> The main statements are previewed here and taught in a later chapter.

Three statements are most common: the income statement, which shows profit; the statement of owner's equity, which shows what the owner's share has become; and the balance sheet, which lists what the business owns and owes on one day.^2 Chapter 9, 'Financial Statements and Closing Entries', teaches them. Notice how the whole process now closes into a circle. Events are recorded, recording follows the standards and the three ideas, and the statements carry the result to the readers.

^2: Under the International Financial Reporting Standards, the balance sheet is called the statement of financial position. This book uses the name balance sheet.

:box IN SHORT
Accounting records, sorts and reports money events. Standards, the business entity rule, going concern and historical cost make the reports trustworthy for their readers.

> A short review of the section.

*Before moving on.* Accounting standards make businesses report alike. Three ideas decide what is recorded: separate entity, continued operation and price paid. Financial statements deliver the result. You should now be able to say: readers can trust accounting reports because rules, not moods, decide what the reports contain.

* * *

## Worked Case: Matching Users to Questions

> A worked case applies the chapter's ideas to the shop's five readers.

:case Case file, illustrative. Situation: the 2025 records of Meghna and Sons are read by Nurul (profit Tk 750,000); the bank (loan Tk 600,000); publishers (owed Tk 1,150,000); the tax authority (profit return); and staff (wages Tk 2,940,000).

> The question asks for a reader, a branch and a rule for each party.

*Question.* For each reader, which question does the reader ask, which branch of accounting serves the reader, and which rule makes the answer trustworthy?

> Reasoning begins with the bank and the publishers, who are outsiders with money at stake.

*Reasoning.* Take the bank first. It is an external user, so financial accounting serves it. It asks whether the loan of Tk 600,000 can be repaid. The answer is trustworthy because accounting standards make the shop report in the same way as other borrowers. Take the publishers next. They are external users. They ask whether the shop will pay the Tk 1,150,000 owed to them. The business entity rule matters here, because the debt belongs to the shop and not to Nurul's household.

> Reasoning continues with the tax authority and the staff.

The tax authority is an external user. It asks whether the profit return is honest, and standards give it a common method to test. The staff, treated here as external users, ask whether the wages of Tk 2,940,000 are safe and whether the shop will go on. The going concern assumption is the rule that matters to them, because it states that the shop is expected to continue.

> Nurul needs both kinds of accounting.

Nurul is the internal user. Nurul reads the profit of Tk 750,000, which comes from financial accounting. Nurul also needs management reports, such as the weekly report on fast-selling books, to decide what to order. Historical cost supports the profit figure, because every book is recorded at the price paid.

> The conclusion states the match and the check confirms it is complete.

*Conclusion.* Five readers, five questions, one set of records. Four readers are served by financial accounting, and Nurul is served by both branches. *Check.* Count the readers: five in the case file, five in the answer. Each answer names one reader, one question and at least one rule. The wages figure, the loan figure and the profit figure all agree with the case file.

* * *

## Summary

> The chapter's main ideas in a few lines.

Accounting is the process of recording, sorting and reporting the money effects of a business's events to people who need them. Bookkeeping is its recording part. Financial accounting serves outsiders and follows written standards; management accounting serves managers. Internal users run the business; external users do not. Four ideas keep reports trustworthy: accounting standards, the business entity rule, the going concern assumption and historical cost. Financial statements carry the result to the readers.

## Think It Through

:q 2.t1 | Nurul pays a household bill from the shop's till. Using the business entity rule and the point of view of the bank, explain why a shop's money and a home's money must be kept apart.

## Where People Go Wrong

> Bookkeeping and accounting are different things.

Many students think that bookkeeping and accounting are the same. They are not. Bookkeeping is the recording part. Accounting also sorts and reports, and it serves readers who need decisions.

> Only managers read accounting information.

A common error is to think that only managers use accounting. In fact, banks, suppliers, tax authorities, owners and staff all read it. Each asks a different question of the same records.

> The business entity rule is not the same as company law.

Some students believe that the business entity rule applies only to companies. It applies to every business, including a one-person shop, because accounting treats the business as separate whatever the law says.

> Historical cost is not always the best measure, but it is the most reliable.

A fourth confusion is to think that historical cost shows what an item is worth today. It does not. It shows the price paid, which can be proved. Present value may differ, and that is why the rule is a choice of reliability over currency.

## In History

> The committee of 1973 first tried to give the world one set of accounting rules.

By the early 1970s, businesses in many countries sold goods and borrowed money across borders, yet each country kept its own accounting rules. A bank in one country could not easily compare a borrower's reports with those of a borrower in another. On 29 June 1973, professional accounting bodies from several countries formed the International Accounting Standards Committee in London. The idea came from Sir Henry Benson, a leading British accountant and former president of the Institute of Chartered Accountants in England and Wales. The bodies came from Australia, Canada, France, Germany, Japan, Mexico, the Netherlands, the United Kingdom and Ireland, and the United States.

> The committee's standards were later taken over by a board.

Its members worked part-time as standard setters while holding other jobs. They aimed to write standards in the public interest and to win acceptance for them across the world. The committee worked until 2000, and on 1 April 2001 a new body, the International Accounting Standards Board, replaced it and continued its work. The story shows what this chapter has argued: accounting is trustworthy when many people agree on the rules first.

## Review Questions

:q 2.1 | Match each reader of Meghna and Sons to the question it asks: Nurul, the bank, the publishers, the tax authority and the staff.
:q 2.2 | Suppose the bank asks the shop for its records, but only the weekly book-sales report is shown. Which branch of accounting does the weekly report belong to, and why is it not enough for the bank?
:q 2.3 | A village tailor, who sells stitching, keeps her family's rent and food costs in her business book. Which rule is broken, and who is misled?
:q 2.4 | A shop is told it will close in three months. Explain what happens to the going concern assumption and to the way its shelves are recorded under historical cost.

:read Camfferman, Kees and Zeff, Stephen A., Financial Reporting and Global Capital Markets: A History of the International Accounting Standards Committee, 1973-2000, 2007
