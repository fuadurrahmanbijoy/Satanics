:chapter XX | The Whole Cycle and Reporting Periods
:mood Which twelve months are we reporting, and which costs belong to them?
:desc This chapter completes your first pass through the accounting cycle for a trading business. It explains why a business reports for a chosen year and for shorter periods inside it, and why some costs wait in inventory while others reach the income statement at once. It then links every report you have met into one connected whole.
:plate ch20-plate.svg | A clerk and his master at the year-end table, with the finished ledgers stacked beside them

> A friend's question about a shop can be answered with three different stretches of time.

Imagine that you own a small bookshop. On the evening of 30 September, a friend who has lent you money asks how the shop is doing. You open your records. You could describe the whole of last year. You could describe the three months that ended today. Or you could describe the time since 1 July, when the government's own twelve-month period began. All three answers are true, and each gives different figures. Which one should you give, and who decides?

> A second puzzle: two payments that look alike are treated in different ways.

Now consider a second puzzle. During those three months the shop paid Tk 2,450,000 for new books and Tk 180,000 for rent. Both payments are money that left the business, yet an accountant handles them differently. The books are not charged against profit until a customer buys them; until then they wait on the shelf as inventory. The rent belongs to the three months in which the shop used the building, whether or not a single book is sold. Why the difference?

> A third puzzle: the many records and reports of earlier chapters must join into one system.

The third puzzle is larger. By now you have met the journal, the ledger, the trial balance, adjusting entries, the worksheet, the financial statements and closing entries. Each has its own chapter. This chapter asks how they fit together. If one number changes in the ledger, which reports must change with it, and in what order? When you can answer that, you hold the whole accounting cycle in your mind, and not only its parts.

> The chapter rests on earlier work on the balance sheet, the classified income statement and cost flow.

*You will need:* Chapter 9, 'Financial Statements and Closing Entries', section 9.3 'Reversing Entries'; Chapter 10, 'Accounts of a Merchandising Company', section 10.2 'Classified Income Statement'; Chapter 14, 'Costing Inventory: FIFO, LIFO and Weighted Average', section 14.1 'The Problem of Changing Prices'; and Appendix A1, 'Maths You Will Use'.

* * *

## 20.1 Fiscal Year and Interim Periods

@! Go slowly here.

> A business never stops, so accountants cut its life into equal slices of time and measure each slice.

Think first of a family budget. A family that earns a monthly salary does not wait until old age to check its spending. It looks at one month, sees what came in and what went out, and plans the next month. A school does the same with its school year, which begins when classes begin and not on 1 January. A business needs the same habit. It may trade for fifty years, but its owner cannot wait fifty years to learn whether it earns a profit. So the owner chooses a slice of time and measures it.

> A fiscal year is any twelve-month reporting period that a business chooses; it may start in any month.

@ Fiscal year | Any twelve-month period a business chooses for its yearly reports, which may start in any month.

The usual name for this slice is the **fiscal year**. A fiscal year means any twelve-month period that a business chooses for its yearly reports, and it may start in any month. A shop might choose 1 April to 31 March, or 1 July to 30 June. The word *fiscal* comes from the Latin *fiscus*, a basket for money, and it now means "to do with money and accounts".

@ Year | Word in use. In daily life, a year is the twelve months from 1 January to 31 December. In accounting, a year is whichever twelve months a business chooses for its reports.

> The word year has two meanings, and the accounting meaning is the chosen one.

Notice that the word *year* now has two meanings. In daily life it usually means 1 January to 31 December. In accounting it means whichever twelve months the business has chosen. The most familiar choice is the calendar year, which runs from 1 January to 31 December. A business that picks the calendar year has a fiscal year that matches the calendar. A business that picks another start month does not.

> The case file shows a business that has chosen the calendar year.

:case Case file, illustrative. Meghna and Sons, the family-run bookshop in Dhanmondi, Dhaka, reports for a calendar year ending 31 December. Its yearly reports therefore cover 1 January to 31 December. Bangladesh's government fiscal year is different: it runs from 1 July to 30 June.

> Two bodies in one country may use two different twelve-month periods.

The case file shows an important point. A government and a business in the same country can use different twelve-month periods, and neither one is wrong. Each chooses the period that suits its own work. Many students find this confusing, because they expect one year for everyone. The remedy is to ask of every report the same question: from which date to which date does it run?

> Some businesses end their year when trade is quiet, because counting inventory is then easier.

Why would a business choose a year that is not the calendar year? One common reason is the pattern of trade. A seller of school uniforms might sell most items in the weeks before term begins. If the year ended in the middle of that rush, the shelves would be in constant movement and inventory would be hard to count. Ending the year when trade is quiet gives a calmer count. Rules differ from country to country, and tax law or company law can limit the choice, so a business must check the rules of its own country.

> A year gives news only once, so lenders and owners also want reports for shorter slices.

A fiscal year answers the question "How did we do?" only once a year. A lender who must decide this week whether to lend more money cannot wait. An owner who sees losses building would like to know in the third month, and not after the twelfth. For this reason businesses also prepare reports for shorter slices of time.

@ Interim period | A reporting period shorter than a year, such as a quarter.

> An interim period is a reporting period shorter than a year, such as a quarter.

An **interim period** is a reporting period shorter than a year, such as a quarter. A quarter is three months; four quarters make a year.^1 Months, quarters and half-years are all interim periods.
^1: A quarter may begin in any month. For a business with a calendar year, the quarters end on 31 March, 30 June, 30 September and 31 December.

@ Period | Word in use. In daily life, a period is any stretch of time, such as a school lesson. In accounting, a period is the span of time that one set of reports covers, such as a month, quarter or year.

> The case file records one interim period of three months.

:case Case file, illustrative. Meghna and Sons prepared a report for the interim period of the quarter ended 30 September 2026. Net sales in that quarter were Tk 3,900,000. The quarter began on 1 July 2026 and is the third quarter of the shop's calendar year.

> Different bodies measure different periods, and a table lays the dates side by side.

The table below sets four periods side by side. Read each row from left to right: the name, the dates, and the length. The dates for Meghna and Sons come from the case file; the other two come from the facts you have already read.

:table Four reporting periods compared
| Period | Dates | Length |
| Meghna and Sons, calendar year | 1 January to 31 December | 12 months |
| Meghna and Sons, interim period | 1 July to 30 September 2026 | 3 months |
| Bangladesh government fiscal year | 1 July to 30 June | 12 months |
| United States federal fiscal year (from 1976) | 1 October to 30 September | 12 months |

> Interim reports follow the same methods as yearly reports but rely more on estimates.

Interim reports use the same accounts and the same method as yearly reports. They are, however, less final. Some adjusting entries, such as the use of equipment during the quarter, must be estimated, and the full-year count of inventory may not yet have taken place. Treat interim figures as a useful early signal, and not as the last word.

> Recap of fiscal year and interim period.

*Before moving on.* A fiscal year is any twelve months a business chooses, and the calendar year is one such choice. An interim period is shorter than a year, and a quarter is the usual example. Always ask of a report: from which date to which date?

> The reader should now be able to state the difference between the two kinds of period.

*You should now be able to say:* "A fiscal year is a chosen twelve months, and an interim period is a shorter slice inside it."

## 20.2 Product Costs and Period Costs

> A shop owner pays for books and for rent, yet only one of these payments waits on the shelf.

Return to the second puzzle. The owner of Meghna and Sons has paid for books, for freight in, for rent and for wages. All four are costs, and all four reduce cash. But the first two are tied to goods, and the last two are tied to time. That difference decides when each cost reaches the income statement.

@ Product cost | A cost of buying or making goods held for sale, such as the price paid for books and freight in.

> A product cost is the cost of buying goods that are held for sale, including freight in.

A **product cost** is a cost of buying or making goods held for sale, such as the price paid for books and freight in. Freight in means the carrier's charge for bringing the goods to the shop. A product cost first becomes part of inventory. It stays there until the goods are sold, and only then does it move to cost of goods sold in the income statement.^2
^2: Which cost is attached to which unit sold depends on the cost flow assumption. Chapter 14 teaches this in section 14.1, 'The Problem of Changing Prices'. This chapter assumes first-in first-out, but any method would classify the costs in the same way.

@ Cost | Word in use. In daily life, cost is the price you pay for something. In accounting, a cost is an amount given up to obtain goods or services, and it is later either held as an asset or charged as an expense.

> The word cost has an everyday meaning and a narrower accounting meaning.

The word *cost* needs care. In daily life it means the price paid. In accounting it means an amount given up to get goods or services, and the later treatment depends on what was bought. A cost for goods held for sale is held as inventory until the sale. A cost for something used up with time is charged at once.

@ Period cost | A cost charged to the period in which it is incurred, such as rent or wages.

> A period cost belongs to the time in which it is incurred, not to any particular goods.

A **period cost** is a cost charged to the period in which it is incurred, such as rent or wages. The shop must pay rent for July, August and September whether it sells ten books or ten thousand. The cost belongs to the time, and not to a particular book. So the income statement for the quarter carries the rent in full, and nothing waits on the shelf.

> The case file lists the product costs and period costs of one quarter.

:case Case file, illustrative. For the quarter ended 30 September 2026, Meghna and Sons recorded these product costs: books bought Tk 2,450,000 and freight in Tk 40,000. It recorded these period costs: rent Tk 180,000 and wages Tk 735,000.

> The two classes of cost differ in what they are tied to and in when they reach the income statement.

The table below compares the two classes. Read down each column to see how a cost behaves. The first row shows what the cost is tied to, the second shows where it first appears, and the third shows when it reaches the income statement.

:table Product costs and period costs compared
| Feature | Product cost | Period cost |
| Tied to | Goods held for sale | A stretch of time |
| First appears | In inventory, on the balance sheet | Straight in the income statement |
| Reaches income statement | When the goods are sold | In the period incurred |
| Examples from the case | Books bought, freight in | Rent, wages |

:pause 20.p1 | Meghna and Sons pays Tk 40,000 to a carrier to bring books into the shop, and Tk 180,000 as rent. Which payment is a product cost, and which is a period cost?

> A classified income statement groups these costs under separate headings.

Chapter 10 shows how a classified income statement groups costs under headings.^3 The product costs sit inside cost of goods sold, which is deducted from net sales to find gross profit. The period costs sit below gross profit as operating expenses. You can think of the income statement as a staircase: product costs come off first, then period costs.
^3: Chapter 10, 'Accounts of a Merchandising Company', section 10.2 'Classified Income Statement'.

> A cost can look the same on paper yet belong to the other class, so ask what it is tied to.

Some costs are easy to misplace. Delivery to a customer is freight out, and it is tied to the act of selling, not to the buying of goods, so it is a period cost. Freight in, which brings goods to the shop, is a product cost. The name "freight" appears in both, but the question that sorts them is the same: is the cost tied to goods held for sale, or to time and selling? A second exception concerns unsold goods. If the shop buys books in September and sells none before the quarter ends, the whole product cost is still in inventory on 30 September, and none of it has reached the income statement.

> The viewpoint of the owner, the manager and the lender explains why the split matters.

Each reader of the reports uses this split differently. The owner wants to know whether the books bought are selling, which the product costs show. The manager wants to control rent and wages, which belong to the period and do not change with each sale. A lender wants to know whether sales cover both classes of cost. If the two classes were mixed, none of these readers could separate the cost of the goods from the cost of running the shop.

> Recap of product cost and period cost.

*Before moving on.* A product cost belongs to goods held for sale and waits in inventory until the sale. A period cost belongs to the time in which it is incurred and reaches the income statement at once. Freight in is a product cost; rent and wages are period costs.

> The reader should now be able to state what separates the two classes of cost.

*You should now be able to say:* "A product cost follows the goods, and a period cost follows the calendar."

## 20.3 The Linked Statements

@! Go slowly here.

> A single number in the ledger flows through every report, much as one water pipe feeds several taps.

Think of a water pipe that feeds three taps in a house. If the pipe is blocked, all three taps fail. The accounts work the same way. Every figure in the ledger feeds the reports, and a change at the source changes every tap it feeds. Learn the pipe first and the taps follow.

> The cycle begins with transactions and ends with a post-closing check on the accounts.

The cycle has a fixed order. First, transactions are recorded in the journal and posted to the ledger. Second, the accounts are listed in a trial balance to test that debits equal credits. Third, adjusting entries are made for items such as accrued wages and used supplies, and the adjusted accounts are listed again. Fourth, the income statement, the statement of owner's equity and the balance sheet are prepared. Fifth, closing entries reset the revenue and expense accounts to zero for the next period.

:fig How the trial balance, the adjustments, the statements and the closing entries connect | ch20-fig01.svg

> The figure shows the cycle as boxes joined by arrows, with dashed boxes for the steps that change balances.

To read the figure, follow the arrows. Each box is a step or a report, and each arrow means that the figures pass on to the next box. The dashed boxes mark the two steps that change account balances: the adjusting entries and the closing entries. The solid boxes only collect and report the balances that already exist.

> How the three statements connect is the heart of the cycle.

The three statements pass figures along a chain. The income statement finds the profit for the period. That profit goes into the statement of owner's equity, where it is added to the opening owner's equity, after any owner's withdrawals are subtracted. The closing owner's equity then goes into the balance sheet. If any link is wrong, the balance sheet will not balance.^4
^4: Chapter 9, 'Financial Statements and Closing Entries', section 9.3 'Reversing Entries', describes the balance sheet and the entries that follow the statements.

> An account payable is an amount we owe; an account receivable is an amount owed to us.

A common confusion lies between two accounts. An account payable means an amount the business owes to a supplier. An account receivable means an amount a customer owes to the business. Some books call these creditors and debtors, but this book uses payable and receivable. Both appear on the balance sheet: the payable among the liabilities, and the receivable among the assets. A payable is money going out later; a receivable is money coming in later.

> The trial balance and the balance sheet look alike but serve different purposes.

The trial balance and the balance sheet also look alike. Both list accounts with amounts. The trial balance lists every ledger account, including revenue and expense accounts, to test that total debits equal total credits. It is a working test, and nobody outside the business needs to see it. The balance sheet lists only assets, liabilities and owner's equity at one date, and it is a report for readers. A trial balance can balance and still contain an error that affects the profit, such as a cost put in the wrong account.

> The complete cycle can be reviewed by following one quarter of Meghna and Sons from start to end.

Follow one quarter through the whole cycle. In July, August and September, each purchase of books, payment of rent and sale is recorded in the journal and posted to the ledger. On 30 September the trial balance lists the account balances. Adjusting entries then bring in costs that belong to the quarter but are not yet recorded, such as wages earned but not yet paid. The adjusted figures feed the income statement, which shows the profit found in the worked example below. At the end of a full year, closing entries move the revenue and expense balances into owner's equity. For an interim report, many businesses prepare the statements without closing the accounts, because the year has not ended.

:box IN SHORT
The cycle has six verbs: record, post, test, adjust, report and close. Record and post fill the ledger. Test and adjust prepare it. Report tells the story. Close resets the temporary accounts for the next period.

:pause 20.p2 | A business pays Tk 5,000 in cash to settle an account payable of the same amount. Which two totals on the balance sheet change, and does the balance sheet still balance?

> Recap of the linked statements.

*Before moving on.* The ledger feeds the trial balance; adjustments correct it; the statements report it; closing entries reset the temporary accounts. A payable is owed by us; a receivable is owed to us. The trial balance tests; the balance sheet reports.

> The reader should now be able to state how the statements are linked.

*You should now be able to say:* "The statements are linked, so profit flows from the income statement through owner's equity to the balance sheet."

## Worked Example: One Quarter of Meghna and Sons

> A worked example sorts the costs and finds the profit for the quarter ended 30 September 2026.

This example applies the chapter to the case file. We first sort the costs, and then we find the profit for the interim period. Take each step slowly and notice where each figure comes from.

> The given figures and the question to be answered.

*Given.* Net sales for the quarter ended 30 September 2026 are Tk 3,900,000. Product costs are books bought Tk 2,450,000 and freight in Tk 40,000. Period costs are rent Tk 180,000 and wages Tk 735,000. To keep the arithmetic clear, assume that all the books bought were sold in the quarter and that inventory did not change. *Find.* The total product cost, the total period cost, the gross profit and the profit for the quarter.

> The formulas are stated in words first and then in symbols.

*Formula.* Product cost total equals books bought plus freight in, or P = B + F. Period cost total equals rent plus wages, or C = R + W. Gross profit equals net sales minus product cost total, or G = S − P. Profit equals gross profit minus period cost total, or N = G − C. Here S stands for net sales, and N stands for profit.

> The steps show every line of arithmetic with units.

*Steps.* First, P = Tk 2,450,000 + Tk 40,000 = Tk 2,490,000. Second, C = Tk 180,000 + Tk 735,000 = Tk 915,000. Third, G = Tk 3,900,000 − Tk 2,490,000 = Tk 1,410,000. Fourth, N = Tk 1,410,000 − Tk 915,000 = Tk 495,000.

:table Income statement for the quarter ended 30 September 2026 (Tk)
| Line | Amount |
| Net sales | 3,900,000 |
| Less product costs (books bought and freight in) | 2,490,000 |
| Gross profit | 1,410,000 |
| Less period costs (rent and wages) | 915,000 |
| Profit | 495,000 |

> The answer and a check of the result against another route.

*Answer.* Product costs are Tk 2,490,000 and period costs are Tk 915,000. Gross profit is Tk 1,410,000, and profit for the quarter is Tk 495,000. *Check.* Take all the costs together: Tk 2,490,000 + Tk 915,000 = Tk 3,405,000. Then Tk 3,900,000 − Tk 3,405,000 = Tk 495,000, which equals the profit found above.

> A second, messier example uses new figures and one cost that is easy to misplace.

Now a second example with new figures. A small bakery has net sales of Tk 800,000 for a quarter. It bought flour and other goods for Tk 310,000 and paid freight in of Tk 12,000. It paid rent Tk 90,000, wages Tk 160,000 and delivery to customers Tk 18,000. Product costs are Tk 310,000 + Tk 12,000 = Tk 322,000. Delivery to customers is freight out, so it is a period cost; period costs are Tk 90,000 + Tk 160,000 + Tk 18,000 = Tk 268,000. Gross profit is Tk 800,000 − Tk 322,000 = Tk 478,000, and profit is Tk 478,000 − Tk 268,000 = Tk 210,000. Check: Tk 800,000 − Tk 322,000 − Tk 268,000 = Tk 210,000.

> Common slips in this calculation arise from mixing classes, periods or signs.

Watch for three slips. The first is to place freight in with the period costs, which would understate gross profit. The second is to mix periods, for example by comparing a quarter's profit with a full year's profit. The third is to add the profit instead of subtracting the costs, which gives a figure larger than sales.

> A worked case applies the ideas to a decision instead of a calculation.

*Situation.* The owner of Meghna and Sons wants to know whether the quarter's profit of Tk 495,000 can stand for a full year. *Question.* Is it safe to multiply the quarter's profit by four? *Reasoning.* The quarter is one interim period of a calendar year. Trade may be higher or lower in the other quarters, and some adjustments in an interim report are estimates. *Conclusion.* The figure is a useful signal but not a forecast of the year. *Check.* The case file does not give figures for the other quarters, so no firm yearly figure can be drawn from this one.

* * *

## Summary

> A short summary of the whole chapter.

A fiscal year is a chosen twelve-month reporting period, and an interim period is a shorter one. A product cost is tied to goods and waits in inventory until the sale, while a period cost is charged to the time in which it is incurred. The statements are linked: profit flows from the income statement to owner's equity to the balance sheet. A payable is owed by the business and a receivable is owed to it. The trial balance tests the accounts, and the balance sheet reports them.

## Think It Through

:q 20.t1 | Suppose Meghna and Sons changed its fiscal year to run from 1 July to 30 June, the same as the Bangladesh government. Name two things that would change in its reports, and one thing that would stay the same.

:q 20.t2 | A seller of school uniforms trades most heavily in the weeks before term starts. Which twelve-month period would you suggest for this business, and why?

## Where People Go Wrong

> Common misunderstandings and their corrections.

Many students believe that a fiscal year must follow the calendar. It need not: it is any twelve months the business chooses. Some believe that every payment is an expense at once. A product cost waits in inventory until the sale. Others treat freight in and freight out alike, but the first is a product cost and the second is a period cost. A further error is to think that a balanced trial balance proves every account is right. It proves only that debits equal credits.

## In History

> A true account of a government that chose a new fiscal year.

Until 1976, the United States federal government counted its fiscal year from 1 July to 30 June. The Congressional Budget and Impoundment Control Act of 1974, signed into law on 12 July 1974, changed this. Under section 501, the fiscal year began on 1 October from 1976. To make the change, the period from 1 July to 30 September 1976 was treated as a separate three-month transition quarter, between fiscal years 1976 and 1977. The case shows that a fiscal year is a choice, and that a change of choice needs a bridging period.

## Review Questions

:q 20.1 | Classify each cost of a bookshop as a product cost or a period cost: books bought, freight in, shop rent, wages of the shop assistants, delivery to a customer.

:q 20.2 | A business records net sales of Tk 600,000, product costs of Tk 380,000 and period costs of Tk 150,000 for a quarter. Find the gross profit and the profit.

:q 20.3 | Trace the cycle from one transaction to the post-closing check. Name each step in order and say which steps change account balances.

:q 20.4 | Explain in two sentences the difference between an account payable and an account receivable, and say where each appears on the balance sheet.

:q 20.5 | A business has a fiscal year from 1 April to 31 March. Name the dates of its second quarter, and say which of these is an interim period: the year, the second quarter, or the full cycle.
