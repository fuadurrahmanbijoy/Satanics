:chapter IX | Financial Statements and Closing Entries
:mood What must a business show at the end of the year, and what must it empty before the next year begins?
:desc At the end of a period, the accounts must report their results and then prepare for a fresh start. This chapter teaches the three reports that present the results, the closing entries that reset the accounts, and the reversing entries that make the first payment of the new period easy to record.
:plate ch09-plate.svg | A clerk seals a finished annual account into a folder with a ribbon.

> This chapter rests on three earlier pieces of work.
> Recall: worksheet, Chapter 8, 'The Worksheet', section 8.3 'Worked Worksheet'.
> Recall: deferrals, Chapter 7, 'Adjusting the Accounts', section 7.2 'Deferrals'.

You will need three earlier pieces of work. Chapter 8, 'The Worksheet', section 8.3 'Worked Worksheet', showed how the adjusted figures are collected on one sheet. Chapter 7, 'Adjusting the Accounts', section 7.2 'Deferrals', explained the entries that move amounts between periods. Appendix A1, 'Maths You Will Use', holds the arithmetic.

> A market stall owner must answer two different questions on the last evening of the month.

A woman keeps a tea stall in a market. On the last evening of the month she empties the cash tin onto the table. She counts the takings, remembers what she paid for leaves, milk and sugar, and keeps apart the money she took home. Then she faces a question that every business must answer sooner or later. How much did the stall earn this month? And what does the stall own and owe tonight?

> The earnings belong to the month that ended; the tin and the debts continue.

These are two different questions, and their answers behave differently. The earnings belong to the month that has ended. The cash tin, the debts and the owner's stake continue into the next month. On the first morning of the new month, the earnings must start again at nothing, while the cash tin must keep what it holds. How can one set of records do both?

> Meghna Binding Service meets the same puzzle at the end of its first year.

:case Case file, illustrative. Meghna Binding Service, the separate set of books for the book-binding workshop that began on 1 January 2026, ends its first year on 31 December 2026. Its Revenue account then holds Tk 788,000. If nothing is done, the first sale of 2027 would be added to that balance, and the account could never show what the workshop earned in one year alone.

> The chapter answers the puzzle in three parts, then applies them to the workshop.

This chapter answers the puzzle in three parts. Section 9.1 teaches the three reports that present the results of a period. Section 9.2 teaches the closing entries, which reset the accounts that measure one period. Section 9.3 teaches reversing entries, a step that makes the first payment of a new period easier to record. A worked example with Meghna Binding Service follows, and the chapter ends with the history of the law that first required companies to publish a balance sheet.

* * *

## 9.1 The Three Statements

> The word statement means a formal report of figures, not a spoken claim.
@ Statement | Word in use. In daily life, something said or written, such as a bank statement. In accounting, a formal report of figures for a period or for a date.

Return to the tea stall. At the end of the month the owner wants three answers. What did the stall earn after paying its costs? How did her own stake in the stall change? What does the stall own and owe tonight? Each answer needs a separate page, because each answers a different question. Accountants call each such page a statement, and this section teaches the three pages in the order in which they are prepared.

> Here are the stall's small, round figures for the month.

Here are her figures. She sold tea for Tk 5,000. She spent Tk 3,000 on leaves, milk, sugar and fuel. She took Tk 500 home for her family. When she started the stall, she had put in Tk 2,500. At the month's end the stall holds cash of Tk 3,700 and equipment worth Tk 1,300, and it owes its supplier Tk 1,000. We will use these figures for every statement in this section.

> The first statement answers: what did the business earn?
@ Income statement | A report of revenue and expenses for a period, ending in net income or net loss.

The first answer comes from the **income statement**. An income statement is a report of revenue and expenses for a period, ending in net income or net loss. Revenue is the amount a business earns by selling goods or services. An expense is a cost of earning that revenue. The stall's revenue is Tk 5,000 and its expenses are Tk 3,000, so its net income is Tk 2,000. If expenses were larger than revenue, the result would be a net loss.

> The table lists revenue first, expenses next and the result last.

The table below shows the income statement of the stall. Read it from the top downwards: revenue first, then expenses, and the result on the last line.

:table Income statement of the tea stall for one month
| Item | Tk |
| Revenue: tea sold | 5,000 |
| Expenses: leaves, milk, sugar and fuel | 3,000 |
| Net income | 2,000 |

> Every statement has a three-line heading: who, which statement, and when.

Every statement has a heading of three lines: the name of the business, the name of the statement, and the period or date. The income statement covers a period, so its third line reads, for example, *For the year ended 31 December 2026*. Without the period, a reader cannot judge whether Tk 2,000 is a good result for one week or a poor result for one year. Because the books follow the accrual basis of accounting, the statement reports revenue when it is earned and matches expenses to that revenue, as the matching principle requires.

> The second statement answers: how did the owner's stake change?
@ Statement of owner's equity | A report showing how the owner's capital changed during a period.

The second answer comes from the **statement of owner's equity**. A statement of owner's equity is a report showing how the owner's capital changed during a period. Owner's equity is the owner's claim on the business. Some books call it capital, net worth or proprietorship; this book uses owner's equity for the idea, and Owner's Capital as the name of the account. The stall began with capital of Tk 2,500, and the statement shows how that figure became a new one.

> Ending capital equals starting capital plus net income minus drawings.

The calculation has three parts. Ending capital equals starting capital, plus net income, minus drawings. Drawings are amounts that the owner withdraws from the business for personal use. For the stall, the steps are Tk 2,500 + Tk 2,000 − Tk 500 = Tk 4,000. A net loss would be subtracted instead of added, and any extra money that the owner invests during the period would be added.

> The third statement answers: what does the business own and owe on one date?
@ Balance sheet | A report of assets, liabilities and owner's equity at one date.

The third answer comes from the **balance sheet**. A balance sheet is a report of assets, liabilities and owner's equity at one date. Assets are things of value that the business owns. Liabilities are amounts that the business owes. The report is called a balance sheet because its two sides must be equal: assets equal liabilities plus owner's equity. Some countries and standards use the title statement of financial position for the same report; this book uses balance sheet.^1

^1: The International Financial Reporting Standards use the title statement of financial position. The contents are the same as in a balance sheet. Which title is required depends on the law and standards of the country and on the kind of business.

> The balance sheet for the stall shows that both sides equal Tk 5,000.

The table below shows the stall's balance sheet. The left part lists what the stall owns, and the lower part lists what it owes and what belongs to the owner. The two totals must agree.

:table Balance sheet of the tea stall at the end of the month
| Item | Tk |
| Cash | 3,700 |
| Equipment | 1,300 |
| Total assets | 5,000 |
| Accounts payable (owed to the supplier) | 1,000 |
| Owner's Capital | 4,000 |
| Total liabilities and owner's equity | 5,000 |

> The balance sheet shows one date, so its heading says at, not for.

Notice the difference. The balance sheet shows a single date, so its third line reads *At 31 December 2026*. The other two statements cover a period.

> The three statements are prepared in a fixed order because each feeds the next.

The order matters, because each statement supplies a number to the next. The income statement is prepared first, because it produces net income. The statement of owner's equity comes second, because it needs net income and produces ending capital. The balance sheet comes last, because it needs ending capital. The figure below shows the links. Each box is one statement. Each arrow shows a number moving from one box to the next, and the words on the arrow name that number.

:fig The three statements and the numbers that link them | ch09-fig01.svg

> Owners, lenders and managers read the three statements for different reasons.

The owner reads the income statement to judge the work. A bank that lends money reads the balance sheet to see whether assets cover liabilities.

> Before moving on: each statement answers one question, and each feeds the next.

*Before moving on.* The income statement reports revenue, expenses and net income for a period. The statement of owner's equity reports how capital changed, using net income and drawings. The balance sheet reports assets, liabilities and owner's equity at one date. Prepare them in that order, and give each the right third line of heading.

* * *

## 9.2 Closing the Books

> Some accounts must reset to zero at period end and others must not.

Look again at the tea stall's books after the month's results are known. Its Revenue account holds Tk 5,000, its Expenses account holds Tk 3,000, and its Drawings account holds Tk 500. Next month the owner wants the results of the new month only. If the old figures stay, each new sale is added to Tk 5,000, and no one can separate the two months. The books must be reset, but not every account may be reset. The Cash account must keep its Tk 3,700. Which accounts may be emptied, and which must not?

> Accounts that measure one period are temporary; accounts that show position are permanent.
@ Temporary account | An account for revenue, expense or drawings, closed to zero at the end of each period.
@ Permanent account | An account for assets, liabilities or capital, whose balance carries forward to the next period.

Accountants answer by dividing accounts into two groups. A **temporary account** is an account for revenue, expense or drawings, closed to zero at the end of each period. Revenue and Expenses are examples. A **permanent account** is an account for assets, liabilities or capital, whose balance carries forward to the next period. Cash and Accounts Payable are examples. A temporary account measures one period only. A permanent account shows the position of the business and has no end date.

> The table sorts the account types into temporary and permanent.

The table below sorts the common account types. Read each row from left to right: the kind of account, its group, and what happens to its balance at the end of the period.

:table Which accounts are temporary and which are permanent
| Kind of account | Group | At the end of the period |
| Revenue | Temporary | Closed to zero |
| Expense | Temporary | Closed to zero |
| Drawings | Temporary | Closed to zero |
| Asset | Permanent | Balance carries forward |
| Liability | Permanent | Balance carries forward |
| Owner's Capital | Permanent | Updated, then carried forward |

> The word closing in accounting means moving a balance to capital so that an account starts again at zero.
@ Closing | Word in use. In daily life, shutting a shop for the night. In accounting, moving the balance of a temporary account to capital so that the account starts the new period at zero.
@ Closing entry | A journal entry at period end that transfers a temporary account's balance to capital.

The tool that resets a temporary account is the closing entry. A **closing entry** is a journal entry at period end that transfers a temporary account's balance to capital. Suppose the stall's Revenue account has a credit balance of Tk 5,000. A closing entry debits Revenue for Tk 5,000. That debit cancels the credit, and the account stands at zero. The same amount must be credited somewhere, and that place is capital, or an account that leads to capital.

> A helper account collects revenue and expenses before the net result moves to capital.
@ Income summary | A temporary account used to collect revenue and expenses before the net result goes to capital.

Most books use a helper account for this purpose. The **income summary** is a temporary account used to collect revenue and expenses before the net result goes to capital. Think of it as a small table where the month's revenue and expenses are placed side by side, so that the difference is easy to see. After the net result is moved to capital, the income summary itself stands at zero.

> Closing takes four steps, each one a journal entry, and the order is fixed.

Closing takes four steps, and each step is one journal entry. The steps are performed in this order, after all adjusting entries have been recorded.

> The four steps close revenue, expenses, the income summary and drawings.

Step 1. Close each revenue account: debit it and credit Income Summary. Step 2. Close each expense account: credit it and debit Income Summary. Step 3. Close Income Summary to Owner's Capital: a credit balance means net income, which is credited to capital. Step 4. Close Drawings to Owner's Capital: credit Drawings and debit capital.

> The table shows the four closing entries for the tea stall.

The table below shows the four entries for the tea stall. The stall has several expense accounts; their total is used here to keep the table short. In a real set of books, each expense account is credited separately.

:table The four closing entries of the tea stall
| Step | Account | Debit (Tk) | Credit (Tk) |
| 1 | Revenue | 5,000 |  |
| 1 | Income Summary |  | 5,000 |
| 2 | Income Summary | 3,000 |  |
| 2 | Expenses (all accounts) |  | 3,000 |
| 3 | Income Summary | 2,000 |  |
| 3 | Owner's Capital |  | 2,000 |
| 4 | Owner's Capital | 500 |  |
| 4 | Drawings |  | 500 |

> After step 2, the income summary holds the net result: credits of revenue less debits of expenses.

Follow the income summary through the steps. After step 1 it holds a credit of Tk 5,000. After step 2 it also holds a debit of Tk 3,000, so its balance is a credit of Tk 2,000. That balance is the net income. Step 3 debits Income Summary for Tk 2,000 and moves the amount to capital, and the account is left at zero. The rule is: a credit balance is closed by a debit of the same amount, and a debit balance is closed by a credit of the same amount.

:pause 9.p1 | A shop has revenue of Tk 800 and expenses of Tk 500. After steps 1 and 2, what balance does Income Summary hold, and is it a debit or a credit?

> The figure shows the four closing entries as arrows that end in Owner's Capital.

The figure below shows the same four entries as arrows. Revenue, Expenses and Drawings sit on the left. Income Summary sits in the middle. Owner's Capital sits on the right, and every path ends there. Each arrow is labelled with its step number. Where an arrow points shows where a balance moves; the line style tells the kind of balance: a solid line for a credit and a dashed line for a debit.

:fig Closing entries as arrows into capital | ch09-fig02.svg

> Closing never erases records; it only resets the accounts that measure one period.

Three points often cause confusion. First, closing does not erase history. The journal keeps every entry, and the income statement keeps every figure. Second, drawings are not an expense. They do not pass through the income summary, because they are the owner's withdrawal and not a cost of earning revenue. Third, some books close revenue and expenses directly to capital and skip the income summary.^2 The final capital is the same.

^2: This shorter method gives the same ending capital. It is used less often in teaching, because the income summary shows the net result in one place before it moves to capital.

> Permanent accounts are never closed, and a net loss reverses the direction of step 3.

Permanent accounts are never closed; their balances continue. If the result of the period is a net loss, the income summary has a debit balance after step 2. Step 3 then credits Income Summary and debits Owner's Capital, which reduces capital.

:box IN SHORT
Temporary accounts measure one period and return to zero through closing entries. Permanent accounts show the position and carry their balances forward.

> Before moving on: closing resets four kinds of balance and leaves the permanent accounts alone.

*Before moving on.* A temporary account is closed to zero at the end of each period; a permanent account carries its balance forward. The four closing entries move revenue, expenses and drawings into Owner's Capital, using the income summary as a helper for the net result. After closing, only permanent accounts hold balances.

* * *

## 9.3 Reversing Entries

> A payment that covers two periods creates extra work for the person who records it.

:case Case file, illustrative. At 31 December 2026, Meghna Binding Service owes its workers Tk 14,000 for wages earned in 2026 but not yet paid. The adjusting entry of that date debited Wages Expense and credited Wages Payable for Tk 14,000. On 5 January 2027 the workshop pays wages of Tk 28,000. Half of this payment settles the old debt, and half pays for work done in 2027. How should the payment be recorded?

> Without a reversal, the bookkeeper must split the payment by hand, and a slip counts the same wages twice.

The difficulty is the split. If the bookkeeper records the full Tk 28,000 as an expense, the Tk 14,000 of 2026 is counted twice: once by the adjusting entry, and again by the payment. To avoid this, the bookkeeper must remember to debit Wages Payable and Wages Expense for Tk 14,000 each. With many such payments, memory is not a safe method.

> A reversing entry cancels the earlier accrual so that payment can be recorded in the usual way.
@ Reversing entry | An entry on the first day of a new period that cancels an earlier accrual so that routine payment can be recorded in the usual way.

The remedy is the **reversing entry**. A reversing entry is an entry on the first day of a new period that cancels an earlier accrual so that routine payment can be recorded in the usual way. Here the reversing entry is the exact opposite of the adjusting entry: it debits Wages Payable and credits Wages Expense for Tk 14,000. After it, the payment on 5 January needs no thought. The bookkeeper debits Wages Expense and credits Cash for the full amount.

> The table shows the reversal and the payment, with their dates.

The table below shows the two entries in 2027. Read the rows by date: the reversal first, then the payment.

:table Reversal and payment of wages, Meghna Binding Service, 2027
| Date | Account | Debit (Tk) | Credit (Tk) |
| 1 January 2027 | Wages Payable | 14,000 |  |
| 1 January 2027 | Wages Expense |  | 14,000 |
| 5 January 2027 | Wages Expense | 28,000 |  |
| 5 January 2027 | Cash |  | 28,000 |

> After both entries, the expense account holds only the wages that belong to 2027.

Now examine the accounts. Wages Payable holds a credit of Tk 14,000 from December and a debit of Tk 14,000 from the reversal, so it stands at zero. Wages Expense holds a credit of Tk 14,000 from the reversal and a debit of Tk 28,000 from the payment, so its balance is a debit of Tk 14,000. That is exactly the wages for work done in 2027. The old debt is gone, the new expense is correct, and the payment was recorded without any splitting.

> Reverse accruals that routine payments will settle; most deferrals need no reversal.

The next question is when to reverse. The usual answer is: reverse an accrual that a later routine payment or receipt will settle. Wages payable is the classic case. Interest owed or interest earned but not yet received is another. Deferrals are different. In the deferral entries of Chapter 7, section 7.2, the original payment or receipt was first recorded in an asset or liability account, such as Prepaid Insurance or Unearned Revenue. The adjusting entry already left each balance correct, so a reversal is not needed.

> Reversing is a convenience, not a requirement, and the result is the same either way.

Reversing is a convenience and never a requirement. A bookkeeper who splits the payment correctly by hand reaches the same balances. Two rules keep the method safe. Date the reversal on the first day of the new period, after the old period has been closed and its statements prepared. And never reverse a closing entry, because closing entries must stay in place for the period that ended.

> The reversal changes nothing in the old period's statements and corrects the new period's expense.

The effect on the next period is easy to state. The balance sheet at 31 December 2026 still shows wages payable of Tk 14,000, because the reversal is dated 2027. The income statement for 2027 shows only the wages that belong to 2027. If the bookkeeper forgets the reversal and records the full payment, the 2027 wages are overstated by Tk 14,000.

> Before moving on: reverse accruals on the first day of the new period; the payment then follows the usual routine.

*Before moving on.* A reversing entry cancels an earlier accrual on the first day of a new period. It is used for accruals that routine payments will settle, and it is optional. After the reversal, the full payment is recorded in the usual way, and the expense account shows only the new period's share.

* * *

## A Worked Example: Statements and Closing for Meghna Binding Service

> Here is the data for the workshop's first year, used in every step below.

:case Case file, illustrative. Meghna Binding Service, statements for 2026. Revenue Tk 788,000. Expenses Tk 604,000. Capital at 1 January 2026 Tk 400,000. Drawings for the year Tk 80,000. Assets at 31 December 2026: cash Tk 150,000, accounts receivable Tk 110,000, supplies Tk 15,000, prepaid insurance Tk 27,000, equipment (net) Tk 288,000. Liabilities: accounts payable Tk 60,000, wages payable Tk 14,000, unearned revenue Tk 12,000.

> The first calculation finds net income from the income statement.

:case Case file, illustrative. Calculation 1: net income. *Given:* revenue Tk 788,000; expenses Tk 604,000. *Find:* net income for 2026. *Formula:* net income equals revenue minus expenses; in symbols, N = R − E, where N is net income, R is revenue and E is expenses. *Steps:* Tk 788,000 − Tk 604,000 = Tk 184,000. *Answer:* the net income of the workshop for the year ended 31 December 2026 is Tk 184,000. *Check:* revenue is larger than expenses, so the result must be a net income; and Tk 184,000 is about 23 per cent of Tk 788,000, a reasonable share.

> The second calculation finds ending capital for the statement of owner's equity.

:case Case file, illustrative. Calculation 2: capital at the end of the year. *Given:* capital at the start Tk 400,000; net income Tk 184,000; drawings Tk 80,000. *Find:* capital at 31 December 2026. *Formula:* ending capital equals starting capital plus net income minus drawings; in symbols, C₁ = C₀ + N − D. *Steps:* Tk 400,000 + Tk 184,000 = Tk 584,000; then Tk 584,000 − Tk 80,000 = Tk 504,000. *Answer:* ending capital is Tk 504,000. *Check:* the owner added net income and withdrew less than that, so capital must have grown: Tk 504,000 is larger than Tk 400,000.

> The third calculation totals assets and liabilities and tests the balance sheet.

:case Case file, illustrative. Calculation 3: the balance sheet. *Given:* the assets, liabilities and ending capital above. *Find:* total assets, total liabilities, and whether the two sides agree. *Formula:* assets equal liabilities plus owner's equity; in symbols, A = L + E. *Steps:* assets are Tk 150,000 + Tk 110,000 + Tk 15,000 + Tk 27,000 + Tk 288,000 = Tk 590,000. Liabilities are Tk 60,000 + Tk 14,000 + Tk 12,000 = Tk 86,000. Then L + E = Tk 86,000 + Tk 504,000 = Tk 590,000. *Answer:* the balance sheet has total assets of Tk 590,000, and both sides agree. *Check:* the equity of Tk 504,000 also equals assets less liabilities: Tk 590,000 − Tk 86,000.

> The table presents the workshop's balance sheet at 31 December 2026.

The table below sets the balance sheet out in full. Read it from the top: assets, then liabilities, then owner's equity, and last the two equal totals.

:table Balance sheet of Meghna Binding Service at 31 December 2026
| Item | Tk |
| Cash | 150,000 |
| Accounts receivable | 110,000 |
| Supplies | 15,000 |
| Prepaid insurance | 27,000 |
| Equipment (net) | 288,000 |
| Total assets | 590,000 |
| Accounts payable | 60,000 |
| Wages payable | 14,000 |
| Unearned revenue | 12,000 |
| Total liabilities | 86,000 |
| Owner's Capital | 504,000 |
| Total liabilities and owner's equity | 590,000 |

> The four closing entries, dated 31 December 2026, use the same figures.

The books are now closed. The table below shows the four closing entries of 31 December 2026. Revenue and expenses are shown as totals, because the case file gives totals only.

:table Closing entries of Meghna Binding Service, 31 December 2026
| Step | Account | Debit (Tk) | Credit (Tk) |
| 1 | Revenue | 788,000 |  |
| 1 | Income Summary |  | 788,000 |
| 2 | Income Summary | 604,000 |  |
| 2 | Expenses (all accounts) |  | 604,000 |
| 3 | Income Summary | 184,000 |  |
| 3 | Owner's Capital |  | 184,000 |
| 4 | Owner's Capital | 80,000 |  |
| 4 | Drawings |  | 80,000 |

> The check: Income Summary ends at zero, and capital ends at the figure in the statement.

Check the closing. After step 1, Income Summary holds a credit of Tk 788,000. After step 2 it holds Tk 788,000 − Tk 604,000 = a credit of Tk 184,000. Step 3 removes it, so the account is at zero. Capital is Tk 400,000 + Tk 184,000 = Tk 584,000 after step 3 and Tk 584,000 − Tk 80,000 = Tk 504,000 after step 4. This equals the balance sheet figure. On 1 January 2027, the reversal and the payment of 5 January from section 9.3 leave Wages Expense with a debit of Tk 14,000, the share that belongs to 2027.

> Four slips are common when students perform these steps.

Four slips are common. The first is a wrong sign: adding drawings to capital instead of subtracting them. The second is a mixed-up period: heading the balance sheet *For the year ended* instead of *At*. The third is a forgotten liability, such as Tk 12,000 of unearned revenue, which makes the two sides disagree. The fourth is closing Drawings through the income summary, which understates net income in the report.

* * *

## Summary

> The summary lists the five ideas of the chapter.

The income statement, the statement of owner's equity and the balance sheet are prepared in that order, each feeding the next. After they are prepared, closing entries move the balances of temporary accounts into Owner's Capital through the income summary, and permanent accounts carry their balances forward. On the first day of the new period, a reversing entry cancels an accrual so that the routine payment is recorded in the usual way. For Meghna Binding Service, the year produced net income of Tk 184,000 and ending capital of Tk 504,000.

## Think It Through

:q 9.t1 | Suppose Meghna Binding Service did not close its Revenue account on 31 December 2026, and then recorded Tk 900,000 of revenue during 2027. What balance would the account show at the end of 2027, and why would that figure mislead a reader?

:q 9.t2 | Explain in your own words why the balance sheet cannot be prepared before the statement of owner's equity.

## Where People Go Wrong

> Mistake one: closing permanent accounts, which would erase the position of the business.

Some students close every account, including Cash. This is wrong. Only revenue, expense and drawings accounts are closed. Assets, liabilities and capital show the position of the business and must carry their balances forward.

> Mistake two: treating drawings as an expense.

Some students charge drawings to the income summary with the expenses. Drawings are the owner's withdrawal, not a cost of earning revenue. They are closed directly to Owner's Capital, and they never reduce net income.

> Mistake four: believing that reversing entries are always required.

Some students think the books are wrong without a reversal. They are not. A reversal only makes later recording easier. Deferrals recorded in asset or liability accounts usually need no reversal at all.

## In History

> The Joint Stock Companies Act 1844 made a balance sheet a legal duty of registered companies.

Before 1844, a company in the United Kingdom could usually gain a separate legal existence only by royal charter or by a private Act of Parliament. In 1844 Parliament passed the Joint Stock Companies Act, which received royal assent on 5 September 1844 and came fully into force on 1 November 1844. A company could now register with an official called the Registrar of Joint Stock Companies. The Act also placed duties on registered companies. They had to keep books of account, and their directors had to prepare a "full and fair" balance sheet. Auditors then examined it, and a copy went to the Registrar for the public to inspect. Parliament later replaced the Act with the Joint Stock Companies Act 1856. Today the law of each country sets how a company reports to its owners.

## Review Questions

:q 9.1 | State the question that each of the three statements answers, and name the third line of each heading.

:q 9.2 | A small shop has this adjusted trial balance at 31 December 2026 (in Tk): Cash 6,000; Accounts Receivable 2,000; Equipment 9,000; Drawings 1,000; Expenses 7,000 (debits); Accounts Payable 3,000; Owner's Capital 10,000; Revenue 12,000 (credits). Prepare the three statements.

:q 9.3 | Write the four closing entries for the shop in question 9.2.

:q 9.4 | Sort these accounts into temporary and permanent: Revenue, Prepaid Insurance, Wages Expense, Drawings, Wages Payable, Owner's Capital.

:q 9.5 | Wages of Tk 6,000 were earned but unpaid at 31 December 2026, and Tk 8,000 was paid on 4 January 2027. Write the reversing entry and the payment, and state the wages expense of 2027.

:q 9.6 | A business has revenue of Tk 9,000 and expenses of Tk 11,000 for the year. Write the third closing entry and say what happens to capital.

:read Edwards, J. R., A History of Financial Accounting, 1989
:read Littleton, A. C., Accounting Evolution to 1900, 1933
