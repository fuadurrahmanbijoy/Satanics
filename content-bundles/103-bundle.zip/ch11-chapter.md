:chapter XI | Special Journals
:mood How can a shop record hundreds of credit sales without writing the same words hundreds of times?
:desc This chapter shows how a business with many repeated transactions saves time and avoids error. You will meet the sales journal and the purchases journal, learn how their totals reach the ledger, and see how a control account checks the individual accounts of customers.
:plate ch11-plate.svg | A warehouse office with several day-books on a sloping desk

:box YOU WILL NEED
You will need the idea of the journal from Chapter 5 'The Journal and the Ledger', section 5.2 'The Journal', and the idea of posting from Chapter 5 'The Journal and the Ledger', section 5.3 'The Ledger and Posting'. Appendix A1 'Maths You Will Use' covers rounding and units, which help when you check totals.

> A busy shop faces a puzzle: hundreds of similar sales, each needing the same careful record.

Picture a stall in a market that sells tea and biscuits. Most customers pay at once. Three regular customers, however, take their goods now and promise to pay at the end of the month. Each of these sales must be recorded. The owner has learned that every transaction begins in the journal, so each credit sale receives its own entry: a date, the account to debit, the account to credit, the amount and a short explanation.

> Repeating the same entry many times costs time and invites mistakes.

Now picture the stall growing into a large shop. It makes two hundred credit sales in one month. Two hundred journal entries must be written, and in each one the same two account names appear: the account receivable and the sales account. Then every entry must be posted to the ledger, which means two hundred postings to the sales account alone. A tired clerk might skip one entry, write a figure wrongly, or post the debit and forget the credit. Many students find this point puzzling, because the method works well for ten entries. The difficulty appears only at two hundred.

> The answer is to separate the kinds of transaction and to give each kind its own book.

Think about how the shop could save effort. Every credit sale has the same shape. The debit is always the account receivable, and the credit is always sales. Only three things change from one sale to the next: the date, the customer and the amount. Suppose the shop prints those headings across a page and writes one line for each sale. The repeated words disappear. At the end of the month the clerk totals the amount column once and posts a single total to each of the two accounts. Two hundred postings shrink to two.

> This chapter builds that idea in three steps and then adds a check against error.

Section 11.1 names the idea and explains why a single journal reaches its limit. Section 11.2 shows the sales journal and the purchases journal and how their totals reach the ledger. Section 11.3 introduces a main account that sums many customer accounts, and a method to prove that the two agree. Our running example is a bookshop in Dhanmondi, Dhaka, where credit sales and credit purchases are frequent.

* * *

## Why Special Journals

> The single journal records every kind of transaction, so it repeats the same words again and again.

> Recall: the journal, Chapter 5, 'The Journal and the Ledger', section 5.2 'The Journal'.

@ Journal | Word in use. In daily life, a diary or a magazine on one subject. In accounting, a book where each transaction is first recorded, in date order.

In Chapter 5 you learned that the journal is the first book of record. Each transaction, supported by a source document such as an invoice, is written there in date order before it reaches the ledger. A journal of this kind accepts any transaction: a purchase of furniture, a payment of rent, a loan from a bank. For that reason we shall call it the general journal in this chapter. Its strength is flexibility. Its weakness appears when one kind of transaction occurs again and again.

> The general journal has three limits, and each one grows with the number of transactions.

The first limit is repetition. Each credit sale needs its own entry, and each entry names the same two accounts. The second limit is that only one person can write in one book at a time, so a second clerk must wait. The third limit is posting. Each entry is posted separately to two ledger accounts, so the number of postings is twice the number of entries. Errors also grow, and an error among hundreds of similar entries is hard to find.

> A small count shows how quickly the work grows, so read the table row by row.

The table compares the work in the general journal with the work in a book kept for credit sales alone. The first row counts the ledger postings to the two main accounts, the receivable account and the sales account. A row is read from left to right: the task, the work for three sales, then the work for two hundred sales. For the general journal the count is twice the number of sales, because each sale touches two accounts. For a book of credit sales alone the count is two, because only the total is posted.

:table Postings to the two main accounts when sales are recorded on credit
| Method | Three sales | Two hundred sales |
| General journal, posting every entry | 6 postings | 400 postings |
| Book for credit sales, posting the total | 2 postings | 2 postings |

> A special journal groups transactions of one kind in one book, with columns for the parts that change.

@ Special journal | A journal used for only one kind of repeated transaction, such as credit sales, to speed up recording.

A **special journal** is a journal used for only one kind of repeated transaction, such as credit sales. It names the two accounts once, in its heading, and records only the changing parts on each line. Return to the tea stall. Its three credit sales of Tk 100, Tk 200 and Tk 300 take three short lines in a special journal. In the general journal they would take three full entries, each with two account names and an explanation.

> Special journals give four benefits: less writing, shared work, fewer postings and easier checking.

Consider the benefits from several viewpoints. The owner receives records sooner and at lower cost. A manager can give the book of credit sales to one clerk and the book of credit purchases to another, and both clerks work at the same time. An employee writes fewer words and makes fewer slips. A customer, who may query a bill, is helped because every sale sits on a line that is easy to find. The plain rule is this: when many transactions of one kind occur, give them a book of their own.

> A special journal has limits, because it accepts only its own kind of transaction.

Special journals also have exceptions. A special journal for credit sales does not record cash sales, because no account receivable arises when the customer pays at once; Chapter 12 'The Cash Book and Bank Reconciliation' describes the book used for cash. It does not record the sale of a delivery van, because a van is not goods held for sale. Adjusting and correcting entries also stay in the general journal. Finally, a very small business may have too few transactions to justify extra books, and one journal is then enough.

> Recap: one book per repeated kind of transaction, with the rest staying in the general journal.

*Before moving on.* A special journal is a book for one repeated kind of transaction. It saves writing, shares work and reduces postings. The general journal remains for everything that does not fit a special journal. You should now be able to say why two hundred credit sales need two postings in a special journal and four hundred in the general journal.

* * *

## Sales and Purchases Journals

> A small clean example shows the method before we meet the real records.

We begin with the tea stall, because its numbers are small. The calculation follows the order used throughout this book. *Given.* Three credit sales, of Tk 100, Tk 200 and Tk 300. *Find.* The total to post to the sales account. *Formula.* The total equals the first amount plus the second plus the third. In symbols, T = a₁ + a₂ + a₃, where T is the total and a₁, a₂ and a₃ are the three amounts. *Steps.* Tk 100 + Tk 200 = Tk 300. Then Tk 300 + Tk 300 = Tk 600. *Answer.* The total is Tk 600, posted once to sales. *Check.* Posting the three amounts one by one would also give Tk 600.

> The sales journal records credit sales of goods, one line for each sale invoice.

@ Sales journal | A special journal that records only sales of goods on credit.

The **sales journal** is a special journal that records only sales of goods on credit. Its source document is the copy of the sales invoice that the business keeps. Each invoice becomes one line, and the usual columns are the date, the invoice number, the name of the customer and the amount.^1 The sales journal lists the credit sales of the business, nothing more.

^1: Some businesses add columns, for example for tax charged on sales. The rules differ from country to country, so this chapter leaves them out and shows only the main idea.

> The case file shows three credit sales in November 2026, each with an invoice number.

:case Case file, illustrative. In November 2026, Meghna and Sons made three credit sales. On 4 November it sold goods to Dhanmondi Girls' School for Tk 85,000 (invoice 701). On 12 November it sold goods to Rose Valley School for Tk 120,000 (invoice 702). On 20 November it sold goods to Lalmatia College for Tk 64,000 (invoice 703). The total of credit sales for the month is Tk 269,000.

> To read the sales journal, follow each row across and then the amount column down.

The table below is the sales journal for the case. Read each row from left to right: the date, the invoice number, the customer and the amount in taka. Then read the amount column downwards and total it. The heading does not name the two accounts for each line, because every line has the same debit and credit.

:table Sales journal of Meghna and Sons, November 2026
| Date | Invoice | Customer | Amount (Tk) |
| 4 November | 701 | Dhanmondi Girls' School | 85,000 |
| 12 November | 702 | Rose Valley School | 120,000 |
| 20 November | 703 | Lalmatia College | 64,000 |
| Total | | | 269,000 |

> Each line goes to the customer's own account; the total goes to the main ledger once.

The figure shows what happens next. Each line is posted to the account of the customer named on it, so that the business always knows how much each customer owes. At the end of the month, the total of Tk 269,000 is posted once to two main accounts: a debit to the account receivable and a credit to sales. Solid lines in the figure show the posting of each line. Dashed lines show the posting of the total.

:fig Sales journal columns and posting to ledgers | ch11-fig01.svg

> The purchases journal is the matching book for goods bought on credit from suppliers.

@ Purchases journal | A special journal that records only purchases of goods on credit.

The **purchases journal** is a special journal that records only purchases of goods on credit. Its source document is the invoice received from the supplier. The columns are the date, the name of the supplier and the amount. In November 2026, Meghna and Sons bought on credit as the next case paragraph records.

> The case file lists three credit purchases, which total Tk 300,000.

:case Case file, illustrative. On 3 November 2026, Meghna and Sons bought goods on credit from Ananda Publishers for Tk 150,000. On 9 November it bought goods on credit from Prothom Print for Tk 96,000. On 17 November it bought goods on credit from Jonaki Books for Tk 54,000. The total of credit purchases for the month is Tk 300,000.

> Posting the totals gives each main account one entry for the month, and each supplier's account one entry per line.

The posting rule is the same in reverse. Each line is posted to the account of the supplier named on it. The total of Tk 300,000 is posted once to two main accounts: a debit to Purchases, an account that collects the cost of goods bought for resale, and a credit to the account payable. The debit and credit follow the rules of Chapter 4 'Accounts, Debits and Credits': a purchase of goods is a debit, and an increase in a debt owed is a credit. Debits and credits for the month are equal, at Tk 300,000 each.

> Only credit purchases of goods for resale belong in the purchases journal.

Exceptions apply here too. A purchase paid in cash does not belong in the purchases journal, because no debt to a supplier arises. A purchase of equipment on credit, such as a new shelving unit, does not belong there either, because the business buys it to use and not to resell. Both go elsewhere: the first in the cash book of Chapter 12 'The Cash Book and Bank Reconciliation', the second in the general journal. A clerk therefore asks two questions of each invoice received. Was it bought on credit? Was it goods for resale? Only two answers of yes place it in the purchases journal.

> A posting reference lets anyone trace a figure back to its source.

Each posting should carry a reference. The journal line records the account to which it was posted, and the account records the journal and the date from which the figure came. This two-way trail costs a few seconds for each posting. It repays that time whenever a customer queries a bill or an auditor, who is a person who examines the records, asks where a figure originated.

> Recap: each sale or purchase has one line, and each total is posted once.

*Before moving on.* The sales journal records credit sales, and the purchases journal records credit purchases. Each line is posted to one individual account, and each total is posted once to the main accounts. You should now be able to state which accounts the sales journal total of Tk 269,000 debits and credits.

* * *

## Control Accounts

> The individual accounts of customers need a home of their own, apart from the main ledger.

@ Subsidiary ledger | A ledger holding the individual accounts of customers or suppliers, supporting a main ledger account.

A business with hundreds of customers cannot keep every customer account among its main accounts, because the main ledger would become huge and hard to read. It keeps them in a separate book. A **subsidiary ledger** is a ledger holding the individual accounts of customers or suppliers, supporting a main ledger account. One subsidiary ledger holds the accounts of customers. Another holds the accounts of suppliers. Meghna and Sons posts each line of the sales journal to the customer's account in the first of these.

> The main ledger keeps a single summary account for each subsidiary ledger.

@ Control | Word in use. In daily life, power to direct something. In accounting, a check that a total agrees with the sum of its parts.

@ Control account | A main ledger account that sums up the balances of all the accounts in a subsidiary ledger.

A **control account** is a main ledger account that sums up the balances of all the accounts in a subsidiary ledger. The accounts receivable control account sums up every customer account. The accounts payable control account sums up every supplier account. Its name explains its job. The word control here means a check, not power over customers. If the control account and the subsidiary ledger are correct, they must tell the same story. A difference shows that an error exists somewhere.

> Pause and check that you can tell the two ledgers apart.

:pause 11.p1 | Which holds the balance of one named customer: the accounts receivable control account or the subsidiary ledger? Which holds the total owed by all customers?

> Agreeing totals means comparing the control account with the sum of the individual balances.

Agreeing the totals is a short calculation, and we perform it with the case. The control account receives the total of the sales journal as a debit. The subsidiary ledger receives the same sales as individual debits, one for each customer. Neither side may be changed without the other. A student might ask why a business keeps both records. The answer is that each one checks the other.

> The case file gives the opening balance, which both records must match.

:case Case file, illustrative. At 1 November 2026, the accounts receivable control account of Meghna and Sons had an opening balance of Tk 280,000. During November, credit sales posted from the sales journal total Tk 269,000.

> The calculation follows the standard order, and the check is the agreement itself.

*Given.* The opening balance is Tk 280,000. We assume that the customer accounts brought forward also total Tk 280,000, as a correct ledger requires. The November credit sales are Tk 85,000, Tk 120,000 and Tk 64,000. *Find.* The closing balance of the control account, and of the sum of customer accounts. *Formula.* Closing balance equals opening balance plus credit sales posted. In symbols, C = O + S, where C is the closing balance, O is the opening balance and S is the sales posted. *Steps.* Tk 85,000 + Tk 120,000 + Tk 64,000 = Tk 269,000. Then Tk 280,000 + Tk 269,000 = Tk 549,000. *Answer.* Both the control account and the sum of customer accounts show Tk 549,000. *Check.* The two totals are equal, so the posting is consistent.

> Agreement does not prove that every figure is correct, only that no posting is missing or unequal.

Exceptions need care. Agreement shows that the control account and the customer accounts hold the same total. It does not prove that each customer account is correct, because an error could be posted to both sides. One example is a sale recorded under the wrong customer name. Two errors of equal and opposite size could also hide each other. In this chapter we ignore cash received from customers and goods returned, so the balance only rises; Chapter 12 shows how receipts reduce it.

> The same method applies to suppliers, with the control account on the credit side.

The same method applies to suppliers. Meghna and Sons posts each line of the purchases journal to the supplier named on it: Tk 150,000 to Ananda Publishers, Tk 96,000 to Prothom Print and Tk 54,000 to Jonaki Books. These are credits, because they increase debts owed. The credit side of the accounts payable control account receives the total of Tk 300,000. The credits in the supplier accounts also total Tk 300,000, since Tk 150,000 + Tk 96,000 = Tk 246,000, and Tk 246,000 + Tk 54,000 = Tk 300,000. Only the new purchases are counted here, because the case gives no opening balance for suppliers.

> Recap: one control account summarises one subsidiary ledger, and the two totals must agree.

*Before moving on.* A subsidiary ledger holds individual accounts. A control account in the main ledger sums them. To agree the totals, find the closing balance of the control account and compare it with the sum of the individual balances. You should now be able to say what a difference between the two totals tells you.

* * *

## Worked Case: Recording and Agreeing One Month

> This worked case joins the sales journal, the purchases journal and the control account in one month.

*Situation.* It is 30 November 2026. Meghna and Sons has recorded its credit sales on invoices 701, 702 and 703, with a total of Tk 269,000, and its credit purchases from three suppliers, with a total of Tk 300,000. The accounts receivable control account opened the month at Tk 280,000. *Question.* Which totals reach the main ledger, and do the control account and the customer accounts agree at month end?

> The reasoning starts with the totals and then moves to the check.

*Reasoning.* First, total each journal. The sales journal total is Tk 85,000 + Tk 120,000 + Tk 64,000, which is Tk 269,000. The purchases journal total is Tk 150,000 + Tk 96,000 + Tk 54,000, which is Tk 300,000. Second, post each total once. For sales, debit the accounts receivable control account Tk 269,000 and credit Sales Tk 269,000. For purchases, debit Purchases Tk 300,000 and credit the accounts payable control account Tk 300,000. Third, post each line to the customer or supplier account named on it. Fourth, compare the control account with the sum of the customer accounts.

> The conclusion is that the control account stands at Tk 549,000, matching the customer accounts.

*Conclusion.* The accounts receivable control account is Tk 280,000 + Tk 269,000, which is Tk 549,000. The three customer accounts have received debits of Tk 85,000, Tk 120,000 and Tk 64,000, and, as assumed, the brought-forward customer balances total Tk 280,000. Their sum is also Tk 549,000. The totals agree. *Check.* Debits and credits posted from the two journals are Tk 569,000 each, as Tk 269,000 plus Tk 300,000 gives the same sum on both sides.

> Posting the lines to individual accounts is the step that makes later checking possible.

*Posting the lines.* The three customer accounts each receive a debit: Dhanmondi Girls' School Tk 85,000, Rose Valley School Tk 120,000 and Lalmatia College Tk 64,000. The three supplier accounts each receive a credit: Ananda Publishers Tk 150,000, Prothom Print Tk 96,000 and Jonaki Books Tk 54,000. Each posting names the journal that it came from, so any figure can be traced to its source document. This trail is the reason a business records a reference on every posting.

> Three slips occur often in this work, and each one can be prevented.

Common slips deserve a warning. The first is posting both the lines and the total to the same main account, which counts every sale twice. The second is posting the total to the wrong side, a credit where a debit belongs. The third is mixing periods, for example putting a sale of 2 December in the November total. Each slip is found by the same test: after posting, the control account and the individual accounts must agree.

* * *

## Summary

> The summary restates the whole chapter in a few lines.

A special journal records one repeated kind of transaction in its own book. The sales journal holds credit sales, and the purchases journal holds credit purchases. Each line is posted to an individual account in a subsidiary ledger, and each total is posted once to the main ledger. A control account sums a subsidiary ledger, and the two totals must agree. For Meghna and Sons in November 2026, credit sales were Tk 269,000, credit purchases were Tk 300,000, and the accounts receivable control account closed at Tk 549,000.

## Think It Through

:q 11.t1 | A very small business makes five credit sales in a year. Explain why it may not need a sales journal, and say at what point the answer might change.

:q 11.t2 | A clerk posts every line of the sales journal to the customer accounts and then posts every line again to the accounts receivable control account. What goes wrong, and how would the agreement test reveal it?

:q 11.t3 | A clerk totals a sales journal as Tk 52,400, but the true total is Tk 54,200. The customer accounts have been posted correctly. Which test reveals the error, and what difference appears?

## Where People Go Wrong

> Five common misunderstandings are stated here, each with its correction.

Some students believe that a special journal replaces the ledger. It does not. A special journal is a book of first record, like the general journal, and its entries still reach the ledger by posting. Others believe that all transactions of a business go into special journals. They do not: cash transactions, adjusting entries and correcting entries have other books. A third belief is that agreement of the control account with the customer accounts proves that all figures are right. It proves only that the two totals are equal. Last, students sometimes read the word control as a power over customers. In accounting it means a check. A fifth belief is that special journals need new rules for debit and credit. They do not: the rules of Chapter 4 'Accounts, Debits and Credits' apply unchanged, and only the method of recording is different.

## In History

> A machine built for the census of 1890 started the mechanising of record-keeping.

In 1890 the United States counted its people with machines designed by Herman Hollerith, an American engineer and former employee of the Census Bureau. The count of 1880 had taken about seven years to tabulate. The Census Bureau then held a contest for a faster method, and Hollerith's system won.^2 His method placed the facts about each person on a punched card. Holes in the card completed an electrical circuit, and dials counted the totals. Hollerith had patented the machine in 1889, and the census of 1890 was the first large count to use it.

^2: The Census Bureau, the Smithsonian Institution and The Henry Ford museum each describe the contest and the machine, and their accounts agree on these points.

> The machines worked in two stages: first record each fact on a card, then total each kind of fact.

Clerks first transferred the facts from the census schedules onto cards, using a punch. The cards then passed through the tabulating machine, and dials recorded one count for each kind of fact. Notice that this is the two-stage method of this chapter: record each item on its own line or card, then total each kind once. In 1911 Hollerith's firm joined three other firms to form the Computing-Tabulating-Recording Company, which later became IBM.

> The link with accounting is the idea of grouping like records and totalling them quickly.

A tabulating machine is not a special journal, but the two share one idea: group records of the same kind and total each group at once. In 1896 Hollerith incorporated the Tabulating Machine Company. In later decades, similar machines were adapted to bookkeeping, and the company became part of the business that grew into IBM. Mechanised records, like special journals, show that large numbers of similar transactions reward the effort of organising them.

## Review Questions

:q 11.1 | A tea stall makes three credit sales: Tk 100, Tk 200 and Tk 300. Enter them in a sales journal, total the amount column, and state which two main accounts receive the total and on which side.

:q 11.2 | A different bookshop makes these credit sales in December 2026: 2 December, invoice 801, Greenfield School, Tk 42,500; 9 December, invoice 802, Padma College, Tk 18,750; 15 December, invoice 803, Greenfield School, Tk 31,200. Its accounts receivable control account opens at Tk 150,000. Enter the sales, total them, and find the closing balance of the control account.

:q 11.3 | In one week a sales journal totals Tk 126,400. The control account opened at Tk 310,000. After posting, the customer accounts show balances of Tk 120,000, Tk 95,400, Tk 150,000 and Tk 61,000. Do the totals agree? If not, state the difference.

:q 11.4 | A shop records three credit purchases: Tk 36,000, Tk 54,500 and Tk 29,500. The accounts payable control account opened at Tk 200,000. Total the purchases journal, state the debit and credit posted, and find the closing balance of the control account.

