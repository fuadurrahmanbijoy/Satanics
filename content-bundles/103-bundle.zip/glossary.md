:glossary 01
Service business | A business that earns money by doing work for customers rather than by selling goods. The customer pays for the work performed, such as a repaired book, a haircut or a lesson, and takes home no goods that the business bought or made.
Merchandising business | A business that buys finished goods and sells them again at a higher price. It does not change the goods. A bookshop that buys books from publishers and sells the same books to readers is an example.
Manufacturing business | A business that makes goods from materials and then sells them. It holds materials, goods half finished and goods ready to sell. A bakery that turns flour and fuel into bread is an example.
Company | A business that the law treats as a person separate from its owners. Its ownership is divided into equal parts called shares, so it can have many owners. It can own goods and owe money in its own name.
Shareholder | A person who owns one or more shares of a company. A person who holds one tenth of the shares owns one tenth of the company. More shares give a larger part of the ownership.

:glossary 02
Accounting | The process of recording, sorting and reporting the money effects of a business's events to people who need them. When a shop sells a novel, accounting records the sale, sorts it with other sales, and reports the total to the owner, the bank and others.
Bookkeeping | The recording part of accounting: writing down each transaction in the right book. A bookkeeper writes each sale and payment as it happens, while an accountant also sorts the records, checks them and prepares reports for readers who need them.
Financial accounting | Accounting that prepares reports for outsiders, such as lenders, owners and tax authorities. Its reports follow written rules, so that outsiders can compare one business with another. A bank's yearly report on a borrower is an example.
Management accounting | Accounting that prepares reports inside the business to help managers plan and control. No outside rule governs these reports, and the manager designs them to answer a question, such as which books sell fastest each week.
Accounting standard | A written rule about how to record and report items, so that different businesses report in the same way. For example, a standard may say how goods held for sale must be measured. In daily life, a standard means a level of quality.
Business entity | The rule that a business is treated as separate from its owner when records are kept. The owner's household spending stays out of the business records, and two businesses of one owner keep separate books, even when the law treats the owner and business as one person.
Going concern | The assumption that a business will continue to operate for the foreseeable future. Because of it, a shop's shelves are treated as items used for years. The assumption fails when the business is about to close, and records must then show sale values.
Historical cost | The rule of recording an asset at the price paid for it, not at its present value. The price paid can be proved by a receipt, while a present value is an opinion. A shelf bought for a price stays at that price in the records.
Financial statement | A formal report of a business's results or position, prepared at the end of a period. A period may be a month, a quarter or a year. The income statement, which shows profit, and the balance sheet are examples taught in a later chapter.

:glossary 03
Transaction | An event that changes the money position of a business and must be recorded. Buying shelving for cash is a transaction; a customer saying she may buy next month is not, because no money has yet changed.
Asset | Something of value that a business owns or controls, such as cash, goods held for sale or equipment. For example, the shelving bought by a workshop is an asset, and so is the cash in its drawer.
Liability | An amount that a business owes to others, such as a bank loan or an unpaid supplier bill. For example, Tk 200,000 owed to a publisher for books is a liability until it is paid.
Owner's equity | The owner's claim on the business: what is left of the assets after all liabilities are paid. For example, assets of Tk 565,000 less liabilities of Tk 120,000 leave owner's equity of Tk 445,000.
Accounting equation | The rule that assets always equal liabilities plus owner's equity, written A = L + E. It holds because every asset was provided either by a lender or by the owner.
Revenue | Money earned, or becoming due, from selling goods or doing services. For example, a binding fee of Tk 40,000 earned by a workshop is revenue, whether the customer pays now or later.
Expense | A cost used up in earning revenue, such as rent or wages. For example, rent paid for a month in which a workshop has used the room is an expense; buying shelving is not.
Drawings | Money or goods that the owner withdraws from the business for personal use. Drawings lower the owner's equity, but they are not an expense, because they do not help to earn revenue.

:glossary 04
Account | A record that collects all the increases and decreases of one kind of item. The Cash account, for example, shows every receipt and payment of cash, so its balance tells the business how much cash it holds.
Chart of accounts | A list of every account a business uses, with a code for each. It stops the business from opening duplicate accounts or forgetting one. Meghna Binding Service, for example, uses eight accounts, so its chart is short.
T-account | A simple account drawn as a letter T, with the name of the account across the top. The left side holds the debit entries and the right side holds the credit entries. It is a quick way to show an account's entries and balance.
Debit | An entry on the left side of an account. It increases assets, drawings and expenses, and it decreases liabilities, owner's capital and revenue. The word names a side; it does not mean good, bad, more or less.
Credit | An entry on the right side of an account. It increases liabilities, owner's capital and revenue, and it decreases assets, drawings and expenses. Like debit, the word names a side only and carries no judgement.
Normal balance | The side of an account, debit or credit, on which its increases are recorded and where its balance usually ends. Cash has a debit normal balance, and Accounts Payable has a credit normal balance. A balance on the other side is a signal to look closer.
Double entry | The rule that every transaction is recorded twice, once as a debit and once as a credit of equal amount. It keeps the accounting equation in balance and exposes many mistakes, though equal totals do not prove that every entry is right.

:glossary 05
Accounting cycle | The series of steps repeated each period, from recording transactions to preparing closing records. It begins with source documents, passes through the journal and the ledger, and ends with reports and closing records, after which the next period starts the same steps again.
Source document | Paper or electronic proof of a transaction, such as an invoice, receipt or cheque stub. Records begin from the document, not from memory, because a bank, a tax authority or an auditor can inspect it. A publisher's invoice for books is an example.
Journal | The book of first entry, in which transactions are recorded in date order with debits and credits. Each entry shows the date, the debited account, the credited account, the amounts and a narration. A purchase on credit is written here before anywhere else.
Narration | A short note under a journal entry explaining the transaction. A good narration names the event, not the accounts. For example, "Bought shelving for cash" tells a later reader why Shelving was debited and Cash credited.
Compound entry | A journal entry that has more than one debit or more than one credit. Total debits still equal total credits. Buying a press for Tk 30,000, part paid in cash and part owed, debits one account and credits two.
Ledger | The book containing all of a business's accounts, where the effects of journal entries are collected. Each account has its own page, so all the Cash entries or all the Rent entries sit together and can be balanced.
Posting | Copying the debits and credits from the journal to the right accounts in the ledger. Posting changes no amount. Each journal line is copied once, and the folio columns record that it has been done.

:glossary 06
Trial balance | A list of all ledger account balances, with debits and credits totalled, to test that they are equal. It is taken at one date. If the two totals agree, the test is passed; if they differ, a slip must be found.
Unadjusted trial balance | A trial balance taken before the period-end adjustments have been recorded. The January list of Meghna Binding Service is unadjusted, because no adjustment has yet been made to the accounts.
Transposition error | A mistake in which two digits of a number are written in the wrong order, such as 53 for 35. Posted on one side only, it makes the trial balance totals differ by a multiple of 9, here 18.
Suspense account | A temporary account that holds a difference until its cause is found. It takes the side that makes the two column totals agree, and it must be cleared by a correcting entry before reports are prepared.

:glossary 07
Accounting period | The span of time, such as a month, a quarter or a year, for which a business measures and reports its results. For example, Meghna Binding Service reports for the calendar year 2026.
Accrual basis of accounting | A method that records revenue when it is earned and an expense when it is incurred, whether or not cash has moved. For example, wages earned in December belong to December even if paid in January.
Matching principle | The rule that expenses are recorded in the same period as the revenue they helped to earn. For example, insurance for October to December is placed beside the revenue of those months.
Prepaid expense | A cost paid in advance that is an asset until it is used up, after which it becomes an expense. For example, a year of insurance paid on 1 October is mostly still an asset on 31 December.
Unearned revenue | Money received before the work is done, held as a liability until the work is performed. For example, a school pays Tk 24,000 in advance; the part not yet worked remains a liability.
Accrued expense | A cost that has already been used up but not yet paid, shown as a liability. For example, wages earned by workers in the last days of December but paid in January.
Accrued revenue | Revenue that has already been earned but not yet received or billed, shown as an asset. For example, binding work finished in December for which the invoice is sent in January.
Adjusting entry | A journal entry made on the last day of a period to bring an account to its correct balance for that period. For example, debiting Insurance Expense and crediting Prepaid Insurance for the part used.

:glossary 08
Worksheet | A large ruled working paper with columns. An accountant uses it to move the figures of the trial balance through the adjustments towards the statements. It is private, it is not a financial statement, and it changes no ledger account. Example: Supplies show Tk 1,000 before an adjustment and Tk 400 after it.
Adjusted trial balance | A trial balance prepared after the adjusting entries have been taken into account. It shows the correct balance of each account, and its debit total equals its credit total. Example: Supplies of Tk 1,000 less an adjustment of Tk 600 appear as Tk 400.
Net income | The amount by which total revenue exceeds total expenses for a period. It is found by subtracting total expenses from total revenue, and it increases owner's equity. Example: revenue of Tk 6,000 less expenses of Tk 3,400 gives net income of Tk 2,600.
Net loss | The amount by which total expenses exceed total revenue for a period. It is found by subtracting total revenue from total expenses, and it reduces owner's equity. Example: expenses of Tk 3,400 and revenue of Tk 3,000 give a net loss of Tk 400.

:glossary 09
Income statement | A report of revenue and expenses for one period, such as a year, ending in net income or net loss. Its heading says *For the year ended*. Example: revenue Tk 788,000 less expenses Tk 604,000 gives net income of Tk 184,000.
Statement of owner's equity | A report showing how the owner's capital changed during one period. It starts with capital at the beginning, adds net income, subtracts drawings, and ends with capital at the end. Example: Tk 400,000 + Tk 184,000 − Tk 80,000 = Tk 504,000.
Balance sheet | A report of assets, liabilities and owner's equity at one date. Its two sides must agree, because assets equal liabilities plus owner's equity. Its heading says *At* and then the date. Some standards call it the statement of financial position.
Temporary account | An account for revenue, expense or drawings that measures one period only. It is closed to zero at the end of the period, so the next period starts afresh. Example: the Revenue account of one year.
Permanent account | An account for assets, liabilities or capital. It shows the position of the business, so it is never closed. Its balance at the end of one period becomes the opening balance of the next. Example: the Cash account.
Closing entry | A journal entry made at the end of a period that moves the balance of a temporary account to capital, usually through the income summary. After it, the temporary account stands at zero. Example: debit Revenue Tk 788,000, credit Income Summary Tk 788,000.
Income summary | A temporary account used to collect revenue and expenses at period end. Its balance equals net income or net loss, which is then moved to capital. After that move, the account stands at zero. It exists only during closing.
Reversing entry | An entry made on the first day of a new period that cancels an earlier accrual. It lets the later payment be recorded in the usual way. Example: debit Wages Payable and credit Wages Expense for Tk 14,000 on 1 January 2027.

:glossary 10
Net sales | Sales less sales returns and allowances. It is the revenue a merchandising business really keeps. Example: sales of Tk 10,000, less returns of Tk 500 and allowances of Tk 200, give net sales of Tk 9,300.
Cost of goods sold | The cost of the goods that were sold during the period. It equals opening inventory plus purchases less purchase returns less closing inventory. Example: Tk 2,000 + Tk 6,000 − Tk 300 − Tk 1,700 = Tk 6,000.
Gross profit | Net sales less cost of goods sold, before operating expenses are deducted. It shows what the business earns from buying and selling goods. Example: Tk 14,400,000 − Tk 9,800,000 = Tk 4,600,000.
Operating expense | A cost of running the business, such as wages or rent, apart from the cost of goods sold. Operating expenses are grouped as selling expenses and administrative expenses. Example: advertising and office rent.
Current asset | An asset expected to be turned into cash or used up within one year. Examples are cash, accounts receivable, inventory and prepaid expenses. Current assets are listed in the order in which they come closest to cash.
Current liability | A debt that must be paid within one year. Accounts payable are the usual example. The part of a long loan that falls due within one year is also current. Example: a loan instalment due in six months.
Error of omission | A mistake in which a transaction is left out of the books completely. Neither side of the entry is made, so the trial balance still agrees. Example: a credit sale of Tk 800 that is never entered.
Error of commission | A mistake in which an entry is made in the right class of account but the wrong account, or with a wrong amount. Example: electricity of Tk 700 debited to Telephone Expense, when both are expenses.
Error of principle | A mistake in which an entry is made in the wrong class of account, such as an expense recorded as an asset. Example: Tk 40,000 spent on a delivery van and debited to Repairs Expense.
Compensating error | Two or more mistakes that cancel each other so that the trial balance still agrees. Example: Wages debited Tk 300 too much and Rent debited Tk 300 too little, so the debit total is still correct.

:glossary 11
Special journal | A journal used for only one kind of repeated transaction, such as credit sales. It names the two accounts once in its heading and records only the changing parts, such as date, name and amount, on each line. Using one saves writing and reduces postings.
Sales journal | A special journal that records only sales of goods on credit. Each line comes from a copy of a sales invoice and shows the date, invoice number, customer and amount. Its total is posted once to the main ledger. Cash sales are not recorded in it.
Purchases journal | A special journal that records only purchases of goods on credit. Each line comes from an invoice received from a supplier and shows the date, supplier and amount. Its total is posted once to the main ledger. Cash purchases and purchases of equipment are not recorded in it.
Subsidiary ledger | A ledger holding the individual accounts of customers or suppliers, supporting a main ledger account. A business may keep one for customers and another for suppliers. Each line of a special journal is posted to the matching account in it.
Control account | A main ledger account that sums up the balances of all the accounts in a subsidiary ledger. If both are correct, the control account balance equals the total of the individual balances. A difference shows that an error exists somewhere.

:glossary 12
Cash book | A book that serves as both journal and ledger for cash and bank receipts and payments. It has a debit side for money received and a credit side for money paid, usually with a Cash column and a Bank column. A customer's Tk 500 in notes is written once, in the Cash column.
Deposit in transit | Money recorded as deposited in the books but not yet shown on the bank statement, because the bank has not yet processed it. For example, a deposit made after the bank closes on the last day of the month. It is added on the bank side of the reconciliation.
Outstanding cheque | A cheque written and recorded in the books but not yet paid by the bank, because the payee has not yet presented it or it has not yet cleared. For example, a cheque for Tk 900 written on 30 June and paid on 4 July. It is subtracted on the bank side.
Credit memo | A bank's notice that it has added money to the account, for example a collection made for the business or interest paid. The name follows the bank's books, where more owed to the customer is a credit. It is added on the book side of the reconciliation.
Debit memo | A bank's notice that it has deducted money from the account, for example a service charge. The name follows the bank's books, where less owed to the customer is a debit. It is subtracted on the book side of the reconciliation.
Dishonoured cheque | A cheque that the bank refuses to pay, usually because the writer's account lacks funds. The bank takes back any amount it credited, so the business subtracts it on the book side and restores the customer's account receivable. For example, a customer's cheque for Tk 800 returned unpaid.
Bank reconciliation statement | A statement that explains the difference between the bank balance in the cash book and the balance on the bank's statement. It has two halves, each ending in an adjusted balance, and the two must be equal. It is a working paper, not a ledger account.

:glossary 13
Inventory | Goods held for sale, or materials held to make goods for sale, in the ordinary course of business. The business must own them. It is a current asset until sale, when its cost becomes cost of goods sold. Books on a bookshop's shelves are inventory.
Raw materials | Materials a manufacturer holds to turn into products. They have not yet been changed by the factory's work. In a binding workshop, reels of paper, board, thread and glue are raw materials.
Work in process | Goods in a factory that have been started but are not yet finished. Their cost includes the materials and labour used so far. Sewn sheets that have no cover yet are work in process.
Finished goods | Completed products held for sale. They are closest to being turned into cash. Bound volumes ready for collection are finished goods, and a bookshop's inventory consists wholly of them.
Perpetual inventory system | A system that updates the inventory account after every purchase and sale, so that the account always shows what the business should hold. A count is still needed, as a check on the records.
Periodic inventory system | A system that finds inventory only by a physical count at period end. During the year only purchases are recorded, and cost of goods sold is found by subtraction: opening inventory plus purchases less closing inventory.
Net realisable value | The expected selling price of an item less the cost of selling it. If it is lower than cost, the item is reported at net realisable value. An item that sells for Tk 150 with Tk 20 of selling cost has a value of Tk 130.

:glossary 14
Cost flow assumption | A rule that decides which purchase costs are treated as sold and which remain in inventory. It concerns the order of costs, not the movement of goods. For example, a shop may sell its newest dictionary first but still assume that the oldest cost was sold first.
Ending inventory | The cost of goods still on hand at the end of the period. It appears as an asset in the balance sheet and becomes the opening inventory of the next period. Cost of goods sold plus ending inventory equals the cost of goods available.
First-in first-out | A method that treats the oldest costs as sold first, leaving the newest costs in inventory. Often written FIFO. When prices rise it gives the lowest cost of goods sold, the highest gross profit and an ending inventory close to current prices.
Last-in first-out | A method that treats the newest costs as sold first, leaving the oldest costs in inventory. Often written LIFO. When prices rise it gives the highest cost of goods sold and the lowest gross profit. International Accounting Standard 2 bars it.
Weighted average cost | A method that gives every unit the average cost of all units available. The unit cost is the cost available divided by the units available, so a larger layer counts for more. For example, Tk 32,600 divided by 100 units gives Tk 326 a unit.

:glossary 15
Plant asset | A long-lived physical asset used in running a business, such as a machine or a building. It is owned, used in the work of the business, and lasts more than one period. A book-cutting machine in a bookshop is a plant asset.
Intangible asset | A long-lived asset with no physical form, such as a patent or a trademark. The business cannot touch it, yet it can earn money for years. A patent is a legal right to be the only maker of an invention for a number of years.
Acquisition cost | All the money spent to buy an asset and make it ready for use. It includes the invoice price less discounts, freight, installation and testing. Payments after the asset is ready, such as repairs, are not part of it.
Capital expenditure | Spending that creates or improves an asset lasting more than one period. It is recorded as an asset on the balance sheet. The purchase of a machine is capital expenditure, and so is a motor fitted to make it work faster.
Revenue expenditure | Spending that keeps an asset in working order and is treated as an expense of the period. It is recorded in the income statement. A repair that restores a machine to its first condition is revenue expenditure.

:glossary 16
Depreciation | The spreading of a plant asset's cost over the years it is expected to be useful. It is a method of allocation, not a measure of the fall in market price and not a payment of cash. For example, a Tk 10,000 bicycle may carry a charge of Tk 2,000 a year.
Useful life | The period, or the amount of use, over which an asset is expected to serve the business. It may be given in years, kilometres or units made. It is an estimate and may be shorter than the time the asset would physically last.
Residual value | The amount a business expects to receive when it disposes of an asset at the end of its useful life. It may be zero. Only the cost less the residual value is spread over the years. For example, a machine costing Tk 330,000 with a residual value of Tk 30,000 has Tk 300,000 to spread.
Straight-line method | A depreciation method that charges an equal amount each year. The yearly charge equals cost less residual value, divided by the useful life in years. For example, (Tk 330,000 − Tk 30,000) ÷ 5 gives Tk 60,000 a year.
Units-of-production method | A depreciation method that charges an amount based on how much the asset is used in the period. A charge for each unit of use is found first and then multiplied by the units used. For example, Tk 0.60 a book times 90,000 books gives Tk 54,000.
Declining-balance method | A depreciation method that charges a fixed percentage of the asset's remaining book value each year. The charge is largest in the first year and falls after that. For example, 40% of Tk 330,000 gives Tk 132,000 in year 1.
Accumulated depreciation | The total depreciation charged to date on an asset, shown as a deduction from its cost. It grows by one charge each year. For example, after three years of Tk 60,000 it equals Tk 180,000.
Book value | An asset's cost less its accumulated depreciation. It is a figure in the records and need not equal the price at which the asset could be sold. For example, Tk 330,000 less Tk 180,000 gives a book value of Tk 150,000.

:glossary 17
Non-trading organisation | An organisation, such as a club or charity, that exists to serve its members or a cause rather than to earn profit. Its result is called a surplus or a deficit, and its equity is the accumulated fund. A village reading room is an example.
Subscription | A regular payment made by a member for belonging to an organisation. It is the main income of most clubs. Fees may be paid late, on time or early, so the cash received in a year is adjusted to find the income that belongs to the year.
Receipts and payments account | A summary of all cash received and paid in a period, with opening and closing balances. It has the form of a cash book. It shows cash only, so it ignores amounts owed, amounts paid early and the difference between lasting assets and everyday costs.
Income and expenditure account | The non-trading organisation's equivalent of an income statement, showing surplus or deficit on an accrual basis. It records income and costs in the period to which they belong, and leaves out the purchase of lasting assets.
Statement of affairs | A list of a business's assets and liabilities at one date, used to find capital when records are incomplete. The assets less the liabilities give the owner's equity. It is built by counting, so it is less exact than a balance sheet from a ledger.

:glossary 18
Partnership | A business owned by two or more people who agree to share its profit and loss. The owners are called partners. Three friends who open a bookshop and agree to share what it earns and loses form a partnership. The law of each country adds its own rules.
Partnership deed | A written agreement setting out each partner's capital, duties and share of profit. It prevents disputes by recording what was agreed. Where the deed is silent on a point, the law of the place supplies a rule, which partners often wish to replace.
Profit-sharing ratio | The fixed proportion in which partners divide profit and loss. A ratio of 5:3:2 cuts the amount into ten equal parts, giving five to the first partner, three to the second and two to the third. Unless the deed says otherwise, it also divides losses.
Interest on capital | A payment credited to partners for their capital before the remaining profit is divided. It rewards money put in. For a period shorter than a year, it is capital times the yearly rate times the fraction of the year. It divides profit; it is not an outside cost.
Liquidation | The process of selling a business's assets, paying its debts and sharing what remains among the owners. Outsiders are paid first. Each partner then receives capital less his or her share of any loss, so the partners are the last to be paid.
Realisation | The sale of assets, in liquidation, and the gain or loss on that sale. The loss is the book amount less the amount received. For example, an asset with a book amount of Tk 100 sold for Tk 80 gives a realisation loss of Tk 20.

:glossary 19
Share capital | The money a company receives from shareholders in exchange for shares. It records the face value of the shares issued. If shareholders pay Tk 1,000 for 100 shares of face value Tk 10, share capital is Tk 1,000. It appears among the owners' equity.
Authorised capital | The largest amount of share capital a company is allowed to issue under its founding documents. It is a ceiling and not money received. A company with authorised capital of Tk 50,000 may sell shares worth up to Tk 50,000 and no more.
Issued capital | The part of authorised capital that has actually been sold to shareholders. It can never exceed authorised capital. If authorised capital is Tk 50,000 and shares worth Tk 30,000 have been sold, issued capital is Tk 30,000.
Ordinary share | A share that gives a holder a vote and a claim on profit after other claims are paid. The dividend is not fixed, so it is large when profit is large and may be nothing when profit is small. It carries more risk and more possible reward.
Preference share | A share that gets a fixed dividend before ordinary shareholders, usually without a vote. For example, a holder of preference shares at 8% receives 8% of their face value before any ordinary dividend, if the company has enough profit.
Share application | A request to buy shares, sent with money, to a company that is offering them. The sender is not yet a shareholder. The company holds the money in a temporary account called Share Application until it decides who receives shares.
Allotment | The company's formal decision to give shares to applicants. From this moment the applicants become shareholders, and the company credits Share Capital and, where there is a premium, Share Premium. The Share Application account is then closed.
Share premium | The amount paid for a share above its face value. A share of face value Tk 10 sold for Tk 25 carries a premium of Tk 15. The premium is credited to its own account and is not part of share capital.

:glossary 20
Fiscal year | Any twelve-month period a business chooses for its yearly reports. It may start in any month, and the calendar year is one choice among many. Meghna and Sons uses 1 January to 31 December, while the Bangladesh government uses 1 July to 30 June.
Interim period | A reporting period shorter than a year. A quarter of three months is the usual example, and months and half-years are others. Interim reports use the same methods as yearly reports but depend more on estimates.
Product cost | A cost of buying or making goods held for sale. It waits in inventory until the goods are sold and then moves to cost of goods sold. The price paid for books and freight in are examples.
Period cost | A cost charged to the period in which it is incurred, because it belongs to time and not to particular goods. It reaches the income statement at once. Rent and wages are examples.
