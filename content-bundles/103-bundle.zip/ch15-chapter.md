:chapter XV | Plant Assets
:mood Two bills of the same size, one for a new machine and one for a repair: why do they live in different parts of the accounts?
:desc This chapter explains the long-lived assets a business uses to do its work, such as machines and buildings. You learn what counts as the cost of such an asset, which payments belong in that cost and which do not, and how to tell spending that builds an asset from spending that only keeps it working. The rules decide how large the profit and the balance sheet appear.
:plate ch15-plate.svg | A machine shop of the iron age, with lathe, leather belt and workmen

> A small puzzle: two payments for the same machine, one that stays in the asset and one that does not.

Imagine that the owner of a bookshop buys a machine to cut the edges of books. The seller sends an invoice. A lorry brings the machine, and the lorry driver wants payment. An electrician connects it, and a technician tests it on a few sheets of paper. Four months later a blade breaks, and a mechanic repairs the machine. Each of these events costs money, and the owner pays for all of them. Yet the accountant will treat them in two very different ways.

> The puzzle asks which payments become part of the machine in the accounts and which do not.

Why does the difference matter? Suppose the accountant adds every payment to the machine. The machine looks more valuable, and the profit for the year looks larger, because fewer costs are charged against it. Suppose instead that the accountant charges every payment as an expense at once. The profit for the year looks smaller, and the machine looks cheaper than it really was. Neither extreme is honest. The accountant needs a rule that decides, payment by payment, where each one belongs. This chapter builds that rule.

> The running case supplies the payments for one machine, which the chapter follows to the end.

:case Case file, illustrative. Meghna and Sons bought a book-cutting machine on 1 April 2026. The invoice was Tk 300,000. Freight was Tk 10,000, installation was Tk 15,000 and a trial run cost Tk 5,000. On 14 August 2026 a breakdown required a repair that cost Tk 8,000.

:box YOU WILL NEED
This chapter uses the balance sheet and the income statement from Chapter 9 'Financial Statements and Closing Entries', section 9.1 'The Three Statements'. It also uses the idea of a cost paid now that benefits later periods, from Chapter 7 'Adjusting the Accounts', section 7.2 'Deferrals'. The arithmetic is addition and subtraction; Appendix A1 'Maths You Will Use' holds a short reference.

* * *

## 15.1 What Plant Assets Are

> A business owns some things to sell and other things to use, and this chapter is about the second group.

Think about a family that runs a small food stall. The rice and vegetables on the table are for sale, and they are gone in a day. The stove, the large pot and the table itself are different. The family does not sell them. It uses them every day for years. Accountants separate these two groups, because they behave differently in the accounts. The first group is inventory, which Chapter 13 explains. The second group is the subject of this section.

> Plant asset is the name for long-lived physical things used in the business.
@ Plant asset | A long-lived physical asset used in running a business, such as a machine or a building.
@ Plant | Word in use. In daily life, a growing thing such as a tree, or a factory. In accounting, plant asset covers any long-lived physical asset used in the business, in a shop, an office or a factory alike.

The accounting name for the stove, the pot and the table is **plant asset**. A plant asset is a long-lived physical asset used in running a business, such as a machine or a building. For example, the book-cutting machine of Meghna and Sons is a plant asset. The word *plant* may mislead you. In daily speech it means a living plant or a factory. In accounting it applies to the equipment of any business, even a small shop with no factory at all.

> Four features together mark an item as a plant asset.

How can you tell whether an item is a plant asset? Test it with four questions. First, is it physical, so that you can touch it? Second, does the business own it? Third, does the business use it to do its work, rather than hold it to sell? Fourth, will it last for more than one accounting period? If the answer to all four is yes, the item is a plant asset. A machine, a delivery van, a shelf unit, a computer and a building all pass the test. A pack of paper fails the fourth question, because the business uses it up within weeks.

> A plant asset moves from the business's cash to its balance sheet, and then it serves for years.

Think about what this means for the statements. When the business buys a plant asset, the money does not disappear as an expense. The business gives up cash and receives an asset of equal value. So the balance sheet shows the asset, and the income statement shows no expense on the day of purchase. The business then uses the asset over many periods. This is the same idea as the deferrals of Chapter 7, section 7.2 'Deferrals': a cost is paid now, and its benefit comes later. Chapter 16 'Depreciation' teaches how the cost is spread over the years of use.

> An exception: the same object can be a plant asset in one business and inventory in another.

The test depends on purpose, so the same object may fall into either group. A book-cutting machine on the floor of Meghna and Sons is a plant asset, because the shop uses it. The same machine in the showroom of a company that sells such machines is inventory, because that company holds it for sale. The question is always: for what purpose does this business hold the item?

> Land is also a plant asset, but it behaves differently from the others.

Land deserves a short note. It is physical, owned and used, and it lasts. So it counts as a plant asset. But land does not wear out the way a machine does, and Chapter 16 'Depreciation' explains why this matters. For now, remember only that the class includes land, buildings, machines, vehicles and furniture.

> Some valuable assets cannot be touched, and they form a separate group.
@ Intangible asset | A long-lived asset with no physical form, such as a patent or a trademark.

Not every long-lived asset has a physical form. An **intangible asset** is a long-lived asset with no physical form, such as a patent or a trademark. For example, a patent is a legal right, given by the state, to be the only maker of a new invention for a number of years. A trademark is a name or sign that identifies a product. The owner cannot touch either one, yet each can earn money for years. The word *intangible* means "not able to be touched". Rules for intangible assets differ from country to country, so a business follows the standards of the place where it reports.

> A table sets the two groups side by side so that you can compare them.

The table below compares the two kinds of long-lived asset with an ordinary item that is neither. Read each row as a question, and each column as an answer for one item.

:table Plant assets, intangible assets and ordinary supplies
| Question | Plant asset | Intangible asset | Pack of paper |
| --- | --- | --- | --- |
| Physical form? | Yes | No | Yes |
| Used in the business, not held for sale? | Yes | Yes | Yes |
| Lasts more than one period? | Yes | Yes | No |
| Example | Book-cutting machine | Patent | Paper for printing |

> The viewpoints of owner, bank and manager show why the class matters.

The class matters to different people. The owner wants to know how much money is tied up in equipment. A bank that lends money may accept the equipment as security, so it asks what the equipment cost. The manager decides when a machine must be replaced. The employee uses the machine every day and wants it kept in good order. All four depend on one reliable number: the cost of the asset.

> Before moving on, we collect the ideas of this section.

*Before moving on.* A plant asset is a long-lived physical asset used in running a business. It is physical, owned, used and lasting. An intangible asset has no physical form but meets the other tests. The same object may be inventory in a different business. You should now be able to say, for any item, whether it is a plant asset, and give the reason.

## 15.2 Cost of a Plant Asset

> The first task is to decide how much the asset cost, and the answer is larger than the invoice.

How much did the machine cost? Many students say: the amount on the invoice. This answer is tempting, and it is incomplete. The owner paid for the lorry, the electrician and the test as well. The machine was not usable until all of these were done. An honest cost must include them.

> The rule says the cost covers everything spent to buy the asset and make it ready.
@ Acquisition cost | All the money spent to buy an asset and make it ready for use.

The accounting name for this honest cost is **acquisition cost**. Acquisition cost is all the money spent to buy an asset and make it ready for use. For example, if a machine costs Tk 200,000 and the owner pays another Tk 10,000 to bring it and install it, the acquisition cost is Tk 210,000. The word *acquisition* means "getting". The test for each payment is simple to say: was it necessary to get the asset and to make it ready for use? If yes, it belongs in the cost.

> The items that belong in the cost can be listed, and each has a reason.

Let us look at the usual items. The first is the price on the invoice, less any trade discount the seller gives. The second is freight, the cost of bringing the asset to the business, because the asset is of no use at the seller's door. The third is installation, which includes the electrician and any special base or wiring. The fourth is testing, because a machine is not ready until it has been tested. The fifth is any tax or duty on the purchase that the business cannot recover. Where a tax can be reclaimed from the government, it is not part of the cost; rules on this differ between countries, so the business checks the law of its own place.

> The items that do not belong are those that come after the asset is ready, or that do not add to it.

Other payments are not part of the cost. Repairs after the asset is working are not part of it, because the asset was already ready. Training the staff to use the machine is not part of it, because the training does not make the machine itself ready. Insurance for the first year of use, and the running costs such as electricity, are not part of it either, because they relate to using the asset, not to getting it. Damage caused by careless handling during delivery is also excluded. It is a loss for the period, not a part of the asset. Many students find this list confusing at first. The test makes it easy: a payment up to the moment the asset is ready for use is in the cost, and a payment after that moment is out.

> The case file lists four payments to the moment of readiness and one payment afterwards.

:case Case file, illustrative. For the book-cutting machine bought on 1 April 2026: invoice Tk 300,000; freight Tk 10,000; installation Tk 15,000; trial run Tk 5,000. These four payments were all made to bring the machine to a working state. The repair of Tk 8,000 on 14 August 2026 came after the machine was working.

> The figure shows how the cost builds up from its parts, one on top of the other.

The figure below shows the cost as a stack. Read it from the bottom upward. The widest block at the bottom is the invoice. Each block above it is one more payment added to the cost. The top block is the total, the acquisition cost. The blocks are not drawn to scale, because the smaller payments would be too thin to see.

:fig Cost build-up of one machine as stacked parts | ch15-fig01.svg

> A first example, with small and clean numbers, shows the method before the case.

We now apply the method. *Given.* A shop buys a machine with an invoice price of Tk 200,000, less a trade discount of Tk 10,000. Freight is Tk 4,000. Installation is Tk 6,000. The staff training course costs Tk 3,000. *Find.* The acquisition cost.

> The formula is stated in words first and then in symbols.

*Formula.* Acquisition cost equals the invoice price less trade discount, plus freight, plus installation, plus testing and any tax that cannot be recovered. In symbols, let P be the invoice price, D the trade discount, F the freight, I the installation and T the other payments needed for readiness. Then the acquisition cost is P − D + F + I + T.

> Each line of arithmetic is shown, and the training course is left out with a reason.

*Steps.* The price after discount is 200,000 − 10,000 = Tk 190,000. Add freight: 190,000 + 4,000 = 194,000. Add installation: 194,000 + 6,000 = 200,000. There is no testing cost, so T = 0. The training course of Tk 3,000 is excluded, because it does not make the machine ready. *Answer.* The acquisition cost is Tk 200,000. *Check.* The total paid for the machine and its readiness is 190,000 + 4,000 + 6,000 = 200,000, and the Tk 3,000 is treated as an expense.

:pause 15.p1 | A delivery van is bought for Tk 900,000. The business also pays Tk 20,000 for the first year's road licence and Tk 12,000 for painting its name on the side before use. Which payments, if any, belong in the acquisition cost? Give a reason for each.

> Now the case file is worked in the same order, with the same method.

Now we apply the method to the machine of Meghna and Sons. The price is Tk 300,000, with no discount stated. Freight is Tk 10,000, installation is Tk 15,000 and the trial run is Tk 5,000. The acquisition cost is 300,000 + 10,000 + 15,000 + 5,000 = Tk 330,000. The repair of Tk 8,000 is excluded, because it happened more than four months after the machine was working.

> The entry records the whole acquisition cost as one asset, not as five separate items.

The entry follows. Suppose the shop paid by bank. The business debits Machinery with Tk 330,000 and credits Bank with Tk 330,000. The machine appears on the balance sheet at Tk 330,000, and no expense is recorded on the day of purchase. Why record one figure rather than five? The five payments together are the price of having a working machine, and the balance sheet should show that price in one place.

> Before moving on, we collect the ideas of this section.

*Before moving on.* The acquisition cost of a plant asset is all the money spent to buy it and make it ready for use. It includes the invoice price less discounts, freight, installation and testing. It excludes payments after readiness, such as repairs and training. You should now be able to list the payments for one asset and state which belong in the cost.

## 15.3 Capital and Revenue Spending

> Every payment a business makes either builds an asset or is used up, and the two kinds need names.

Sections 15.1 and 15.2 dealt with the cost of one asset. We now widen the question. Every day the business pays for things: wages, rent, paper, repairs, new machines. Some of these payments create something that lasts for years. Others are used up in the period. If the accountant puts a payment in the wrong group, the profit and the balance sheet are both wrong. We need two names for the two groups.

> The first group is spending that creates or improves a lasting asset.
@ Capital expenditure | Spending that creates or improves an asset lasting more than one period.
@ Improvement | Word in use. In daily life, any change for the better. In accounting, a change that makes an asset last longer, work faster or do more, and so is added to its cost.

The first group is **capital expenditure**. Capital expenditure is spending that creates or improves an asset lasting more than one period. For example, the purchase of the book-cutting machine, at Tk 330,000, is capital expenditure. It is recorded as an asset on the balance sheet. The word *capital* here has nothing to do with the owner's money. It points to the long life of the thing that the spending creates.

> The second group is spending that keeps an asset in order and is used up in the period.
@ Revenue expenditure | Spending that keeps an asset in working order and is treated as an expense of the period.

The second group is **revenue expenditure**. Revenue expenditure is spending that keeps an asset in working order and is treated as an expense of the period. For example, the repair of Tk 8,000 on 14 August 2026 is revenue expenditure. It is recorded as an expense in the income statement of 2026. The name can confuse a new reader. It does not mean that the spending produces revenue. It means that the spending is matched against the revenue of the period in which it is made.

> The matching principle gives the reason for the split.

Why is the line drawn here? Think of the matching principle and the accrual basis of accounting, which you have met. An expense belongs to the period whose revenue it helps to earn. A repair keeps the machine running this year, so its cost belongs to this year. A new machine will help earn revenue for many years, so its cost is spread across those years. If the accountant charged the whole machine to the first year, that year would look poor and the later years would look rich, which is a false picture.

> The hard cases are the repairs and improvements, and a single test sorts them.

Some cases are not obvious. A mechanic works on a machine. Is that a repair or an improvement? The test asks what the spending does. If it restores the asset to the condition in which it was first bought, it is a repair: revenue expenditure. If it makes the asset last longer, work faster or do more than before, it is an improvement: capital expenditure. For example, replacing a broken blade with a new blade of the same kind is a repair. Fitting a motor that makes the machine cut twice as fast is an improvement, and its cost is added to the cost of the machine.

> A table compares the two kinds of spending question by question.

The table below sets the two kinds side by side. Read each row as a question and each column as an answer.

:table Capital expenditure and revenue expenditure compared
| Question | Capital expenditure | Revenue expenditure |
| --- | --- | --- |
| What does it do? | Creates or improves a lasting asset | Keeps the asset working |
| Where is it recorded first? | Balance sheet, as an asset | Income statement, as an expense |
| How long is the benefit? | More than one period | This period |
| Example from the case | Machine, Tk 330,000 | Repair, Tk 8,000 |

> The exception: a small payment may be treated as an expense even if the item lasts.

There is one exception that avoids waste of effort. A business may buy a stapler that lasts five years. Strictly it is a plant asset. But recording it as an asset and tracking its cost for five years is not worth the effort. Most businesses therefore set a minimum amount, below which any such item is charged as an expense at once. The size of the minimum is a business decision and differs from one business to another.

> The effect of an error shows why the rule matters.

Suppose the Tk 8,000 repair were wrongly added to the machine. The income statement would show Tk 8,000 less expense, so the profit would be Tk 8,000 higher. The balance sheet would show the machine at Tk 338,000, which is Tk 8,000 too much. Both statements would be wrong in the same direction. Now suppose the opposite error: a Tk 15,000 installation were charged as an expense. The profit would be Tk 15,000 too low and the machine Tk 15,000 too low in the balance sheet.

> Before moving on, we collect the ideas of this section.

*Before moving on.* Capital expenditure creates or improves an asset lasting more than one period, and it is recorded as an asset. Revenue expenditure keeps an asset in working order, and it is an expense of the period. A repair restores; an improvement adds. A mistake in the choice moves profit and the asset by the same amount. You should now be able to classify any payment and say what happens if it is wrongly classified.

## Worked Example: The Book-Cutting Machine

> The whole bill for the machine is split into capital and revenue spending, with every line shown.

:case Case file, illustrative. Meghna and Sons paid the following for the book-cutting machine in 2026: invoice Tk 300,000; freight Tk 10,000; installation Tk 15,000; trial run Tk 5,000; repair after a breakdown on 14 August Tk 8,000.

> The question has two parts: the acquisition cost, and the effect on profit if the repair is wrongly capitalised.

*Find.* (a) the acquisition cost and the amount of revenue expenditure; (b) the balance sheet figure and the profit effect if the repair were wrongly added to the machine.

> Part (a) adds only the payments needed to make the machine ready.

*Part (a), steps.* Payments up to readiness: 300,000 + 10,000 = 310,000. Then 310,000 + 15,000 = 325,000. Then 325,000 + 5,000 = 330,000. The repair of Tk 8,000 is after readiness and is a revenue expenditure. *Answer.* The acquisition cost is Tk 330,000 and the revenue expenditure is Tk 8,000. *Check.* The total of all payments is 330,000 + 8,000 = 338,000, which equals 300,000 + 10,000 + 15,000 + 5,000 + 8,000.

> Part (b) shows that a wrong choice moves profit and the asset by the same amount.

*Part (b), steps.* If the repair were wrongly capitalised, the machine would appear at 330,000 + 8,000 = Tk 338,000, which is Tk 8,000 too high. The expenses of 2026 would be Tk 8,000 too low, so profit would be Tk 8,000 too high. *Answer.* Balance sheet overstated by Tk 8,000; profit overstated by Tk 8,000. *Check.* The two errors are equal, because one payment is placed in the wrong statement.

> The entries record each kind of spending in its proper place.

The correct entries, if both were paid by bank, are these. For the purchase: debit Machinery Tk 330,000 and credit Bank Tk 330,000. For the repair: debit Repairs Expense Tk 8,000 and credit Bank Tk 8,000.

> Common slips: adding after-readiness payments, leaving out freight or installation, and confusing a repair with an improvement.

Three slips are common. The first is to add the repair to the cost because it concerns the machine. The test is timing and purpose, not the name of the asset. The second is to leave out freight or the trial run because they are not on the invoice. The third is to treat a restoring repair as an improvement, or the other way round.

## Summary

> The chapter's ideas in a few lines.

A plant asset is a long-lived physical asset used in running a business. An intangible asset has no physical form but lasts as well. The acquisition cost of a plant asset is all the money spent to buy it and make it ready for use. Capital expenditure creates or improves an asset lasting more than one period; revenue expenditure keeps an asset working and is an expense of the period. Wrong classification changes profit and the balance sheet together.

## Think It Through

:q 15.t1 | Suppose a business wrongly charges the Tk 15,000 installation of the machine as an expense in 2026. What is the effect on 2026 profit and on the balance sheet figure for the machine?
:q 15.t2 | A manager wishes to show a high profit this year. Explain why she might be tempted to capitalise repairs, and why this is dishonest even if it is not noticed at once.

## Where People Go Wrong

> Belief: the cost of an asset is the invoice price.

The cost includes freight, installation, testing and any tax that cannot be recovered. The invoice is only the first part.

> Belief: any payment connected with a machine is part of its cost.

Only payments up to the moment the asset is ready for use are part of the cost. Repairs, training and running costs come later and are expenses.

> Belief: capital expenditure means spending the owner's capital.

The word *capital* in this phrase refers to the lasting nature of the asset that the spending creates. It has no link to the owner's own money.

> Belief: revenue expenditure produces revenue.

Revenue expenditure is an expense that is matched against the revenue of the same period. The name comes from that matching, not from producing revenue.

> Belief: an improvement and a repair are the same thing.

A repair restores the asset to its first condition and is an expense. An improvement raises its life, speed or output and is added to the asset.

## In History

> A famous fraud began with the wrong choice between capital and revenue spending.

In June 2002 the American telephone company WorldCom, one of the largest in the country, told the public that it had wrongly treated a large part of its costs as assets. The costs were line costs, the fees it paid to other companies to carry calls over their networks. On 25 June 2002 it announced that about USD 3.8 billion of such payments, made during 2001 and the first quarter of 2002, had been recorded as assets and not as expenses.

> The case shows why the choice of capital or revenue spending can decide profit or loss.

The effect was large. Reports at the time said that, without the transfers, WorldCom would have shown a loss for 2001 and for the first quarter of 2002. Its internal audit team, led by Cynthia Cooper, traced the entries. The company filed for bankruptcy in July 2002. The lesson is the one you have learned: spending that is used up in the period must be charged to the period, and only spending that creates a lasting asset can be added to the balance sheet.

## Review Questions

:q 15.1 | A shop buys a printing machine. The invoice is Tk 450,000 and a trade discount of Tk 20,000 is allowed. Freight is Tk 8,000, installation Tk 12,000, a trial run Tk 4,000, and operator training Tk 6,000. Find the acquisition cost and the amount treated as an expense.
:q 15.2 | Classify each payment as capital or revenue expenditure: (a) new blades of the same kind, Tk 3,000; (b) a motor that raises output by half, Tk 40,000; (c) a concrete base laid for a new machine, Tk 9,000; (d) the yearly service of a van, Tk 7,500; (e) painting a building before first use, Tk 25,000.
:q 15.3 | A business treats a repair of Tk 12,000 as capital expenditure by mistake. State the effect on profit for the year and on the plant asset on the balance sheet.
:q 15.4 | A van costs Tk 600,000. The business pays Tk 30,000 to bring it from the port and Tk 18,000 to paint its name on it, both before use. In the first year it pays Tk 22,000 for repairs and Tk 9,000 for a licence. Find the acquisition cost, and the total revenue expenditure for the year.

:read Horngren, Harrison and Oliver, Accounting, 2012
