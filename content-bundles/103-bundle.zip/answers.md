:answers 01
:a 1.p1 | It is a merchandising business, because it buys finished goods (rice) and sells them again without changing them.
:a 1.p2 | One quarter, because 25 is one quarter of 100.
:a 1.t1 | Its customers pay for work, so it holds no goods bought for resale. It still records fees, wages, rent and any money owed, and the materials it uses are a cost of the work.
:a 1.t2 | The salon combines a service business (hair work) with a merchandising business (shampoo bought and resold). If shampoo is a small part of its income, the service kind brings in most of its money.
:a 1.t3 | Not in the sense of this chapter, because the club does not supply goods or services to earn a profit. It still needs records of the fees it collects and the money it spends.
:a 1.t4 | It combines manufacturing (bread baked from materials) and merchandising (tea bought and resold). Ownership has the shape of a partnership, with three owners. Any one of the three friends, a lender or the tax authority would need its records.
:a 1.1 | The tailor is a service business, the grocer is a merchandising business, and the furniture workshop is a manufacturing business.
:a 1.2 | Examples: the owner (whether the bakery earns a profit), a lender (whether a loan can be repaid), the tax authority (how much tax is due), and an employee (whether wages will be paid).
:a 1.3 | 410,000 shares × Tk 10 = Tk 4,100,000. One tenth of 410,000 is 41,000 shares.
:a 1.4 | A shareholder is a person who owns one or more shares of a company. A merchandising business buys finished goods and resells them, while a manufacturing business makes goods from materials and then sells them.
:a 1.5 | It is a service business, because it repairs and binds books for schools. Separate records let the owner see the result of each business alone and judge each one fairly.

:answers 02
:a 2.1 | Nurul asks whether the shop earned enough profit (Tk 750,000). The bank asks whether the loan (Tk 600,000) can be repaid. The publishers ask whether the Tk 1,150,000 owed to them will be paid. The tax authority asks whether the profit return is honest. The staff ask whether wages (Tk 2,940,000) and jobs are safe.
:a 2.t1 | A household bill is not a cost of the shop. If it appears in the shop's records, the shop's profit looks too low and the bank forms a false picture of the shop's ability to repay. The business entity rule keeps the two sets of money apart.
:a 2.p1 | The book leaves the shop's inventory, so the shop's records must show that event. The rule says the shop is separate from Nurul, so the shop's goods are not Nurul's to take without a record.
:a 2.p2 | It is bookkeeping, because the clerk only records each payment in the right book. Accounting would also sort the payments and report totals to readers.
:a 2.2 | The weekly book-sales report is management accounting, because it is made for the manager inside the business and follows no outside rule. It is not enough for the bank, which is an external user and needs a formal report that follows written standards.
:a 2.3 | The business entity rule is broken, because family costs are mixed with the business. Anyone who reads her records, such as a lender or a tax authority, is misled about how well the business is doing.
:a 2.4 | The going concern assumption no longer holds, because the shop will not use its shelves for years. The records must then show what the shelves would fetch when sold, instead of the price paid under historical cost.

:answers 03
:a 3.p1 | Owner's equity = 80,000 − 25,000 = Tk 55,000. Check: liabilities plus equity, 25,000 + 55,000 = 80,000, which equals the assets.
:a 3.p2 | Owner's equity = 40,000 + 15,000 − 9,000 − 2,000 = Tk 44,000.
:a 3.t1 | Buying shelving for cash: one asset (shelving) rises by Tk 120,000 and another (cash) falls by Tk 120,000. Total assets are unchanged, so liabilities and owner's equity need no change and the equation stays equal.
:a 3.t2 | She is not right. Paying the publisher lowered cash by Tk 80,000 and lowered the account payable by Tk 80,000. Owner's equity did not change, so no expense arose.
:a 3.1 | (a) asset; (b) liability; (c) asset; (d) liability; (e) owner's equity.
:a 3.2 | Liabilities = 240,000 − 150,000 = Tk 90,000. Check: 90,000 + 150,000 = 240,000.
:a 3.3 | Owner's equity at the end = 300,000 + 410,000 − 365,000 − 50,000 = Tk 295,000.
:a 3.4 | Equity = 1,250 − 480 = 770 thousand, which is Tk 770,000.
:a 3.5 | Assets Tk 252,000 (cash 162,000 and equipment 90,000); liabilities Tk 50,000 (90,000 − 40,000); owner's equity Tk 202,000 (200,000 + 30,000 − 18,000 − 10,000). Check: 50,000 + 202,000 = 252,000.

:answers 04
:a 4.p1 | Debit. Rent is an expense, and expenses increase by debit, so its balance usually falls on the debit side.
:a 4.p2 | Shelving is an asset that increases, so it is debited. Cash is an asset that decreases, so it is credited.
:a 4.t1 | Cash is an asset, and assets stand on the left of the equation A + D + E = L + C + R. Increases of left-side items are recorded on the left, which is the debit side.
:a 4.t2 | Debit Drawings and credit Cash, both for Tk 10,000. Drawings is its own type because the owner's personal use is not a cost of earning revenue, so it is not an expense.
:a 4.1 | Debit Cash 2,000 and credit Owner's Capital 2,000; debit Shelf 500 and credit Cash 500; debit Cash 300 and credit Sales Revenue 300. Cash: debits 2,300 less credits 500 gives a debit balance of Tk 1,800.
:a 4.2 | Debit Inventory (paper) 18,000, credit Accounts Payable 18,000; debit Accounts Payable 7,500, credit Cash 7,500; debit Cash 26,400, credit Service Revenue 26,400; debit Wages 9,200, credit Cash 9,200; debit Drawings 4,000, credit Cash 4,000. Cash: 50,000 + 26,400 − 7,500 − 9,200 − 4,000 = 55,700 debit. Accounts Payable: 18,000 − 7,500 = 10,500 credit.
:a 4.3 | Borrowing: debit Cash 100,000, credit Bank Loan 100,000. Repaying: debit Bank Loan 40,000, credit Cash 40,000. Bank Loan has a credit balance of Tk 60,000.
:a 4.4 | An asset normally has a debit balance, so a credit balance means more cash was recorded as paid out than received, through an error or an overdraft. Check each entry against its source document.
:a 4.5 | Inventory: asset, debit, debit. Accounts Payable: liability, credit, credit. Drawings: drawings, debit, debit. Service Revenue: revenue, credit, credit. Wages: expense, debit, debit.

:answers 05
:a 5.p1 | Debit Electricity (an expense) Tk 10,000 and credit Cash Tk 10,000. Narration: Paid electricity bill in cash.
:a 5.t1 | Publisher Payable would show a credit balance of Tk 200,000 instead of Tk 120,000. The credit balances would then total Tk 740,000 against debit balances of Tk 660,000, so credits would exceed debits by Tk 80,000.
:a 5.1 | Debit Cash 100,000, credit Owner's Equity 100,000 (narration: Owner invested cash). Then debit Shelving 20,000, credit Cash 20,000 (narration: Bought shelving for cash).
:a 5.2 | Cash debit side: 100,000. Cash credit side: 20,000. Balance = 100,000 − 20,000 = Tk 80,000 debit.
:a 5.3 | Debit total = 125,500 + 48,250 = 173,750. Credit total = 30,750 + 61,400 = 92,150. Balance = 173,750 − 92,150 = Tk 81,600, on the debit side.
:a 5.4 | Debit side: 245,000 + 52,000 = 297,000. Credit side: 118,500. Balance = 297,000 − 118,500 = Tk 178,500 debit.
:a 5.5 | Debit Equipment 30,000; credit Cash 10,000; credit Equipment Dealer Payable 20,000. Debits 30,000 equal credits 30,000. Balances: Equipment Tk 30,000 debit; Cash Tk 10,000 credit on these entries alone; Equipment Dealer Payable Tk 20,000 credit.

:answers 06
:a 6.p1 | Every entry has equal debits and credits, and posting copies both sides, so the ledger holds equal totals of debits and credits. Balancing removes the same amount from both totals, so the debit balances still equal the credit balances.
:a 6.t1 | Two examples: the 15 January rent entry left out entirely, which leaves Cash at Tk 305,000 and Rent at nil but both totals at Tk 660,000; and wages debited to Rent instead of Wages, which leaves the totals equal but Rent wrongly at Tk 95,000 and Wages at nil.
:a 6.1 | Debits: 50,000 + 30,000 = Tk 80,000. Credits: Tk 80,000. The totals are equal.
:a 6.2 | Debits: 187,450 + 96,300 + 150,000 + 42,000 + 78,500 = Tk 554,250. Credits: 64,250 + 400,000 + 90,000 = Tk 554,250. The trial balance is balanced.
:a 6.3 | Difference = 465,500 − 458,900 = Tk 6,600, with credits larger. 6,600 ÷ 9 is not a whole number, so a transposition is unlikely. Half is Tk 3,300, which suggests a debit balance of Tk 3,300 listed in the Credit column.
:a 6.4 | The debits fall short by Tk 7,200, so a suspense account with a debit balance of Tk 7,200 is added in the Debit column.
:a 6.5 | Difference = 81,000 − 18,000 = Tk 63,000, with debits larger (63,000 ÷ 9 = 7,000). The credits are short, so the suspense balance of Tk 63,000 goes on the credit side. Correcting entry: debit Suspense 63,000, credit Rent 63,000. Narration: Corrected rent posted as 81,000 instead of 18,000, and cleared the suspense account.

:answers 07
:a 7.p1 | Monthly rent = 24,000 ÷ 12 = Tk 2,000. November and December are two months, so Tk 4,000 belongs to the year. The matching principle (with the accrual basis) decides it: the cost is placed in the period in which it is used.
:a 7.p2 | The Tk 6,500 owed to workers is an accrued expense, a liability. The Tk 11,000 of unbilled work is accrued revenue, an asset.
:a 7.t1 | The records would show a profit of Tk 280,000 instead of Tk 184,000, which is Tk 96,000 too high. The owner might withdraw too much, and a lender or tax authority would judge the business on a wrong figure. Assets would also be overstated and liabilities understated.
:a 7.t2 | The Tk 36,000 was paid in cash on 1 October. The adjustment on 31 December only moves the used part, Tk 9,000, from the asset Prepaid Insurance to the expense Insurance Expense. No money moves on that date.
:a 7.1 | 6,000 ÷ 6 = Tk 1,000 a month. March to June is 4 months, so the expense is Tk 4,000 and the prepaid expense is 6,000 − 4,000 = Tk 2,000.
:a 7.2 | Supplies expense = 52,500 − 18,200 = Tk 34,300. Entry: debit Supplies Expense 34,300; credit Supplies 34,300.
:a 7.3 | 18,000 ÷ 6 = Tk 3,000 a month. November and December are 2 months, so revenue earned is Tk 6,000 and unearned revenue is 18,000 − 6,000 = Tk 12,000.
:a 7.4 | Depreciation = 240,000 ÷ 8 = Tk 30,000: debit Depreciation Expense, credit Accumulated Depreciation. Wages: debit Wages 9,000, credit Wages Payable 9,000. Unbilled work: debit Accounts Receivable 15,000, credit Service Revenue 15,000. Expenses rise by 39,000 and revenue by 15,000, so profit falls by Tk 24,000.

:answers 08
:a 8.p1 | Tk 400, a debit: the debit of Tk 1,000 less the credit of Tk 600 leaves a debit of Tk 400.
:a 8.p2 | The debit side, because revenue (Tk 6,000) exceeds expenses (Tk 3,400), so the debit column is short by Tk 2,600 and the balancing figure makes the two totals equal.
:a 8.t1 | The credit total is Tk 8,500 + Tk 2,600 = Tk 11,100, so the difference is Tk 300 (debit larger). Wages Payable is Tk 300, so check first whether that balance was extended to the balance sheet credit column.
:a 8.t2 | The difference is Tk 270, and 270 ÷ 9 = 30, so it is divisible by 9. This suggests a transposition error. Wages of Tk 2,300 written as Tk 2,030 would give exactly this shortfall.
:a 8.1 | Adjusted balances: Cash 3,000; Prepaid Insurance 900; Wages 3,000; Insurance Expense 300 (debits, total 7,200); Capital 3,200; Fees Revenue 4,000 (credits, total 7,200). Income columns: debit 3,300, credit 4,000, so net income is Tk 700. Balance sheet: debit 3,900; credit 3,200 + 700 = 3,900.
:a 8.2 | Adjustments: Supplies Expense 2,700 (Supplies 4,200 less 1,500 on hand); Wages 1,300 with Wages Payable 1,300; Depreciation Expense 4,800 with Accumulated Depreciation 4,800. Adjusted totals are 131,100 each side. Expenses: 18,500 + 4,800 + 2,000 + 2,700 + 4,800 = 32,800. Net income = 61,400 - 32,800 = Tk 28,600. Balance sheet columns: debit 98,300; credit 69,700 + 28,600 = 98,300.
:a 8.3 | Net loss of 3,500 thousand (21,500 - 18,000). It is entered in the credit column of the income pair (18,000 + 3,500 = 21,500) and the debit column of the balance sheet pair (40,000 + 3,500 = 43,500). In full taka, the net loss is Tk 3,500,000.
:a 8.4 | Adjusted balances: Cash 9,000; Equipment 12,000; Prepaid Insurance 900; Wages 3,400; Insurance Expense 900; Depreciation Expense 1,200 (debits, total 27,400); Accumulated Depreciation 1,200; Wages Payable 400; Unearned Revenue 900; Capital 17,400; Fees Revenue 7,500 (credits, total 27,400). Expenses 5,500; net income = 7,500 - 5,500 = Tk 2,000. Balance sheet: debit 21,900; credit 19,900 + 2,000 = 21,900.
:a 8.5 | A worksheet gathers all balances on one page, tests the adjustments before they are recorded, and checks the arithmetic with equal totals. It changes no account because it is working paper; the ledger changes only when the adjusting entries are journalised and posted.

:answers 09
:a 9.p1 | A credit of Tk 300: credit Tk 800 less debit Tk 500. This balance is the net income.
:a 9.t1 | Tk 788,000 + Tk 900,000 = Tk 1,688,000. The figure mixes two years, so the 2027 income statement would overstate revenue by Tk 788,000.
:a 9.t2 | The balance sheet needs ending capital. Ending capital comes from the statement of owner's equity (starting capital plus net income minus drawings), so that statement must come first.
:a 9.1 | Income statement: what did the business earn? Statement of owner's equity: how did capital change? Balance sheet: what does the business own and owe on one date? The first two headings end *For the year ended …*; the balance sheet heading ends *At …*.
:a 9.2 | Net income is Tk 12,000 − Tk 7,000 = Tk 5,000. Ending capital is Tk 10,000 + Tk 5,000 − Tk 1,000 = Tk 14,000. Assets are Tk 6,000 + Tk 2,000 + Tk 9,000 = Tk 17,000; liabilities Tk 3,000 plus capital Tk 14,000 also give Tk 17,000.
:a 9.3 | Step 1: debit Revenue 12,000, credit Income Summary 12,000. Step 2: debit Income Summary 7,000, credit Expenses 7,000. Step 3: debit Income Summary 5,000, credit Owner's Capital 5,000. Step 4: debit Owner's Capital 1,000, credit Drawings 1,000.
:a 9.4 | Temporary: Revenue, Wages Expense, Drawings. Permanent: Prepaid Insurance, Wages Payable, Owner's Capital.
:a 9.5 | 1 January 2027: debit Wages Payable 6,000, credit Wages Expense 6,000. 4 January 2027: debit Wages Expense 8,000, credit Cash 8,000. Wages expense of 2027 is Tk 8,000 − Tk 6,000 = Tk 2,000.
:a 9.6 | The net loss is Tk 11,000 − Tk 9,000 = Tk 2,000, so Income Summary has a debit balance. Step 3: debit Owner's Capital 2,000, credit Income Summary 2,000. Capital falls by Tk 2,000.

:answers 10
:a 10.p1 | Tk 500 + Tk 2,000 − Tk 700 = Tk 1,800.
:a 10.p2 | Tk 22,500, the first instalment, because it falls due within one year. The other Tk 67,500 is non-current.
:a 10.t1 | The two mistakes are equal and opposite on the same side, so total debits still equal total credits. Example: Wages debited Tk 300 too much and Rent debited Tk 300 too little.
:a 10.t2 | Cost of goods sold is Tk 2,000 too large, gross profit is Tk 2,000 too small, and inventory is missing from current assets, so the balance sheet understates assets.
:a 10.1 | Tk 5,000 − Tk 300 − Tk 100 = Tk 4,600.
:a 10.2 | Net sales Tk 78,000. Cost of goods sold = 12,000 + 50,000 − 1,000 − 14,000 = Tk 47,000. Gross profit Tk 31,000. Operating expenses 6,000 + 7,000 = Tk 13,000. Profit Tk 18,000.
:a 10.3 | Current assets Tk 22,000 (3,000 + 4,000 + 14,000 + 1,000); equipment Tk 20,000; total assets Tk 42,000. Current liabilities Tk 7,000 (5,000 + 2,000); long-term loan Tk 10,000; owner's equity Tk 25,000; total Tk 42,000.
:a 10.4 | (a) omission; (b) principle; (c) commission; (d) compensating error.
:a 10.5 | (b) Debit Vehicles Tk 40,000; credit Repairs Expense Tk 40,000. (c) Debit Electricity Expense Tk 700; credit Telephone Expense Tk 700.
:a 10.6 | Inventory: current asset. Shop fittings: non-current asset. Accounts payable: current liability. Loan due in four years: non-current liability. Loan due in six months: current liability.

:answers 11
:a 11.p1 | The subsidiary ledger holds the balance of one named customer. The accounts receivable control account holds the total owed by all customers together.
:a 11.t1 | Five credit sales make five entries and ten postings, so a special journal saves very little. The answer changes when credit sales become many, for example dozens each month, or when more than one clerk must write at the same time.
:a 11.t2 | Every sale is posted twice to the control account, so it is too high by the total of the lines. The customer accounts are correct, so the two totals disagree by exactly the amount posted twice, and the test reveals the slip.
:a 11.t3 | The agreement test reveals it. The control account, posted from the wrong total, is Tk 1,800 lower than the sum of the customer accounts, since Tk 54,200 - Tk 52,400 = Tk 1,800.
:a 11.1 | Lines of Tk 100, Tk 200 and Tk 300 give a total of Tk 600. Debit the accounts receivable account Tk 600 and credit Sales Tk 600, each posted once.
:a 11.2 | Total: Tk 42,500 + Tk 18,750 + Tk 31,200 = Tk 92,450. Closing balance: Tk 150,000 + Tk 92,450 = Tk 242,450. Both Greenfield School lines go to one customer account.
:a 11.3 | They do not agree. The control account should be Tk 310,000 + Tk 126,400 = Tk 436,400. The customer accounts total Tk 426,400. The difference is Tk 10,000, which suggests a posting is missing or wrong.
:a 11.4 | Total: Tk 36,000 + Tk 54,500 + Tk 29,500 = Tk 120,000. Debit Purchases Tk 120,000 and credit the accounts payable control account Tk 120,000. Closing balance: Tk 200,000 + Tk 120,000 = Tk 320,000.

:answers 12
:a 12.p1 | A difference of Tk 1,000 means an item is missing, wrongly placed or wrongly added. Tick the items again and check the arithmetic; make no entry until the two adjusted balances agree.
:a 12.t1 | Entries are needed for the service charge (Tk 1,500), the dishonoured cheque (Tk 8,000), the interest (Tk 2,500) and the school payment (Tk 40,000), because the bank recorded them first. No entry is needed for the deposit in transit or the two cheques, because the business recorded them first and the bank will catch up.
:a 12.t2 | The business should contact the payee to learn why the cheque has not been presented, because rules on old cheques differ between banks and countries. Until it clears, the cheque stays on the reconciliation as an outstanding cheque and is subtracted on the bank side each month.
:a 12.1 | Bank side: 3,400 + 700 − 300 = 3,800. Book side: 3,000 + 900 − 100 = 3,800. The adjusted balance is Tk 3,800 on both sides.
:a 12.2 | Bank side: 91,250 + 12,000 + 6,500 − 9,800 − 4,150 = 95,800. Book side: 95,050 + 5,000 − 750 − 3,500 = 95,800. The adjusted balance is Tk 95,800.
:a 12.3 | The cash book is higher by Tk 1,750 before adjusting. Bank side: 18,400 + 5,000 − 3,200 − 1,100 = 19,100. Book side: 20,150 − 250 − 800 = 19,100. The adjusted balance is Tk 19,100.
:a 12.4 | Bank side: 47,000 + 4,000 − 9,000 = 42,000. Book side: 40,000 + 3,000 + 500 − 1,500 = 42,000. Entries: debit Bank, credit Account Receivable Tk 3,000; debit Bank, credit Interest Revenue Tk 500; debit Bank Charges, credit Bank Tk 1,500. Bank on the balance sheet is Tk 42,000.

:answers 13
:a 13.p1 | It will be hidden. A periodic system calculates cost of goods sold by subtraction, so the cost of the 3 stolen books is included in cost of goods sold with no separate sign.
:a 13.t1 | The extra holding cost is 380,000 × 10% = Tk 38,000. The shop may also face a write-down if the titles can only be sold for less than their cost.
:a 13.t2 | Two possible costs: lost sales when demand rises or a delivery is late, and the loss of customers who do not return. More frequent orders may also raise transport costs and remove bulk-buying discounts.
:a 13.1 | (a) raw materials; (b) work in process; (c) not inventory, because it is not held for sale; (d) finished goods; (e) not inventory, because the shop does not own it.
:a 13.2 | Net realisable value = 500 − 90 = Tk 410 a copy. Cost is Tk 450, so each copy is written down by 450 − 410 = Tk 40. For 200 copies the write-down is Tk 8,000.
:a 13.3 | Cost of goods sold = 40,000 + 65,000 − 30,000 = Tk 75,000.
:a 13.4 | The difference is 500 − 470 = 30 units, and 30 × 60 = Tk 1,800. The shop should first investigate the cause. If none is found, it reduces Inventory to the counted figure and charges Tk 1,800 as a loss.
:a 13.5 | Holding cost is 600,000 × 12% = Tk 72,000 a year. The write-down per unit is 80 − 55 = Tk 25, so for 150 units it is Tk 3,750. The units are reported at 150 × 55 = Tk 8,250.

:answers 14
:a 14.p1 | The oldest 60 units are 20 at Tk 300, 30 at Tk 320 and 10 at Tk 340, so the cost of goods sold is Tk 6,000 + Tk 9,600 + Tk 3,400 = Tk 19,000. The 40 units left are 40 × Tk 340 = Tk 13,600. Tk 19,000 + Tk 13,600 = Tk 32,600.
:a 14.p2 | The unit cost is Tk 326, so 25 sets cost 25 × Tk 326 = Tk 8,150.
:a 14.t1 | FIFO is highest at Tk 12,600, weighted average is next at Tk 12,180, and LIFO is lowest at Tk 11,600 in the case. When prices rise, FIFO charges the oldest, cheapest costs to the sale and LIFO charges the newest, dearest costs. Weighted average lies between them.
:a 14.t2 | The ranking reverses: LIFO gives the highest gross profit, FIFO the lowest, and weighted average lies between. For all three methods, cost of goods sold plus ending inventory equals the cost available.
:a 14.1 | Cost available is Tk 100 + Tk 120 = Tk 220. FIFO: ending Tk 120, cost of goods sold Tk 100, gross profit Tk 100. LIFO: ending Tk 100, cost of goods sold Tk 120, gross profit Tk 80. Weighted average: unit cost Tk 11, ending Tk 110, cost of goods sold Tk 110, gross profit Tk 90.
:a 14.2 | Cost available is Tk 1,800 + Tk 2,880 + Tk 5,200 = Tk 9,880 for 200 units; 70 remain. FIFO: ending Tk 3,640, cost of goods sold Tk 6,240, gross profit Tk 4,160. LIFO: ending Tk 3,240, cost of goods sold Tk 6,640, gross profit Tk 3,760. Weighted average: unit cost Tk 49.40, ending Tk 3,458, cost of goods sold Tk 6,422, gross profit Tk 3,978. Each pair adds to Tk 9,880.
:a 14.3 | Cost available is Tk 2,000 + Tk 1,750 = Tk 3,750 for 50 boxes; 20 remain. FIFO: ending Tk 1,400, cost of goods sold Tk 2,350, gross profit Tk 650. LIFO: ending Tk 1,600, cost of goods sold Tk 2,150, gross profit Tk 850. Weighted average: unit cost Tk 75, ending Tk 1,500, cost of goods sold Tk 2,250, gross profit Tk 750. LIFO gives the highest profit because prices fall.
:a 14.4 | FIFO: 4,160 ÷ 10,400 = 40.0%. LIFO: 3,760 ÷ 10,400 = 36.2%. Weighted average: 3,978 ÷ 10,400 = 38.3%. FIFO gives the highest ending inventory, Tk 3,640, because prices rise and FIFO leaves the newest, dearest costs in inventory.

:answers 15
:a 15.p1 | The van price of Tk 900,000 and the painting of Tk 12,000, which is needed before use, belong in the cost. The road licence of Tk 20,000 is a cost of using the van during the first year, so it is an expense, not part of the cost.
:a 15.t1 | Profit for 2026 would be Tk 15,000 too low, and the machine on the balance sheet would be Tk 15,000 too low at Tk 315,000 instead of Tk 330,000.
:a 15.t2 | Capitalising a repair removes it from expenses, so profit rises and the asset grows. This is dishonest because the repair does not create a lasting asset, so the profit and the balance sheet both give a false picture, even if the entry is not noticed at first.
:a 15.1 | Acquisition cost = 450,000 − 20,000 + 8,000 + 12,000 + 4,000 = Tk 454,000. The training of Tk 6,000 is an expense.
:a 15.2 | (a) revenue; (b) capital; (c) capital; (d) revenue; (e) capital, because it is done before first use.
:a 15.3 | Profit is Tk 12,000 too high and the plant asset is Tk 12,000 too high on the balance sheet.
:a 15.4 | Acquisition cost = 600,000 + 30,000 + 18,000 = Tk 648,000. Revenue expenditure for the year = 22,000 + 9,000 = Tk 31,000.

:answers 16
:a 16.p1 | (Tk 120,000 − Tk 20,000) ÷ 4 = Tk 25,000 a year.
:a 16.p2 | Year 1: 25% × Tk 80,000 = Tk 20,000, leaving Tk 60,000. Year 2: 25% × Tk 60,000 = Tk 15,000, leaving Tk 45,000.
:a 16.t1 | The yearly charge falls from Tk 60,000 to (Tk 330,000 − Tk 30,000) ÷ 8 = Tk 37,500, so each year's profit rises by Tk 22,500. The total charged over the whole life is unchanged at Tk 300,000, because only the timing changes.
:a 16.t2 | Depreciation is an allocation of cost, not a transfer of cash. The cash was paid on the day of purchase, and the yearly entry moves no cash. Saving for a new machine is a separate decision about cash.
:a 16.1 | Charge: (Tk 50,000 − Tk 10,000) ÷ 4 = Tk 10,000 a year. After two years the accumulated depreciation is Tk 20,000, so the book value is Tk 30,000.
:a 16.2 | Straight-line: (Tk 275,000 − Tk 25,000) ÷ 8 = Tk 31,250 a year; for 3 months, Tk 31,250 × 3 ÷ 12 = Tk 7,812.50. Units-of-production: Tk 250,000 ÷ 400,000 = Tk 0.625 a unit; 36,000 × Tk 0.625 = Tk 22,500.
:a 16.3 | Year 1: Tk 30,000, remaining Tk 120,000. Year 2: Tk 24,000, remaining Tk 96,000. Year 3: Tk 19,200, remaining Tk 76,800. Gain = Tk 80,000 − Tk 76,800 = Tk 3,200.
:a 16.4 | Yearly charge: (Tk 240,000 − Tk 40,000) ÷ 5 = Tk 40,000. Entry for 2026: debit depreciation expense Tk 40,000, credit accumulated depreciation Tk 40,000. After three years the accumulated depreciation is Tk 120,000 and the book value is Tk 120,000, so the sale gives a loss of Tk 20,000. Sale entry: debit cash Tk 100,000, debit accumulated depreciation Tk 120,000, debit loss on sale Tk 20,000; credit press at cost Tk 240,000.

:answers 17
:a 17.p1 | No. The money is for a later year, so it belongs to the period that it pays for. It is received early and is shown as a liability, fees paid in advance, until that period begins.
:a 17.t1 | Cash can rise because of money not charged against the year, such as a loan or the sale of an asset, or because the club bought no lasting assets. A deficit arises when expenditure on the accrual basis, including amounts owed but unpaid, exceeds income that belongs to the year, such as when many fees are still owed.
:a 17.t2 | Profit = 46,000 − 50,000 + 9,000 − 0 = Tk 5,000. The equity fell by Tk 4,000 only because she withdrew Tk 9,000, so the business was profitable.
:a 17.1 | Receipts: 6,000 + 40,000 + 3,000 = Tk 49,000. Payments: 15,000 + 12,000 + 8,000 = Tk 35,000. Closing cash = 49,000 − 35,000 = Tk 14,000.
:a 17.2 | Subscriptions = 40,000 − 2,000 − 1,500 + 3,500 = Tk 40,000. Wages = 12,000 + 1,000 = Tk 13,000. Income = 40,000 + 3,000 = 43,000. Expenditure = rent 15,000 + wages 13,000 = 28,000. Surplus = Tk 15,000. The cupboard is an asset, not an expense.
:a 17.3 | Opening owner's equity = 60,000 − 15,000 = 45,000. Closing = 72,000 − 18,000 = 54,000. Profit = 54,000 − 45,000 + 20,000 − 8,000 = Tk 21,000.
:a 17.4 | In the receipts and payments account the Tk 30,000 is a payment. In the income and expenditure account it does not appear as expenditure, because it is a lasting asset. In the balance sheet it appears as an asset at its cost.

:answers 18
:a 18.p1 | Interest for a year is 200,000 × 5% = Tk 10,000. For six months, 10,000 × 6 ÷ 12 = Tk 5,000.
:a 18.t1 | His share of the remainder does not change, because the ratio stays 5:3:2 and he still receives two parts in ten. His interest rises by 400,000 × 6% = Tk 24,000 a year, so his total grows through the first layer only.
:a 18.t2 | Outsiders such as suppliers and banks are paid first, from all the cash available. If the cash cannot cover the debts, nothing is left for the partners, whose capital is used up by the loss.
:a 18.1 | Four parts in all. The first partner receives (3 ÷ 4) × 80,000 = Tk 60,000 and the second receives (1 ÷ 4) × 80,000 = Tk 20,000. Check: 60,000 + 20,000 = 80,000.
:a 18.2 | Interest: Mira 450,000 × 8% = 36,000; Naveed 300,000 × 8% = 24,000; total 60,000. Remainder 211,000 − 60,000 = 151,000. Shares: Mira (3 ÷ 5) × 151,000 = 90,600; Naveed (2 ÷ 5) × 151,000 = 60,400. Totals: Mira Tk 126,600 and Naveed Tk 84,400, which add to 211,000.
:a 18.3 | Time is 9 ÷ 12 = 0.75 year. Interest: Mira 450,000 × 8% × 0.75 = 27,000; Naveed 300,000 × 8% × 0.75 = 18,000; total 45,000. Remainder 180,000 − 45,000 = 135,000. Shares: Mira 81,000; Naveed 54,000. Totals: Mira Tk 108,000 and Naveed Tk 72,000, which add to 180,000.
:a 18.4 | Debit Bank Tk 300,000 and credit Priya, Capital Tk 300,000, dated 1 April 2028, with a narration that the amount was paid in by the new partner on admission. Debits equal credits.
:a 18.5 | Loss = 850,000 − 700,000 = Tk 150,000. Shares: P (2 ÷ 3) × 150,000 = Tk 100,000; Q (1 ÷ 3) × 150,000 = Tk 50,000. Payments: P 400,000 − 100,000 = Tk 300,000; Q 200,000 − 50,000 = Tk 150,000. Check: cash after debts is 700,000 − 250,000 = 450,000, which equals 300,000 + 150,000.

:answers 19
:a 19.p1 | The premium on each share is 18 − 10 = Tk 8. On 1,000 shares the total premium is 1,000 × 8 = Tk 8,000.
:a 19.t1 | The company could allot shares to every applicant in proportion, for example 2 shares for every 3 applied for, or accept some applications in full and refuse the rest. Money for shares not allotted must be returned to the applicant, or used for the later amount due if the applicant agrees.
:a 19.t2 | The business may already be worth more than the face value of its shares, because of its name, its customers and the profit it has kept. Buyers pay the extra Tk 30 for a share of that value, and the company records it as share premium.
:a 19.1 | Application: debit Bank 10,000; credit Share Application 10,000. Allotment: debit Share Application 10,000; credit Share Capital 10,000. There is no premium, because the issue price equals the face value.
:a 19.2 | Share capital = 50,000 × 10 = Tk 500,000. Share premium = 50,000 × 6 = Tk 300,000. Application: debit Bank 400,000; credit Share Application 400,000. Allotment: debit Share Application 400,000 and Bank 400,000; credit Share Capital 500,000 and Share Premium 300,000. Check: 500,000 + 300,000 = 800,000 = 400,000 + 400,000.
:a 19.3 | Shares authorised = 2,000,000 ÷ 5 = 400,000. Issued capital = 120,000 × 5 = Tk 600,000. Shares still unissued = 400,000 − 120,000 = 280,000, worth Tk 1,400,000.
:a 19.4 | Total shares = 750,000 ÷ 10 = 75,000. Mira receives 450,000 ÷ 10 = 45,000 shares and Naveed receives 300,000 ÷ 10 = 30,000 shares. Entry: debit Net assets taken over 750,000; credit Share Capital 750,000.

:answers 20
:a 20.p1 | Freight in (Tk 40,000) is a product cost, because it is part of bringing goods to the shop. Rent (Tk 180,000) is a period cost, because it belongs to the time the building is used.
:a 20.p2 | Cash, an asset, falls by Tk 5,000, and accounts payable, a liability, falls by Tk 5,000. Both sides fall by the same amount, so the balance sheet still balances.
:a 20.t1 | Two changes: every report would cover 1 July to 30 June, and the quarters would end on 30 September, 31 December, 31 March and 30 June, so the quarter ended 30 September 2026 would become a first quarter. Moving from a December year-end also needs a bridging period of six months, 1 January to 30 June. The accounts, the debit and credit rules and the split between product costs and period costs stay the same.
:a 20.t2 | A year ending when trade is quiet, such as soon after the term-start rush, is a good choice. Inventory is low and easy to count then, and the whole busy season falls inside one year.
:a 20.1 | Product costs: books bought and freight in. Period costs: shop rent, wages of the shop assistants and delivery to a customer (freight out).
:a 20.2 | Gross profit is Tk 600,000 − Tk 380,000 = Tk 220,000. Profit is Tk 220,000 − Tk 150,000 = Tk 70,000.
:a 20.3 | The order is: journal, posting to the ledger, trial balance, adjusting entries, adjusted trial balance, the three statements, closing entries, post-closing trial balance. The adjusting entries and the closing entries change account balances.
:a 20.4 | An account payable is an amount the business owes, and it appears among the liabilities. An account receivable is an amount owed to the business, and it appears among the assets.
:a 20.5 | The second quarter runs from 1 July to 30 September. The second quarter is an interim period; the year is the fiscal year, and the cycle is a set of steps and not a period of time.
