:chapter XII | The Cash Book and Bank Reconciliation
:mood Two honest records of one account, and two different totals. Which one is right?
:desc This chapter shows how a business records its cash and bank money in a cash book, and why its bank balance rarely matches the figure the bank reports. You learn the common reasons for a difference and how to prepare a bank reconciliation statement that explains every taka of it. You also learn which differences need a journal entry afterwards.
:plate ch12-plate.svg | A bank counter in the age of ink and ledgers

> A small puzzle: two careful people record the same money and reach different totals.

Imagine that you keep a small notebook for your savings account. Every time you put money in, you write the amount. Every time you take money out, you write that too. At the end of the month you add everything up and your notebook says Tk 5,000. Then the bank sends you its own list of what happened in the account. Its final figure is Tk 5,700. The difference is Tk 700.

> Neither person is careless, so the difference needs an explanation, not a search for blame.

Who is wrong? Perhaps the bank made a mistake. Perhaps you did. Many students expect this answer, and it is usually false. In most months both records are correct. They differ because the bank and you learn about each event at different times, and because some events reach one record before the other. Your task is not to decide which record is right. Your task is to explain, item by item, how one total becomes the other. If you can do that, you have proved that both records are sound, and you have found the true balance as well.

> The same difference appears in the running case, and the chapter will explain all of it.

:case Case file, illustrative. On 31 October 2026 the cash book of Meghna and Sons showed a bank balance of Tk 612,000. The bank statement for the same date showed a balance of Tk 655,000. The difference is Tk 43,000. The case file lists seven items that explain this difference; by the end of the chapter each one has a place.

:box YOU WILL NEED
This chapter uses the idea of a special journal from Chapter 11 'Special Journals', section 11.1 'Why Special Journals'. It also uses the ledger and posting from Chapter 5 'The Journal and the Ledger', section 5.3 'The Ledger and Posting'. The arithmetic is addition, subtraction and checking two totals against each other; Appendix A1 'Maths You Will Use' holds a short reference.

* * *

## 12.1 The Cash Book

> Every business receives and pays money in two ways, and it needs one book that records both.

A business handles money in two places. Some money is in the drawer: notes and coins from customers, kept for small payments. The rest is in the bank account: cheques deposited, transfers received, and payments made by cheque. Think of your own purse and your own bank card. You know the amount in each, and you add them to know what you have. A business needs the same habit, kept with more care. It records both kinds of money in one book.

> The cash book is the first record and the ledger account for cash and bank, in one place.
> Recall: journal, Chapter 5 'The Journal and the Ledger', section 5.3 'The Ledger and Posting'.
@ Cash book | A book that serves as both journal and ledger for cash and bank receipts and payments.

This book is called the **cash book**. A cash book is a book that serves as both journal and ledger for cash and bank receipts and payments. For example, when a customer pays Tk 500 in notes, you write the amount once in the cash book. Many students find this confusing, because they have learned that a journal and a ledger are two different books. Usually an entry is written in the journal first and posted to the ledger afterwards, which is two steps. For cash and bank, the cash book joins the two steps into one. This saves work, because a cash book is also the ledger account for Cash and the ledger account for Bank.

> The other half of every cash book entry still has to reach its own ledger account.

The cash book does not finish the job alone. Every transaction has two sides. If a customer pays Tk 500 in notes for books, the cash book records the money received. The sale itself must still reach the ledger account for sales. Likewise, if the customer was paying an account receivable, that account must be reduced. We call this the other side of the entry. The cash book holds one side, and posting carries the other side to the ledger.

> The page is divided into receipts on the left and payments on the right, with a column for each kind of money.

A cash book page looks like a ledger account with two sides. The left side is the debit side and holds money received. The right side is the credit side and holds money paid. Each side is split into columns. A cash book with a Cash column and a Bank column on each side is called a two-column cash book. The Cash column follows the notes and coins in the drawer. The Bank column follows the money in the bank account. The table below shows four small entries and where each one is placed. Read each row from left to right: the event, the side, the column, and the reason.

:table Four entries in a two-column cash book
| Event | Side | Column | Reason |
| --- | --- | --- | --- |
| Customer pays Tk 500 in notes | Debit | Cash | Money received into the drawer |
| Customer's cheque for Tk 2,000 deposited | Debit | Bank | Money received into the bank account |
| Rent of Tk 1,000 paid by cheque | Credit | Bank | Money paid out of the bank account |
| Tk 300 of notes paid for postage | Credit | Cash | Money paid out of the drawer |

> One kind of entry moves money between the two columns and needs no other ledger account.

Sometimes the owner moves money between the drawer and the bank. Suppose the owner takes Tk 3,000 in notes from the drawer and deposits it. The Bank column receives money, so it is debited. The Cash column loses money, so it is credited. Both halves are in the same book. We call this a contra entry. The word *contra* is Latin for "against": the two halves face each other across the page. A contra entry has an important feature. It does not touch any other ledger account, because both sides are already in the cash book.

> Totalling a column gives its balance, and the Bank column balance is the figure we shall later compare with the bank.

At the end of each period you total each column. On the debit side the total shows all money received. On the credit side the total shows all money paid. The difference is the balance. The Cash column balance should equal the notes and coins in the drawer. The Bank column balance is what the books say is in the bank. The bank reports its own figure, and the rest of this chapter compares the two. For the owner, this balance answers a daily question: how much can we spend today?

> Before moving on, we recall the three ideas of this section.

*Before moving on.* The cash book is a journal and a ledger in one. Its two sides hold receipts and payments, and its columns separate cash from bank. A contra entry moves money between the two columns and touches no other account. You should now be able to say where each of four events is written in a cash book.

## 12.2 Why Bank and Book Differ

> The bank keeps a second record of the same account, so two records must be compared.
@ Statement | Word in use. In daily life, something said or written, such as a statement to a newspaper. In banking, the list of an account's receipts, payments and balance that the bank sends to its customer.

The bank account has two keepers. The business keeps the Bank column of its cash book. The bank keeps its own record of the same account and sends the business a statement from time to time.

> A bank statement is a list of the account's movements, not a claim that someone has made.

A bank statement lists each receipt and payment the bank has recorded, with a balance after each. It is a source document, because it is written evidence that an event took place. It is also the bank's version of the account, so it is the natural thing to compare with the cash book.

> The principle: a difference arises only when one record learns of an event before the other.

Here is the principle that explains every difference. Each event in the account is recorded by two parties. If both record it in the same period, the records agree. If one records it earlier, the records differ until the other catches up. We can therefore sort the differences into two groups. In the first group, the business has recorded the event and the bank has not yet done so. The bank will catch up without any action from us, so no entry is needed in our books. In the second group, the bank has recorded the event and the business has not. The business must make an entry to catch up. Keep these two groups in mind, because they decide what we do with each item.

> A deposit in transit is a receipt the business has recorded but the bank has not.
@ Deposit in transit | Money recorded as deposited in the books but not yet shown on the bank statement.

The first item in group one is the **deposit in transit**. A deposit in transit is money recorded as deposited in the books but not yet shown on the bank statement. For example, a shop banks Tk 400 after the bank has closed on the last day of the month. The shop records the receipt at once. The bank records it on the next working day. The statement therefore omits it, and the bank balance looks lower than the cash book balance by Tk 400.

> An outstanding cheque is a payment the business has recorded but the bank has not yet paid.
@ Outstanding cheque | A cheque written and recorded but not yet paid by the bank.
@ Clear | Word in use. In daily life, easy to understand or free of obstacles. In banking, a cheque clears when the bank has paid it and moved the money out of the writer's account.

The second item in group one is the **outstanding cheque**. An outstanding cheque is a cheque written and recorded but not yet paid by the bank. For example, you write a cheque for Tk 900 to a supplier and record the payment the same day. The supplier needs a few days to deposit it, and the banks need more days to clear it. Until it clears, the bank statement still shows the money in your account, so the bank balance looks higher than the cash book balance by Tk 900.

> A credit memo is the bank telling the business that it added money to the account.
@ Credit memo | A bank's notice that it has added money to the account, for example a collection or interest.

Now we move to group two, the events that the bank records first. The first is the **credit memo**. A credit memo is a bank's notice that it has added money to the account, for example a collection or interest. Suppose the bank collects a Tk 300 payment on the business's behalf, or pays Tk 300 of interest. The bank adds the money and informs the business with a credit memo. Why is it called a credit? The bank looks at the account from its own side. The money in your account is money the bank owes you, a liability of the bank. When the bank owes you more, it records a credit. For you, the memo increases the balance.

> A debit memo is the bank telling the business that it took money out of the account.
@ Debit memo | A bank's notice that it has deducted money, for example a service charge.

The opposite item is the **debit memo**. A debit memo is a bank's notice that it has deducted money, for example a service charge. Suppose the bank charges Tk 100 for running the account. It deducts the money and sends a debit memo. The bank owes you less, so it records a debit. For you, the memo decreases the balance. Remember the pairing: a credit memo adds to your balance and a debit memo subtracts from it. The names follow the bank's books, not yours. This is a common source of confusion, so check each memo against that rule.

> A dishonoured cheque is a cheque the bank would not pay, so money recorded as received has gone.
@ Dishonoured cheque | A cheque that the bank refuses to pay, usually because the writer's account lacks funds.

The last item is the **dishonoured cheque**. A dishonoured cheque is a cheque that the bank refuses to pay, usually because the writer's account lacks funds. Suppose a customer pays you with a cheque for Tk 800, and you deposit it and record the receipt. Later the customer's bank refuses to pay, so your bank takes the Tk 800 back out of your account. Your cash book still shows the money, so it is Tk 800 too high. The customer also owes you again, so the account receivable is restored. The legal results of a dishonoured cheque differ from country to country, so a business must check the law that applies where it trades.

> Payments made straight into or out of the bank account are also learned from the statement.

One more situation fits group two. A customer may pay the bank account directly by transfer, with no cheque and no visit. The bank records the receipt at once. The business learns of it only from the statement. The same can happen for a payment out, such as a standing order to pay a bill. We treat a direct receipt like a credit memo and a direct payment like a debit memo.

> A table sorts the items by who records first and whether an entry is needed.

The table below gathers the items. Read each row as a question: who records the event first, and what must the business do? The two items at the top need no entry, because the bank will catch up. The four at the bottom need an entry in the cash book.

:table Why the bank statement and the cash book differ
| Item | Recorded first by | Is an entry needed in our books? |
| --- | --- | --- |
| Deposit in transit | Business | No; the bank catches up |
| Outstanding cheque | Business | No; the bank catches up |
| Credit memo, or direct receipt | Bank | Yes; we add to the cash book |
| Debit memo, or direct payment | Bank | Yes; we subtract from the cash book |
| Dishonoured cheque | Bank | Yes; we subtract and restore the account receivable |

> The case file lists seven items at 31 October 2026, and each fits one row of the table.

:case Case file, illustrative. On 31 October 2026 the items were as follows. Cash book bank balance: Tk 612,000. Bank statement balance: Tk 655,000. Deposit in transit: Tk 48,000. Outstanding cheques: no. 4417 for Tk 36,000 and no. 4421 for Tk 22,000. Bank service charge: Tk 1,500. Dishonoured customer cheque: Tk 8,000. Interest credited by the bank: Tk 2,500. School payment made directly to the bank and not yet in the books: Tk 40,000.

> Before moving on, we restate the principle of this section.

*Before moving on.* The bank statement and the cash book differ because one record learns of an event before the other. A deposit in transit and an outstanding cheque are known to the business first, and need no entry. A credit memo, a debit memo and a dishonoured cheque are known to the bank first, and need an entry. You should now be able to say, for any item, who knows first and what follows.

## 12.3 Preparing the Reconciliation

> The reconciliation turns two different totals into two matching totals, with every step shown.
@ Bank reconciliation statement | A statement that explains the difference between the bank balance in the cash book and the balance on the bank's statement.

You now know the six causes of difference. The next question is how to arrange them so that nothing is forgotten. The answer is a working paper called the **bank reconciliation statement**.

> The statement is built in two halves, one starting from each record.

A bank reconciliation statement is a statement that explains the difference between the bank balance in the cash book and the balance on the bank's statement. It has two halves. The first half starts from the bank statement balance and deals with the items the bank has not yet recorded. The second half starts from the cash book balance and deals with the items the business has not yet recorded. Each half ends with a figure, and we call these two figures the adjusted balances. If the work is correct, the adjusted balances are equal, and that common figure is the true amount in the bank.

> Each half has its own rule for adding and subtracting, based on the six items.

The rules follow from what you learned in section 12.2. In words: the adjusted bank balance is the bank statement balance plus deposits in transit, less outstanding cheques. The adjusted book balance is the cash book bank balance plus credit memos, less debit memos and dishonoured cheques. In symbols, let S be the bank statement balance, D the deposits in transit and C the outstanding cheques. Let B be the cash book bank balance, M the credit memos, N the debit memos and H the dishonoured cheques. Then the adjusted bank balance is S + D − C, and the adjusted book balance is B + M − N − H. A deposit in transit is added to the bank side because the bank will soon receive it. An outstanding cheque is subtracted because the bank will soon pay it.

:box IN SHORT
Adjusted bank balance = S + D − C. Adjusted book balance = B + M − N − H. The two must be equal. If they are not, an item is missing or wrongly placed.

> The figure shows the two halves side by side, ending in a single agreed balance.

The figure below shows the layout. Read it from top to bottom in each column. The left column begins with the bank statement balance and shows the two timing items. The right column begins with the cash book balance and shows the three items from the bank. Each column ends in a box, and a dashed line joins the two boxes to show that they must be equal.

:fig Two-sided layout of a bank reconciliation | ch12-fig01.svg

> Four steps give a method that works for any month.

Follow this method. First, compare the cash book with the statement, line by line, and tick every pair that agrees. Second, list the unticked items from the cash book: these are deposits in transit and outstanding cheques. Third, list the unticked items from the statement: these are credit memos, debit memos, dishonoured cheques and direct payments. Fourth, calculate the two adjusted balances and compare them. If they differ, tick again and check the arithmetic before you change anything.

> Here is a first example with small, clean numbers, which returns to the puzzle that opened the chapter.

Now we apply the method to the puzzle at the start of the chapter. We use the tutor's pace: each step is announced.

> The data of the small example.
*Given.* The cash book shows a bank balance of Tk 5,000. The statement shows Tk 5,700. A deposit of Tk 400 is in transit. One cheque for Tk 900 is outstanding. The bank added a credit memo for Tk 300 and a debit memo for Tk 100.

> The question to answer.
*Find.* The adjusted balance on each side, and whether they agree.

> The two rules, in symbols.
*Formula.* Adjusted bank balance = S + D − C. Adjusted book balance = B + M − N − H, with no dishonoured cheque here, so H = 0.

:table First example: small numbers
| Bank statement side | Tk | Cash book side | Tk |
| --- | --- | --- | --- |
| Statement balance | 5,700 | Cash book balance | 5,000 |
| Add deposit in transit | 400 | Add credit memo | 300 |
| Less outstanding cheque | 900 | Less debit memo | 100 |
| Adjusted bank balance | 5,200 | Adjusted book balance | 5,200 |

> Every line of arithmetic.
*Steps.* Left: 5,700 + 400 = 6,100, and 6,100 − 900 = 5,200. Right: 5,000 + 300 = 5,300, and 5,300 − 100 = 5,200.

> The result in a sentence, and a test of it.
*Answer.* Both adjusted balances are Tk 5,200, so the two records agree and the true balance is Tk 5,200.

> A test that the result is sensible.
*Check.* The original difference was 5,700 − 5,000 = 700. The bank side fell by 500 (400 − 900) and the book side rose by 200 (300 − 100), and 500 + 200 = 700. The puzzle is solved: neither record was wrong.

:pause 12.p1 | Suppose the adjusted bank balance is Tk 645,000 and the adjusted book balance is Tk 644,000. What should you do before you make any entry?

> The reconciliation statement is a working paper, so only the book-side items lead to entries.
> Recall: ledger and posting, Chapter 5 'The Journal and the Ledger', section 5.3 'The Ledger and Posting'.

After the reconciliation, one question remains: which items need a journal entry? The reconciliation statement is not a book of account. It is a working paper, so writing it changes no ledger account. The deposit in transit and the outstanding cheque need no entry, because the bank will record them without our help. The credit memos, debit memos and dishonoured cheques need entries, because our books are missing them. Each entry is posted to the cash book on one side and to the matching ledger account on the other. After posting, the cash book balance equals the adjusted balance.

> Before moving on, we restate the method.

*Before moving on.* A bank reconciliation statement has two halves, one from the bank statement and one from the cash book. Timing items adjust the bank side. Items from the bank adjust the book side. Only the book side leads to journal entries. You should now be able to say why a deposit in transit needs no entry and a debit memo does.

## Worked Example: The October Reconciliation

> The case file for 31 October 2026 is reconciled in full, with every line shown.

We now reconcile the seven items of the case file, with larger numbers and more varied items.

> The data for the October reconciliation.
:case Case file, illustrative. Given for 31 October 2026: cash book bank balance Tk 612,000; bank statement balance Tk 655,000; deposit in transit Tk 48,000; outstanding cheques no. 4417 for Tk 36,000 and no. 4421 for Tk 22,000; bank service charge Tk 1,500; dishonoured customer cheque Tk 8,000; interest credited by the bank Tk 2,500; school payment direct to the bank not yet in the books Tk 40,000.

> The task is to find the adjusted balance on each side and to check that they agree.

*Find.* The adjusted bank balance and the adjusted book balance, and the entries that follow. The formula is the same as before: S + D − C for the bank side, and B + M − N − H for the book side. Here M is the interest of Tk 2,500 plus the school payment of Tk 40,000. N is the service charge of Tk 1,500. H is the dishonoured cheque of Tk 8,000.

:table October reconciliation, 31 October 2026
| Bank statement side | Tk | Cash book side | Tk |
| --- | --- | --- | --- |
| Statement balance | 655,000 | Cash book balance | 612,000 |
| Add deposit in transit | 48,000 | Add interest credited | 2,500 |
| Less cheque no. 4417 | 36,000 | Add school payment | 40,000 |
| Less cheque no. 4421 | 22,000 | Less service charge | 1,500 |
| | | Less dishonoured cheque | 8,000 |
| Adjusted bank balance | 645,000 | Adjusted book balance | 645,000 |

> The arithmetic is shown line by line so that you can repeat it by hand.

*Steps.* Bank side: 655,000 + 48,000 = 703,000. The cheques total 36,000 + 22,000 = 58,000. Then 703,000 − 58,000 = 645,000. Book side: 612,000 + 2,500 = 614,500. Then 614,500 + 40,000 = 654,500. Then 654,500 − 1,500 = 653,000. Then 653,000 − 8,000 = 645,000.

> The answer is a single balance, and a quick test confirms the work.

*Answer.* Both adjusted balances are Tk 645,000. This is the true bank balance, and it is the figure for the balance sheet. *Check.* The original difference was 655,000 − 612,000 = 43,000. The bank side moved by 48,000 − 58,000 = −10,000. The book side moved by 2,500 + 40,000 − 1,500 − 8,000 = +33,000. And 10,000 + 33,000 = 43,000, so every taka is explained.

> Four items need journal entries, because the books of Meghna and Sons are missing them.

Now the entries. Four items came from the bank, so four entries are needed. Suppose the school owed Meghna and Sons Tk 40,000 for books supplied earlier. The table shows each entry.

:table Entries after the October reconciliation
| Item | Debit | Credit | Tk |
| --- | --- | --- | --- |
| Interest credited | Bank | Interest Revenue | 2,500 |
| School payment | Bank | Account Receivable (the school) | 40,000 |
| Service charge | Bank Charges | Bank | 1,500 |
| Dishonoured cheque | Account Receivable (the customer) | Bank | 8,000 |

> After posting, the Bank column of the cash book equals the adjusted balance.

The net effect on the Bank account is +2,500 + 40,000 − 1,500 − 8,000 = +33,000. So the cash book balance changes from Tk 612,000 to Tk 645,000. The deposit in transit and the two cheques have no entry; they will appear on the statement in November, and the bank side will then agree without help.

> Common slips: a wrong sign, a missed item, a misplaced half.

Three slips are common. The first is a wrong sign: a dishonoured cheque is subtracted from the cash book side, not added. The second is a missed item, usually the direct payment, because it is not in either record you started with. The third is adding an item to the wrong half; the table in section 12.2 shows which half each item belongs to.

## Summary

> The chapter's ideas in a few lines.

The cash book is a journal and a ledger in one, with a Cash column and a Bank column. The bank statement and the cash book differ because one learns of an event before the other. Deposits in transit and outstanding cheques are timing differences and need no entry. Credit memos, debit memos and dishonoured cheques come from the bank and need entries. A bank reconciliation statement brings both records to one adjusted balance.

## Think It Through

:q 12.t1 | In the case file of 31 October 2026, which items need a journal entry and which do not? Give one reason for each group.
:q 12.t2 | Cheque no. 4417 for Tk 36,000 is still outstanding three months later. What should the business do, and what does the reconciliation show each month until then?

## Where People Go Wrong

> Belief: the bank statement is the correct record, so the cash book must be forced to match it.

Some students think the statement is always right. It is not. The statement lacks the business's deposits in transit and outstanding cheques, so it is also incomplete. Neither record is correct until both are adjusted. The adjusted balance is correct, and neither raw total is.

> Belief: every reconciling item needs a journal entry.

Only the items that came from the bank need entries. A deposit in transit and an outstanding cheque are already in the cash book. Entering them again would record them twice.

> Belief: a credit memo reduces the balance, because credit sounds like a reduction.

The names follow the bank's books. A credit memo means the bank owes you more, so your balance rises. A debit memo means the bank owes you less, so your balance falls.

> Belief: a dishonoured cheque is a gain, because it is a cheque.

A dishonoured cheque is a loss of money that was recorded as received. It is subtracted from the cash book, and the customer's account receivable is restored.

> Belief: an agreeing reconciliation proves there are no mistakes.

Agreement is strong evidence, not proof. Two errors of equal size in opposite directions could cancel. The agreement shows that the known items explain the difference.

## In History

> Cheque clearing began when bank clerks in London began meeting to exchange cheques.

In the City of London, the old centre of banking in the English capital, banks once sent clerks from door to door to exchange the cheques they held against each other. From the 1770s the clerks began to meet each day in one place. Each clerk brought the cheques drawn on the other banks, and the clerks swapped them and settled only the differences, in cash. This daily meeting is the origin of cheque clearing. In the early nineteenth century a formal Bankers' Clearing House grew from it.

> The history explains why outstanding cheques exist at all.

This history matters for the reconciliation. A cheque must travel through the clearing process before the bank pays it, and the journey takes days. In those days the business has recorded the payment and the bank has not. That gap is the outstanding cheque.

## Review Questions

:q 12.1 | The cash book shows a bank balance of Tk 3,000. The statement shows Tk 3,400. A deposit of Tk 700 is in transit. A cheque for Tk 300 is outstanding. The bank collected Tk 900 for the business (a credit memo) and charged Tk 100 (a debit memo). Prepare the reconciliation statement and state the adjusted balance.
:q 12.2 | The cash book shows Tk 95,050 and the statement shows Tk 91,250. Deposits in transit are Tk 12,000 and Tk 6,500. Outstanding cheques are no. 0215 for Tk 9,800 and no. 0219 for Tk 4,150. A credit memo shows a collection of Tk 5,000. A debit memo shows a service charge of Tk 750. A customer's cheque for Tk 3,500 was dishonoured. Prepare the reconciliation statement.
:q 12.3 | In a later month the statement shows Tk 18,400 and the cash book shows Tk 20,150. A deposit of Tk 5,000 is in transit. Cheques of Tk 3,200 and Tk 1,100 are outstanding. A service charge of Tk 250 and a dishonoured cheque of Tk 800 are not in the books. Say which balance is higher before adjusting, then reconcile.
:q 12.4 | The cash book shows Tk 40,000 and the statement shows Tk 47,000. A deposit of Tk 4,000 is in transit and a cheque for Tk 9,000 is outstanding. A customer paid Tk 3,000 directly into the bank. The bank credited interest of Tk 500 and charged Tk 1,500. Reconcile, write the journal entries, and state the figure for Bank on the balance sheet.

:read Kelly, The Elements of Book-Keeping, 1805
:read Babbage, On the Economy of Machinery and Manufactures, 1832
