:chapter I | Business Activity and Companies
:mood Who does the work, who owns the shop, and who needs to know?
:desc This chapter shows what businesses do: some sell work, some sell goods bought from others, and some make what they sell. It then explains who may own a business, from one person to many shareholders, and why every owner needs written records.
:plate ch01-plate.svg | A clerk at his high desk among the ledgers, about 1880

:box YOU WILL NEED
Nothing from earlier pages, because this is the first chapter. You need only your own experience of buying, selling and saving money.

> A shop can be busy all day and still leave its owner unsure of the result.

Picture a bookshop on a busy street in Dhaka. From morning until evening, customers enter, choose a book, pay, and leave. At closing time the owner empties the cash drawer onto the desk and counts the notes. The pile looks large. Was it a good day? The owner hesitates, because the cash alone cannot answer the question.

> The cash in the drawer does not say whether the day was profitable.

Consider what the owner would need to know. Some of the cash may be payment for a book that has not yet been delivered. Some books on the shelves may have been bought from publishers who have not yet been paid. The rent for the month must still be found from somewhere. Even part of the pile may be borrowed from a relative last week. A drawer of cash is a fact. A good day is a judgement, and a judgement needs more facts.

> This chapter asks what businesses do, who owns them, and why they keep records.

This chapter begins to teach you how such judgements are made. First we ask what kinds of work businesses perform, because a bookshop, a tailor and a bakery have different things to count. Next we ask who owns a business, because one owner and a thousand owners need different things from the same records. Last we ask why records are kept at all. The answer gives you the reason for the rest of the book.

> The book marks its key words, notes and questions in the same way every time.

A word about the way this book is built. A new key word appears in bold, and its meaning follows at once. A short note in the side column repeats that meaning. Each section ends with a paragraph that begins *Before moving on.* Where an idea is new and hard, a flag tells you to go slowly, and a *Pause and check* question lets you test yourself before you continue. Many students find the first chapters slow, because every word is new. That is normal, and the pace is meant to help you.

* * *

## What Businesses Do

@! Go slowly here.
> A business supplies something people want and receives money in return.

@ Business | Word in use. In daily life, it can mean any occupation or concern. In accounting, it is an organisation that supplies goods or services to earn a profit.

Begin with something you may have seen yourself. A woman sells tea from a small stall beside a bus stop. She buys leaves and milk, boils them, pours the cups, and takes payment. Each action belongs to one pattern: she gives people something they want, and she receives money in return. We call that pattern business activity, the work an organisation performs to supply goods or services to customers for money. The word *business* has two meanings, so notice which one this book uses.^1

^1: The word *business* is also used for any private matter or occupation. This book uses it only for an organisation that supplies goods or services to earn a profit.

> Every business activity has three parts: obtain, work and deliver.

Look closer at the tea seller, because her day shows three parts that every business activity contains. First, she obtains what she needs: leaves, milk, fuel and a place to stand. Second, she performs work on them: she boils the mixture and pours the cups. Third, she delivers the result to customers and collects their money. A larger business has the same three parts, with more people and larger amounts. Meghna Binding Service, for example, obtains materials and the time of its workers, performs the work of repair and binding, and delivers the finished books to schools for a fee. When you meet a new business, ask these three questions in turn. The answers tell you what the business must count.

> Businesses exist because no one can make everything that he or she needs.

Why does business activity exist? Nobody can grow all their food, make all their clothes and print all their books. So people specialise: one person does a task well and exchanges the result for what others do well. Profit is the reason a business continues. Profit is the money left after the costs of the business are paid.^2 The tea seller earns profit only when the money from customers is larger than the cost of leaves, milk, fuel and her own time.

^2: Profit has a precise meaning in accounting, and later chapters teach it. For now, the plain meaning is enough.

> Business activity can fail, and failure is called a loss.

Where does business activity fail? It fails when the costs are larger than the money received. The difference is then a loss, not a profit. A loss is not a disgrace, but a business that suffers losses for long cannot continue. This is why the owner must learn the result, and why the result must be learned from facts and not from feeling.

> Owners, managers, employees and customers each look at a business differently.

Different people see the same business differently. The owner asks whether the business rewards the money and effort put into it. A manager, who directs the daily work for the owner, asks whether the work is well organised. An employee, who works for a wage, asks whether the wage will be paid. A customer asks whether the goods are good and the price fair. Every one of these questions depends on facts about the business.

> Businesses differ in what the customer finally receives.

Businesses differ in what the customer receives. We use three groups, and the first test is simple: does the customer receive work, goods that the business bought, or goods that the business made? Each group needs different records, so each group has its own name. We shall meet the groups one at a time, starting with the one that is easiest to see.

> A service business is paid for work, not for goods.
@ Service business | A business that earns money by doing work for customers rather than by selling goods.

A **service business** earns money by doing work for customers, not by selling goods. A hairdresser, a tailor who stitches the customer's own cloth, and a teacher are examples. In this book, Meghna Binding Service is a service business: it repairs and binds books for schools. The customer leaves with a repaired book, but the business was paid for the work.

> A merchandising business buys goods and sells the same goods again.
@ Merchandising business | A business that buys finished goods and sells them again at a higher price, such as a bookshop.

A **merchandising business** buys finished goods from others and sells them again at a higher price. A bookshop is the clearest example: it buys books from publishers and sells the same books to readers. It does not change the books. It earns its profit from the gap between the price it pays and the price it receives.

:pause 1.p1 | A shop buys sacks of rice and sells the rice by the kilogram. Which kind of business is it, and why?

> A manufacturing business changes materials into goods and sells them.
@ Manufacturing business | A business that makes goods from materials and then sells them.

A **manufacturing business** makes goods from materials and then sells them. A bakery turns flour, sugar and fuel into bread. A factory turns timber into chairs. The business holds three things that the other two kinds do not: materials waiting to be used, goods half finished, and goods ready to sell. Later chapters will give these three names.

> The table sets the three kinds of business side by side.

The table below compares the three kinds. Read it one row at a time: the first column names the kind, and the other columns say what the customer receives, what the business must count, and one example. The comparison matters because the thing a business must count decides what its records look like.

:table The three kinds of business
| Kind | The customer receives | The business must count | Example |
| Service | Work | Fees earned and the cost of doing the work | Meghna Binding Service |
| Merchandising | Goods bought from others | Goods bought, goods sold, and the price gap | Meghna and Sons, a bookshop |
| Manufacturing | Goods the business made | Materials, goods half finished, goods finished | A bakery that bakes its own bread |

> The figure shows each kind as a chain from the source to the customer.

The figure shows each kind as a chain. Read each row from left to right. A box names who holds the work or the goods, and an arrow shows the direction in which they travel toward the customer. A service chain is short, a merchandising chain has a supplier before the shop, and a manufacturing chain has the factory in the middle.

:fig Three kinds of business drawn as chains from source to customer | ch01-fig01.svg

> The kind of business decides which facts its owner must watch.

Why does the kind matter? Because it tells the owner where to look. In a service business, the owner watches the fees earned and the cost of the workers' time. In a merchandising business, the owner watches how many goods were bought, how many were sold and what remains on the shelves. In a manufacturing business, the owner watches all of these and also the materials and goods still being made. More things to count means more records.

> Many real businesses combine two kinds, and that is allowed.

Real businesses often combine kinds. A bakery that also sells tea bought from a wholesaler is manufacturing and merchandising together. A shop that repairs what it sells is merchandising and service together. The three groups are tools for thinking, not boxes into which every firm must fit. When a firm mixes kinds, we ask which kind brings in most of its money, and we describe the other kinds as additions.

> The recap gathers the section into three sentences.

*Before moving on.* Business activity is work done to supply goods or services for money, and profit is what remains after costs. A service business sells work, a merchandising business sells goods it bought, and a manufacturing business sells goods it made. You should now be able to say which of the three describes a bookshop, a hairdresser and a bakery, and why.

* * *

## Who Owns the Business

> Every business belongs to someone, and the kind of owner changes the records.

Every business belongs to someone. The owner provides the money and effort to begin, and receives the profit or bears the loss. Owners come in three main shapes: one person, a few people, and many people. Each shape gives the business different duties, because other people lend money, sell goods or buy shares according to who stands behind it.

> A sole proprietor is the one person who owns and answers for the business.

The first shape is the sole proprietor, a single person who owns the business and answers for it. The tea seller beside the bus stop is a sole proprietor. So is the owner of Meghna and Sons, Nurul Meghna, who has traded in Dhanmondi since 4 April 1996. The business is simple to begin and simple to direct. Its weakness is that all the money, work and risk rest on one person.

> A partnership shares ownership among two or more people by agreement.

The second shape is the partnership: a business owned by two or more people who agree to run it together and share its profit. For example, two friends might open a bookshop and divide the profit between them. Partnerships bring more money and more skills than one person can supply. They also bring a new question, which is who receives how much. Chapter 18, 'Partnership Accounts', teaches how partners' records answer it.

> A company is a business that the law treats as a person of its own.
@ Company | A business that the law treats as a person separate from its owners, with ownership divided into shares.

The third shape is the **company**. A company is a business that the law treats as a person separate from its owners, with its ownership divided into equal parts called shares. A person can buy a share, so a company can have hundreds of owners. The idea is strange at first. The company can own goods and owe money in its own name, even though the people who own it remain separate.^3

^3: The rules for forming a company differ from country to country. In Bangladesh, companies are formed under the Companies Act 1994; other countries have their own laws.

> A shareholder is an owner of a company through its shares.
@ Shareholder | A person who owns one or more shares of a company.

A **shareholder** is a person who owns one or more shares of a company. The proposal for Meghna and Sons Limited illustrates this: it names 410,000 shares of Tk 10 each. Suppose a person held 41,000 of those shares. That person would own one tenth of the company, because 41,000 is one tenth of 410,000. More shares give a larger part of the ownership.

:pause 1.p2 | A company has 100 shares, and one person holds 25 of them. What part of the company does this person own?

> The three shapes differ in who owns, who decides and who must be told.

Consider the three shapes from the viewpoint of an outsider who thinks of lending money. For a sole proprietor, the lender deals with one person. For a partnership, the lender deals with several people who agreed together. For a company, the lender deals with the company itself, and the shareholders may be many strangers. As the number of owners grows, more people need clear, written facts, because they cannot watch the business every day.

> A company's shares let many people own a small part of one business.

The company shape has one more feature that matters for records. Because a company can issue shares, it can collect small sums from many people and gather a large total. This is how very large businesses, such as ships and railways in earlier centuries, found money that no single owner possessed. The cost is that shareholders, who may live far away, rely on the records to learn what their business is doing.

> The company shape is not always better; each shape has a use.

Do not conclude that the company is the best shape. A company has more rules to follow, more reports to prepare and more people to inform. A small family shop may reasonably remain a sole proprietor for many years. The right shape depends on how much money is needed, how many people share the work, and how many outsiders must be told.

> A sole proprietor keeps control, which is why many small shops remain one.

Why would an owner choose to remain a sole proprietor? Control is the main reason. One person decides what to buy, what to charge and when to open, and no agreement or vote slows the decision. The profit also belongs to one person. For a small family shop with modest needs, these benefits often outweigh the extra money that more owners might bring.

> Advanced note: a shareholder's risk is limited, and a beginner may defer it.

*Advanced note, which you may defer.* One more feature explains why companies are popular. In most countries, a shareholder who has fully paid for his or her shares cannot be made to pay the company's debts from personal wealth. This protection is called limited liability. It makes people willing to buy shares, because the most they can lose is the amount they paid. The rules differ by country, so check the law of the place where the company is formed. Chapter 19, 'Company Accounts: Shares', returns to shares.

> The recap gathers the section into three sentences.

*Before moving on.* A sole proprietor is one owner, a partnership is two or more owners by agreement, and a company is a separate legal person owned through shares. A shareholder owns one or more shares. You should now be able to say who owns each of three businesses, and why a company with many shareholders needs written facts.

* * *

## Why Records Are Needed

> A record is a written note that lets anyone check what happened.

@ Record | Word in use. In daily life, it can mean the best result ever achieved, as in a sports record. In accounting, it is a written note of an event in the business, such as a sale or a payment.

Return to the shop owner and the pile of notes. What would turn the pile into an answer? The owner needs a written note of each sale, each purchase and each payment, made when the event happened. Such written notes are the records of a business. The word has two meanings, so notice that this book uses the second. Records are the memory of the business, written down so that it does not depend on any one person.

> Memory is weak, and other people cannot see inside it.

Why not trust memory? A busy owner forgets a small payment, remembers a large one wrongly, and cannot show either to anyone else. A lender, a tax officer or a partner will not accept "I believe so". A written record can be checked, copied, filed and examined years later. It also protects honest people, because it shows that an account was kept fairly.

> Many decisions depend on records, and each decision has its own reader.

Several decisions depend on records. The owner decides whether to hire another worker, buy more books or begin a new workshop. A lender decides whether a business can repay a loan. The tax authority decides how much tax is due. A person thinking of buying shares decides whether the company is sound. For Meghna and Sons, the proposal to form a company in 2026 will need records, because strangers will be asked to trust it. Chapter 2, 'What Accounting Is', describes these readers more fully.

> A useful record is dated, complete and open to checking.

What makes a record useful? Three qualities matter. It is dated, so that anyone can place the event in time. It is complete, so that a sale or payment is never left out because it seemed small. It is open to checking, so that a second person can follow it to the original paper, such as a receipt. A note on a scrap of paper, undated and unsigned, may be true, but nobody can prove it. The later chapters teach methods that give every record these qualities.

> Records are a basis for judgement, not a guarantee of success.

Records have limits. They do not make a business succeed; they only show what has happened, so that better choices become possible. Poor records are worse than none when they mislead. For that reason the later chapters teach not only how to write records but how to check them.

> The recap gathers the section into three sentences.

*Before moving on.* A record is a written note of an event in the business, kept so that facts do not depend on memory. Owners, lenders, tax officers and shareholders each make decisions that need those records. You should now be able to say why a busy owner cannot rely on memory, and name two people who need the records.

* * *

## Worked Case: Classifying the Meghna Businesses

> The case file gives the facts about three Meghna businesses and one proposal.

:case Case file, illustrative. Meghna and Sons is a family-run bookshop in Dhanmondi, Dhaka, owned by Nurul Meghna and trading since 4 April 1996. In 2025 it sold books worth Tk 14,400,000, which later chapters will call its net sales (Chapter 10, 'Accounts of a Merchandising Company'). The shop buys books and sells them. On 1 January 2026 a separate workshop, Meghna Binding Service, began to repair and bind books for schools, with its own set of books. A proposal exists to form a company in 2026 with 410,000 shares of Tk 10 each, a total of Tk 4,100,000.

> The question asks for the kind, the shape of ownership and the sum.

*Question.* What kind of business is each of the two Meghna businesses? Who owns the shop today? If the company is formed, what is the total value of the shares at their face price of Tk 10? Use only the facts in the case file.

> The shop buys finished books and resells them, so it is a merchandising business.

*Reasoning.* Begin with the shop. The case file says it buys books and sells them. It does not change the books, and it is not paid for work. This matches the definition of a merchandising business. Next, the workshop repairs and binds books for schools. The schools pay for work, and the workshop does not resell goods it bought. This matches the definition of a service business.

> One named owner makes the shop a sole proprietor today; the proposal would change that.

Now consider ownership. The case file names one owner, Nurul Meghna, so the shop today has the shape of a sole proprietor. The proposal would change the shape, because a company has shares and shareholders. To find the total value, multiply the number of shares by the price of one share: 410,000 shares × Tk 10 = Tk 4,100,000. A buyer of any of these shares would become a shareholder.

> The conclusion gives the three answers in plain sentences.

*Conclusion.* The shop is a merchandising business owned by one person, Nurul Meghna. The workshop is a service business. If the company is formed, its 410,000 shares have a total face price of Tk 4,100,000.

> The check repeats the arithmetic and the definitions.

*Check.* Multiply again from the other direction: Tk 4,100,000 ÷ Tk 10 = 410,000 shares, which agrees with the proposal. Test each kind against its definition: goods bought and resold give merchandising, and work done for payment gives service. Notice that the sales figure of Tk 14,400,000 was not needed to decide the kind, because the kind depends on what the business does, not on how much it earns.

* * *

## Summary

> The summary restates the chapter in a few lines.

Business activity is work done to supply goods or services for money. A service business sells work, a merchandising business sells goods it bought, and a manufacturing business sells goods it made. A business may be owned by one person, by partners or by shareholders of a company, which the law treats as a separate person. Written records let owners and outsiders check the facts and make decisions.

## Think It Through

> Four short problems test whether the kinds of business and ownership are secure.

Meghna Binding Service repairs and binds books for schools. The four problems below move from a familiar case, to the same case reshaped, to a new setting, and then to a case that combines earlier ideas.

:q 1.t1 | The workshop earns money from binding work. Why does it keep no records of goods bought to sell again?
:q 1.t2 | A hairdresser begins to sell bottles of shampoo bought from a wholesaler. Which kinds of business does the salon now combine, and which kind brings in most of its money if shampoo is only a small part of its income?
:q 1.t3 | A village club collects a monthly fee from its members and spends it on a reading room. Is the club a business in the sense used in this chapter? Give a reason.
:q 1.t4 | A bakery owned by three friends bakes bread and also sells tea that it buys from a wholesaler. State the kinds of business it combines, the shape of its ownership, and one person who would need its records.

## Where People Go Wrong

> Cash in the drawer is not the same as profit.

*A mistaken belief:* "The cash in the drawer is the profit." *Correction:* cash is only money held. Some of it may be owed to suppliers or may belong to customers who paid in advance. Profit is what remains after all the costs of the period are paid.

> A service business still needs records, though it holds no goods for sale.

*A mistaken belief:* "A service business has nothing to record." *Correction:* it holds no goods for resale, but it earns fees, pays wages and rent, and owes money. These all need written notes.

> A company and its owners are different persons in law.

*A mistaken belief:* "A company and its owner are the same." *Correction:* a company is a separate legal person. It can own goods and owe money in its own name, and its shareholders remain separate people.

> More owners do not by themselves make a business better.

*A mistaken belief:* "A business with more owners is stronger." *Correction:* more owners bring more money and more opinions, and more people to inform. Strength depends on the work the business does and the care with which it is run.

> The three kinds of business are tools for thinking, not strict boxes.

*A mistaken belief:* "Every firm belongs to exactly one kind." *Correction:* many firms mix kinds. We name the kind that earns most of the money and treat the others as additions.

## In History

> A royal charter of 1600 created an early company that served its investors.

On 31 December 1600, Queen Elizabeth I granted a royal charter to a group of London merchants trading to the East Indies. The charter gave the group the sole right to trade there for fifteen years, and its aim was to compete with the Dutch merchants who then controlled much of the spice trade. Thomas Smythe became the first governor of the English East India Company.

> The company's voyages were paid for by investors, who expected to learn the result.

Voyages across the ocean were costly and dangerous, so no single merchant paid for them. The Company raised money by selling shares to merchants, and these investors expected an account of what became of their money. In this way the Company shows early the link between a company, its shareholders and its records. The later political history of the Company, which includes the governing of large parts of South Asia, belongs to history books and is not told here.

## Review Questions

:q 1.1 | A tailor stitches clothes from cloth that customers bring. A grocer buys rice and sells it again. A furniture workshop builds chairs from timber and sells them. State the kind of business each one is.
:q 1.2 | List four people or groups who would want to see the records of a bakery, and say what each wants to learn.
:q 1.3 | In the proposal for Meghna and Sons Limited, there are 410,000 shares of Tk 10 each. Calculate their total face price, and say how many shares would be one tenth of the company.
:q 1.4 | In one sentence each, explain what a shareholder is and how a merchandising business differs from a manufacturing business.
:q 1.5 | Meghna Binding Service began on 1 January 2026 as a separate set of books from the shop. Name its kind of business, and give one reason why the owner may want the shop and the workshop recorded apart.

:read Gower, L. C. B., Principles of Modern Company Law, 1954
:read Pollard, Sidney, The Genesis of Modern Management, 1965
