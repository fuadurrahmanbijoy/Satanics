:chapter IV | Accounts, Debits and Credits
:mood How can one fact be written down so that it can be found, added and checked?
:desc This chapter teaches the account, the record that gathers every change to one kind of item. It shows the six types of account and the rule of debit and credit, called double entry, and applies the rule to seven transactions of a small business.
:plate ch04-plate.svg | A clerk ruling a ledger page with a straight-edge and pen, about 1880

:box YOU WILL NEED
Chapter 3, 'The Accounting Equation', section 3.1 'Assets, Liabilities and Equity'; section 3.2 'Revenue, Expenses and Drawings'; and section 3.3 'Transactions and the Equation'. Also Appendix A1, 'Maths You Will Use', for adding and subtracting columns of figures.

> A diary of events makes the simplest question hard to answer.

Imagine that you keep a diary for a small business. Each evening you write one line for every event: money received, a bill paid, books bought. After a month the diary holds dozens of lines. Then a lender asks one question: how much cash does the business hold today? To answer, you must read every line, decide which ones touched cash, and add and subtract them in the right order. If your answer is wrong, you cannot see where the mistake lies.

> The equation of Chapter 3 works for a few events but not for thousands.

Chapter 3 gave one answer: change the accounting equation after each transaction. That method works well for seven events. It fails for seven thousand, because the table would need a column for every kind of item and a row for every event. A real business needs two things. It needs to keep each kind of item in one place, with every increase and decrease together. It also needs a rule that catches mistakes at once.

> The chapter teaches the place, the six kinds and the rule that catches mistakes.

This chapter teaches both. First we meet the account, which is the place. Next we sort accounts into six types. Then we learn the rule of debit and credit, which links every entry to a second entry and so exposes many errors. The rule was written in a printed book more than five hundred years ago, and it has hardly changed since. Few ideas in business have lasted so long.

* * *

## The Account

@! Go slowly here.
> A household notebook with one page for each item shows the idea of an account.

Think of a household exercise book. One page is headed *Rice*, another *Electricity*, a third *Money lent to a neighbour*. Each time something happens, you write it on the page where it belongs. To learn how much was spent on rice this month, you read one page and not the whole book. A business uses the same idea, with many more pages and with strict rules for writing on them.

> An account holds all the changes to one kind of item.
@ Account | A record that collects all the increases and decreases of one kind of item, such as Cash.

An **account** is a record that collects all the increases and decreases of one kind of item. For example, the Cash account collects every receipt and every payment of cash, so it shows how much cash the business holds. The business keeps one account for each kind of item it must follow: one for Cash, one for shelving, one for money owed to a publisher, and so on.

> A chart of accounts is the list that stops duplicate or missing accounts.
@ Chart of accounts | A list of every account a business uses, with a code for each.

As the number of accounts grows, the business needs a list, so that nobody opens a second Cash account by mistake. A **chart of accounts** is a list of every account a business uses, with a code for each. For example, a business might give the code 101 to Cash and the code 201 to Accounts Payable. Meghna Binding Service, the running case, uses only eight accounts, so its chart is short. A large company may use hundreds.

> A T-account is a quick drawing of an account with two sides.
@ T-account | A simple account drawn as a letter T, with a left side and a right side.

Before we use real ledger books, we need a quick way to draw an account. A **T-account** is a simple account drawn as a letter T, with a left side and a right side. The name of the account is written across the top, and each entry is written below it, on one side or the other. The figure shows a T-account for Cash. The horizontal line separates the name from the entries, the vertical line separates the two sides, and each figure is one entry. Later in this chapter, the two sides receive their proper names.

:fig A T-account for Cash, with its two sides labelled | ch04-fig01.svg

> The recap gathers the section into three sentences.

*Before moving on.* An account collects all the changes to one kind of item, the chart of accounts lists every account in use, and a T-account is a quick drawing with a left side and a right side. You should now be able to say what the Cash account would show, and why a business keeps a separate account for each kind of item.

* * *

## Six Types of Account

> Every account belongs to one of six types taken from the equation.

Chapter 3 sorted the items of a business into groups when it built the accounting equation.^1 Accounts follow the same groups, and there are six types. Why six? Because each type moves in its own way when something happens, and the rules of the next section depend on knowing the type. The table below lists them. Read each row from left to right: the type, what its accounts record, and examples from Meghna Binding Service.

^1: Recall: asset, liability and equity, Chapter 3, 'The Accounting Equation', section 3.1 'Assets, Liabilities and Equity'; revenue, expense and drawings, section 3.2 'Revenue, Expenses and Drawings'.

:table The six types of account
| Type | What its accounts record | Examples |
| Asset | Things of value the business owns or controls | Cash, Shelving, Inventory |
| Liability | Amounts the business owes to others | Accounts Payable |
| Owner's capital | Value the owner has put into the business | Owner's Capital |
| Drawings | Value the owner takes out for personal use | Drawings |
| Revenue | Money earned or due from goods or services | Service Revenue |
| Expense | Costs used up in earning revenue | Rent, Wages |

> Asset accounts record what is owned; liability accounts record what is owed.

An asset account records something of value that the business owns or controls, such as Cash, Shelving or Inventory. Here *inventory* means the books held for sale, a subject that Chapter 13, 'Inventory: Meaning and Measurement', teaches in full. A liability account records an amount owed to others. Accounts Payable, for example, holds the amounts owed to publishers. The owner can look at the first and see what the business has, and look at the second and see what it owes.

> The owner's capital account records money put in; drawings records money taken out.

The owner's capital account records the value the owner has put into the business, and it is part of owner's equity. The drawings account records what the owner takes out for personal use. Why keep them apart? Because the owner should see both how much was put in and how much was taken out. A single combined account would hide the second figure behind the first.

> Revenue accounts record what is earned; expense accounts record what is used up.

A revenue account records money earned or due from selling goods or doing work. Service Revenue is the revenue account of Meghna Binding Service. An expense account records a cost used up in earning revenue, such as Rent or Wages. The business keeps a separate expense account for each cost, because an owner wishes to know the rent and the wages separately and not as one lump.

> The recap gathers the section into three sentences.

*Before moving on.* The six types are asset, liability, owner's capital, drawings, revenue and expense. Each account belongs to exactly one type, and its type decides how it behaves. You should now be able to name the type of Cash, Accounts Payable, Rent and Service Revenue.

* * *

## Debit and Credit

@! Go slowly here.
> Bank statements use the two words, but with a meaning that does not fit here.
@ Debit | Word in use. In daily life, a bank debits an account when it takes money out. In accounting, a debit is an entry on the left side of an account, whether the balance rises or falls.
@ Credit | Word in use. In daily life, credit means buying now and paying later, or a bank adding money to an account. In accounting, a credit is an entry on the right side of an account.

You have probably seen the words *debit* and *credit* on a bank statement. The bank says it has debited your account when it takes money out and credited it when it adds money. Shops also use *credit* for buying now and paying later. In accounting, the two words have a fixed and different meaning, and the bank's habit can mislead you. Put it aside for this chapter. The words come from Venice: *debit* from the Latin *debere*, to owe, and *credit* from *credere*, to believe.

> A debit is an entry on the left side of an account.
@ Debit | An entry on the left side of an account; it increases assets and expenses and decreases liabilities and equity.

A **debit** is an entry on the left side of an account. That is the whole meaning of the word: the left side. It does not mean good or bad, and it does not mean more or less. In the Cash T-account, a figure written on the left side is a debit to Cash. Whether a debit raises or lowers the balance depends on the type of account, as the next paragraphs show.

> A credit is an entry on the right side of an account.
@ Credit | An entry on the right side of an account; it increases liabilities, equity and revenue and decreases assets.

A **credit** is an entry on the right side of an account. Again, the word names a side and nothing else. A payment of cash is written on the right side of the Cash T-account, so we say that Cash is credited. The balance of an account is the difference between its two sides. Whether a credit raises or lowers that balance also depends on the type of account.

> The sides of an account copy the sides of the accounting equation.

Why does an asset increase on the left? The reason lies in the accounting equation, which has two sides.^2 Assets stand on the left of the equals sign, and liabilities and owner's equity stand on the right. The rule copies this layout. An increase in an item from the left side of the equation is recorded on the left of its account. An increase in an item from the right side is recorded on the right. Decreases are recorded on the opposite side from increases.

^2: Recall: the equation in expanded form, Chapter 3, 'The Accounting Equation', section 3.2 'Revenue, Expenses and Drawings'.

> Drawings and expenses lower equity, so they behave like assets; revenue behaves like equity.

Three types need a second thought: revenue, expenses and drawings. They are parts of owner's equity. Revenue raises equity, so it sits with the right side. Expenses and drawings lower equity, so their increases take the opposite side, the left. The expanded equation shows the result. In words: assets plus drawings plus expenses equal liabilities plus owner's capital plus revenue. In symbols: A + D + E = L + C + R, where A is assets, D is drawings, E is expenses, L is liabilities, C is owner's capital and R is revenue.

> The three types on the left increase by debit; the three on the right increase by credit.

Now the rule can be read straight from the equation. The three types on the left, which are assets, drawings and expenses, increase on the left, so they increase by debit. The three types on the right, which are liabilities, owner's capital and revenue, increase on the right, so they increase by credit. Every decrease is on the other side. The table gathers the rule. Read each row from the left: the type, the side of an increase, the side of a decrease, and the normal balance, which the next paragraph explains.

:table The side of increase and decrease for each type
| Type | Increase | Decrease | Normal balance |
| Asset | Debit | Credit | Debit |
| Drawings | Debit | Credit | Debit |
| Expense | Debit | Credit | Debit |
| Liability | Credit | Debit | Credit |
| Owner's capital | Credit | Debit | Credit |
| Revenue | Credit | Debit | Credit |

> The normal balance is the side on which an account usually ends.
@ Normal balance | The side of an account, debit or credit, on which increases are recorded and where its balance usually falls.

An account usually grows more than it shrinks, so its balance usually ends on the side of its increases. The **normal balance** is the side of an account, debit or credit, on which increases are recorded. Cash has a debit normal balance, because cash increases by debit. Accounts Payable has a credit normal balance. When a balance falls on the other side, it is a signal to look closer: an asset that ends on the credit side may mean an error, or a bank overdraft.

:pause 4.p1 | Rent is an expense. On which side is its normal balance, and why?

> The figure shows each type with its side of increase and its normal balance.

The figure shows the same rule as a picture. The left column lists the three types that increase by debit, and the right column lists the three that increase by credit. A short bar under each name marks its normal balance. You can rebuild the whole picture from one fact: assets, drawings and expenses stand on the left, and the rest stand on the right.

:fig Six account types, each with its side of increase and normal balance | ch04-fig02.svg

> Double entry means every transaction has two equal sides.

Many students find this the hardest step, because it asks you to hold two ideas together. Start with a question. If all changes to an item sit in one account, how can we know that none was forgotten? Chapter 3 gives the clue. Every transaction left the accounting equation in balance, so every transaction had at least two effects. The method of recording should show both effects each time. That method is called double entry.

> Double entry records each transaction twice, with equal debit and credit.
@ Double entry | The rule that every transaction is recorded twice, once as a debit and once as a credit of equal amount.

**Double entry** is the rule that every transaction is recorded twice, once as a debit and once as a credit of equal amount. Take the first transaction of Meghna Binding Service. On 1 January 2026 the owner invests cash of Tk 500,000. Cash is an asset and it increases, so Cash is debited Tk 500,000. Owner's Capital increases, so Owner's Capital is credited Tk 500,000. One fact, two entries, one amount.

:pause 4.p2 | A business buys shelving for cash. Name the two accounts, and say which one is debited and which one credited.

> Equal entries keep the equation in balance and expose many mistakes.

Why does the rule help? Each entry changes the equation by the same amount on each side, so the equation stays in balance after every transaction. It follows that, at any moment, the total of all debit entries must equal the total of all credit entries. If they differ, an error exists, and the business knows it at once. This check is far better than the diary of the opening puzzle. The Venetian method was described in print by Luca Pacioli in 1494, and its essential rule is the one you have now learned.

> The owner and the lender both gain from the check of equal totals.

Consider the viewpoints. The owner gains a quick way to find mistakes before they grow. A lender, who cannot watch the business, gains confidence that the figures were kept under a rule that exposes many errors. An employee who keeps the records gains protection, because a difference points to the mistake and not to the person.

> Double entry has limits: equal totals do not prove that every entry is right.

Where does the rule fail? Equal totals show that debits and credits agree. They do not show that the right accounts were chosen. If rent is debited to Wages by mistake, the totals still agree. If a transaction is left out completely, both sides are missing and the totals still agree. Chapter 6, 'The Trial Balance', teaches how to test the totals and what the test cannot find. Also, some transactions affect three or more accounts. The rule still holds: the debits together equal the credits together. Chapter 5, 'The Journal and the Ledger', shows such entries.

> The recap gathers the section into three sentences.

*Before moving on.* A debit is the left side and a credit is the right side. Assets, drawings and expenses increase by debit, while liabilities, owner's capital and revenue increase by credit, and the normal balance of each type is the side of its increase. Under double entry every transaction has equal debits and credits. You should now be able to say, for any account, which side raises it and which side lowers it.

* * *

## Applying the Rules

> Four questions turn any transaction into a debit and a credit.

Every transaction can be recorded by the same four questions, asked in order. First, which two accounts does the transaction affect? Second, what is the type of each? Third, does each account increase or decrease? Fourth, use the table to find the side: an increase in an asset is a debit, a decrease is a credit, and so on for each type. Finish by checking that the debit amount equals the credit amount. If you follow the questions in order, you do not need to memorise any transaction.

* * *

## Worked Example: Recording the January Transactions

> Two examples follow: a small one to learn the method, then the full case.

We apply the method twice. The first example uses small round numbers, so that the method is the only new thing. The second is the real case, with seven transactions. Each example follows the same order: Given, Find, Formula, Steps, Answer and Check.

> The given facts of the small example are three events of a tiny stall.

*Example 1. Given.* A student begins a tea stall. (a) She puts Tk 1,000 of her own cash into the business. (b) She buys a stove for Tk 300 in cash. (c) She earns Tk 200 in cash by selling tea. *Find.* The debit and credit of each event, and the balance of each account.

> The formula says which side raises each type and that the amounts are equal.

*Formula.* In words: increases of assets, drawings and expenses are debits, increases of liabilities, owner's capital and revenue are credits, and each transaction has an equal debit and credit. In symbols, the rule comes from A + D + E = L + C + R.

> Each event gets one debit and one credit of equal amount.

*Steps.* (a) Cash is an asset and increases, so debit Cash 1,000. Owner's Capital increases, so credit Owner's Capital 1,000. (b) The stove is an asset and increases, so debit Equipment 300. Cash decreases, so credit Cash 300. (c) Cash increases, so debit Cash 200. Tea Revenue increases, so credit Tea Revenue 200. In the Cash T-account the left side holds 1,000 and 200, which total 1,200. The right side holds 300. The balance is 1,200 − 300 = 900 on the left.

> The answer states each balance and its side.

*Answer.* Cash has a debit balance of Tk 900. Equipment has a debit balance of Tk 300. Owner's Capital has a credit balance of Tk 1,000, and Tea Revenue has a credit balance of Tk 200.

> The check compares the two sides of the equation.

*Check.* The debit balances total 900 + 300 = 1,200, and the credit balances total 1,000 + 200 = 1,200. They agree. In the equation, assets of Tk 1,200 equal owner's capital of Tk 1,000 plus revenue of Tk 200, with no liabilities.

> The case file gives the seven January transactions of Meghna Binding Service.

:case Case file, illustrative. *Example 2. Given.* Meghna Binding Service, January 2026: 1 January, the owner invests cash of Tk 500,000. 2 January, it buys shelving for cash, Tk 120,000. 3 January, it buys books for sale on credit from a publisher, Tk 200,000. 10 January, it earns Tk 40,000 in cash for binding work. 15 January, it pays rent of Tk 60,000. 20 January, it pays Tk 80,000 to the publisher. 31 January, it pays wages of Tk 35,000.

> The find and the formula are the same as in the first example.

*Find.* The debit and credit of each transaction, and the balance of each account. *Formula.* The same as in Example 1. Use the four questions of the last section for each line, and remember that Inventory is an asset and Accounts Payable is a liability.

> The table shows the debit and credit of each transaction.

*Steps.* The table below gives the result of the four questions for each transaction. Read each row from left to right: the date, the account debited, the account credited and the amount. Notice the sixth row. Paying the publisher lowers a liability, so Accounts Payable is debited, and it lowers an asset, so Cash is credited.

:table The seven transactions with their debits and credits
| Date | Debit | Credit | Amount (Tk) |
| 1 January | Cash | Owner's Capital | 500,000 |
| 2 January | Shelving | Cash | 120,000 |
| 3 January | Inventory | Accounts Payable | 200,000 |
| 10 January | Cash | Service Revenue | 40,000 |
| 15 January | Rent | Cash | 60,000 |
| 20 January | Accounts Payable | Cash | 80,000 |
| 31 January | Wages | Cash | 35,000 |

> Adding each account's two sides gives its balance.

Now add the two sides of each account. Cash has debits of 500,000 and 40,000, which total 540,000, and credits of 120,000, 60,000, 80,000 and 35,000, which total 295,000. The difference is 540,000 − 295,000 = 245,000 on the debit side. The other accounts are found in the same way, and the table below gives them all.

:table The balance of each account at 31 January 2026
| Account | Debits | Credits | Balance |
| Cash | 540,000 | 295,000 | 245,000 debit |
| Shelving | 120,000 | 0 | 120,000 debit |
| Inventory | 200,000 | 0 | 200,000 debit |
| Accounts Payable | 80,000 | 200,000 | 120,000 credit |
| Owner's Capital | 0 | 500,000 | 500,000 credit |
| Service Revenue | 0 | 40,000 | 40,000 credit |
| Rent | 60,000 | 0 | 60,000 debit |
| Wages | 35,000 | 0 | 35,000 debit |

> The answer lists the eight balances in one sentence.

*Answer.* At 31 January 2026, Cash has a debit balance of Tk 245,000, Shelving Tk 120,000 and Inventory Tk 200,000. Rent has a debit balance of Tk 60,000 and Wages Tk 35,000. Accounts Payable has a credit balance of Tk 120,000, Owner's Capital Tk 500,000 and Service Revenue Tk 40,000.

> Two checks confirm the result: equal totals and the equation.

*Check.* First, the debit balances total 245,000 + 120,000 + 200,000 + 60,000 + 35,000 = 660,000. The credit balances total 120,000 + 500,000 + 40,000 = 660,000. They agree. Second, the debit entries of the seven rows total 1,035,000, and so do the credit entries. Third, the assets are 245,000 + 120,000 + 200,000 = 565,000, which equals liabilities of 120,000 plus owner's equity of 445,000, found as 500,000 + 40,000 − 60,000 − 35,000.

> Four common slips cause most wrong entries.

*Common slips.* Students often treat debit as meaning decrease, which is wrong for assets. They record an expense on the credit side because the cash leaves. They forget the second entry, so the totals differ. Or they read a liability as an asset and debit it when the business borrows. When an entry looks strange, return to the four questions.

> The recap gathers the section into three sentences.

*Before moving on.* The four questions are: which accounts, what types, increase or decrease, and which side. Each transaction gets one debit and one credit of equal amount. You should now be able to record any simple transaction without memorising it.

* * *

## Summary

> The summary restates the chapter in a few lines.

An account collects all the changes to one kind of item, and the chart of accounts lists them all. There are six types: asset, liability, owner's capital, drawings, revenue and expense. A debit is the left side and a credit is the right side. Assets, drawings and expenses increase by debit, and liabilities, owner's capital and revenue increase by credit. Double entry records every transaction with an equal debit and credit, which keeps the equation in balance.

## Think It Through

> Two problems test whether the rule can be explained and applied again.

:q 4.t1 | Explain, using the accounting equation, why Cash increases on the debit side and not on the credit side.
:q 4.t2 | The owner takes Tk 10,000 in cash from the business for personal use. Name the two accounts, say which is debited and which credited, and explain why the business does not record this as an expense.

## Where People Go Wrong

> Debit does not mean decrease, and credit does not mean increase.

*A mistaken belief:* "Debit means less and credit means more." *Correction:* the words name the left side and the right side. Debits raise assets, expenses and drawings, but they lower liabilities, owner's capital and revenue.

> Debit is not bad and credit is not good.

*A mistaken belief:* "A credit is good news and a debit is bad news." *Correction:* neither word has a moral meaning. A debit to Cash is good news for the business, and a credit to Accounts Payable means the business owes more.

> Expenses are debited even though money leaves the business.

*A mistaken belief:* "Money going out is a credit, so every payment is a credit to the expense." *Correction:* the credit goes to Cash, which falls. The expense account increases, so it is debited.

> Equal totals do not prove that every entry is right.

*A mistaken belief:* "If debits equal credits, the books are correct." *Correction:* equal totals show agreement only. A wrong account, a missing transaction or a wrong amount on both sides still leaves the totals equal.

## In History

> Luca Pacioli described the Venetian method of double entry in a printed book.

In 1494, in Venice, a printer issued a large book on mathematics by Luca Pacioli, a friar of the Franciscan order who also taught mathematics. Its title, *Summa de arithmetica, geometria, proportioni et proportionalita*, means a summary of arithmetic, geometry, proportions and proportionality. Within it is a section on bookkeeping, called *Particularis de computis et scripturis*, which describes how merchants of Venice kept their books.

> Pacioli recorded a practice that merchants already used; he did not invent it.

Pacioli did not claim to have invented the method. He described what he called the method of Venice, which merchants had used for generations before the printing press made it widely available. His book was a textbook for students of mathematics and business. That is why it mattered: a method kept in merchants' habit became a method that anyone could read and teach.

## Review Questions

:q 4.1 | A small kiosk begins when its owner puts Tk 2,000 in cash into the business. It then buys a shelf for Tk 500 in cash and earns Tk 300 in cash from sales. Give the debit and the credit for each event, and state the balance of Cash.
:q 4.2 | A workshop has a Cash balance of Tk 50,000 on the debit side. It buys paper for Tk 18,000 on credit, pays Tk 7,500 to the supplier, earns Tk 26,400 in cash, pays wages of Tk 9,200 in cash, and the owner takes Tk 4,000 in cash for personal use. Give the entries, and find the balances of Cash and Accounts Payable.
:q 4.3 | A business borrows Tk 100,000 in cash from a bank, and later repays Tk 40,000 in cash. Give the entries for both events and the balance of the Bank Loan account.
:q 4.4 | A Cash account shows a balance of Tk 5,000 on the credit side. Say what this would normally mean, and name one way to find the cause.
:q 4.5 | For each account, state its type, the side that increases it, and its normal balance: Inventory, Accounts Payable, Drawings, Service Revenue, Wages.

:read Pacioli, Luca, Summa de arithmetica, geometria, proportioni et proportionalita, 1494
:read Gleeson-White, Jane, Double Entry, 2011
