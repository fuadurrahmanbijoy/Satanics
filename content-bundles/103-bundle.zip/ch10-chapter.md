:chapter X | Accounts of a Merchandising Company
:mood If a shop buys goods all year, why is its cost of goods not the amount it spent?
:desc A business that buys goods and sells them again needs accounts that a service business does not. This chapter teaches how sales, purchases and returns are recorded, how the income statement and balance sheet are arranged in classes, and how mistakes in the books are classified and corrected.
:plate ch10-plate.svg | A general store of the 1880s, with shelves, barrels and a counter.

> This chapter builds on two sections of Chapter 9.
> Recall: the three statements, Chapter 9, 'Financial Statements and Closing Entries', section 9.1 'The Three Statements'.
> Recall: closing the books, Chapter 9, 'Financial Statements and Closing Entries', section 9.2 'Closing the Books'.

You will need two sections of Chapter 9, 'Financial Statements and Closing Entries': section 9.1 'The Three Statements' and section 9.2 'Closing the Books'. You will also use Appendix A1, 'Maths You Will Use', for percentages.

> A bookseller who still holds unsold books cannot find profit by subtracting all purchases.

A bookseller buys 100 books at Tk 100 each and sells 80 of them at Tk 150 each. What profit did the bookseller make? A hasty answer subtracts the cost of all 100 books from the takings: Tk 12,000 − Tk 10,000 = Tk 2,000. That answer is wrong, and it is wrong in a useful way. Twenty books are still on the shelf. They have not been lost or used, and they are still worth Tk 2,000 to the bookseller. Only the cost of the 80 books that were sold, Tk 8,000, belongs against the takings, so the profit is Tk 4,000.

> A business that buys goods to sell again must separate goods sold from goods still held.

A business that buys goods in order to sell them again is called a merchandising business. Its main difficulty is the one in the puzzle: at any date, some of the goods bought have been sold, and some have not. The accounts of such a business must separate the two.

> The running case shows the same gap between the goods bought and the cost of the goods sold.

:case Case file, illustrative. Meghna and Sons, the family bookshop in Dhanmondi, Dhaka, bought books costing Tk 10,200,000 during 2025, before returns. Yet its cost of goods sold for 2025 is Tk 9,800,000. The difference is explained by opening inventory, purchase returns and closing inventory, as this chapter shows.

> The chapter has four sections and one worked example.

This chapter has four sections. Section 10.1 teaches sales, purchases, returns and the cost of goods sold. Section 10.2 arranges these in a classified income statement. Section 10.3 arranges the balance sheet in the same way. Section 10.4 teaches the kinds of error that can occur in the books and how each is corrected. A worked example with Meghna and Sons follows.

* * *

## 10.1 Sales, Purchases and Returns

> The word sales means revenue from goods sold, not a price reduction event.
@ Sales | Word in use. In daily life, the act of selling, or a time when prices are lowered. In accounting, the revenue earned from goods sold to customers.

Think of a stationery seller with a small stall. In one month she sells goods for Tk 10,000. That figure is her sales. Then a customer returns notebooks worth Tk 500 because the pages are loose, and she gives another customer a price reduction of Tk 200 because a pen is scratched. Does she still have Tk 10,000 of sales? She does not, because she did not keep all of that money. Each of these cases has a name, and the accounts record them separately.

> A sales return is goods sent back; an allowance is a price reduction for a faulty item.

A sales return is goods that a customer sends back, and the business refunds or cancels the amount. A sales allowance is a reduction in the price that a customer agrees to pay because the goods are faulty. Both are recorded in their own accounts, and not by changing the original sale. The business can then see how often goods come back.

> Net sales is the revenue the business really keeps after returns and allowances.
@ Net sales | Sales less sales returns and allowances: the revenue a merchandising business really keeps.

The amount that remains is called **net sales**. Net sales means sales less sales returns and allowances, the revenue a merchandising business really keeps. For the stationery seller, net sales are Tk 10,000 less Tk 500 less Tk 200. This figure, and not the larger one, is the first line of the income statement.

> The first calculation finds net sales for the stall.

*Given:* sales Tk 10,000; sales returns Tk 500; sales allowances Tk 200. *Find:* net sales. *Formula:* net sales equal sales minus sales returns minus sales allowances; in symbols, NS = S − R − A. *Steps:* Tk 10,000 − Tk 500 = Tk 9,500; then Tk 9,500 − Tk 200 = Tk 9,300. *Answer:* net sales are Tk 9,300. *Check:* net sales must be smaller than sales, and Tk 9,300 is.

> Purchases are goods bought for resale, and purchase returns are goods sent back to the supplier.

On the buying side the same pattern appears. The Purchases account records goods bought for resale. It does not record shop fittings or supplies, because those are not sold. A purchase return is goods that the business sends back to a supplier, recorded in its own account. For the stall, goods bought during the month cost Tk 6,000, and notebooks worth Tk 300 were sent back to the supplier. Purchases less purchase returns give net purchases of Tk 5,700.

> Cost of goods sold takes the goods available for sale and removes the goods still held.
@ Cost of goods sold | The cost of the goods that were sold during the period.

Now we can solve the opening puzzle. The **cost of goods sold** is the cost of the goods that were sold during the period. The business does not record the cost of each sale as it happens. It counts the goods that remain at the end of the period, and from that count it calculates the cost of the goods sold.^1 Goods that remain are called inventory, and they are an asset, not an expense, until they are sold.

^1: Some businesses update their inventory records with every sale and so do not need to calculate the cost of goods sold at the end. This chapter uses the count at the end of the period.

> The formula starts with opening inventory, adds net purchases and removes closing inventory.

The formula has four parts. Opening inventory is the inventory held at the start of the period. Add purchases and subtract purchase returns. The result is the goods available for sale. Then subtract closing inventory, the inventory still held at the end. In symbols, C = O + P − R − E, where C is cost of goods sold, O is opening inventory, P is purchases, R is purchase returns and E is closing inventory.

> The second calculation finds the cost of goods sold for the stall.

*Given:* opening inventory Tk 2,000; purchases Tk 6,000; purchase returns Tk 300; closing inventory Tk 1,700. *Find:* cost of goods sold. *Formula:* C = O + P − R − E. *Steps:* Tk 2,000 + Tk 6,000 = Tk 8,000; Tk 8,000 − Tk 300 = Tk 7,700; Tk 7,700 − Tk 1,700 = Tk 6,000. *Answer:* the cost of goods sold is Tk 6,000. *Check:* goods available for sale were Tk 7,700, and Tk 1,700 of them remain, so Tk 6,000 must have been sold.

:pause 10.p1 | A shop starts the month with inventory of Tk 500, buys goods for Tk 2,000, and counts Tk 700 of inventory at the end. What is the cost of goods sold?

> The bookshop's 2025 figures resolve the opening puzzle.

:case Case file, illustrative. In 2025, Meghna and Sons began with inventory of Tk 3,300,000 and bought books for Tk 10,200,000. It sent books worth Tk 200,000 back to suppliers and counted inventory of Tk 3,500,000 at the end. So Tk 3,300,000 + Tk 10,200,000 − Tk 200,000 − Tk 3,500,000 = Tk 9,800,000. The bookshop bought Tk 10,200,000 of books, yet the cost of the books it sold was Tk 9,800,000.

> Owners, managers and customers each care about returns for a different reason.

Each person with an interest sees something different here. The owner wants to know how much revenue the business keeps. A manager watches the returns, because a high figure suggests faulty goods or poor service. A customer sees only the refund, but the refund is the reason the business records the return. Returns also show the limit of the method: if inventory is counted wrongly, the cost of goods sold is wrong by the same amount.

> Three common slips: forgetting the closing count, forgetting returns, and counting fittings as purchases.

Three slips are common. If the closing count is forgotten, the cost of goods sold is too large and profit is too small. If purchase returns are forgotten, the same happens. If fittings are placed in the Purchases account, the cost of goods sold is too large, because fittings are not goods for resale.

> Before moving on: net sales and cost of goods sold both remove what the business did not really sell.

*Before moving on.* Net sales are sales less returns and allowances. The cost of goods sold equals opening inventory plus purchases less purchase returns less closing inventory. Unsold goods remain an asset until they are sold.

* * *

## 10.2 Classified Income Statement

> A classified income statement groups items so that the reader can see the shop's two kinds of result.

Return to the stationery seller. Her net sales are Tk 9,300 and her cost of goods sold is Tk 6,000. She also paid for advertising, delivery, rent and wages. If all these costs were placed in one long list, she could not tell whether her trading with customers or her running costs were the problem. A classified income statement answers by grouping items into classes. It first shows the result of buying and selling goods, and then the cost of running the business.

> Gross profit is the first result: net sales less the cost of the goods sold.
@ Gross profit | Net sales less cost of goods sold, before operating expenses are deducted.

The first result is the **gross profit**. Gross profit is net sales less cost of goods sold, before operating expenses are deducted. For the stationery seller, Tk 9,300 − Tk 6,000 = Tk 3,300. The figure below shows gross profit as the gap between two bars. The left bar is net sales, and the right bar is the cost of goods sold. The height of each bar shows the amount, and the gap at the top of the right bar is the gross profit.

:fig Gross profit as the gap between net sales and cost of goods sold | ch10-fig01.svg

> Operating expenses are the costs of running the business, apart from the cost of goods.
@ Operating expense | A cost of running the business, such as wages or rent, apart from the cost of goods sold.

The second class contains the operating expenses. An **operating expense** is a cost of running the business, such as wages or rent, apart from the cost of goods sold. Most statements divide operating expenses into two groups. Selling expenses are costs of finding customers and delivering goods, such as advertising. Administrative expenses are costs of managing the business as a whole, such as office rent and salaries. The groups show where the money goes.

> The third calculation finds the stall's profit.

*Given:* gross profit Tk 3,300; selling expenses Tk 900; administrative expenses Tk 1,200. *Find:* profit. *Formula:* profit equals gross profit minus operating expenses; in symbols, P = G − (V + D), where G is gross profit, V is selling expenses and D is administrative expenses. *Steps:* Tk 900 + Tk 1,200 = Tk 2,100; then Tk 3,300 − Tk 2,100 = Tk 1,200. *Answer:* profit is Tk 1,200.^2 *Check:* profit must be smaller than gross profit, and Tk 1,200 is.

^2: In this chapter the case file calls the final result profit. It is the same figure that Chapter 9 calls net income.

> A percentage of net sales lets the reader compare gross profit across years or shops.

Percentages make a comparison possible. The stationery seller's gross profit is Tk 3,300 on net sales of Tk 9,300, which is about 35 per cent. A shop with a higher percentage keeps more from each taka of sales. Appendix A1 shows how to calculate a percentage. Two shops can have the same gross profit and different profit, because one of them spends more on running costs. That is the reason the statement separates the two classes.

> The figure shows the order of the lines in a classified income statement.

The next figure shows the layout. The six boxes are the lines of the statement from top to bottom. The two heavy boxes are the results: gross profit after the first three lines, and profit at the foot. The brackets on the right show the two parts: the goods, and the running costs.

:fig The layout of a classified income statement | ch10-fig02.svg

> Meghna and Sons' 2025 statement puts its figures in this layout.

:case Case file, illustrative. The table below shows the 2025 income statement of Meghna and Sons. Read it from top to bottom: net sales, the build-up of the cost of goods sold, gross profit, the two groups of operating expenses, and profit.

:table Classified income statement of Meghna and Sons, year ended 31 December 2025 (Tk)
| Item | Tk |
| Net sales | 14,400,000 |
| Opening inventory | 3,300,000 |
| Add: purchases | 10,200,000 |
| Less: purchase returns | (200,000) |
| Less: closing inventory | (3,500,000) |
| Cost of goods sold | 9,800,000 |
| Gross profit | 4,600,000 |
| Selling expenses | 1,990,000 |
| Administrative expenses | 1,860,000 |
| Total operating expenses | 3,850,000 |
| Profit | 750,000 |

> Before moving on: the statement shows gross profit first, then operating expenses, then profit.

*Before moving on.* Gross profit is net sales less cost of goods sold. Operating expenses are the costs of running the business and are grouped as selling and administrative. Profit is gross profit less operating expenses. The classes tell the reader where the business gains and where it spends.

* * *

## 10.3 Classified Balance Sheet

> The word current in accounting means within one year.
@ Current | Word in use. In daily life, happening now. In accounting, expected to be used, collected or paid within one year.

Suppose you run a shop and wish to know what money you can count on in the next twelve months, and what you must pay in the same time. A single list of assets and liabilities will not tell you, because a shop counter and a coin in the till are both assets, yet only one of them can pay a bill next month. The classified balance sheet solves this by separating items that are near to cash, or near to payment, from those that are not.

> Current assets are turned into cash or used up within a year.
@ Current asset | An asset expected to be turned into cash or used up within one year.

A **current asset** is an asset expected to be turned into cash or used up within one year. Cash is the plainest example. Accounts receivable, the amounts that customers owe, will be collected soon. Inventory will be sold. Prepaid expenses, such as insurance paid in advance, will be used up. Current assets are listed in the order in which they come closest to cash.

> Current liabilities are debts that must be paid within a year.
@ Current liability | A debt that must be paid within one year.

A **current liability** is a debt that must be paid within one year. Accounts payable, the amounts the business owes to suppliers, are the usual example. A long loan can also contribute a current part: the instalments due in the next twelve months are shown as current, and the rest is shown separately.

> Non-current items last longer than a year, and owner's equity forms its own group.

Items that last or fall due after more than one year are non-current. A non-current asset, such as shop fittings, serves the business for several years. A non-current liability, such as a long-term loan, is paid after more than a year. Owner's equity is shown in a group of its own. Fittings are shown net, meaning after the fall in value that Chapter 16, 'Depreciation', teaches.

> Meghna and Sons' balance sheet at 31 December 2025 follows the classes.

:case Case file, illustrative. The table below shows the balance sheet of Meghna and Sons at 31 December 2025. Read it in three parts: assets first, then liabilities, then owner's equity. The two totals at the foot must agree.

:table Classified balance sheet of Meghna and Sons at 31 December 2025 (Tk)
| Item | Tk |
| Cash | 420,000 |
| Accounts receivable | 280,000 |
| Inventory | 3,500,000 |
| Prepaid expenses | 60,000 |
| Total current assets | 4,260,000 |
| Fittings (net) | 600,000 |
| Total assets | 4,860,000 |
| Accounts payable | 1,150,000 |
| Loan due within one year | 120,000 |
| Total current liabilities | 1,270,000 |
| Long-term loan | 480,000 |
| Owner's capital (2,860,000 + 750,000 − 500,000) | 3,110,000 |
| Total liabilities and owner's equity | 4,860,000 |

> The capital line comes from the statement of owner's equity of Chapter 9.

The capital figure is not new. It is the result of the statement of owner's equity: Tk 2,860,000 at the start, plus the profit of Tk 750,000, less drawings of Tk 500,000. The three statements of Chapter 9 therefore link here to the classified layout.

:pause 10.p2 | A loan of Tk 90,000 is repayable in four equal yearly instalments of Tk 22,500, the first due in six months. Which amount is a current liability?

> A lender compares what is due soon with what can be turned into cash soon.

Different readers use these classes. A bank that lends money to Meghna and Sons compares current assets of Tk 4,260,000 with current liabilities of Tk 1,270,000. The current assets are about three times as large, which suggests that the shop can pay its debts of the coming year. The owner reads the same figures to decide how much to withdraw. One limit must be remembered: inventory is a current asset, but it becomes cash only if customers buy it.

> Before moving on: current items fall within a year; non-current items last longer.

*Before moving on.* A current asset is turned into cash or used up within one year. A current liability must be paid within one year. Items beyond one year are non-current, and owner's equity forms its own group.

* * *

## 10.4 Correction of Errors

> An agreeing trial balance does not prove that the books are free of error.

The trial balance is the list that tests whether total debits equal total credits. Many students believe that when it agrees, the books must be right. They are not always right. Some mistakes leave the totals equal. Accountants name four kinds, and each has its own correction.

> An error of omission leaves a transaction out of the books completely.
@ Error of omission | A mistake in which a transaction is left out of the books completely.

An **error of omission** is a mistake in which a transaction is left out of the books completely. A credit sale of Tk 800 that is never entered is an example. Neither side is recorded, so the trial balance still agrees.

> An error of commission uses the wrong account of the right class, or a wrong amount.
@ Error of commission | A mistake in which an entry is made in the right class of account but the wrong account, or with a wrong amount.

An **error of commission** is a mistake in which an entry is made in the right class of account but the wrong account, or with a wrong amount. Tk 700 paid for electricity and debited to Telephone Expense is an example. Both are expenses, so the class is right and the account is wrong.

> An error of principle puts an entry in the wrong class of account.
@ Error of principle | A mistake in which an entry is made in the wrong class of account, such as an expense recorded as an asset.

An **error of principle** is a mistake in which an entry is made in the wrong class of account, such as an expense recorded as an asset. Tk 40,000 spent on a delivery van and debited to Repairs Expense is an example. A van is an asset, and the entry placed it among the expenses.

> A compensating error is two mistakes that cancel each other in the trial balance.
@ Compensating error | Two or more mistakes that cancel each other so that the trial balance still agrees.

A **compensating error** is two or more mistakes that cancel each other so that the trial balance still agrees. Suppose Wages is debited Tk 300 too much and Rent is debited Tk 300 too little. The debit total is correct, though both accounts are wrong.

> A correcting entry fixes an error with a new journal entry and erases nothing.

The remedy for each is a correcting entry, which is a new journal entry that fixes the error without erasing the old record. The table below shows one correction for each kind. Read each row as the entry that would put the books right.

:table Correcting entries for the four kinds of error
| Kind of error | Debit | Credit | Tk |
| Omission: unrecorded credit sale | Accounts Receivable | Sales | 800 |
| Commission: electricity in Telephone Expense | Electricity Expense | Telephone Expense | 700 |
| Principle: van in Repairs Expense | Vehicles | Repairs Expense | 40,000 |
| Compensating: Wages too high, Rent too low | Rent Expense | Wages Expense | 300 |

> A bookkeeper finds omission, principle and compensating errors by checking, not by the trial balance.

How are such errors found? A disagreeing trial balance warns of a one-sided mistake, and the bookkeeper searches for it. Errors of omission, principle and compensating errors do not disturb the totals, so only careful checks reveal them: comparing records with invoices, reviewing the accounts, and asking whether each entry used the right class. A good bookkeeper never relies on the trial balance alone. Because the books are permanent records, corrections are made by a new entry, dated and explained, so that the history stays visible.

> Before moving on: four kinds of error, and each is fixed by a new entry.

*Before moving on.* An error of omission leaves out a whole transaction. An error of commission uses the wrong account of the right class, or a wrong amount. An error of principle uses the wrong class. A compensating error is two mistakes that cancel. Each is corrected by a new journal entry.

* * *

## A Worked Example: Meghna and Sons for 2025

> The data for the bookshop's 2025 statements is given first.

:case Case file, illustrative. Meghna and Sons, 2025. Net sales Tk 14,400,000. Opening inventory Tk 3,300,000; purchases Tk 10,200,000; purchase returns Tk 200,000; closing inventory Tk 3,500,000. Selling expenses Tk 1,990,000; administrative expenses Tk 1,860,000. Capital at the start Tk 2,860,000; drawings Tk 500,000.

> The first calculation finds the cost of goods sold and gross profit.

:case Case file, illustrative. Calculation 1. *Given:* the inventory and purchase figures above. *Find:* cost of goods sold and gross profit. *Formula:* C = O + P − R − E, then gross profit = net sales − C. *Steps:* Tk 3,300,000 + Tk 10,200,000 = Tk 13,500,000; less Tk 200,000 = Tk 13,300,000; less Tk 3,500,000 = Tk 9,800,000. Then Tk 14,400,000 − Tk 9,800,000 = Tk 4,600,000. *Answer:* cost of goods sold is Tk 9,800,000 and gross profit is Tk 4,600,000. *Check:* gross profit is about 32 per cent of net sales, a reasonable share for a bookshop.

> The second calculation finds operating expenses and profit.

:case Case file, illustrative. Calculation 2. *Given:* selling expenses Tk 1,990,000; administrative expenses Tk 1,860,000; gross profit Tk 4,600,000. *Find:* operating expenses and profit. *Formula:* profit = gross profit − operating expenses. *Steps:* Tk 1,990,000 + Tk 1,860,000 = Tk 3,850,000; then Tk 4,600,000 − Tk 3,850,000 = Tk 750,000. *Answer:* operating expenses are Tk 3,850,000 and profit is Tk 750,000. *Check:* profit is smaller than gross profit.

> The third calculation finds capital and tests the balance sheet.

:case Case file, illustrative. Calculation 3. *Given:* capital at the start Tk 2,860,000; profit Tk 750,000; drawings Tk 500,000; current assets Tk 4,260,000; fittings Tk 600,000; current liabilities Tk 1,270,000; long-term loan Tk 480,000. *Find:* ending capital, and whether assets equal liabilities plus owner's equity. *Formula:* ending capital = start + profit − drawings; A = L + E. *Steps:* Tk 2,860,000 + Tk 750,000 = Tk 3,610,000; less Tk 500,000 = Tk 3,110,000. Assets: Tk 4,260,000 + Tk 600,000 = Tk 4,860,000. Liabilities: Tk 1,270,000 + Tk 480,000 = Tk 1,750,000; with capital, Tk 1,750,000 + Tk 3,110,000 = Tk 4,860,000. *Answer:* ending capital is Tk 3,110,000, and both sides total Tk 4,860,000. *Check:* Tk 4,860,000 − Tk 1,750,000 = Tk 3,110,000.

> Changing one figure shows how the statements respond.

Now change one figure to see how the method responds. Suppose purchase returns had been Tk 300,000 instead of Tk 200,000. Then cost of goods sold would be Tk 3,300,000 + Tk 10,200,000 − Tk 300,000 − Tk 3,500,000 = Tk 9,700,000, and gross profit would be Tk 14,400,000 − Tk 9,700,000 = Tk 4,700,000. Profit would rise by Tk 100,000 to Tk 850,000, and capital would rise by the same amount. A larger return to suppliers lowers the cost of goods sold.

> Three slips are common in these calculations.

Three slips are common. The first is forgetting the closing inventory, which would give a cost of goods sold of Tk 13,300,000 and a gross profit of only Tk 1,100,000. The second is placing the loan due within one year among the non-current items. The third is adding drawings to capital instead of subtracting them.

* * *

## Summary

> The summary gathers the chapter in a few lines.

A merchandising business records sales, returns, purchases and inventory. Net sales are sales less returns and allowances. The cost of goods sold is opening inventory plus purchases less purchase returns less closing inventory. Gross profit is net sales less cost of goods sold, and profit is gross profit less operating expenses. The balance sheet separates current from non-current items. Four kinds of error are corrected by new entries.

## Think It Through

:q 10.t1 | Explain why a compensating error does not stop the trial balance from agreeing, and give an example of your own.

:q 10.t2 | A bookshop forgets to count its closing inventory of Tk 2,000 when it calculates its cost of goods sold. What happens to the cost of goods sold, to gross profit and to the balance sheet?

## Where People Go Wrong

> Mistake one: treating all purchases as the cost of goods sold.

Some students treat everything bought as the cost of goods sold. Only the goods that were sold count. Goods that remain are inventory, an asset, until they are sold.

> Mistake two: ignoring returns and allowances.

Some students start from sales and forget the returns. Net sales are always smaller than sales when goods come back or prices are reduced.

> Mistake three: treating a long loan as wholly non-current.

Some students place a whole long loan below the current items. The instalment due within one year is current, and only the rest is non-current.

> Mistake four: believing that an agreeing trial balance means no errors.

Some students stop checking when the trial balance agrees. Omission, principle and compensating errors can all leave it in balance.

## In History

> Frank Woolworth failed with his first store in 1879 and succeeded with his second.

Frank Winfield Woolworth was an American merchant, born in 1852. In 1879 he opened his first store in Utica, a city in New York State in the United States. It sold goods at a fixed price of five cents, and it failed within months. Later the same year he opened a second store in Lancaster, Pennsylvania, which succeeded and added goods at ten cents. A shop of this kind lives on the gap between the cost of its goods and the price at which they sell. A fixed price means that every customer pays the same amount for the same item. Woolworth's chain grew from that second store, and the gap between net sales and cost of goods sold, the gross profit, was the figure on which it depended.

## Review Questions

:q 10.1 | A shop has sales of Tk 5,000, sales returns of Tk 300 and sales allowances of Tk 100. Find net sales.

:q 10.2 | Prepare a classified income statement from this data (Tk): sales 80,000; sales returns 2,000; opening inventory 12,000; purchases 50,000; purchase returns 1,000; closing inventory 14,000; selling expenses 6,000; administrative expenses 7,000.

:q 10.3 | Prepare a classified balance sheet from this data (Tk): cash 3,000; accounts receivable 4,000; inventory 14,000; prepaid expenses 1,000; equipment (net) 20,000; accounts payable 5,000; loan due within one year 2,000; long-term loan 10,000; owner's equity 25,000.

:q 10.4 | Name the kind of error in each case: (a) a sale of Tk 900 never recorded; (b) a delivery van of Tk 40,000 debited to Repairs Expense; (c) electricity of Tk 700 debited to Telephone Expense; (d) Wages debited Tk 300 too much and Rent debited Tk 300 too little.

:q 10.5 | Write the correcting entries for errors (b) and (c) of question 10.4.

:q 10.6 | Classify each as a current asset, a non-current asset, a current liability or a non-current liability: Inventory; shop fittings; accounts payable; a loan due in four years; a loan due in six months.

:read Edwards, J. R., A History of Financial Accounting, 1989
