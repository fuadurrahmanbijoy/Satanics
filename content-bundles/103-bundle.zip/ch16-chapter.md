:chapter XVI | Depreciation
:mood If a machine serves for five years, why should one year pay for all of it?
:desc This chapter teaches why the cost of a plant asset is spread over the years in which it helps to earn revenue. You will learn three methods of spreading cost, record the charge in the accounts, and find the gain or loss when an asset is sold.
:plate ch16-plate.svg | A locomotive in a depot, with an engineer inspecting its wheels

:box YOU WILL NEED
You will need the cost of a plant asset from Chapter 15 'Plant Assets', section 15.2 'Cost of a Plant Asset', and the difference between capital and revenue spending from Chapter 15 'Plant Assets', section 15.3 'Capital and Revenue Spending'. Appendix A1 'Maths You Will Use' covers percentages and rounding, which this chapter uses throughout.

> A bookshop buys a costly machine, and the question is which years should bear its cost.

On 1 April 2026, Meghna and Sons pays Tk 330,000 for a book-cutting machine. The machine will cut books for about five years. In the year of purchase the shop spends Tk 330,000, and its profit for that year is far smaller than usual. In the next four years the machine cuts thousands of books, yet the shop records no cost at all for it. Those years look more profitable than they really are.

> Charging the whole cost to one year gives an unfair picture of every year.

Consider what the owner would conclude. In the first year, the bookshop seems to lose money, and a lender may refuse a loan. In the later years, it seems to earn large profits, and the owner may spend too much. Both pictures are false, because the machine helps to earn revenue in all five years. Many students find this point difficult at first, because they remember that the cash left the business on one day. The accounts, however, must follow the use of the machine and not the day of payment.

> The remedy is to charge a share of the cost to each year of use, and this chapter teaches how.

The remedy has a name, and this chapter teaches it. Section 16.1 explains the idea and the words that belong to it. Section 16.2 and section 16.3 teach three methods of choosing the share for each year. Section 16.4 shows how to record the share and what happens when the asset is sold. Go slowly. The same machine returns in every section, so only the method changes.

* * *

## Why Depreciate

@! Go slowly here.

> A bicycle bought for a delivery job shows why cost should be shared over the years of use.

Suppose you begin a part-time delivery job and buy a bicycle for Tk 10,000. You expect to use it for four years, and then to sell it for about Tk 2,000. Would it be fair to say that all your earnings in the first year were reduced by Tk 10,000? The bicycle helps you earn in each of the four years. A fair view charges a share of its cost to each year. You pay once, but you use it four times.

> Depreciation is the spreading of an asset's cost over the years of its use.

@ Depreciation | The spreading of a plant asset's cost over the years it is expected to be useful.

**Depreciation** is the spreading of a plant asset's cost over the years it is expected to be useful. The bicycle shows the idea: a share of Tk 10,000 is charged in each of the four years. Depreciation is a method of allocation. It does not measure the fall in the market price of the asset, and it does not mean that cash is paid each year. The cash was paid on the day of purchase.

> Two everyday words, value and life, have special meanings when used with assets.

@ Value | Word in use. In daily life, what something is worth to a person. In accounting, a figure in the records, such as cost less depreciation, which need not equal the price in the market.

@ Life | Word in use. In daily life, the time a person lives. In accounting, the period over which an asset is expected to serve the business, which need not equal its physical age.

Before we continue, notice that two ordinary words carry special meanings here. The word value in accounting often means a figure in the records, and the word life means the period of expected service. The two notes beside this paragraph give both meanings. We shall use each word in its accounting sense from now on.

> Useful life is the period, or the amount of use, over which an asset is expected to serve.

@ Useful life | The period, or the amount of use, over which an asset is expected to serve the business.

The **useful life** of an asset is the period, or the amount of use, over which the asset is expected to serve the business. The bicycle has a useful life of four years. A delivery van might have a useful life of 200,000 kilometres. Notice that useful life is an expectation, not a fact, and it can be shorter than the time the asset physically lasts. A business may sell a machine after five years even though the machine could run for ten.

> Residual value is the amount the business expects to receive when the asset is disposed of.

@ Residual value | The amount a business expects to receive when it disposes of an asset at the end of its useful life.

The **residual value** of an asset is the amount the business expects to receive when it disposes of the asset at the end of its useful life. The bicycle has a residual value of Tk 2,000. If the business expects to receive nothing, the residual value is zero. Only the part of the cost that will be used up needs to be spread, so the residual value is not charged to the years of use.

> A first calculation with small numbers shows the amount to spread and the share for each year.

We now use the smallest numbers possible. *Given.* A bicycle costs Tk 10,000, has a residual value of Tk 2,000, and has a useful life of four years. *Find.* The amount to be spread, and an equal share for each year. *Formula.* The amount to be spread equals cost minus residual value. An equal yearly share equals the amount to be spread divided by the number of years. In symbols, S = C − R and D = S ÷ n, where C is the cost, R is the residual value, S is the amount to be spread, n is the useful life in years and D is the yearly share. *Steps.* S = Tk 10,000 − Tk 2,000 = Tk 8,000. D = Tk 8,000 ÷ 4 = Tk 2,000. *Answer.* Tk 8,000 is spread, at Tk 2,000 a year. *Check.* Four years at Tk 2,000 make Tk 8,000, and Tk 10,000 less Tk 8,000 leaves the residual value of Tk 2,000.

> Three factors affect the yearly charge: wear from use, passing of time, and change in the market.

Several factors lead a business to choose a life and a residual value. Wear from use reduces the usefulness of a machine. The passing of time rots wood and rusts iron, even when the machine stands idle. Changes in the market can make an asset out of date: a faster machine appears, or the books the shop sells change. A manager considers all three. The owner then chooses an estimate. Different people may reach different estimates, and tax rules in some countries use their own lives and rates, which may differ from those used in the accounts.^1

^1: Intangible assets, such as a licence, are also spread over their useful lives, but this chapter treats plant assets only.

> Land is the usual exception, and estimates may be revised as experience grows.

Exceptions need care. Land is a plant asset, but it is not depreciated, because it does not wear out or become out of date in the way that buildings and machines do. An estimate of life or of residual value may also prove wrong. If so, the business revises the estimate and spreads the remaining cost over the remaining years. It does not go back and alter the past years.

> Recap: depreciation spreads cost; life and residual value are estimates that set the amount and the period.

*Before moving on.* Depreciation spreads the cost of a plant asset over its useful life. The amount to be spread is the cost less the residual value. You should now be able to say why a machine bought in one year should not reduce the profit of that year alone.

* * *

## Straight-Line and Units-of-Production

@! Go slowly here.

> Equal shares are the easiest rule, and the case file gives the figures for the machine.

:case Case file, illustrative. Meghna and Sons bought a book-cutting machine on 1 April 2026 at a cost of Tk 330,000. The residual value is Tk 30,000, the useful life is five years, and the capacity is 500,000 books. The business closes its books on 31 December each year.

> The straight-line method charges the same amount in every year.

@ Straight-line method | A depreciation method that charges an equal amount each year.

The **straight-line method** is a depreciation method that charges an equal amount each year. The bicycle in section 16.1 used it, at Tk 2,000 a year. The word straight describes the picture of book value falling by equal steps, which forms a straight line on a graph. The method is the most common because it is easy to calculate and easy to explain.

> The machine's yearly charge is Tk 60,000, and the nine months of 2026 carry Tk 45,000.

*Given.* Cost Tk 330,000, residual value Tk 30,000, useful life five years, bought on 1 April 2026. *Find.* The charge for a full year, and the charge for 2026. *Formula.* Yearly charge equals cost minus residual value, divided by useful life in years. In symbols, D = (C − R) ÷ n. For a part of a year, multiply by the fraction of the year, m ÷ 12, where m is the number of months of use. *Steps.* D = (Tk 330,000 − Tk 30,000) ÷ 5 = Tk 300,000 ÷ 5 = Tk 60,000. From 1 April to 31 December is 9 months, so the 2026 charge is Tk 60,000 × 9 ÷ 12 = Tk 45,000. *Answer.* The full-year charge is Tk 60,000, and the charge for 2026 is Tk 45,000. *Check.* Tk 60,000 × 5 = Tk 300,000, which is the cost less the residual value.

> Pause and check that you can calculate the straight-line charge.

:pause 16.p1 | A van costs Tk 120,000, has a residual value of Tk 20,000 and a useful life of four years. What is the straight-line charge for a full year?

> The units-of-production method links the charge to how much the machine is used.

@ Units-of-production method | A depreciation method that charges an amount based on how much the asset is used in the period.

Some assets wear out by use more than by time. The **units-of-production method** is a depreciation method that charges an amount based on how much the asset is used in the period. A cutting machine is used more in a busy year than in a quiet year, and its wear follows the number of books cut. The method first finds a charge for each unit of use, and then multiplies by the units used.

> The machine's charge is Tk 0.60 for each book, so 90,000 books give Tk 54,000.

*Given.* The machine can cut 500,000 books in its life, and it cut 90,000 books in 2026. *Find.* The charge for each book, and the charge for 2026. *Formula.* The charge for each unit equals cost minus residual value, divided by the total units expected. In symbols, k = (C − R) ÷ U and D = k × u, where U is the total units expected, k is the charge for each unit and u is the units used in the period. *Steps.* k = Tk 300,000 ÷ 500,000 = Tk 0.60 a book. D = 90,000 × Tk 0.60 = Tk 54,000. *Answer.* The 2026 charge is Tk 54,000. *Check.* If all 500,000 books were cut, the total would be 500,000 × Tk 0.60 = Tk 300,000, which equals the amount to be spread.

> Each method has limits: straight-line ignores use, and units-of-production needs a good estimate of use.

Exceptions apply to both methods. The straight-line method charges the same amount in a busy year and in a quiet year, so it ignores use. The units-of-production method needs a reliable estimate of total units, which is hard for some assets, and it charges nothing in a year when the machine stands idle, even though time still passes. The 2026 results also differ: Tk 45,000 by straight line and Tk 54,000 by units of production. Both are correct under their own rule.

> Recap: straight-line gives equal shares; units-of-production follows use.

*Before moving on.* The straight-line method charges Tk 60,000 a year for the machine, and Tk 45,000 for 2026. The units-of-production method charges Tk 0.60 a book, and Tk 54,000 for 90,000 books. You should now be able to say which method suits an asset that wears by use.

* * *

## Declining-Balance

@! Go slowly here.

> A larger charge in early years suits an asset that loses usefulness quickly.

Some assets lose most of their usefulness early. A new machine cuts faster and breaks down less than an old one, and a new vehicle is worth more in its first year than in its fifth. For such assets a larger charge in the early years is a fairer picture. The third method provides it.

> The declining-balance method charges a fixed percentage of the remaining cost each year.

@ Declining-balance method | A depreciation method that charges a fixed percentage of the asset's remaining book value each year.

The **declining-balance method** is a depreciation method that charges a fixed percentage of the asset's remaining cost each year. We call the remaining cost the *book value*, a term that section 16.4 defines fully: it is the cost less all depreciation charged so far. Because the base falls each year, the charge falls each year. The balance that declines gives the method its name. The method uses the cost in the first year, and the residual value is not subtracted when the percentage is applied.

> The machine's charge at 40% is Tk 132,000 in year 1 and Tk 79,200 in year 2.

*Given.* Cost Tk 330,000, residual value Tk 30,000, a rate of 40% a year. *Find.* The charge and the remaining cost at the end of year 1 and year 2. *Formula.* The charge equals the rate times the remaining cost at the start of the year. The remaining cost at the end equals the start less the charge. In symbols, D = r × B and B′ = B − D, where r is the rate, B is the remaining cost at the start and B′ is the remaining cost at the end. *Steps.* Year 1: D = 40% × Tk 330,000 = Tk 132,000, and B′ = Tk 330,000 − Tk 132,000 = Tk 198,000. Year 2: D = 40% × Tk 198,000 = Tk 79,200, and B′ = Tk 198,000 − Tk 79,200 = Tk 118,800. *Answer.* The charges are Tk 132,000 and Tk 79,200, and the remaining cost after two years is Tk 118,800. *Check.* Tk 132,000 + Tk 79,200 = Tk 211,200, and Tk 330,000 − Tk 211,200 = Tk 118,800.

> Pause and check that you can apply a percentage to the remaining cost.

:pause 16.p2 | An asset costs Tk 80,000 and is depreciated at 25% by the declining-balance method. Find the charge and the remaining cost at the end of year 1 and year 2.

> The method must stop at the residual value, so the last charge is cut to fit.

The method has a limit that students often miss. The remaining cost must never fall below the residual value. The machine's remaining cost after year 3 is Tk 71,280, and after year 4 it is Tk 42,768. A charge of 40% in year 5 would be Tk 17,107, which would leave Tk 25,661, below the residual value of Tk 30,000. The year 5 charge is therefore cut to Tk 42,768 − Tk 30,000 = Tk 12,768.

> The table compares the yearly charges, and both methods spread the same Tk 300,000.

The table below compares the yearly charges by the straight-line method and by the declining-balance method. Read each row across to compare the two methods for one year. The last row shows that both methods charge the same total, Tk 300,000, over five years. Only the timing differs.

:table Yearly depreciation charges for the machine over five years (Tk)
| Year | Straight-line | Declining-balance |
| 1 | 60,000 | 132,000 |
| 2 | 60,000 | 79,200 |
| 3 | 60,000 | 47,520 |
| 4 | 60,000 | 28,512 |
| 5 | 60,000 | 12,768 |
| Total | 300,000 | 300,000 |

> The figure shows the remaining cost falling faster under declining-balance than under straight-line.

The first figure draws the remaining cost of the machine against the years. The horizontal axis shows the years since purchase, and the vertical axis shows taka. A point shows the remaining cost at the end of that year. The solid line, for straight-line, falls by equal steps. The dashed line, for declining-balance, falls steeply at first and then flattens. Both lines end at the residual value of Tk 30,000.

:fig Straight-line against declining-balance as two descending lines | ch16-fig01.svg

> Recap: declining-balance charges more early, less later, and stops at the residual value.

*Before moving on.* The declining-balance method applies a fixed rate to the remaining cost. For the machine at 40%, the charges are Tk 132,000 and Tk 79,200 in the first two years. You should now be able to say why the charge falls each year, and why the last charge may be cut.

* * *

## Recording and Disposal

> Each year the charge is recorded by debiting an expense and crediting a separate account.

At the end of each year the business records the charge in an adjusting entry, of the kind taught in Chapter 7 'Adjusting the Accounts'. The entry debits an expense account, called depreciation expense, which reduces profit. It credits a second account, which collects the charges and is shown as a deduction from the cost of the asset. The cost account itself is left unchanged.

> Accumulated depreciation is the running total of the charges made on one asset.

@ Accumulated depreciation | The total depreciation charged to date on an asset, shown as a deduction from its cost.

**Accumulated depreciation** is the total depreciation charged to date on an asset, shown as a deduction from its cost. After one year it equals one charge, after two years two charges, and so on. The business keeps the original cost visible, so that a reader can see both what the asset cost and how much has been charged. For the machine, the 2026 charge by straight line is Tk 45,000, and the entry is shown below.

:table Entry on 31 December 2026 for the straight-line charge
| Account | Debit (Tk) | Credit (Tk) |
| Depreciation expense, machine | 45,000 | |
| Accumulated depreciation, machine | | 45,000 |

> Book value is cost less accumulated depreciation, and it shows the cost not yet charged.

@ Book value | An asset's cost less its accumulated depreciation.

The **book value** of an asset is its cost less its accumulated depreciation. At 31 December 2026 the book value of the machine is Tk 330,000 − Tk 45,000 = Tk 285,000. The balance sheet shows the three figures together: cost, accumulated depreciation and book value. Book value is a figure in the records. It is not the price at which the machine could be sold, which may be higher or lower.

:table The machine in the balance sheet at 31 December 2026 (Tk)
| Item | Amount |
| Machine, at cost | 330,000 |
| Less accumulated depreciation | 45,000 |
| Book value | 285,000 |

> The figure shows book value stepping down once a year under straight-line.

The second figure shows the book value of the machine at the end of each year. The horizontal axis shows the years, and the vertical axis shows taka. Each horizontal step shows the book value that holds through a year, and each drop shows one yearly charge. After year 3 the book value is Tk 150,000, the amount used in the next calculation.

:fig Book value of the machine stepping down year by year | ch16-fig02.svg

> A sale after three years brings a gain or a loss, found by comparing proceeds with book value.

:case Case file, illustrative. After three years of straight-line depreciation, Meghna and Sons sells the book-cutting machine for Tk 120,000. The machine cost Tk 330,000 and the straight-line charge is Tk 60,000 a year.

> The calculation first finds the book value at the date of sale and then compares it with the proceeds.

*Given.* Cost Tk 330,000, charge Tk 60,000 a year for three years, proceeds Tk 120,000. *Find.* The gain or loss on sale. *Formula.* Gain or loss equals proceeds minus book value. A positive result is a gain and a negative result is a loss. In symbols, G = P − B, where P is the proceeds and B is the book value. *Steps.* Accumulated depreciation = 3 × Tk 60,000 = Tk 180,000. B = Tk 330,000 − Tk 180,000 = Tk 150,000. G = Tk 120,000 − Tk 150,000 = −Tk 30,000. *Answer.* The sale gives a loss of Tk 30,000. *Check.* The machine was carried at Tk 150,000 but brought only Tk 120,000, a shortfall of Tk 30,000.

> The entry removes the asset and its accumulated depreciation and records the cash and the loss.

The entry for the sale removes the machine from the records. It credits the machine for its full cost. It debits accumulated depreciation, so that the charges made so far are cleared. It debits cash for the proceeds, and it debits a loss account for the loss. The debits and credits must be equal, and the table shows that they are.

:table Entry for the sale of the machine after three years
| Account | Debit (Tk) | Credit (Tk) |
| Cash | 120,000 | |
| Accumulated depreciation, machine | 180,000 | |
| Loss on sale of machine | 30,000 | |
| Machine, at cost | | 330,000 |

> Depreciation must be brought up to the date of sale first, and a sale above book value gives a gain.

Two exceptions complete the picture. If the sale falls during a year, the charge for the part of the year must be recorded first, so that the book value is correct on the date of sale. If the machine had sold for Tk 170,000, the result would be Tk 170,000 − Tk 150,000 = Tk 20,000, a gain, and the entry would credit a gain account instead of debiting a loss account.

> Recap: accumulated depreciation and book value are linked, and a sale compares proceeds with book value.

*Before moving on.* Accumulated depreciation is the total charged so far, and book value is cost less that total. At sale, gain or loss equals proceeds minus book value. You should now be able to say why the machine's sale gave a loss of Tk 30,000.

* * *

## Worked Case: A Van Sold After Two Years

> This worked case shows that the method chosen changes the gain or loss on sale.

*Situation.* A different shop bought a delivery van on 1 January 2026 for Tk 480,000. It estimated a residual value of Tk 60,000 and a useful life of six years. At 31 December 2027, after two years, it sold the van for Tk 250,000. These figures are for practice and are not part of the case file. *Question.* What is the gain or loss on sale if the shop used straight-line depreciation, and what is it if the shop used declining-balance at 30%?

> The reasoning finds the book value under each method and compares it with the proceeds.

*Reasoning.* Straight line: the yearly charge is (480,000 − 60,000) ÷ 6 = Tk 70,000. After two years the accumulated depreciation is Tk 140,000, so the book value is Tk 480,000 − Tk 140,000 = Tk 340,000. Declining balance: year 1 is 30% × 480,000 = Tk 144,000, leaving Tk 336,000. Year 2 is 30% × 336,000 = Tk 100,800, leaving Tk 235,200. The accumulated depreciation is Tk 244,800. The proceeds are Tk 250,000 in both cases.

> The conclusion is a loss of Tk 90,000 under straight-line and a gain of Tk 14,800 under declining-balance.

*Conclusion.* Straight-line: Tk 250,000 − Tk 340,000 = −Tk 90,000, a loss. Declining balance: Tk 250,000 − Tk 235,200 = Tk 14,800, a gain. The same van, sold at the same price, gives a loss under one method and a gain under the other. The faster method had already charged more cost, so less remained to set against the proceeds. *Check.* Under straight-line, the debits are Tk 250,000 + Tk 140,000 + Tk 90,000 = Tk 480,000, which equals the credit to the van. Under declining balance, the debits are Tk 250,000 + Tk 244,800 = Tk 494,800, and the credits are Tk 480,000 + Tk 14,800 = Tk 494,800.

> Three slips occur often in this work, and each one can be prevented.

Common slips deserve a warning. The first is to forget the residual value in the straight-line formula, which makes every charge too large. The second is to subtract the residual value from the cost before applying the declining-balance rate, instead of applying the rate to the full remaining cost. The third is to forget the fraction of the year in the year of purchase. Test every answer by asking whether the total of the charges equals the cost less the residual value.

* * *

## Summary

> The summary restates the whole chapter in a few lines.

Depreciation spreads the cost of a plant asset over its useful life, after subtracting the residual value. The straight-line method charges an equal amount each year, the units-of-production method charges by use, and the declining-balance method charges a fixed percentage of the remaining cost. The charge is recorded as an expense and as accumulated depreciation. Book value is cost less accumulated depreciation, and the gain or loss on a sale is the proceeds minus the book value. For Meghna and Sons, the machine's straight-line charge is Tk 60,000 a year, and a sale after three years for Tk 120,000 gives a loss of Tk 30,000.

## Think It Through

:q 16.t1 | A manager raises the estimated life of the book-cutting machine from five years to eight years, with the same residual value. What happens to the yearly straight-line charge, to the profit of each year, and to the total charged over the whole life?

:q 16.t2 | A student says: "Depreciation sets aside cash for buying a new machine." Explain what is wrong with this statement.

## Where People Go Wrong

> Five common misunderstandings are stated here, each with its correction.

Some students believe that depreciation measures the fall in the market price of an asset. It does not: it spreads the cost over the years of use, by a rule. Others believe that depreciation is a payment of cash. It is not: the cash was paid when the asset was bought, and the yearly entry moves no cash. A third belief is that book value equals the price at which the asset could be sold. Book value is a figure in the records, and the market price may be higher or lower. A fourth belief is that a faster method gives a larger total charge. Over the whole life all methods charge the same total, and only the timing differs. Last, students sometimes depreciate land. Land is usually not depreciated, because it does not wear out in the same way.

## In History

> A book of 1850 about railways discussed the wearing out of locomotives and track.

In 1850, Dionysius Lardner published *Railway Economy* in London. Lardner was an Irish-born writer on science and engineering, who lived from 1793 to 1859.^2 The railways were then about twenty years old, and their owners had to decide how to treat the wearing out of locomotives, carriages and track. Lardner discussed how parts wear with use and must be replaced, and he described the cost of keeping a railway in repair.

^2: Accounts of the book and its author are given in articles on the history of accounting and railways. This chapter relies on those summaries and not on the text of the book itself.

> The railways showed that heavy equipment does not last for ever, so its cost belongs to many years.

Railway companies owned costly equipment that served for many years, which is the same situation as that of the book-cutting machine. Lardner's discussion is an early case for the idea of this chapter: when equipment wears out, a fair record charges a part of its cost to each year of service. The methods in this chapter, straight-line, declining-balance and units-of-production, are later ways of making that idea exact.

## Review Questions

:q 16.1 | A machine costs Tk 50,000, has a residual value of Tk 10,000 and a useful life of four years. Find the straight-line charge for a year and the book value after two years.

:q 16.2 | Equipment costs Tk 275,000 on 1 October 2026. Its residual value is Tk 25,000, its useful life is eight years, and its capacity is 400,000 units. The business closes its books on 31 December. Find the straight-line charge for 2026, and the units-of-production charge for 2026 if 36,000 units were produced.

:q 16.3 | An asset costs Tk 150,000 and is depreciated at 20% by the declining-balance method. Find the charge and the remaining cost for each of the first three years. After three years it is sold for Tk 80,000. Find the gain or loss.

:q 16.4 | A press costs Tk 240,000 on 1 January 2026, with a residual value of Tk 40,000 and a useful life of five years. Using straight-line depreciation, write the entry for 2026. At 31 December 2028 the press is sold for Tk 100,000. Find the gain or loss and write the entry for the sale.
