:chapter VI | The Trial Balance
:mood If every fact is written twice, can the books be tested against themselves?
:desc Every entry in the books has equal debits and credits, so the whole ledger must carry the same equality. This chapter shows how to list the ledger balances, test the equality, and find and fix a difference, using the January 2026 books of Meghna Binding Service.
:plate ch06-plate.svg | An accountant checking two columns of figures with a ruler and a magnifying glass

:box YOU WILL NEED
Chapter 5 'The Journal and the Ledger', section 5.3 'The Ledger and Posting'; Chapter 5 'The Journal and the Ledger', section 5.1 'The Accounting Cycle'; Appendix A1 'Maths You Will Use'.

> A second, independent count tests the first, and the ledger offers such a pair.

A shopkeeper closes for the evening and counts the coins in the till. Then the shopkeeper adds the till roll, the paper strip on which each sale was printed. If the two answers agree, the count is probably right. If they differ, something is wrong, and the shopkeeper knows to search. Neither answer proves anything alone, but two independent answers that agree give real comfort.

> After a month of posting, the bookkeeper needs a test that avoids rereading every line.

The books of a business offer a similar pair of answers. Every transaction was written with debits equal to credits. After a month of journalising and posting, a bookkeeper has hundreds of lines in many accounts. How can the bookkeeper learn, without rereading every line, whether a slip has occurred? And if a test says "wrong", how can the slip be found without starting again? This chapter answers both questions, and it also explains an uncomfortable truth: a test that says "right" does not prove that the books are perfect.

* * *

## 6.1 Preparing a Trial Balance

> The ledger should keep the equality of debits and credits that every entry has.

> Recall: ledger and posting, Chapter 5, section 5.3.

Recall that every journal entry has debits equal to credits, and that posting copies each debit and each credit to its account. If both jobs are done correctly, one result must follow: the total of all debits in the ledger equals the total of all credits. Let D be the total of all debit amounts posted and C the total of all credit amounts. Because each entry has equal sides, D = C. Balancing an account removes the same amount from both of its sides, so the equality survives. The total of the debit balances therefore equals the total of the credit balances.

> A tiny example with made-up figures shows the equality surviving the balancing.

Here is a tiny example with made-up figures. Entry one debits Cash and credits Owner's Equity for Tk 100. Entry two debits Rent and credits Cash for Tk 30. The debit total D is 100 + 30 = 130, and the credit total C is 100 + 30 = 130. After balancing, Cash is a debit of 100 − 30 = 70, Rent is a debit of 30, and Owner's Equity is a credit of 100. The debit balances total 70 + 30 = 100, and the credit balance is 100. The equality holds.

> Two everyday words take a special meaning in this chapter.

@ Balance | Word in use. In daily life, to keep steady, or the amount left in a bank account. In accounting, the difference between the two sides of an account.

@ Trial | Word in use. In daily life, a hearing in a court of law, or a test of something new. In accounting, a test of whether two totals are equal.

Two words need care. In everyday speech, a *balance* may be the amount left in a bank account. In accounting, the balance of an account is the difference between its two sides, as Chapter 5 showed. The word *trial* in everyday speech may mean a hearing in court. Here it means only a test. The test asks one question and gives a plain answer, but it is not a verdict on the books.

> A trial balance lists every ledger balance and compares the two column totals.

@ Trial balance | A list of all ledger account balances, with debits and credits totalled, to test that they are equal.

The list that carries out the test has a name. A **trial balance** is a list of all ledger account balances, with debits and credits totalled, to test that they are equal. The list has three parts: the name of each account, its balance in the Debit column if the balance is a debit, and its balance in the Credit column if the balance is a credit. At the foot, each column is added. The trial balance is taken at one date, so its heading reads "as at" that date.

> Preparing the list takes five steps, always in the same order.

The preparation has five steps. First, balance every account in the ledger, using the method of Chapter 5. Second, write the heading: the name of the business, the words "Trial Balance", and the date. Third, list each account with its balance in the correct column. Fourth, add each column. Fifth, compare the two totals. If they are equal, the test is passed. If they differ, the books contain a slip that must be found before the next step of the cycle.

> Accounts are listed in a fixed order, and accounts with no balance are left out.

The accounts are usually listed in the order of the ledger: assets first, then liabilities, owner's equity, revenue and expenses. An account with no balance, such as a suspense account that has been cleared, may be left off the list or shown with a dash. The order is a convention that makes lists easy to read and to compare from month to month. It does not affect the test.

> The figure that follows shows the layout, row by row.

> Recall: accounting cycle, Chapter 5, section 5.1.

The next figure shows the layout of a trial balance. Read it from the top. The first row holds the headings. The rows below hold one account each, with its balance in one of the two columns. A ruled line separates the accounts from the totals, and the totals sit in the last row, where the eye can compare them. A trial balance is step 4 of the accounting cycle.

:fig A trial balance as a two-column list with totals | ch06-fig01.svg

> The trial balance in this chapter is taken before any period-end adjustment.

@ Unadjusted trial balance | A trial balance taken before the period-end adjustments have been recorded.

The January list is an **unadjusted trial balance**: a trial balance taken before the period-end adjustments have been recorded. An adjustment is a change that brings the accounts up to date at the end of a period; Chapter 7, 'Adjusting the Accounts', teaches them. Every trial balance in this chapter is unadjusted, because no adjustment has yet been made.

> The January ledger is balanced first, then each balance is listed in its column.

:case Case file, illustrative. Given: Meghna Binding Service, trial balance as at 31 January 2026. Debit balances: Cash 245,000; Shelving 120,000; Inventory 200,000; Rent 60,000; Wages 35,000. Credit balances: Publisher Payable 120,000; Owner's Equity 500,000; Service Revenue 40,000. *Find:* the totals of the two columns, and whether they are equal.

> The formula is a plain addition of each column, followed by a comparison.

*Formula.* In words: the debit total is the sum of all debit balances, the credit total is the sum of all credit balances, and the test is passed when the two are equal. In symbols: DT = sum of debit balances; CT = sum of credit balances; the test is DT = CT. *Steps.* DT = 245,000 + 120,000 + 200,000 + 60,000 + 35,000 = Tk 660,000. CT = 120,000 + 500,000 + 40,000 = Tk 660,000. The table that follows sets out the list.

:table Trial balance of Meghna Binding Service as at 31 January 2026
| Account | Debit (Tk) | Credit (Tk) |
| Cash | 245,000 |  |
| Shelving | 120,000 |  |
| Inventory | 200,000 |  |
| Publisher Payable |  | 120,000 |
| Owner's Equity |  | 500,000 |
| Service Revenue |  | 40,000 |
| Rent | 60,000 |  |
| Wages | 35,000 |  |
| Totals | 660,000 | 660,000 |

> A trial balance is taken often, because later steps depend on it.

The test has a place in the cycle. Steps 5 to 8 of the accounting cycle build on the ledger balances, so an undetected slip at this point would travel into every later report. Taking the trial balance at the end of each month, or even each week, keeps the search for a slip short. In a small bookshop with few transactions, one list a month is enough; a busy business may take one daily.

> The answer and the check show a passed test that still proves less than it seems.

*Answer.* Both columns total Tk 660,000, so the test is passed. *Check.* A second sum in a different order helps: debits, 35,000 + 60,000 + 200,000 + 120,000 + 245,000 = 660,000. The same total appears. From the owner's viewpoint, the result is reassuring. From the viewpoint of a bank, it is a first sign of care, though not a proof that every figure is right, as section 6.2 explains.

> Common slips in preparing the list are easy to avoid with a tick for each account.

Common slips are few. A balance may be written in the wrong column. An account that has a balance may be left out. A digit may be added wrongly. Tick each ledger account as it is listed, and compare the number of accounts on the list with the number in the ledger.

> Different readers use the trial balance in different ways.

The trial balance serves several people inside the business. The bookkeeper uses it to learn whether posting went well. The owner, Nurul, uses it as a quick picture of what the accounts hold, though it is not a formal report. An employee who prepares the later steps of the cycle uses it as the starting list, because adjustments and statements are built from its figures. A bank usually asks for the formal reports rather than for this working paper.

:pause 6.p1 | Explain in your own words why the debit total of a trial balance must equal the credit total when every journal entry and every posting is correct.

> A short review of the trial balance and its preparation.

*Before moving on.* A trial balance lists all ledger balances in two columns and tests that the totals are equal. The test works because every entry has equal debits and credits. The five steps are: balance, head, list, add, compare.

* * *

## 6.2 What the Trial Balance Does Not Show

> A balanced list can still hide an error, as one missing entry shows.

Suppose that the rent payment of 15 January had never been written in the journal. Rent would show nothing, and Cash would show Tk 305,000 instead of Tk 245,000. The debit total would be 305,000 + 120,000 + 200,000 + 35,000 = Tk 660,000. The credit total would still be Tk 660,000. The test is passed, yet the books are wrong. This example is the central lesson of the section: the test checks equality, not truth.

> The test finds errors that put the totals out of line.

A framework helps. Divide errors into two groups. The first group changes only one side of the books, so the totals differ and the trial balance finds the error. Examples are a debit posted without its credit, an amount posted wrongly on one side only, a column added wrongly, and a balance listed in the wrong column. The second group changes both sides by the same amount, so the totals stay equal and the test says nothing.

> A table sets six kinds of error beside their effect on the totals.

The table that follows lists six kinds of error. Read a row from left to right: the kind of error, whether the totals differ, and an example from the January case. The example of the wrong account is a payment of wages debited to Rent. Rent would show Tk 95,000 and Wages nothing, but the debit total would remain Tk 660,000.

:table Six kinds of error and the trial balance
| Kind of error | Totals differ? | Example from the January case |
| One side of an entry not posted | Yes | The Rent debit of 60,000 is never posted; the debit total becomes 600,000 |
| Wrong amount on one side only | Yes | Wages posted as 53,000 on the debit side only |
| Whole transaction left out | No | The 15 January rent entry is never recorded |
| Same wrong amount on both sides | No | Wages and Cash both posted as 53,000 |
| Wrong account of the same type | No | Wages debited to Rent |
| Two errors that cancel | No | A debit too high by 10,000 and another too low by 10,000 |

> One common slip in copying digits has a name and a useful property.

@ Transposition error | A mistake in which two digits of a number are written in the wrong order, such as 53 for 35.

The wages example in the table is a special slip. A **transposition error** is a mistake in which two digits of a number are written in the wrong order, such as 53 for 35. It is common because the eye reads quickly and the hand writes quickly. Posted on one side only, it makes the totals differ by a number that always divides by 9. The reason is short. A two-digit number with digits a and b equals 10a + b. With the digits reversed it equals 10b + a. The difference is 9a − 9b = 9(a − b), which is a multiple of 9. For 53 and 35, the difference is 18 = 9 × 2.

> A difference divisible by 9 suggests a transposition but does not prove one.

The property has a limit. A difference that divides by 9 suggests a transposition, but other slips can also give such a difference, so the sign is a lead and not a proof. The rule also holds when the digits stand in thousands, as in 53,000 for 35,000, where the difference is 18,000. Always confirm by looking at the source document.

> Two errors can hide each other, and so equal totals cannot rule out several errors.

The last row of the table needs a word of explanation. Suppose one debit is posted Tk 10,000 too high, and another debit, in a different entry, is posted Tk 10,000 too low. The debit total rises by 10,000 and falls by 10,000, so it ends where it began. Such luck is rare, but it shows that equal totals cannot rule out several errors.

> A balanced list is a starting point for the auditor and a warning for the owner.

An auditor who reads a balanced trial balance treats it as a starting point and not as an end. The auditor tests source documents against the journal to find the errors that the totals cannot show. An owner who sees equal totals may feel safe, but a missing sale or a payment posted to the wrong account still spoils the reports. A careful bookkeeper therefore combines the test with other checks, such as confirming that every source document has been recorded.

> A short review of what the test finds and what it misses.

*Before moving on.* The trial balance finds errors that change one side only. It cannot find a missing transaction, an equal error on both sides, a wrong account of the same type, or errors that cancel. A transposition error on one side gives a difference divisible by 9.

* * *

## 6.3 Finding and Fixing Differences

> A difference of Tk 18,000 shows where a search for a slip begins.

Suppose the wages of 31 January were posted to the debit side of the Wages account as Tk 53,000, while the credit to Cash was posted correctly as Tk 35,000. The trial balance now shows a debit total of Tk 678,000 and a credit total of Tk 660,000. The difference is Tk 18,000. The bookkeeper holds one number and faces a long ledger. Where should the search begin?

> The search moves from the cheapest check to the most costly.

Locating a difference follows a fixed order, from the cheapest check to the most costly. First, add both columns again, in a different order. Second, test whether the difference is divisible by 9, which points to a transposition error. Third, test whether the difference equals one account balance, which points to a posting that was missed, and whether half of the difference equals a balance, which points to a balance listed in the wrong column. Fourth, compare every posting with the journal and tick each line that agrees. Fifth, recalculate each balance. Stop as soon as the cause is found.

> Two further differences show how the second and third checks work.

The checks have examples in the January ledger. Suppose the Rent debit of Tk 60,000 was never posted. The debit total would be Tk 600,000 against a credit total of Tk 660,000. The difference of Tk 60,000 equals one amount in the journal, so the bookkeeper would look for a missed posting of that size. Suppose instead that Service Revenue, a credit balance of Tk 40,000, were listed in the Debit column. The debit total would become Tk 700,000 and the credit total Tk 620,000. The difference of Tk 80,000 is twice Tk 40,000, so half of it points to a balance in the wrong column.

> Careful habits reduce the search.

The best search is the one that is never needed. Careful bookkeepers check each entry before posting, tick each journal line when it has been posted, and take a trial balance often, for example at the end of each week. A difference found among a week of entries is far easier to trace than a difference found among a year of them.

> Sometimes the search cannot finish before the reports are due.

@ Suspense account | A temporary account that holds a difference until its cause is found.

When time runs short, the bookkeeper may open a suspense account. A **suspense account** is a temporary account that holds a difference until its cause is found. If the credits fall short, the difference is entered as a credit balance in the suspense account. If the debits fall short, it is entered as a debit balance. The two column totals then agree. This is an honest device only if it stays temporary: the account must be cleared as soon as the cause is found, and it must never remain in the final reports.

> A found error is corrected by a new journal entry and never by erasing.

When the cause is found, the books are corrected by a new journal entry. The entry carries a narration and is posted like any other. The wrong figure is never rubbed out, because the books must stay readable to an auditor, who is a person that checks records for accuracy. A correcting entry usually has two parts. It removes the wrong amount from the account in which it was posted, and it clears the suspense account.

> A short review of the search, the suspense account and the correcting entry.

*Before moving on.* A difference is searched for in a fixed order: re-add, test for divisibility by 9, compare with one balance or half a balance, tick the postings, recalculate. A suspense account holds the difference for a short time. A correcting entry, never an erasure, fixes the error.

* * *

## Worked Example: The Wages Difference

> The case file gives an error to find and to fix.

:case Case file, illustrative. Given: the January 2026 ledger of Meghna Binding Service is correct except that the wages of 31 January were posted to the Wages account as Tk 53,000 instead of Tk 35,000. The credit to Cash was posted correctly. The correct trial balance totals Tk 660,000 on each side.

> The task is to find the difference, its cause and the correction.

*Find.* The trial balance totals with the error, the difference, its probable cause, and the entries that clear it.

> The two formulas are a subtraction and a divisibility test.

*Formula.* In words: the difference is the larger column total minus the smaller. In symbols: d = DT − CT, where DT is the debit total and CT is the credit total. A transposition of two digits gives d = 9(a − b), where a and b are the two digits, in the units of their place.

> Steps 1 and 2 find the totals and the difference.

*Steps.* Step 1: add the columns. The wrong debit balance for Wages is Tk 53,000, so DT = 245,000 + 120,000 + 200,000 + 60,000 + 53,000 = Tk 678,000. CT = 120,000 + 500,000 + 40,000 = Tk 660,000. Step 2: subtract. d = 678,000 − 660,000 = Tk 18,000, with the debits larger.

> Steps 3 and 4 test the difference and confirm the cause.

Step 3: test for 9. 18,000 ÷ 9 = 2,000, so the difference divides by 9. Step 4: look for the digits. Two numbers that differ by 18 in the thousands are 53 and 35, which are a transposition of each other. The payroll record, which is the source document, shows Tk 35,000. The cause is therefore a transposition error in the debit posting to Wages.

> Step 5 shows the trial balance with the difference held in suspense.

Step 5: hold the difference. The credits are short by Tk 18,000, so a credit balance of that amount is entered in a suspense account. The table that follows shows the list.

:table Trial balance as at 31 January 2026 with the error and a suspense account
| Account | Debit (Tk) | Credit (Tk) |
| Cash | 245,000 |  |
| Shelving | 120,000 |  |
| Inventory | 200,000 |  |
| Rent | 60,000 |  |
| Wages | 53,000 |  |
| Publisher Payable |  | 120,000 |
| Owner's Equity |  | 500,000 |
| Service Revenue |  | 40,000 |
| Suspense |  | 18,000 |
| Totals | 678,000 | 678,000 |

> Step 6 corrects the books with one journal entry.

Step 6: correct. Wages is too high by Tk 18,000, so Wages is credited by that amount. The suspense account is cleared by a debit of the same amount. The table that follows shows the journal entry.

:table The correcting entry
| Date | Particulars | Folio | Debit (Tk) | Credit (Tk) |
| 31 January 2026 | Suspense |  | 18,000 |  |
|  |   Wages |  |  | 18,000 |
|  | Narration: Corrected wages posted as 53,000 instead of 35,000, and cleared the suspense account. |  |  |  |

> The answer and the check agree with the case file.

*Answer.* After posting, Wages = 53,000 − 18,000 = Tk 35,000, and the suspense account = 18,000 − 18,000 = nil. The totals of the correct trial balance are Tk 660,000 on each side. *Check.* Wages now equals the Tk 35,000 of the source document. The suspense account has no balance. The debit total and the credit total both equal the Tk 660,000 of section 6.1.

> Common slips arise when the sign, the column or the unit is mixed up.

Common slips occur at this stage. A student may place the suspense balance on the wrong side, which doubles the difference instead of removing it. A student may correct the error by overwriting the figure in the Wages account, which hides the history. A student may forget to clear the suspense account, so that it stays in the books. Check the side, the entry and the final balance of Suspense, in that order.

* * *

## Summary

> The chapter's main ideas in a few lines.

A trial balance lists all ledger balances in two columns and tests that the debit total equals the credit total. It is step 4 of the accounting cycle. Taken before adjustments, it is an unadjusted trial balance. The test finds errors that change one side only, and it cannot find omissions or equal errors on both sides. A transposition error gives a difference divisible by 9. A difference may be held in a suspense account, and a correcting entry then removes the error.

## Think It Through

:q 6.t1 | Name two errors that leave a trial balance in balance. For each, give an example from the January ledger of Meghna Binding Service and say what would still be wrong.

## Where People Go Wrong

> A balanced trial balance does not prove the books are right.

Many students believe that a balanced trial balance proves that the books are correct. It proves only that the debit balances and the credit balances are equal. Missing entries and equal errors on both sides remain hidden.

> The difference is not always the size of the error.

A second error is to assume that the difference equals the error. A transposition error of 53 for 35 makes an error of 18, which equals the difference only because the credit was right. A balance in the wrong column makes the difference twice the balance.

> The suspense account is not a place to leave a problem.

A third error is to leave the difference in the suspense account and carry on. The account is temporary. Its balance must be explained and cleared before reports are prepared.

> A trial balance is a test and not a financial statement.

A fourth confusion is to treat the trial balance as the balance sheet. The trial balance is a working list for testing the books. The balance sheet is a formal report taught in Chapter 9, 'Financial Statements and Closing Entries'.

## In History

> A Flemish mathematician argued that a ruler's accounts also need method.

Simon Stevin was born in Bruges, in Flanders, in 1548 and died in 1620. He was a mathematician and engineer who served as tutor and adviser to Prince Maurice of Nassau, the military leader of the Dutch Republic. Stevin wrote on many subjects, among them bookkeeping. His book on the subject, usually called *Princely Bookkeeping*, was printed in Leiden in the first decade of the seventeenth century, with a French edition in 1608.

> Stevin wanted a state to keep its books by the method of merchants.

Stevin urged that the household and finances of a prince be recorded by the double-entry method that merchants already used, and he put the method into practice for Prince Maurice. The idea behind a trial balance is the same idea: the books of a business or a state should be tested against themselves at regular times, so that slips are found by method and not by chance.

## Review Questions

:q 6.1 | Prepare a trial balance as at 31 March 2026 from these balances: Cash Tk 50,000 debit; Equipment Tk 30,000 debit; Owner's Equity Tk 80,000 credit. State whether the totals are equal.
:q 6.2 | Prepare a trial balance from these balances and state whether it is balanced: Cash 187,450 debit; Inventory 96,300 debit; Equipment 150,000 debit; Rent 42,000 debit; Wages 78,500 debit; Publisher Payable 64,250 credit; Owner's Equity 400,000 credit; Service Revenue 90,000 credit.
:q 6.3 | A trial balance shows a debit total of Tk 458,900 and a credit total of Tk 465,500. Find the difference. Is it divisible by 9? What does half of it suggest?
:q 6.4 | The credit total of a trial balance is Tk 7,200 larger than the debit total. State the suspense account balance that would be added and on which side.
:q 6.5 | Rent of Tk 18,000 was posted to the debit side of the Rent account as Tk 81,000, and the credit to Cash was correct. Find the difference, say on which side the suspense balance goes, and write the correcting entry with its narration.

:read Stevin, Simon, Vorstelicke Bouckhouding (Princely Bookkeeping), early seventeenth century
