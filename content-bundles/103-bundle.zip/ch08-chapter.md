:chapter VIII | The Worksheet
:mood How can an accountant test every change on paper before touching a single record?
:desc A large ruled sheet carries figures from the trial balance through the adjustments to the statements. This chapter builds its ten columns one pair at a time, extends each balance, and teaches the checks that reveal a hidden mistake.
:plate ch08-plate.svg | A clerk at a very wide ruled sheet, with an abacus beside him

:box YOU WILL NEED
Chapter 7 'Adjusting the Accounts', section 7.4 'Recording Adjusting Entries'; Chapter 6 'The Trial Balance', section 6.1 'Preparing a Trial Balance'; Appendix A1 'Maths You Will Use'.

> A year-end clerk holds correct balances that are not yet ready to use.

It is the evening of 31 December, and a clerk in a small office is holding the trial balance. It lists eighteen accounts, and the debit total equals the credit total. Yet the balances are not ready to use. Some supplies have been consumed, some wages are owed, and the equipment has lost part of its value. Six changes must be made before anyone can learn what the business gained or lost during the year.

> Changing the records directly, and drafting the statements early, are both risky.

The clerk could write each change into the ledger at once. But suppose the third change contains an error. The ledger now holds a wrong figure, and correcting it leaves crossings-out on a record that other people must trust. The clerk could also draft the final statements straight away. But the statements need the changed figures, so a late discovery means writing every statement a second time.

> The question of the chapter: how can every change be tested on paper first?

So here is the question for this chapter. How can an accountant try every change, see every result and find every error, without writing in any permanent record? Think about a difficult sum at home. You take a spare sheet of paper, write the figures in columns and work there, and only then write the answer neatly. Accountants do the same. Their spare sheet has a name, and it has an exact layout. By the end of this chapter you will be able to build it, complete it and check it.

## Why Use a Worksheet

@! Go slowly here.
> A family budget on a rough sheet shows the idea before the subject.

Before meeting the subject idea, consider a family that is planning a wedding. On a large sheet of paper, the family lists every cost. Beside the list is a column headed "first estimate". Next to it is a column headed "changes", where the family enters a rise in the hall price and a cousin who has cancelled. A third column shows the new estimate. Only when the whole sheet is complete does the family write the final budget on a clean page. The large sheet is rough, and mistakes on it cost little. The clean page is the one that other people will read.

> A worksheet is a working paper that carries figures from the trial balance to the statements.
@ Sheet | Word in use. In daily life, a flat piece of paper or cloth. In accounting, the large ruled page, or its computer copy, on which a worksheet is drawn.
@ Worksheet | A working paper with columns that moves figures from the trial balance through adjustments to the statements.

The accountant's method follows the same pattern, and the rough sheet has a name. A **worksheet** is a working paper with columns that moves figures from the trial balance through the adjustments to the statements. For example, a worksheet may show Supplies as Tk 1,000 in one column and Tk 400 in a later column, so that a reader sees the figure before and after a change. Notice the word "working". The worksheet is where the work is done. It is not where the answer is published. The family's first estimate matches the trial balance, the changes match the adjustments, and the clean page matches the statements.

> Recall: adjusting entries, Chapter 7, section 7.4 'Recording Adjusting Entries'.
> A worksheet has three jobs: to gather, to test and to check.

A worksheet does three jobs, and each one answers a worry from the opening puzzle. The first job is to gather. All the account balances stand on one page, in one order, so the clerk does not turn between ledger pages. The second job is to test. The clerk can enter the six changes on the worksheet and see their effect before recording any of them in the journal. The third job is to check. Equal totals at each stage show whether the arithmetic is sound, and the last columns show the result of the period before any statement is drafted.

> The same idea in numbers: a Tk 600 change is tested without touching the ledger.

Here is the idea in the smallest possible numbers. Supplies show Tk 1,000 in the trial balance, and Tk 600 of them have been used. On the worksheet we enter Tk 600 as a credit to Supplies, and we see at once that Tk 400 remain. Nothing in the ledger has changed. If we had made an arithmetic slip, we would correct it on the worksheet and begin again at no cost.

> Owner, manager, clerk and outsider value the worksheet in different ways.

Different people value these jobs in different ways. The owner wants to know the result of the year early, before the statements are ready. The clerk wants to avoid rewriting, because a worksheet error is corrected on the sheet itself, while a ledger error needs a formal correction. A bank or a customer never sees the worksheet at all, because it is private working paper.

@! Go slowly here.
> The worksheet is private working paper; it is not a financial statement.

A worksheet is not a statement. This difference is easy to forget, because the worksheet holds the same figures that later appear in the statements. A financial statement is a formal report for outside readers. In this book we prepare two of them, and Chapter 9, 'Financial Statements and Closing Entries', teaches them fully. For now, here are short previews in plain words. The income statement lists the revenue and the expenses of a period. The balance sheet lists what the business owns and owes on one date. The worksheet only prepares the figures that these two statements need.

> The worksheet changes no record, and it has limits.

Because the worksheet is working paper, it changes no account. The ledger keeps its old balances until the adjusting entries are recorded in the journal and posted, as Chapter 7, section 7.4 'Recording Adjusting Entries' explains. A worksheet is also optional: a small business may omit it, and a computer program may perform the same task without showing it. Finally, a worksheet has limits. Equal totals show that debits equal credits, but they cannot show that an amount sits in the right account. A cost entered in the wrong account leaves the totals equal. A clerk must never hide a difference in a suspense account merely to make the totals agree.

> The recap restates the three jobs, the private status and the limits.

*Before moving on.* A worksheet is a working paper with columns. It gathers balances, tests the adjustments and checks the arithmetic, and it is private. It is not a statement, and it changes no ledger account. Equal totals do not prove that every amount is in the right account. *You should now be able to say* why an accountant uses a worksheet before the statements, and why it changes no record.

## Building the Ten Columns

> A tiny repair stall gives clean numbers for learning the method.

We now build a worksheet one pair of columns at a time. To keep the arithmetic small, we use a repair stall that exists only for teaching; it is not part of the running case. At the end of its year, the stall's trial balance shows these debit balances: Cash Tk 5,000, Supplies Tk 1,000, Equipment Tk 6,000 and Wages Tk 2,000. It shows these credit balances: Capital Tk 8,000 and Repair Revenue Tk 6,000. Each side totals Tk 14,000. Three changes are needed. Supplies worth Tk 600 have been used, wages of Tk 300 are owed, and the equipment has lost Tk 500 of its value.

> The figure shows five pairs of columns, read from left to right.

Before filling any column, look at the layout. The worksheet has one column for account titles and then five pairs of columns, which makes ten numbered columns. Each pair has a debit column and a credit column. The figure below shows the layout. To read it, begin at the left and move right. Each box names a pair of columns, and the numbers 1 to 10 show the order of the columns. The two hatched pairs on the right are the statement columns. In the tables of this chapter, Dr stands for debit and Cr stands for credit.

:fig Ten-column worksheet layout with column headings | ch08-fig01.svg

> Recall: trial balance, Chapter 6, section 6.1 'Preparing a Trial Balance'.
> Step 1 copies the trial balance into columns 1 and 2 and checks the totals.

The first pair is the trial balance columns. In step 1, we copy every account title and balance from the trial balance, debits into column 1 and credits into column 2. Then we total both columns. The totals must agree before we go further, because an error here would travel through the whole worksheet. For the stall, Tk 14,000 equals Tk 14,000, so we continue. Below the last account we leave blank rows for accounts that the adjustments will create, such as Supplies Expense. Their cells in columns 1 and 2 stay empty, because the ledger holds no balance for them yet. If the totals disagree, stop and find the error first. A transposition error is a common cause.

> Recall: accrual basis of accounting and the matching principle.
> Step 2 enters each adjustment as an equal debit and credit in columns 3 and 4.

The second pair is the adjustments columns, and here the worksheet shows its purpose. Under the accrual basis of accounting, each accounting period must carry its own revenue and expenses, and the matching principle places an expense in the period that earned the related revenue. The adjustments make this happen. In step 2, we enter each adjustment as a debit in column 3 and an equal credit in column 4. We label both parts with the same small letter, so that a reader can pair them. Adjustment (a): debit Supplies Expense Tk 600 and credit Supplies Tk 600. Adjustment (b): debit Wages Tk 300 and credit Wages Payable Tk 300. Adjustment (c): debit Depreciation Expense Tk 500 and credit Accumulated Depreciation Tk 500.

> The adjustments columns must total equally, and they are not yet in the ledger.

Now we total columns 3 and 4. Each equals Tk 1,400, and they must agree, because every adjustment has the same amount on both sides. Remember the limit from section 8.1: the worksheet only shows the adjustments. The entries must still be recorded in the journal and posted.

@! Go slowly here.
> The adjusted trial balance shows the correct balance of each account after the changes.
@ Adjusted trial balance | A trial balance prepared after adjusting entries, showing the correct balance of each account.

The third pair is the **adjusted trial balance**. An adjusted trial balance is a trial balance prepared after the adjusting entries, showing the correct balance of each account. For example, Supplies stand at Tk 1,000 in column 1; after the Tk 600 credit in column 4, the adjusted trial balance shows Tk 400 in column 5. Step 3 finds each of these balances by combining the first two pairs, one row at a time.

> The combining rule: add figures on the same side, subtract figures on opposite sides.

The rule for step 3 has two parts. If the balance and the adjustment stand on the same side, add them. Wages is a debit of Tk 2,000, and adjustment (b) adds a debit of Tk 300, so the adjusted balance is a debit of Tk 2,300. If they stand on opposite sides, subtract the smaller from the larger, and place the answer on the larger side. Supplies is a debit of Tk 1,000 and a credit of Tk 600, so the answer is a debit of Tk 400. A row with only an adjustment, such as Wages Payable, keeps that figure on its own side.

> The table shows columns 1 to 6 for the stall; read each row from left to right.

The table below shows the stall's worksheet through column 6. Read each row from left to right. For Supplies, Tk 1,000 is a debit in column 1. The letter (a) beside Tk 600 marks a credit in column 4. The result, Tk 400, is a debit in column 5. The bottom row shows that every pair of columns has equal totals, and the adjusted trial balance totals Tk 14,800 on each side.

:table Stall worksheet, columns 1 to 6 (taka)
| Account | Trial balance Dr | Trial balance Cr | Adjustments Dr | Adjustments Cr | Adjusted Dr | Adjusted Cr |
| Cash | 5,000 | | | | 5,000 | |
| Supplies | 1,000 | | | (a) 600 | 400 | |
| Equipment | 6,000 | | | | 6,000 | |
| Capital | | 8,000 | | | | 8,000 |
| Repair Revenue | | 6,000 | | | | 6,000 |
| Wages | 2,000 | | (b) 300 | | 2,300 | |
| Supplies Expense | | | (a) 600 | | 600 | |
| Depreciation Expense | | | (c) 500 | | 500 | |
| Wages Payable | | | | (b) 300 | | 300 |
| Accumulated Depreciation | | | | (c) 500 | | 500 |
| Totals | 14,000 | 14,000 | 1,400 | 1,400 | 14,800 | 14,800 |

:pause 8.p1 | In the stall's worksheet, what is the adjusted balance of Supplies, and on which side does it stand?

> In one line: the adjusted trial balance is the trial balance after the changes, with equal totals.

*In one line.* The adjusted trial balance combines columns 1 to 4 row by row, and its two totals must agree before we move on.

@! Go slowly here.
> Step 4 sends each adjusted balance to exactly one statement column.

The fourth and fifth pairs are the statement columns. In step 4, every adjusted balance is copied to one column only, and the kind of account decides which. Revenue and expense accounts go to the income statement columns, which are 7 and 8. Asset, liability and owner's equity accounts go to the balance sheet columns, which are 9 and 10. Within each pair, a debit balance stays a debit and a credit balance stays a credit.

> The table shows where each kind of account is entered.

The table below shows the destination of each kind of account. Read a row from left to right: the kind of account, the side on which its balance normally stands, and the columns that receive it.

:table Where each kind of account is entered
| Kind of account | Normal side | Statement columns |
| Asset, for example Cash | Debit | Balance sheet, debit |
| Accumulated Depreciation | Credit | Balance sheet, credit |
| Liability, for example Wages Payable | Credit | Balance sheet, credit |
| Capital | Credit | Balance sheet, credit |
| Drawings | Debit | Balance sheet, debit |
| Revenue | Credit | Income statement, credit |
| Expense | Debit | Income statement, debit |

> Two accounts cause most confusion, and some offices use fewer columns.

Two rows need care. Accumulated Depreciation is not a liability; it is a credit balance that reduces the Equipment on the balance sheet, so it goes to the balance sheet credit column. Drawings is a debit balance, but it is not an expense, because it records money taken out by the owner. It reduces owner's equity, so it goes to the balance sheet debit column. Finally, some offices use fewer columns than ten.^1 We use ten because the adjusted trial balance then has its own pair of totals, and each pair is easier to check.

^1: Some offices use eight columns, leaving out the adjusted trial balance pair and extending each balance straight from the first two pairs. The method is shorter, but an error is harder to locate.

> The recap restates the five pairs and the four steps.

*Before moving on.* The worksheet has five pairs of columns: trial balance, adjustments, adjusted trial balance, income statement and balance sheet. Step 1 copies the trial balance. Step 2 enters the adjustments. Step 3 combines them into the adjusted trial balance. Step 4 sends each balance to one statement column. *You should now be able to say* what each pair of columns holds and which accounts go to the income statement columns.

* * *

## Worked Worksheet

> We finish the stall first, with small numbers, then complete the running case.

We now complete the worksheet. This section has three tasks: to extend each balance, to total the columns and find the result of the year, and to check the worksheet. We begin with the stall again, because its figures are small, and then we turn to the running case. Take each task slowly, and notice that none of them needs a new idea. They need only care.

> Given and Find: the stall's adjusted balances, and the statement columns to complete.

*Given.* The stall's adjusted trial balance from section 8.2. The debits are Cash 5,000, Supplies 400, Equipment 6,000, Wages 2,300, Supplies Expense 600 and Depreciation Expense 500. The credits are Capital 8,000, Repair Revenue 6,000, Wages Payable 300 and Accumulated Depreciation 500. All figures are in taka. *Find.* The income statement columns, the balance sheet columns and the result of the year.

@ Extend | Word in use. In daily life, to make something longer or to allow more time. In accounting, to copy an adjusted balance into the correct statement column.
> Extending a balance means copying it to one statement column on its own side.

To extend a balance needs no calculation, only care. Wages 2,300, Supplies Expense 600 and Depreciation Expense 500 are expenses, so each is a debit in column 7. Repair Revenue 6,000 is revenue, so it is a credit in column 8. Cash 5,000, Supplies 400 and Equipment 6,000 are assets, so they are debits in column 9. Capital 8,000, Wages Payable 300 and Accumulated Depreciation 500 are credits in column 10. Every adjusted balance appears once, and only once.

@! Go slowly here.
> Net income is the amount by which revenue exceeds expenses.
@ Net income | The amount by which total revenue exceeds total expenses for a period.

Now we total columns 7 and 8. The difference between them is the result of the year, and it has a name. **Net income** is the amount by which total revenue exceeds total expenses for a period. For example, if the stall earns Tk 6,000 and its expenses are Tk 3,400, its net income is Tk 2,600.

> The formula for net income, in words and in symbols.

*Formula.* In words: net income equals total revenue minus total expenses. In symbols, NI = R − E. Here NI stands for net income, R stands for total revenue and E stands for total expenses.

> Steps, answer and check for the stall: net income is Tk 2,600.

*Steps.* Column 7 total: E = Tk 2,300 + Tk 600 + Tk 500 = Tk 3,400. Column 8 total: R = Tk 6,000. Then NI = Tk 6,000 − Tk 3,400 = Tk 2,600. *Answer.* The stall's net income is Tk 2,600. *Check.* Enter Tk 2,600 under column 7, on the debit side, so that column 7 totals Tk 6,000 like column 8. Enter Tk 2,600 under column 10, on the credit side. Column 9 totals Tk 11,400, and column 10 totals Tk 8,800 + Tk 2,600 = Tk 11,400.

> The balancing figure goes to opposite sides because net income increases owner's equity.

Why does Tk 2,600 appear twice, on opposite sides? In the income columns, the debit side is short by Tk 2,600, so the figure balances that pair. In the balance sheet columns, net income increases owner's equity, and owner's equity has a credit balance, so the figure belongs on the credit side. One amount, two columns, opposite sides.

:pause 8.p2 | The stall's income columns total Tk 3,400 (debit) and Tk 6,000 (credit). On which side of the income columns is the balancing figure placed, and why?

> Net loss is the opposite case, with expenses above revenue.
@ Net loss | The amount by which total expenses exceed total revenue for a period.

A period can also end badly. A **net loss** is the amount by which total expenses exceed total revenue for a period. For example, if the stall earned Tk 3,000 in a slow quarter and its expenses were Tk 3,400, its net loss would be Tk 400. The formula reverses: NL = E − R. The balancing figure now goes to the credit side of the income columns and to the debit side of the balance sheet columns, because a loss reduces owner's equity.

> Three checks show whether a worksheet is sound, and each has limits.

A worksheet is checked three times. First, the totals of columns 1 and 2, of columns 3 and 4, and of columns 5 and 6 must agree. Second, after the balancing figure is added, columns 7 and 8 must agree, and columns 9 and 10 must agree. Third, the balancing figure under the income columns must equal the one under the balance sheet columns, on opposite sides. These checks catch arithmetic slips and extension errors. They do not catch an amount placed in the wrong account, because the totals still agree.

> The case file gives the adjusted balances of the running case.

:case Case file, illustrative. Meghna and Sons uses the dataset of the Chapter 7 case. After the adjustments, the balances are, in taka: Cash 150,000; Accounts Receivable 110,000; Supplies 15,000; Prepaid Insurance 27,000; Equipment 360,000; Accumulated Depreciation 72,000; Accounts Payable 60,000; Wages Payable 14,000; Unearned Revenue 12,000; Capital 400,000; Drawings 80,000; Service Revenue 788,000; Wages 344,000; Rent 120,000; Utilities 26,000; Supplies Expense 33,000; Insurance Expense 9,000; Depreciation Expense 72,000. The file records total expenses of 604,000 and net income of 788,000 - 604,000 = Tk 184,000.

> The table extends each case balance, and the bottom rows give the totals.

The first four columns of this worksheet hold the unadjusted balances and the adjusting entries, which Chapter 7, section 7.4 'Recording Adjusting Entries' records. Here we begin at the adjusted trial balance, in columns 5 and 6, and extend every balance. Read each row from left to right. Cash is a debit of 150,000 in column 5, and it is extended to column 9. Service Revenue is a credit in column 6, and it is extended to column 8.

:table Meghna and Sons worksheet, columns 5 to 10 (taka)
| Account | Adjusted Dr | Adjusted Cr | Income Dr | Income Cr | Balance sheet Dr | Balance sheet Cr |
| Cash | 150,000 | | | | 150,000 | |
| Accounts Receivable | 110,000 | | | | 110,000 | |
| Supplies | 15,000 | | | | 15,000 | |
| Prepaid Insurance | 27,000 | | | | 27,000 | |
| Equipment | 360,000 | | | | 360,000 | |
| Accumulated Depreciation | | 72,000 | | | | 72,000 |
| Accounts Payable | | 60,000 | | | | 60,000 |
| Wages Payable | | 14,000 | | | | 14,000 |
| Unearned Revenue | | 12,000 | | | | 12,000 |
| Capital | | 400,000 | | | | 400,000 |
| Drawings | 80,000 | | | | 80,000 | |
| Service Revenue | | 788,000 | | 788,000 | | |
| Wages | 344,000 | | 344,000 | | | |
| Rent | 120,000 | | 120,000 | | | |
| Utilities | 26,000 | | 26,000 | | | |
| Supplies Expense | 33,000 | | 33,000 | | | |
| Insurance Expense | 9,000 | | 9,000 | | | |
| Depreciation Expense | 72,000 | | 72,000 | | | |
| Totals | 1,346,000 | 1,346,000 | 604,000 | 788,000 | 742,000 | 558,000 |
| Net income | | | 184,000 | | | 184,000 |
| Final totals | | | 788,000 | 788,000 | 742,000 | 742,000 |

> Steps and answer: expenses Tk 604,000, net income Tk 184,000, both pairs balanced.

*Steps.* Columns 5 and 6 each total Tk 1,346,000. Column 7 totals Tk 344,000 + Tk 120,000 + Tk 26,000 + Tk 33,000 + Tk 9,000 + Tk 72,000 = Tk 604,000. Column 8 holds Service Revenue of Tk 788,000. So NI = Tk 788,000 − Tk 604,000 = Tk 184,000, which we enter under column 7 and under column 10. Column 9 totals Tk 742,000. Column 10 totals Tk 72,000 + Tk 60,000 + Tk 14,000 + Tk 12,000 + Tk 400,000 = Tk 558,000 before net income, and Tk 742,000 after it. *Answer.* Net income is Tk 184,000, the same as the case file.

> A second check with the accounting equation confirms the result.

*Check.* The worksheet checks pass, and we can test the result a second way. Assets less Accumulated Depreciation are Tk 662,000 − Tk 72,000 = Tk 590,000. Liabilities are Tk 60,000 + Tk 14,000 + Tk 12,000 = Tk 86,000. Owner's equity is Tk 400,000 + Tk 184,000 − Tk 80,000 = Tk 504,000. Then Tk 86,000 + Tk 504,000 = Tk 590,000, so the accounting equation holds.

:box IN SHORT
A worksheet moves figures through five pairs of columns: trial balance, adjustments, adjusted trial balance, income statement and balance sheet. Net income is revenue minus expenses, and it is entered on the debit side of the income columns and the credit side of the balance sheet columns.

> Common slips: a wrong column, a wrong side, a forgotten account and a mixed-up sign.

Many students find the last step confusing, because one amount appears in two places. These are the common slips. Some students extend a debit balance into a credit column. Some treat Drawings as an expense and extend it to the income columns. Some forget an account that came from an adjustment, such as Wages Payable. Some place a net loss on the same sides as a net income, which reverses the sign. Finally, some mix units, for example by writing 3,500 for a figure that is in thousands of taka. Name each slip before you begin, and you will notice it when it occurs.

> The recap restates extending, finding net income or loss, and checking.

*Before moving on.* To extend a balance, copy it to one statement column on its own side. Net income is revenue minus expenses, and net loss is expenses minus revenue. The balancing figure appears on opposite sides in the income columns and the balance sheet columns. Three checks test the worksheet, and none of them finds an amount in the wrong account. *You should now be able to say* where net income is entered, and why it is entered twice.

* * *

## Summary

> The chapter in a few lines: five pairs of columns, one result, three checks.

A worksheet is a working paper with columns. It moves the figures of the trial balance through the adjustments, the adjusted trial balance and the statement columns, without changing any ledger account. Net income is total revenue minus total expenses, and net loss is the reverse. The balancing figure is entered twice, on opposite sides. Equal totals check the arithmetic, but they cannot show that an amount is in the right account.

## Think It Through

:q 8.t1 | A clerk extends the stall's balances. The balance sheet columns total Tk 11,400 (debit) and Tk 8,500 (credit) before net income. Net income of Tk 2,600 is added to the credit side. Find the difference between the two totals, name the stall account with the same balance, and say what you would check first.

:q 8.t2 | The stall's adjusted trial balance shows a debit total of Tk 14,530 and a credit total of Tk 14,800. Find the difference. Is it divisible by 9? What kind of error does this suggest, and which balance is the likely cause?

## Where People Go Wrong

> Misunderstanding: the worksheet records the adjusting entries in the ledger.

Some students believe that the worksheet records the adjusting entries. It does not. The worksheet only shows the adjustments, so that they can be tested. The entries must still be recorded in the journal and posted to the ledger, or the ledger will keep its old balances.

> Misunderstanding: Drawings belong to the income statement columns.

Some students extend Drawings to the income statement columns, because it looks like a cost. Drawings is money taken out by the owner. It is not an expense, and it reduces owner's equity. It belongs in the balance sheet debit column.

> Misunderstanding: net income is entered once, on the same side everywhere.

Some students enter net income on the debit side of both pairs of statement columns. The income columns need it on the debit side to balance, but the balance sheet columns need it on the credit side, because it increases owner's equity. A net loss reverses both sides.

> Misunderstanding: equal totals prove that the worksheet is correct.

Some students believe that equal totals prove a worksheet correct. They prove only that debits equal credits. A cost entered in the wrong account, or an amount left out of both sides, leaves the totals equal. The totals are a necessary test, not a sufficient one.

## In History

> In 1979 two Americans built an electronic version of the accountant's columnar worksheet.

In 1979, Dan Bricklin and Bob Frankston wrote VisiCalc, the first electronic spreadsheet for the Apple II. Bricklin was then a student at Harvard Business School, in Massachusetts, in the United States. Frankston was a programmer. The Apple II was a small personal computer, sold to homes and offices. Their program was built from the accountant's columnar worksheet. It gave the computer the same columns and rows that an accountant draws on a large ruled sheet, and it recalculated the dependent figures whenever one figure changed.^2

^2: Software Arts was the company that Bricklin and Frankston formed to develop the program. A firm called Personal Software sold it.

> The modern spreadsheet keeps the logic of the paper worksheet.

Today, the worksheet of this chapter often lives on a computer screen. A clerk who changes one adjustment sees every total change at once. Yet the logic has not changed. Figures still move from left to right through the same pairs of columns, and the same equal-total checks still apply. A machine calculates faster than a clerk, but it cannot tell whether an amount sits in the right account. That judgement remains with you.

## Review Questions

:q 8.1 | Clean numbers. A business has these unadjusted balances: Cash Tk 3,000, Prepaid Insurance Tk 1,200 and Wages Tk 3,000 (debits); Capital Tk 3,200 and Fees Revenue Tk 4,000 (credits). Insurance of Tk 300 has expired. Complete the ten-column worksheet and state the net income.

:q 8.2 | Realistic data. The unadjusted balances are, in taka: Cash 24,500; Accounts Receivable 18,300; Supplies 4,200; Equipment 48,000; Drawings 6,000; Wages 17,200; Rent 4,800; Utilities 2,000 (debits); Accounts Payable 9,600; Capital 54,000; Fees Revenue 61,400 (credits). Supplies on hand at the end are Tk 1,500; wages owed are Tk 1,300; depreciation of equipment is Tk 4,800. Complete the worksheet and state the net income.

:q 8.3 | Changed sign and unit. For one quarter, the income columns total 21,500 (debit) and 18,000 (credit), and the balance sheet columns, before the balancing figure, total 40,000 (debit) and 43,500 (credit). All figures are in thousands of taka. State the result, the column that receives it in each pair, and the amount in full taka.

:q 8.4 | Combined problem. The unadjusted balances are, in taka: Cash 9,000; Equipment 12,000; Prepaid Insurance 1,800; Wages 3,000 (debits); Capital 17,400; Unearned Revenue 2,400; Fees Revenue 6,000 (credits). Adjustments: (a) insurance of 900 has expired; (b) fees of 1,500 in Unearned Revenue are now earned; (c) depreciation is 1,200; (d) wages of 400 are owed. Complete the worksheet and state the net income.

:q 8.5 | Name two jobs that a worksheet does and a ledger alone does not. Then explain why the worksheet does not change any account.
