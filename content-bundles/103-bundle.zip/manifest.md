:bundle
status: ok
failures: 0
chapters: 20
appendix: none
changed-duplicates-resolved: 0
glossary-duplicates-removed: 0
chapter | ch01 | I | Business Activity and Companies | 3298 | 1 | 5 | 11
chapter | ch02 | II | What Accounting Is | 3373 | 1 | 9 | 7
chapter | ch03 | III | The Accounting Equation | 3017 | 2 | 8 | 9
chapter | ch04 | IV | Accounts, Debits and Credits | 3263 | 2 | 7 | 9
chapter | ch05 | V | The Journal and the Ledger | 2693 | 2 | 7 | 7
chapter | ch06 | VI | The Trial Balance | 3217 | 1 | 4 | 7
chapter | ch07 | VII | Adjusting the Accounts | 3710 | 2 | 8 | 8
chapter | ch08 | VIII | The Worksheet | 3574 | 1 | 4 | 9
chapter | ch09 | IX | Financial Statements and Closing Entries | 3470 | 2 | 8 | 9
chapter | ch10 | X | Accounts of a Merchandising Company | 3327 | 2 | 10 | 10
chapter | ch11 | XI | Special Journals | 3266 | 1 | 5 | 8
chapter | ch12 | XII | The Cash Book and Bank Reconciliation | 3436 | 1 | 7 | 7
chapter | ch13 | XIII | Inventory: Meaning and Measurement | 3374 | 1 | 7 | 8
chapter | ch14 | XIV | Costing Inventory: FIFO, LIFO and Weighted Average | 3704 | 2 | 5 | 8
chapter | ch15 | XV | Plant Assets | 3272 | 1 | 5 | 7
chapter | ch16 | XVI | Depreciation | 3489 | 2 | 8 | 8
chapter | ch17 | XVII | Accounts of Clubs and Sole Traders | 3309 | 1 | 5 | 7
chapter | ch18 | XVIII | Partnership Accounts | 2838 | 1 | 6 | 8
chapter | ch19 | XIX | Company Accounts: Shares | 2962 | 1 | 8 | 7
chapter | ch20 | XX | The Whole Cycle and Reporting Periods | 3144 | 1 | 4 | 9
