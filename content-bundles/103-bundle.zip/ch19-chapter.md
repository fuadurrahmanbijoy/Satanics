:chapter XIX | Company Accounts: Shares
:mood How can a thousand strangers own one business together?
:desc This chapter explains how a company raises money by selling shares. It shows what share capital is, how ordinary and preference shares differ, and how an issue of shares is recorded from application to allotment, including the share premium. Every entry is worked by hand, from small numbers to a realistic case.
:plate ch19-plate.svg | A registrar's clerk writes share certificates beside a copying press

:box YOU WILL NEED
Chapter 9, 'Financial Statements and Closing Entries', section 9.3 'Reversing Entries'; Chapter 18, 'Partnership Accounts', section 18.1 'Forming a Partnership'; Appendix A1, 'Maths You Will Use'.

> A bookshop needs far more money than its four partners own, so it looks to many small contributors.
Suppose a bookshop wishes to open ten new branches. The cost is Tk 5,000,000. The four partners who own it have already put in all the money they can spare. A thousand neighbours would each be willing to give Tk 5,000, if they could be sure of a fair return. Yet the partners cannot ask a thousand people to become partners. A deed with a thousand names would be impossible to write, and in many countries every partner is personally responsible for the firm's debts. No sensible neighbour would accept that risk for Tk 5,000.

> The puzzle is to give each contributor a small, equal piece of the business and a firm limit on the risk.
What arrangement would be attractive to the neighbours and safe for the partners? Each neighbour needs a small piece of the business, a paper to prove it, a claim on profit, and a promise that the loss can never be more than the money paid. The partners need a way to keep control of the shop while they raise the money. Merchants found an answer long ago, and it is the subject of this chapter. The money raised becomes the capital of a company, and each small piece of ownership is called a share.

> This chapter takes three steps: what share capital is, which kinds of share exist, and how shares are issued.
We shall proceed in three steps. First, we see what the money raised is called and how its size is limited. Second, we meet the two chief kinds of share. Third, we record an issue of shares in the books, from the first application to the last entry. Chapter 18 described a business with a few owners who know each other. Here the owners may be many, and the records change to suit them.

* * *

## 19.1 Share Capital

> A company is owned by many people through shares, and a share is one equal part of that ownership.
Ten families in a village decide to dig a well. The well will cost Tk 100,000, so each family pays Tk 10,000 and receives a written note of its part. Nobody owns the well alone, and nobody's part is larger than another's. A company works in a similar way, on a larger scale. Its owners are called shareholders. A shareholder is a person who owns one or more shares, and a share is one of the equal parts into which the ownership of a company is divided.

> Recall: balance sheet, Chapter 9, section 9.3 'Reversing Entries'.
@ Stock | Word in use. In everyday English, a supply of goods kept ready for sale. In the United States and some other places, stock also means a company's shares. This book uses inventory for goods and stock only for company shares.
@ Share capital | The money a company receives from shareholders in exchange for shares.
> Share capital is the money shareholders pay to the company for their shares.
The accountant needs a name for the money that the shareholders pay in. **Share capital** is the money a company receives from shareholders in exchange for shares. If a shareholder pays Tk 1,000 for 100 shares, then Tk 1,000 enters the share capital. In a partnership, each partner has a separate capital account, as Chapter 18 showed. A company keeps one share capital account for all its shareholders together. On the balance sheet it appears among the owners' equity. In the United States, share capital is often called capital stock.

> Each share carries a face value, the amount printed on it, which is fixed when the share is created.
Every share is created with an amount printed on it. This amount is called the face value, and it is the same for every share of the same kind. A company might create shares with a face value of Tk 10. The face value is a fixed label. It is not the price at which people trade the shares afterwards, and it is not what the company's books record when one shareholder sells to another. Those later sales happen between shareholders, so the company's own accounts do not change.

> A company may not create shares without limit; its founding documents set a ceiling.
A company cannot create unlimited shares. The people who found it choose a ceiling, and write that ceiling into its founding documents.^1 Think of a theatre. The building has a fixed number of seats, whatever the size of tonight's audience. The ceiling of a company works as the number of seats does.

@ Authorised capital | The largest amount of share capital a company is allowed to issue under its founding documents.
> Authorised capital is the ceiling on the shares a company may sell.
**Authorised capital** is the largest amount of share capital a company is allowed to issue under its founding documents. A company with authorised capital of Tk 50,000 may sell shares worth up to Tk 50,000 and no more. If the founders later want to sell shares worth more, they must first change the founding documents by the legal method of their country.

@ Issue | Word in use. In daily life, a topic of concern, or a copy of a magazine. In accounting, to issue shares means to sell and deliver them to the people who apply for them.
@ Issued capital | The part of authorised capital that has actually been sold to shareholders.
> Issued capital is the part of the ceiling that has actually been sold.
Most companies do not sell all their authorised shares at once. **Issued capital** is the part of authorised capital that has actually been sold to shareholders. If the company above has sold shares worth Tk 30,000, then its issued capital is Tk 30,000. The remaining Tk 20,000 is authorised but not issued, and the company may sell it later. Issued capital can never be larger than authorised capital.

> Example 1 uses small round numbers, so that the method is the only thing to learn.
Example 1 applies these ideas to a small company. The first line of each step names the rule, and every line of arithmetic follows it.

:table Example 1: authorised capital and issued capital
| Part | Working |
| Given | Authorised capital Tk 50,000, in shares of face value Tk 5. The company has issued 6,000 shares. |
| Find | The number of shares authorised, the issued capital, and the capital not yet issued. |
| Formula | In words: shares authorised = authorised capital ÷ face value; issued capital = shares issued × face value; capital not yet issued = authorised capital − issued capital. In symbols: N = A ÷ F, I = n × F and U = A − I, where A is authorised capital, F is face value and n is the number of shares issued. |
| Step 1 | N = 50,000 ÷ 5 = 10,000 shares. |
| Step 2 | I = 6,000 × 5 = Tk 30,000. |
| Step 3 | U = 50,000 − 30,000 = Tk 20,000, which is 20,000 ÷ 5 = 4,000 shares. |
| Answer | The company may issue 10,000 shares. It has issued capital of Tk 30,000 and may still issue shares worth Tk 20,000. |
| Check | 30,000 + 20,000 = Tk 50,000, which equals the authorised capital. |

> The case file gives a proposed company a ceiling of Tk 10,000,000 and a first issue to its partners.
:case Case file, illustrative. Meghna and Sons Limited is a proposal to turn the business into a company. Its authorised capital is Tk 10,000,000, in 1,000,000 shares of face value Tk 10. The first issue is 410,000 shares to the partners, in exchange for net assets of Tk 4,100,000. Net assets are the assets of the business less its liabilities. The partners' own capital accounts, which Chapter 18 described, are replaced by the shares they receive.

> Shares of face value Tk 10 given for net assets of Tk 4,100,000 are recorded as Tk 4,100,000 of share capital.
Now we record the first issue. The partners hand over net assets, and the company gives them shares in return. The company debits the net assets it receives. Debit means the left-hand side of an account. It credits Share Capital with the face value of the shares given. Here 410,000 shares × Tk 10 = Tk 4,100,000, which equals the value of the net assets, so no further entry is needed. The table shows the entry.

:table Journal entry for the first issue of shares
| Account | Debit (Tk) | Credit (Tk) |
| Net assets taken over | 4,100,000 | |
| Share Capital | | 4,100,000 |
| Shares issued to the partners in exchange for net assets | | |

> The entry is shown in short form; the full entry debits each asset and credits each liability.
This entry is shown in short form. In the full entry, every asset is debited by its own amount and every liability is credited by its own amount, and the difference is Tk 4,100,000. After this entry, the issued capital is Tk 4,100,000. The capital not yet issued is Tk 10,000,000 − Tk 4,100,000 = Tk 5,900,000.

> Different readers want different things from the same figures: owners, managers, lenders and employees.
Each reader looks at share capital for a different reason. A shareholder asks what part of the company he or she owns. A manager asks how much more may be raised without changing the founding documents. A bank asks how much owners' money stands behind its loan. An employee, a supplier or a customer asks mainly whether the company is stable.

> Authorised capital is a ceiling and issued capital is what has been sold; the two are not interchangeable.
Many students find these two terms confusing, because both are amounts of capital in the founding documents' language. The test is simple. If shareholders have paid for it, it is issued. If the company has only permission to sell it, it is authorised and not yet issued.

> Three terms carry forward: share capital, authorised capital and issued capital.
*Before moving on.* Share capital is the money a company receives from shareholders in exchange for shares. Authorised capital is the ceiling set by the founding documents. Issued capital is the part of the ceiling that has been sold, and it is never larger than the ceiling.

* * *

## 19.2 Types of Share

> Investors differ: one wants steady income and another wants a voice and a chance of higher reward.
Two neighbours each have Tk 100,000 to invest in the bookshop. Anwar is retired and wants a steady, predictable income. Babita is young and is willing to wait for a larger reward, and she wishes to have a say in how the shop is run. One kind of share cannot suit both of them equally. For this reason, companies create more than one kind.

@ Ordinary share | A share that gives a holder a vote and a claim on profit after other claims are paid.
> An ordinary share gives a vote and a claim on whatever profit remains.
We begin with the common kind. An **ordinary share** is a share that gives a holder a vote and a claim on profit after other claims are paid. The vote lets the holder help to choose the people who direct the company. The claim on profit has no fixed amount, so it is large when the company does well and may be nothing when it does badly. Babita would choose ordinary shares.

@ Preference share | A share that gets a fixed dividend before ordinary shareholders, usually without a vote.
> A preference share gives a fixed dividend, paid before the ordinary shareholders, usually without a vote.
The second kind suits Anwar. A **preference share** is a share that gets a fixed dividend before ordinary shareholders, usually without a vote. A dividend is a share of profit that the company pays out to its shareholders. If Anwar holds preference shares with a fixed rate of 8% a year, he receives 8% of their face value first, before any ordinary shareholder is paid, but the company has not promised that it will earn that profit.

> The two kinds differ in their rights, and a table makes the differences easy to compare.
We now have the rights of each kind. The table below sets them side by side. To read a row, find the right in the left-hand column and move across to see how each kind treats it.

:table The rights of the two kinds of share
| Right | Ordinary share | Preference share |
| Vote at meetings | Yes | Usually no |
| Dividend | Not fixed; paid from profit that remains | Fixed rate; paid first |
| Order of payment | After the preference dividend | Before the ordinary dividend |
| Gain when profit is large | Large, because the claim is on what remains | Limited to the fixed rate |
| Loss when profit is small | May receive nothing | Paid first, if profit is enough |

> In the table, the fixed rate protects the preference holder, and the remainder rewards the ordinary holder.
The table shows a trade between safety and reward. The preference holder gains safety and gives up the vote and the chance of a large dividend. The ordinary holder accepts risk and gains a vote and a larger claim when profit is large. Neither kind is better for everyone, because the right choice depends on what the investor needs.

> Example 2 divides one year's dividend between the two kinds of share.
Example 2 uses clean figures, so that the method is clear. The company has 100,000 preference shares and 200,000 ordinary shares, all with a face value of Tk 10. These numbers are chosen to teach the method and do not belong to the case file.

:table Example 2: paying a dividend to the two kinds of share
| Part | Working |
| Given | Preference capital Tk 1,000,000 at a fixed rate of 8% a year. Ordinary capital Tk 2,000,000. The company decides to pay Tk 400,000 as dividends for the year. |
| Find | The dividend to the preference shareholders, the dividend to the ordinary shareholders, and the amount for each ordinary share. |
| Formula | In words: preference dividend = preference capital × rate; ordinary dividend = total dividend − preference dividend. In symbols: P = C × r and O = T − P, where C is preference capital, r is the rate, and T is the total dividend. |
| Step 1 | P = 1,000,000 × 8% = Tk 80,000. |
| Step 2 | O = 400,000 − 80,000 = Tk 320,000. |
| Step 3 | There are 2,000,000 ÷ 10 = 200,000 ordinary shares, so each receives 320,000 ÷ 200,000 = Tk 1.60. |
| Answer | The preference shareholders receive Tk 80,000. The ordinary shareholders receive Tk 320,000, which is Tk 1.60 for each share. |
| Check | 80,000 + 320,000 = Tk 400,000, which equals the total dividend. |

> A dividend is paid out of profit, so it is a division of the company's profit and not an expense like rent.
A common slip is to treat a dividend as an expense. It is a division of profit among the owners, as the appropriation account of Chapter 18 was. Another slip is to pay the ordinary shareholders first. The preference dividend always comes first, as the table showed.

> The case file names no preference shares, so every share in the case has the same rights.
:case Case file, illustrative. The proposal for Meghna and Sons Limited states one face value, Tk 10, for all its shares. The case file names no preference shares, so this chapter treats every share in the case as an ordinary share.

> Rights vary by country and by company; the founding documents of each company state its own rules.
The rights described here are the common pattern. The exact rights of each kind of share depend on the law of the country and on the founding documents of each company. Some preference shares carry a vote in certain circumstances, and some fixed dividends may be carried forward when profit is too small to pay them. Read the documents of the company concerned.

> Two kinds of share, ordinary and preference, trade vote and reward against fixed income and priority.
*Before moving on.* An ordinary share carries a vote and a claim on profit that remains after other claims are paid. A preference share carries a fixed dividend, paid before the ordinary dividend, usually without a vote. The right choice for an investor depends on whether safety or reward matters more.

^1: The rule differs by country. Under the Companies Act 1994 of Bangladesh, the founding documents state a ceiling of share capital. In the United Kingdom, the Companies Act 2006 ended the need for most companies to state one. Read the law of your own country before applying any rule from this chapter.


* * *

## 19.3 Issuing Shares

> A company that wants outsiders' money must invite applications, choose among them and then deliver the shares.
Suppose a company offers shares to the public. How does it know who wants them, how much money has arrived, and who has actually become a shareholder? The process has two formal steps, and each step has its own name and its own entry in the books.

@ Share application | A request to buy shares, sent with money, to a company that is offering them.
> A share application is a request to buy shares, sent with money.
The first step belongs to the buyer. A **share application** is a request to buy shares, sent with money, to a company that is offering them. A neighbour who sends Tk 5,000 and a form asking for 500 shares has made a share application. At this point the neighbour is not yet a shareholder. The company holds the money, but it has not yet agreed to deliver any shares.

> Money held before allotment is recorded in a temporary account named Share Application.
The company records the money received from applicants. We debit Bank, because cash has arrived, and credit an account named Share Application. This account holds the money until the company decides who receives shares. It is a temporary account, closed at the next step.

@ Allotment | The company's formal decision to give shares to applicants.
> Allotment is the company's decision to give shares to the applicants.
The second step belongs to the company. **Allotment** is the company's formal decision to give shares to applicants. When the company allots 500 shares to the neighbour, he or she becomes a shareholder. From this moment the company may credit its share capital, because the shares now exist in the hands of their owners. The Share Application account is closed, and its balance moves into the permanent accounts.

@ Share premium | The amount paid for a share above its face value.
> Share premium is the amount paid above face value, and it is kept in its own account.
Some companies sell shares for more than their face value. **Share premium** is the amount paid for a share above its face value. A share with a face value of Tk 10 sold for Tk 25 carries a premium of Tk 15. The premium is not part of the share capital, which holds only the face value. It is credited to a separate account named Share Premium. In many countries the law limits what a company may do with that account.

> Recall: partnership, Chapter 18, section 18.1 'Forming a Partnership'.
> A company may charge a premium because the business is already worth more than the face value of its shares.
Why would anyone pay more than the face value? Because the business may already be worth more than the amounts printed on its shares. A shop with a good name, loyal customers and years of trading is worth more than a new shop with the same number of shares. In a partnership, a new partner may pay for such a gain, as Chapter 18 showed. In a company, the share premium records the same idea.

:pause 19.p1 | A share of face value Tk 10 is issued at Tk 18. What is the premium on each share, and what is the total premium on 1,000 shares?

> Two journal entries record an issue: one when applications arrive and one on allotment.
The entries follow the order of events, and each has a debit total equal to its credit total. When the application money is received, we debit Bank and credit Share Application. When the shares are allotted, we debit Share Application, and we debit Bank for any further money received at that time. We credit Share Capital with the face value of the shares and credit Share Premium with the premium. This chapter assumes that all money is paid when it is due. A real company must also record money that arrives late.

> Example 3 records a small issue with a premium, so that the method is the only thing to learn.
Example 3 uses small numbers. The company issues 1,000 shares of face value Tk 10 at Tk 12. Applicants pay Tk 12 a share with the application, and all 1,000 shares are allotted.

:table Example 3: recording a small issue with a premium
| Part | Working |
| Given | 1,000 shares, face value Tk 10, issued at Tk 12. All the money is paid with the application, and all 1,000 shares are allotted. |
| Find | The share capital, the share premium, and the two journal entries. |
| Formula | In words: share capital = shares × face value; share premium = shares × (issue price − face value). In symbols: K = n × F and M = n × (P − F), where n is the number of shares, F is the face value and P is the issue price. |
| Step 1 | Application money = 1,000 × 12 = Tk 12,000. Debit Bank 12,000; credit Share Application 12,000. |
| Step 2 | K = 1,000 × 10 = Tk 10,000. |
| Step 3 | M = 1,000 × (12 − 10) = Tk 2,000. |
| Step 4 | On allotment: debit Share Application 12,000; credit Share Capital 10,000 and Share Premium 2,000. |
| Answer | Share capital is Tk 10,000 and share premium is Tk 2,000. |
| Check | 10,000 + 2,000 = Tk 12,000, which equals the application money received. |

> Three slips are common: credit capital with the whole price, forget the premium, or mix the two steps.
Three slips are common. The first is to credit Share Capital with the whole issue price, which hides the premium. The second is to record the issue before the allotment, so that Share Capital appears before anybody owns a share. The third is to credit the application money to Share Capital directly, which skips the temporary account.

> Application comes first, then allotment, then premium: this is the order of the technique.
*Before moving on.* A share application is a request to buy shares, sent with money. Allotment is the company's decision to give shares to applicants. Share premium is the amount paid above face value, and it is credited to its own account. The entries follow the order of events: application, allotment, premium.

* * *

## Worked Case: The Public Issue of Meghna and Sons Limited

> The case file offers 200,000 shares at Tk 25, so the same method is now applied to a realistic issue.
Example 3 used small numbers. The case file now gives a realistic issue. Read the figure below from left to right. The bar is the issue price of Tk 25 for one share. The hatched part is the face value of Tk 10, and the dotted part is the premium of Tk 15. The words under the bar name the money asked at each step.

:fig The issue price of one share, split into face value and share premium | ch19-fig01.svg

> The case file records the public issue, the two money stages, and the totals credited.
:case Case file, illustrative. Meghna and Sons Limited makes a public issue of 200,000 shares at Tk 25, which is a face value of Tk 10 and a premium of Tk 15. Application money is Tk 10 a share, which is Tk 2,000,000. Allotment money is Tk 15 a share, which is Tk 3,000,000. The total is Tk 5,000,000. Share capital credited is Tk 2,000,000, and share premium credited is Tk 3,000,000.

> Example 4 works the public issue in the standard order, with the journal entries at the end.
Example 4 works the case in full. Many students find this example confusing, because the application money equals the face value and the allotment money equals the premium. This is a feature of the case, and it is not a rule: other issues divide the money in other ways, as question 19.2 shows.

:table Example 4: the public issue of Meghna and Sons Limited
| Part | Working |
| Given | 200,000 shares, face value Tk 10, issue price Tk 25. Application money Tk 10 a share. Allotment money Tk 15 a share. All money is paid when due. |
| Find | The money at each step, the share capital, the share premium, and the journal entries. |
| Formula | In words: money at a step = shares × amount a share; share capital = shares × face value; share premium = shares × (issue price − face value). In symbols: K = n × F and M = n × (P − F). |
| Step 1 | Application money = 200,000 × 10 = Tk 2,000,000. |
| Step 2 | Allotment money = 200,000 × 15 = Tk 3,000,000. |
| Step 3 | Total money = 2,000,000 + 3,000,000 = Tk 5,000,000, which also equals 200,000 × 25. |
| Step 4 | Share capital K = 200,000 × 10 = Tk 2,000,000. |
| Step 5 | Share premium M = 200,000 × (25 − 10) = Tk 3,000,000. |
| Answer | Share capital credited is Tk 2,000,000 and share premium credited is Tk 3,000,000. |
| Check | 2,000,000 + 3,000,000 = Tk 5,000,000, which equals the total money received. |

> The two journal entries put the money into Bank first and into capital and premium second.
The journal entries follow. The first records the money received with the applications. The second records the allotment and the money received at that stage.

:table Journal entries for the public issue
| Step | Account | Debit (Tk) | Credit (Tk) |
| Application | Bank | 2,000,000 | |
| | Share Application | | 2,000,000 |
| Allotment | Share Application | 2,000,000 | |
| | Bank | 3,000,000 | |
| | Share Capital | | 2,000,000 |
| | Share Premium | | 3,000,000 |

> After the issue, the company has issued capital of Tk 6,100,000 and a share premium account of Tk 3,000,000.
Now consider the effect on the company. Before this issue, its issued capital was Tk 4,100,000. After the public issue it is Tk 4,100,000 + Tk 2,000,000 = Tk 6,100,000, which is still below the authorised capital of Tk 10,000,000. The share premium of Tk 3,000,000 is held in its own account, outside the share capital. The company has raised Tk 5,000,000 in cash in all. The balance sheet shows both accounts among the owners' equity, in the way that Chapter 9 described.

* * *

## Summary

> A company raises share capital by selling shares, and the entries follow application, allotment and premium.
A company is owned by shareholders through shares. Share capital is the money it receives for them. Authorised capital is the ceiling set by the founding documents, and issued capital is the part sold. Ordinary shares carry a vote and a claim on remaining profit; preference shares carry a fixed dividend paid first, usually without a vote. In an issue, a share application is recorded in a temporary account, allotment moves it into Share Capital at face value, and share premium is credited to its own account.

## Think It Through

:q 19.t1 | The company offers 200,000 shares, but applications arrive for 300,000. Suggest two ways the company could treat the extra applications, and say what must happen to the money of any applicant who receives no shares.
:q 19.t2 | A company with shares of face value Tk 10 sells new shares for Tk 40. Explain, in two or three sentences, why the buyers may be willing to pay Tk 30 more than the face value.

## Where People Go Wrong

> Authorised capital is a permission and not money; only issued capital has been paid for.
*Belief:* authorised capital is money the company already has. *Correction:* authorised capital is a ceiling. Only the part that has been issued, and paid for, has become share capital.

> The premium is not part of share capital, because share capital holds only face value.
*Belief:* the whole issue price goes to Share Capital. *Correction:* only the face value is credited to Share Capital. The amount above face value is credited to Share Premium.

> A preference dividend is fixed in rate, but the company must still earn profit to pay it.
*Belief:* a preference dividend is a promise that is always paid. *Correction:* it is a fixed rate and the first claim on profit. The company can pay it only if there is profit, and the rules of each company decide what happens when there is none.

> A shareholder who sells shares to another person does not change the company's share capital.
*Belief:* when shares are sold between shareholders, the company's share capital changes. *Correction:* the company's books change only when the company itself issues shares and receives money for them. Later sales are between shareholders.

## In History

> The Joint Stock Companies Act 1856 let any seven people register a company, and the registered company could limit its owners' liability.
In the nineteenth century, a person who invested in a business could, in many cases, lose more than the money paid in. The United Kingdom Parliament changed this. The Joint Stock Companies Act 1856, which received royal assent on 14 July 1856, allowed seven or more people to register a company by signing a memorandum of association. The company could be registered with limited liability, which means that a shareholder could lose no more than the amount he or she had agreed to pay for shares.

> The 1856 Act spread share ownership by making small investments safe, and the neighbours of our puzzle would have understood it.
A company with limited liability had to carry the word "Limited" at the end of its name, so that everybody who dealt with it knew the limit. The neighbours in our opening puzzle would have understood the value of this rule. A person could put in Tk 5,000, lose at most Tk 5,000, and share in the profit. This is the reason that share ownership spread, as the Act made small investments safer for people who did not run the business themselves.

## Review Questions

:q 19.1 | A company issues 1,000 shares of face value Tk 10 at Tk 10. Applicants pay the whole Tk 10 with the application, and all 1,000 shares are allotted. Journalise the application and the allotment.
:q 19.2 | A company issues 50,000 shares of face value Tk 10 at Tk 16. Applicants pay Tk 8 a share with the application and Tk 8 a share on allotment. Find the share capital and the share premium, and journalise the application and the allotment.
:q 19.3 | A company has authorised capital of Tk 2,000,000 in shares of face value Tk 5. It has issued 120,000 shares. Find the number of shares authorised, the issued capital, and the number of shares still unissued.
:q 19.4 | Mira and Naveed, former partners with capital of Tk 450,000 and Tk 300,000, form a company. They receive shares of face value Tk 10, equal in value to their capital, in exchange for net assets of Tk 750,000. Find the number of shares each receives, and journalise the issue.
