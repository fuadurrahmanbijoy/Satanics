:chapter III | Utility and Diminishing Marginal Utility
:mood Why does the same cup of tea please a little less each time?
:desc This chapter explains how economists describe satisfaction, how they count it with an imaginary unit, and why each extra unit of a good adds less than the one before. A tea table and a student buying exercise books show the rule at work, and the chapter ends with the limits of the rule.
:plate ch03-plate.svg | A Victorian tea table, with the diner finishing her third cup

> Two earlier ideas and one appendix help with this chapter.

*You will need* two ideas from earlier chapters: opportunity cost, from Chapter 2 'Scarcity, Choice and Opportunity Cost', section 2.2 'Opportunity Cost'; and the meaning of an economic law, from Chapter 1 'What Economics Is', section 1.4 'Economic Laws'. Appendix A1 'Maths You Will Use' helps with adding columns of numbers and with reading a graph.

> A diner enjoys her first cup of tea and refuses her fourth.

Imagine a long table set for afternoon tea in a Victorian town house. A diner sits down, tired and cold after a walk. The first cup of hot tea is a delight, and she drinks it slowly. The second cup is still pleasant, though the delight is smaller. She drinks the third mainly because it stands in front of her. When the maid offers a fourth, the diner covers the cup with her hand and says, politely, that she has had enough.

> The tea, the table and the price stayed the same, yet the pleasure changed.

Look at what did not change. The tea is the same tea. The cups, the table and the maid are the same. The tea is free, since the hostess pays for it. Yet the drink that gave great pleasure at the start gives almost none at the end. Why should a good thing lose its power to please as we take more of it?

> This small puzzle explains why buyers stop buying.

The question looks small, but it is not. Every day, people decide how much of a good to buy and when to stop. A bookseller must ask how many notebooks one customer will want. If every extra notebook pleased as much as the first, a customer would buy without end, and no shop could ever fill the wish. In fact customers stop. To understand why they stop is the first step towards understanding how buyers choose, which later chapters study.

> The chapter moves slowly, in small steps, because the ideas are abstract.

Here we build the answer in small steps. First we name the pleasure and learn to count it, using imaginary numbers. Then we state the rule by which pleasure fades, and we test it on a student buying exercise books at Meghna and Sons. Many students find this chapter slow at first, because satisfaction cannot be seen or weighed. For that reason we go slowly, one idea at a time, with small numbers.

* * *

## 3.1 The Idea of Utility

> Every purchase begins with a want that the buyer hopes to satisfy.

@! Go slowly here.

Begin with your own day. Why did you eat your last meal? You were hungry, and food satisfied the hunger. Hunger is a want, and the pleasure or relief of meeting it is a kind of reward. Every time a person drinks, reads, travels or buys, a want is being met and a reward is felt. Economics needs a short name for that reward, so that we can reason about it without confusion.

@ Utility | The satisfaction a person gets from using a good or service.

> Economists call the satisfaction from a good its utility.

Economists call the reward **utility**. Utility means the satisfaction a person gets from using a good or service. A cup of hot tea gives utility to a cold traveller. A bus ticket gives utility to a worker who must reach the office. Notice what the word does not say. Utility is not a judgement of whether a good is wise or healthy. A sweet snack may harm the teeth, yet it gives utility to the person who enjoys it, because utility counts only the satisfaction that person feels.

> Two people can gain different utility from the same good.

Utility belongs to the person, not to the good. Picture a market stall that sells green mangoes. A child who loves their sharp taste may feel great satisfaction from one mango, while an older neighbour who dislikes sour fruit feels almost none. The good is the same, but the utility differs. For this reason economists speak of the utility a particular person gets, at a particular time, and not of the utility a good has in itself. A good that pleases nobody has no utility at all, however carefully it was made.

@ Utility | Word in use. In daily life, a utility is a public service such as water or electricity. In economics, utility is the satisfaction a good gives.

> The everyday word and the economic word differ.

You may know the word from daily life, where a *utility* is a public service such as the supply of water or electricity. In this book the word always has its economic sense: satisfaction. When a company that supplies water appears in an example, we call it a water company and keep the word utility for the feeling.

@ Total utility | The whole satisfaction from all units of a good consumed.

> Adding the satisfaction from every unit gives total utility.

Now suppose the diner drinks three cups. Each cup gave her some satisfaction. If we add the satisfaction from the first cup, the second cup and the third cup, we reach **total utility**. Total utility means the whole satisfaction from all units of a good consumed. For the diner, it is everything she enjoyed from all three cups together. Total utility answers one question: how much satisfaction did she gain altogether?

@! Go slowly here.
@ Marginal utility | The extra satisfaction from consuming one more unit of a good.

> Marginal utility looks only at the last unit, not at the whole.

Now ask a different question: how much did the third cup add? The answer is the **marginal utility** of the third cup. Marginal utility means the extra satisfaction from consuming one more unit of a good. If the diner had two cups and gains a little from a third, that little gain is the marginal utility of the third cup. A staircase gives a useful picture. Total utility is how high you stand after climbing some steps. Marginal utility is the height of the last step you climbed. They are two different measures: the height so far, and the height of one step.

@ Marginal | Word in use. In daily life, marginal often means small or at the edge, as in a marginal improvement. In economics, marginal means extra: the change caused by one more unit.

> In economics, marginal means extra.

The word *marginal* needs care for the same reason. A margin is the edge of a page. In economics the margin is the edge of what you already have, and marginal means what one more unit adds at that edge. The word does not mean small or unimportant. The marginal utility of a cup may be large, as it is for the first cup after a long walk.

:pause 3.p1 | The diner drinks one cup, then a second cup that pleases her a little. After the second cup, is her total satisfaction higher or lower than after the first? Give a reason.

### Measuring Satisfaction

> Satisfaction cannot be seen, so economists count it with an imaginary unit.

Can satisfaction be counted? Nobody owns a machine that reads how happy a cup of tea makes a person. William Stanley Jevons, an English economist who wrote in the 1870s, found it useful to imagine such a machine.^1 Economists therefore agree to count satisfaction in an imaginary unit.

@ Util | An imaginary unit used to count satisfaction in economic examples.

^1: Recall: opportunity cost, Chapter 2, 'Scarcity, Choice and Opportunity Cost', section 2.2 'Opportunity Cost'. We use it later in this chapter, when we ask what a buyer forgoes.

> The imaginary unit is the util.

The unit is the **util**. A util means an imaginary unit used to count satisfaction in economic examples. If the first cup gives 10 utils and the second gives 8 utils, we say that the first cup pleased the diner more. The numbers are not real measurements. They are a tool that lets us reason exactly about more and less.

> A small table shows five cups of tea, with the extra and the whole counted in utils.

The table below shows the diner's tea in utils. The numbers are imaginary and chosen to be small. Each row is one cup. The middle column gives the marginal utility of that cup, and the last column gives the total utility after that cup.

:table Satisfaction from five cups of tea (imaginary utils)
| Cup | Marginal utility (utils) | Total utility (utils) |
| 1 | 10 | 10 |
| 2 | 8 | 18 |
| 3 | 5 | 23 |
| 4 | 2 | 25 |
| 5 | 0 | 25 |

> Read a row to see what one cup added and what all cups gave.

To read a row, take cup 3. Its marginal utility is 5, so the third cup added 5 utils. Its total utility is 23, so the three cups together gave 23 utils. Notice the link between the columns: the total after cup 3 equals the total after cup 2 plus the marginal utility of cup 3, because 18 plus 5 is 23. Each total is the sum of all the marginal utilities so far.

> Counting in utils turns a feeling into a list that can be compared.

Why count at all? Without numbers, we could say only that the diner liked the first cup more than the second. With numbers, we can say how much more, and we can say how fast the pleasure fades. That speed is exactly what the law in the next section describes. The numbers must be treated as a tool of reasoning, in the way that a map is a tool: it does not equal the land, but it helps a traveller decide.

> Utils compare one person's own moments, not different people.

One limit is important. A util belongs to one person at one time. We may say that the diner liked cup 1 more than cup 2. We may not say that her 10 utils equal 10 utils felt by another person, because no common scale exists.

> The section ends by recalling the three ideas and the unit.

*Before moving on.* Utility is satisfaction. Total utility is the satisfaction from all units; marginal utility is the extra from one more unit. We count satisfaction in utils, which are imaginary but useful. You should now be able to say, in your own words, why the total after the fourth cup can be higher than after the third even though the fourth cup added only a little.

## 3.2 The Law of Diminishing Marginal Utility

> Three economists in three countries found the same rule within a few years.

In the early 1870s, an economist in England, one in Austria and one in Switzerland each published the same observation about satisfaction. None knew of the work of the others. The section called In History, at the end of this chapter, tells that story. Here we explain the observation itself, and we use the tea table to see it.

### The Law Stated

> Look again at the marginal utility column of the tea table.

Return to the table of five cups. Read down the marginal column: 10, 8, 5, 2, 0. Each number is smaller than the one before. The cups are the same cups, and the diner is the same diner. Yet each extra cup adds less. This pattern is so regular that economists give it a name and call it a law.

@! Go slowly here.
@ Law of diminishing marginal utility | As a person consumes more units of a good, the satisfaction added by each extra unit falls.

> The law states that each extra unit adds less than the one before.

The pattern is the **law of diminishing marginal utility**. The law of diminishing marginal utility says that as a person consumes more units of a good, the satisfaction added by each extra unit falls. The word *diminishing* means becoming smaller. Notice that the law speaks about the marginal utility, the extra, and not about the total.^2

^2: Recall: laws, Chapter 1, 'What Economics Is', section 1.4 'Economic Laws'. An economic law describes a regular tendency in human choice, not a rule that nature enforces.

:box THE LAW IN SHORT
Keep consuming one good, and the extra satisfaction from each new unit becomes smaller.

> The law is about the extra, so the total can still rise while the extra falls.

This point is the one that confuses students most. When marginal utility falls from 10 to 8 to 5, the total still rises, from 10 to 18 to 23. A smaller step is still a step upward. The total utility rises as long as the marginal utility is above zero. At the fifth cup the marginal utility is zero, so the total stops rising and stays at 25. If a sixth cup were forced upon the diner, it would give her discomfort, and the marginal utility would fall below zero.

### Why the Law Holds

> A want is limited, and each unit satisfies part of it.

Why should the extra satisfaction shrink? Begin with the bridge from daily life. A person who is very thirsty has a strong want for water. The first glass meets the strongest part of that want, and the relief is great. After the glass, the want is smaller. The second glass meets what remains, so the relief is smaller. Each unit uses up part of a want that has a limit, and a smaller want leaves less satisfaction to gain.

> The law helps explain why buyers do not buy without end.

Return to the puzzle at the start of the chapter. If marginal utility did not fall, the diner would drink cup after cup, and no shop would ever need to attract new customers, because each customer would buy forever. Because marginal utility falls, every buyer reaches a point where one more unit is not worth having. When the unit is not free, a buyer must also compare the satisfaction gained with what is forgone, which is the opportunity cost of the purchase. A later chapter joins these two ideas.

> The same fact looks different from the consumer's side and the seller's side.

Look at the same fact from two viewpoints. For the consumer, it is a feeling: the fourth cup is not worth much. For the owner of a shop such as Meghna and Sons, it is a pattern in sales: a customer buys the first notebook readily, hesitates over the second and rarely wants a long row of identical ones. The owner cannot see the utils, but the owner can see the customer stop. The law gives a reason for what the owner observes. An assistant who serves the customers sees the same fact from a third position: a customer who comes in for one book rarely leaves with ten, and the assistant learns to expect it.

### The Schedule and the Curve

> A table of utility for one person is a schedule; a line through the numbers is a curve.

A table that lists the utility of each unit is called a schedule, and the same numbers drawn as a line are called a curve. We now use the shop's own example. The next paragraph is a record of a case, and its figures are fixed.

> The case file records the student's utility for five books.

:case Case file, illustrative. A student buys exercise books at Meghna and Sons. The marginal utility of each book, in utils, is: 1st book 40, 2nd book 30, 3rd book 20, 4th book 10, 5th book 0. The total utility after each book is 40, 70, 90, 100 and 100.

> The case table sets the numbers side by side.

:table The student's utility from exercise books (utils)
| Book | Marginal utility (utils) | Total utility (utils) |
| 1st | 40 | 40 |
| 2nd | 30 | 70 |
| 3rd | 20 | 90 |
| 4th | 10 | 100 |
| 5th | 0 | 100 |

:pause 3.p2 | Using the tea table, how much did the fourth cup add to the diner's total satisfaction? Which column gives the answer?

> Before reading a chart, learn what its two axes show.

Now we draw the numbers. Every chart in this book has two lines at right angles, called axes.^3 On the horizontal axis we place the number of books. On the vertical axis we place utils. A point on the chart means: at this number of books, the utils have this value. The first chart shows total utility.

^3: See Appendix A1 'Maths You Will Use', section A1.5 'Reading a Graph', for axes, points and slope.

:fig Total utility rises with each book and then becomes flat | ch03-fig01.svg

> The total line climbs quickly, then more slowly, then stops climbing.

Read the chart from left to right. The line climbs steeply from the first book to the second, because 40 utils are added. It climbs less steeply to the third, because 30 and 20 are added. It becomes flat after the fourth book, because the fifth adds nothing. A flat line means the total has stopped rising.

:fig Marginal utility falls with each book and reaches zero | ch03-fig02.svg

> The second chart shows the same facts as the extra from each book.

The second chart shows the extra from each book instead of the whole. Its points go down: 40, 30, 20, 10, 0. A line through them slopes downward from left to right, and that downward slope is the law in picture form. The line reaches the horizontal axis at the fifth book, where marginal utility is zero. The dashed part below the axis shows what would happen if a further book were forced upon the student: marginal utility would be negative, and total utility would fall.

> The two charts are the same story told twice.

*Before moving on.* The law says the extra satisfaction from each unit falls. The marginal column goes down while the total column goes up and then stops. At the point where marginal utility is zero, total utility is at its highest. You should now be able to say why the total can rise while the extra falls.

## 3.3 Limits of the Law

> A law holds only under stated conditions.

The law holds when certain conditions are met. The units must be alike in size and quality, as cups of the same tea are. The consumer's tastes must stay the same during the time of consumption. The consumption must follow without long gaps, because after a rest the want returns and the first unit pleases again. Economists say these conditions together as: other things remain equal.

> Apparent exceptions usually disappear when the unit is defined with care.

Some cases look like exceptions. A collector of stamps may value each new stamp more as the set nears completion. Yet the unit that matters is then the complete set, and the law holds for sets. A person who is addicted to a drug may crave more each time, but this is a harm and not a normal want. Treat such cases as limits of the law, not as proofs that it fails. A third case is a good that is useful only in a set, such as a left shoe: the first shoe alone adds little, and the second adds much. Here again the sensible unit is the pair.

> The section closes with its conditions in two lines.

*Before moving on.* The law needs alike units, steady tastes and no long gaps. Apparent exceptions usually change the unit.

## Worked Case: Reading a Utility Schedule

> Two links between the columns let us calculate any missing number.

A table gives some numbers and hides others. Two links let us find the hidden ones. In words: total utility after a unit equals the total before it plus the marginal utility of that unit. In symbols, TU(n) = TU(n − 1) + MU(n), where TU(n) is the total utility after n units, TU(n − 1) is the total after one fewer unit, and MU(n) is the marginal utility of the nth unit. Rearranged, MU(n) = TU(n) − TU(n − 1).^4

^4: Appendix A1 'Maths You Will Use', section A1.3 'Rearranging an Equation', shows how to move a term across the equals sign.

> The first example uses the student's own numbers and finds a total.

**Example 1.** *Given:* the marginal utilities of the first three exercise books are 40, 30 and 20 utils. *Find:* the total utility after three books. *Formula:* total utility is the sum of the marginal utilities so far. *Steps:* 40 + 30 = 70 utils; 70 + 20 = 90 utils. *Answer:* total utility after three books is 90 utils. *Check:* the case table shows 90 in the row of the 3rd book, so the answer is sensible.

> The second example starts from totals and finds the extra from each unit.

**Example 2.** *Given:* a different person drinks glasses of sugarcane juice, and total utility after each glass is 12, 22, 30, 36, 40, 42 and 42 utils. *Find:* the marginal utility of each glass. *Formula:* MU(n) = TU(n) − TU(n − 1), and for the first glass MU(1) = TU(1). *Steps:* glass 1: 12; glass 2: 22 − 12 = 10; glass 3: 30 − 22 = 8; glass 4: 36 − 30 = 6; glass 5: 40 − 36 = 4; glass 6: 42 − 40 = 2; glass 7: 42 − 42 = 0. *Answer:* the marginal utilities are 12, 10, 8, 6, 4, 2 and 0 utils. *Check:* the list falls at every step, as the law predicts, and the total stops rising when marginal utility reaches zero.

> Four common slips spoil these calculations.

*Common slips.* Students often read the marginal column as if it were the total column. They forget to write utils beside the numbers. They subtract in the wrong order, which gives a negative number for a gain. And they treat the first row differently from the others: for the first unit, marginal utility and total utility are the same number.

## Summary

> The chapter's main ideas in a few lines.

Utility is the satisfaction a good gives. Total utility is the whole satisfaction from all units, and marginal utility is the extra from one more unit. We count satisfaction in imaginary utils. The law of diminishing marginal utility says that each extra unit adds less than the one before. Total utility rises as long as marginal utility is above zero, and it stops rising when marginal utility reaches zero.

## Think It Through

> Two short problems that use the tea table.

:q 3.t1 | Why might the diner's fifth cup of tea give her zero utility? Give two reasons from the diner's own situation.

:q 3.t2 | In the tea table, suppose the diner could drink a sixth cup that gave her minus 3 utils. What would her total utility be after six cups, and what should she do?

## Where People Go Wrong

> A common error is to believe that falling marginal utility means falling total utility.

*Error 1: "If marginal utility falls, the total falls."* This is wrong. A smaller extra is still an extra, so the total rises while marginal utility is above zero. The total falls only when marginal utility is negative.

> Utility is not the same as usefulness or goodness.

*Error 2: "Utility means a good is useful or good for you."* This is wrong. Utility is the satisfaction a person feels, whether or not the good is wise. Economics describes the feeling and leaves the moral judgement to others.

> The law applies to one period and one person, not to a lifetime.

*Error 3: "The law means the first unit is always the best."* This is wrong. The law describes units consumed in one period. After a long rest, the want returns and the next unit pleases again.

> Utils are a tool, not a measurement of the world.

*Error 4: "Ten utils for me equal ten utils for you."* This is wrong. A util is an imaginary unit for one person's own comparison, and no common scale links two people.

## In History

> Four writers found the rule, and three of them did so within four years.

In 1854, a Prussian civil servant named Hermann Heinrich Gossen published a book in Germany that stated the idea of diminishing satisfaction and drew its curves. Few people bought it, and Gossen died in 1858, largely unknown. In 1871, William Stanley Jevons in England published *The Theory of Political Economy*, and in the same year Carl Menger in Austria published *Grundsätze der Volkswirthschaftslehre*. In 1874, Léon Walras, who taught at Lausanne in Switzerland, published the first part of *Éléments d'économie politique pure*.

> The revolution was the work of independent minds in different countries.

The three writers did not know of one another's work when they began. Historians call these years from 1871 to 1874 the marginal revolution, because each author built a theory of value on marginal utility. Jevons learned of Gossen's book after publishing his own, and in a later edition he acknowledged that Gossen had come first.

> The history teaches that a good idea can wait for its readers.

The story carries a lesson for a student. Gossen stated the idea first and was ignored, while the three later writers were read and remembered. An idea becomes part of a science only when other people understand it, test it and use it. The law you have learned passed that test, and today it is the starting point of the theory of how buyers choose.

## Review Questions

> Six questions that check the chapter's ideas.

:q 3.1 | Define utility, and give one example from your own day.

:q 3.2 | Complete the table. Marginal utilities for four units are 50, 35, 20 and 5 utils. Find the total utility after each unit.

:q 3.3 | Total utilities for five units are 20, 36, 48, 54 and 56 utils. Find the marginal utility of each unit.

:q 3.4 | State the law of diminishing marginal utility, and name one condition under which it holds.

:q 3.5 | In the case table, what is the marginal utility of the 5th exercise book? What is the opportunity cost of buying that book, in words, if the student could spend the money on another good?

:q 3.6 | A student says the total falls after the third cup because the marginal utility falls. Explain the mistake.

:read William Stanley Jevons, The Theory of Political Economy, 1871
:read Carl Menger, Grundsätze der Volkswirthschaftslehre, 1871
:read Léon Walras, Éléments d'économie politique pure, 1874
