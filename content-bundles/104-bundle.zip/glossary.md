:glossary 01
Economics | The study of how people, firms and governments choose to use limited resources to satisfy wants. It exists because wants are many and means are few. A student with Tk 100 who must choose among wants worth Tk 150 meets the problem on a small scale.
Microeconomics | The branch of economics that studies choices made by individual consumers and firms. Its unit is one consumer, one firm or one market. A question about how one bookshop chooses its price belongs to microeconomics.
Macroeconomics | The branch of economics that studies the whole economy, including output, prices and employment. Its unit is a total or an average for a country. A question about the price level of a whole country belongs to macroeconomics.
Positive economics | Statements about what is, which can be tested against facts. A positive statement may be true or false, but records or measurement can settle which. The shop sold 41,000 copies in 2025 is a positive statement.
Normative economics | Statements about what ought to be, which depend on values and cannot be tested by facts alone. Words such as should and ought often signal them. Textbooks should be cheaper is a normative statement.
Economic law | A statement of how people usually behave, true when other conditions stay the same. It describes a tendency, not a certainty, because people choose. When the price of a good rises, consumers usually buy less of it.
Ceteris paribus | A Latin phrase meaning all other things stay the same, used to study one change at a time. It is a method of thinking, not a claim that nothing else changes. To study the effect of price on notebook sales, we hold incomes and other prices fixed.

:glossary 02
Want | Something a person would like to have, however little or much the person can pay for it. A want may be a good, a service or a condition. Example: a bicycle, a haircut or a free afternoon.
Scarcity | The condition that resources are limited while wants are unlimited, so choices must be made. It applies to rich and poor alike, and it is the reason economics exists. Example: a family cannot buy everything on its list.
Opportunity cost | The value of the best alternative given up when a choice is made. Only the best alternative counts, not all alternatives added. Example: Rafiq's extra parcel gives up 2 books.
Trade-off | Giving up some of one thing in order to have more of another. It is the exchange itself, while opportunity cost measures what is given up. Example: planting more jute and less rice.
Production possibility curve | A line showing the largest combinations of two goods that can be produced with all resources used fully. Points inside waste resources; points outside cannot be reached. Example: Rafiq's 800 books or 400 parcels.

:glossary 03
Utility | The satisfaction a person gets from using a good or service. It is a feeling, not a judgement of whether the good is wise or healthy. A cold drink on a hot day gives utility to the person who drinks it.
Total utility | The whole satisfaction a person gets from all the units of a good consumed in a period. It is found by adding the marginal utility of each unit. If three cups gave 10, 8 and 5 utils, total utility is 23 utils.
Marginal utility | The extra satisfaction a person gets from consuming one more unit of a good. It is the height of the last step, not the height of the whole staircase. If the third cup adds 5 utils, its marginal utility is 5 utils.
Util | An imaginary unit used to count satisfaction in economic examples. A util is not a real measurement; it lets us reason exactly about more and less for one person. A cup worth 10 utils pleases more than a cup worth 8 utils.
Law of diminishing marginal utility | As a person consumes more units of a good, the satisfaction added by each extra unit falls. It holds when units are alike, tastes are steady and consumption has no long gaps. Marginal utilities of 10, 8, 5, 2 and 0 show the law.

:glossary 04
Demand | The quantities of a good that buyers are willing and able to buy at each price in a period. Both the wish and the money are needed. One entry is a quantity demanded; the whole list is demand. For the notebook: 40 at Tk 40, 50 at Tk 30, and so on.
Demand schedule | A table showing the quantity demanded at each price. Each row pairs one price with one quantity. The shop's table lists Tk 60 with 20 notebooks, Tk 50 with 30, and continues down to Tk 20 with 60.
Law of demand | When the price of a good rises, the quantity demanded falls, if other conditions stay the same. The same law says a fall in price raises the quantity demanded. It is drawn as a downward-sloping line.
Demand curve | A line on a graph showing the quantity demanded at each price. Price is on the vertical axis and quantity on the horizontal axis. A point on the line means that at this price buyers choose this quantity. Usually the line slopes downward.
Substitute goods | Goods that can replace each other, so a price rise for one raises demand for the other. If a rival notebook becomes dearer, some buyers move to ours, and demand for our notebook shifts to the right.
Complementary goods | Goods used together, so a price rise for one lowers demand for the other. Pens and notebooks are used together. If pens become dearer, fewer notebooks are wanted at every price.
Normal good | A good for which demand rises when buyers' incomes rise. The word normal does not mean usual. If families with more money buy more notebooks, the notebook is a normal good.
Giffen good | A rare, very basic good for which quantity demanded rises when its price rises. Marshall wrote that Giffen noticed it among very poor households buying bread. It is a special case and the law of demand holds for nearly all other goods.
Snob effect | A fall in demand for a good because many other people now buy it. A buyer who values rarity leaves a good that has become common, as when a once-rare scarf is worn by everyone.
Bandwagon effect | A rise in demand for a good because many other people buy it. A buyer wants what friends and neighbours have, as when a mobile phone becomes more useful because all of one's friends use it.

:glossary 05
Price elasticity of demand | The percentage change in quantity demanded divided by the percentage change in price, each found by the midpoint method. A result of 2 means quantity changes twice as fast as price. The size of the result is reported, without its sign.
Elastic demand | Demand for which the percentage change in quantity is larger than the percentage change in price, so price elasticity of demand is above 1. A price cut raises total revenue. Example: the notebook between Tk 50 and Tk 40, at 1.29.
Inelastic demand | Demand for which the percentage change in quantity is smaller than the percentage change in price, so price elasticity of demand is below 1. A price cut lowers total revenue. Salt is a likely example.
Unit elastic demand | Demand for which the percentage change in quantity equals the percentage change in price, so price elasticity of demand equals 1. Total revenue does not change when the price changes. It is the dividing line between elastic and inelastic demand.
Total revenue | Price multiplied by quantity sold; the money a firm receives from its sales. Example: 40 notebooks sold at Tk 40 give total revenue of Tk 1,600. The total revenue test uses it to judge the effect of a price change.
Income elasticity | The percentage change in quantity demanded divided by the percentage change in consumers' income. A positive result means more income raises the quantity demanded. Example: income up 10% and fiction up 15% give 1.5.
Cross elasticity | The percentage change in quantity demanded of one good divided by the percentage change in the price of another. Positive for substitutes, negative for goods used together. Example: a rival notebook dearer by 10% and 4% more quantity give 0.4.

:glossary 06
Consumption | The use of goods and services by people to satisfy their wants. Eating a meal, riding a bus and filling a notebook with notes are all consumption. It takes place when the good is used, which may be later than the day of purchase. A firm that uses cloth to make shirts does not consume the cloth.
Willingness to pay | The highest price a buyer would pay for one more unit of a good. It is a limit held in the mind, not a price on a tag. It falls as a consumer buys more units and it differs between consumers. A consumer buys a unit only when the price is at or below this limit.
Consumers' surplus | The gap between what buyers are willing to pay for a good and what they actually pay. Added over all units bought, it measures the gain consumers keep. In the notebook case, a price of Tk 40 leaves three customers a surplus of Tk 30 in total. On a chart it is the triangle under the demand curve and above the price.

:glossary 07
Indifference curve | A line on a graph that joins every combination of two goods giving a consumer the same satisfaction. Because the satisfaction is equal along the line, she would not mind which combination she received. Example: 4 notebooks with 14 pens and 6 notebooks with 8 pens may lie on one curve.
Indifference map | A set of indifference curves drawn on one graph. A curve further from the corner where the axes meet shows greater satisfaction, so the map ranks every combination of the two goods. Example: 6 notebooks with 14 pens lies on a higher curve than 6 notebooks with 8 pens.
Marginal rate of substitution | The number of units of one good a consumer will give up to gain one more unit of another good, while her satisfaction stays the same. It is the steepness of the indifference curve. Example: giving up 3 pens for each extra notebook.
Budget line | A line on a graph showing every combination of two goods that a consumer can buy with a given income at given prices. Its ends are income divided by each price, and its steepness is the price ratio. Example: Tk 400 at Tk 40 and Tk 20 gives ends of 10 notebooks and 20 pens.
Consumer equilibrium | The point where a consumer gets the greatest satisfaction possible from a given income. It lies on the budget line, on the highest reachable indifference curve, where the marginal rate of substitution equals the price ratio. Example: 6 notebooks and 8 pens.

:glossary 08
Supply | The quantities of a good that sellers are willing and able to sell at each price in a period. Both the stock and the wish to sell are needed. One entry is a quantity supplied; the whole list is supply. For the notebook: 40 at Tk 40, 50 at Tk 50, and so on.
Supply schedule | A table showing the quantity supplied at each price. Each row pairs one price with one quantity. The wholesaler's table lists Tk 20 with 20 notebooks, Tk 30 with 30, and continues up to Tk 60 with 60.
Law of supply | When the price of a good rises, the quantity supplied rises, if other conditions stay the same. The same law says a fall in price lowers the quantity supplied. It is drawn as an upward-sloping line.
Supply curve | A line on a graph showing the quantity supplied at each price. Price is on the vertical axis and quantity on the horizontal axis. A point on the line means that at this price sellers offer this quantity. Usually the line slopes upward.
Exceptional supply curve | A supply curve that does not slope upward, such as one that bends backward or stays fixed. A worker who offers fewer hours at very high pay gives a backward-bending curve. Fish caught for one market day give a fixed supply.

:glossary 09
Elasticity of supply | The percentage change in quantity supplied divided by the percentage change in price. It tells us how strongly firms respond to a price change. If a 10% rise in price raises quantity supplied by 5%, the elasticity of supply is 0.5.
Competitive market | A market with many buyers and sellers, none of whom can set the price. Each one must accept the price that the whole market produces. A street of tea stalls selling the same tea is a small example.
Equilibrium price | The price at which the quantity buyers want equals the quantity sellers offer. At this price neither side has a reason to change its plans, so the price stays still. In the notebook market it is Tk 40.
Excess demand | A situation in which buyers want more than sellers offer at a price. Some buyers cannot obtain the good, so they offer more money and push the price up. In the notebook market at Tk 30, buyers want 50 and firms offer 30.
Excess supply | A situation in which sellers offer more than buyers want at a price. Some goods stay unsold, so sellers cut the price and push it down. In the notebook market at Tk 50, firms offer 50 and buyers want 30.

:glossary 10
Production function | A rule showing the largest output that can be made from each combination of inputs. It records what is technically possible with the best known methods. Example: 1 oven and 2 helpers can make at most 100 loaves a day.
Short run | A period so short that at least one input, such as a machine, cannot be changed. It is not a fixed number of days; it is whatever period leaves an input fixed. Example: a baker can hire helpers but cannot install a new oven.
Long run | A period long enough for all inputs to be changed. Its length differs between firms. Example: given years, a baker can build a new bakery and buy more ovens.
Total product | The whole quantity of output produced with a given amount of inputs. Example: the binding workshop with 4 workers has a total product of 44.
Marginal product | The extra output from adding one more unit of an input, others held fixed. It equals the change in total product divided by the change in the input. Example: the fourth worker adds 44 - 36 = 8.
Average product | Total product divided by the number of units of the input used. It shows the output per unit. Example: 44 ÷ 4 = 11 with 4 workers.
Law of diminishing returns | Adding more of one input to fixed amounts of others will, after a point, add less and less to output. It belongs to the short run and does not say that total output falls. Example: each worker beyond the second in the workshop.
Returns to scale | The change in output when all inputs are increased in the same proportion. It may be increasing, constant or decreasing. Example: doubling workers and machines raised output from 24 to 60.

:glossary 11
Explicit cost | A cost that involves a payment of money to people outside the firm, such as rent, wages, paper or interest on a loan. It appears in a receipt or bank record. A shop's monthly rent paid to its landlord is an example.
Implicit cost | The value of resources that the owner supplies to the firm, for which no money is paid. These resources could have earned money elsewhere, so they have an opportunity cost. An owner's unpaid time is an example.
Fixed cost | A cost that does not change with the quantity produced in the short run, because it is owed even when nothing is made. It is the cost of being ready to produce. A workshop's machine rent is an example.
Variable cost | A cost that changes with the quantity produced. It is zero when nothing is made and rises as output rises. Paper, thread, glue and the wages of extra workers are examples in a binding workshop.
Total cost | The whole cost of producing a given output, found by adding fixed cost and variable cost. At zero output it equals fixed cost. A workshop with fixed cost of Tk 600 and variable cost of Tk 720 has total cost of Tk 1,320.
Marginal cost | The extra cost of producing one more unit of output, found by dividing the change in total cost by the change in output. Fixed cost does not affect it. If total cost rises by Tk 220 for 10 more books, marginal cost is Tk 22 a book.
Average total cost | Total cost divided by the number of units produced, so that fixed and variable costs are shared among all units. It is the cost of each unit on average. A total cost of Tk 1,120 for 20 books gives Tk 56 a book.

:glossary 12
Isoquant | A line showing all combinations of two inputs that produce the same output. The word means equal quantity. In the case, the mixes (2, 10), (3, 6), (4, 4), (5, 3) and (6, 2) of workers and machines all give 100 books a day, so they lie on one isoquant.
Isocost line | A line showing all combinations of two inputs that cost the same total amount. Its slope is the ratio of the two input prices. With a wage of Tk 600 and a machine rent of Tk 400, every mix on the Tk 4,000 line, such as 4 workers and 4 machines, costs Tk 4,000.
Marginal rate of technical substitution | The amount of one input a firm can give up when it adds one unit of another, keeping output the same. It is the machines saved divided by the workers added along an isoquant, and it falls as workers replace machines. At the least-cost combination it equals the price ratio.
Least-cost combination | The mix of inputs that produces a given output at the lowest total cost. It lies where the lowest isocost line touches the isoquant. In the case, 4 workers and 4 machines make 100 books for Tk 4,000, less than any other mix on the isoquant.

:glossary 13
Market structure | The set of features of a market, such as the number of sellers, the kind of good, the ease of entry and the information buyers hold, that shape how firms behave. A row of identical potato stalls and a lone village pharmacy have different structures.
Industry | All the firms that produce the same kind of good. The quantity supplied by the industry is the sum of what its firms supply. All the firms that make notebooks, for example, form the notebook industry.
Perfect competition | A market with very many buyers and sellers, identical goods, free entry and full information. No real market meets all four conditions, so it is a model. A grain exchange comes near it, because wheat of one grade is the same whoever grew it.
Price taker | A firm that must accept the market price because its own sales are too small to affect it. If the market price is Tk 40, such a firm sells any quantity at Tk 40 and nothing at a higher price, so it chooses only its output.
Equilibrium of the firm | The output at which a firm earns the largest possible profit and has no wish to change. A price taker finds it where marginal cost equals the price. For the binding workshop at Tk 40, it is 50 units.
Normal profit | The least profit a firm must earn to stay in business, covering the owner's implicit costs, such as the value of the owner's own time. A baker who could earn a wage in a factory must earn at least that from her bakery.

:glossary 14
Monopoly | A market in which one seller supplies a good with no close substitute. Entry is blocked by barriers such as sole ownership of a resource, an exclusive legal right or a large cost advantage. Example: the only ferry across a river.
Price maker | A firm that can choose its price because it faces the whole demand of the market, as a monopolist does. It cannot choose both price and quantity, since the demand curve fixes one once the other is chosen. Example: the seller in the case file, who chooses Tk 50.
Marginal revenue | The extra revenue from selling one more unit of output. For a price maker it is smaller than the price, because a cut in price applies to every unit sold. Example: selling 10 more copies, from 20 to 30, adds Tk 300, or Tk 30 a copy.
Monopolistic competition | A market with many sellers of similar but not identical goods, and free entry. Each seller has a small power over its price, but new entrants take away extra profit over time. Example: a street of tea stalls.
Product differentiation | Making a good different from rivals' goods in quality, style or brand, to build loyal buyers. The differences may be real or only believed. Example: a stall that serves tea in clean glasses with a friendly greeting.
Oligopoly | A market dominated by a few large sellers, each aware of what the others do. Entry is hard, and each firm's best choice depends on its rivals' choices. Example: three bus firms on one road.

:glossary 15
Rent | The payment to the owner of land for its use, in everyday talk and in economics. In this book the word is kept for land. Example: Tk 60,000 a month paid for a shop site.
Economic rent | The payment to any factor above the least needed to keep it in use. For land as a whole the least needed is nothing, so the whole payment is economic rent. Example: a singer paid Tk 100,000 who would sing for Tk 40,000 earns Tk 60,000.
Quasi-rent | A temporary surplus earned by a man-made asset while its supply is fixed in the short run. It disappears when new assets are built. Example: printing presses when demand for books suddenly rises.
Wage | The payment to labour for its work over a period. It may be stated by the hour, the day or the month. Example: Tk 35,000 a month for a shop assistant.
Nominal wage | A wage measured in money, without allowing for changes in prices. It is the figure on the pay slip. Example: Tk 35,000 a month.
Real wage | A wage measured by the goods and services it can buy. It equals the nominal wage divided by the price index over 100. Example: 35,000 ÷ 1.12 = Tk 31,250.
Marginal revenue product | The extra revenue a firm gains from employing one more unit of labour. A firm hires while it is at least equal to the wage. Example: an assistant who adds Tk 40,000 a month.

:glossary 16
Interest | The payment a borrower makes to a lender for the use of money over time. It is stated as a yearly rate, which is the year's interest divided by the sum borrowed. Tk 100 paid on a loan of Tk 1,000 for a year is a rate of 10 per cent.
Loanable funds | The money that savers offer to lend and that borrowers demand to borrow at each rate of interest. Borrowers want more when the rate is low, and savers offer more when it is high. The rate where the two amounts are equal is the equilibrium rate.
Liquidity preference | The wish of people to hold money in cash form instead of lending it, because cash can be spent at once. Interest is the reward that persuades people to give up cash. Keeping money for emergencies is an example.
Accounting profit | Revenue minus explicit costs only. Revenue is the money a firm receives from sales. Accounting profit appears in a firm's accounts. A farmer who sells a harvest for Tk 300,000 and pays Tk 250,000 in costs has an accounting profit of Tk 50,000.
Economic profit | Revenue minus all costs, both explicit and implicit, including normal profit. It is accounting profit less the value of what the owner's time and money could earn elsewhere. A positive result is supernormal profit, and a negative result is below normal.
Risk bearing | The act of taking on the chance of loss in business, which profit rewards. A firm that makes goods before knowing whether buyers will come bears risk. One view of profit says owners are paid more on average for facing this chance.
