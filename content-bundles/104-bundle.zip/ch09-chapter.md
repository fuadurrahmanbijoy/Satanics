:chapter IX | Elasticity of Supply and Market Equilibrium
:mood Who decides a price when no single person decides it?
:desc This chapter measures how strongly sellers respond when the price changes. It then joins the buyers' side and the sellers' side of a market to find the price where the market settles, and shows what moves that price.
:plate ch09-plate.svg | Merchants at a corn exchange, where a bell opens the day's bargaining

:box YOU WILL NEED
Chapter 4, 'Demand and the Demand Curve', section 4.1 'Quantity Demanded and the Law of Demand'; Chapter 8, 'Supply and the Supply Curve', section 8.1 'Quantity Supplied and the Law of Supply'; Chapter 5, 'Elasticity of Demand', section 5.1 'Price Elasticity of Demand'; and Appendix A1, 'Maths You Will Use'.

> A seller must choose a price, yet no single seller truly decides it.

Early on a market morning, a seller unloads crates of notebooks and must choose a price. If the price is too high, shoppers walk past and the crates stay full. If the price is too low, the crates are empty by ten o'clock, and she wonders how much money she gave away. Every seller in the row faces the same worry, and each one watches the others.

> By evening the sellers charge almost the same price, and nobody announced it.

By evening, a strange thing has happened. Nobody called a meeting and nobody gave an order, yet the sellers in the row charge almost the same price, and most of the crates are sold. Something has guided hundreds of separate choices to one number. What is that something? Why did the price settle at this number and not at another?

> The chapter has two jobs: measure how sellers respond, then find where the market settles.

This chapter answers in two steps. First, we measure how strongly sellers react when the price changes; section 9.1 gives this measure its name. Second, we join the buyers' side and the sellers' side to find the price where the market settles, and we ask what moves that price. Many students find the second step easier once the first is secure, because both steps use the same idea of percentage change.

* * *

## 9.1 Elasticity of Supply

> The direction of the response is known from Chapter 8; its size is not.

Chapter 8 taught the law of supply: when the price of a good rises, firms offer more of it. That law gives a direction and nothing more. Suppose the price of a notebook rises by 10%. Will firms offer 2% more, or 20% more? A baker with a hot oven can bake extra loaves by the afternoon. A farmer who planted onions in March cannot grow more by Friday. Both respond in the same direction, yet the size of the response differs greatly. To compare them, we need one number that records the size.

@ Elasticity of supply | The percentage change in quantity supplied divided by the percentage change in price.

> A single number records how strongly sellers respond to a price change.

That number is called **elasticity of supply**. Elasticity of supply means the percentage change in quantity supplied divided by the percentage change in price. Suppose the price rises by 10% and the quantity supplied rises by 5%. Then the elasticity of supply is 5 ÷ 10 = 0.5. Because supply slopes upward, price and quantity supplied move in the same direction, so the answer is never negative.

> Recall: price elasticity of demand, Chapter 5, section 5.1 'Price Elasticity of Demand'.
> Percentages let us compare goods that are measured in different units.

Why do we use percentages and not plain changes? A change of 10 notebooks is large for a small shop and tiny for a printing firm. A change of 10 kilograms means little for rice and much for saffron. A percentage compares the size of the move with the starting amount. The measure copies the one you met for buyers in Chapter 5, with the quantity supplied in place of the quantity demanded.

### Measuring it

> Percentage of which number? The midpoint answers this question.

Measuring needs one decision: a percentage of which number? If the price moves from Tk 30 to Tk 40, the rise is 33% of Tk 30 but only 25% of Tk 40. The same journey gives two answers. The *midpoint method* removes the problem by dividing each change by the average of the start value and the end value.

> The formula, first in words and then in symbols.

The formula, in words: elasticity of supply equals the change in quantity supplied divided by the average quantity, all divided by the change in price divided by the average price. In symbols: Es = (ΔQ ÷ average Q) ÷ (ΔP ÷ average P). Here Es is the elasticity of supply, ΔQ is the change in quantity supplied, and ΔP is the change in price.^1

^1: Some books divide by the starting value instead of the average. That method gives a slightly different number when the change is large. This book uses the midpoint throughout.

> The case file gives a clean pair of numbers for the first calculation.

:case Case file, illustrative. In the notebook market where Meghna and Sons sells its popular 200-page notebook, the quantity supplied equals the price in taka. At a price of Tk 30, firms offer 30 notebooks. At a price of Tk 40, firms offer 40 notebooks. We now calculate the elasticity of supply between these two prices.

> Each step of the first calculation is shown, in the standard order.

*Given.* The price rises from Tk 30 to Tk 40. The quantity supplied rises from 30 to 40 notebooks.
*Find.* The elasticity of supply between Tk 30 and Tk 40.
*Formula.* Es = (ΔQ ÷ average Q) ÷ (ΔP ÷ average P), as defined above.
*Steps.* (1) Change in quantity: 40 − 30 = 10 notebooks. (2) Average quantity: (30 + 40) ÷ 2 = 35 notebooks. (3) Change in quantity as a fraction of the average: 10 ÷ 35 = 0.286. (4) Change in price: 40 − 30 = Tk 10. (5) Average price: (30 + 40) ÷ 2 = Tk 35. (6) Change in price as a fraction of the average: 10 ÷ 35 = 0.286. (7) Divide: 0.286 ÷ 0.286 = 1.0.
*Answer.* The elasticity of supply between Tk 30 and Tk 40 is 1.0.
*Check.* Both fractions are equal, so their ratio must be 1.

### Types of elasticity of supply

> The size of the number places supply into one of five types.

The size of the number places supply into one of five types. Read the table row by row: the first column gives the value, the second names the type, and the third says what firms do when the price rises.

:table Five types of elasticity of supply
| Value | Type | What firms do when the price rises |
| Greater than 1 | Elastic supply | Quantity supplied rises by a larger percentage than the price |
| Equal to 1 | Unit elastic supply | Quantity supplied rises by the same percentage as the price |
| Between 0 and 1 | Inelastic supply | Quantity supplied rises by a smaller percentage than the price |
| Zero | Perfectly inelastic supply | Quantity supplied does not change; the supply curve is a vertical line |
| Without limit | Perfectly elastic supply | Firms offer any quantity at one price; the supply curve is a horizontal line |

> The two extreme types are rare, and the notebook case sits at 1.

The two extreme rows are rare. Seats in a stadium on match day are close to perfectly inelastic, because the number of seats cannot change that afternoon. A straight supply line that starts at the origin, like the notebook line above, has an elasticity of exactly 1 at every point on it. Most goods lie between the extremes.

### Factors

> Time is the strongest factor, followed by spare capacity and stocks.

Four factors decide where a good lies in the table. *Time* matters most. In a day, a firm can only sell what it holds; in a year, it can build more machines. *Spare capacity* matters next: a printing firm with idle presses can raise output quickly. *Stocks* of finished goods allow a quick response, but perishable goods cannot be stored. *Inputs* matter too: if workers and materials are hard to find, output rises slowly.

> The manager and the owner see the same factors from different positions.

A manager asks, "Can my workers and machines make more this week?" An owner asks, "Is it worth buying a new machine?" The first question concerns the short run and gives a low elasticity. The second concerns the long run and gives a higher one. Elasticity of supply is therefore never a fixed property of a good; it depends on the period we choose.

> Before moving on, recall the measure and the five types.

*Before moving on.* Elasticity of supply measures how strongly firms respond to a price change, using percentages and the midpoint. A value above 1 is elastic, 1 is unit elastic, and below 1 is inelastic. Time, spare capacity, stocks and inputs decide the value.

* * *

## 9.2 Market Equilibrium

> A puzzle: neither side can force the price on the other.

Return to the market row. A seller wishes to charge Tk 60 for a notebook, but buyers will pay only Tk 30. Neither side can force the other. The price that finally appears comes from the meeting of both sides, and from neither side alone. To study that meeting, we must first say what kind of market we mean.

@ Market | Word in use. In daily life, a place where people meet to buy and sell, such as a street market. In economics, all the buyers and sellers of one good, wherever they are.
@ Competitive market | A market with many buyers and sellers, none of whom can set the price.

> We begin with markets where nobody controls the price.

We study a **competitive market**. A competitive market means a market with many buyers and sellers, none of whom can set the price. A street of tea stalls selling the same tea is an example: if one stall raises its price, buyers walk to the next stall. A market where one seller does control the price is a different case, taught in Chapter 14, 'Monopoly and Imperfect Competition', section 14.1 'Monopoly'.

@ Equilibrium | Word in use. In daily life, a state of balance, such as a scale holding still. In economics, a price and quantity at which nothing pushes the price to change.
@ Equilibrium price | The price at which the quantity buyers want equals the quantity sellers offer.

> The price where both sides agree is the equilibrium price.

The price at which the market settles has a name: the **equilibrium price**. The equilibrium price means the price at which the quantity buyers want equals the quantity sellers offer. If buyers want 40 notebooks and sellers offer 40 notebooks, both sides are satisfied and nobody has a reason to change the price. The quantity bought and sold at that price is the *equilibrium quantity*.

> The case file finds the equilibrium by setting the two quantities equal.

:case Case file, illustrative. In the notebook market, the quantity demanded equals 80 minus the price, and the quantity supplied equals the price. At the equilibrium price the two quantities are equal, so 80 − price = price. Then 80 = 2 × price, and the price is Tk 40. At Tk 40, buyers want 80 − 40 = 40 notebooks and firms offer 40 notebooks. The equilibrium price is Tk 40 and the equilibrium quantity is 40.

> How to read the chart: axes, curves and the crossing point.

To read the next chart, start with the axes. The horizontal axis shows the quantity of notebooks. The vertical axis shows the price in taka. A point on a line shows one price and the quantity that goes with it. The demand curve slopes downward and the supply curve slopes upward. Where they cross, the quantity demanded equals the quantity supplied, and that crossing is the equilibrium.

:fig Notebook market: demand and supply cross at the equilibrium price | ch09-fig01.svg

:pause 9.p1 | At the equilibrium price of Tk 40, how many notebooks do buyers want, and how many do firms offer?

@! Go slowly here.

> What happens at any other price is the work of the next two ideas.

Now ask what happens at a price other than Tk 40. The table below lists three prices from the notebook market. For each row, compare the two middle columns, which show how many notebooks buyers want and how many firms offer.

:table Notebook market at three prices
| Price | Quantity demanded | Quantity supplied | Result |
| Tk 30 | 50 | 30 | Buyers want 20 more than firms offer |
| Tk 40 | 40 | 40 | The two quantities are equal |
| Tk 50 | 30 | 50 | Firms offer 20 more than buyers want |

@ Excess demand | A situation in which buyers want more than sellers offer at a price, pushing the price up.

> Too low a price leaves buyers wanting more than is offered.

At Tk 30, buyers want 50 notebooks but firms offer only 30. This is **excess demand**. Excess demand means a situation in which buyers want more than sellers offer at a price, pushing the price up. The 20 buyers who find empty shelves offer more money to win the notebooks, and sellers notice that they can charge more. The price therefore rises towards Tk 40.

@ Excess supply | A situation in which sellers offer more than buyers want at a price, pushing the price down.

> Too high a price leaves sellers with unsold goods.

At Tk 50, firms offer 50 notebooks but buyers want only 30. This is **excess supply**. Excess supply means a situation in which sellers offer more than buyers want at a price, pushing the price down. Twenty notebooks stay unsold, and sellers cut the price to empty their shelves. The price therefore falls towards Tk 40.

:fig Shortage and excess supply at wrong prices | ch09-fig02.svg

> Both forces push towards the same price, which is why the market settles there.

The two forces point to the same place. Below the equilibrium price, excess demand pushes the price up. Above it, excess supply pushes the price down. Only at Tk 40 do the pushes stop. That is the answer to the opening puzzle: nobody decides the price, but every buyer and seller adds a small push, and the pushes balance at the equilibrium price.

> The rule has limits: adjustment takes time, and a controlled price blocks it.

The rule has limits. Adjustment takes time, and in a market for a perishable good the price may fall before the sellers understand why. A law that fixes the price blocks the pushes altogether; the Think It Through section returns to this. The rule also assumes a competitive market. Finally, from the owner's view the price is a signal, and from the consumer's view it is a limit on what can be bought.

> Before moving on, recall the three ideas of this section.

*Before moving on.* A competitive market has many buyers and sellers, none of whom set the price. The equilibrium price makes the quantity demanded equal the quantity supplied. Above it there is excess supply and the price falls; below it there is excess demand and the price rises.

* * *

## 9.3 Changes in Equilibrium

> A puzzle: a school opens nearby, and the equilibrium price may no longer hold.

A school opens beside the shop, and a hundred more students need notebooks. The price of notebooks was Tk 40 yesterday. Will it still be Tk 40 today? The equilibrium price holds only while the conditions behind demand and supply stay the same. When a condition changes, a curve moves, and the market finds a new crossing point.

@! Go slowly here.

> A shift moves a whole curve; a change of price moves us along a curve.

Two kinds of change must be kept apart. A *shift* means the whole demand curve or the whole supply curve moves, because something other than the price has changed, such as incomes or the price of materials. A *movement along* a curve happens when the price changes and the curve stays still. Section 9.2 showed movements along: as the price fell towards Tk 40, the quantity demanded rose along the demand curve.

> When demand shifts right, buyers want more at every price, so price and quantity both rise.

Take a demand shift first. When more buyers arrive, the demand curve shifts to the right. At the old price of Tk 40, buyers now want more than firms offer, so there is excess demand. The price rises. As it rises, firms offer more along the supply curve. The market settles at a higher price and a larger quantity.

> The case file finds the new crossing after demand rises.

:case Case file, illustrative. In the notebook market, demand rises to a quantity demanded of 100 minus the price, and supply stays at a quantity supplied equal to the price. At the new equilibrium, 100 − price = price, so 100 = 2 × price and the price is Tk 50. The quantity is 50 notebooks. The price has risen from Tk 40 to Tk 50, and the quantity from 40 to 50.

:pause 9.p2 | If demand shifts to the right and supply does not shift, what happens to the equilibrium price and the equilibrium quantity?

> When supply shifts left, sellers offer less at every price, so price rises and quantity falls.

Now take a supply shift. When the price of paper rises, firms make notebooks only at a higher cost to themselves, and the supply curve shifts to the left. At the old price, buyers want more than firms offer, so the price rises. As it rises, buyers move up the demand curve and buy fewer notebooks. The new equilibrium has a higher price and a smaller quantity.

> The case file finds the new crossing after supply falls.

:case Case file, illustrative. In the notebook market, supply falls to a quantity supplied of the price minus 10, and demand returns to the original quantity demanded of 80 minus the price. At the new equilibrium, 80 − price = price − 10, so 90 = 2 × price and the price is Tk 45. The quantity is 35 notebooks. The price has risen from Tk 40 to Tk 45, and the quantity has fallen from 40 to 35.

> Four single shifts have four predictable results, shown in one table.

The table below collects the four single shifts. Read each row from the left: the first column names the shift, and the next two columns give the effect on the equilibrium price and the equilibrium quantity.

:table Effects of single shifts on equilibrium
| Shift | Equilibrium price | Equilibrium quantity |
| Demand shifts right | Rises | Rises |
| Demand shifts left | Falls | Falls |
| Supply shifts right | Falls | Rises |
| Supply shifts left | Rises | Falls |

> When both curves shift together, one effect is certain and the other depends on size.

Sometimes both curves shift at once. Then the table gives two answers that may disagree. If demand shifts right and supply shifts left, both shifts push the price up, so the price certainly rises. But the shifts push the quantity in opposite directions, so the quantity depends on which shift is larger. When the effects disagree, we must calculate with the numbers; guessing is unsafe.

> Before moving on, recall the shift rule and the two kinds of change.

*Before moving on.* A shift moves a whole curve; a price change moves us along a curve. Demand shifting right raises both price and quantity. Supply shifting left raises the price and lowers the quantity. With two shifts, one effect is certain and the other depends on the sizes.

* * *

## Worked Examples

> Worked example 1 uses messier figures for the elasticity formula.

The first example uses figures that are not round, as real data seldom are. A tailoring firm sells shirts at Tk 200 and supplies 100 shirts a month. When the price rises to Tk 240, it supplies 110 shirts a month.

> The steps of worked example 1, from data to check.

*Given.* Price rises from Tk 200 to Tk 240. Quantity supplied rises from 100 to 110 shirts a month.
*Find.* The elasticity of supply.
*Formula.* Es = (ΔQ ÷ average Q) ÷ (ΔP ÷ average P).
*Steps.* (1) ΔQ = 110 − 100 = 10 shirts. (2) Average Q = (100 + 110) ÷ 2 = 105 shirts. (3) 10 ÷ 105 = 0.0952. (4) ΔP = 240 − 200 = Tk 40. (5) Average P = (200 + 240) ÷ 2 = Tk 220. (6) 40 ÷ 220 = 0.1818. (7) Es = 0.0952 ÷ 0.1818 = 0.52.
*Answer.* The elasticity of supply is about 0.52, so supply is inelastic.
*Check.* The quantity rose by about 9.5% and the price by about 18.2%. A smaller percentage over a larger one gives a value below 1, as found.

> Worked example 2 combines a market with two curves and a shift.

The second example joins the earlier techniques. It uses invented figures for a market in rice sacks. First we find the equilibrium; then demand shifts, and we find it again.

> The steps of worked example 2, before and after the shift.

*Given.* Quantity demanded = 70 − price. Quantity supplied = 2 × price − 20. Later, demand shifts to a quantity demanded of 100 − price.
*Find.* The equilibrium price and quantity before and after the shift.
*Formula.* At equilibrium, quantity demanded = quantity supplied.
*Steps.* Before: (1) 70 − price = 2 × price − 20. (2) Add 20 to both sides: 90 − price = 2 × price. (3) Add price to both sides: 90 = 3 × price. (4) Price = 90 ÷ 3 = 30. (5) Quantity = 70 − 30 = 40. After: (6) 100 − price = 2 × price − 20. (7) 120 = 3 × price. (8) Price = 40. (9) Quantity = 100 − 40 = 60.
*Answer.* The equilibrium moves from a price of 30 and a quantity of 40 to a price of 40 and a quantity of 60.
*Check.* At a price of 40, quantity demanded is 100 − 40 = 60 and quantity supplied is 2 × 40 − 20 = 60. Demand shifted right, and both price and quantity rose, as the table says.

> Common slips: units, signs and mixed-up shifts cause most wrong answers.

Three slips cause most wrong answers. First, forgetting to divide by the average and using the start value only. Second, writing the ratio upside down: the percentage change in quantity goes on top. Third, calling a price change a shift. Elasticity has no unit, because it divides one percentage by another; do not write taka or notebooks after it.

* * *

## Summary

> The whole chapter in a few lines.

Elasticity of supply is the percentage change in quantity supplied divided by the percentage change in price, found with the midpoint method. Values above 1 are elastic and below 1 are inelastic. In a competitive market, the equilibrium price makes the quantity demanded equal the quantity supplied. Excess demand pushes the price up; excess supply pushes it down. A shift of demand or supply moves the equilibrium to a new price and quantity.

## Think It Through

> Two short problems apply the chapter to real choices.

Use the notebook market of this chapter to answer the first question. Use the factors of section 9.1 for the second.

:q 9.t1 | A law forbids any price above Tk 30 for a notebook. Using the notebook market, state the quantity demanded, the quantity supplied and the excess demand at Tk 30, and say who gains and who loses.
:q 9.t2 | A farmer says, "Give me a year and I can supply far more rice, but this month I cannot." Which factor from section 9.1 does she describe, and what does it say about the elasticity of supply this month and next year?

## Where People Go Wrong

> Mistake one: treating a change of price as a shift.

*Mistake: "A fall in price shifts the demand curve."* A change in the price of the good moves buyers along the same curve. A shift needs a change in something else, such as the number of buyers. The corrected rule: price changes cause movements along; other changes cause shifts.

> Mistake two: reading elasticity as the steepness of the line.

*Mistake: "A flat supply curve is always elastic."* Steepness depends on the units of the axes, but elasticity uses percentages and does not. A straight line from the origin has an elasticity of 1 at every point, however steep it looks.

> Mistake three: thinking equilibrium means a fair price or a happy market.

*Mistake: "At equilibrium everyone is satisfied."* Equilibrium means only that no force pushes the price to change. Some buyers still cannot afford the good at that price, and some firms would like a higher price. The corrected rule: equilibrium describes balance, not fairness.

## In History

> In 2019, a sudden ban shifted supply and the price of onions in Dhaka jumped.

On 29 September 2019, the government of India banned the export of onions with immediate effect, to improve supply at home. Bangladesh imports about a quarter of the onions it uses, and the Commerce Minister of Bangladesh said that about nine-tenths of those imports came from India. The ban therefore shifted the supply of onions in Dhaka to the left. In the Kawran Bazar market, the price of imported onions rose from Tk 60 to Tk 100 a kilogram overnight, according to the *Business Standard*. In the following weeks, retail prices in Dhaka reached about Tk 250 a kilogram, according to the *Dhaka Tribune*.^2

^2: Prices differed by market, by variety and by day, so reports give different peaks.

> The case shows that short-run supply is inelastic and that time raises the response.

The case also shows the factors of section 9.1. In the short run, the supply of onions was inelastic: the harvest season had ended and the crop could not be grown again in a week. Buyers kept buying, because onions are a daily kitchen good. Over the following weeks, importers brought onions from other countries, including Pakistan and Egypt, and supply became more elastic. As the new onions arrived, the price eased.

## Review Questions

> Five questions follow the ladder from clean figures to a combined problem.

:q 9.1 | The price of a good rises from Tk 20 to Tk 30, and the quantity supplied rises from 90 to 110 units. Calculate the elasticity of supply with the midpoint method, and name its type.
:q 9.2 | The price of mangoes rises from Tk 100 to Tk 130 a kilogram. The weekly quantity supplied rises from 400 to 500 kilograms. Calculate the elasticity of supply.
:q 9.3 | The price of a good falls from Tk 60 to Tk 50, and the weekly quantity supplied falls from 330 to 270 units. Calculate the elasticity of supply, and name its type.
:q 9.4 | In a market, quantity demanded = 60 − price and quantity supplied = 2 × price. Find the equilibrium price and quantity. Then demand shifts to a quantity demanded of 90 − price; find the new equilibrium.
:q 9.5 | In the market of question 9.4, supply then shifts to a quantity supplied of 2 × price − 30, with demand at 90 − price. Find the new equilibrium, and compare it with the equilibrium after the demand shift only.

:read Alfred Marshall, Principles of Economics, 1890
