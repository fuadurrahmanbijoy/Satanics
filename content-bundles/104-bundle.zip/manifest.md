:bundle
status: ok
failures: 0
chapters: 16
appendix: none
changed-duplicates-resolved: 0
glossary-duplicates-removed: 0
chapter | ch01 | I | What Economics Is | 3454 | 2 | 7 | 8
chapter | ch02 | II | Scarcity, Choice and Opportunity Cost | 3188 | 1 | 5 | 10
chapter | ch03 | III | Utility and Diminishing Marginal Utility | 3192 | 2 | 5 | 10
chapter | ch04 | IV | Demand and the Demand Curve | 3203 | 3 | 10 | 11
chapter | ch05 | V | Elasticity of Demand | 3317 | 2 | 7 | 10
chapter | ch06 | VI | Consumption and Consumers' Surplus | 3253 | 1 | 3 | 8
chapter | ch07 | VII | Indifference Curve Analysis | 3555 | 2 | 5 | 10
chapter | ch08 | VIII | Supply and the Supply Curve | 3328 | 2 | 5 | 11
chapter | ch09 | IX | Elasticity of Supply and Market Equilibrium | 3139 | 2 | 5 | 9
chapter | ch10 | X | Production Function and Returns | 3388 | 2 | 8 | 12
chapter | ch11 | XI | Costs of Production | 3725 | 2 | 7 | 11
chapter | ch12 | XII | The Least-Cost Combination of Inputs | 3377 | 1 | 4 | 9
chapter | ch13 | XIII | Market Structure and Perfect Competition | 3577 | 2 | 6 | 8
chapter | ch14 | XIV | Monopoly and Imperfect Competition | 3747 | 2 | 6 | 10
chapter | ch15 | XV | Rent and Wages | 3489 | 2 | 7 | 10
chapter | ch16 | XVI | Interest and Profit | 2991 | 1 | 6 | 11
