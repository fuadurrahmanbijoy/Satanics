:answers 01
:a 1.p1 | (a) Positive: the shop's staff records can confirm the number 7. (b) Normative: whether the shop ought to employ an eighth person depends on values and judgement, and facts alone cannot settle it.
:a 1.t1 | The claim ignores that another condition changed in the same month, since free notebooks reduce the need to buy. Ceteris paribus requires all other things to stay the same, and here they did not. We cannot tell how much of the fall came from the price.
:a 1.t2 | Economic laws describe how people usually behave, so they state tendencies and not certainties. Exactness is not the test of usefulness; a usual pattern can still guide a seller or a government. Used with ceteris paribus, such a law separates one cause from many.
:a 1.1 | (a) Positive: staff records can test it. (b) Normative: it says what ought to be. (c) Positive: the accounts can confirm the figure. (d) Normative: should signals a value judgement.
:a 1.2 | (a) Micro: one firm. (b) Macro: the general price level. (c) Micro: one consumer. (d) Macro: a total for the whole economy.
:a 1.3 | Her wants cost Tk 60 + Tk 60 + Tk 30 = Tk 150, but she has only Tk 100. Wants exceed means by Tk 50, so she must choose and give up something.
:a 1.4 | Consumption, production, exchange and distribution. Examples: a reader takes a book home (consumption); a printer makes the book (production); the shop buys it from the printer (exchange); the shop's income pays staff and owner (distribution).
:a 1.5 | Ceteris paribus means all other things stay the same. An economic law states a usual tendency of people, while a law of nature, such as the fall of a stone, describes things that do not choose and holds exactly.

:answers 02
:a 2.p1 | The best alternative given up, which is the Tk 300 earned. Sleeping late is a lesser alternative and is not added.
:a 2.t1 | The cost is the Tk 120 that could have been earned, the best alternative. For a student with no job offer, or with a different alternative such as a tutoring fee, the cost would differ.
:a 2.t2 | The maximum is 1,000 books or 500 parcels. 600 books needs 30 hours and 300 parcels needs 30 hours, so 60 hours are needed; it is still not attainable.
:a 2.1 | A want is something a person would like to have, whatever the price. One want may be met, but others appear in its place, so the whole list is without limit.
:a 2.2 | Scarcity is the condition that resources are limited while wants are unlimited, so choices must be made. A rich person has limited time; a poor person has limited money.
:a 2.3 | The Tk 400 from working, as the best alternative. Resting is a lesser alternative and is not counted.
:a 2.4 | One pair of trousers costs 8 ÷ 4 = 2 shirts. One shirt costs 4 ÷ 8 = 0.5 pair of trousers.
:a 2.5 | Shelving gives 30 × 20 = 600 books; packing gives 10 × 10 = 100 parcels. All 40 hours are used, and at 600 books the curve allows 100 parcels, so the point lies on the curve.
:a 2.6 | First step: 10 buses lost for 5 cars, 2 per car. Second step: 20 buses lost for 5 cars, 4 per car. The opportunity cost rises.
:a 2.7 | Resources differ in their suitability, so moving them costs more and more. More resources, or better methods, would shift the curve outward.

:answers 03
:a 3.p1 | Higher. The second cup added some satisfaction, so the total rose, even though the second cup pleased her less than the first.
:a 3.p2 | 2 utils (25 minus 23). The marginal utility column gives it directly.
:a 3.t1 | By the fifth cup her want for tea has been met by the first four cups. She is no longer cold or thirsty, so a further cup adds nothing.
:a 3.t2 | Total utility = 25 + (−3) = 22 utils. She should refuse the sixth cup, because it lowers her total satisfaction.
:a 3.1 | Utility is the satisfaction a person gets from using a good or service. Example: the relief of a cold drink on a hot afternoon.
:a 3.2 | Totals: 50, then 50 + 35 = 85, then 85 + 20 = 105, then 105 + 5 = 110 utils.
:a 3.3 | Marginal utilities: 20, then 36 − 20 = 16, 48 − 36 = 12, 54 − 48 = 6, 56 − 54 = 2 utils.
:a 3.4 | As a person consumes more units of a good, the satisfaction added by each extra unit falls. It holds when the units are alike, tastes stay steady and consumption has no long gaps.
:a 3.5 | The marginal utility of the 5th book is 0 utils. Its opportunity cost is the other good the money could have bought, which would have given some satisfaction, so the student gives up something for nothing.
:a 3.6 | Falling marginal utility means each addition is smaller, not that the total shrinks. The total keeps rising while marginal utility is above zero.

:answers 04
:a 4.p1 | 50 notebooks. A lower price (Tk 30 against Tk 50) brings a larger quantity demanded, which is the law of demand.
:a 4.p2 | A movement along the curve, because the price of the good itself changed, and the quantity demanded falls from 40 to 30.
:a 4.t1 | Buyers may take a high price as a sign of quality or rank, or may expect the price to rise further. Their tastes or expectations then change with the price, so other conditions are not equal. A ring is not a very basic good, so it is not a Giffen good.
:a 4.t2 | The fare rise is a movement along the bus demand curve, with a smaller quantity demanded. Cheaper petrol makes car travel cheaper, and cars are a substitute for buses, so demand for bus travel shifts to the left.
:a 4.1 | The points are (20, Tk 60), (30, Tk 50), (40, Tk 40), (50, Tk 30), (60, Tk 20), with quantity on the horizontal axis. The line slopes downward: each Tk 10 fall in price adds 10 notebooks, so a lower price goes with a larger quantity demanded.
:a 4.2 | The new curve lies 5 notebooks to the left of the old one at every price. A rise of 10 on the old curve gives Q = 90 − P, so the quantity at Tk 40 is 50 (40 + 10).
:a 4.3 | (a) movement; (b) shift, to the right, since pens and notebooks are used together; (c) shift, to the left; (d) movement.
:a 4.4 | At Tk 35, Q = 80 − 35 = 45 notebooks. For Q = 55, P = 80 − 55 = Tk 25.
:a 4.5 | Substitute goods: tea and coffee; a price rise for tea raises demand for coffee. Complementary goods: pens and notebooks; a price rise for pens lowers demand for notebooks.
:a 4.6 | A Giffen good is a rare, very basic good for which quantity demanded rises when its price rises. It is not the usual case because for almost every good a higher price lowers the quantity demanded.
:a 4.7 | Demand rises, so the curve shifts to the right. The number of buyers has changed, and that is a determinant of demand.

:answers 05
:a 5.p1 | %ΔP = 4 ÷ 10 × 100 = +40%; %ΔQ = -10 ÷ 25 × 100 = -40%; E = 40 ÷ 40 = 1, so demand is unit elastic.
:a 5.t1 | Quantity demanded falls by about 0.3 × 10% = 3%. Demand is inelastic, so total revenue rises, because the 10% higher price outweighs the 3% fall in quantity.
:a 5.t2 | With time, consumers find substitutes and change habits, so demand becomes more elastic. A large rise may also lose customers who watch the price closely, so the gain in revenue may not last.
:a 5.1 | It is the percentage change in quantity demanded divided by the percentage change in price. Percentages remove units and starting levels, so goods of different size can be compared.
:a 5.2 | The base is the average of the old and new values, which is the same whichever is called old. The percentage and so the elasticity do not depend on the direction.
:a 5.3 | %ΔQ = -20 ÷ 50 × 100 = -40%; %ΔP = 10 ÷ 25 × 100 = +40%; E = 1. Demand is unit elastic.
:a 5.4 | Quantity rises from 40 to 50: %ΔQ = 10 ÷ 45 = 22.22%; price falls from 40 to 30: %ΔP = 10 ÷ 35 = 28.57%; E = 0.78, inelastic. Total revenue falls from Tk 1,600 to Tk 1,500, as the test predicts.
:a 5.5 | Income elasticity = 10% ÷ 20% = 0.5.
:a 5.6 | Cross elasticity = -3% ÷ 5% = -0.6. The negative sign shows that tea and sugar are used together.
:a 5.7 | A brand of tea has many close substitutes, namely other brands, so a consumer can switch when its price rises. Tea in general has fewer substitutes.

:answers 06
:a 6.p1 | No. The price of Tk 12 is above the willingness to pay of Tk 9, so the consumer does not buy the pen.
:a 6.t1 | Each old buyer keeps Tk 10 more, because the price fell by Tk 10, and 3 x 10 = Tk 30. A fourth customer joins but adds Tk 0. The total rises by Tk 30, from Tk 30 to Tk 60.
:a 6.t2 | The toll is only what users pay. Many would have paid more, and the gap between what they would pay and the Tk 20 is their surplus. The benefit is the toll plus this surplus, so it is larger than the tolls collected.
:a 6.1 | Consumption is the use of goods and services by people to satisfy their wants. Example: drinking water, or travelling by bus.
:a 6.2 | Price is what the consumer must pay, Tk 40 in the notebook case. Willingness to pay is the most the consumer would pay, for instance Tk 60 for the first customer. The gap, Tk 20, is that customer's surplus.
:a 6.3 | At Tk 50: (60 - 50) + (50 - 50) = Tk 10. At Tk 20: 40 + 30 + 20 + 10 + 0 = Tk 100.
:a 6.4 | At Tk 16: (30 - 16) + (22 - 16) + (16 - 16) = 14 + 6 + 0 = Tk 20. At Tk 10: 20 + 12 + 6 + 0 = Tk 38. The rise is 38 - 20 = Tk 18.
:a 6.5 | Willingness to pay falls with each unit, because marginal utility falls. The last unit bought has a willingness to pay close to the price, so the gap between them is close to zero.

:answers 07
:a 7.p1 | No. Q has the same notebooks as P but 2 more pens, so Q is better. Two combinations on one curve must please equally.
:a 7.p2 | As she gives up pens, those that remain become more precious to her, and as notebooks pile up each extra one is worth less. So she parts with fewer pens for each extra notebook.
:a 7.t1 | The old combination now costs 6 × Tk 40 + 8 × Tk 10 = Tk 240 + Tk 80 = Tk 320, which is less than Tk 400, so she can still buy it and has Tk 80 left. She can therefore reach a higher curve, so she is better off. The exact new best point depends on her curves.
:a 7.t2 | Suppose two curves cross at X. Take A on one curve to the right of X, and B on the other curve directly above A, with the same notebooks and more pens. B is better than A. But A and B each please equally with X, so they would be equal. The two statements clash, so the curves cannot cross.
:a 7.1 | Tk 200 ÷ Tk 40 = 5 notebooks, or Tk 200 ÷ Tk 20 = 10 pens. Two others: 2 notebooks and 6 pens (80 + 120 = 200); 3 notebooks and 4 pens (120 + 80 = 200).
:a 7.2 | Pens given up: 8 − 5 = 3. Notebooks gained: 8 − 6 = 2. Rate = 3 ÷ 2 = 1.5 pens per notebook. It is smaller than 3, because she now holds fewer pens and more notebooks, so she gives up fewer pens for each notebook.
:a 7.3 | Notebooks: 450 ÷ 50 = 9. Pens: 450 ÷ 30 = 15. Steepness: 50 ÷ 30 = 1.67 pens per notebook. Check: 9 × 50 = Tk 450.
:a 7.4 | Notebooks: 400 ÷ 50 = 8, down from 10. Pens: 400 ÷ 20 = 20, unchanged. The line turns inwards around the pen point and becomes steeper: 50 ÷ 20 = 2.5 pens per notebook.
:a 7.5 | No. The price ratio is 2, but her rate is 4: she would give up 4 pens for one more notebook while the market asks only 2. She gains by buying more notebooks and fewer pens, moving towards 6 notebooks and 8 pens.
:a 7.6 | 2 pens × Tk 20 = Tk 40. This equals the price of Tk 40, so her consumers' surplus on that last notebook is Tk 40 − Tk 40 = 0.

:answers 08
:a 8.p1 | 50 notebooks. A higher price (Tk 50 against Tk 30) brings a larger quantity supplied, which is the law of supply.
:a 8.p2 | A shift to the right, because a subsidy lowers the seller's expense, so more notebooks are offered at every price. The price of notebooks itself did not change.
:a 8.t1 | At a high rate of pay the worker can earn the income needed in fewer hours, and may value rest more. The curve rises, reaches a peak and bends backward.
:a 8.t2 | For the day, the curve is a vertical line at 200 fish, since more cannot be had at any price. Over a week more fish can be brought, so the quantity supplied can rise with the price and the curve slopes upward.
:a 8.1 | The points are (20, Tk 20), (30, Tk 30), (40, Tk 40), (50, Tk 50), (60, Tk 60), with quantity on the horizontal axis. The line slopes upward: each Tk 10 rise in price adds 10 notebooks, so a higher price goes with a larger quantity supplied.
:a 8.2 | The new curve lies 10 notebooks to the left of the old one at every price. An increase of 15 on the old curve gives Qs = P + 15, so the quantity at Tk 40 is 55 (40 + 15).
:a 8.3 | (a) movement; (b) shift, to the right; (c) shift, to the right; (d) movement.
:a 8.4 | At Tk 55, Qs = 55 notebooks. For Qs = 25, P = Tk 25. With Qs = P − 10, at Tk 55 the quantity is 55 − 10 = 45.
:a 8.5 | When the price of a good rises, the quantity supplied rises, if other conditions stay the same. Costs of inputs, technology, taxes and subsidies, or the number of sellers must stay fixed.
:a 8.6 | A backward-bending curve, such as hours of work offered at a very high rate of pay; and a fixed supply, such as the fish caught for one market day.
:a 8.7 | Supply rises, so the curve shifts to the right. The number of sellers has changed, and that is a determinant of supply.

:answers 09
:a 9.p1 | Buyers want 80 − 40 = 40 notebooks, and firms offer 40 notebooks. The two quantities are equal.
:a 9.p2 | Both rise. The shift creates excess demand at the old price, the price climbs, and firms offer more along the supply curve.
:a 9.t1 | At Tk 30, buyers want 50 notebooks and firms offer 30, so excess demand is 20. Buyers who obtain a notebook gain a lower price; the 20 who cannot buy, and the firms who cannot charge more, lose.
:a 9.t2 | She describes time. This month supply is inelastic because the crop cannot grow faster; next year it is more elastic because she can plant more.
:a 9.1 | ΔQ = 20, average Q = 100, so 0.2. ΔP = 10, average P = 25, so 0.4. Elasticity = 0.2 ÷ 0.4 = 0.5. Supply is inelastic.
:a 9.2 | ΔQ = 100, average Q = 450, so 0.222. ΔP = 30, average P = 115, so 0.261. Elasticity = 0.222 ÷ 0.261 = about 0.85.
:a 9.3 | ΔQ = 60, average Q = 300, so 0.2. ΔP = 10, average P = 55, so 0.182. Elasticity = 0.2 ÷ 0.182 = 1.1. Supply is elastic.
:a 9.4 | Before: 60 − price = 2 × price, so price = 20 and quantity = 40. After: 90 − price = 2 × price, so price = 30 and quantity = 60.
:a 9.5 | 90 − price = 2 × price − 30, so 120 = 3 × price, price = 40, quantity = 50. Compared with the demand shift only (price 30, quantity 60), the price is higher and the quantity is lower.

:answers 10
:a 10.p1 | Marginal product of the third helper = 18 - 12 = 6 loaves. Average product with 3 helpers = 18 ÷ 3 = 6 loaves.
:a 10.p2 | The 8 means the fourth worker adds 8 to total product (44 - 36). Average product with 4 workers is 44 ÷ 4 = 11.
:a 10.p3 | With some inputs fixed, extra units of one input eventually add less and less to output. The fixed input is the machine.
:a 10.t1 | The machine is already used to its limit and the bench is crowded, so the extra worker has no machine time to use. The cause is the fixed input, not the skill of the worker.
:a 10.t2 | Each extra worker adds less output for the same wage, so more worker-days, and more pay, are needed for each extra unit of output.
:a 10.1 | A production function is a rule showing the largest output that can be made from each combination of inputs. It records the best method known, not what a careless firm might produce.
:a 10.2 | In the short run at least one input is fixed; in the long run all inputs can be changed. A machine or an oven is a fixed input.
:a 10.3 | Marginal product: 30, 40, 30, 20. Average product: 30, 35, 33.33, 30.
:a 10.4 | The third worker's marginal product is 12, equal to the average of 12 for 2 workers, so the average does not change.
:a 10.5 | Output rises by less than the inputs (2.4 against 3): decreasing returns to scale.
:a 10.6 | Output rises by more than the inputs (2.6 against 2): increasing returns to scale.
:a 10.7 | The law changes one input and holds others fixed, and it belongs to the short run; returns to scale changes all inputs together, and it belongs to the long run. The law concerns the extra output; returns to scale compares proportional changes.

:answers 11
:a 11.p1 | Yes. It is an implicit cost, because the building has a best alternative use worth Tk 5,000 a month, although she pays nothing in money.
:a 11.p2 | Total cost rises by 1,560 − 1,320 = Tk 240 for 10 books, so marginal cost is 240 ÷ 10 = Tk 24 a book.
:a 11.t1 | Average variable cost rises by Tk 2, but average fixed cost falls from Tk 15 to Tk 12, a fall of Tk 3. The net change is −Tk 1. Marginal cost of Tk 34 is also below the old average of Tk 39, which pulls the average down.
:a 11.t2 | Her time is an implicit cost, because it could earn a wage elsewhere. She should ask: what is the best use of my time outside the shop, and what is it worth?
:a 11.1 | Explicit costs: 8,000 + 3,000 = Tk 11,000. Implicit costs: her time, Tk 12,000, plus the rent forgone on the building, Tk 5,000, which is Tk 17,000.
:a 11.2 | Total cost = 200 + variable cost: Tk 200, 300, 380, 440, 520, 630 and 760 at outputs of 0, 5, 10, 15, 20, 25 and 30.
:a 11.3 | Marginal cost per page for each step of five pages: Tk 20, 16, 12, 16, 22 and 26. For example, (300 − 200) ÷ 5 = 20.
:a 11.4 | ATC = TC ÷ Q: Tk 60.00, 38.00, 29.33, 26.00, 25.20 and 25.33 at 5 to 30 pages. It is lowest at 25 pages, at Tk 25.20.
:a 11.5 | Total cost for one day at 20 pages is Tk 520, which includes the fixed cost. For 6 days, 520 × 6 = Tk 3,120.
:a 11.6 | Total cost at 20 pages rises by Tk 60, from 520 to 580. Marginal cost does not change, because fixed cost cancels in the subtraction. Average total cost at 20 pages is 580 ÷ 20 = Tk 29.
:a 11.7 | Forgone interest = 0.08 × 3,000,000 = Tk 240,000. Implicit costs = 360,000 + 240,000 = Tk 600,000. Result = 500,000 − 600,000 = −Tk 100,000.

:answers 12
:a 12.p1 | 4,800 / 600 = 8 workers.
:a 12.t1 | The firm moves toward machines: fewer workers and more machines. At the new wage the least-cost mix is (3, 6) at Tk 5,100. Keeping (4, 4) would cost Tk 5,200, a rise of 4 x 300 = Tk 1,200. Changing the mix limits the rise to Tk 1,100.
:a 12.t2 | No. With 6 machines fixed, the mix for 100 books is (3, 6), which costs Tk 4,200. That is Tk 200 above the least cost of Tk 4,000 at (4, 4). Only workers can be changed in the short run.
:a 12.1 | An isoquant joins all mixes of two inputs that give the same output. An isocost line joins all mixes that cost the same total amount. Output can be counted in units, but the satisfaction shown by an indifference curve cannot be counted.
:a 12.2 | All workers: 4,800 / 600 = 8 workers. All machines: 4,800 / 400 = 12 machines. The slope is the price ratio 600 / 400 = 1.5.
:a 12.3 | Costs: (1, 8) = 30 + 80 = Tk 110; (2, 4) = 60 + 40 = Tk 100; (4, 2) = 120 + 20 = Tk 140; (8, 1) = 240 + 10 = Tk 250. The least-cost combination is (2, 4) at Tk 100.
:a 12.4 | Costs: (2, 10) = 1,200 + 3,000 = Tk 4,200; (3, 6) = 1,800 + 1,800 = Tk 3,600; (4, 4) = 2,400 + 1,200 = Tk 3,600; (5, 3) = 3,000 + 900 = Tk 3,900; (6, 2) = 3,600 + 600 = Tk 4,200. Two mixes tie at Tk 3,600. The MRTS between them is 2, which equals the new price ratio 600 / 300 = 2.
:a 12.5 | At (4, 4): 2,400 / 4,000 = 60%. At (3, 6) with the wage at Tk 900: 2,700 / 5,100 = 52.9%. The share falls because the firm replaces workers with machines.
:a 12.6 | Workers: 30 / 600 = 0.05 books per taka. Machines: 10 / 400 = 0.025 books per taka. Workers add more per taka, so the firm should hire more workers and rent fewer machines.

:answers 13
:a 13.p1 | Its sales fall to nothing. Buyers can obtain an identical good at Tk 40 from other firms and know that price, so no one pays Tk 42.
:a 13.t1 | Other firms see the profit and, since entry is free, they begin to sell the good. Industry supply shifts to the right, the price falls, and the fall stops when no profit above normal remains.
:a 13.t2 | The potato seller faces very many sellers of an identical good, and customers can easily move to the next stall. The pharmacist is the only seller for ten kilometres, so customers have little choice and entry of rivals is unlikely.
:a 13.1 | Extra revenue per step is 5 × 10 = 50. Extra costs are 20, 35, 45, 60, so extra profits are +30, +15, +5, −10. The best output is 15 units, and the steps made add 30 + 15 + 5 = Tk 50.
:a 13.2 | Extra revenue per step is 500; extra costs are 300, 220, 200, 240, 340, 480, so every step adds profit and the best output is 60 units. Total revenue is 60 × 50 = 3,000, total cost is 1,900 + 480 = 2,380, and profit is Tk 620.
:a 13.3 | Each step earns extra revenue of 100 × 20 = 2,000 against extra costs of 1,800, 1,400, 1,600, 2,200, 3,000. Extra profits are +200, +600, +400, −200, −1,000. The best output is 300 kilograms, and the steps made add Tk 1,200.
:a 13.4 | New demand: 100 − price = price, so the price is Tk 50. The workshop's best output is 60 units and its profit is Tk 620, against Tk 100 at Tk 40. Profit above normal attracts new firms, so industry supply shifts right and the price falls in the long run.
:a 13.5 | Monopolistic competition: many sellers, different versions of the good (each tailor has a style) and easy entry.

:answers 14
:a 14.p1 | To sell 30 units she must cut the price on all units. She loses Tk 10 on each of the first 20 units (Tk 200) and gains 10 new units at Tk 50 (Tk 500). The net gain is Tk 300, or Tk 30 a unit, which is below Tk 50.
:a 14.p2 | Each firm fears that rivals would copy a price cut but not a price rise, so a change brings it little gain either way. It leaves the price alone.
:a 14.t1 | No. One large firm may serve everyone at a lower cost for each unit than many small firms, and a market of differentiated goods gives variety that identical goods cannot. Price is only one measure of how well a market serves consumers.
:a 14.t2 | At 50 units marginal revenue is −10, so the extra units lower revenue while adding cost. Output of 40 units gives revenue Tk 1,600 against Tk 1,500 at 50, and cost falls from Tk 1,900 to Tk 1,560, so profit rises from −Tk 400 to Tk 40.
:a 14.1 | (1,600 − 1,500) ÷ (40 − 30) = 100 ÷ 10 = Tk 10 per unit.
:a 14.2 | Marginal revenue per unit: 50, 30, 10, −10. Take the first two steps (50 over 20, 30 over 22); stop at the third (10 under 25). Output 20 units, price 60 − 20 = Tk 40. Total cost = 100 + 200 + 220 = Tk 520. Profit = 800 − 520 = Tk 280.
:a 14.3 | Tk 300 for the whole step of 10 units is Tk 300 ÷ 10 = Tk 30 per unit, so the figures agree. Compare the per-unit figure, Tk 30, with the marginal cost of Tk 20 per unit; marginal revenue is higher, so the step is worth taking.
:a 14.4 | At 40 units the price is Tk 40 and the marginal cost is Tk 24, so output rises; at 50 units the price is Tk 30 and the marginal cost is Tk 34, so it stops. Competitive output is 40 units at Tk 40, against 30 units at Tk 50 for the monopoly: ten more units at Tk 10 less.
:a 14.5 | (a) Monopolistic competition. (b) Oligopoly. (c) Monopoly.
:a 14.6 | Marginal revenue = (900 − 800) ÷ 10 = Tk 10 per cup. This is below the marginal cost of Tk 12, so the stall should not sell the extra 10 cups. Yes, Tk 10 is below the price of Tk 18.

:answers 15
:a 15.p1 | The 60-bag land pays no rent. The 70-bag land pays 70 - 60 = 10 bags, and the 90-bag land pays 90 - 60 = 30 bags.
:a 15.t1 | Demand: a surgeon's work brings in or saves a great deal, so the marginal revenue product is high. Supply: few people can qualify because training is long and costly. High demand and small supply give a high wage.
:a 15.t2 | The farm's yield net of transport falls less, or its sale price rises, so its advantage over the marginal land grows and its rent rises. Demand for its use rises while its supply is fixed.
:a 15.1 | Rent is the payment to the owner of land for its use. Nobody can make more land, so the total supply does not respond to payment.
:a 15.2 | Economic rent = 80,000 - 50,000 = Tk 30,000.
:a 15.3 | Marginal land: 0. The 100 kg grade: 100 - 80 = 20 kg. The 120 kg grade: 120 - 80 = 40 kg.
:a 15.4 | 120 ÷ 100 = 1.2, and 24,000 ÷ 1.2 = Tk 20,000.
:a 15.5 | The real wage falls. Money rises by 5% but prices rise by 8%, so purchasing power is lower.
:a 15.6 | Hire two. The first two add 45,000 and 34,000, above the wage of 30,000. The third adds 29,000, which is below it.
:a 15.7 | Rent is the lasting payment to the owner of land, whose supply is fixed. Quasi-rent is a temporary surplus of a man-made asset while its supply is fixed in the short run, and it disappears as new assets are built.

:answers 16
:a 16.p1 | Interest = 200,000 × 0.09 = Tk 18,000. Total repayment = 200,000 + 18,000 = Tk 218,000.
:a 16.p2 | Accounting profit = 900,000 − 700,000 = Tk 200,000. Economic profit = 200,000 − 150,000 = Tk 50,000, which is supernormal profit.
:a 16.t1 | The risky venture may end in loss, and owners will not accept that chance unless the average reward is larger. If it earned no more, few people would take the risk. Profit is the reward for facing the chance of loss.
:a 16.t2 | The small trader is a riskier borrower, because the chance of non-repayment is higher. A small loan also costs almost as much to administer as a large one, so the cost per taka lent is higher.
:a 16.1 | Interest = 50,000 × 0.10 = Tk 5,000. Total repayment = 50,000 + 5,000 = Tk 55,000.
:a 16.2 | 9.5 per cent is 0.095. Interest = 450,000 × 0.095 = Tk 42,750.
:a 16.3 | Interest for a year is 600,000 × 0.11 = Tk 66,000. Three months is 3 ÷ 12 of a year, so interest = 66,000 × 3 ÷ 12 = Tk 16,500.
:a 16.4 | Forgone interest = 0.06 × 2,000,000 = Tk 120,000. Implicit costs = 300,000 + 120,000 = Tk 420,000. Economic profit = 420,000 − 420,000 = Tk 0. This is normal profit only.
:a 16.5 | Economic profit = 380,000 − 450,000 = −Tk 70,000. The owner could earn Tk 70,000 more elsewhere, so the result is below normal profit.
:a 16.6 | Accounting profit = 2,000,000 − 1,700,000 = Tk 300,000. Forgone interest = 0.08 × 1,000,000 = Tk 80,000. Implicit costs = 200,000 + 80,000 = Tk 280,000. Economic profit = 300,000 − 280,000 = Tk 20,000, which is supernormal profit.
:a 16.7 | Risk bearing, limit: it does not pay every risk-taker. Marginal productivity, limit: one owner's contribution is hard to measure. Innovation, limit: many profits need no new idea. Monopoly, limit: it does not explain profit among many rivals.
