:chapter II | Scarcity, Choice and Opportunity Cost
:mood Every road taken leaves another road behind.
:desc This chapter shows why every choice gives something up, how to measure what is given up, and how a single curve can picture the choices open to a person, a firm or a country.
:plate ch02-plate.svg | A traveller stops where the road divides

:box YOU WILL NEED
Chapter 1, 'What Economics Is', section 1.1 'The Meaning and Scope of Economics', for the meaning of economics; Chapter 1, section 1.4 'Economic Laws', for laws and the same-conditions rule; and Appendix A1, 'Maths You Will Use', for ratios and simple graphs.

> A traveller must choose one road, and the other road is lost.

A traveller walks along a country road at the end of an afternoon. Ahead, the road divides in two. A signpost stands on each branch. One road leads to a market town, where the traveller could sell goods and buy supplies. The other leads to a river village, where an old friend waits and a good meal is promised. Night is coming, and there is strength for only one more journey today.

> The traveller's trouble is not a lack of roads but a lack of time.

The traveller does not lack roads, and does not lack good reasons. Both roads are worth taking. What the traveller lacks is time, because the evening allows only one walk. Whichever road is chosen, something valuable is left behind. No clever planning removes that loss. It can only be understood, measured and weighed against the gain.

> The same pattern appears in every shop, household and country.

The same pattern appears everywhere. A family with Tk 20,000 to spend cannot buy everything on its list. A shopkeeper with one free afternoon cannot both count stock and visit a supplier. A government with one budget cannot build every road and school it would like. This chapter gives the pattern a name and a measure. Section 2.1 explains why choice cannot be avoided. Section 2.2 shows how to measure what choice gives up. Section 2.3 draws the idea as a curve.

* * *

## 2.1 Wants and Scarcity

### Wants

@! Go slowly here.

> Everyday life shows how one wish leads to the next.

Begin with your own week. This morning you wished for a good breakfast, and you had it. By noon you wished for a new pair of shoes. By evening you wished for a holiday by the sea. Each wish was met or set aside, and each was soon replaced by another. You never reached a day with no wish left. This simple observation is the first step in economics.

@ Want | Something a person would like to have, however little or much the person can pay for it.

> A want is anything a person would like to have.

Economists give such wishes a name. A **want** means something a person would like to have, however little or much the person can pay for it. A bicycle is a want. So are a meal, a university degree, an afternoon of rest and a quiet street. The definition does not ask whether the want is wise or sensible. A want need not be a physical good; it may be a service, such as a haircut, or a condition, such as free time.

> Wants differ among people, but wishing never ends.

Wants differ from person to person and from place to place. A farmer in Mymensingh, a banker in London and a student in Dhaka will list different wants. Wants also change with age and with income. Yet one feature is shared. When one want is satisfied, another appears, often a larger one. A person who owns a bicycle wishes for a motorcycle; a person with a motorcycle wishes for a car. Economists therefore treat wants, taken together, as without a limit.

> Individual wants can be satisfied for a moment, but not for good.

There is an exception that confuses many students. A single want can be satisfied. After a full meal, you do not wish for another. This does not contradict the point above. The want for that meal has ended for now, yet it returns within hours, and other wants stand ready to take its place. What has no end is the whole list.

> Before moving on: a want is a wish, and the whole list of wants has no end.

*Before moving on.* A want is something a person would like to have, whatever the price. One want may be met for a time, but the list as a whole keeps growing. This is half of the picture. The other half follows.

### Scarcity and resources

@! Go slowly here.

> A market stall shows the limit that meets unlimited wishes.

Think of a market stall. The owner has a small table, a few hours and a purse of money. The customers wish for many goods, but the stall can offer only what the table can hold, what the hours allow and what the purse can buy. The owner's wishes are larger than the stall. The same is true for every household, firm and country, for the same reason: the things used to make goods and services are limited.

> Resources are the things used to produce goods and services.

Economists call these things resources. Resources are the inputs used to make goods and services: land and raw materials, the work of people, tools and machines, money, and time. A bakery's resources include its oven, its flour, its bakers and its hours. A country's resources include its farmland, its rivers, its factories and its workers. Not one of them is unlimited at a given time.

@ Scarcity | The condition that resources are limited while wants are unlimited, so choices must be made.

> Scarcity is the gap between unlimited wants and limited resources.

When unlimited wants meet limited resources, the result is **scarcity**. Scarcity means the condition that resources are limited while wants are unlimited, so choices must be made. A family cannot buy everything on its list, and a country cannot build everything its citizens wish for. Scarcity is the reason economics exists. If every want could be met at once, nothing would need to be chosen and nothing would need to be studied.

> Scarcity is not the same as rarity, and it is not the same as poverty.

Scarcity has two common misreadings. The first is that scarcity means rarity. Air is common, but a pure breath of it in a crowded city may be scarce, and the same is true of clean water. The second is that scarcity belongs only to poor people. A billionaire also has limited time and must choose. Scarcity affects rich and poor, and it applies to every society.^1

^1: Robbins, whom you will meet in the section 'In History', argued that scarcity of means with alternative uses is the common feature of every economic problem.

@ Choice | Word in use. In daily life, the thing selected, or the freedom to select. In economics, picking one use of limited resources and so giving up the others.

> Choice is the act of selecting among uses of limited resources.

Scarcity forces choice. Faced with limited resources, a person, a firm or a government must decide which wants to meet and which to leave. A choice may be made carefully or carelessly, openly or without thought. Doing nothing is also a choice, because the hours and the money go somewhere. The question is never whether to choose, but how well.

> Households, firms and governments each face scarcity in their own way.

Each decision maker meets scarcity from a different side. A household has a fixed income and must divide it among food, rent, school fees and savings. A firm has a limited budget, a limited number of workers and a limited number of working hours, and must decide what to make and how much. A government has limited tax income and must divide it among roads, schools, hospitals and defence. The three decision makers differ in size, yet all three must choose, and every choice leaves some wants unmet.

> Before moving on: scarcity is the meeting of limited resources with unlimited wants.

*Before moving on.* Resources are limited; wants are not. Scarcity is the condition that results, and it forces choices on everyone. You should now be able to say why a billionaire and a farmer both face scarcity, though their choices differ.

* * *

## 2.2 Opportunity Cost

### What is given up

@! Go slowly here.

> Every choice has a price in what is left behind, even when no money changes hands.

Return to the traveller. If the traveller walks to the market town, the evening with the old friend is lost. If the traveller walks to the river village, the market sale is lost. In each case the lost evening has a value, even though no money is paid for it. Economists want a word for this loss, so that choices can be compared fairly.

@ Cost | Word in use. In daily life, the price paid for a good. In this book, price is what the consumer pays, and cost is what is given up or spent to make or obtain something.

@ Opportunity cost | The value of the best alternative given up when a choice is made.

> Opportunity cost is the value of the best alternative that is given up.

The word is **opportunity cost**, which means the value of the best alternative given up when a choice is made. Notice the words 'best alternative'. When the traveller has three roads to choose from, only the most valuable of the two roads left behind counts. The opportunity cost of an hour spent at a cinema is the best other use of that hour, such as paid work or study, and not all the possible uses added together.

> Opportunity cost often has no price tag, yet it is real.

Opportunity cost is not always measured in money. A student who spends Friday evening at a wedding gives up the evening's study. A shopkeeper who keeps the shop open on a holiday gives up a day of rest. Money can measure the cost when the alternative has a money value, but time, effort and enjoyment count equally.

:pause 2.p1 | You have a free Saturday morning. You can sleep late, study for three hours or earn Tk 300 helping at a shop. If you choose to study, what is the opportunity cost?

@ Trade-off | Giving up some of one thing in order to have more of another.

> A trade-off is giving up some of one thing to gain more of another.

A related word describes the act itself. A **trade-off** means giving up some of one thing in order to have more of another. A farmer who plants more jute plants less rice. A student who studies an extra hour gives up an hour of sleep. Opportunity cost measures the size of what is given up; the trade-off is the exchange itself.

> The owner, the employee and the consumer each see the cost differently.

Opportunity cost looks different from each viewpoint. For the owner of a shop, the cost of opening on a holiday is the rest and family time given up. For an employee, the cost of an extra shift is the evening at home. For a consumer, the cost of buying a book is the other goods the same money could have bought. In each case the question is the same: what is the best use that is left behind?

> When the alternative has no value, the opportunity cost is zero.

There is an exception. If the best alternative has no value, the opportunity cost is zero. A shop table that stands empty overnight and has no other use costs nothing to use for a night's storage. Such cases are rare, because most resources have some other use, and economists therefore look for the alternative before they call anything free.

> You should now be able to say what the opportunity cost of any choice is.

*You should now be able to say* that the opportunity cost of a choice is the best alternative left behind, and that a trade-off is the exchange of some of one thing for more of another.

### Measuring opportunity cost

> Opportunity cost can be turned into a number when outputs are known.

@! Go slowly here.

When the choice involves producing goods, opportunity cost can be measured exactly. In words: the opportunity cost of one unit of a good equals the quantity of the other good given up, divided by the quantity of the first good gained. In symbols, opportunity cost per unit = quantity given up ÷ quantity gained.

> Recall: economics defined, Chapter 1, section 1.1 'The Meaning and Scope of Economics'.

:case Case file, illustrative. Rafiq has 40 hours a week for two jobs. In one hour he can shelve 20 books or pack 10 online parcels. If he spends all 40 hours on shelving, he completes 800 books and 0 parcels. If he spends all 40 hours on packing, he completes 400 parcels and 0 books.

> The steps for Rafiq follow the usual order: Given, Find, Formula, Steps, Answer, Check.

*Given:* the record above. *Find:* the opportunity cost of one extra parcel, in books. *Formula:* opportunity cost per unit = quantity given up ÷ quantity gained. *Steps.* One hour of packing gains 10 parcels. The same hour, spent on shelving, would have produced 20 books. So 10 parcels cost 20 books, and one parcel costs 20 ÷ 10 = 2 books. *Answer:* each extra parcel gives up 2 books. *Check:* going from 800 books to 0 books gives up 800 books, and 800 ÷ 400 parcels is also 2 books for each parcel. The two methods agree.

> The opportunity cost of books is the reverse ratio.

The opposite choice has the reverse cost. One extra book gives up 10 ÷ 20 = 0.5 of a parcel. In general the opportunity cost of A in terms of B is the inverse of the opportunity cost of B in terms of A. A common slip is to forget this, and to give 2 books where 0.5 of a parcel is wanted. Always say which good is being measured, and in which unit.

> Opportunity cost can also be a choice between two uses of money.

:case Case file, illustrative. Nurul Meghna, who founded Meghna and Sons in 1996, has Tk 500,000 to spend on one of two uses: new titles for the shop, or an online site. The opportunity cost of choosing the new titles is the online site, and the opportunity cost of choosing the online site is the new titles.

> Before moving on: the best alternative given up, measured in the units of the other good.

*Before moving on.* Opportunity cost is the best alternative given up. When outputs are known, divide the quantity given up by the quantity gained. Rafiq's extra parcel costs 2 books. Nurul's choice of one use of Tk 500,000 costs the other.

* * *

## 2.3 The Production Possibility Curve

### Drawing the choices

> A picture can show every choice open to Rafiq at once.

Rafiq's choice is not limited to all shelving or all packing. He may share his 40 hours in any proportion. A picture can show every such choice together. Before drawing it, test one more case from his record. Suppose he gives 20 hours to shelving and 20 hours to packing. Shelving gives 20 × 20 = 400 books. Packing gives 20 × 10 = 200 parcels. That is a third combination: 400 books and 200 parcels.

> Recall: laws and the same-conditions rule, Chapter 1, section 1.4 'Economic Laws'.

@ Production possibility curve | A line showing the largest combinations of two goods that can be produced with all resources used fully.

> The production possibility curve joins the largest combinations of two goods.

Plot the combinations and join them. The result is a **production possibility curve**, which means a line showing the largest combinations of two goods that can be produced with all resources used fully. Like the demand schedule in Chapter 4, it holds other things the same: Rafiq's hours, his speed and his tools stay fixed while the choices change. Each point on the line is one way of dividing the 40 hours.

> The axes show books and parcels, and each point is one combination.

To read the figure, look at the axes. The horizontal axis shows the number of books shelved; the vertical axis shows the number of parcels packed. A point is one combination of the two. Point A is 800 books and 0 parcels. Point C is 0 books and 400 parcels. Point B is 400 books and 200 parcels. The line joining them is straight because Rafiq's speeds do not change as he moves his hours.

:fig Rafiq's production possibility curve with three points | ch02-fig01.svg

### Reading the curve

> Points on, inside and outside the curve have three different meanings.

The curve divides the picture into three regions. A point on the curve is attainable and uses all 40 hours. A point inside the curve is attainable but wastes something. For example, 400 books and 100 parcels needs only 20 + 10 = 30 hours, so 10 hours are left idle. A point outside the curve cannot be reached with present resources. For example, 600 books and 300 parcels needs 30 + 30 = 60 hours, which is more than 40.

> The slope of the line shows the opportunity cost.

The curve also shows opportunity cost. Moving along the line from A toward C, each extra parcel gives up 2 books, as we found earlier. The steepness of the line therefore carries the price of one good in terms of the other. A trade-off is visible as a move along the curve: more of one good, less of the other.

> Real curves usually bow outward, and the cost rises as you move along.

Rafiq's curve is a straight line because every hour of his time is equally good at each job. Most real curves bow outward, like a bowl turned on its side. The reason is that resources differ. A farm field suited to rice grows jute poorly, so moving it to jute costs more and more rice. This book returns to the idea when it studies costs of production. For now, remember that a straight line is a simplification chosen for easy arithmetic.

### Growth shifts the curve

> More resources or better methods move the whole curve outward.

The curve is drawn for fixed resources and fixed methods. If either improves, the curve moves. Suppose Rafiq's week grows from 40 to 50 hours. All shelving now gives 1,000 books and all packing gives 500 parcels, so the whole line moves outward. Faster work has the same effect. A combination that was out of reach becomes possible. Economists call this growth. It does not remove scarcity, because wants rise as well.

> A whole country can be pictured with the same curve.

The same picture serves a whole country. Imagine a small country that uses all of its farmland, workers and machines to produce food and medicines. A curve shows the largest combinations of the two. A country at a point on the curve can have more medicines only by giving up some food. A country at a point inside the curve, perhaps because many workers are idle, can gain more of both goods without giving up anything. This explains why economists care about unemployment: it moves a country inside its curve.

> Before moving on: the curve shows the attainable, and growth moves it.

*Before moving on.* The production possibility curve shows the largest combinations of two goods. Points on it use all resources; points inside waste some; points outside are out of reach. Its slope shows opportunity cost, and growth moves the whole curve outward.

* * *

## Worked Examples: Changing the Setting

> Four examples, each a little less tidy than the last.

The first example is Rafiq above, with clean numbers. The next three change the setting. Each uses the order Given, Find, Formula, Steps, Answer, Check.

> Rung 2: a farm with less tidy numbers gives a ratio that is not whole.

*Given:* a farmer has 3 acres. On one acre, she can grow 2,500 kg of rice or 1,500 kg of jute. *Find:* the opportunity cost of 1 kg of jute, in rice. *Formula:* quantity given up ÷ quantity gained. *Steps.* One acre of jute gives up 2,500 kg of rice and gains 1,500 kg of jute. So 1 kg of jute costs 2,500 ÷ 1,500 = 1.67 kg of rice. *Answer:* about 1.67 kg of rice. *Check:* the reverse cost of 1 kg of rice is 1,500 ÷ 2,500 = 0.6 kg of jute, and 1.67 × 0.6 is close to 1, as it should be.

> Rung 3: the units change from dozens to single items.

*Given:* in one hour, a bakery can make 6 dozen rolls or 3 dozen cakes. *Find:* the opportunity cost of one cake, in rolls. *Steps.* Convert to single items: 6 dozen = 72 rolls and 3 dozen = 36 cakes. One hour of cakes gives up 72 rolls and gains 36 cakes, so one cake costs 72 ÷ 36 = 2 rolls. *Answer:* 2 rolls. *Check:* working in dozens gives 6 ÷ 3 = 2 as well. The slip to avoid is to compare dozens of one good with single items of the other.

> Rung 4: a table combines costs, points inside and outside, and a rising ratio.

*Given:* a workshop can produce these combinations with all resources fully used.

:table Combinations of chairs and tables a workshop can make
| Chairs | Tables |
| 0 | 30 |
| 10 | 26 |
| 20 | 18 |
| 30 | 0 |

> The table is read row by row, and the cost is found between rows.

*Find:* the opportunity cost of an extra chair at each step, and whether 20 chairs with 20 tables is attainable. *Steps.* From 0 to 10 chairs, tables fall from 30 to 26, so 4 tables are given up for 10 chairs: 0.4 tables per chair. From 10 to 20 chairs, 8 tables are given up: 0.8 per chair. From 20 to 30 chairs, 18 tables are given up: 1.8 per chair. At 20 chairs the most tables possible is 18, so 20 tables is out of reach. *Answer:* the cost rises at each step, and the point is unattainable. *Check:* the sum of the three losses is 4 + 8 + 18 = 30, the full number of tables.

* * *

## Summary

> The chapter's main results in a few lines.

Wants are without limit; resources are limited. This meeting is scarcity, and it forces choice. Opportunity cost is the value of the best alternative given up, and a trade-off is the exchange of some of one thing for more of another. Opportunity cost is found by dividing the quantity given up by the quantity gained. The production possibility curve shows the largest combinations of two goods; its slope shows opportunity cost, and growth moves it outward.

## Think It Through

:q 2.t1 | You can study for one hour or work in a shop and earn Tk 120 an hour. Explain the cost of studying that hour, and say why the answer may differ for another student.
:q 2.t2 | Rafiq's week grows to 50 hours. State his new maximum books and parcels, and say whether 600 books and 300 parcels are now attainable.

## Where People Go Wrong

> Four common misunderstandings, each corrected.

Many students believe that opportunity cost is all the alternatives added together. It is only the best one. They also believe that opportunity cost is the money paid; yet a free evening used for study still has a cost. A third error is to think that scarcity means poverty or rarity, when it describes the meeting of limited resources and unlimited wants for everyone. The last error is to think that a point inside the curve is a good choice because it is attainable. It is attainable, but it wastes resources that could give more of both goods.

## In History

> In 1932 an English economist defined economics as the study of choice under scarcity.

Lionel Robbins (1898 to 1984) was an English economist who taught at the London School of Economics. In 1932 the publisher Macmillan of London issued his book *An Essay on the Nature and Significance of Economic Science*. Earlier writers had defined economics as the study of wealth or of business. Robbins argued instead that economics studies human behaviour as a relationship between ends and scarce means that have alternative uses.

> The definition made scarcity and choice the centre of the subject.

The new definition changed the question. It did not matter whether an activity concerned money; any choice among uses of limited means had an economic side. The book became one of the most cited works on the nature of the subject, and its idea shapes this chapter: wants are many, means are limited, and choice follows. Not every economist accepted the definition, and some argued that it left out matters such as the study of national output.

> A fifth error concerns money already spent.

A fifth error is to treat a sunk loss as a cost of the next decision. Money already spent and not recoverable cannot be given up again, so only the alternatives still open count when you choose.

## Review Questions

:q 2.1 | Define want, and explain why the list of wants as a whole has no end even though one want can be satisfied.
:q 2.2 | Explain scarcity in your own words, and give one example for a rich person and one for a poor person.
:q 2.3 | A student can spend Saturday studying, working for Tk 400 or resting. Studying is chosen. What is the opportunity cost?
:q 2.4 | In one hour a tailor can make 8 shirts or 4 pairs of trousers. Find the opportunity cost of one pair of trousers, in shirts, and of one shirt, in trousers.
:q 2.5 | Using Rafiq's record, find his combination of books and parcels if he spends 30 hours on shelving and 10 hours on packing. Is it on, inside or outside his curve?
:q 2.6 | A production table shows 0 cars with 50 buses, 5 cars with 40 buses, and 10 cars with 20 buses. Find the opportunity cost of a car in each step and say what happens to it.
:q 2.7 | Give one reason why a real production possibility curve bows outward, and one event that would shift it outward.

:read Lionel Robbins, An Essay on the Nature and Significance of Economic Science, 1932
