:chapter I | What Economics Is
:mood Why can no one have everything they want?
:desc This chapter introduces economics as the study of choice when wants are many and means are few. It separates the study of single shops from the study of a whole country. It teaches you to tell a statement of fact from a statement of opinion, and to see why every economic law carries a condition. It also sets the habits this book uses in every chapter.
:plate ch01-plate.svg | A market square in the 1880s, with stalls, shoppers and a clock tower

> This chapter needs no earlier knowledge.

*You will need:* nothing. The chapter starts from things you already do: spending, saving, buying and selling. Each subject word is explained at the moment it first appears, in plain English, with a small example.

> A market square shows many people facing one problem: choice.

Picture a market square on a Saturday morning in a town of the 1880s. Stalls sell rice, cloth, fruit, pens and notebooks. Hundreds of people walk between them, and each carries a short list of things to buy and a limited amount of money. One father wants shoes for his daughter and a new lamp for the house. He can pay for only one of the two today. Which does he choose, and how does he decide?

> The seller also faces limits, so both sides of the stall must choose.

Now consider the other side of the stalls. A cloth seller has one table, ten hours of daylight and a fixed amount of money to spend on stock. She can buy more cotton or more silk for tomorrow, but she cannot buy as much of both as she would like. Whatever she chooses, she gives up something else. She must also decide the price at which to sell. A price that is too high leaves her cloth unsold, and a price that is too low leaves her with too little money.

> The two choices look different but share one shape.

The father's choice is about a lamp, and the seller's choice is about silk. They look unrelated, yet they share one shape. Wants are many, the means to satisfy them are few, and so someone must choose. A harder question follows. When thousands of such choices are made each day, why does the square not fall into disorder? Why do shoes, lamps and cloth appear at the stalls in roughly the quantities that people wish to buy, at prices they can pay?

> This puzzle is the subject of the book; the chapter plan follows.

No single person in the square plans all of this, and that fact makes the puzzle worth studying. This book builds its answer step by step, and it begins with the plainest question of all: what does this subject study? Section 1.1 gives the meaning of the subject. Section 1.2 divides it into two branches. Section 1.3 separates statements of fact from statements of opinion. Section 1.4 explains the kind of law that economists can state, and the condition that every such law carries.

* * *

## The Meaning and Scope of Economics

@! Go slowly here.

> Begin with your own week: wants that cost more than your money.

Begin with something you know well. Imagine a student who receives Tk 100 for the week. She wants a notebook at Tk 60, a meal in a café at Tk 60, and a bus ticket at Tk 30. Together these wants cost Tk 150, which is more than Tk 100. She cannot have all three, so she must choose, and each choice means giving up something else. This small case holds the whole subject in one picture.

> Three plain words carry the idea: want, good and resource.

Three plain words are needed. A want is a wish to have something, such as a notebook. A good is anything that satisfies a want. Some books also say commodity or product; this book always says good, and uses service only for help given by a person, such as a lesson. A resource is anything used to make goods: land, people's work, tools and money. Keep these three words in mind, because the next definition uses all of them.

> Economics is the study of choice under limited resources.

@ Economics | The study of how people, firms and governments choose to use limited resources to satisfy wants.

The student's problem has a name in the subject. **Economics** means the study of how people, firms and governments choose to use limited resources to satisfy wants. A firm is any organisation that makes goods to sell, whether a small bookshop or a large factory; some books say business or enterprise, but this book always says firm. A government is the body that makes rules and raises money for a country. Our student is a person, the cloth seller is a firm, and a government that must choose between building a school and building a road faces the same problem on a larger scale.

:box IN SHORT
Economics is about choice. Wants are many, resources are limited, and so every person, firm and government must choose.

> Read the first figure as two bars with a gap between them.

Figure 1 shows the idea in a picture. Read it from left to right. The tall bar on the left stands for wants, and the shorter bar on the right stands for the means to satisfy them. The dashed line marks the top of the means. The distance between the dashed line and the top of the wants is the gap that cannot be filled, and the word *choice* sits between the bars because the gap forces it.

:fig Economics as choice among wants and limited means | ch01-fig01.svg

> Economics covers four connected activities.

The *scope* of a subject is the range of things it studies. Economists usually group the activities they study into four. Consumption is the use of goods to satisfy wants, as when a family eats bread. Production is the making of goods, as when a printer makes books. Exchange is the buying and selling by which goods pass from one person to another. Distribution is the sharing of the income from production among those who helped to make the goods, such as workers and owners. The four are linked: nothing is consumed until it is produced and exchanged, and the income shared in distribution pays for the next round of consumption.

> The running case shows all four activities in one small shop.

:case Case file, illustrative. Meghna and Sons is a family-run bookshop in Dhanmondi, Dhaka, founded on 4 April 1996 by Nurul Meghna. In 2025 its sales were Tk 14,400,000, its profit was Tk 750,000, and it had 7 staff. The shop buys books from printers, which is exchange. Readers take the books home to read them, which is consumption. The shop's income pays its staff and its owner, which is distribution. Printers who make the books are engaged in production.

> Economics is a science that explains and an art that advises.

Is economics a science? A science is organised knowledge, built by gathering facts and testing explanations against them. Economics does this: it collects facts about prices, output and choices, and it offers explanations of cause and effect. An art, in the older meaning of the word, is a practical skill used to reach an aim. When an adviser tells a government how to lower the price of food, the adviser uses economics as an art. Most writers call economics a social science, because it studies people, who differ from one another, change their minds and cannot be placed in a laboratory. One exception to the comparison with physics follows from this: economic results are less exact.

> Recap of the section in a few lines.

*Before moving on.* Economics is the study of choice. It exists because wants are many and resources are limited. It covers consumption, production, exchange and distribution, and it is both a science, which explains, and an art, which advises. You should now be able to say, in one sentence, why a student with Tk 100 and wants worth Tk 150 faces an economic problem.

## Micro and Macro

@! Go slowly here.

> A street map and a country map show different views of one land.

Start with maps. A street map of Dhanmondi shows each lane, shop and house, and it helps you find one bookshop. A map of the whole country does not show the lanes, but it shows the roads that join the cities, and it helps you plan a long journey. Neither map is wrong, and neither replaces the other. They are two ways of looking at the same land. Economics uses the same two views, and each has its own name.

> Microeconomics is the close view of single consumers and firms.

@ Microeconomics | The branch of economics that studies choices made by individual consumers and firms.
@ Market | Word in use. In daily life, a place with stalls where people buy and sell. In economics, any arrangement in which buyers and sellers deal with each other, in one place or by telephone or screen.

The close view is called **microeconomics**. Microeconomics means the study of the choices made by individual consumers and individual firms. A consumer is a person who buys a good to use it, not to sell it again. The word begins with the Greek word for small.^1 In microeconomics we ask how one consumer decides what to buy, how one firm decides how much to make and at what price, and how the choices of many consumers and firms meet in a market.

^1: *Mikros* is Greek for small and *makros* is Greek for large. Many scientific words are built from Greek parts in this way.

> A microeconomist asks questions about one firm, such as this shop.

:case Case file, illustrative. Meghna and Sons is a micro unit. In 2025 its sales were Tk 14,400,000, its profit was Tk 750,000, and it had 7 staff. A microeconomist who studies this shop asks how its owner chose the price of its books, how many staff to employ, and how many copies to keep in stock. Each of these questions concerns one firm.

> Macroeconomics is the wide view of the whole economy.

@ Macroeconomics | The branch of economics that studies the whole economy, including output, prices and employment.
@ Economy | Word in use. In daily life, a saving, as in an economy of effort. In economics, the whole system by which the people of a country make, share and use goods.

The wide view is called **macroeconomics**. Macroeconomics means the study of the whole economy, including output, prices and employment. Output is the total amount of goods made in a country in a period of time. The price level is the general level of prices across the country. Employment is the number of people who have paid work. A macroeconomist does not ask about one shop. The questions are of this kind: why did the price level of the whole country rise, or why did total employment fall?

> The same shop is a very small part of the national picture.

:case Case file, illustrative. Seen through the macro view, the same shop almost disappears. The macro view follows the price level and the total employment of the whole country, and it does not follow the shop's own books. The shop's 7 staff are counted inside the national total of jobs, together with the staff of every other firm.

> Read the second figure from left to right: one shop, then the whole country.

Figure 2 places the two views side by side. On the left, the picture is close: one shop, with its sales, profit and staff. On the right, the picture is wide: many shops and houses make up a country, and our shop is only one of them, marked by hatching. Under each picture, the label names what that view measures. Read the figure as a change of distance, not a change of subject.

:fig Micro and macro viewpoints on one shop | ch01-fig02.svg

> A table sets the two branches side by side, row by row.

The table below compares the two branches. Read it across. Each row names one feature, then gives the micro answer in the middle column and the macro answer in the right column.

:table Micro and macro compared
| Feature | Microeconomics | Macroeconomics |
| Unit studied | One consumer, one firm or one market | The whole economy |
| Typical question | How does one firm choose its price? | Why did the price level of the country change? |
| Case file example | Sales of Tk 14,400,000 and 7 staff at one shop | The price level and total employment of the country |
| Main concern | Single prices and quantities | Totals and averages |

> The branches differ in size but are linked in both directions.

The branches differ in the size of the unit, yet they are linked. Total employment in the country is the sum of the jobs in every firm, so macro totals come from micro choices. The link runs the other way as well. When the price level of the country rises, a shop pays more for its supplies, and that changes the shop's choices. One exception needs care. Size alone does not decide the branch: a very large firm is still one firm, so a question about it belongs to microeconomics.

> This book teaches microeconomics, so its scope is the choices of single units.

What is the scope of microeconomics? It covers how a consumer chooses among goods, how a firm chooses what to make and how to make it, how prices form where buyers and sellers meet, and how the people who supply work, land and money are paid. This book teaches microeconomics. Macroeconomics appears here only so that you can see where the boundary lies.

> Recap of the section in a few lines.

*Before moving on.* Microeconomics studies single consumers and firms. Macroeconomics studies the whole economy. The branches differ in the unit they study, and each depends on the other. You should now be able to say how a question about one shop differs from a question about the price level of a whole country.

## Positive and Normative Statements

> Two friends argue about textbooks, and only one dispute can be settled by checking.

Two friends sit in the shop and discuss books. The first says, "The shop sold 41,000 copies in 2025." The second says, "Textbooks should be cheaper." Both sound like ordinary remarks, but they are different in kind. Could a person settle either one by looking at records? Think about this before you read on.

> Positive economics deals with statements that facts can test.

@ Positive economics | Statements about what is, which can be tested against facts.

The first remark is an example of **positive economics**. Positive economics means statements about what is, which can be tested against facts. To test the remark, a person counts the copies recorded in the shop's sales books. The records will show the statement to be true or false. A positive statement may be false, because positive means testable, not correct. If the records show 39,000 copies, the statement fails the test but is still positive.

> The shop's own record gives a clean example of a positive statement.

:case Case file, illustrative. Statement: "The shop sold 41,000 copies in 2025." This is positive. The shop's sales books can confirm it or reject it, and no opinion is needed to decide.

> Normative economics deals with what ought to be, which depends on values.

@ Normative economics | Statements about what ought to be, which depend on values and cannot be tested by facts alone.

The second remark is an example of **normative economics**. Normative economics means statements about what ought to be, which depend on values and cannot be tested by facts alone. A value is a belief about what is good or fair. The remark "Textbooks should be cheaper" gives no fact to check. A student who wants low prices and a bookseller who wants a fair return can agree on every fact and still disagree on this point. Words such as should, ought, fair and better often signal a normative statement.

> One question separates the two kinds of statement.

To tell them apart, ask one question: could records or measurement show this statement to be true or false? If the answer is yes, the statement is positive. If the answer depends on what we think is right, the statement is normative. Many statements mix the two. "Textbook prices are too high because paper costs more" has a positive part, the claim about cost, and a normative part, the words too high. Separate the parts and test each one on its own.

> A table sets the two kinds of statement side by side.

The table below compares the two kinds of statement. Read each row across, from the feature on the left to the answers for positive and normative statements.

:table Positive and normative statements compared
| Feature | Positive | Normative |
| Speaks about | What is | What ought to be |
| Can facts test it? | Yes | Not by facts alone |
| Case file example | The shop sold 41,000 copies in 2025 | Textbooks should be cheaper |
| Signal words | Is, was, rose, fell | Should, ought, fair, better |

:pause 1.p1 | Classify each statement as positive or normative, and give a reason: (a) The shop employs 7 staff. (b) The shop should employ an eighth person.

> Recap of the section in a few lines.

*Before moving on.* A positive statement says what is and can be tested against facts. A normative statement says what ought to be and depends on values. Positive does not mean true. You should now be able to say which kind of statement a given sentence is, and what test shows it.

## Economic Laws

@! Go slowly here.

> A law of nature is exact, so what can an economic law claim?

Water boils at 100 degrees Celsius at sea level, and a stone released from the hand falls to the ground. These statements hold in every place, without exception. Now consider this one: when the price of a good rises, consumers usually buy less of it. Is that equally certain? Many students find this step confusing, because both statements are called laws. The difference is the subject of this section.

> An economic law states a usual pattern of behaviour under a condition.

@ Economic law | A statement of how people usually behave, true when other conditions stay the same.

An **economic law** means a statement of how people usually behave, true when other conditions stay the same. Take the statement about price. When the price of a notebook rises, most consumers buy fewer notebooks. The word usually is part of the law. Some consumers may still buy the same number, but the usual pattern is clear enough to guide a seller or a government.

> Ceteris paribus names the condition that every economic law carries.

@ Ceteris paribus | A Latin phrase meaning all other things stay the same, used to study one change at a time.

The condition has a name. **Ceteris paribus** is a Latin phrase meaning all other things stay the same.^2 Economists use it to study one change at a time. To test how the price of notebooks affects purchases, we imagine that incomes, tastes and the prices of other goods stay fixed. Otherwise we could not tell which change caused the result. The phrase is a method of thinking. It does not claim that other things never change; in real life they change all the time.

^2: Latin was the language of ancient Rome. Scholars in Europe used it for many centuries, so many technical phrases still come from it.

:box IN SHORT
An economic law is a usual pattern, and it holds ceteris paribus: all other things staying the same.

> Economic laws are less exact than natural laws because people choose.

How do economic laws differ from natural laws? A law of nature, such as the fall of a stone, describes things that do not choose, so it can be exact and the same everywhere. An economic law describes people, who have different tastes and change their minds. For this reason, an economic law states a tendency, not a certainty. People also cannot be placed in a laboratory and held still, so economists must use the words ceteris paribus to separate one cause from many.

> Every economy faces three basic problems.

Because resources are limited, every economy faces the same three basic problems. It must decide what to produce, which means which goods, and how many of each. It must decide how to produce, which means with which resources and methods. It must decide for whom to produce, which means how the goods will be shared among people. The market square in our opening puzzle answers these questions every day without any one person planning the answers.

> Recap of the section in a few lines.

*Before moving on.* An economic law states how people usually behave, and it holds ceteris paribus. It is a tendency, not a certainty, because people choose. Every economy must decide what, how and for whom to produce. You should now be able to say why the words ceteris paribus must accompany an economic law.

## Worked Case: Sorting Questions About One Shop

> This case applies the chapter's two sorting tests to five items from the shop.

The worked case below applies the two sorting tests of this chapter. The first test asks whether a statement is positive or normative. The second asks whether a question belongs to microeconomics or macroeconomics. It is an exercise in reasoning, and the steps are shown in full.

> The situation lists five items drawn from the shop's case file.

:case Case file, illustrative. Situation: five items are taken from the file of Meghna and Sons. (a) "The shop sold 41,000 copies in 2025." (b) "Textbooks should be cheaper." (c) "What decides the total number of jobs in the whole country?" (d) "How did the shop's owner choose the number of staff?" (e) "The shop's profit in 2025 was Tk 750,000."

> The question asks for two sorting decisions per item.

Question: for each statement, decide whether it is positive or normative. For each item, decide whether its subject is micro or macro. A question that asks for information is not a statement, so for items (c) and (d) only the second decision applies.

> Items (a) and (e) can be checked against records, so they are positive.

Reasoning, part one. Item (a) can be checked against the shop's sales books, so it is positive. Its subject is one shop, so it is micro. Item (e) is also a statement of fact: the shop's accounts show its profit, and the figure is Tk 750,000. It is positive, and it is micro, because it describes one firm.

> Item (b) states a value, and item (c) asks about a total.

Reasoning, part two. Item (b) says what ought to be, and no record can settle it, so it is normative. It concerns the price of one kind of good, so it is a micro matter. Item (c) asks about the total number of jobs in the whole country, so its subject is macro. It is a question, and so it is neither positive nor normative.

> Item (d) is about one firm, so it is a micro question.

Reasoning, part three. Item (d) asks how one owner chose the number of staff. The unit is one firm, so the question is micro. The answer would be a matter of fact, such as the shop's sales and wages, though the item itself is a question.

> The conclusions are collected in a table.

Conclusion: the table below gives the result. Read each row across, from the item to its two sorting decisions.

:table Sorting the five items
| Item | Positive or normative | Micro or macro |
| (a) 41,000 copies sold | Positive | Micro |
| (b) Textbooks should be cheaper | Normative | Micro |
| (c) Total jobs in the country | Not a statement | Macro |
| (d) The owner's choice of staff | Not a statement | Micro |
| (e) Profit of Tk 750,000 | Positive | Micro |

> A check confirms each decision with the test from the chapter.

Check: for each statement, ask whether records could show it to be true or false. Items (a) and (e) pass, and item (b) fails. For each subject, ask whether the unit is one firm or a total. Items (a), (b), (d) and (e) concern single units, and item (c) concerns a total. The decisions agree.

* * *

## Summary

> The chapter's main ideas, in a few lines.

Economics is the study of how people, firms and governments choose to use limited resources to satisfy wants. It has two branches: microeconomics studies single consumers and firms, and macroeconomics studies the whole economy. Positive statements say what is and can be tested against facts, and normative statements say what ought to be and depend on values. An economic law states how people usually behave, ceteris paribus. Every economy must decide what, how and for whom to produce.

## Think It Through

:q 1.t1 | In a town, the price of notebooks rose in March, and notebook sales fell. In the same month, the school gave a free notebook to every student. A newspaper says the price rise alone caused the fall. Using the words ceteris paribus, explain why this claim is weak.
:q 1.t2 | A friend says, "Economic laws are useless, because they are not exact." Using Section 1.4, write a reply of three sentences.

## Where People Go Wrong

> Many people think economics is the study of money, but it studies choice.

Many people believe that economics is the study of money. Money appears in many economic questions, but it is a tool, not the subject. The subject is choice under limited resources, and choices are made even where no money changes hands, as when a student chooses how to spend a free afternoon.

> Micro does not mean small things, and macro does not mean large things.

Some students think that micro means small things and macro means large things. This is a common confusion. The words refer to the unit studied. A large firm with thousands of staff is still one firm, so questions about it are micro. A question about the total number of jobs in the country is macro, however the jobs are spread.

> A positive statement is not always true, and a normative statement is not worthless.

Another confusion is that positive statements are true and normative statements are worthless. Positive statements can be false, as the case of 39,000 copies showed. Normative statements are not worthless: choices about what ought to be are the reason many people study economics. Facts alone cannot settle them by facts alone.

> Ceteris paribus is a thinking device, not a claim about the world.

The last confusion concerns ceteris paribus. Some students read it as a claim that nothing else ever changes. In fact, the phrase tells us to imagine other things unchanged, so that one cause can be studied on its own. Without it, an economist cannot tell whether a fall in sales came from a higher price or from some other change.

## In History

> Alfred Marshall's 1890 book gave economics a definition that centres on people.

Alfred Marshall (1842 to 1924) was an English economist who taught at the University of Cambridge. He began to write his book *Principles of Economics* in 1881 and published it in 1890. For many years it was the leading economics textbook in England. In it, Marshall described economics as the study of people in "the ordinary business of life".

> The definition moves the subject from money towards everyday human conduct.

The phrase matters for two reasons. First, it makes people, not money, the centre of the subject. Second, it treats economics as part of ordinary life. Buying a notebook, hiring an assistant and choosing a price are all examples of that business. The choices of Meghna and Sons are of exactly this kind, as are the choices of the father and the cloth seller in our opening puzzle.

> The definition still serves as a starting point, with later additions.

Marshall's wording is still quoted in textbooks today. This chapter's definition adds one idea that his phrase does not state directly: the focus on limited resources, which explains why choice is needed at all.

## Review Questions

:q 1.1 | Classify each statement as positive or normative, and give a reason: (a) Meghna and Sons had 7 staff in 2025. (b) Bookshops ought to pay their staff more. (c) The shop's profit in 2025 was Tk 750,000. (d) Fewer people should buy books online.
:q 1.2 | Separate each question into micro or macro: (a) How should one bookshop choose its staff? (b) Why did prices across the country rise? (c) How does a consumer choose between two goods? (d) What decides total employment in the country?
:q 1.3 | In your own words, explain why a student with Tk 100 and wants worth Tk 150 faces an economic problem.
:q 1.4 | Name the four activities in the scope of economics and give one example of each from a bookshop.
:q 1.5 | What does ceteris paribus mean, and what is one difference between an economic law and a law of nature?

:read Alfred Marshall, Principles of Economics, 1890
