:chapter X | Production Function and Returns
:mood Why does the sixth worker add less than the second?
:desc This chapter shows how inputs become output, why each extra worker added to a fixed workshop eventually adds less than the one before, and what happens to output when every input grows together.
:plate ch10-plate.svg | A workshop where workers are added one by one at a single bench

:box YOU WILL NEED
Chapter 2, 'Scarcity, Choice and Opportunity Cost', section 2.2 'Opportunity Cost', for the idea of giving up one use to gain another; Chapter 8, 'Supply and the Supply Curve', section 8.1 'Quantity Supplied and the Law of Supply', for supply; and Appendix A1, 'Maths You Will Use', for ratios, averages and simple graphs.

> A workshop owner adds workers one by one and watches the output.

A bookbinder owns a small workshop in an old street. It has a single long bench and one sewing machine. On Monday the owner hires one worker, who folds the pages, sews them and fits the covers alone, and the day's output is modest. On Tuesday a second worker arrives. One folds while the other sews, and the output is more than double. Encouraged, the owner hires a third worker, then a fourth. The output keeps rising, but each new worker adds a little less than the last.

> By the sixth worker the bench is crowded and the output no longer grows.

By the sixth day the bench is crowded. Workers wait for the machine, carry the same pile of paper from hand to hand and step round one another. The sixth worker is as willing as the first, and works as hard, yet the day's output does not rise at all. The owner has paid for one more worker and received nothing for it. Nothing about the workers has changed. Something about the bench has.

> The puzzle is why extra workers first add more and then add less.

This is the puzzle of the chapter. Why did the second worker add more than the first, and why did the sixth add nothing? If extra workers always added as much as the first, one workshop could feed the whole city, and we would never need a second bench. Section 10.1 names the parts of the problem and defines the measures. Section 10.2 explains the pattern, which is among the most important in economics. Section 10.3 asks what happens when the owner builds a bigger workshop and raises every input at once.

* * *

## 10.1 Inputs and Output

### The rule that links them

@! Go slowly here.

> A baker's kitchen shows how inputs become output.

Begin in a kitchen. A baker uses flour, water, an oven, fuel and time to make loaves. The things used are the inputs, and the loaves are the output. Inputs are the workers, machines, materials and land that a firm uses in production; output is the quantity of goods that results. A baker with more flour and a second oven can make more loaves, but not without limit, and not in any proportion.

> Recall: opportunity cost, Chapter 2, section 2.2 'Opportunity Cost'.

Every input has another use, so using it has an opportunity cost, as Chapter 2 explained. A firm therefore wants the largest output from the inputs it has chosen. Engineers and owners can describe the relationship between inputs and output in a table, a graph or a rule. Economists give the rule a name.

@ Production function | A rule showing the largest output that can be made from each combination of inputs.

> A production function links each combination of inputs to its largest output.

A **production function** means a rule showing the largest output that can be made from each combination of inputs. Suppose a baker with 1 oven and 2 helpers can make at most 100 loaves a day. Then 100 is the output in the production function for that combination. The words 'largest output' matter. A careless baker might produce less from the same inputs, but the production function records only what the best method can achieve.

@ Product | Word in use. In daily life, a good that is offered for sale. In this chapter, the quantity of output, as in total product.

> Different combinations of inputs give different outputs.

Change the combination, and the output changes. Two helpers and two ovens might give 180 loaves. One helper and one oven might give 60. The production function lists all such pairs. It does not say which combination to choose, because that depends on prices and costs, which later chapters study. It states only what is technically possible, and it assumes the best known methods.

> Before moving on: a production function ties inputs to the largest output.

*Before moving on.* Inputs are what a firm uses, and output is what it makes. A production function is the rule that shows the largest output for each combination of inputs. It describes what is possible, not what is wise.

### The short run and the long run

> Some inputs can be changed quickly, and others cannot.

Not every input can be changed at once. A baker can hire another helper by next week, but a new oven must be ordered, delivered and installed, which may take months. A firm cannot adjust all its inputs at the same speed, and the speed decides what choices it has.

@ Short run | A period so short that at least one input, such as a machine, cannot be changed.

> The short run is a period in which at least one input is fixed.

The **short run** means a period so short that at least one input, such as a machine, cannot be changed. In the short run the baker may hire more helpers and buy more flour, but the oven stays. An input that cannot be changed in the period is called a fixed input, and an input that can be changed is a variable input. The short run is not a number of days or months. It is whatever period leaves at least one input fixed.

@ Long run | A period long enough for all inputs to be changed.

> The long run is a period in which every input can be changed.

The **long run** means a period long enough for all inputs to be changed. Given enough time, the baker can build a new bakery, buy five ovens and move to another street. In the long run nothing is fixed. Different firms have different long runs: a roadside tea stall can change every input in a week, while a steel plant may need years. The two periods divide this chapter, because the law in section 10.2 belongs to the short run, and the idea in section 10.3 belongs to the long run.

> Before moving on: the short run has a fixed input and the long run has none.

*Before moving on.* In the short run at least one input is fixed. In the long run all inputs can be changed. The length of each depends on the firm and the industry.

### Total, marginal and average product

@! Go slowly here.

> Three measures describe how output responds to one input.

We now need three measures of output. They are needed to follow how output changes when the firm varies one input, such as workers, while all other inputs stay fixed. Take the smallest possible example, a baker with one oven. With 1 helper the baker makes 6 loaves a day, and with 2 helpers 14 loaves a day.

@ Total product | The whole quantity of output produced with a given amount of inputs.

> Total product is the whole output from the given inputs.

The first measure is the simplest. **Total product** means the whole quantity of output produced with a given amount of inputs. With 1 helper, total product is 6 loaves. With 2 helpers, it is 14 loaves. It is the number that the firm sells.

@ Marginal product | The extra output from adding one more unit of an input, others held fixed.

> Marginal product is the extra output from one more unit of the input.

The second measure asks what the last helper added. **Marginal product** means the extra output from adding one more unit of an input, others held fixed. In words: marginal product equals the change in total product divided by the change in the input. In symbols, MP = ΔTP ÷ ΔL, where MP stands for marginal product, TP for total product, L for the number of workers, and Δ for 'change in'. When the baker adds the second helper, total product rises from 6 to 14, so MP = (14 - 6) ÷ (2 - 1) = 8 loaves.

@ Average product | Total product divided by the number of units of the input used.

> Average product is the output per unit of the input.

The third measure asks what each helper produces on average. **Average product** means total product divided by the number of units of the input used. In symbols, AP = TP ÷ L. With 2 helpers, AP = 14 ÷ 2 = 7 loaves per helper. Many students find these three measures confusing, because they use the same units and sound alike. Remember the questions: total product asks how much altogether, marginal product asks how much the last unit added, and average product asks how much each unit produced on average.

> The measures can be read from a table of workers and output.

:pause 10.p1 | A baker with one oven makes 5 loaves with 1 helper, 12 with 2 helpers and 18 with 3 helpers. Find the marginal product of the third helper and the average product with 3 helpers.

> You should now be able to say what each of the three measures asks.

*You should now be able to say* what total, marginal and average product ask: how much altogether, how much the last unit added, and how much per unit on average.

* * *

## 10.2 The Law of Diminishing Returns

### The pattern in the workshop

> The binding workshop gives the pattern in numbers.

Return to the bookbinder. The workshop has one machine, and the owner varies only the number of workers. The record shows what happened.

> Recall: supply, Chapter 8, section 8.1 'Quantity Supplied and the Law of Supply'.

:case Case file, illustrative. A binding workshop has one machine. With 1 to 6 workers, daily output is 10, 24, 36, 44, 48 and 48. The marginal product is 10, 14, 12, 8, 4 and 0. The average product is 10, 12, 12, 11, 9.6 and 8.

> The schedule is a table that lists the three measures worker by worker.

To read the table below, go along each row. The first column gives the number of workers, the second gives total product, the third gives the marginal product of the last worker, and the fourth gives average product. Each marginal product is the difference between a total product and the one above it. Each average product is a total product divided by the number of workers on its row.

:table The binding workshop's product schedule
| Workers | Total product | Marginal product | Average product |
| 1 | 10 | 10 | 10 |
| 2 | 24 | 14 | 12 |
| 3 | 36 | 12 | 12 |
| 4 | 44 | 8 | 11 |
| 5 | 48 | 4 | 9.6 |
| 6 | 48 | 0 | 8 |

> Total product rises throughout, but by smaller and smaller steps after the second worker.

Follow the marginal column. The first worker adds 10 and the second adds 14, because two people can share the tasks and keep the machine busy. The third adds 12, the fourth 8, the fifth 4 and the sixth 0. From the third worker onward every extra worker adds less than the one before, while total product still rises until the fifth worker. The sixth leaves total product at 48.

:pause 10.p2 | In the schedule, what does the figure 8 in the marginal column mean, and what is the average product when 4 workers are used?

> The workshop's pattern is an example of a general law.

@ Law of diminishing returns | Adding more of one input to fixed amounts of others will, after a point, add less and less to output.

> The law of diminishing returns says extra units of one input eventually add less.

The pattern is general enough to be called a law. The **law of diminishing returns** means that adding more of one input to fixed amounts of others will, after a point, add less and less to output. The binding workshop shows it: with the machine fixed, each worker beyond the second adds less than the one before. The law does not say that output falls. It says that the extra output shrinks.

:box IN SHORT
Hold some inputs fixed, keep adding one input, and the extra output from each new unit will eventually become smaller and smaller.

:pause 10.p3 | State the law of diminishing returns in your own words and name the fixed input in the binding workshop.

### Why returns diminish, and when the law holds

> The cause is a fixed input shared among more and more workers.

Why does the pattern appear? In the binding workshop the machine is fixed. The first worker must do every task alone, moving between folding, sewing and covering, and so wastes time. The second worker allows each person to specialise, and the machine is kept busy. This is why marginal product rises at first. Soon the machine is in use all day. Each new worker now has less machine time to share, must wait for a turn, or takes over a task someone else was doing well. By the sixth worker the machine can produce no more, and no addition of labour can change that.

> The law holds only under stated conditions.

The law holds under conditions that you should state each time. First, at least one input is fixed, so the law is a short-run law. Second, the methods of production stay the same; a better machine would move the whole schedule up. Third, the units of the variable input are alike. The workers in the workshop are equally skilled, so the fall in marginal product is not caused by hiring worse workers. It is caused by the crowding of a fixed input. If a student explains the fall by saying 'the later workers are lazier', the explanation is wrong, and the law is lost.

> The law is about the extra output, not about the whole output.

A common error concerns what diminishes. Total product does not have to fall, and in our case it rises until the fifth worker. What diminishes is the marginal product, the addition to output. An example from farming helps. Put one more labourer on a single field, and the harvest rises. Put a hundred more, and it hardly rises, because the soil, not the labour, limits the harvest. The extra output shrinks long before any harm is done.

> The first figure shows total product rising, quickly at first, then slowly, then not at all.

To read the first figure, look at the axes. The horizontal axis shows the number of workers; the vertical axis shows total product. Each point shows the output for one number of workers. The curve rises steeply for the first two workers, flattens through the fourth and fifth, and levels out at the sixth, where it no longer rises.

:fig Total product curve for the binding workshop | ch10-fig01.svg

> The second figure shows the marginal and average curves, which meet at the highest average.

The second figure draws the other two measures. The solid line is marginal product and the dashed line is average product. Marginal product climbs to 14 at the second worker, then falls to 0. Average product climbs to 12, stays there for the third worker and then falls. The curves meet at the third worker, where both equal 12, and this is where average product is at its highest.

:fig Marginal and average product curves for the binding workshop | ch10-fig02.svg

> The marginal product pulls the average up or down.

The link between the two curves is a rule that deserves attention. When marginal product is above average product, the average rises; when it is below, the average falls; when the two are equal, the average neither rises nor falls. Check it against the table. The second worker adds 14, above the average of 10, so the average climbs to 12. The third adds 12, equal to the average, so the average stays at 12. The fourth adds 8, below 12, so the average falls to 11. The same rule governs the average mark of a class: a new student above the average raises it, and one below lowers it.

### Three stages of production

> The schedule divides into three stages.

The schedule can be divided into three stages. The first stage runs from the first worker to the point where average product is highest, here the third worker. Average product is rising, so each worker added makes the others more productive. The second stage runs from that point to the point where marginal product reaches zero, here the sixth worker. Marginal product is positive but falling, and average product is falling. The third stage begins when marginal product turns negative, which means total product falls. The binding workshop has not reached it.

> A firm usually works in the second stage.

A careful firm avoids the third stage, since no firm wants to pay for a worker whose presence lowers output. It also has little reason to stop in the first stage, since extra workers raise the average output of all. This reasoning points a firm toward the second stage. Where in the second stage the owner stops depends on costs and prices, which Chapter 11 and later chapters study.

> Before moving on: the law, the schedule and the stages describe one pattern.

*Before moving on.* The law of diminishing returns says that with some inputs fixed, extra units of one input eventually add less and less. Marginal product rises at first, then falls; average product rises while marginal product is above it. The three stages divide the schedule at the peak of average product and at the point where marginal product reaches zero.

* * *

## 10.3 Returns to Scale

### Changing every input

@! Go slowly here.

> The long run raises every input together, which is a different question.

The law of diminishing returns changed one input and held the others fixed. The owner can ask a different question: if the workshop is rebuilt with twice as many workers and twice as many machines, will output double? The answer matters for the long run, when all inputs can change.

@ Scale | Word in use. In daily life, an instrument for weighing, or the ratio on a map. In economics, the size of a firm's operation, meaning the amount of all its inputs taken together.

@ Returns to scale | The change in output when all inputs are increased in the same proportion.

> Returns to scale is the change in output when all inputs grow in the same proportion.

**Returns to scale** means the change in output when all inputs are increased in the same proportion. Double the workers and double the machines, and see what happens to output. There are three possible answers, and each has a name. The test is to compare the proportional rise in output with the proportional rise in inputs.

> The three cases are compared by the size of the rise in output.

Output may rise by more than the inputs. This is increasing returns to scale. It may rise by exactly as much, which is constant returns to scale. Or it may rise by less, which is decreasing returns to scale. In symbols, if inputs are multiplied by k, output is multiplied by more than k, by exactly k, or by less than k. Here k stands for any number above 1, such as 2 or 1.5.

> The record gives four outputs for four sizes of workshop.

:case Case file, illustrative. In the binding workshop, 2 workers and 1 machine give an output of 24. With 4 workers and 2 machines the output is 60. With 6 workers and 3 machines it is 90. With 8 workers and 4 machines it is 108.

> The record can be classified step by step.

*Given:* the four outputs above. *Find:* the kind of returns to scale at each step. *Steps.* From 2 workers and 1 machine to 4 and 2, inputs are multiplied by 4 ÷ 2 = 2, and output by 60 ÷ 24 = 2.5. Output grows faster than inputs: increasing returns. From 4 and 2 to 6 and 3, inputs are multiplied by 1.5, and output by 90 ÷ 60 = 1.5. They match: constant returns. From 6 and 3 to 8 and 4, inputs are multiplied by 8 ÷ 6 = 1.33, and output by 108 ÷ 90 = 1.2. Output grows more slowly: decreasing returns. *Answer:* increasing, then constant, then decreasing. *Check:* the pattern of 2.5, 1.5 and 1.2 agrees with the pattern of inputs.

### Causes

> Specialisation and bulk buying favour growth; coordination difficulties limit it.

Why increasing returns at first? A larger workshop allows each worker to specialise, can use larger machines that a small workshop cannot afford, and can buy materials in bulk at lower prices. Why decreasing returns later? A very large firm is hard to manage. Orders pass through more people, mistakes spread, and effort is spent on coordination rather than production. Constant returns lie between: the firm repeats what it already does. Many firms pass through all three as they grow.

> The law of diminishing returns and returns to scale are different ideas.

Do not mix up the two ideas. The table below compares them. Read each row across: the first column names the feature, and the next two give the answer for each idea.

:table Diminishing returns compared with returns to scale
| Feature | Law of diminishing returns | Returns to scale |
| Inputs changed | One input; others fixed | All inputs together |
| Period | Short run | Long run |
| Question | How does the extra output change? | How does output change with the size of the firm? |
| Result | Extra output shrinks | Output may rise by more, the same or less |

> Before moving on: the long run asks about all inputs, the short run about one.

*Before moving on.* Returns to scale compares the proportional rise in output with the proportional rise in all inputs. Increasing means output rises faster, constant means equally, and decreasing means more slowly. The law of diminishing returns belongs to the short run, and returns to scale to the long run.

* * *

## Worked Examples: Four Rungs

> Four examples, from clean numbers to a combined problem.

Each example below follows the order Given, Find, Formula, Steps, Answer, Check.

> Rung 1: a table with small clean numbers.

*Given:* a baker with one oven makes 5, 12, 18 and 20 loaves with 1, 2, 3 and 4 helpers. *Find:* the marginal and average product at each number of helpers. *Formula:* MP = ΔTP ÷ ΔL and AP = TP ÷ L. *Steps.* MP: 5; 12 - 5 = 7; 18 - 12 = 6; 20 - 18 = 2. AP: 5 ÷ 1 = 5; 12 ÷ 2 = 6; 18 ÷ 3 = 6; 20 ÷ 4 = 5. *Answer:* MP is 5, 7, 6, 2 and AP is 5, 6, 6, 5. *Check:* the marginal product is above the average product while the average rises, and equals it at the peak of 6 with 3 helpers.

> Rung 2: realistic data in kilograms are less tidy.

*Given:* on one acre, 1 to 5 labourers harvest 420, 900, 1,300, 1,560 and 1,690 kg of rice. *Find:* the marginal and average product. *Steps.* MP: 420; 480; 400; 260; 130. AP: 420; 450; 433.33; 390; 338. *Answer:* marginal product peaks with the second labourer and falls after, while average product peaks at the second as well. *Check:* the third labourer's marginal product (400) is below the average (450), so the average falls, to 433.33, as it should.

> Rung 3: the unit and the sign change.

*Given:* a workshop records output in dozens: 4 dozen with 5 workers, 4 dozen with 6 workers, and 3.75 dozen with 7 workers. *Find:* the marginal product of the sixth and seventh workers, in single items. *Steps.* Sixth: 4 - 4 = 0 dozen. Seventh: 3.75 - 4 = -0.25 dozen, and -0.25 × 12 = -3 items. *Answer:* the sixth adds nothing and the seventh takes away 3 items. *Check:* a negative marginal product means total product is falling: the third stage.

> Rung 4: a combined problem uses the law and returns to scale together.

*Given:* a bakery with 1 oven and 2 helpers makes 30 loaves a day. With 2 ovens and 4 helpers it makes 66. With 2 ovens and 5 helpers it makes 76. *Find:* the returns to scale from the first to the second combination, and the marginal product of the fifth helper. *Steps.* Inputs are multiplied by 2. Output is multiplied by 66 ÷ 30 = 2.2. The fifth helper's marginal product, with the ovens fixed at 2, is 76 - 66 = 10. *Answer:* increasing returns to scale, and a marginal product of 10 loaves. *Check:* the first answer changed all inputs; the second changed one input only.

* * *

## Summary

> The chapter's main results in a few lines.

A production function shows the largest output from each combination of inputs. In the short run at least one input is fixed; in the long run none is. Total product is the whole output, marginal product is the extra output from one more unit, and average product is output per unit. The law of diminishing returns says that, with some inputs fixed, extra units of one input eventually add less and less. Returns to scale asks what happens when all inputs rise in the same proportion.

## Think It Through

:q 10.t1 | The sixth worker in the binding workshop adds nothing. Explain why a seventh worker is unlikely to add anything, without using the idea that later workers are less able.
:q 10.t2 | The workshop pays each worker the same daily wage. Why does the labour cost of each extra unit of output rise as more workers are hired?

## Where People Go Wrong

> Four common misunderstandings, each corrected.

Many students think that diminishing returns means output falls; it means that the extra output shrinks. Some explain it by saying that later workers are less skilled, when the cause is the crowding of a fixed input. Others confuse the law with returns to scale, and the table in section 10.3 shows why they differ. The last error is to treat marginal and average product as the same measure; the first is the last unit's addition, and the second is the output per unit.

## In History

> In 1798 Malthus applied the idea of shrinking extra output to food.

Thomas Robert Malthus (1766 to 1834) was an English clergyman and scholar. In 1798 his book *An Essay on the Principle of Population* appeared in London, first without the author's name. He wrote it in reply to the hopeful ideas of the writer William Godwin. His central claim was that population tends to grow faster than the food supply.

> His argument is a famous use of diminishing returns, though it failed in one respect.

The argument rests on the idea of this chapter. Land is limited, and adding more labourers to the same land adds less and less food. If people multiply faster than food, hunger follows. Malthus later taught at the East India Company's college at Haileybury. His forecast has not held in most countries, because new seeds, tools and farming methods raised output beyond what the old methods allowed. In the language of this chapter, improved methods moved the whole schedule upward.

## Review Questions

:q 10.1 | Define production function, and say why it concerns the largest output.
:q 10.2 | Distinguish the short run from the long run, and give an example of a fixed input.
:q 10.3 | A farm with fixed land has outputs of 30, 70, 100 and 120 kg with 1, 2, 3 and 4 labourers. Complete a table of marginal and average product.
:q 10.4 | In the binding workshop, explain why the average product stays at 12 for the third worker.
:q 10.5 | Inputs are multiplied by 3 and output is multiplied by 2.4. Classify the returns to scale.
:q 10.6 | Inputs are multiplied by 2 and output is multiplied by 2.6. Classify the returns to scale.
:q 10.7 | State two differences between the law of diminishing returns and returns to scale.

:read Thomas Malthus, An Essay on the Principle of Population, 1798
