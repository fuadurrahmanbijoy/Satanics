:chapter VIII | Supply and the Supply Curve
:mood Why does a farmer bring more sacks to market when the price is high?
:desc This chapter builds the seller's side of the market. It explains what sellers are willing and able to sell at each price, why a higher price brings a larger quantity, how to draw the supply curve, and what shifts it. It ends with a few exceptional curves that do not rise.
:plate ch08-plate.svg | A Victorian farm-cart arriving at market, loaded with sacks and crates

> Two ideas from Chapter 4 and one appendix help with this chapter.

*You will need* two ideas from Chapter 4: what buyers are willing and able to buy, from Chapter 4 'Demand and the Demand Curve', section 4.1 'Quantity Demanded and the Law of Demand'; and the difference between a movement along a curve and a shift, from Chapter 4 'Demand and the Demand Curve', section 4.2 'Movement and Shift'. Appendix A1 'Maths You Will Use' helps with reading a graph and with rearranging an equation.

> A farm-cart arrives at the market town, and its load depends on the price.

Picture a farm-cart arriving at a Victorian market town on a Saturday morning. It is loaded with sacks of potatoes and crates of eggs. The farmer has driven eleven miles in the dark, and he has chosen carefully what to bring. Last month, when potatoes sold poorly, he brought a few sacks and kept the rest to feed his pigs. This month the price is high, and the cart is piled so high that the horse leans into the harness.

> The same farmer brings different loads, and he cannot bring an unlimited load.

The farmer, the farm and the horse are the same as last month. Only the price has changed. Yet he brings more sacks, and the market sees a larger load. Notice also what he does not do. Even at a very high price he does not bring a hundred sacks, because he has only so many fields, so many workers and so many hours. Why does a higher price bring a larger load, and what limits it?

> Chapter 4 told the story of buyers; this chapter tells the story of sellers.

Chapter 4 told the story of the crowd that buys. This chapter tells the story of the farmer who sells. The two stories mirror each other, and many ideas return in reverse form. That mirror makes the chapter easier, but it also makes a trap: students sometimes copy a rule from demand and forget to reverse it. We therefore build the seller's side step by step, and we mark each place where it differs from the buyer's side.

* * *

## 8.1 Quantity Supplied and the Law of Supply

> Begin with a question about a seller: how many would you offer at each price?

Begin with a question from your own life. Suppose you could make bracelets at home and sell them to friends. At a price of Tk 20 each you might make a few, because the beads and the time are worth more than the price. At Tk 60 each you would make many more. The number of units that sellers choose to offer for sale at one particular price in a period is called the quantity supplied. It is one number tied to one price, in the same way as the quantity demanded.

@ Supply | The quantities of a good that sellers are willing and able to sell at each price in a period.

> Supply is the whole list of prices and quantities supplied, not one number.

Economists use the word **supply** for the larger idea. Supply means the quantities of a good that sellers are willing and able to sell at each price in a period. As with demand, two conditions are needed. A seller who wishes to sell but has no stock and no means of making more is not supplying anything. A seller with plenty of stock who refuses to sell is not supplying either. For the notebook at the shop, supply is the full list: so many notebooks at Tk 20, so many at Tk 30, and so on. One entry is a quantity supplied. The whole list is supply.

@ Supply | Word in use. In daily life, supply can mean a store of goods kept for later, as in a supply of rice, or the act of providing something. In economics, supply is the whole list of quantities sellers will sell at each price.

> In this book, supply alone always means the whole list.

The everyday word needs care. In daily speech people say that "supply is short" when they mean that the stock is small today. This book keeps two words apart. Quantity supplied means one quantity at one price. Supply alone means the whole list of prices and quantities.

@ Supply schedule | A table showing the quantity supplied at each price.

> A supply schedule is a table of prices and the quantities supplied at them.

The simplest record of supply is a table. A **supply schedule** is a table showing the quantity supplied at each price. We now use the case of the shop's own wholesaler. The next paragraph is a record, and its figures are fixed.

> The case file records the weekly supply of the notebook by its wholesaler.

:case Case file, illustrative. The wholesaler who sells the 200-page notebook to Meghna and Sons records its weekly supply. At a price of Tk 20 the quantity supplied is 20 notebooks; at Tk 30, 30; at Tk 40, 40; at Tk 50, 50; at Tk 60, 60. The quantity supplied equals the price in taka.

> The same record is laid out as a table.

:table Weekly supply schedule for the 200-page notebook
| Price (Tk) | Quantity supplied (notebooks a week) |
| 20 | 20 |
| 30 | 30 |
| 40 | 40 |
| 50 | 50 |
| 60 | 60 |

> Each row pairs one price with one quantity supplied.

To read a row, take the line for Tk 40. It says that at a price of Tk 40, the wholesaler chooses to offer 40 notebooks a week. Now read down the table. As the price rises by Tk 10 each time, the quantity supplied also rises by 10 each time. Compare this with the demand schedule of Chapter 4: there the quantity fell as the price rose, and here it rises.^1 The rule in the case file, quantity equals price, gives the same numbers.

^1: Recall: demand, Chapter 4, 'Demand and the Demand Curve', section 4.1 'Quantity Demanded and the Law of Demand'.

@ Law of supply | When the price of a good rises, the quantity supplied rises, if other conditions stay the same.

> The pattern in the table is the law of supply.

The pattern has a name. The **law of supply** says that when the price of a good rises, the quantity supplied rises, if other conditions stay the same. The law works in both directions: when the price falls, the quantity supplied falls. As in the law of demand, the final clause matters. Costs, technology and taxes must stay fixed, or we cannot tell whether a change in the quantity offered came from the price.

> Two reasons explain why a higher price brings a larger quantity supplied.

Why do sellers behave in this way? Two reasons are enough for now. The first is the reward. A higher price makes each extra unit more profitable to offer, so a seller will use more hours, more materials and more space. The second is the expense of expanding. Making a large quantity usually costs more for each extra unit than making a small quantity, because the best fields, the best workers and the best machines are used first. A seller will accept the higher expense of the extra units only if the price is high enough to pay for them.

@ Cost | Word in use. In daily life, cost often means what a buyer pays for something. In economics, cost means the seller's expense in making the good, and what the buyer pays is the price.

> In this book, cost means the seller's expense, and price means what the buyer pays.

Notice how the word *cost* is used in the paragraph above. This book gives it a narrow meaning: the expense that a seller meets in making and delivering a good. What the buyer pays is called the price. A notebook may have a price of Tk 40 and cost the wholesaler less than that to supply. Keeping the two words apart avoids many confusions later.

:pause 8.p1 | At a price of Tk 30 the wholesaler supplies 30 notebooks a week. Without drawing anything, say how many notebooks are supplied at Tk 50, and state in one sentence the law of supply that your answer shows.

@ Supply curve | A line on a graph showing the quantity supplied at each price.

> A supply curve draws the table as a line on a graph.

A table is exact, but a picture shows the pattern at a glance. A **supply curve** is a line on a graph showing the quantity supplied at each price. It is drawn in the same way as the demand curve.^2 Price is on the vertical axis, and the quantity supplied is on the horizontal axis. Each row of the table gives one point: the price in the row sets the height, and the quantity sets the distance from the vertical axis. Join the five points, and a line appears.

^2: See Appendix A1 'Maths You Will Use', section A1.5 'Reading a Graph', for axes, points and slope.

> The supply curve rises from the bottom left to the top right.

For the wholesaler, the five points lie on a straight line that rises from the bottom left to the top right. We call it a curve although it is straight, because the word covers lines of every shape. The upward slope is the law of supply drawn as a picture: a higher price goes with a larger quantity supplied. A demand curve slopes downward, and a supply curve slopes upward. That single difference marks the two sides of every market, and the chart in the next section shows both the curve and what moves it.

> The section closes with the four ideas in a few lines.

*Before moving on.* Quantity supplied is one number at one price. Supply is the whole list of prices and quantities, which the supply schedule records and the supply curve draws. The law of supply says that, other conditions staying the same, a higher price brings a larger quantity supplied.

## 8.2 Determinants of Supply

> A tax on paper changes what the wholesaler offers, although the notebook's price has not moved.

Suppose the government places a tax on paper, the main material in a notebook. The wholesaler's expenses rise at once. The price of the notebook has not changed, and yet the wholesaler now offers fewer notebooks at the same price. This event is different from a change in the price of the notebook, and it shows how supply has its own movements and shifts.^3

^3: Recall: shifts, Chapter 4, 'Demand and the Demand Curve', section 4.2 'Movement and Shift'.

> A change in the price of the good itself moves us along one curve.

First, the price of the good itself changes. If the notebook's price rises from Tk 40 to Tk 50, the quantity supplied rises from 40 to 50 notebooks a week. On the graph, the point moves along the same line. We call this a movement along the curve. The curve does not change position, because the whole list of prices and quantities is the same list as before. This is the mirror of the movement along a demand curve.

> Four conditions decide where the whole supply curve lies.

Second, something other than the price changes. The supply curve was drawn with other conditions held fixed, and four are most important. The first is the cost of inputs: the materials, labour, rent and power that a seller must buy. The second is technology, meaning the methods and machines used in making the good. The third is taxes and subsidies. The fourth is the number of sellers in the market. When any of these changes, sellers offer different quantities at every price.

> Dearer inputs raise the seller's expense and reduce what is offered.

*Cost of inputs.* If paper, wages or rent become dearer, each notebook is more expensive to make, and the wholesaler offers fewer at every price. If inputs become cheaper, the wholesaler offers more. The effect works through the seller's expense, which is why the word cost, as used in this book, stays on the seller's side.

> Better methods allow a seller to make more from the same inputs.

*Technology.* A faster printing machine allows a firm to make more notebooks from the same paper and the same hours of work. Each notebook then costs less to make, and the firm offers more at every price. An improvement in technology raises supply.

> A tax raises the seller's expense, and a subsidy lowers it.

*Taxes and subsidies.* A tax on a good, or on an input, raises the seller's expense, and supply falls. A subsidy is a payment from the government to sellers to encourage them to produce, and it lowers the seller's expense, so supply rises. The tax on paper in our opening example is a tax on an input.

> More sellers in the market mean a larger quantity supplied at each price.

*Number of sellers.* If a second wholesaler begins to sell the notebook, the quantity offered to the market at each price rises. If a wholesaler leaves, the quantity falls. The table below lists the four determinants. We introduce it in words first: each row names a determinant, and the last column gives the effect on supply.

:table The determinants of supply, with a notebook example
| Determinant | Example for the notebook | Effect on supply |
| Cost of inputs | Paper becomes dearer | Falls |
| Technology | A faster printing machine is installed | Rises |
| Taxes and subsidies | A tax on paper is introduced | Falls |
| Taxes and subsidies | A subsidy on paper is introduced | Rises |
| Number of sellers | A new wholesaler enters the market | Rises |

> Read each row as a change of condition and the resulting change of supply.

To read a row, take the third line: when a tax on paper is introduced, the wholesaler's expense rises, and supply falls. The word *falls* here means that fewer notebooks are offered at every price, and not only at one price.

> A change in a determinant shifts the whole supply curve.

When a determinant changes, the whole curve moves to a new position. We call this a shift of the supply curve, which some books call a change in supply. This book uses the word shift. The case file gives a precise example.

> The case file records the shift caused by a tax on paper.

:case Case file, illustrative. A tax on paper lowers the wholesaler's weekly supply of the notebook by 10 at every price. At a price of Tk 20 the quantity supplied becomes 10; at Tk 30, 20; at Tk 40, 30; at Tk 50, 40; at Tk 60, 50.

> The chart shows the old curve, the new curve and a movement along the old curve.

Now we draw the numbers, and this is the first chart of the chapter. Read it as follows. The vertical axis shows the price in taka, and the horizontal axis shows the quantity supplied in notebooks a week. A point means: at this price, the wholesaler offers this quantity. The solid line is the original supply curve, and the dashed line is the supply curve after the tax. The bold part of the solid line shows a movement along the curve, from Tk 40 to Tk 50.

:fig The supply curve, with a movement along it and a shift to the left after a tax on paper | ch08-fig01.svg

> The new curve lies to the left of the old curve.

Read the picture along a horizontal line at Tk 40. The old curve meets this line at 40 notebooks, and the new curve meets it at 30. The gap between the two curves is 10 notebooks at every price. The price on the vertical axis did not change, so the shift is not a movement along either curve. A move to the left means less supplied at every price. A move to the right means more supplied at every price.

:pause 8.p2 | The government gives a subsidy to the makers of paper. Is the result a movement along the supply curve for notebooks or a shift? Say in which direction it goes, and give one reason.

> A short test separates the two causes.

*Before moving on.* Ask one question: what changed? If the price of the good itself changed, there is a movement along the supply curve. If the cost of inputs, technology, a tax or subsidy, or the number of sellers changed, there is a shift of the whole curve. A fall in expenses or a rise in the number of sellers shifts the curve to the right, and the opposite changes shift it to the left.

## 8.3 Exceptional Supply Curves

> Not every supply curve rises, and the exceptions teach the reasons behind the rule.

The law of supply describes most goods, but not all. Some supply curves do not slope upward, and economists have a name for them.

@ Exceptional supply curve | A supply curve that does not slope upward, such as one that bends backward or stays fixed.

> An exceptional supply curve does not rise.

An **exceptional supply curve** is a supply curve that does not slope upward, such as one that bends backward or stays fixed. Two cases are worth knowing. Each is a limit of the law, and each has a reason that you can state in one sentence.

> A backward-bending curve appears when a higher price makes a seller supply less.

The first case is the backward-bending curve. The best example is the supply of working hours by one person. As the pay for each hour rises, the worker at first offers more hours, because work is now better rewarded. At a very high rate of pay, however, the worker can earn the income that he or she needs in fewer hours, and may prefer more rest. The hours offered then fall as the pay rises further. The curve rises, reaches a peak and then bends back.

:fig A backward-bending supply curve of working hours | ch08-fig02.svg

> The curve rises at first and bends back after the peak.

Read the chart in the same way as before. The vertical axis shows the pay for one hour, and the horizontal axis shows the hours that one worker offers in a week. The solid line rises until the peak, which marks the most hours the worker will offer. Beyond the peak, the line goes back toward the vertical axis, so a higher pay brings fewer hours. This pattern is a matter of choice, and it applies to some people, not to all.

> A fixed supply stays the same at every price.

The second case is fixed supply. On a market day, a fishmonger who has caught a fixed number of fish cannot offer more, however high the price rises. A single famous painting, and a fixed number of seats in a hall, are other examples. The curve is a vertical line: the quantity supplied is the same at every price. In the short period before more can be made, the price cannot change what is on offer.

> The section closes with the two exceptional cases and their reasons.

*Before moving on.* An exceptional supply curve does not slope upward. A backward-bending curve comes from a seller who chooses less as the price rises, and a fixed supply comes from a quantity that cannot change in the short period. Both are limits of the law of supply.

## Worked Case: Using the Wholesaler's Supply Schedule

> Two links let us calculate any quantity or price from the supply rule.

The case file gives a rule: the quantity supplied equals the price in taka. In symbols, Qs = P, where Qs is the quantity supplied in notebooks a week and P is the price in taka. After the tax on paper, the quantity supplied is 10 lower at every price, so the rule becomes Qs = P − 10. Rearranged, the new rule gives P = Qs + 10.^4

^4: Appendix A1 'Maths You Will Use', section A1.3 'Rearranging an Equation', shows how to move a term across the equals sign.

> The first example is a clean calculation of a quantity and a price.

**Example 1.** *Given:* Qs = P. *Find:* the quantity supplied when the price is Tk 35, and the price at which 45 notebooks are supplied. *Formula:* quantity supplied equals the price in taka. *Steps:* at Tk 35, Qs = 35; for 45 notebooks, P = 45. *Answer:* at Tk 35 the wholesaler supplies 35 notebooks a week, and 45 notebooks a week are supplied at Tk 45. *Check:* both answers fall between rows of the table, and the quantity rises with the price, as the law of supply says.

> The second example follows the shift caused by the tax.

**Example 2.** *Given:* the old rule Qs = P and the new rule Qs = P − 10 after the tax on paper. *Find:* the quantity supplied at Tk 50 under each rule, and the price at which 30 notebooks are supplied after the tax. *Formula:* Qs = P for the old rule, Qs = P − 10 for the new rule, and P = Qs + 10 for the price under the new rule. *Steps:* old rule, Qs = 50; new rule, Qs = 50 − 10 = 40; for 30 notebooks under the new rule, P = 30 + 10 = Tk 40. *Answer:* at Tk 50 the quantity falls from 50 to 40 notebooks a week, and the wholesaler needs a price of Tk 40 to offer 30 notebooks. *Check:* the table after the tax shows 30 notebooks at Tk 40, and the fall of 10 matches the case file.

> Sorting events as price causes or non-price causes needs only one question.

**Worked classification.** *Situation:* in one month, six events happen. (a) The wholesaler raises the notebook price from Tk 40 to Tk 50. (b) A tax on paper is introduced. (c) A faster printing machine is installed. (d) A second wholesaler begins to sell the notebook. (e) Paper becomes dearer for another reason. (f) The notebook price falls from Tk 60 to Tk 50. *Question:* which events are movements along the supply curve and which are shifts? *Reasoning:* in (a) and (f) the price of the good itself changed. In (b) the tax changed, in (c) the technology changed, in (d) the number of sellers changed, and in (e) the cost of inputs changed. *Conclusion:* (a) and (f) are movements along the curve, and (b) to (e) are shifts, with (c) and (d) to the right and (b) and (e) to the left. *Check:* only (a) and (f) change the price on the vertical axis for the notebook.

> Four common slips spoil these answers.

*Common slips.* Students often call a price change a shift. They give the direction of a shift the wrong way, forgetting that a fall in supply moves the curve to the left. They treat the new rule as Qs = P + 10 instead of Qs = P − 10. And they use the word cost for what the buyer pays, when this book uses price for that.

## Summary

> The chapter's main ideas in a few lines.

Supply is the set of quantities that sellers are willing and able to sell at each price, and a quantity supplied is one entry in that set. The law of supply says that, other conditions staying the same, a higher price brings a larger quantity supplied, so the supply curve slopes upward. A change in the price of the good is a movement along the curve. A change in the cost of inputs, technology, taxes or subsidies, or the number of sellers is a shift of the curve. An exceptional supply curve, such as a backward-bending curve or a fixed supply, does not slope upward.

## Think It Through

> Two problems that apply the chapter to new settings.

:q 8.t1 | A worker is offered more and more pay for each hour, yet at a very high rate chooses to work fewer hours. Give two reasons for this choice, and say what shape of supply curve it makes.

:q 8.t2 | A fishmonger has 200 fish on a market day and no way of getting more before the market closes. Describe the supply curve for that day, and say what changes if the market is open for a week.

## Where People Go Wrong

> A shift is often confused with a movement.

*Error 1: "A rise in the price of the good shifts its supply curve."* This is wrong. A rise in the price of the good moves the point along the same curve. Only a change in a determinant shifts the curve.

> The direction of a shift is often reversed.

*Error 2: "A tax on inputs shifts supply to the right."* This is wrong. A tax raises the seller's expense, so fewer units are offered at every price, and the curve shifts to the left.

> Supply is not the same as quantity supplied.

*Error 3: "Supply and quantity supplied mean the same."* This is wrong. Quantity supplied is one number at one price. Supply alone is the whole list of prices and quantities.

> Cost and price are different ideas in this book.

*Error 4: "The cost of a notebook is what the shop pays the wholesaler, so cost and price are the same."* This is wrong in this book. Price is what a buyer pays. Cost is the seller's expense in making and delivering the good.

## In History

> An English professor compared supply and demand to the two blades of a pair of scissors.

In 1890, Alfred Marshall, who lived from 1842 to 1924 and taught economics at Cambridge in England, published *Principles of Economics*. He had begun the book in 1881. Before him, economists had long argued about what governs the price of a good: the satisfaction it gives to buyers, or the expense of making it. Marshall answered with a comparison. We might as sensibly ask which blade of a pair of scissors cuts a piece of paper, he wrote, as ask which of the two decides the price.

> The picture has lasted, and modern economists still begin with it.

Marshall's point was that supply and demand work together, and both are needed. The book became the leading textbook in England for many years. To this day, an economist who wishes to explain why the price of a good has changed begins by asking whether the demand curve shifted, or the supply curve, or both. The next chapter, Chapter 9 'Elasticity of Supply and Market Equilibrium', puts the two blades together.

## Review Questions

> Seven questions that check the chapter's ideas.

:q 8.1 | Plot the supply schedule of the notebook from the case file on a graph, with price on the vertical axis. Say what the slope of the line shows.

:q 8.2 | After the tax on paper, the quantities supplied at Tk 20, 30, 40, 50 and 60 are 10, 20, 30, 40 and 50. Plot the new curve on the same graph as the old one. Then draw a third curve that shows an increase in supply of 15 at every price, and give its quantity at Tk 40.

:q 8.3 | Sort each cause as a price cause (movement along the curve) or a non-price cause (shift of the curve): (a) the notebook price rises from Tk 30 to Tk 40; (b) paper becomes cheaper; (c) a subsidy is paid to notebook makers; (d) the wholesaler lowers the notebook price from Tk 60 to Tk 50.

:q 8.4 | Using Qs = P, find the quantity supplied at Tk 55 and the price at which 25 notebooks are supplied. Then, using Qs = P − 10, find the quantity supplied at Tk 55.

:q 8.5 | State the law of supply, and name one condition that must stay the same for it to hold.

:q 8.6 | Name two kinds of exceptional supply curve, and give one example of each.

:q 8.7 | A new wholesaler enters the market, and the notebook's price is unchanged. Say what happens to supply, and name the determinant that changed.

:read Alfred Marshall, Principles of Economics, 1890
