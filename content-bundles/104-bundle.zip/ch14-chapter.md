:chapter XIV | Monopoly and Imperfect Competition
:mood Who sets the price when there is no crowd of sellers?
:desc Chapter 13 studied a firm so small that it must accept the market price. This chapter studies the other cases: the single seller, the many sellers whose goods differ, and the few large sellers who watch one another.
:plate ch14-plate.svg | A Victorian diamond merchant weighs stones in a guarded room, as one seller guards his supply

:box YOU WILL NEED
Chapter 13 'Market Structure and Perfect Competition', section 13.1 'Kinds of Market'; Chapter 13 'Market Structure and Perfect Competition', section 13.2 'The Perfectly Competitive Firm'; Chapter 11 'Costs of Production', section 11.2 'Short-Run Costs'; Appendix A1 'Maths You Will Use'.

> One seller seems able to charge any price, yet something stops it.

A town has one shop that sells a rare title which every student of a certain subject must read. No other shop stocks it. The owner thinks: "I am the only seller, so I may charge Tk 1,000 a copy." Why does she not do so? At Tk 1,000 almost no student would buy, and her shelf would stay full. At a very low price many students would buy, but she would earn little on each copy. Somewhere between the two lies a price that brings her the most profit. How does she find it?

> The seller must weigh the price she asks against the quantity she sells.

Chapter 13 described the opposite case. A firm in perfect competition is a price taker: it accepts the market price and chooses only its output. A single seller faces a harder and more interesting choice. Every time she lowers her price to sell more, she earns less on the copies that she could already sell. So she must weigh price against quantity, and the weighing needs a new idea, which we meet in section 14.1.

> Most real markets lie between the two extremes.

Few markets look like either extreme. A street of tea stalls has many sellers, yet each stall is a little different. Mobile telephone service in many countries is supplied by a handful of large firms. This chapter therefore studies four markets in turn: the single seller, the many sellers whose goods differ, the few large sellers, and then all four side by side. Many students find the long list of market names confusing. We give each name one plain definition and one picture, and we compare the markets only at the end.

* * *

## Monopoly

> A village with one ferry shows the single-seller idea.

Begin with a village on a wide river. One ferry carries people across, and no bridge or other boat exists. The ferry owner does not fear that a neighbouring ferry will take her passengers, because there is none. She can choose her fare, and the villagers must pay it or stay on their side. Her position is the heart of this section: a seller with the whole market to itself.

@ Monopoly | A market in which one seller supplies a good with no close substitute.

@ Monopoly | Word in use. In daily life, people call any very large firm a monopoly, and a board game carries the same name. In economics, it means one seller with no close substitute, however small the market.

> One seller with no close substitute makes a monopoly.

A **monopoly** is a market in which one seller supplies a good with no close substitute. The ferry across the river is a monopoly, and so is the only pharmacy on a remote island. The word *close* matters: a good has a close substitute if consumers would readily switch to it when the price rises. Swimming is not a real choice for the villagers, so the ferry has none. The size of the market does not matter; a monopoly may serve a village or a nation.

@ Price maker | A firm that can choose its price because it faces the whole demand of the market.

> A monopolist can choose its price, unlike a price taker.

Because the monopolist is the only seller, the demand curve of the whole market is its own demand curve. That makes it a **price maker**: a firm that can choose its price because it faces the whole demand of the market. Compare the price taker of Chapter 13, which must accept the market price.^1 The monopolist's power has a limit. If it raises its price, consumers buy less; if it lowers its price, they buy more. It can choose the price or the quantity, but not both: the demand curve fixes the other.

^1: Recall: price taker, Chapter 13, 'Market Structure and Perfect Competition', section 13.2 'The Perfectly Competitive Firm'.

> Barriers to entry protect a monopoly from rivals.

A monopoly lasts only while rivals cannot enter. Four common barriers stand in their way. The firm may own the only supply of a key resource, as one mine may hold all the stones. The law may give it an exclusive right, such as a patent or a licence. One large firm may serve the market at a lower cost for each unit than two smaller firms could, so a second firm would lose money. Or the firm may use threats to drive rivals away. The law differs by country: some governments grant exclusive rights, and others forbid firms to misuse their power, so a reader must learn the rules of the country concerned.

@ Marginal revenue | The extra revenue from selling one more unit of output.

> To choose her output, the seller needs the extra revenue from one more unit.

Return to the bookshop. To choose her output, the owner must know what each extra copy adds to her revenue. This idea is called **marginal revenue**, which means the extra revenue from selling one more unit of output. If she sells one more copy and her revenue rises by Tk 40, the marginal revenue is Tk 40. For a price taker, marginal revenue equals the price, because extra units sell at the same price. For a price maker it is smaller than the price, and the next paragraph shows why.

> To sell more, a monopolist must cut the price on every unit.

Take the case that follows. The seller sells 20 copies at Tk 60. To sell 30 copies she must cut the price to Tk 50, and the cut applies to all 30 copies, including the first 20. She gains 10 new copies at Tk 50, which is Tk 500. She loses Tk 10 on each of the first 20 copies, which is Tk 200. The net gain is Tk 300 for 10 extra copies, or Tk 30 a copy. So marginal revenue, Tk 30, lies well below the price of Tk 50.

> A worked example turns the idea into a formula.

*Given.* At 20 units the price is Tk 60 and total revenue is Tk 1,200; at 30 units the price is Tk 50 and total revenue is Tk 1,500.
*Find.* The marginal revenue per unit for the step from 20 to 30 units.
*Formula.* In words: the rise in total revenue divided by the rise in output. In symbols: MR = X ÷ Y, where MR is marginal revenue, X is the rise in total revenue and Y is the rise in output.
*Steps.* X = 1,500 − 1,200 = Tk 300. Y = 30 − 20 = 10 units. MR = 300 ÷ 10 = Tk 30 per unit.
*Answer.* Marginal revenue for this step is Tk 30 per unit.
*Check.* The gain of Tk 500 less the loss of Tk 200 is Tk 300, which agrees; and Tk 30 is below the price of Tk 50, as the argument said it must be.

:pause 14.p1 | A seller sells 20 units at Tk 60 and 30 units at Tk 50. Why is the marginal revenue of the step below Tk 50?

> The case file gives the seller's price, revenue and costs.

:case Case file, illustrative. A seller with the whole market for a specialised title: price Tk 70 at 10 units, Tk 60 at 20, Tk 50 at 30, Tk 40 at 40, Tk 30 at 50 (price = 80 − quantity); total revenue 700, 1,200, 1,500, 1,600, 1,500; marginal revenue per step 70, 50, 30, 10, −10; marginal cost per step 30, 22, 20, 24, 34. Output 30 at price Tk 50; total cost 1,320; profit Tk 180.

> The table sets the case out in five rows.

The table repeats the case file in a form that is easy to scan. Read across each row: the output, the price at which that output sells, the total revenue (price times output), the marginal revenue for the 10-unit step that ends at that output, and the marginal cost for the same step. Marginal revenue falls faster than price, and it becomes negative in the last row, where selling more lowers total revenue.

:table The seller's price, revenue and costs (taka)
| Output | Price | Total revenue | Marginal revenue | Marginal cost |
| 10 | 70 | 700 | 70 | 30 |
| 20 | 60 | 1,200 | 50 | 22 |
| 30 | 50 | 1,500 | 30 | 20 |
| 40 | 40 | 1,600 | 10 | 24 |
| 50 | 30 | 1,500 | −10 | 34 |

> The best output is where marginal revenue meets marginal cost.

How much should she sell? Compare, step by step, what a step adds to revenue with what it adds to cost. A step is worth taking while marginal revenue is at least marginal cost, because it then adds at least as much to revenue as to cost. Look down the table. The step to 30 units adds Tk 30 a unit to revenue and Tk 20 to cost, so it adds profit. The step to 40 units adds only Tk 10 to revenue but Tk 24 to cost, so it loses profit. The best output is 30 units, and the price comes from the demand curve: Tk 50. This is the rule that Chapter 13 used for the competitive firm, with marginal revenue in place of price.^2

^2: Recall: marginal cost, Chapter 11, 'Costs of Production', section 11.2 'Short-Run Costs'; the output of largest profit is taught in Chapter 13, 'Market Structure and Perfect Competition', section 13.3 'Equilibrium of Firm and Industry'.

> The figure draws the same facts as three lines.

The figure shows the same facts. The horizontal axis counts output in units, and the vertical axis counts taka. The falling straight line is the demand curve: each point gives the price at which that output sells. The steeper line below it is marginal revenue, which falls twice as fast and reaches zero at 40 units. The curved line is marginal cost. Where marginal revenue meets marginal cost, at about 30 units, we climb to the demand curve to read the price, Tk 50. The shaded rectangle is the profit: the gap between the price of Tk 50 and the average cost of Tk 44 (1,320 ÷ 30) is Tk 6, and Tk 6 times 30 units is Tk 180.

:fig The monopolist's demand, marginal revenue and marginal cost, with the best output and its profit | ch14-fig01.svg

> A monopoly is not sure of profit, and its position may not last.

The theory has exceptions. First, a monopolist may lose money if no price on the demand curve covers its average cost; being the only seller does not create buyers. Second, a monopoly seldom lasts for ever. A high profit tempts rivals to find a way round the barrier, and governments may control the price or break up the firm. From the consumer's viewpoint, the monopoly price is usually higher and the output lower than in a competitive market, as section 14.4 shows.

> Recap of section 14.1.

*Before moving on.* A monopoly has one seller and no close substitute, so the seller is a price maker. Marginal revenue lies below price, and the seller chooses the output at which marginal revenue meets marginal cost, then reads the price from the demand curve. *You should now be able to say* why a monopolist's marginal revenue is smaller than its price.

## Monopolistic Competition

> A street of tea stalls shows many sellers whose goods differ.

Walk down a busy street in Dhaka lined with small stalls that sell tea and biscuits. There are many sellers, and anyone may open another stall. Yet no two stalls are the same. One has a shaded seat, another brews a stronger tea, a third stands where the buses stop. Regular consumers prefer one stall and will pay a little more to keep going there. Each stall therefore holds a small power over its own price, although many rivals are close by.

@ Monopolistic competition | A market with many sellers of similar but not identical goods, and free entry.

> Many sellers of similar but different goods, with free entry, make monopolistic competition.

This market has a name. **Monopolistic competition** is a market with many sellers of similar but not identical goods, and free entry. The tea street is one example; hair salons and small restaurants in one neighbourhood are others. The name joins two ideas. Each seller is a little like a monopolist, because its good differs from rivals' goods. Each seller also competes, because rivals offer close, though not perfect, substitutes, and anyone may enter.

@ Product differentiation | Making a good different from rivals' goods in quality, style or brand, to build loyal buyers.

@ Brand | Word in use. In daily life, a name printed on a good, or a mark burned on cattle. In economics, a name and style that make a firm's good known and different from rivals' goods.

> Differences in quality, style or brand give each seller loyal consumers.

The source of each seller's small power is **product differentiation**, which means making a good different from rivals' goods in quality, style or brand, to build loyal buyers. A stall that serves tea in clean glasses with a friendly greeting has differentiated itself. The *brand* of a good is the name and style by which consumers recognise it. The differences may be real, such as a stronger tea, or only believed, such as a famous name. Either way, a loyal consumer finds the good hard to replace.

> Its demand curve slopes down but is flatter than a monopolist's.

Because the good is different, a seller can raise its price without losing every consumer, so its demand curve slopes downward, as a monopolist's does. Because close substitutes exist, a rise in its price still sends many consumers to rivals, so the curve is flatter than a monopolist's would be. Like the monopolist, the seller finds that marginal revenue lies below price, and it chooses the output at which marginal revenue equals marginal cost. We call that choice the equilibrium of the firm, a term taught in Chapter 13, section 13.3 'Equilibrium of Firm and Industry'.

> Free entry removes extra profit over time.

In the short run, a differentiated seller may earn more than the least profit it needs to stay in business. That profit attracts new sellers, who open new stalls with similar goods. Each new rival takes some consumers from the existing sellers, so every existing seller's demand curve shifts inwards. The process continues until a typical seller earns only enough to stay in business. This is the same ending as in perfect competition, but with one difference: each seller still has loyal consumers, so its price stays a little above marginal cost.

> Differentiation costs money, and whether it helps consumers is a matter of judgement.

Differentiation has costs. Sellers spend on advertising, packaging and decoration to build a brand, and these costs enter the price. Consumers gain variety, which many value. Whether the gain outweighs the cost is a matter of judgement, and economists differ. From the owner's viewpoint, the aim is loyalty. From the consumer's viewpoint, it is choice. From the employee's viewpoint, a stall with loyal consumers may offer steadier work.

> Recap of section 14.2.

*Before moving on.* Monopolistic competition has many sellers, free entry and goods that differ. Product differentiation gives each seller a downward-sloping demand curve, flatter than a monopolist's, and free entry removes extra profit over time. *You should now be able to say* what separates it from both perfect competition and monopoly.

## Oligopoly

> Three bus firms on one road show how few sellers watch each other.

Imagine a long road served by only three bus firms. If one firm cuts its fare, it will take many riders from the other two, so they will probably cut theirs too. If one raises its fare, the others may keep theirs low and take its riders. Before changing a fare, each firm must guess how the others will react. A seller among many sellers never worries about this. A seller among a few worries about it all the time.

@ Oligopoly | A market dominated by a few large sellers, each aware of what the others do.

> A few large sellers, each watching the others, make an oligopoly.

An **oligopoly** is a market dominated by a few large sellers, each aware of what the others do. Mobile telephone service, flights on a busy route and cement in a country are common examples. The word comes from Greek words meaning *few* and *to sell*. Entry is hard, because the firms are large and a newcomer needs a great deal of money, equipment or consumer loyalty to compete with them.

> Each firm's best choice depends on its rivals' choices.

The key feature is *interdependence*: the best price or output of each firm depends on what its rivals do. In a competitive market a firm ignores its rivals, because each is too small to matter. In a monopoly there are no rivals to watch. In an oligopoly the firms are few enough that every move is noticed. This makes the market harder to predict, and economists offer several theories rather than one.

> Kinked demand explains why prices in an oligopoly often stay fixed.

One theory explains why oligopoly prices often stay the same for long periods. Suppose a firm believes that its rivals will copy a price cut but ignore a price rise. If it cuts its price, rivals match the cut, and it gains few extra consumers. If it raises its price, rivals do not follow, and it loses many consumers. So its demand curve bends, or has a kink, at the present price: flat above that price and steep below it. The firm sees little reward in changing its price in either direction, so it leaves the price alone. The theory explains why a price stays where it is; it does not explain how the price was first set.

:pause 14.p2 | Why might an oligopolist leave its price unchanged even when its costs fall a little?

> Firms may compete on features or agree to act together, and the law often forbids agreement.

Oligopolists have two broad paths. They may compete without cutting prices, by advertising, quality and service. Or they may agree with one another on prices or output, acting together like a single monopolist. Many countries forbid such agreements through competition law, but the rules and the penalties differ from country to country. Agreements are also fragile, because each firm can gain by secretly selling below the agreed price, and when many firms do this the agreement fails.

> Recap of section 14.3.

*Before moving on.* An oligopoly has a few large sellers, hard entry and interdependence: each firm must guess how rivals will react. Kinked demand explains why prices often stay fixed, and agreements among firms are fragile and often unlawful. *You should now be able to say* why one firm's choice affects the others.

## Comparing Markets

> A table compares the four markets on four features.

The table below sets the four markets side by side. Read one column at a time to see what defines each market, and read one row at a time to see how a single feature changes as we move from many sellers to one. The figure that follows shows the number of sellers as dots, and the shapes show whether the goods are alike or different.

:table The four market structures compared
| Feature | Perfect competition | Monopolistic competition | Oligopoly | Monopoly |
| Sellers | Very many | Many | Few | One |
| Goods | Identical | Similar but different | Identical or different | No close substitute |
| Entry | Free | Free | Hard | Blocked |
| Price | Price taker | Price maker, small power | Price maker, watches rivals | Price maker, large power |

:fig Four market structures: very many, many, few and one seller | ch14-fig02.svg

> In the case file, the monopoly sells less at a higher price than a competitive market would.

Suppose, as an illustration, that a competitive market faced the same demand and the same marginal cost as the seller of the case file. Competitive sellers push output to the point where price equals marginal cost. At 40 units the price is Tk 40 and the marginal cost of the step is Tk 24, so output rises. At 50 units the price is Tk 30 and the marginal cost is Tk 34, so output stops at 40. The competitive market would sell 40 units at Tk 40, while the monopolist sells 30 units at Tk 50: ten fewer units, at a price Tk 10 higher.

> Lower price is one measure of a market, not the only one.

Is a lower price always better? Not always. A competitive market tends to give the lowest price for a given good, but one large firm may serve everyone at a lower cost for each unit than many small firms could. Monopolistic competition gives consumers variety that a market of identical goods cannot. Price is one measure of how well a market serves consumers; quantity, quality, variety and the pace of new ideas are others. The reader should weigh them all.

> Recap of section 14.4.

*Before moving on.* The four markets differ in the number of sellers, the kind of goods and the ease of entry, and these differences decide how much power a seller has over price. *You should now be able to say* which market a given description fits.

## Worked Case: The Seller's Best Output

> The case file gives the data for the worked case.

*Given.* From the case file of section 14.1: demand price = 80 − quantity; total revenue 700, 1,200, 1,500, 1,600, 1,500 at outputs 10 to 50; marginal cost per unit for each 10-unit step 30, 22, 20, 24, 34; total cost Tk 1,320 at 30 units.
*Find.* The output of largest profit, the price, and the profit.
*Formula.* In words: raise output while marginal revenue is at least marginal cost; read the price from demand; profit is total revenue minus total cost. In symbols: profit = P × Q − C, where P is price, Q is output and C is total cost.

> The steps compare marginal revenue with marginal cost for each step.

*Steps.* (1) Marginal revenue per unit for each step: 700 ÷ 10 = 70; (1,200 − 700) ÷ 10 = 50; (1,500 − 1,200) ÷ 10 = 30; (1,600 − 1,500) ÷ 10 = 10; (1,500 − 1,600) ÷ 10 = −10. (2) Compare with marginal cost: 70 against 30, take the step; 50 against 22, take it; 30 against 20, take it; 10 against 24, stop. (3) Output is 30 units. (4) Price = 80 − 30 = Tk 50. (5) Total revenue = 50 × 30 = Tk 1,500. (6) Profit = 1,500 − 1,320 = Tk 180.
*Answer.* The seller sells 30 units at Tk 50 and earns a profit of Tk 180.
*Check.* Total cost at 20 units is 1,320 − 10 × 20 = Tk 1,120, so profit there is 1,200 − 1,120 = Tk 80. Total cost at 40 units is 1,320 + 10 × 24 = Tk 1,560, so profit there is 1,600 − 1,560 = Tk 40. Both are below Tk 180.

> A second example uses a new seller and less tidy numbers.

*Given.* Price = 60 − quantity; fixed cost Tk 100; marginal cost per unit for the 10-unit steps ending at 10, 20, 30 and 40 units: 20, 22, 25, 30. *Find.* Output, price and profit. *Formula.* As above. *Steps.* Total revenue at 10, 20, 30, 40 units: 500, 800, 900, 800. Marginal revenue per unit: 50, 30, 10, −10. Against marginal cost, the first two steps are taken (50 over 20, 30 over 22) and the third is not (10 under 25). Output is 20 units and price is 60 − 20 = Tk 40. Total cost = 100 + 10 × 20 + 10 × 22 = Tk 520. Profit = 800 − 520 = Tk 280. *Answer.* 20 units at Tk 40, profit Tk 280. *Check.* At 30 units, total cost is 520 + 10 × 25 = 770 and revenue is 900, so profit is 130, which is less than 280.

> Four common slips spoil these calculations.

Common slips deserve a warning. Some students compare price with marginal cost instead of marginal revenue with marginal cost. Some read the price from the marginal revenue line, when it must come from the demand curve at the chosen output. Some forget that a step of 10 units must be divided by 10 to give a figure per unit. Others choose an output where marginal revenue is negative, which always loses money when marginal cost is positive.

> Recap of the worked case.

*Before moving on.* To find a monopolist's best output, compute marginal revenue for each step, take steps while it is at least marginal cost, read the price from demand, and then find profit. *You should now be able to say* how each of the six steps leads to the answer.

* * *

## Summary

> The chapter's four markets and one rule fit together.

A monopoly has one seller and no close substitute, so the seller is a price maker whose marginal revenue lies below its price. It chooses the output at which marginal revenue meets marginal cost, and it reads the price from demand. Monopolistic competition has many sellers, free entry and product differentiation. An oligopoly has a few large sellers who must guess one another's moves. Compared with competition, a monopoly tends to sell less at a higher price.

## Think It Through

:q 14.t1 | Is a lower price always better for consumers? Give one reason from the chapter why the answer may be no.
:q 14.t2 | Why will a seller with positive marginal cost never choose an output at which marginal revenue is negative? Use the 50-unit row of the table to test your answer.

## Where People Go Wrong

> A monopolist cannot charge any price it likes.

Some students think a monopolist can charge any price. It cannot. It controls its price only up to the limit set by the demand curve: a higher price brings fewer buyers. The seller in the case file chooses Tk 50, not Tk 500.

> Marginal revenue is not the same as price for a price maker.

Some students use the price as the marginal revenue of a monopolist. For a price taker the two are equal, but for a price maker marginal revenue is smaller, because a cut in price applies to every unit sold.

> Monopolistic competition is not a mild monopoly.

Some students treat monopolistic competition as a weak form of monopoly. It differs in kind. It has many sellers and free entry, so extra profit does not last, while a monopoly is protected by barriers.

> Oligopoly does not mean that firms agree.

Some students think firms in an oligopoly must agree with one another. The defining feature is interdependence, not agreement. Firms may compete hard, and agreements are often unlawful and fragile.

## In History

> A British businessman joined many diamond owners into one firm.

At Kimberley, in what is now South Africa, many separate owners worked diamond claims in the 1870s and 1880s. Cecil Rhodes, a British businessman who had come to South Africa as a young man, set out to buy the claims and join them under one owner. His chief rival was Barney Barnato, another Briton, whose firm owned much of the Kimberley mine.

> In 1888 the rival holdings merged into De Beers Consolidated Mines.

In March 1888 the rival holdings were merged to form De Beers Consolidated Mines, with Rhodes as its first chairman. In July 1889 the firm paid £5,338,650, then an unprecedented sum, for the Kimberley mine, and in the same month it won control of two more mines, Bultfontein and Dutoitspan. It then controlled most of the world's supply of diamonds, the first barrier of section 14.1. That barrier did not hold for ever: later, new mines in other places came into production and loosened the firm's hold.

## Review Questions

:q 14.1 | Total revenue is Tk 1,500 at 30 units and Tk 1,600 at 40 units. Find the marginal revenue per unit for the step from 30 to 40 units.
:q 14.2 | A seller faces price = 60 − quantity and has a fixed cost of Tk 100. Total revenue is 500, 800, 900 and 800 at 10, 20, 30 and 40 units, and the marginal cost per unit for the four 10-unit steps is 20, 22, 25 and 30. Find the output, the price and the profit.
:q 14.3 | In the case file the marginal revenue of the step to 30 units is Tk 30 per unit. A manager says it is Tk 300. Show that both figures agree, and say which to compare with a marginal cost of Tk 20 per unit.
:q 14.4 | Suppose a competitive market faced the demand and marginal cost of the case file, so that price equals marginal cost. Find its output and price, and compare them with the monopoly's.
:q 14.5 | Name the market: (a) many tailors, each with a different style, free to open new shops; (b) three firms supply all the cement in a country; (c) one firm holds the only licence to supply a town with water.
:q 14.6 | A tea stall's total revenue is Tk 800 at 40 cups and Tk 900 at 50 cups, and its marginal cost is Tk 12 a cup for those 10 cups. Find the marginal revenue per cup and say whether the stall should sell the extra 10 cups. Is marginal revenue below the price of Tk 18 at 50 cups?

:read Joan Robinson, The Economics of Imperfect Competition, 1933
:read Edward Chamberlin, The Theory of Monopolistic Competition, 1933
