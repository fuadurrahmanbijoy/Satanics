:chapter VII | Indifference Curve Analysis
:mood Can a shopper's wishes be drawn on paper?
:desc This chapter draws a consumer's taste as a line of equal satisfaction and her purse as a line of limited spending. Where the two lines meet in the right way, we find the combination of two goods that suits her best.
:plate ch07-plate.svg | A Victorian draper's shop: a shopper weighs two bolts of cloth against the contents of her purse

:box YOU WILL NEED
Chapter 3 'Utility and Diminishing Marginal Utility', section 3.1 'The Idea of Utility'; Chapter 6 'Consumption and Consumers' Surplus', section 6.2 'Consumers' Surplus'; Appendix A1 'Maths You Will Use'.

> A shopper's choice depends on taste and on the size of her purse.

Suppose you enter a market stall that sells only two goods, mangoes and guavas, and you have Tk 100 to spend. You could buy only mangoes. You could buy only guavas. Or you could buy some of each, in many different mixes. Every mix may cost the same, yet you will not feel the same about them. Which mix should you choose? Most people say, "The one I like best." That answer is true, but it hides two questions. What does it mean to like one mix as much as another? And how does the purse limit the choice?

> This chapter answers both questions with two lines on one graph.

Chapter 3 gave one way to think about taste: count the satisfaction, or utility, of each mix. Counting is difficult, because nobody can look inside a buyer's mind and read a number. This chapter offers a second way that needs no counting. It asks only that a shopper can say whether one mix is better than, worse than, or equal to another. From that single ability we can draw a picture of her taste, and then add a picture of her purse.

> The first line shows what pleases the shopper; the second shows what she can afford.

The picture has two parts. The first is a line of taste: all the mixes that please the shopper equally. The second is a line of limit: all the mixes that her money can buy. Where the two lines meet in the right way, we shall find her best choice. Section by section, we give each line its proper name, learn how to measure its steepness, and then bring the two together. Many students find a graph with several lines confusing at first, because each line answers a different question. We therefore go one line at a time.

* * *

## Indifference Curves

@! Go slowly here.

> A friend's two plates of fruit can please you equally.

Begin with an everyday case. A friend offers you a plate of fruit. Plate one holds 4 mangoes and 2 guavas. Plate two holds 3 mangoes and 4 guavas. After a moment's thought you say that you would be equally happy with either plate. On plate two you have lost one mango and gained two guavas, and your pleasure has not changed. In ordinary speech you are *indifferent* between the plates, which means you do not mind which one you receive.

> Economists call a particular amount of each of two goods a combination.

Economists use the same idea with two goods of their choosing. Let the goods be notebooks and pens. A particular amount of each good, such as 4 notebooks and 14 pens, is called a *combination*. (Some books say *bundle*; this chapter uses *combination* throughout.) For any two combinations, a consumer can say: this one is better, that one is better, or they are equal. That is the only ability we need, and every adult shopper has it.

@ Indifference curve | A line showing all combinations of two goods that give a consumer the same satisfaction.

> An indifference curve joins all the combinations that please equally.

Now we can name the main tool of the chapter. An **indifference curve** is a line showing all combinations of two goods that give a consumer the same satisfaction. The two plates of fruit above would lie on one indifference curve, because you value them equally. The satisfaction in question is what Chapter 3 called utility.^1 Notice the change of method. Chapter 3 tried to count utility in numbers; here we only compare. Every combination on one curve has the same utility, whatever that utility is worth in numbers.

^1: Recall: utility, Chapter 3, 'Utility and Diminishing Marginal Utility', section 3.1 'The Idea of Utility'.

@ Curve | Word in use. In daily life, a bend in a road or a river. In economics, a line drawn on a graph, which may bend or may be straight.

> The word curve means a line on a graph, bent or straight.

Many students find the word *curve* confusing, because it suggests a bend, and the economist's curve is sometimes straight. Treat it as a name for any line drawn on a graph to show a relationship. An indifference curve does bend, for a reason that we meet in section 7.2. Until then, think of it only as a path through the combinations that please equally.

> A table of five combinations shows the same satisfaction throughout.

Now build one indifference curve from small, round numbers. The table below lists five combinations of notebooks and pens that one student values equally. Read each row from left to right: the letter names the combination, and the next two columns give its notebooks and its pens. These figures are made up to teach the idea; they are not part of the case file. Notice how the number of pens falls as the number of notebooks rises.

:table One student's equally satisfying combinations (illustration)
| Combination | Notebooks | Pens |
| A | 3 | 20 |
| B | 4 | 14 |
| C | 6 | 8 |
| D | 8 | 5 |
| E | 12 | 2 |

> The same five combinations drawn as points make a falling line.

A graph shows the same facts in a second form. The first time we use one, here is how to read it. The horizontal axis counts notebooks. The vertical axis counts pens. Each point is one combination: its distance along tells the notebooks, and its height tells the pens. Join the five points with a smooth line and you have an indifference curve. It falls from left to right and bends in towards the corner where the axes meet.

:fig An indifference curve through the five combinations A to E | ch07-fig01.svg

> The curve falls because more of one good must replace less of the other.

Why does the curve fall? Suppose the student holds combination A and receives one more notebook. She now has more of one good, so she is better off. To return to her old level of satisfaction she must give up some pens. That is why the notebooks go up while the pens go down. If both numbers rose together, the new combination would be better, so it could not lie on the same curve. This argument uses one assumption: the student always prefers more of a good to less.

:pause 7.p1 | Combination P has 5 notebooks and 10 pens. Combination Q has 5 notebooks and 12 pens. Can P and Q lie on the same indifference curve? Give your reason.

@ Indifference map | A set of indifference curves, with higher curves showing greater satisfaction.

> Many curves together, higher ones better, form an indifference map.

One curve shows one level of satisfaction, but the student can imagine many levels, so there are many curves. An **indifference map** is a set of indifference curves, with higher curves showing greater satisfaction. Think of the contour lines on a walker's map, where each line joins places of equal height; here each line joins combinations of equal satisfaction, and a curve further from the corner of the axes is a higher hill. The student prefers 6 notebooks and 14 pens to 6 notebooks and 8 pens, because it has the same notebooks and more pens, so it lies on a higher curve.

> Four properties of the curves follow from one assumption.

Four properties follow from the assumption that the consumer prefers more of a good to less. First, each curve slopes downward, as the table showed. Second, a curve further from the corner where the axes meet gives greater satisfaction, because it holds more of the goods. Third, curves bend in towards that corner; section 7.2 'Marginal Rate of Substitution' explains why. Fourth, two curves never cross. The assumption has limits. If more of a good makes the consumer worse off, such as a sweet she has already eaten too many of, the first property fails. This chapter keeps to the usual case.

> Recap of section 7.1.

*Before moving on.* An indifference curve joins the combinations of two goods that please a consumer equally. It slopes down, and a map of such curves ranks every combination, with higher curves better and no two curves crossing. *You should now be able to say* what one point on a curve shows and why a higher curve is preferred.

## Marginal Rate of Substitution

@ Marginal rate of substitution | The amount of one good a consumer will give up to gain one more unit of another good.

@! Go slowly here.

> Moving along a curve means swapping one good for the other.

Return to the table of equally satisfying combinations. Moving from B (4 notebooks, 14 pens) to C (6 notebooks, 8 pens), the student gains 2 notebooks and gives up 6 pens, and her satisfaction stays the same. At what rate does she swap pens for notebooks? The **marginal rate of substitution** is the amount of one good a consumer will give up to gain one more unit of another good. Here she gives up 3 pens for each extra notebook, so the rate over this step is 3. The word *marginal* means "one more", as in the marginal utility of Chapter 3.^2

^2: Recall: marginal utility, Chapter 3, 'Utility and Diminishing Marginal Utility', section 3.1 'The Idea of Utility'.

> A worked example turns the swap into a number.

*Given.* Combination B has 4 notebooks and 14 pens; combination C has 6 notebooks and 8 pens; both lie on one curve.
*Find.* The rate at which pens are swapped for notebooks from B to C.
*Formula.* In words: pens given up divided by notebooks gained. In symbols: rate = F ÷ G, where F is the fall in pens and G is the gain in notebooks.
*Steps.* F = 14 − 8 = 6 pens. G = 6 − 4 = 2 notebooks. Rate = 6 ÷ 2 = 3 pens per notebook.
*Answer.* She gives up 3 pens for each extra notebook.
*Check.* Three pens for each of two notebooks is 6 pens, which agrees with the fall we measured.

> The rate falls at every step along the curve.

Apply the same steps to each neighbouring pair in the table. The rates are 6, 3, 1.5 and 0.75. The rate falls at every step. The reason lies in the student's own wishes. When she has many pens and few notebooks, a notebook is precious to her and a pen is cheap, so she will give up many pens for one notebook. When pens are few and notebooks many, each pen is precious, so she gives up only a few. This falling rate is why an indifference curve bends in towards the corner of the axes: the curve grows flatter as we move to the right.

> At one combination, the rate is the steepness of the curve there.

So far we measured the rate over a step. At a single combination, the economist measures it for a very small step, and the result equals the steepness of the curve at that point. At combination C the steepness is 2, which lies between the rate 3 on its left and the rate 1.5 on its right. This is the value that appears in the case of section 7.4. Common slips are easy to make here: dividing in the wrong order, putting the goods on the wrong axes, and forgetting to say "pens per notebook".

:pause 7.p2 | Along an indifference curve the student holds more notebooks and fewer pens. Why does she give up fewer pens for each extra notebook?

> Recap of section 7.2.

*Before moving on.* The marginal rate of substitution is the number of pens a consumer gives up for one more notebook, with satisfaction unchanged. It falls along a curve, which is why the curve bends inwards. *You should now be able to say* how to compute the rate between two combinations on one curve.

## The Budget Line

> A fixed sum of money limits what any shopper can buy.

Taste is only half the story. Return to the stall with Tk 100. Suppose mangoes cost Tk 20 each and guavas cost Tk 10 each. Spending all the money on mangoes buys 5. Spending it all on guavas buys 10. Three mangoes and 4 guavas cost Tk 60 and Tk 40, which is Tk 100 again. Each of these combinations is affordable, and together they follow a pattern that we can draw.

@ Budget line | A line showing every combination of two goods that a consumer can buy with a given income at given prices.
@ Line | Word in use. In daily life, a queue of people or a mark made with a pen. On a graph, a path of points; the budget line is straight, while an indifference curve bends.

> A budget line shows every combination that the money can buy.

A **budget line** is a line showing every combination of two goods that a consumer can buy with a given income at given prices. At the stall, the points for 5 mangoes, 10 guavas, and 3 mangoes with 4 guavas all lie on one budget line. Points inside the line are affordable but leave some money unspent. Points beyond the line cost more than the shopper has. The word *line* here means a path of points on a graph, and this one is straight.

> The case file gives the student's income and the two prices.

:case Case file, illustrative. A student has Tk 400 to spend on notebooks at Tk 40 each and pens at Tk 20 each. The most that can be bought is 10 notebooks or 20 pens.

> A worked example finds both ends of the line and its steepness.

*Given.* Income Tk 400; notebook price Tk 40; pen price Tk 20.
*Find.* The most of each good, and the pens given up for each extra notebook.
*Formula.* In words: the most of a good is income divided by its price; the pens given up for one notebook are the notebook price divided by the pen price. In symbols: M = I ÷ P, where M is the most of a good, I is income and P is that good's price; price ratio = notebook price ÷ pen price.
*Steps.* Notebooks: Tk 400 ÷ Tk 40 = 10. Pens: Tk 400 ÷ Tk 20 = 20. Price ratio: Tk 40 ÷ Tk 20 = 2 pens per notebook.
*Answer.* She can buy at most 10 notebooks or 20 pens, and each extra notebook costs her 2 pens.
*Check.* Ten notebooks cost 10 × Tk 40 = Tk 400, and 20 pens cost 20 × Tk 20 = Tk 400.

> The line is straight and its steepness is the price ratio.

To draw the line, mark 10 on the axis of notebooks and 20 on the axis of pens, and join the marks with a ruler. Each point on the line is a combination that uses exactly Tk 400. The line is straight because, at fixed prices, each extra notebook always costs the same 2 pens. Its steepness is the price ratio, 2. Compare this with the curve: the curve bends because her wishes change as her holdings change, while the line is straight because prices stay fixed.

> Income shifts the line sideways; a price change turns it.

Two changes alter the line. If income rises and prices stay the same, the whole line shifts outwards, parallel to the old one, because the price ratio is unchanged: with Tk 600 she could buy 15 notebooks or 30 pens. If one price changes, the line turns around the point on the axis of the other good. If pens fell to Tk 10, she could still buy only 10 notebooks, but now 40 pens, so the line turns outwards around the notebook point and becomes steeper.

> Recap of section 7.3.

*Before moving on.* The budget line shows every combination that a given income buys at given prices. Its ends are income divided by each price, and its steepness is the price ratio. A rise in income shifts it; a price change turns it. *You should now be able to say* where the line meets each axis and why it is straight.

## Consumer Equilibrium

> Both pictures on one graph show the best affordable combination.

We now hold two pictures. A map of curves shows what the student wants, and a budget line shows what she can afford. Draw both on one graph. Her aim is to reach the highest curve possible, and the budget line stops her from reaching any curve that lies beyond it. So the question becomes: which is the highest curve that still touches the budget line?

@ Consumer equilibrium | The point where a consumer gets the greatest satisfaction possible from a given income.

> Consumer equilibrium is the best affordable combination.

**Consumer equilibrium** is the point where a consumer gets the greatest satisfaction possible from a given income. The word *equilibrium* means a state of balance: once the consumer is there, she has no wish to change. For the student, it is the combination on the budget line that lies on the highest reachable curve.

> The best point is where one curve touches the line and does not cross it.

In the figure below, the straight falling line is the budget line, and the two bent lines are indifference curves. The higher curve never meets the budget line, so the student cannot reach it. The lower curve crosses the line at two points, P and Q, and between them the line runs through combinations that lie on higher curves, so she can do better by moving. The best curve is the one that touches the line at a single point, marked B, without crossing. At B the curve and the line have the same steepness.

:fig The budget line, a curve that crosses it, and the curve that touches it at the best combination | ch07-fig02.svg

> At the best point, the rate she accepts equals the rate the market asks.

The steepness of the curve is the marginal rate of substitution, and the steepness of the line is the price ratio. At the touching point the two are equal. The rule has a plain meaning. The curve's steepness says how many pens she would give up for one more notebook. The line's steepness says how many pens she must give up. If the first is larger, a notebook is worth more to her than it costs, so she buys more notebooks; her willingness to pay, measured in pens, exceeds the price.^3 If the first is smaller, she buys fewer. She stops only when the two are equal.

^3: Recall: willingness to pay and consumers' surplus, Chapter 6, 'Consumption and Consumers' Surplus', section 6.2 'Consumers' Surplus'.

:box IN SHORT
At consumer equilibrium the marginal rate of substitution equals the price ratio, and the combination lies on the budget line.

> The rule has exceptions, so check its conditions.

The rule needs care. If the student would rather spend everything on one good, the best point lies on an axis, and the two steepnesses need not be equal. The rule also assumes that all income is spent and that the curves bend in as described in section 7.1. This chapter treats only the usual case, in which both goods are bought.

> Recap of section 7.4.

*Before moving on.* Consumer equilibrium is the point on the budget line that lies on the highest reachable curve. There the curve touches the line, and the marginal rate of substitution equals the price ratio. *You should now be able to say* why a combination on a crossing curve is not the best.

## A Worked Case: The Student's Best Combination

> The case file states the student's best combination.

:case Case file, illustrative. A student has Tk 400 for notebooks at Tk 40 and pens at Tk 20. The most that can be bought is 10 notebooks or 20 pens. The best bundle is 6 notebooks and 8 pens (Tk 240 + Tk 160 = Tk 400), where the marginal rate of substitution is 2, equal to the price ratio 40 / 20 = 2.

> We test the case file's claim step by step.

*Given.* Income Tk 400; notebooks Tk 40; pens Tk 20; the curve table of section 7.1; the claimed best combination of 6 notebooks and 8 pens.
*Find.* Whether this combination is the best the student can afford.
*Formula.* In words: spending equals notebooks times their price plus pens times their price; the best combination has its rate equal to the price ratio. In symbols: S = (N × Tk 40) + (K × Tk 20), where S is spending, N is notebooks and K is pens.

> The steps check spending, steepness and the two nearest affordable neighbours.

*Steps.* (1) Spending: S = (6 × 40) + (8 × 20) = 240 + 160 = Tk 400, so the combination lies on the budget line. (2) Price ratio: 40 ÷ 20 = 2. (3) The rate at 6 notebooks and 8 pens is 2, as section 7.2 found. (4) The rate equals the price ratio, so the curve touches the line. (5) Test neighbours on the line. P is 4 notebooks and 12 pens: 160 + 240 = Tk 400. The table says 4 notebooks with 14 pens is equally good as the claimed combination, and P has 2 pens fewer, so P is worse. Q is 8 notebooks and 4 pens: 320 + 80 = Tk 400. The table says 8 notebooks with 5 pens is equally good, and Q has 1 pen fewer, so Q is worse.
*Answer.* Yes: 6 notebooks and 8 pens is the best combination she can afford.
*Check.* A better combination, 6 notebooks and 14 pens, costs 240 + 280 = Tk 520, which is more than Tk 400, so she cannot buy it.

> A second example uses less tidy numbers.

*Given.* Income Tk 540; notebooks Tk 60; pens Tk 45. *Find.* The ends of the budget line and its steepness. *Formula.* The most of a good is income divided by its price; steepness is the notebook price divided by the pen price. *Steps.* Notebooks: 540 ÷ 60 = 9. Pens: 540 ÷ 45 = 12. Steepness: 60 ÷ 45 = 1.33 pens per notebook. *Answer.* At most 9 notebooks or 12 pens, with 1.33 pens given up per notebook. *Check.* 9 × 60 = Tk 540 and 12 × 45 = Tk 540.

> Four common slips spoil these calculations.

Common slips deserve a warning. Some students divide income by the wrong price, which swaps the two ends of the line. Some put the pen price on top of the price ratio, which turns the steepness upside down. Some forget the units, so that 1.33 loses its meaning of pens per notebook. Others test only one neighbour and declare a winner; test both sides of the touching point.

> Recap of the worked case.

*Before moving on.* To find the best combination, compute the ends of the budget line, find the price ratio, locate the point where the rate equals it, and test the neighbours. *You should now be able to say* how each of the five steps supports the answer.

* * *

## Summary

> The chapter's tools fit together in four steps.

An indifference curve joins combinations that please a consumer equally, and a map of such curves ranks every combination. The marginal rate of substitution measures the pens she will swap for one more notebook, and it falls along a curve. The budget line shows what her income buys at given prices, and its steepness is the price ratio. Consumer equilibrium is where the budget line touches the highest curve it can reach; there the rate equals the price ratio.

## Think It Through

:q 7.t1 | Income is Tk 400, notebooks cost Tk 40, and pens fall in price from Tk 20 to Tk 10. Show that the student can still afford 6 notebooks and 8 pens. What does that tell you about her satisfaction after the price fall?
:q 7.t2 | Explain why two indifference curves cannot cross. Use the idea that the consumer prefers more of a good to less.

## Where People Go Wrong

> Indifferent does not mean uninterested.

Some students think that being indifferent means not caring. The student cares a great deal. She is indifferent only between combinations on the same curve, and she strongly prefers any combination on a higher curve to one on a lower curve.

> The curve shows taste, not what she can afford.

Some students read an indifference curve as a list of what the consumer can buy. It is not. The curve says nothing about money. Only the budget line shows affordability, and a point on a curve may cost more than her income.

> The rate and the price ratio are different things.

Some students treat the marginal rate of substitution and the price ratio as one idea. The first comes from her wishes and changes along a curve. The second comes from the market and stays fixed along a budget line. They are equal only at consumer equilibrium.

> The best combination is not the cheapest or the most equal.

Some students expect the best combination to hold equal numbers of the two goods, or to cost the least. The best combination is the one on the highest reachable curve. For the student it is 6 notebooks and 8 pens, which are not equal numbers.

## In History

> Indifference curves were drawn before 1934.

The curves in this chapter are older than the 1930s. Francis Edgeworth, an economist who taught at Oxford, drew the first indifference curves in his book *Mathematical Psychics* in 1881. The Italian economist Vilfredo Pareto used them again in his *Manuale di economia politica* in the early 1900s, and he stressed that a theory of choice needs only the comparison of combinations.

> In 1934 Hicks and Allen rebuilt consumer theory on the curves.

In 1934 two economists at the London School of Economics, John Hicks and R. G. D. Allen, published *A Reconsideration of the Theory of Value*. It appeared in two parts in the journal *Economica*, in February and May 1934. They credited Pareto as their inspiration and rebuilt the theory of consumer choice on indifference curves, so that the argument no longer needed satisfaction to be counted in numbers. The budget line, the marginal rate of substitution and the tangency rule of this chapter are the core of that theory, and the method is still the usual way to teach consumer choice.

## Review Questions

:q 7.1 | A student has Tk 200. Notebooks cost Tk 40 and pens cost Tk 20. Find the most of each good she can buy, and name two other combinations on her budget line.
:q 7.2 | From combination C (6 notebooks, 8 pens) the student moves to combination D (8 notebooks, 5 pens) and stays equally satisfied. Find the marginal rate of substitution over this step. Is it larger or smaller than the rate of 3 from B to C, and why?
:q 7.3 | Income is Tk 450, notebooks cost Tk 50 and pens cost Tk 30. Find where the budget line meets each axis, and its steepness.
:q 7.4 | Income is Tk 400 and pens cost Tk 20. The price of a notebook rises from Tk 40 to Tk 50. Find the new ends of the budget line and say how the line moves.
:q 7.5 | Notebooks cost Tk 40 and pens Tk 20. At 4 notebooks and 12 pens, which lie on her budget line, her marginal rate of substitution is 4. Is she at consumer equilibrium? If not, which good should she buy more of?
:q 7.6 | At 6 notebooks and 8 pens her marginal rate of substitution is 2 pens per notebook, and a pen costs Tk 20. Find in taka the most she would pay for one more notebook. Compare it with the price of Tk 40 and say what this shows about consumers' surplus on that notebook.

:read J. R. Hicks and R. G. D. Allen, A Reconsideration of the Theory of Value, 1934
:read J. R. Hicks, Value and Capital, 1939
