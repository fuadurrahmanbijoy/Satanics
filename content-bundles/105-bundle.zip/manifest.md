:bundle
status: ok
failures: 0
chapters: 18
appendix: none
changed-duplicates-resolved: 0
glossary-duplicates-removed: 0
chapter | ch01 | I | Money, Finance and the Firm | 3208 | 1 | 12 | 12
chapter | ch02 | II | The Financial Manager's Work | 3097 | 1 | 11 | 12
chapter | ch03 | III | The Goal of the Firm and Agency | 3717 | 1 | 8 | 8
chapter | ch04 | IV | The Time Value of Money: Single Sums | 4337 | 2 | 13 | 9
chapter | ch05 | V | Annuities | 4027 | 2 | 7 | 10
chapter | ch06 | VI | Uneven Cash Flows | 3110 | 1 | 2 | 8
chapter | ch07 | VII | Capital Budgeting: Decisions and Cash Flows | 3677 | 1 | 10 | 9
chapter | ch08 | VIII | Capital Budgeting: Evaluation Techniques | 2894 | 2 | 5 | 11
chapter | ch09 | IX | Return and Risk | 3503 | 2 | 10 | 7
chapter | ch10 | X | Risk, Required Return and Market Efficiency | 3623 | 2 | 13 | 8
chapter | ch11 | XI | Operating Leverage and Break-even Analysis | 3313 | 2 | 6 | 9
chapter | ch12 | XII | Financial and Total Leverage | 3252 | 1 | 7 | 7
chapter | ch13 | XIII | Valuing Bonds | 3774 | 2 | 9 | 9
chapter | ch14 | XIV | Valuing Common and Preferred Stock | 3078 | 1 | 4 | 9
chapter | ch15 | XV | Working Capital and the Cash Cycle | 3682 | 2 | 10 | 7
chapter | ch16 | XVI | Short-Term Financing and Matching | 3249 | 1 | 10 | 10
chapter | ch17 | XVII | Long-Term Financing and the Cost of Capital | 3630 | 1 | 9 | 8
chapter | ch18 | XVIII | Leasing | 2967 | 1 | 7 | 8
