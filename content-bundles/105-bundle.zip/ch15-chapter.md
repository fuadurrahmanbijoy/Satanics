:chapter XV | Working Capital and the Cash Cycle
:mood How can a business that sells well still have no money to pay its bills?
:desc This chapter follows the money a business holds in goods and in customers' promises to pay. It measures the delay in days, shows what a slow cheque costs, and teaches you to estimate the cash a business must keep working.
:plate ch15-plate.svg | A warehouse, a clerk with a tally board and a loaded cart at the door

> A good year of sales and a record profit, yet an empty cash drawer: how can all three be true?
> You will need: Chapter 2, 'The Financial Manager's Work', section 2.3 'How Finance Shapes Business Success'; Chapter 1, 'Money, Finance and the Firm', section 1.3 'Where Funds Come From and Where They Go'.

Imagine a bookshop that has had its best year. Sales rose in every month, and the profit is the largest in the history of the business. On the last evening of the year, the owner opens the cash drawer. It is almost empty. A supplier's bill falls due on Monday, and the staff must be paid on Thursday. The owner has a profit but no money. How can both be true?

> The answer lies in time: the shop paid before it was paid.

The answer is not found in the sales. It is found in time. The shop paid for its books before it sold them. It then sold many of them to schools on credit, which means the schools promised to pay later. Between paying and being paid, the shop's money lay in two places where it could not be spent. Some lay on the shelves, in the form of books. The rest lay in the promises of customers. The profit was real, but it was not yet cash.

> This chapter names the gap, measures it in days, and estimates the money needed to cross it.

This gap between paying out and collecting is the subject of this chapter. It matters to every financial manager, because many businesses have failed for lack of cash while their sales were strong. We shall name the parts of the gap and measure it in days. We shall learn why even a cheque needs days to become money that can be used. Then we shall estimate how much money a business must hold to cross the gap. We begin with a market stall, because the idea is the same at any size.

* * *

## 15.1 What Working Capital Is

> A rice stall, with small numbers, shows the idea before any new word appears.
@! Go slowly here.

Before any new word, take the smallest picture we can find. A woman keeps a rice stall in a market. On Monday morning she buys ten sacks of rice from a wholesaler at Tk 1,000 a sack, Tk 10,000 in all. The wholesaler trusts her and lets her pay on Friday. By Wednesday evening she has sold six sacks at Tk 1,200 each. A tea stall and a canteen took Tk 1,500 of that rice on credit, which means they will pay next week. The rest was paid in cash, and the cash is in her tin. Four sacks remain on the stall.

> The table lists what she holds and what she owes on Wednesday evening.

Let us list what she holds and what she owes at that moment. Each row is one item and its value in taka. The first three rows are what she holds, and the fourth row adds them. The fifth row is what she owes. The last row is the difference.

:table Wednesday evening at the rice stall
| Item | Tk |
| Cash in the tin | 5,700 |
| Four sacks of rice, valued at cost | 4,000 |
| Owed to her by the tea stall and the canteen | 1,500 |
| Total she holds | 11,200 |
| Owed to the wholesaler | 10,000 |
| Total held minus total owed | 1,200 |

> Working capital is the money a business keeps in the short-term things it uses to trade every day.
@ Working capital | the money a business has tied up in short-term assets such as stock and money owed by customers
@ Stock | Word in use. In daily life and in a shop, the goods on the shelves. In finance, also a share in a business, as in common stock. This book calls goods inventory.

The cash, the rice and the customers' promises are what the woman uses to trade from day to day. Finance gives the money held in them a name. **Working capital** means the money a business has tied up in short-term assets such as stock and money owed by customers. "Tied up" means held in a form that cannot be spent at once. Her Tk 4,000 of rice cannot pay a bill until it is sold. The word *working* is used because this money keeps moving: from cash into goods, from goods into customers' promises, and back into cash.

> A current asset is an owned item expected to become cash within about a year.
> Recall: asset and liability, Chapter 1, section 1.3 'Where Funds Come From and Where They Go'.
@ Current | Word in use. In daily life, happening now, as in current news. In finance, due or expected within about a year, as in current asset.
@ Current asset | an asset expected to turn into cash within about a year

Which assets belong in working capital? The short-term ones. A **current asset** is an asset expected to turn into cash within about a year. Her cash is already cash. Her rice will become cash when it is sold. The tea stall's promise will become cash when the tea stall pays. Her cart, which she will use for many years, is not a current asset.

> A current liability is an amount owed that must be paid within about a year.
@ Current liability | an amount owed that must be paid within about a year

The other side of the table is what she owes. A **current liability** is an amount owed that must be paid within about a year. The Tk 10,000 she owes the wholesaler is one, because it falls due on Friday. A loan that she may repay over five years is not.

> Inventory is the goods a business holds, either to sell or to turn into other goods.
@ Inventory | goods held for sale or for use in making goods

The four sacks on her stall are her **inventory**. Inventory means goods held for sale or for use in making goods. The books on a bookshop's shelves are inventory. So are the cloth a tailor holds and the flour a baker holds before baking. Shopkeepers often say stock for the same thing. This book says inventory, and keeps the word stock for shares in a business, as in common stock.

> Accounts receivable is what customers owe the business for goods taken on credit.
@ Account | Word in use. In daily life, a record of money kept at a bank. In accounting, a named record of one kind of item, such as the money owed by one customer.
@ Accounts receivable | money owed to a business by customers who bought on credit

The Tk 1,500 owed by the tea stall and the canteen is called **accounts receivable**. Accounts receivable is money owed to a business by customers who bought on credit. *Credit* here means permission to pay later. *Receivable* means "able to be received". A school that takes books in March and pays in April creates accounts receivable for a bookshop.

> Accounts payable is what the business owes its suppliers for goods taken on credit.
@ Accounts payable | money a business owes to suppliers for goods bought on credit

The mirror image is the Tk 10,000 owed to the wholesaler. **Accounts payable** is money a business owes to suppliers for goods bought on credit. *Payable* means "to be paid". The same debt appears on both sides of a trade. The wholesaler counts the Tk 10,000 as accounts receivable, and the stallholder counts it as accounts payable.

> Net working capital is the short-term assets left after the short-term debts are subtracted.
@ Net working capital | current assets minus current liabilities

Look again at the last row of the table. Tk 11,200 held and Tk 10,000 owed leaves Tk 1,200. This is the stall's net working capital. **Net working capital** is current assets minus current liabilities. Here, Tk 11,200 − Tk 10,000 = Tk 1,200. If she owed more than she held in current assets, the answer would be negative. That would warn her that she could not pay her short-term debts from her short-term assets.

> The case file gives the trading days and the yearly amounts for Meghna and Sons Limited.

:case Case file, illustrative. Meghna and Sons Limited, 1 September 2025 (figures for the 12 months to 31 August 2025). Sales were Tk 9,000,000. Cost of sales was Tk 6,300,000. Inventory was held for 75 days. Customers (school accounts) paid in 20 days. Suppliers were paid in 45 days.

> Cost of sales is what the goods sold in the year cost the business to buy.

*Cost of sales* is the price the business paid for the goods it sold in the year. We use it here only as a measure. The shop's inventory and its accounts payable are valued at cost, so we compare them with cost of sales and not with sales.

> A current asset is only a hope of cash, so a large working capital does not make payment certain.
> Recall: liquidity, Chapter 2, section 2.3 'How Finance Shapes Business Success'.

Working capital has limits. A current asset is a hope of cash, not cash. Rice may not sell. A customer may pay late, or not at all. So a high net working capital does not guarantee that bills can be paid on Monday, if most of it is unsold goods. This is a question of liquidity, which you met in Chapter 2.

> Owner, supplier and financial manager each look at working capital differently.

The owner sees working capital as money that cannot be taken out of the business. The supplier sees it as a sign that the business can pay its bills. The financial manager asks two questions: is the amount enough to keep trading, and is it larger than it needs to be?

> Recap: working capital is short-term money; net working capital is what is left after short-term debts.

*Before moving on.* Working capital is the money a business holds in short-term assets. Current assets turn into cash within about a year, and current liabilities fall due within about a year. Net working capital is the difference. Inventory, accounts receivable and accounts payable are the three items we follow in the next section. *You should now be able to say* how the stall's net working capital is found, and why it is Tk 1,200.

* * *

## 15.2 The Cash Conversion Cycle

> Follow one parcel of goods from arrival to cash, counting the days.
@! Go slowly here.

Follow one parcel of books through Meghna and Sons. On day 0 the books arrive from the supplier. They stand on the shelves for some time. Then a school buys them on credit, and some days later the school pays. Each stage takes days, and we can count them. In the case file, the books stand for 75 days, and the school takes 20 days to pay.

> The operating cycle is the time from buying goods to receiving the customer's cash.
@ Operating cycle | the days from buying stock to collecting cash from the customer

The time from the day the goods arrive to the day the customer's cash is collected has a name. The **operating cycle** is the days from buying stock to collecting cash from the customer. It has two parts. The inventory days are the days the goods wait for a buyer. The receivable days are the days a customer takes to pay. In words: operating cycle = inventory days + receivable days. For the shop, 75 + 20 = 95 days.

:pause 15.p1 | A business holds its goods for 40 days before they are sold, and its customers pay in 15 days. How long is its operating cycle?

> The shop did not pay its supplier on day 0, so the supplier's money was in the goods for a time.

But the shop did not pay the supplier on day 0. It paid on day 45. For those 45 days the supplier's money, not the shop's own, was in the goods. The operating cycle leaves this out. The shop must find its own money only after day 45, and it needs that money until the customer pays on day 95. That gap lasts 95 − 45 = 50 days.

> The cash conversion cycle counts only the days the business must supply its own money.
@ Cash conversion cycle | the operating cycle minus the days a business takes to pay its suppliers

The gap has a name. The **cash conversion cycle** is the operating cycle minus the days a business takes to pay its suppliers. In symbols: C = I + R − P. Here C is the cash conversion cycle, I the inventory days, R the receivable days and P the payable days, which are the days the business takes to pay its suppliers. For the shop, 75 + 20 − 45 = 50 days. Read it this way: for 50 days the shop has paid for goods and has not yet been paid by its customers.

:box IN SHORT
Cash conversion cycle = inventory days + receivable days − payable days. A shorter cycle means the business needs less of its own money.

> The figure shows the three delays on one timeline and the gap that is the cash conversion cycle.

The figure below is a timeline, and you read it from left to right. Each unit along the line is one day. Day 0 is the day the goods arrive, and day 95 is the day the cash arrives. The bracket at the top is the operating cycle. The three lower bars show inventory days, receivable days and payable days, and each bar starts and ends above the day marked beneath it. The outlined bar at the bottom is the gap, the cash conversion cycle.

:fig Timeline of the cash conversion cycle for Meghna and Sons Limited | ch15-fig01.svg

:pause 15.p2 | A business has an operating cycle of 70 days and pays its suppliers after 30 days. What is its cash conversion cycle?

> The cycle is an average, and it can be short, long, or even below zero.

Three limits matter. First, the days are averages. A shop sells many products, and each has its own days. Second, a business that is paid at the till has no receivable days. A grocer who is paid in cash and pays suppliers after 30 days can have a cash conversion cycle below zero. This means customers' money arrives before the suppliers are paid. Third, a long wait for suppliers is not free. A supplier who is paid late may charge more, or may stop deliveries.

> The financial manager can shorten the cycle by holding less inventory or collecting sooner.

The financial manager therefore has three levers. Hold less inventory. Collect from customers sooner. Pay suppliers later, but fairly. A faster collection cuts the receivable days, so the operating cycle and the cash conversion cycle both shrink by the same number of days. A customer, by contrast, prefers more days to pay. Each party's interest is different.

> Recap: the cycle is inventory days plus receivable days, less payable days.

*Before moving on.* The operating cycle is inventory days plus receivable days. The cash conversion cycle subtracts the payable days. For Meghna and Sons they are 95 days and 50 days. *You should now be able to say* why the supplier's 45 days reduce the shop's need for its own money.

* * *

## 15.3 Float

> A cheque takes days to become usable money, and the delay has a cost.

Start with one cheque. A customer of Meghna and Sons pays a large bill by cheque. The customer has paid, but can the shop spend the money that same day? It cannot. The case file records what happened.

> The case file records the three delays one cheque met before the shop could use its money.

:case Case file, illustrative. Meghna and Sons Limited. On 3 February 2025 a customer posted a cheque for Tk 200,000. Mail took 2 days, processing took 1 day and clearing took 3 days. Total float was 6 days. Money unused at 10% a year costs 200,000 × 0.10 × 6/365 = Tk 329.

> Float is money paid by one person that the receiver cannot yet use.
@ Float | money that has been paid by one person but cannot yet be used by the receiver

While the cheque travelled, the customer had paid but the shop could not use the money. That delay has a name. **Float** is money that has been paid by one person but cannot yet be used by the receiver. It has three parts. Mail float is the days the cheque spends travelling to the receiver. Processing float is the days the receiver takes to record the cheque and pay it into a bank. Clearing float is the days the banks take to move the money from the payer's account to the receiver's. For the shop, 2 + 1 + 3 = 6 days.

> The figure places the three parts of float on one timeline, from posting to usable money.

The next figure is a second timeline. Read it from left to right. Each unit is one day. Day 0 is the day of posting, and day 6 is the day the money can be used. Each bar is one part of float, and the line below it shows the total.

:fig Timeline of one cheque, from posting to usable money | ch15-fig02.svg

> The cost of float is the amount, times the interest rate, times the days lost, divided by 365.

Money that cannot be used has a cost, because it could have reduced a loan or earned a return. In words: cost of float = amount × yearly interest rate × days of float ÷ 365. Here, Tk 200,000 × 0.10 × 6 ÷ 365 = Tk 329. The sum is small for one cheque. A business that receives hundreds of cheques loses much more. Float can also help the payer, who keeps the use of the money until the cheque clears. What the payer gains, the receiver loses.

> Float shrinks with faster payment methods, and its days differ by bank and country.

These days are the case file's illustration. The time a cheque needs depends on the banks and the country, and payment by electronic transfer can remove most of it.

> Recap: float is paid money that cannot yet be used, in three parts.

*Before moving on.* Float is money paid by one person that the receiver cannot yet use. Its parts are mail, processing and clearing. Each day of float costs the receiver the use of the money.

* * *

## 15.4 Estimating Working Capital Needs

> The days can be turned into taka to show how much money the cycle needs.

How much money does the cycle hold? Knowing that it lasts 50 days is not enough, because a manager must know how many taka to find. We turn each of the three items into taka. The idea is simple to state. One day of trading carries a certain amount, and the item holds that many days of it.

> Each item equals one day's amount multiplied by the days it is held.

There are three rules, each using a 365-day year.^1 Inventory is held at cost, so inventory = cost of sales × inventory days ÷ 365. Accounts receivable is what customers owe at the selling price, so receivables = sales × receivable days ÷ 365. Accounts payable is owed at cost, so payables = cost of sales × payable days ÷ 365. The net investment in the cycle is inventory + receivables − payables.

^1: Some businesses use a 360-day year to make the arithmetic easier. This book uses 365 days throughout.

> The case file gives the three amounts and the net investment for Meghna and Sons.

:case Case file, illustrative. Meghna and Sons Limited, 1 September 2025. Using a 365-day year, inventory was Tk 1,294,521, receivables (on sales) were Tk 493,151 and payables were Tk 776,712. The net investment in the cycle was Tk 1,010,959.

> The shop must find about Tk 1,010,959 of its own money, because its suppliers fund only part of the cycle.

So the shop must find about Tk 1,010,959 of its own money to keep the cycle turning. Its suppliers fund Tk 776,712 of the goods and the debts, and only for 45 days at a time. The full working is shown in section 15.5. How a business pays for this money is the work of Chapter 16, 'Short-Term Financing and Matching', section 16.4 'The Matching Principle'.

> The need grows in step with trading: more sales means more money in the cycle.

The need grows with trading. If sales and cost of sales rise by one fifth and the days stay the same, each of the three items rises by one fifth, and so does the net investment.

> The estimate uses averages and three items only, so it is a guide and not an exact budget.

Three cautions apply. The estimate uses yearly averages, so a busy season can need more than the average. It leaves out cash and the other current assets. And the days can change: a customer who pays later raises the need at once.

> Recap: turn each item into taka using days, then add inventory and receivables and subtract payables.

*Before moving on.* Inventory and payables use cost of sales, and receivables use sales. Multiply by the days and divide by 365. Add inventory and receivables, then subtract payables. For Meghna and Sons the answer is Tk 1,010,959.

* * *

## 15.5 Worked Examples: From Days to Taka

> Four examples apply the method, from small numbers to a combined problem.

We work four examples. The first uses small, round numbers, so the method is the only new thing. The second uses the case file. The third changes the situation, and the fourth combines the ideas of this chapter. Each follows one order: given, find, formula, steps, answer, check.

> Example 1 gives the data, the question and the formulas.

*Example 1: clean numbers.* *Given.* A small trader holds inventory for 30 days. Customers pay in 10 days, and suppliers are paid in 20 days. Yearly sales are Tk 365,000, and cost of sales is Tk 219,000. *Find.* The cash conversion cycle and the net investment in the cycle. *Formula.* Cash conversion cycle = inventory days + receivable days − payable days. Net investment = (cost of sales × inventory days ÷ 365) + (sales × receivable days ÷ 365) − (cost of sales × payable days ÷ 365).

> The steps take each item in turn and then combine them.

*Steps.* Cycle: 30 + 10 − 20 = 20 days. Inventory: 219,000 × 30 ÷ 365 = Tk 18,000. Receivables: 365,000 × 10 ÷ 365 = Tk 10,000. Payables: 219,000 × 20 ÷ 365 = Tk 12,000. Net investment: 18,000 + 10,000 − 12,000 = Tk 16,000.

> The answer is 20 days and Tk 16,000, and the check explains the Tk 4,000 above cost.

*Answer.* The cycle is 20 days, and the trader needs Tk 16,000 of its own money in it. *Check.* Cost of sales is Tk 600 a day, and 20 days at that rate is Tk 12,000. The answer is Tk 4,000 higher because receivables are valued at the selling price: 10 days × (Tk 1,000 − Tk 600) = Tk 4,000.

> Example 2 repeats the method with the case file figures.

*Example 2: realistic numbers.* *Given.* Sales Tk 9,000,000 and cost of sales Tk 6,300,000. Inventory is held 75 days, customers pay in 20 days and suppliers are paid in 45 days. *Find.* The same two answers. *Formula.* The same as in Example 1.

> The steps carry two decimal places and round only at the end.

*Steps.* Cycle: 75 + 20 − 45 = 50 days. Inventory: 6,300,000 × 75 ÷ 365 = 472,500,000 ÷ 365 = Tk 1,294,520.55. Receivables: 9,000,000 × 20 ÷ 365 = 180,000,000 ÷ 365 = Tk 493,150.68. Payables: 6,300,000 × 45 ÷ 365 = 283,500,000 ÷ 365 = Tk 776,712.33. Net investment: 1,294,520.55 + 493,150.68 − 776,712.33 = Tk 1,010,958.90, which rounds to Tk 1,010,959.^2

^2: Each amount is rounded to the nearest taka in the case file. Adding the rounded parts gives Tk 1,010,960. The unrounded total rounds to Tk 1,010,959, and that is the figure we use.

> The cycle is 50 days and the net investment is Tk 1,010,959, which passes a reasonableness check.

*Answer.* The cycle is 50 days, and the shop needs Tk 1,010,959 of its own money in it. *Check.* Fifty days of cost of sales is about Tk 863,014. The answer is higher because receivables are counted at the selling price, which includes the shop's profit.

> Four slips cause most wrong answers in this kind of problem.

Common slips are these. Using sales where cost of sales belongs, for inventory and payables. Forgetting to divide by 365. Adding payables instead of subtracting them. Mixing periods, such as months for one item and days for another. Write the units beside every number, and check the sign of each line.

> Example 3 changes the situation: the suppliers ask to be paid sooner.

*Example 3: a reshaped case.* This is an exercise built on the case file, not part of it. *Given.* Suppose the suppliers of Meghna and Sons shorten the payment time from 45 days to 30 days. All other figures stay as in Example 2. *Find.* The new cycle and the extra money needed. *Formula.* The same as before.

> The steps change only the payables and compare the new need with the old.

*Steps.* New cycle: 75 + 20 − 30 = 65 days. New payables: 6,300,000 × 30 ÷ 365 = 189,000,000 ÷ 365 = Tk 517,808.22. New net investment: 1,294,520.55 + 493,150.68 − 517,808.22 = Tk 1,269,863.01, which rounds to Tk 1,269,863. Extra money: 1,269,863 − 1,010,959 = Tk 258,904.

> The cycle grows by 15 days and the need by Tk 258,904, as the check confirms.

*Answer.* The cycle lengthens by 15 days to 65 days, and the shop must find Tk 258,904 more. *Check.* One day of cost of sales is about Tk 17,260. Fifteen days × Tk 17,260 is about Tk 258,900, which agrees.

> Example 4 combines the cash needed with the cost of float.

*Example 4: a combined problem.* *Given.* The case file figures. Suppose every sale of the year is paid by cheque, and each cheque has the 6 days of float found in section 15.3. The interest rate is 10% a year. *Find.* The money held in float on average, its yearly cost, and the total need. *Formula.* Money in float = sales × float days ÷ 365. Yearly cost = money in float × interest rate. Total need = net investment + money in float.

> The steps find the float, price it, and add it to the net investment.

*Steps.* Money in float: 9,000,000 × 6 ÷ 365 = 54,000,000 ÷ 365 = Tk 147,945.21. Yearly cost: 147,945.21 × 0.10 = Tk 14,794.52. Total need: 1,010,958.90 + 147,945.21 = Tk 1,158,904.11.

> About Tk 147,945 is always in float, costing about Tk 14,795 a year.

*Answer.* About Tk 147,945 is always in float, which costs about Tk 14,795 a year. The total need is about Tk 1,158,904. *Check.* One cheque of Tk 200,000 costs Tk 329. Sales are 45 times larger, since 9,000,000 ÷ 200,000 = 45. Then 45 × 329 = Tk 14,805, close to the answer.

> Recap: the same method handles clean numbers, the case file, a changed case and a combined case.

*Before moving on.* The method never changed: days, then taka, then add and subtract. A change in one day count moves the need by that many days of the right amount. Float adds more days of money that cannot be used.

* * *

## Summary

> Working capital is money held in short-term assets, and the cash conversion cycle measures how long the business must fund it.

Working capital is money held in current assets such as inventory and accounts receivable. Net working capital is current assets minus current liabilities. The operating cycle is inventory days plus receivable days, and the cash conversion cycle subtracts the payable days. For Meghna and Sons the cycle is 50 days and the net investment is Tk 1,010,959. Float is money paid but not yet usable. For one cheque it lasted 6 days and cost Tk 329.

## Think It Through

:q 15.t1 | Meghna and Sons expects sales and cost of sales to rise by one fifth, with the days unchanged. Estimate the net investment in the cycle, and the extra money needed. Explain in plain words why the need rises.

## Where People Go Wrong

> A profit in the reports is not cash in the drawer.

*Wrong:* a business that makes a profit must have money. *Right:* profit is counted when goods are sold, but cash arrives only when customers pay. Money can sit in inventory and accounts receivable while bills fall due.

> A long cycle is not a failure; it is a need that must be funded.

*Wrong:* a long cash conversion cycle shows a badly run business. *Right:* some trades, such as selling books to schools, have long cycles. The danger is a long cycle with no plan to fund it.

> Paying suppliers later helps only while the supplier agrees to wait.

*Wrong:* the later a supplier is paid, the better. *Right:* more payable days shorten the cycle, but a supplier who is paid late may raise prices or stop deliveries.

> Float helps the payer and costs the receiver.

*Wrong:* float is the bank's problem. *Right:* the payer keeps the use of the money while the cheque travels, and the receiver loses it. The loss is measured in days and in interest.

## In History

> A large American retailer reported profits yet failed, because its cash was held in credit sales and inventory.

W. T. Grant was a chain of variety stores in the United States. William Thomas Grant opened the first of them in Lynn, Massachusetts, in 1906. By the 1970s the chain was large and national, and its reports still showed profit. In October 1975 it filed for reorganisation under Chapter 11 of the United States bankruptcy law, which lets a business keep trading while it tries to settle its debts. It was liquidated soon afterwards.

> Two authors later showed that the chain's operations had not produced cash for years.

In 1980 two authors, James Largay and Clyde Stickney, published a study of the failure in the *Financial Analysts Journal*. They found that for about ten years before the collapse the chain's operations had not produced cash. The money was tied up in credit sales and inventory, the same items you met in this chapter, until none was left to pay the bills. They argued that watching cash flows would have revealed the danger years before the usual ratios did. A profit in the reports does not pay a bill. Cash does.

## Review Questions

:q 15.1 | A business holds inventory for 60 days, its customers pay in 25 days and its suppliers are paid in 35 days. Find the operating cycle and the cash conversion cycle.
:q 15.2 | The business in question 15.1 has yearly sales of Tk 10,950,000 and cost of sales of Tk 7,300,000. Using a 365-day year, find the money it invests in the cycle.
:q 15.3 | A customer posts a cheque. Mail takes 3 days, processing takes 2 days and clearing takes 2 days. Name the three parts of float and find the days lost.
:q 15.4 | Explain in your own words why a faster collection from customers shortens the cash conversion cycle.

:read James A. Largay and Clyde P. Stickney, Cash Flows, Ratio Analysis and the W. T. Grant Company Bankruptcy, 1980
