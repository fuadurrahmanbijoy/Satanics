:chapter XVII | Long-Term Financing and the Cost of Capital
:mood Who lends money for five years, and what do they ask in return?
:desc This chapter surveys the long-term funds a business can raise: loans, owners' money and shares sold in the capital market. It names the institutions that supply them in Bangladesh and shows how to compute what the funds cost.
:plate ch17-plate.svg | A shipyard with an iron steamship half built on the slips

> A half-built ship needs money that stays for years, not weeks.
> You will need: Chapter 16, 'Short-Term Financing and Matching', section 16.1 'Financing by Time Span'; Chapter 13, 'Valuing Bonds', section 13.1 'What a Bond Is'; Chapter 14, 'Valuing Common and Preferred Stock', section 14.1 'Rights of Shareholders'.

In a shipyard, an iron steamship rests on the slips with half its hull still open to the sky. The builder has paid for iron, rivets and wages for many months, and the ship will earn nothing until it is launched, fitted and sailing. Suppose the builder had borrowed the money for ninety days. On day ninety the lender would ask for it back, and the half-built ship could be neither sold nor repaid. What kind of money does such a builder need?

> The answer is money that stays as long as the asset takes to pay for itself, and it has a price.

The answer is money that stays for as long as the ship takes to pay for itself: years, not weeks. This is long-term financing, and it is harder to find. The lender must trust the borrower for longer, and must be told what happens if things go wrong. The builder must also pay for it. Every lender and every owner who puts money in expects something back, and the sum of those expectations is a cost the business must earn.

> The chapter surveys the sources of long-term funds and then computes their combined cost.

This chapter has two parts. The first surveys where long-term money comes from: loans, owners' funds and shares sold to the public, with the institutions in Bangladesh that supply them. The second is one calculation, the cost of the whole mix of funds, which a business uses as the rate for judging its projects. Our case is Meghna and Sons Limited, which needs a machine for Project Press, the printing project you met in Chapter 8.

* * *

## 17.1 Term Loans and Debt Instruments

> A lender will wait five years if it is paid along the way and holds rights that protect it.

Why would a bank wait five years for its money? Because the borrower pays interest and returns part of the money along the way, and because the bank holds rights that protect it if payments stop. Those rights are the heart of long-term lending.

> A term loan is repaid in instalments over a fixed period longer than one year.
> Recall: term loans and debt, assumed from earlier chapters; time spans of financing, Chapter 16, section 16.1 'Financing by Time Span'.
@ Term | Word in use. In daily life, a period of time such as a school term. In lending, the length of time a loan runs before it is fully repaid.
@ Term loan | a loan repaid in instalments over a fixed period of more than one year

The commonest long-term debt is the **term loan**. A term loan is a loan repaid in instalments over a fixed period of more than one year. An *instalment* is one of the regular payments that together repay the loan. The agreed length of time is the term. Each instalment usually holds some interest and some repayment of the amount borrowed. Meghna and Sons plans to buy a press machine and asks a bank for a term loan.

> The case file records the new term loan and the two protections the bank asks for.

:case Case file, illustrative. Meghna and Sons Limited, 15 November 2025. A new term loan of Tk 600,000 over 5 years at 10% needs yearly instalments of Tk 158,278.49. Collateral: the machine. Covenant: owners' equity must stay above Tk 2,000,000.

> Collateral is an asset pledged to the lender, who may take it if the loan is not repaid.
@ Collateral | an asset a borrower pledges so the lender can take it if the loan is not repaid

A lender who waits five years wants a way out if the borrower fails. **Collateral** is an asset a borrower pledges so the lender can take it if the loan is not repaid. In the case file, the machine is the collateral. If the shop stopped paying, the bank could take the machine and sell it. Collateral lowers the lender's risk, and so it often lowers the interest rate.

> A covenant is a promise in the loan agreement that limits what the borrower may do.
@ Covenant | a promise in a loan agreement that limits what the borrower may do

The lender may also limit what the borrower does while the loan lasts. A **covenant** is a promise in a loan agreement that limits what the borrower may do. In the case file, owners' equity must stay above Tk 2,000,000. Other covenants may limit new borrowing or the profit paid out to owners. The reason is the same each time: money paid out, or lost, reduces the cushion that protects the lender. If a covenant is broken, the lender may ask for early repayment.

> The instalment is found by the payment method of Chapter 5, shown in section 17.6.

The instalment of Tk 158,278.49 comes from the payment method you learned in Chapter 5, 'Annuities'. Section 17.6 works it through in full.

> A debenture is a bond with no particular asset pledged, so its holder trusts the borrower's standing.
@ Debenture | a bond backed only by the general standing of the borrower, with no particular asset pledged

A business that wants money from many lenders issues bonds. Chapter 13, section 13.1 'What a Bond Is', describes them. Bonds differ in what backs them. A **debenture** is a bond backed only by the general standing of the borrower, with no particular asset pledged. A holder of a debenture trusts the business's record and its profit. A mortgage is different. It is a loan secured by a pledge of land or buildings, which is a particular kind of collateral. A debenture holder therefore carries more risk than a lender with collateral, and usually asks a higher interest rate.

:pause 17.p1 | A bank lends Tk 300,000 and takes a pledge over the borrower's shop building. Is this a debenture? Give a reason.

> Collateral and covenants lower the lender's risk, but they do not remove it, and debt must be repaid whatever the profit.

These protections have limits. A machine may sell for less than the debt. A covenant may stop a business from acting quickly. And debt must be repaid whether or not the business makes a profit, which is why too much of it is dangerous. The lender wants safety. The borrower wants freedom and a low cost. A loan agreement is the balance between the two.

> Recap: a term loan is repaid in instalments; collateral and covenants protect the lender; a debenture pledges nothing in particular.

*Before moving on.* A term loan runs for more than one year and is repaid in instalments. Collateral is an asset the lender may take. A covenant is a promise that limits the borrower. A debenture is a bond with no particular asset pledged.

* * *

## 17.2 Owners' Funds as Long-Term Finance

> Owners can supply long-term money by leaving profit in the business or by paying in new money.

Debt is not the only long-term money. Owners supply it too, in two ways. The first needs no new cash from anyone.

> Retained earnings are profit kept in the business, and the owners expect a return on it.
> Recall: retained earnings, assumed from earlier chapters.

Retained earnings are the profits a business keeps instead of paying them out. Each year, Meghna and Sons may keep part of its profit to buy inventory, fittings or machines. The money stays as long as the business needs it. It is convenient, but it is not free. The owners could have taken the money and used it elsewhere, so they expect the same return on it as on any other money they leave in. For that reason the case file counts retained earnings inside common equity.

> New common or preferred stock brings new money from owners who expect a return.
> Recall: rights of shareholders, Chapter 14, section 14.1 'Rights of Shareholders'.

The second way is to issue new stock. Common stock gives its owners a share in the profit that rises and falls with the business, and the right to vote. Preferred stock usually pays a fixed dividend and gives fewer voting rights. Neither has to be repaid on a fixed date, which is its great advantage over debt. A new issue of common stock also brings new owners, who share the profit and the votes of the old ones.

> The table compares four sources by repayment and by the return each one is paid.

The table compares four sources of long-term money. Read each row as one source. The second column asks whether the money must be repaid on a fixed date, and the third shows what the supplier is paid.

:table Four sources of long-term money
| Source | Repaid on a fixed date? | Return paid |
| Term loan | Yes, in instalments | Interest set by the agreement |
| Preferred stock | No | A fixed dividend (12% in the case file) |
| Common stock | No | Dividends that vary with profit |
| Retained earnings | No | None paid, but owners expect 14% |

> Owner money carries no repayment date, but it asks for a higher return and may share control.

Owners' funds have limits. They cost more than debt, because the owners take more risk. A new issue costs fees and may reduce the control of the existing owners. Seen from the lender's side, a thick layer of owners' funds is a comfort, which is why covenants such as the one in 17.1 protect equity.

> Recap: retained earnings and new stock are owner money, with no repayment date and a higher return.

*Before moving on.* Retained earnings are profit kept in the business. New common and preferred stock bring new owner money. None of these has a fixed repayment date, and all of them expect a return.

* * *

## 17.3 Raising Funds in the Capital Market

> A business that needs more than one bank or its owners can supply may sell securities to the public.

A bank loan comes from one lender. What if a business needs more money than a single bank will lend, and its present owners cannot supply more? It may offer shares or bonds to many people. For that it needs a place where such offers are made and later traded.

> The capital market is where long-term loans and shares are issued and traded.
> Recall: financial market, assumed from earlier chapters.
@ Capital | Word in use. In daily life, money or wealth, or the main city of a country. In finance, the long-term funds a business uses, as in cost of capital.
@ Capital market | the market where long-term loans and shares are issued and traded

That place is the **capital market**. The capital market is the market where long-term loans and shares are issued and traded. Securities are first sold there by the business that issues them. Later they may be traded between investors, who do not give any money to the business itself. A buyer who wishes to leave can sell to another buyer, and this makes people more willing to buy at the start.

> An initial public offering is the first sale of a business's shares to the general public.
@ Initial public offering | the first sale of a business shares to the general public

Suppose a printing business owned by one family decides to sell 30% of its shares to people it does not know. This is an **initial public offering**: the first sale of a business shares to the general public. After it, the shares are usually listed on a stock exchange, so that they can be bought and sold. A later offer to the public by a business already listed is called a public issue. Both bring in new owners and new money, and both are costly and carefully regulated.

> A rights issue offers new shares to existing shareholders in proportion to what they already hold.
@ Rights issue | an offer of new shares to existing shareholders in proportion to what they already hold

There is a quieter way to raise owners' money. A **rights issue** is an offer of new shares to existing shareholders in proportion to what they already hold. Take a business with 1,000 shares, of which one owner holds 100, or 10%. It offers 1 new share for every 5 held, so 200 new shares in all. The owner may buy 20 of them. Then the owner holds 120 of 1,200 shares, still 10%. An owner who does not buy loses a part of that share.

> A public issue brings in new owners; a rights issue keeps control with the old ones.

The two issues compare as follows. A public issue reaches many new buyers and can raise large sums, but it brings fees, disclosure and new owners. A rights issue is cheaper and keeps control with the old owners, but it raises only as much as they are willing to pay.

> Rules for issuing shares differ by country, and Bangladesh has its own regulator.

The rules for issuing shares differ by country. In Bangladesh, the Bangladesh Securities and Exchange Commission regulates the capital market, as the next section shows.

> Recap: the capital market issues and trades long-term funds; an initial public offering is the first sale to the public; a rights issue goes to existing owners first.

*Before moving on.* The capital market is where long-term loans and shares are issued and traded. An initial public offering is a first sale to the public. A rights issue offers new shares to existing owners in proportion to their holdings.

* * *

## 17.4 Long-Term Lenders and Investors in Bangladesh

> Bangladesh has commercial banks, development institutions, an investment institution and two stock exchanges.

Where could Meghna and Sons find five years of money in Dhaka? Several kinds of lender and market venue matter. The names below were checked on 4 October 2026, and names can change, so confirm them before relying on them. Other countries have different names, but the same kinds of supplier appear in most of them.

> The table lists each institution, its kind, and what it supplies.

The table lists the institutions. Read each row as one name, the kind of body it is, and what it offers to a business that needs long-term funds.

:table Suppliers of long-term funds and market venues in Bangladesh
| Name | Kind | What it supplies |
| Commercial banks | Banks | Term loans, usually against collateral |
| Bangladesh Development Bank Limited | Development bank | Long-term loans to industrial projects |
| Investment Corporation of Bangladesh | State-owned investment institution | Money invested in shares and other securities |
| Infrastructure Development Company Limited (IDCOL) | Government-owned finance company | Long-term loans for infrastructure and renewable energy |
| Dhaka Stock Exchange and Chittagong Stock Exchange | Stock exchanges | Places where shares are issued and traded |
| Bangladesh Securities and Exchange Commission | Regulator | No funds; rules for issuing and trading securities |

> The commercial bank is the nearest source for a small business, and it lends against collateral.

For a small family business, the nearest source is a commercial bank. Its term loan looks like the one in the case file: instalments, collateral and covenants. A bank decides by the borrower's record and the collateral on offer. For a new business with few assets, this can be difficult.

> Development institutions were set up to lend for longer terms to projects the state wishes to encourage.

Bangladesh Development Bank Limited was incorporated on 16 November 2009. It joined two public institutions set up in 1972, Bangladesh Shilpa Bank and Bangladesh Shilpa Rin Sangstha, which lent to industry. Its purpose is the same as theirs: long-term loans for industrial projects. IDCOL works in a similar way for infrastructure and renewable energy.

> The investment corporation, the exchanges and the regulator make up the capital market side.

The Investment Corporation of Bangladesh was created by an ordinance in 1976. It is a state-owned institution that invests in shares and other securities, and so supplies money to the capital market. The Dhaka Stock Exchange and the Chittagong Stock Exchange, which was set up in 1995, are the two places where shares are issued and traded. The Bangladesh Securities and Exchange Commission was established on 8 June 1993. It regulates the capital market and approves the rules under which a business may offer shares to the public.

> A business matches its need to the supplier: a bank for a machine loan, the exchange for a large public issue.

A business matches its need to the supplier. Meghna and Sons Limited, with a machine to buy, would start with a bank. A much larger business that wished to raise money from the public would work through an exchange and under the Commission's rules.

> Recap: banks and development institutions lend; the investment corporation invests; the exchanges are the venue; the Commission regulates.

*Before moving on.* Banks and development institutions lend long-term money. The Investment Corporation of Bangladesh invests in securities. The two stock exchanges are the venues, and the Commission regulates them.

* * *

## 17.5 The Cost of Capital

> Every source of money has a price, and the business must earn enough to pay them all.
> Recall: required return and interest rate, assumed from earlier chapters.

Meghna and Sons raised money from three sources, and each one asks for a different return. How much must the business earn, on average, to keep all three satisfied? That average has a name.

> The cost of capital is one average rate for the whole mix of funds.
@ Cost of capital | the average return a business must earn on its funds to satisfy those who supplied them

The **cost of capital** is the average return a business must earn on its funds to satisfy those who supplied them. It is a rate, such as 12.85%, and not an amount of money. We find it in three steps: the cost of each source, the weight of each source, and the sum.

> Debt costs its interest rate less the tax it saves; preferred stock and common equity cost the return they require.

Start with the cost of each source. The bank charges 10% a year. But interest is paid before tax is counted, so it lowers the profit that is taxed. At the assumed tax rate of 25%, the state in effect bears a quarter of the interest.^1 The after-tax cost of the loan is 10% × (1 − 0.25) = 10% × 0.75 = 7.5%. Preferred stock costs its dividend rate, 12%, because dividends are not taken off before tax. Common equity costs the return its owners require, 14%, and this includes retained earnings.

^1: The tax rate of 25% is assumed for illustration only. Tax rules differ by country and change over time.

> The case file lists the three sources of funds, their costs and their weights.

:case Case file, illustrative. Meghna and Sons Limited, 15 November 2025. Long-term funds: bank loans outstanding Tk 500,000 at 10% (after tax 10% × 0.75 = 7.5%); preferred stock Tk 100,000 at 12%; common equity including retained earnings Tk 2,400,000 with a required return of 14%. Total Tk 3,000,000; weights 16.67%, 3.33% and 80.00%.

> A weight is each source's share of the total funds.

The sources differ in size, so they cannot count equally. The weight of a source is its share of the total. Debt: 500,000 ÷ 3,000,000 = 0.1667, or 16.67%. Preferred stock: 100,000 ÷ 3,000,000 = 0.0333, or 3.33%. Common equity: 2,400,000 ÷ 3,000,000 = 0.80, or 80.00%. The weights add to 100%.

> The figure shows the funds as one bar, split by hatching into the three weights.

The figure below is one horizontal bar. The whole bar stands for the total funds, Tk 3,000,000. Each hatched part is one source, and its width shows its share of the total. Read the label under each part for its weight and its cost.

:fig The long-term funds of Meghna and Sons Limited, split by weight | ch17-fig01.svg

:pause 17.p2 | A business has Tk 200,000 of debt and Tk 800,000 of common equity. What is the weight of each source?

> The weighted average cost of capital multiplies each cost by its weight and adds the results.
@ Weighted average cost of capital | the cost of each source of funds multiplied by its share of the total and added together

Now we combine them. The **weighted average cost of capital** is the cost of each source of funds multiplied by its share of the total and added together. In symbols: K = (Wd × Kd) + (Wp × Kp) + (We × Ke). Here K is the weighted average cost, W stands for a weight and K with a letter stands for a cost. The letters d, p and e mean debt after tax, preferred stock and common equity.

> The case file gives the result, 12.85%, and the test of Project Press against it.

:case Case file, illustrative. Meghna and Sons Limited, 15 November 2025. Weighted average cost of capital = 0.1667 × 7.5% + 0.0333 × 12% + 0.80 × 14% = 1.25% + 0.40% + 11.20% = 12.85%. Project Press (Chapter 8 flows) at 12.85%: net present value Tk 172,667, still positive.

> The cost of capital is the discount rate for judging projects: a project must earn at least this much.

Why compute it? A project must earn at least what its funds cost. So the cost of capital serves as the discount rate in net present value, as in Chapter 8, 'Capital Budgeting: Evaluation Techniques', section 8.2 'Net Present Value'. A positive net present value at 12.85% means Project Press earns more than all its suppliers of funds require.

> The result is an estimate that depends on the weights, the costs and the risk of the project.

Four cautions apply. The weights here use the amounts in the case file, and not current market prices. The cost of equity is an estimate, not a bill that arrives. The rate suits projects as risky as the business itself, and a riskier project needs a higher rate. And the cost changes when the mix changes: more debt lowers the average at first, but lenders and owners may ask for more as debt grows.

> Recap: find each cost, find each weight, multiply and add.

*Before moving on.* Find the after-tax cost of debt, and the costs of preferred stock and common equity. Find each weight. Multiply each cost by its weight and add. For Meghna and Sons the result is 12.85%, and Project Press still has a positive net present value.

* * *

## 17.6 Worked Examples: From Costs to a Single Rate

> Four examples apply the method, from clean numbers to a combined problem.

We work four examples. The first uses clean numbers. The second uses the case file. The third changes the situation, and the fourth combines the loan payment with the use of the cost of capital as a discount rate. Each example follows one order: given, find, formula, steps, answer, check.

> Example 1 uses two sources and round numbers so that the method is the only new thing.

*Example 1: clean numbers.* *Given.* Debt of Tk 400,000 costs 8% after tax. Common equity of Tk 600,000 costs 12%. *Find.* The weighted average cost of capital. *Formula.* K = (Wd × Kd) + (We × Ke), where W is a weight and K is a cost. *Steps.* Total funds: 400,000 + 600,000 = Tk 1,000,000. Weights: 400,000 ÷ 1,000,000 = 0.40, and 600,000 ÷ 1,000,000 = 0.60. K = 0.40 × 8% + 0.60 × 12% = 3.2% + 7.2% = 10.4%. *Answer.* The cost of capital is 10.4%. *Check.* The answer lies between 8% and 12%, and nearer to 12%, because equity is the larger source.

> Example 2 repeats the method with the three sources in the case file.

*Example 2: realistic numbers.* *Given.* The case file: bank loans Tk 500,000 at 10%, preferred stock Tk 100,000 at 12%, common equity Tk 2,400,000 at 14%, and a tax rate of 25%. *Find.* The weighted average cost of capital. *Formula.* K = (Wd × Kd) + (Wp × Kp) + (We × Ke).

> The steps find the after-tax cost, the weights and the products in turn.

*Steps.* After-tax cost of debt: 10% × (1 − 0.25) = 7.5%. Total funds: 500,000 + 100,000 + 2,400,000 = Tk 3,000,000. Weights: 0.1667, 0.0333 and 0.8000. Products: 0.1667 × 7.5% = 1.25%. 0.0333 × 12% = 0.40%. 0.80 × 14% = 11.20%. Sum: 1.25% + 0.40% + 11.20% = 12.85%. *Answer.* The cost of capital is 12.85%. *Check.* The answer lies between 7.5% and 14%, and close to 14%, because common equity is 80% of the funds. A common slip is to use 10% for the debt and forget the tax: that would give 13.27%, which is too high.

> Example 3 changes the situation: the new term loan is added to the funds.

*Example 3: a reshaped case.* This is an exercise built on the case file, not part of it. *Given.* Suppose the Tk 600,000 term loan is added to the existing funds, which are unchanged. The loan costs 7.5% after tax, and the owners' required return stays at 14%. *Find.* The new weighted average cost of capital. *Formula.* The same as in Example 2. *Steps.* Debt: 500,000 + 600,000 = Tk 1,100,000. Total funds: 1,100,000 + 100,000 + 2,400,000 = Tk 3,600,000. Weights: 0.3056, 0.0278 and 0.6667. Products: 0.3056 × 7.5% = 2.292%. 0.0278 × 12% = 0.334%. 0.6667 × 14% = 9.334%. Sum: 2.292% + 0.334% + 9.334% = 11.96%. *Answer.* The cost of capital falls to 11.96%. *Check.* The debt share rose from 16.67% to 30.56%, and debt is the cheapest source, so the average falls. In practice owners may ask for more than 14% as debt rises, and then the fall would be smaller.

> Example 4 finds a loan instalment and then tests a project at the cost of capital.

*Example 4: a combined problem.* *Given.* The term loan: Tk 600,000 over 5 years at 10%, repaid in equal instalments at each year end. A project costs Tk 200,000 now and returns Tk 225,000 in one year. The discount rate is 12.85%. *Find.* The yearly instalment, and whether the project passes. *Formula.* Instalment = amount × interest rate ÷ (1 − 1 ÷ (1 + interest rate) multiplied by itself n times), where n is the number of years. Net present value = present value of the return − cost.

> The steps work the instalment first and the project second.

*Steps.* Instalment: 1.10 multiplied by itself 5 times = 1.61051. Then 1 ÷ 1.61051 = 0.620921, and 1 − 0.620921 = 0.379079. The amount times the interest rate is 600,000 × 0.10 = 60,000. Then 60,000 ÷ 0.379079 = Tk 158,278.49, using more decimal places than shown. Project: present value = 225,000 ÷ 1.1285 = Tk 199,379.70. Net present value = 199,379.70 − 200,000 = −Tk 620.30.

> The instalment is Tk 158,278.49, and the project fails by about Tk 620.

*Answer.* The instalment is Tk 158,278.49 a year. The project has a net present value of about −Tk 620, so on these figures it should be rejected. *Check.* Five instalments repay 5 × 158,278.49 = Tk 791,392.45, which is Tk 191,392.45 more than the loan: this is the interest, and it is sensible for a five-year loan at 10%. At the loan's rate of 10% the project would have looked acceptable, since 225,000 ÷ 1.10 = Tk 204,545.45. At the cost of capital it fails.

> Recap: the same steps give the cost of capital for clean, realistic and changed funds, and the rate tests a project.

*Before moving on.* The method never changed: after-tax cost, weight, multiply, add. A change in the mix of funds changes the weights and so the answer. The result is the discount rate that a project must beat.

* * *

## Summary

> Long-term funds come from loans, owners and the capital market, and the business must earn their combined cost.

A term loan is repaid in instalments over more than one year, and collateral and covenants protect the lender. A debenture is a bond with no particular asset pledged. Owners supply long-term money through retained earnings and new stock. The capital market issues and trades long-term loans and shares, and in Bangladesh banks, development institutions, the investment corporation, two exchanges and a regulator play their parts. The cost of capital is the weighted average of the after-tax cost of debt, the cost of preferred stock and the cost of common equity. For Meghna and Sons it is 12.85%.

## Think It Through

:q 17.t1 | A new business asks why long-term funds suit its first machines and its shop fit-out, and why short-term loans do not. Explain in plain words.

## Where People Go Wrong

> Retained earnings are not free money.

*Wrong:* retained earnings cost nothing, because nobody is paid. *Right:* the owners could have taken the profit and used it elsewhere, so they expect a return on it. That is why the case file counts them inside common equity at 14%.

> The cost of debt is the interest rate less the tax it saves.

*Wrong:* the loan costs 10%, so use 10% in the calculation. *Right:* interest lowers taxed profit, so the cost after a 25% tax rate is 7.5%. Use the after-tax cost, and use it for debt only.

> Debt is cheaper, but a business cannot use only debt.

*Wrong:* debt is the cheapest source, so a business should borrow as much as it can. *Right:* debt must be repaid whatever the profit, and lenders and owners ask for more as debt grows.

> The cost of capital is a rate for the whole mix, not the rate of one loan.

*Wrong:* a project that beats the loan's 10% is acceptable. *Right:* a project must beat the cost of all the funds, which is 12.85% for Meghna and Sons.

## In History

> A famous offering of shares in 1956 moved a great business into public hands and created a market for its shares.

Ford Motor Company was founded by Henry Ford in 1903. For half a century its shares were held by members of the Ford family and by the Ford Foundation, a charity in the United States. In January 1956 the Foundation sold about 10.2 million Ford shares to the public at $64.50 each. It was the largest public share offering in American history up to that time. The sum raised was between $640 million and $660 million, depending on whether commissions are counted.

> The sale was led by an investment bank, and the money went to the Foundation, not to the business.

A group of 205 banks, led by Goldman Sachs, an American investment bank, handled the sale. The money went to the Foundation, which wanted to hold less of its wealth in one business, and not to Ford. The offering shows what an initial public offering does. It moves shares into many hands and creates a market where they can be traded, which is the work of a capital market.

## Review Questions

:q 17.1 | Name three conditions a lender may attach to a term loan, and say why a lender asks for each.
:q 17.2 | Compare a rights issue with a public issue. Say who may buy and what each does to the control of the existing owners.
:q 17.3 | List four types of lender or market venue for long-term funds in Bangladesh, and say what each supplies.
:q 17.4 | A loan costs 11% a year and the tax rate is 25%. Find the after-tax cost of the loan.
:q 17.5 | A business is funded 25% by debt costing 7.5% after tax, 5% by preferred stock costing 12%, and 70% by common equity costing 14%. Find the weighted average cost of capital.
