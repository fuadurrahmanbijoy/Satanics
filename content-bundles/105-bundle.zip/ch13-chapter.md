:chapter XIII | Valuing Bonds
:mood What is a promise of future payments worth today?
:desc A certificate can promise payments every year and a larger payment at the end. This chapter shows how to find what such a certificate is worth, why its worth rises and falls as market conditions change, and how to measure the return an investor earns by buying it at a given price.
:plate ch13-plate.svg | An engraver's bench with a copper plate, a burin and the half-cut border of a certificate

> A certificate promises payments for five years, and the puzzle is how much a sensible person would pay for it.

Suppose a friend offers you a certificate. It promises Tk 90 at the end of each of the next five years, and Tk 1,000 at the end of the fifth year. The friend asks Tk 1,000 for it today. Should you pay? The promises total Tk 90 × 5 + 1,000 = Tk 1,450, so the certificate seems a bargain. Many students find this step convincing, because totalling the promises feels natural. Yet the reasoning has a fault, and a second look will show it.

> A taka received later is worth less than a taka today, so the price depends on timing and on the return available elsewhere.

A taka received in five years is worth less than a taka held today, because the taka held today can earn a return in the meantime.^1 So the fair price depends on when each payment arrives and on what return you could earn elsewhere. A person who could earn 12% elsewhere would pay less than a person who could earn 7%. Both could be sensible. The task of this chapter is to turn that idea into a number.

> The chapter names the certificate, defines worth, calculates it, and then measures an investor's return; the pace is slow because two kinds of payment are valued together.

We shall go in four steps. First we name the certificate and its parts. Second we ask what it means for any asset to have a value. Third we calculate the value, using tools from earlier chapters. Fourth we compare the value with the price and measure the return. The pace is slow, because two kinds of payment must be valued at once, and each idea is finished before the next begins.

:box YOU WILL NEED
Chapter 5, 'Annuities', section 5.3 'Present Value of an Annuity'. Chapter 4, 'The Time Value of Money: Single Sums', section 4.3 'Present Value of a Single Sum'. Chapter 8, 'Capital Budgeting: Evaluation Techniques', sections 8.2 'Net Present Value' and 8.3 'Internal Rate of Return and Profitability Index'.

^1: Recall: present value, Chapter 4, 'The Time Value of Money: Single Sums', section 4.3 'Present Value of a Single Sum'.

* * *

## 13.1 What a Bond Is

> Many small certificates let a business borrow a large sum from many lenders.

Imagine a business that needs Tk 5,000,000 to buy equipment. Few lenders can lend so large a sum alone, and one lender would carry all the risk. The business can instead divide the loan into 5,000 pieces of Tk 1,000 and sell each piece to a different person. Each buyer lends Tk 1,000 and receives a certificate that states what the business has promised to pay. This arrangement is common, and the certificate has a name.

@! Go slowly here.
@ Bond | a loan sold to investors, repaid at a set date with fixed interest along the way
> A bond is a loan sold to investors, repaid at a set date with fixed interest along the way.

A **bond** is a loan sold to investors, repaid at a set date with fixed interest along the way. The business that borrows is the issuer, and the person who lends is the investor, also called the bondholder. A bond is therefore debt: the investor is a lender and not an owner of the business.^2 In the example above, the 5,000 certificates together form one loan of Tk 5,000,000.

@ Par value | the amount printed on a bond that is repaid at maturity
@ Par | Word in use. In daily life, par means an equal level, as in "on a par with". In bonds, par is the amount printed on the bond.
@ Face | Word in use. In daily life, the front of the head or the front of an object. In bonds, face value is another name for par value.
> The par value is the amount printed on the bond and repaid at the end.

A bond has three facts printed or agreed at the start. The first is the **par value**. It means the amount printed on a bond that is repaid at maturity, a date explained below. Par value is also called face value. If the investor lends Tk 1,000 and the bond is repaid with Tk 1,000, then Tk 1,000 is the par value.

@ Coupon interest | the fixed interest a bond pays each period, set as a percentage of par value
> Coupon interest is the fixed interest paid each period, found by applying the coupon rate to par value.

The second fact is the **coupon interest**. It is the fixed interest a bond pays each period, set as a percentage of par value. The percentage is called the coupon rate. A bond with a par value of Tk 1,000 and a coupon rate of 9% pays 9% × 1,000 = Tk 90 each period. In the past, bond certificates carried printed coupons that the investor cut off and presented for payment, and the name has remained.

@ Maturity | the date on which a bond is repaid
> Maturity is the date on which the bond is repaid.

The third fact is **maturity**, the date on which a bond is repaid. A bond with five years to maturity makes its last coupon payment and repays its par value at the end of year 5. In this chapter, coupon interest is paid at the end of each year, unless we say otherwise. Section 13.3 treats interest paid twice a year.

> The case file records the terms of the corporate bond used throughout the chapter.

:case Case file, illustrative. Meghna and Sons Limited, 3 August 2025. A corporate bond: par value Tk 1,000, coupon 9% a year (Tk 90), 5 years to maturity.

> The timeline shows five small coupon payments and one larger payment of par value at maturity.

Figure 13.1 shows the payments that this bond promises. Read the line from left to right: it is a timeline, and each mark on it is the end of a year, from year 0 (today) to year 5. An arrow pointing up is money received by the investor. The five small arrows are the coupon payments of Tk 90. The one large arrow at year 5 is the repayment of par value, Tk 1,000. The investor receives the last coupon and the par value on the same date.

:fig A five-year bond: five coupon payments and a larger payment of par value at maturity | ch13-fig01.svg

> The issuer must pay the fixed amounts in every year; the investor knows them in advance, but may sell before maturity.

Look at the bond from two viewpoints. For the issuer, the payments are a fixed duty: the Tk 90 each year must be paid whether sales are good or poor. For the investor, the payments are known in advance, which makes the bond easier to value than most assets. Two limits apply. An investor need not hold the bond to maturity, and may sell it to another investor at a price that differs from par. And the issuer may fail to pay, which is a risk the investor must judge. A comparison of bonds with stock follows later in the book.

:pause 13.p1 | A bond has a par value of Tk 500 and a coupon rate of 8% a year. How much coupon interest does it pay each year?

> A bond has a par value, a coupon interest and a maturity, and together these fix every payment.

*Before moving on.* A bond is a loan sold to investors. Its par value is repaid at maturity, and its coupon interest is paid each period. For the case bond these are Tk 1,000, Tk 90 a year and five years. *You should now be able to say* what a bond is and what its three facts are.

^2: Preview: bonds and stock are compared in Chapter 14, 'Valuing Common and Preferred Stock', section 14.4 'Comparing Bonds and Stock'.

* * *

## 13.2 The Idea of Value

> To value a bond we first need the idea of value itself.

A neighbour offers to sell you a mango tree. What is it worth? The cost of planting it does not decide the answer, and neither does its age. The tree is worth what it will bring: the mangoes of the coming seasons, counted by when they will arrive. Ten mangoes next year are worth more to you than ten mangoes in ten years. The same thinking applies to any asset, and to a bond in particular.

@! Go slowly here.
@ Valuation | the work of finding what an asset is worth from the cash it is expected to bring
> Valuation is the work of finding what an asset is worth from the cash it is expected to bring.

**Valuation** is the work of finding what an asset is worth from the cash it is expected to bring. The word asset here means anything that brings cash, such as a tree, a shop or a bond. Valuation needs two inputs: the cash the asset is expected to bring, and the required return, which is the return the investor needs from an asset of that risk.

@ Intrinsic value | the worth of an asset worked out from the present value of its expected cash flows
> Intrinsic value is the present value of the expected cash flows, discounted at the required return.

The result of valuation has a name. **Intrinsic value** is the worth of an asset worked out from the present value of its expected cash flows. Take the smallest case. An asset will pay Tk 1,100 in one year, and the required return is 10%. Its intrinsic value is 1,100 ÷ 1.10 = Tk 1,000. Today's Tk 1,000, invested at 10%, would grow to the same Tk 1,100.

> Intrinsic value is a calculation, while market value is a price, and a gap between the two may guide a decision.

Do not confuse intrinsic value with market value, the price at which the asset trades today. Intrinsic value is a calculation from expected cash and a required return. Market value is observed in the market. If the intrinsic value is above the market value, the asset looks cheap to the investor who made the calculation; if below, it looks costly. The two may differ because investors disagree about the cash to come or about the required return.

> Valuation turns expected cash and a required return into one number, the intrinsic value.

*Before moving on.* Valuation finds what an asset is worth from the cash it is expected to bring. The intrinsic value is the present value of that cash at the required return. *You should now be able to say* why Tk 1,100 due in one year has an intrinsic value of Tk 1,000 at a required return of 10%.

* * *

## 13.3 The Value of a Bond

> A bond brings two kinds of payment, and each kind is valued with a tool from an earlier chapter.

Look again at Figure 13.1. The bond brings two kinds of payment. The five coupon payments are equal and arrive at equal intervals, which is the pattern of an ordinary annuity.^3 The par value is one sum, paid once at maturity, which is the pattern of a single sum. We already know how to find the present value of each pattern. The value of the bond is the two present values added together, using the required return as the discount rate.

@! Go slowly here.
> The formula adds the present value of the coupons to the present value of the par value.

Here is the rule. In words: the value of a bond equals coupon interest times the annuity factor, plus par value times the single-sum factor. In symbols, V = C × a + P × f. Here V is the value of the bond, C is the coupon interest per period, and P is the par value. The annuity factor a equals [1 − 1 ÷ (1 + r)ⁿ] ÷ r, and the single-sum factor f equals 1 ÷ (1 + r)ⁿ. In both, r is the required return per period, and n is the number of periods. The factors can be read from tables or found with a calculator.

### The smallest case

> A one-year bond is solved first, because it needs only one division.

Begin with one year, so that only one division is needed. A bond has a par value of Tk 1,000, a coupon rate of 10% and one year to maturity. The required return is 10%. The investor receives the coupon of Tk 100 and the par value of Tk 1,000 at the end of the year, a total of Tk 1,100. The value is 1,100 ÷ 1.10 = Tk 1,000. Here the value equals the par value, and Section 13.4 explains why.

:pause 13.p2 | A bond has a par value of Tk 1,000, a coupon rate of 5% and one year to maturity. The required return is 10%. What is its value?

### Clean numbers

> The first full example uses round numbers so that the method is the only thing to learn.

*Given.* Par value Tk 1,000, coupon rate 10%, so C = Tk 100, three years to maturity, required return 10%. *Find.* The value of the bond. *Formula.* V = C × a + P × f, with r = 10% and n = 3.

> The steps find the two factors, multiply each by its payment, and add the results.

*Steps.* First the single-sum factor: (1.10)³ = 1.10 × 1.10 × 1.10 = 1.331, so f = 1 ÷ 1.331 = 0.751315. Second the annuity factor: a = (1 − 0.751315) ÷ 0.10 = 2.486852. Third the present value of the coupons: 100 × 2.486852 = Tk 248.685. Fourth the present value of the par value: 1,000 × 0.751315 = Tk 751.315. Fifth the sum: V = 248.685 + 751.315 = Tk 1,000.000. *Answer.* The bond is worth Tk 1,000.00. *Check.* The coupon rate equals the required return, so the value equals par, as in the one-year case.

### Realistic numbers

> The case bond is valued at a required return of 12%, which differs from its coupon rate.

The case bond has a coupon rate of 9%, but investors in bonds of this risk require 12%. *Given.* Par value Tk 1,000, C = Tk 90, five years, required return 12%. *Find.* The value. *Formula.* V = C × a + P × f. *Steps.* (1.12)⁵ = 1.762342, so f = 1 ÷ 1.762342 = 0.567427. Then a = (1 − 0.567427) ÷ 0.12 = 3.604776. The present value of the coupons is 90 × 3.604776 = Tk 324.430. The present value of the par value is 1,000 × 0.567427 = Tk 567.427. The sum is 324.430 + 567.427 = Tk 891.857.

> The case file records the value at 12%, which is below par.

:case Case file, illustrative. Meghna and Sons Limited, 3 August 2025. Same corporate bond, required return 12%: value Tk 891.86.

> The value is below the par value of Tk 1,000, and a check by estimate confirms that this is sensible.

*Answer.* The bond is worth Tk 891.86. *Check.* The bond pays Tk 90 a year while the market requires 12%, so an investor will pay less than par. The result is below Tk 1,000, as expected, and it is more than the par value's present value alone, Tk 567.43, because the coupons add value.

### Interest paid twice a year

> Many bonds pay interest twice a year, which changes the coupon, the number of periods and the rate.

Many bonds pay interest every half-year. Three changes follow. The coupon of each payment is half the yearly coupon. The number of periods is twice the number of years. The required return per period is half the yearly rate. Take the case bond with interest paid half-yearly: the coupon is Tk 45, there are 10 periods, and the required return of 12% a year becomes 6% per half-year.

> The half-yearly value uses 6% for ten periods and gives Tk 889.60.

*Steps.* With r = 6% and n = 10, f = 1 ÷ (1.06)¹⁰ = 0.558395, and a = (1 − 0.558395) ÷ 0.06 = 7.360087. The present value of the coupons is 45 × 7.360087 = Tk 331.204. The present value of the par value is 1,000 × 0.558395 = Tk 558.395. The value is 331.204 + 558.395 = Tk 889.599.

> The case file records the half-yearly value of Tk 889.60.

:case Case file, illustrative. Meghna and Sons Limited, 3 August 2025. Same corporate bond with half-yearly interest (coupon Tk 45, 10 periods) at 12% a year (6% per half-year): Tk 889.60.

> The half-yearly value is slightly lower because 6% per half-year is the same as a higher return over a full year.

*Answer.* The value is Tk 889.60. *Check.* It is a little below Tk 891.86. Half-yearly coupons arrive earlier, which would raise the value, but 6% each half-year compounds to 1.06 × 1.06 = 1.1236, which is a return of 12.36% over a year. This higher yearly return lowers the value by more.

> Common slips are using the coupon rate as the discount rate, counting years instead of periods, and forgetting to halve the rate.

Four slips are common. The first is discounting at the coupon rate instead of the required return. The second is counting years when interest is paid twice a year, where periods are needed. The third is halving the coupon but not the rate, or the reverse. The fourth is adding the present values of the coupons and the par value without checking that both use the same rate and the same number of periods.

> The value of a bond is the present value of its coupons plus the present value of its par value, at the required return.

*Before moving on.* The value of a bond equals the present value of its coupons plus the present value of its par value, both at the required return. For half-yearly interest, halve the coupon and the rate, and double the periods. *You should now be able to say* why the case bond is worth Tk 891.86 at a required return of 12%.

* * *

^3: Recall: the present value of an ordinary annuity, Chapter 5, 'Annuities', section 5.3 'Present Value of an Annuity'. The par value is a single sum discounted as in Chapter 4, section 4.3.

## 13.4 Discount, Par and Premium Bonds

> The same bond can be worth more than, equal to, or less than its par value, depending on the required return.

The case bond has a par value of Tk 1,000. At a required return of 12% it is worth Tk 891.86. What would it be worth if the market required 9%, or 7%? Before calculating, guess the direction. The bond pays a fixed Tk 90 a year. If other investments offer more than 9%, this bond is less attractive and its price should fall. If they offer less, it is more attractive and its price should rise.

@! Go slowly here.
> At a required return of 9% the bond equals par, and at 7% it is worth more than par.

*Steps at 9%.* With r = 9% and n = 5, a = 3.889651 and f = 0.649931. The present value of the coupons is 90 × 3.889651 = Tk 350.069, and of the par value 1,000 × 0.649931 = Tk 649.931. The sum is Tk 1,000.000. *Steps at 7%.* Here a = 4.100197 and f = 0.712986. The coupons give 90 × 4.100197 = Tk 369.018, and the par value gives 1,000 × 0.712986 = Tk 712.986. The sum is Tk 1,082.004, which is Tk 1,082.00 to the nearest paisa.

> The case file records the three values, and the table sorts them into three kinds of bond.

:case Case file, illustrative. Meghna and Sons Limited, 3 August 2025. Same corporate bond. Required return 12%: value Tk 891.86. Required return 9%: Tk 1,000.00. Required return 7%: Tk 1,082.00.

> The table names each case by comparing the value with par.

The table below collects the three results. Read each row from left to right: the required return, the value that follows from it, and the name of the kind of bond.

:table Value of the case bond at three required returns
| Required return | Value (Tk) | Kind of bond |
| 12% | 891.86 | Discount |
| 9% | 1,000.00 | Par |
| 7% | 1,082.00 | Premium |

@ Discount bond | a bond that sells for less than its par value
@ Premium bond | a bond that sells for more than its par value
> A discount bond sells below par, and a premium bond sells above par.

The names come from the price. A **discount bond** is a bond that sells for less than its par value. At 12%, the case bond sells for Tk 891.86, a discount of Tk 108.14. A **premium bond** is a bond that sells for more than its par value. At 7% it sells for Tk 1,082.00, a premium of Tk 82.00. A bond that sells at exactly par, as at 9%, is a par bond.

> The rule links the required return to the coupon rate: higher means discount, equal means par, lower means premium.

The rule is this. If the required return is above the coupon rate, the bond sells at a discount. If it equals the coupon rate, the bond sells at par. If it is below the coupon rate, the bond sells at a premium. The reason is that the coupon is fixed. When the market requires more than the coupon pays, the price must fall until the buyer's return reaches the required level. When the market requires less, buyers bid the price up.

> Figure 13.2 shows the value falling as the required return rises, crossing the par line at the coupon rate.

Figure 13.2 draws the idea. The horizontal axis shows the required return, and the vertical axis shows the value of the bond. Each point on the curve is the value at one required return. The dashed horizontal line marks par value, Tk 1,000. The curve slopes downward: a higher required return always gives a lower value. It crosses the par line at 9%, the coupon rate. To the left lie premium bonds, and to the right lie discount bonds.

:fig Value of the case bond falling as the required return rises, with par value as a horizontal line | ch13-fig02.svg

> A bond's value moves toward par as maturity approaches, because the par value is then repaid.

One limit should be noted. A discount or premium does not last. As maturity approaches, the value moves toward par, because the par value is repaid on that date.

@! Go slowly here.
@ Yield to maturity | the yearly return an investor earns by buying a bond at its price and holding it to maturity
@ Yield | Word in use. In daily life, to yield is to give way, or the amount a crop produces. In bonds, yield is a return stated as a yearly percentage.
> Yield to maturity is the yearly return from buying at the market price and holding to maturity.

So far the required return was given, and we found the value. Now reverse the question. The price is given, and we want the return. The **yield to maturity** is the yearly return an investor earns by buying a bond at its price and holding it to maturity. It is found by the same idea as the internal rate of return: the rate that makes the present value of the payments equal the price paid.^4

> The case file gives a price of Tk 920 and a yield to maturity of about 11.2%.

:case Case file, illustrative. Meghna and Sons Limited, 3 August 2025. A bond priced at Tk 920 with the same coupon and 5 years left has yield to maturity about 11.2%.

> The method of trial tries two rates, sees that the price lies between the values, and interpolates.

*Given.* Price Tk 920, C = Tk 90, par value Tk 1,000, five years. *Find.* The yield to maturity. *Formula.* There is no direct formula, so we use trial. Choose a rate, calculate the value, and compare it with the price. A value above the price means the rate is too low, because a higher rate lowers the value. *Steps.* At 11% the value is Tk 926.08, above the price. At 12% the value is Tk 891.86, below the price. The yield lies between 11% and 12%. The price is (926.08 − 920) = 6.08 below the value at 11%, out of a total gap of 926.08 − 891.86 = 34.22. The fraction is 6.08 ÷ 34.22 = 0.178, so the yield is about 11% + 0.178 × 1% = 11.18%.

> The answer is checked by calculating the value at the estimated rate.

*Answer.* The yield to maturity is about 11.2%. *Check.* At 11.2% the value is about Tk 919.10, within Tk 1 of the price of Tk 920. The straight-line step is an estimate, and the exact figure is a little lower, at 11.17%.

> The yield to maturity differs from the coupon rate whenever the price differs from par.

Compare the three rates for this bond. The coupon rate is 9% and never changes. The price of Tk 920 is below par, so the yield to maturity, 11.2%, is above the coupon rate: the investor gains the coupon and also the rise from Tk 920 to Tk 1,000. A bond at par has a yield equal to its coupon rate. A premium bond has a yield below it.

> A discount bond has a higher yield than its coupon rate, a par bond equal, and a premium bond lower.

*Before moving on.* A bond sells at a discount when the required return is above the coupon rate, at par when equal, and at a premium when below. The yield to maturity is the return from buying at the price and holding to maturity, found by trial. *You should now be able to say* why the case bond at Tk 920 has a yield to maturity above 9%.

^4: Recall: internal rate of return, Chapter 8, 'Capital Budgeting: Evaluation Techniques', section 8.3 'Internal Rate of Return and Profitability Index'.

* * *

## Worked Example: Half-Yearly Interest and Yield by Trial

> A new bond is valued with half-yearly interest, and then its yield is found from a market price.

*Given.* A bond has a par value of Tk 1,000, a coupon rate of 8% a year paid half-yearly, and three years to maturity. *Find.* First, its value at a required return of 10% a year. Second, the yield to maturity if its price is Tk 940. *Formula.* V = C × a + P × f, with the half-yearly changes of Section 13.3.

> The first part converts to half-years, then values the coupons and the par value.

*Steps, part one.* The coupon is 40, the periods are 6, and the rate is 10% ÷ 2 = 5% per half-year. At 5% and 6 periods, f = 0.746215 and a = 5.075692. The coupons are worth 40 × 5.075692 = Tk 203.028, and the par value is worth 1,000 × 0.746215 = Tk 746.215. The value is Tk 949.243.

> The second part tries 5% and 6% per half-year, then interpolates and doubles the result.

*Steps, part two.* The price of Tk 940 is below Tk 949.24, so the rate must exceed 5%. Try 6%: f = 0.704961 and a = 4.917324, so the value is 40 × 4.917324 + 1,000 × 0.704961 = 196.693 + 704.961 = Tk 901.65. The price lies between the two values. The fraction is (949.24 − 940) ÷ (949.24 − 901.65) = 9.24 ÷ 47.59 = 0.194, so the half-yearly rate is about 5% + 0.194 × 1% = 5.19%. Bond markets state the yearly figure by doubling the half-yearly rate, which gives about 10.4%.

> The answers are Tk 949.24 and about 10.4%, and each is tested against the other.

*Answer.* The value at 10% is Tk 949.24, and the yield to maturity at a price of Tk 940 is about 10.4% a year. *Check.* The bond is a discount bond, so its value is below par, and the coupon rate of 8% is below the required return of 10%, as the rule requires. A price of Tk 940 is below Tk 949.24, so the yield must exceed 10%, and 10.4% does.

* * *

## Summary

> A bond is valued by discounting its coupons and par value at the required return, and its price and yield move in opposite directions.

A bond is a loan sold to investors, with a par value, coupon interest and a maturity. Its intrinsic value is the present value of its coupons plus the present value of its par value, at the required return: V = C × a + P × f. For half-yearly interest, halve the coupon and the rate and double the periods. The value falls as the required return rises. A bond sells at a discount when the required return exceeds the coupon rate, at par when equal, and at a premium when below. The yield to maturity is the return from buying at the price and holding to maturity, found by trial.

## Think It Through

> A bond price of Tk 940 is compared with the case bond to learn what the market requires.

The case bond has a par value of Tk 1,000, a coupon rate of 9% and five years to maturity. It now sells for Tk 940.

:q 13.t1 | Does the market require more or less than the coupon rate? Show the check by calculating the value at 10% and at 11%.
:q 13.t2 | Is this a discount bond, a par bond or a premium bond? What would the price become if the required return fell to 9%?

## Where People Go Wrong

> The coupon rate is not the return an investor earns, because the return depends on the price paid.

Some students treat the coupon rate as the investor's return. The coupon rate is fixed on par value. An investor who pays Tk 920 earns more than 9%, and one who pays Tk 1,082 earns less. The return depends on the price.

> A higher required return lowers the value of a bond, and does not raise it.

Some students expect a higher required return to give a higher value. The reverse is true. A higher required return means a larger discount on the fixed payments, so the present value falls.

> The coupons are discounted at the required return, never at the coupon rate.

Some students discount the coupons at the coupon rate. This always gives a value equal to par, whatever the market requires, and so answers nothing. The discount rate is the required return.

> The yield to maturity is a promise only if the investor holds to maturity and the issuer pays in full.

Some students think the yield to maturity is guaranteed. It is the return the investor earns if every payment is made and the bond is held to maturity. If the issuer fails to pay, or the investor sells early at another price, the return differs.

## In History

> In 1751 Henry Pelham merged several government debts into one stock that paid a fixed rate with no date for repayment.

In the middle of the eighteenth century, the British government carried many separate debts. Henry Pelham, who was Prime Minister of Great Britain from 1743 until his death in 1754, took advantage of low market rates of interest to reduce the burden. In 1751 he merged several of these debts into one stock, later known as Consols, short for consolidated annuities. Its interest rate was brought down to 3 per cent.

> Consols had no maturity, so the investor received interest forever and could sell the stock for a price that moved with the market.

Consols set no date at which the government had to repay. An investor received interest each year and, to turn the holding into cash, sold it to another investor at the market price. Because the interest was fixed, the price rose when market rates fell and fell when they rose, exactly as this chapter describes. The stock created a long-lived market in bonds, and later governments issued similar stocks. They have since been repaid.

## Review Questions

:q 13.1 | A bond has a par value of Tk 1,000, a coupon rate of 8% and four years to maturity. The required return is 10%. Find its value.
:q 13.2 | State how the required return compares with the coupon rate for a discount bond, a par bond and a premium bond, and give the reason for each.
:q 13.3 | A new bond has a par value of Tk 1,000 and a coupon rate of 6% paid half-yearly. It has two years to maturity, and the required return is 8% a year. Find its value.
:q 13.4 | The case bond (coupon 9%, par value Tk 1,000, five years) is priced at Tk 950. Using trial rates of 10% and 11%, estimate its yield to maturity.
:q 13.5 | Explain in plain words why the value of a bond falls when the required return rises.
