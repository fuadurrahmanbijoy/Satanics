:chapter V | Annuities
:mood How does one value a promise that arrives in equal instalments?
:desc This chapter teaches equal payments made at equal intervals. It shows how to find their future value and their present value, how to read a factor table, and how to find an unknown payment for a savings target or a loan.
:plate ch05-plate.svg | A clerk stamps a passbook at the brass-barred counter of a savings bank

:box YOU WILL NEED
Chapter 4, sections 4.2 and 4.3: the future value and the present value of a single sum. Every idea in this chapter is built from those two.

> A choice between Tk 3,000 now and three payments of Tk 1,000 cannot be settled by adding the payments.

A friend offers you a choice. You may take Tk 3,000 today, or you may receive Tk 1,000 at the end of each of the next three years. Which is the better offer? Many people notice that both offers total Tk 3,000 and conclude that the two are equal. They are not equal. Money received today can be deposited and can earn interest; money received next year cannot do so until next year. The Tk 3,000 offer is therefore worth more. But how much more? To answer, you must give each Tk 1,000 payment its own value today.

> The same shape appears in saving: equal deposits grow, because each one earns interest for a different length of time.

Now reverse the picture. Suppose that you deposit Tk 1,000 at the end of each of the next three years in a bank that pays 10% a year. How much will you hold at the end of the third year? The answer is not Tk 3,000. The first deposit earns interest for two years, the second for one year, and the last for no time at all. Each deposit is a single sum with its own length of time, and Chapter 4 showed how to treat a single sum.^1

^1: Chapter 4, 'The Time Value of Money: Single Sums', section 4.2 'Future Value of a Single Sum' and section 4.3 'Present Value of a Single Sum'.

> Single sums can answer both questions, but the labour grows with every extra payment.

You could answer both questions with the tools of Chapter 4. You would treat each payment as a separate single sum and then total the results. For three payments this is tolerable. For a loan repaid over twenty years, or a pension paid over thirty, it would fill pages, and one slip would spoil every line below it. Yet series of equal payments are everywhere in business: rent, loan instalments, savings plans, pensions. This chapter gives such a series a name and a shortcut. It also asks you to see time in a new way, as a row of equal steps with a payment placed on some of them. Go slowly; each idea is short, and each rests on the one before.

* * *

## 5.1 What an Annuity Is

@! Go slowly here.

> Rent, loan instalments and savings plans share one shape: equal payments at equal intervals.

Begin with three ordinary households. One family pays Tk 8,000 rent on the last day of every month. A student deposits Tk 500 on the first day of every month. A father repays a loan with Tk 4,000 each month for two years. The purposes differ, but the payments share three features. Every payment has the same size. The same length of time separates each payment from the next. And the series stops after a known number of payments. Finance gives this shape a name.

> The word annuity names any series of equal payments made at equal intervals for a set number of periods.
@ Annuity | A series of equal payments made at equal time intervals for a set number of periods.
@ Annuity | Word in use. In daily life, a yearly sum paid to a person, often as a pension. In finance, any series of equal payments for a set number of periods.

That name is **annuity**. An annuity is a series of equal payments made at equal time intervals for a set number of periods. Three deposits of Tk 1,000, made one at the end of each of three successive years, form an annuity. So does the monthly loan repayment above. A period is the length of the interval between payments: a month, a quarter or a year. In this chapter the period is one year unless we say otherwise, and the interest rate is always stated for that same period.

> Whether a payment falls at the start or at the end of a period changes its value.

The timing of the first payment needs care. Does it fall at the end of the first period or at its start? The answer matters, because a payment made one period earlier has one more period in which to earn interest. Finance therefore separates two kinds of annuity.

> An ordinary annuity pays at period ends; an annuity due pays at period starts.
@ Ordinary annuity | An annuity whose payments fall at the end of each period.
@ Annuity due | An annuity whose payments fall at the start of each period.
@ Due | Word in use. In daily life, owed or expected on a date, as in "the rent is due on Friday". In finance, the word "due" in annuity due means payment at the start of each period.

An **ordinary annuity** is an annuity whose payments fall at the end of each period. An **annuity due** is an annuity whose payments fall at the start of each period. Take three payments of Tk 1,000 over three years. In an ordinary annuity they are made at the end of year 1, year 2 and year 3. In an annuity due they are made at the start of year 1, year 2 and year 3. The start of year 1 is today, and the start of year 2 is the end of year 1. Loan instalments and bank interest are usually ordinary annuities, because they are paid after the period has run. Rent is often an annuity due, because landlords ask for it in advance. When no kind is stated, take the annuity to be ordinary.

> The figure reads from left to right: ticks on the line are moments in time, and blocks are payments.

The figure below shows both kinds on a timeline. Read each line from left to right. The ticks on a line are moments in time, numbered 0, 1, 2 and 3, where 0 is today and each later number is the end of a year. Each block is one payment of Tk 1,000. On the upper line the blocks sit at the ends of the years, at 1, 2 and 3. On the lower line they sit at the starts, at 0, 1 and 2. The lower blocks are shifted one step to the left, and that shift is the whole difference between the two kinds.

:fig Two timelines of three yearly payments: at the end of each year (ordinary annuity) and at the start of each year (annuity due) | ch05-fig01.svg

> To the saver an annuity grows a sum; to the borrower it is a burden; to the financial manager it is a pattern to value.

Four viewpoints help here. The saver sees an annuity as a way to grow a sum by regular deposits. The borrower sees it as a series of instalments that must be met on time. A landlord, as owner of the property, sees it as income. The financial manager sees it as a pattern whose worth must be measured, so that rent, loans and savings can be compared fairly.

> A perpetuity is an annuity with no final payment.
@ Perpetuity | An annuity that never ends.

One case is unusual but useful. Suppose that the payments never stop. A series of equal payments with no final date is a **perpetuity**. A perpetuity is an annuity that never ends. A fund that pays a scholarship of Tk 50,000 every year for ever is an example. It may seem impossible to value an endless series, since the payments continue without limit. Section 5.3 shows that its present value is nevertheless a fixed, finite sum.

> Recap: an annuity has equal payments at equal intervals; ordinary means period ends, due means period starts.

*Before moving on.* An annuity is a series of equal payments at equal intervals for a set number of periods. It is ordinary when the payments fall at period ends and due when they fall at period starts. A perpetuity never ends. *You should now be able to say* where each payment of an ordinary annuity and of an annuity due falls on a timeline.

* * *

## 5.2 Future Value of an Annuity

@! Go slowly here.

> The future value of an annuity is the total of every payment grown to the date of the last payment.

The future value of an ordinary annuity is the sum that the payments reach on the date of the last payment. Each payment is first grown at compound interest to that date, and the grown amounts are then totalled. We begin with the smallest numbers, so that the method is the only new thing to learn.^2

^2: Recall: future value and compound interest, Chapter 4, 'The Time Value of Money: Single Sums', section 4.2 'Future Value of a Single Sum'.

> Worked example 1 treats each deposit as a single sum and totals the results.

*Given.* Three deposits of Tk 1,000, one at the end of each year for three years; interest rate 10% a year.
*Find.* The sum held at the end of year 3.
*Formula.* Future value of a single sum = amount × (1 + interest rate) to the power of the number of years the amount earns interest.
*Steps.* The first deposit earns interest for 2 years: Tk 1,000 × 1.10² = Tk 1,000 × 1.21 = Tk 1,210. The second earns for 1 year: Tk 1,000 × 1.10 = Tk 1,100. The third earns for no years: Tk 1,000. The total is Tk 1,210 + Tk 1,100 + Tk 1,000 = Tk 3,310.
*Answer.* The deposits reach Tk 3,310 at the end of year 3. That is Tk 310 more than the Tk 3,000 deposited, and the extra Tk 310 is interest.
*Check.* Interest on the first deposit is Tk 210 and on the second Tk 100, and Tk 210 + Tk 100 = Tk 310. The figures agree.

> The multipliers 1.21, 1.10 and 1.00 depend only on the interest rate and the number of payments, so they can be totalled once and reused.

Look at the multipliers in the steps: 1.21, 1.10 and 1.00. Their total is 3.31, and 3.31 × Tk 1,000 = Tk 3,310. This total does not depend on the size of the payment. It depends only on the interest rate and the number of payments. We may therefore calculate it once and reuse it for any payment. It is called the future value factor of an ordinary annuity. For long series, a formula gives it in one step.

> The formula multiplies the payment by one factor that depends on the interest rate and the number of payments.

The rule, in words first: the future value of an ordinary annuity equals the payment multiplied by the future value factor. The factor equals (1 + interest rate) to the power of the number of payments, less 1, all divided by the interest rate. In symbols:
FVA = P × [(1 + i)ⁿ − 1] ÷ i
Here FVA stands for the future value of the annuity, P for the payment made each period, i for the interest rate per period written as a decimal, and n for the number of payments. The expression in square brackets is the factor. It comes from totalling the multipliers, each of which is the one before it multiplied by 1 + i. For our example, (1.10³ − 1) ÷ 0.10 = (1.331 − 1) ÷ 0.10 = 0.331 ÷ 0.10 = 3.31, the same total as before.

:pause 5.p1 | Using the formula, find the future value factor for 10% and 4 years. Then find the future value of four deposits of Tk 1,000, one at the end of each year.

> The case file supplies realistic figures: Tk 60,000 a year for 5 years at 8%.

:case Case file, illustrative. Meghna and Sons, 15 August 2024. All calculations in this chapter's case use an interest rate of 8% a year. Tanvir deposits Tk 60,000 at the end of each of 5 years. The future value of this ordinary annuity is Tk 351,996.06, using the factor 5.866601.

> Worked example 2 repeats the method with the case figures, in the standard order from Given to Check.

*Given.* Tk 60,000 deposited at the end of each of 5 years; interest rate 8% a year.
*Find.* The sum held at the end of year 5.
*Formula.* FVA = P × [(1 + i)ⁿ − 1] ÷ i, with P = Tk 60,000, i = 0.08 and n = 5.
*Steps.* First the power: 1.08⁵ = 1.46932808. Next the factor: (1.46932808 − 1) ÷ 0.08 = 0.46932808 ÷ 0.08 = 5.866601. Then the sum: Tk 60,000 × 5.866601 = Tk 351,996.06.
*Answer.* The deposits reach Tk 351,996.06 at the end of year 5.
*Check.* The deposits total 5 × Tk 60,000 = Tk 300,000. The answer exceeds this by Tk 51,996.06, which is the interest earned. The table below confirms the figure year by year.

> The table follows the balance year by year: opening balance, interest, deposit, closing balance.

To see the factor at work, follow the balance through the five years. Each year the opening balance earns 8% interest, and then the deposit of Tk 60,000 arrives at the year end. Read each row from left to right: opening balance plus interest plus deposit gives the closing balance.

:table Balance of the deposits, year by year (Tk)
| Year | Opening balance | Interest at 8% | Deposit at year end | Closing balance |
| 1 | 0.00 | 0.00 | 60,000.00 | 60,000.00 |
| 2 | 60,000.00 | 4,800.00 | 60,000.00 | 124,800.00 |
| 3 | 124,800.00 | 9,984.00 | 60,000.00 | 194,784.00 |
| 4 | 194,784.00 | 15,582.72 | 60,000.00 | 270,366.72 |
| 5 | 270,366.72 | 21,629.34 | 60,000.00 | 351,996.06 |

> The last closing balance matches the formula, and the figure splits each balance into deposits and interest.

The last closing balance equals the answer from the formula, so the shortcut and the long method agree. The next figure draws the closing balances as bars. Each bar stands for the balance at the end of one year, and its height shows money in taka. The lower, line-hatched part of a bar is the total deposited so far; the upper, cross-hatched part is interest earned. Notice that the interest part grows faster each year, because interest is earned on earlier interest.

:fig Closing balance of the savings plan at the end of each year, split into deposits and interest | ch05-fig02.svg

> An annuity due earns one extra period of interest on every deposit, so its value is the ordinary value times 1 + i.

Now consider the annuity due. If each deposit is made one year earlier, it earns one more year of interest. Every deposit is therefore worth (1 + i) times as much at the end. So the future value of an annuity due equals the future value of the ordinary annuity multiplied by (1 + i). With the smallest numbers: Tk 3,310 × 1.10 = Tk 3,641. Check by deposit: Tk 1,000 × (1.10³ + 1.10² + 1.10) = Tk 1,331 + Tk 1,210 + Tk 1,100 = Tk 3,641.

> The case file sets the annuity due beside the ordinary annuity.

:case Case file, illustrative. Meghna and Sons, 15 August 2024. If the same Tk 60,000 is deposited at the start of each of the 5 years, at 8% a year, the future value is Tk 380,155.74.

> Multiplying by 1.08 reproduces the case figure, and the difference equals one year of interest on the ordinary value.

The calculation is Tk 351,996.06 × 1.08 = Tk 380,155.74. The check is the difference: Tk 380,155.74 − Tk 351,996.06 = Tk 28,159.68, which is 8% of Tk 351,996.06. In other words, depositing at the start of each year earns one extra year of interest on the final sum of the ordinary annuity.

:pause 5.p2 | Find the future value of three deposits of Tk 1,000 at 10% a year when each deposit is made at the start of the year.

> Recap: future value of an ordinary annuity is the payment times a factor; for an annuity due, multiply by 1 + i.

*Before moving on.* The future value of an ordinary annuity is the payment times the factor [(1 + i)ⁿ − 1] ÷ i. For an annuity due, multiply that result by 1 + i. *You should now be able to say* why the annuity due is worth more at the end: each payment earns interest for one extra period.

* * *

## 5.3 Present Value of an Annuity

@! Go slowly here.

> The present value of an annuity is the total of every payment brought back to today.

Return to the opening puzzle. The offer of three payments of Tk 1,000 has a value today, and we can now find it. The present value of an annuity is the sum today that is worth the same as all the payments together. Each payment is discounted back to today, and the discounted amounts are then totalled.^3

^3: Recall: present value and discount rate, Chapter 4, 'The Time Value of Money: Single Sums', section 4.3 'Present Value of a Single Sum'. Here the discount rate is the interest rate that money could earn on a deposit.

> Worked example 3 discounts each of the three payments in the puzzle at 10% and totals the results.

*Given.* Three payments of Tk 1,000, at the end of years 1, 2 and 3; discount rate 10% a year.
*Find.* The present value of the three payments.
*Formula.* Present value of a single sum = amount ÷ (1 + discount rate) to the power of the number of years until the amount is received.
*Steps.* Payment 1: Tk 1,000 ÷ 1.10 = Tk 909.09. Payment 2: Tk 1,000 ÷ 1.21 = Tk 826.45. Payment 3: Tk 1,000 ÷ 1.331 = Tk 751.31. The total is Tk 909.09 + Tk 826.45 + Tk 751.31 = Tk 2,486.85.
*Answer.* The present value of the three payments is Tk 2,486.85.
*Check.* A present value must be less than the Tk 3,000 received in total, and Tk 2,486.85 is. A second check: the future value Tk 3,310 from worked example 1, divided by 1.331, also gives Tk 2,486.85.

> The puzzle is answered: at 10%, Tk 3,000 today is worth more than three payments of Tk 1,000.

So the puzzle is answered. At 10% a year the three payments are worth Tk 2,486.85 today, and the offer of Tk 3,000 today is better by Tk 513.15. The payments are worth less than their total because each one arrives after a delay.

> The present value formula gives the factor for all payments in one step.

The rule, in words first: the present value of an ordinary annuity equals the payment multiplied by the present value factor. The factor equals 1 less (1 + interest rate) to the power of minus the number of payments, all divided by the interest rate. In symbols:
PVA = P × [1 − (1 + i)⁻ⁿ] ÷ i
PVA stands for the present value of the annuity; P, i and n mean what they meant in section 5.2. The power of minus n is a short way to write division by 1 + i, repeated n times. For worked example 3, (1 − 1.10⁻³) ÷ 0.10 = (1 − 0.751315) ÷ 0.10 = 0.248685 ÷ 0.10 = 2.48685, and 2.48685 × Tk 1,000 = Tk 2,486.85.

> The case file offers four yearly rent payments of Tk 120,000, to be valued at 8%.

:case Case file, illustrative. Meghna and Sons, 15 August 2024. The landlord offers 4 yearly rent payments of Tk 120,000, each at year end. The interest rate is 8% a year. The present value is Tk 397,455.22, using the factor 3.312127.

> Worked example 4 values the landlord's offer in the standard order.

*Given.* Tk 120,000 paid at the end of each of 4 years; discount rate 8% a year.
*Find.* The present value of the four payments.
*Formula.* PVA = P × [1 − (1 + i)⁻ⁿ] ÷ i, with P = Tk 120,000, i = 0.08 and n = 4.
*Steps.* First the power: 1.08⁻⁴ = 0.73502985. Next the factor: (1 − 0.73502985) ÷ 0.08 = 0.26497015 ÷ 0.08 = 3.312127. Then the value: Tk 120,000 × 3.312127 = Tk 397,455.24. The case file gives Tk 397,455.22, because the factor shown is rounded to six places; the unrounded factor gives the case figure.
*Answer.* The four payments are worth Tk 397,455.22 today, although they total Tk 480,000.
*Check.* The table below discounts each payment alone, as in worked example 3.

> The table discounts each rent payment separately; the present values total the answer.

Read each row from left to right: the payment, multiplied by the discount multiplier for that year, gives its present value. The multipliers are shown to six places, and the present values are computed from unrounded multipliers.

:table Present value of each rent payment at 8% (Tk)
| Year | Payment | Discount multiplier | Present value |
| 1 | 120,000 | 0.925926 | 111,111.11 |
| 2 | 120,000 | 0.857339 | 102,880.66 |
| 3 | 120,000 | 0.793832 | 95,259.87 |
| 4 | 120,000 | 0.735030 | 88,203.58 |
| Total | 480,000 | | 397,455.22 |

> Printed tables store factors, so that no powers need to be calculated.
@ Factor table | A printed table of ready-made multipliers for given rates and numbers of periods.

Before calculators, people did not calculate powers each time. They read the multiplier from a **factor table**. A factor table is a printed table of ready-made multipliers for given rates and numbers of periods. A reader finds the row for the number of periods, moves across to the column for the factor needed, and multiplies that factor by the payment. The table below lists the two annuity factors for 8% a year.

:table Annuity factors for an interest rate of 8% a year
| Number of payments | Future value factor | Present value factor |
| 1 | 1.000000 | 0.925926 |
| 2 | 2.080000 | 1.783265 |
| 3 | 3.246400 | 2.577097 |
| 4 | 4.506112 | 3.312127 |
| 5 | 5.866601 | 3.992710 |

> Two cells of the table are the factors used in the case file.

Row 5 of the first column holds 5.866601, the factor used for the savings plan in section 5.2. Row 4 of the second column holds 3.312127, the factor used for the rent offer. The same method serves for any rate, provided that the table lists it.

> For an annuity due, each payment is one period closer, so the present value is the ordinary value times 1 + i.

The present value of an annuity due follows the same reasoning as before. Each payment comes one period sooner, so it is discounted one period less and is worth (1 + i) times as much. Therefore the present value of an annuity due equals the present value of the ordinary annuity multiplied by (1 + i). For three payments of Tk 1,000 at 10%: Tk 2,486.85 × 1.10 = Tk 2,735.54. Check by payment: the first payment, made today, is worth Tk 1,000, and the others are worth Tk 909.09 and Tk 826.45, which total Tk 2,735.54.

> A perpetuity is valued by one division, because a fund that pays out only its interest lasts for ever.

Now return to the perpetuity of section 5.1. The payments never stop, yet the present value is finite, because payments in the distant future are discounted to almost nothing. The rule is short: the present value of a perpetuity equals the payment divided by the interest rate. In symbols, PV = P ÷ i.

> The case file gives a scholarship fund that pays Tk 50,000 for ever.

:case Case file, illustrative. Meghna and Sons, 15 August 2024. A scholarship fund pays Tk 50,000 a year for ever. The interest rate is 8% a year. The present value is Tk 625,000.

> The division reproduces the case figure, and a check shows why the fund never runs out.

The calculation is Tk 50,000 ÷ 0.08 = Tk 625,000. The check: a fund of Tk 625,000 earns 8% × Tk 625,000 = Tk 50,000 each year. If the fund pays out only that interest, the fund itself stays whole, and the payments can continue for ever. The rule has limits. It holds only while the interest rate stays at 8%, which no one can promise for ever. It also assumes that the first payment comes at the end of the first period; if the first payment is made today, add one payment to the result.

> Four slips cause most errors: the wrong factor, mixed periods, wrong timing and early rounding.

Common slips are few. Using the future value factor when a present value is wanted gives a sum that grows instead of shrinks. Mixing periods, such as monthly payments with a yearly interest rate, spoils every figure. Treating an annuity due as ordinary forgets the multiplication by 1 + i. Rounding a factor to two or three places loses whole taka on large payments, so keep six places.

> Recap: present value is the payment times a factor; for a due multiply by 1 + i; for a perpetuity divide by the interest rate.

*Before moving on.* The present value of an ordinary annuity is the payment times the factor [1 − (1 + i)⁻ⁿ] ÷ i. For an annuity due, multiply by 1 + i. For a perpetuity, divide the payment by the interest rate. A factor table stores the factors ready made. *You should now be able to say* why a series of payments is worth less today than its total.

* * *

## 5.4 Finding the Payment

> Sometimes the payment is the unknown, and the same factors answer by division.
@ Sinking fund | Money put aside in equal deposits to reach a target sum by a set date.

So far the payment was given and the value was unknown. Often the position is reversed. A business knows the sum it needs, or the sum it has borrowed, and wishes to find the payment. The same two factors serve, but we divide instead of multiplying. The first case is a **sinking fund**. A sinking fund is money put aside in equal deposits to reach a target sum by a set date. The rule is: deposit = target sum ÷ future value factor. The worked example that follows solves the van problem of the case file in full.

> A loan repaid in equal instalments is an annuity whose present value is the amount borrowed.
@ Amortisation | Repaying a loan by equal payments that cover the interest and part of the amount borrowed.

The second case is a loan. The lender receives equal payments, usually at period ends, so the lender holds an ordinary annuity whose present value is the amount borrowed. **Amortisation** means repaying a loan by equal payments that cover the interest and part of the amount borrowed. The rule is: instalment = amount borrowed ÷ present value factor. Each instalment pays that year's interest first, and the rest repays part of the loan.

> Worked example 5 uses a small loan with illustrative figures that are not part of the case file.

*Given.* A loan of Tk 100,000, repaid by 3 equal year-end instalments; interest rate 10% a year.
*Find.* The yearly instalment.
*Formula.* Instalment = amount borrowed ÷ present value factor. The factor for 10% and 3 payments is 2.486852.
*Steps.* Tk 100,000 ÷ 2.486852 = Tk 40,211.48.
*Answer.* The yearly instalment is Tk 40,211.48.
*Check.* The table below shows the loan falling to zero after the third instalment.

> Each year the interest share of the instalment falls and the loan share rises, until the balance is zero.

Read each row from left to right. The opening balance earns 10% interest. The rest of the instalment, Tk 40,211.48 less the interest, repays part of the loan, and the closing balance is what remains.

:table Amortisation of a loan of Tk 100,000 at 10% (Tk)
| Year | Opening balance | Interest | Part of loan repaid | Closing balance |
| 1 | 100,000.00 | 10,000.00 | 30,211.48 | 69,788.52 |
| 2 | 69,788.52 | 6,978.85 | 33,232.63 | 36,555.89 |
| 3 | 36,555.89 | 3,655.59 | 36,555.89 | 0.00 |

> Recap: a target sum divided by the future value factor gives the deposit; a loan divided by the present value factor gives the instalment.

*Before moving on.* To find an unknown payment, divide the known sum by the right factor: the target by the future value factor for a sinking fund, the loan by the present value factor for amortisation. *You should now be able to say* which factor belongs to saving and which to borrowing.

* * *

## Worked Example: Saving for a Van

> The van problem asks for an unknown payment and then checks it by future value.

:case Case file, illustrative. Meghna and Sons, 15 August 2024. A van replacement needs Tk 500,000 in 5 years. The interest rate is 8% a year, and the deposits are equal and made at each year end. The equal year-end deposit is Tk 85,228.23.

> Worked example 6 divides to find the deposit and then reverses the step as a check.

*Given.* Target Tk 500,000 at the end of year 5; equal ordinary deposits; interest rate 8% a year; n = 5.
*Find.* The equal year-end deposit P.
*Formula.* Deposit = target ÷ future value factor, so P = FVA ÷ {[(1 + i)ⁿ − 1] ÷ i}.
*Steps.* The factor for 8% and 5 payments is 5.866601 (section 5.2). Then P = Tk 500,000 ÷ 5.866601 = Tk 85,228.23.
*Answer.* Meghna and Sons must deposit Tk 85,228.23 at the end of each of 5 years.
*Check.* Reverse the step: Tk 85,228.23 × 5.866601 = Tk 500,000.02. The two poisha of difference arise because the deposit was rounded to the nearest poisha.

> Deposits supply most of the target and interest supplies the rest.

Compare the parts. Five deposits total 5 × Tk 85,228.23 = Tk 426,141.15. Interest therefore supplies about Tk 73,859 of the Tk 500,000, which is about 15%. A business that saves over a longer period needs smaller deposits, because interest has more time to work.

* * *

## Summary

> An annuity is a series of equal payments; two factors value it, and division finds an unknown payment.

An annuity is a series of equal payments at equal intervals for a set number of periods. It is ordinary when payments fall at period ends and due when they fall at period starts; a perpetuity never ends. The future value of an ordinary annuity is P × [(1 + i)ⁿ − 1] ÷ i, and its present value is P × [1 − (1 + i)⁻ⁿ] ÷ i. For an annuity due, multiply either result by 1 + i. A perpetuity is worth P ÷ i. A target sum divided by the future value factor gives the deposit of a sinking fund, and a loan divided by the present value factor gives the instalment under amortisation.

## Think It Through

:q 5.t1 | A supplier offers machine parts for Tk 400,000 today or Tk 90,000 at the end of each of the next 5 years. The interest rate is 10% a year, and the present value factor for 10% and 5 payments is 3.790787. Which offer costs less in present value, and why?
:q 5.t2 | Explain in plain words why an annuity due is worth more than an ordinary annuity with the same payment, interest rate and number of payments.

## Where People Go Wrong

> Multiplying the payment by the number of payments ignores the timing of the money.

*Mistake: "Four payments of Tk 25,000 are worth Tk 100,000."* That is their total, not their value today. Payments in the future are worth less than money now, so their present value is lower than the total.

> A factor must match the question: future value factors grow money and present value factors shrink it.

*Mistake: using the future value factor to value an offer today.* The future value factor answers "what will the payments grow to?" The present value factor answers "what are the payments worth now?" Choose by the question asked.

> The period of the payment and the period of the interest rate must be the same.

*Mistake: using a yearly interest rate with monthly payments.* Either convert the rate to a monthly rate and count months, or use yearly payments. Mixed periods give wrong answers that look reasonable.

> An annuity due needs the extra multiplication by 1 + i, and a perpetuity rule needs a steady rate.

*Mistake: treating a due as ordinary, or trusting P ÷ i for any rate.* The first loses one period of interest. The second holds only while the interest rate stays the same for ever.

## In History

> In 1693 Edmond Halley used records from Breslau to price life annuities.

Edmond Halley (1656–1742) is best known for predicting the return of the comet that now bears his name. In 1693 he also published, in the Philosophical Transactions of the Royal Society of London, a paper on the mortality of mankind. His data were the birth and death records of the city of Breslau, now Wrocław in Poland, which a pastor of the city, Caspar Neumann, had sent to the Royal Society.

> Halley's table showed how many people survive to each age, and he used it to price annuities.

From these records Halley made a table showing how many people of a group born in the same year would survive to each age. He then used the table to compute the price of life annuities, which pay a sum each year for as long as the buyer lives. In outline, the fair price is the present value of each yearly payment, weighted by the chance that the buyer is alive to receive it. The calculation joins two ideas of this chapter: equal payments over time, and discounting.

## Review Questions

:q 5.1 | Find the future value of Tk 12,000 deposited each year for 6 years at 9% a year, first as an ordinary annuity and then as an annuity due.
:q 5.2 | Find the present value of a yearly payment of Tk 45,000 for 5 years at 10% a year, paid at each year end.
:q 5.3 | Find the equal yearly deposit that reaches Tk 300,000 in 4 years at 7% a year, with deposits at each year end.
:q 5.4 | Find the level yearly payment that repays a loan of Tk 250,000 over 3 years at 12% a year.
:q 5.5 | Explain the difference between an ordinary annuity and an annuity due, and say which has the higher future value.
:q 5.6 | Find the present value of a perpetuity of Tk 20,000 a year at an interest rate of 5% a year, and explain why a fund of that size can pay for ever.

:read Brealey, Myers and Allen, Principles of Corporate Finance, 2020
:read Halley, An Estimate of the Degrees of the Mortality of Mankind, 1693
:read Bacaer, A Short History of Mathematical Population Dynamics, 2011
