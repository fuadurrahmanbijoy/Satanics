:chapter XVI | Short-Term Financing and Matching
:mood Why can a sound bank fail on the day its customers ask for their money?
:desc This chapter sorts financing by the time for which a business holds the money. You will price trade credit, the most common short-term source, and learn when a supplier's discount is worth taking. You will then apply the matching principle to decide which kind of money suits which need.
:plate ch16-plate.svg | Anxious depositors queue at a bank counter before a clerk behind a wire grille

:box YOU WILL NEED
Chapter 15, section 15.1 'What Working Capital Is' and section 15.2 'The Cash Conversion Cycle'.

> A loan that does not fit the time of the need can ruin a sound plan.

Suppose you need a motorcycle to start a delivery round. A friend lends you the money but says she must have it back in one month. The motorcycle will earn its cost only slowly, over five years. At the end of the month you have not earned enough to repay her. What happens now? You must find a new lender in a hurry, or sell the motorcycle at a poor price. Your delivery round was sound, but the loan did not fit it.

> The opposite mistake is to borrow for many years to meet a need that lasts weeks.

Now reverse the story. You borrow money for ten years to buy a stock of toys that you will sell in six weeks. After the sale you hold idle cash, yet you still pay interest every month for nine more years. Both mistakes come from one error: the time for which you hold the money does not match the time for which you need it.

> Every business must choose how long to hold borrowed money, and each choice has a cost and a danger.

Businesses face this choice every day. Money can be raised for a few days or for many years, and each choice brings its own cost and its own danger. This chapter shows how to sort financing by time, how to price the most common short-term source, which is credit from suppliers, and how to decide which kind of money suits which need. It ends with a bank that made the first mistake on a very large scale.

* * *

## 16.1 Financing by Time Span

> Financing is sorted first by how long the money is held.

@ Term | Word in use. In daily life, a period of time, such as a school term. In finance, the length of time of a loan, or a condition of a contract, as in credit terms.

Every business needs funds, and Chapter 15 showed that working capital is the money tied up in day-to-day operations.^1 The source of funds matters as much as the amount. The first way to sort sources is by time: for how long will the business hold the money before it must repay it? Three spans are in common use, and the dividing lines are one year and five years.

^1: Chapter 15, 'Working Capital and the Cash Cycle', section 15.1 'What Working Capital Is': working capital is defined there.

> There are three spans: up to one year, one to five years, and more than five years.

@ Short-term financing | money borrowed or raised for up to one year
@ Intermediate-term financing | money borrowed or raised for between one and five years
@ Long-term financing | money borrowed or raised for more than five years

Each span has a name. **Short-term financing** means money borrowed or raised for up to one year. For example, a bank overdraft that is cleared in two months is short-term financing. **Intermediate-term financing** means money borrowed or raised for between one and five years, such as a loan for a delivery van repaid over three years. **Long-term financing** means money borrowed or raised for more than five years, such as the money that the owners put into the business as equity.

> Each span has its usual sources, shown in a table.

The usual sources follow the spans. The table below names them. Read each row from left to right: the first cell gives the span, the second gives its length, and the third lists the sources that businesses commonly use for it.

:table Financing spans and their usual sources
| Span | Length | Usual sources |
| Short-term | Up to 1 year | Trade credit, bank overdraft, short bank loans |
| Intermediate-term | 1 to 5 years | Loans for equipment or vehicles, repaid in instalments |
| Long-term | More than 5 years | Bonds, common stock, profit kept in the business, long loans |

> The label describes the agreement, not how long the business hopes to use the money.

The lines between the spans are not walls. A bank may renew an overdraft each year, so short-term money can stay with a business for many years. But the bank is free to refuse, and that freedom is the danger. The label describes the agreement, not the hope of the borrower. The long-term instruments, such as loans and bonds, are taught in Chapter 17.^2

^2: Chapter 17, 'Long-Term Financing and the Cost of Capital', section 17.1 'Term Loans and Debt Instruments': long-term debt instruments are taught there.

> Owners and lenders see the three spans from different sides.

Viewpoint changes the picture. A lender who gives short-term money keeps the right to ask for it back soon, so the lender takes a smaller risk and usually asks for a lower promise of reward. The owner of the business sees the reverse: short money is easy to obtain but must be found again and again. Long-term money gives the owner peace of mind, but the owner must pay for it every month and cannot return it early without agreement. Each span is therefore a trade between ease, safety and cost.

> Recap of the section on spans.

*Before moving on.* Financing is sorted by time: up to one year is short, one to five years is intermediate, and more than five years is long. Each span has its usual sources. A short-term label is only as safe as the lender's promise to renew.

* * *

## 16.2 Trade Credit

> A supplier's early-payment discount looks small, yet refusing it can be very costly.

Imagine that a supplier sends you books worth Tk 500,000 and offers two choices. You may pay Tk 490,000 within 10 days, or Tk 500,000 within 40 days. The saving is only 2%. Is it worth hurrying to pay? Many people say no, because 2% seems small. We shall find that the answer depends on a short calculation, and that the answer is often surprising.

> Trade credit lets a business pay a supplier after the goods arrive.

@ Trade credit | a supplier allowing a business to pay for goods some days after delivery

Start with the idea of delay. **Trade credit** means a supplier allowing a business to pay for goods some days after delivery. A bookshop that receives books on the 1st and pays on the 30th has used the supplier's money for 29 days without paying interest. In the shop's records the unpaid invoice is an account payable. Trade credit is the most common source of short-term financing, because almost every business buys on credit. To the supplier it is a way to win customers. To the buyer it is a loan that appears with each purchase.

> Credit terms are a short code that states the discount and the days allowed.

@ Credit terms | the discount offered and the days allowed for payment, written like 2/10, net 40

Suppliers state their conditions in a standard code. **Credit terms** means the discount offered and the days allowed for payment, written like 2/10, net 40. Read the code in three parts. The first number, 2, is the discount in per cent. The second number, 10, is the number of days in which the discount is available. The word net with the last number, 40, means that the full invoice is due by day 40. So 2/10, net 40 says: take 2% off if you pay within 10 days; otherwise pay the full amount by day 40.

> A cash discount rewards early payment with a lower price.

@ Cash | Word in use. In daily life, coins and notes. In finance, money in hand or in a bank account, ready to be spent.
@ Cash discount | a reduction in price for paying a supplier early

The reduction itself has a name. A **cash discount** means a reduction in price for paying a supplier early. On a Tk 500,000 invoice at 2%, the cash discount is Tk 10,000. A supplier offers it because early money is useful: the supplier can pay its own bills and does not wait for slow customers.

> If you refuse the discount, you borrow from the supplier; we first find the price of that loan.

Now the key question. If you do not take the discount, you in effect borrow money from the supplier for the extra days. What is the interest rate on that loan? Use a small example first. The invoice is Tk 10,000 on terms 2/10, net 30. If you pay on day 10, you pay Tk 9,800. If you wait until day 30, you pay Tk 10,000. By waiting 20 more days you keep Tk 9,800 in your hands, and the price of doing so is Tk 200. The cost for the period is 200 ÷ 9,800 = 2.04%. A year holds 365 ÷ 20 = 18.25 such periods, so the cost for the year is about 2.04% × 18.25 = 37.24%.

> The cost of giving up a discount has a standard formula.

The same steps give a formula. In words: the cost of giving up the discount equals the discount divided by what you pay if you take it, multiplied by the number of periods in a year. In symbols, cost = d ÷ (1 − d) × 365 ÷ (N − D). Here d is the discount as a decimal, so 2% is 0.02, D is the last day for the discount, and N is the day on which the full invoice is due. Check with the example: 0.02 ÷ 0.98 × 365 ÷ 20 = 0.020408 × 18.25 = 0.3724, or 37.24%. The result is an approximation, because it does not allow for interest earning further interest.

:pause 16.p1 | A supplier offers terms 1/10, net 30. What is the cost of giving up the discount, as a yearly rate?

> A cost above the interest rate of other sources means the discount should be taken.

What does the cost tell us? Compare it with the interest rate of the cheapest other source. If a bank charges 14% and giving up the discount costs 37.24%, the business should take the discount, borrowing from the bank if it lacks the cash. If giving up the discount costs less than the bank charges, the business should wait. Three cautions apply. Paying after the net date is not free: the supplier may add charges, refuse future credit or raise prices. Where no discount is offered, trade credit appears free, but the price may already include the cost of the delay. And the formula assumes that the full invoice is paid on the net date.

> Two sets of terms can be compared by their yearly costs.

The formula also lets us compare suppliers. Take terms 2/10, net 30 and terms 1/10, net 40, both on an invoice of Tk 10,000. For the first, the cost of giving up the discount is 0.02 ÷ 0.98 × 365 ÷ 20 = 37.24%. For the second, it is 0.01 ÷ 0.99 × 365 ÷ 30 = 0.010101 × 12.1667 = 12.29%. The first offer punishes late payment far more, because its discount is larger and its extra days are fewer. A business that must choose which invoice to pay early should pay the one with the higher cost of giving up the discount.

> Recap of the section on trade credit.

*Before moving on.* Trade credit is a supplier's permission to pay later. Credit terms such as 2/10, net 40 state the discount and the days. Giving up a cash discount is a costly loan, and its yearly cost is d ÷ (1 − d) × 365 ÷ (N − D).

* * *

## 16.3 Other Short-Term Sources

> Banks supply short-term money as overdrafts and as short loans.

@ Bank overdraft | a bank allowing an account to go below zero up to an agreed limit, with interest charged on the amount used

When suppliers cannot supply enough, the business turns to a bank. A **bank overdraft** means a bank allowing an account to go below zero up to an agreed limit, with interest charged on the amount used. Suppose the limit is Tk 100,000 and the business uses Tk 50,000 for 30 days at 12%. The interest is 50,000 × 0.12 × 30 ÷ 365 = Tk 493.15. Interest runs only on the amount used and only for the days used, which suits needs that rise and fall. A short loan is different: the bank lends a fixed amount for a fixed period, often a few months, and interest runs on the whole amount until repayment. Banks may refuse to renew either one, and rates and rules differ by bank and by country.

> Recap of the section on banks.

*Before moving on.* An overdraft charges interest only on the amount used. A short loan charges interest on the whole amount for the whole period. Both are short-term, and both depend on the bank's willingness to continue.

* * *

## 16.4 The Matching Principle

> Return to the motorcycle puzzle: the money must fit the need.

Return to the opening puzzle. The friend's one-month loan was wrong for a five-year motorcycle, and the ten-year loan was wrong for a six-week stock of toys. A rule can prevent both errors. First, though, we must sort a business's needs by time, because some needs never end and others come and go.

> Permanent needs stay all year, while seasonal needs appear at the busiest times.

@ Permanent working capital | the minimum working capital a business needs all year
@ Seasonal working capital | extra working capital needed only at the busiest times of the year

A bookshop shows the difference. It always needs some stock, some money in the till and some money owed by customers, whatever the month. **Permanent working capital** means the minimum working capital a business needs all year. Before the school term opens, the shop must also buy extra books. **Seasonal working capital** means extra working capital needed only at the busiest times of the year. The size of both comes from the cash conversion cycle, which sets how much money is tied up in operations.^3

^3: Chapter 15, 'Working Capital and the Cash Cycle', section 15.2 'The Cash Conversion Cycle': the cycle sets the size of the need.

> The figure shows a level permanent need and a seasonal peak above it.

The figure below shows both kinds of need. To read it, look at the horizontal axis, which shows the twelve months of the year, and at the height of the shaded area, which shows the money the business needs at that time, in taka. The lower band is the permanent need, which stays level all year. The upper band is the seasonal need, which appears for three months and then disappears.

:fig Permanent and seasonal needs over twelve months, with the finance that matches each | ch16-fig01.svg

> The matching principle ties each kind of need to a kind of money.

@ Matching principle | the rule that short-term needs are financed with short-term funds and long-term needs with long-term funds

The rule follows from the figure. The **matching principle** is the rule that short-term needs are financed with short-term funds and long-term needs with long-term funds. In the figure the lower band calls for long-term finance, and the upper band calls for short-term finance. Two reasons support the rule. The first is safety: money borrowed for three months to buy a machine that lasts ten years must be replaced three months later, and the lender may refuse. The second is cost: money borrowed for ten years to cover a three-month peak must be paid for through nine idle months.

:box IN SHORT
Match the time. Permanent needs are paid for with long-term funds, and seasonal needs with short-term funds.

> A small example with round numbers shows why matching saves interest.

A small example with round numbers shows the saving. A shop needs Tk 100,000 all year and a further Tk 50,000 for two months. Long-term money costs 10% a year and short-term money costs 12% a year. If the shop borrows Tk 50,000 short-term for two months, the interest is 50,000 × 0.12 × 2 ÷ 12 = Tk 1,000. If it carries the same Tk 50,000 on a long-term loan for the whole year, the interest is 50,000 × 0.10 = Tk 5,000. The short-term rate is higher, yet the matched choice costs Tk 4,000 less, because the money is held for only two months.

> The principle is a guide, and a business may choose to lean towards safety or towards low cost.

The principle is a guide, not a law. A cautious business may use more long-term money than the rule needs, so that it is never forced to refinance in a hurry. The price is interest on idle cash. A bolder business may rely more on short-term money, because short-term interest rates are often lower. The price is the danger that lenders refuse to renew. Neither choice is wrong in itself, but each should be made knowingly. A lender prefers to know when it will be repaid, and an owner prefers a low cost and no sudden shortage. Matching serves both.

> Recap of the section on matching.

*Before moving on.* Needs are permanent or seasonal. The matching principle pays for permanent needs with long-term funds and for seasonal needs with short-term funds. The reasons are safety and cost, and the rule is a guide.

* * *

## Worked Case: A Discount and a Seasonal Peak

> The case file records a supplier discount and a seasonal need on two dates.

:case Case file, illustrative. Meghna and Sons Limited, 1 October 2025. A supplier invoice of Tk 500,000 on terms 2/10, net 40. Taking the discount saves Tk 10,000 and costs Tk 490,000 on day 10. Cost of giving up the discount = 2/98 x 365/30 = 24.83% a year (approximation). A bank overdraft costs 14%: borrowing Tk 490,000 for 30 days costs Tk 5,638, which is less than the Tk 10,000 discount, so take the discount and borrow. Seasonal need: permanent current assets Tk 900,000 financed long term; a seasonal peak of Tk 400,000 for 3 months before the January term. Short-term borrowing at 14% costs Tk 14,000; carrying the Tk 400,000 on a long-term loan at 11% for the whole year costs Tk 44,000.

> First question: is the discount worth taking?

*Given.* Invoice Tk 500,000; terms 2/10, net 40; overdraft interest rate 14% a year.
*Find.* The yearly cost of giving up the discount, and whether to take the discount.
*Formula.* Cost = d ÷ (1 − d) × 365 ÷ (N − D).
*Steps.* First, the discount is 0.02 × 500,000 = Tk 10,000, so the payment on day 10 is Tk 490,000. Second, the extra days are N − D = 40 − 10 = 30. Third, cost = 0.02 ÷ 0.98 × 365 ÷ 30 = 0.020408 × 12.1667 = 0.2483.
*Answer.* The cost of giving up the discount is 24.83% a year, which is above the overdraft rate of 14%, so the discount should be taken.
*Check.* Tk 10,000 ÷ Tk 490,000 = 2.04% for 30 days. Twelve such periods give about 24.5%, close to 24.83%, because a year holds slightly more than twelve periods of 30 days.

> Second question: what does the overdraft cost for the 30 days?

*Given.* Borrowing Tk 490,000 for 30 days at 14%.
*Find.* The interest cost, to compare with the Tk 10,000 discount.
*Formula.* Interest = amount × yearly rate × days ÷ 365.
*Steps.* 490,000 × 0.14 = 68,600. Then 68,600 × 30 ÷ 365 = Tk 5,638.
*Answer.* The overdraft costs Tk 5,638, which is less than the Tk 10,000 discount, so the business gains Tk 10,000 − Tk 5,638 = Tk 4,362 by borrowing to take the discount.
*Check.* 5,638 ÷ 490,000 = 1.15%, below the 2.04% that the supplier's terms charge for the same 30 days.

> Third question: which source is cheapest for the seasonal peak?

*Given.* Permanent current assets Tk 900,000 financed long term. Seasonal peak Tk 400,000 for 3 months. Short-term rate 14%; long-term rate 11%.
*Find.* The interest cost of each way of financing the peak.
*Formula.* Interest = amount × yearly rate × months ÷ 12.
*Steps.* Short-term: 400,000 × 0.14 × 3 ÷ 12 = Tk 14,000. Long-term for the whole year: 400,000 × 0.11 × 12 ÷ 12 = Tk 44,000.
*Answer.* Short-term borrowing costs Tk 14,000 and the long loan costs Tk 44,000, so matching saves Tk 30,000 for the year.
*Check.* The short rate is higher, 14% against 11%, but it is paid for only 3 months instead of 12, so the total is smaller.

> Four slips are common in these calculations.

Many students make the same slips here, so check for them. First, using 40 days instead of 30 in the cost formula; the days that matter are the extra days, N − D. Second, forgetting that the bottom of the first fraction is 100% − 2% = 98%, not 100%. Third, mixing months and years: 3 months is 3 ÷ 12 of a year. Fourth, comparing the cost of giving up the discount with the interest rate without checking that both are yearly rates.

* * *

## Summary

> The chapter's main ideas in a few lines.

Financing is short-term (up to one year), intermediate-term (one to five years) or long-term (more than five years). Trade credit is a supplier's permission to pay later, and credit terms such as 2/10, net 40 state the discount and the days. Giving up a cash discount is a costly loan, with a yearly cost of d ÷ (1 − d) × 365 ÷ (N − D). A bank overdraft charges interest on the amount used. The matching principle pays for permanent working capital with long-term funds and for seasonal working capital with short-term funds.

## Think It Through

:q 16.t1 | A toy shop has a permanent need of Tk 300,000 all year and a seasonal need of Tk 150,000 for 4 months before December. A long-term loan costs 10% a year and short-term borrowing costs 13% a year. Choose how to fund each need, compute the interest for the year, and find the interest saved compared with funding everything with the long-term loan.

## Where People Go Wrong

> Mistake: believing short-term money is always cheaper.

Mistake: "Short-term money is always cheaper." Correction: the yearly rate of short-term money may be higher or lower than the long-term rate. What matters is the total interest, which depends on the rate and on how long the money is held.

> Mistake: believing trade credit costs nothing.

Mistake: "Trade credit is free." Correction: it is free only when the buyer pays on the last day without a discount lost. If the buyer gives up a cash discount, the credit can cost more than a bank loan, as the worked case showed with 24.83% against 14%.

> Mistake: taking the discount only when cash is in hand.

Mistake: "I can take the discount only if I have the cash." Correction: if giving up the discount costs more than the bank charges, the business should borrow to take it. The worked case gained Tk 4,362 by doing so.

> Mistake: thinking the matching principle must be exact.

Mistake: "Matching means every need is paid for by money of exactly the same length." Correction: matching is a guide. A business may hold some extra long-term money for safety, and it pays interest on idle cash as the price.

> Mistake: treating the formula result as an exact rate.

Mistake: "The cost of giving up the discount is exact." Correction: the formula is an approximation, because it does not allow for interest earning further interest. It is accurate enough to compare with a bank's interest rate, but it is not a precise measure.

## In History

> In 2007 a British bank that borrowed short to lend long met a queue of depositors.

Northern Rock was a bank in the United Kingdom that lent money to people buying homes. A loan for a home, called a mortgage, is repaid over many years. Yet the bank had funded much of this long lending with money borrowed for short periods from lenders in the money markets, and with sales of mortgages to investors, rather than with savings from ordinary customers.

> Only a small part of the bank's lending came from its savers.

Reports at the time said that only a small part of the money the bank lent came from its savers (Channel 4 News, 2007). For years this plan let the bank borrow cheaply and offer cheap mortgages. It worked while lenders were willing to renew, and it failed when they were not.

> When short lenders stopped renewing, the bank had to ask for help, and savers queued.

On 9 August 2007 the markets for short-term borrowing all but froze, and Northern Rock found that it could not renew its short-term loans (Shin, 2009). The bank's difficulty became public on 13 September 2007, when the BBC reported that it was seeking support from the Bank of England, the country's central bank. On the morning of 14 September 2007, depositors queued outside its branches to take out their savings. The lines continued until 17 September. The lesson matches this chapter: a bank that holds long assets but depends on short money is exposed when lenders stop renewing.

## Review Questions

:q 16.1 | An invoice of Tk 10,000 carries terms 2/10, net 30. Find the cost of giving up the discount as a yearly rate.
:q 16.2 | Find the cost of giving up the discount on terms 3/10, net 45.
:q 16.3 | An invoice of Tk 200,000 carries terms 2/10, net 40. The bank charges 13% a year. Should the business borrow from the bank to take the discount? Compare the interest with the discount.
:q 16.4 | Compare the terms 3/10, net 30 and 1/10, net 60. Which is more costly to give up, and by how much?
:q 16.5 | Define short, intermediate and long spans of financing, and give one source for each.
:q 16.6 | A toy shop has a December peak in stock. Apply the matching principle: say how it should fund its permanent need and its December need.
:q 16.7 | Explain the difference between permanent and seasonal working capital, using a seller of school books as your example.
:q 16.8 | Explain one difference between a bank overdraft and a short loan, with a reason why a business might prefer the overdraft.
