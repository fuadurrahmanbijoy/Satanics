:chapter XII | Financial and Total Leverage
:mood What happens to the owners when a business borrows to push its profit higher?
:desc This chapter shows how borrowing and preferred stock make the profit for each owner's share change by more than the operating profit does. You will calculate that profit for each share, then two measures of how strongly a change in sales or in operating profit moves it. The printing unit data of Chapter 11 is used again, now with its financing added.
:plate ch12-plate.svg | A small hand presses a long lever to lift a heavy casting

> Two printing units with the same operating profit react very differently when sales rise.

Picture two printing units. Both sell the same number of packs, both have the same costs, and both make an operating profit of Tk 80,000. The first was paid for entirely with the owners' own money. The second was paid for partly with a bank loan. Sales rise by 12.5%, and in each unit the operating profit rises by 50%. The owners of the first unit see their profit rise by half. The owners of the second see theirs nearly double. Why?

> The answer is a lever: a fixed payment that does not change while profit does.

The difference lies in what the second unit must pay to the bank. The bank wants its interest in a good year and in a poor year alike. When operating profit rises, the owners keep all of the rise, because the interest stays the same. A small hand pressing a long lever can lift a heavy weight, and a fixed payment works in the same way. But a lever works downward as well as upward, and the owners of the second unit would feel a fall equally sharply.

> This chapter measures the lever in three steps.

We take three steps. First, we see why fixed payments to lenders and to a second kind of owner make the profit for each share swing more widely. Second, we measure that swing with one number. Third, we join it to the swing from operating costs that Chapter 11 measured, and read the combined number as a sign of risk.

> The chapter extends the data set of Chapter 11 and the idea of financial risk.

You will need Chapter 11, 'Operating Leverage and Break-even Analysis', sections 11.2 and 11.3, which set out the printing unit data and the degree of operating leverage. You will also need Chapter 9, 'Return and Risk', section 9.2 'What Risk Is', where financial risk was defined.

* * *

## 12.1 Borrowing and Fixed Financing Charges

> A tea stall shows the effect of borrowing in the smallest numbers.

Suppose you plan a tea stall that costs Tk 10,000. Option one: you pay the whole sum from your savings. Option two: you pay Tk 5,000 and borrow Tk 5,000, and the loan costs Tk 500 in interest each year. In a good year the stall makes Tk 2,000 before any interest. Under option one you keep Tk 2,000, which is 20% of your Tk 10,000. Under option two you keep Tk 2,000 − Tk 500 = Tk 1,500, which is 30% of your own Tk 5,000. Borrowing has lifted your gain, measured on your own money.

> In a poor year the same loan turns the gain into a loss.

Now suppose a poor year, when the stall makes only Tk 400 before interest. Under option one you keep Tk 400, which is 4% of your Tk 10,000. Under option two you owe Tk 500 and receive only Tk 400, so you are Tk 100 short: a loss of 2% on your own Tk 5,000. The loan helped in the good year and hurt in the poor year, because the Tk 500 did not change. The rest of this section gives that fixed payment its name.

@ Charge | Word in use. In daily life, a price asked for a service, or a claim made against a person. In finance, a cost that a business must pay.

@ Fixed financing charge | interest or preferred dividend that must be paid whatever the level of EBIT

> A fixed financing charge is a payment to those who funded the business, owed at any level of EBIT.

A **fixed financing charge** is interest or preferred dividend that must be paid whatever the level of EBIT. *Financing* means paying for a business with funds from outside the day-to-day trade. The tea stall's Tk 500 is a fixed financing charge. Do not confuse it with the fixed operating cost of Chapter 11, such as rent. Both stay the same when sales change. The operating cost is paid to run the trade, and the financing charge is paid to those who supplied the funds.

> Interest is paid before tax is calculated, but a preferred dividend is paid after it.

Two facts about timing matter later. Interest is an expense: the business subtracts it before it calculates tax, so interest lowers the tax bill. A preferred dividend is a share of profit given to a class of owners, so it comes out after tax and saves no tax. We will need this difference when we calculate. A business that cannot pay its interest risks action by its lender, which is why the charge is called fixed.

@ Share | Word in use. In daily life, a part of something divided among people, such as a share of a meal. In finance, one unit of ownership of a business.

@ Common stock | ownership shares that receive what remains after all other claims, with no fixed dividend

> Common stock owners receive whatever is left, so their gain rises and falls with profit.

**Common stock** means ownership shares that receive what remains after all other claims, with no fixed dividend. Some countries call it ordinary shares or equity shares; this book uses common stock. The owners of common stock take the most risk and have the best chance of gain. If the business has Tk 33,000 left after all other claims, all of it belongs to them.

@ Preferred stock | ownership shares with a fixed dividend that is paid before any dividend on common stock

> Preferred stock owners are paid a fixed dividend before common stock owners receive anything.

**Preferred stock** means ownership shares with a fixed dividend that is paid before any dividend on common stock. A business that issues Tk 100,000 of preferred stock at 12% promises Tk 12,000 each year to those owners, ahead of the common stock owners. Preferred stock owners do not usually vote, and they cannot ask for more than the fixed dividend. Terms differ between issues and between countries, and Chapter 14 teaches the rights of shareholders in full.^1

^1: Chapter 14, 'Valuing Common and Preferred Stock', section 14.1 'Rights of Shareholders', teaches the rights of common and preferred shareholders.

> The table compares the three claims on the profit of a business.

The table sets the three claims side by side. Read each row from left to right: who holds the claim, what the holder receives, whether the amount is fixed, and when it is paid.

:table Three claims on the profit of a business
| Claim | What it receives | Fixed? | Paid |
| Lender | Interest | Yes | Before tax |
| Preferred stock | Preferred dividend | Yes | After tax, before common stock |
| Common stock | What remains | No | Last |

> A clean example shows the lever with numbers small enough to follow.

Now we repeat the tea stall in business form, with small round numbers. *Given.* EBIT Tk 10,000; interest Tk 2,000; 1,000 common shares; ignore tax for now. *Find.* The profit for each share, at EBIT of Tk 10,000, Tk 12,000 and Tk 8,000. *Formula.* Profit for each share equals EBIT less interest, divided by the number of shares. The book gives this its proper name, earnings per share, in section 12.2. *Steps.* At Tk 10,000: (10,000 − 2,000) ÷ 1,000 = Tk 8.00. At Tk 12,000: (12,000 − 2,000) ÷ 1,000 = Tk 10.00. At Tk 8,000: (8,000 − 2,000) ÷ 1,000 = Tk 6.00. *Answer.* A 20% rise in EBIT lifts the profit for each share from Tk 8.00 to Tk 10.00, a rise of 25%; a 20% fall lowers it to Tk 6.00, a fall of 25%. *Check.* Without interest the profit for each share would be Tk 10.00, Tk 12.00 and Tk 8.00, and the change would be only 20% each way.

@ Financial leverage | the effect of fixed financing charges in making earnings per share change by more than EBIT

> Financial leverage is the extra swing in profit for each share that fixed charges cause.

The extra swing has a name. **Financial leverage** is the effect of fixed financing charges in making earnings per share change by more than EBIT. In our example EBIT moved 20% and the profit for each share moved 25%, so financial leverage was at work. If a business has no fixed financing charges, the two percentages are equal. The effect cuts both ways, and the owner, the lender and the financial manager see it differently: the owner gains in good years, the lender gains security from a profitable business, and the manager must judge how much swing the owners can bear.

> Financial leverage raises financial risk, and it helps only while EBIT covers the charges.

Financial leverage is the cause of the financial risk that Chapter 9 defined: the extra risk to owners that comes from borrowing.^2 Two limits follow. First, the lever helps only while EBIT is high enough to cover the charges. If EBIT falls below the interest, the owners make a loss on the unit. Second, borrowing is not wrong in itself; the question is how much swing the owners can bear.

^2: Chapter 9, 'Return and Risk', section 9.2 'What Risk Is', defined financial risk.

> The section's ideas are fixed financing charges, the two kinds of stock and financial leverage.

*Before moving on.* A fixed financing charge is interest or preferred dividend owed at any level of EBIT. Common stock receives what remains, and preferred stock receives a fixed dividend first. Financial leverage is the extra swing in profit for each share that these charges cause.

* * *

## 12.2 Degree of Financial Leverage

> Meghna and Sons Limited provides a full data set for measuring the swing.

:case Case file, illustrative. Meghna and Sons Limited, 1 July 2025. The business was registered to own the shop and the printing unit, and the 8,000-pack data of Chapter 11 is repeated. Sales are 8,000 packs at Tk 90 each. Variable cost is Tk 50 a pack. Fixed operating cost is Tk 240,000. EBIT is therefore Tk 80,000. The printing unit is financed by a bank loan of Tk 200,000 at 10%, giving interest of Tk 20,000, and by Tk 100,000 of preferred stock at 12%, giving a dividend of Tk 12,000. There are 5,000 common shares. The tax rate is 25%.

@ Earnings per share | profit left for common stock owners divided by the number of common shares

> Earnings per share is the profit for the common stock owners, shared out per common share.

The owners of common stock care about what is left for them. **Earnings per share** is the profit left for common stock owners divided by the number of common shares. If Tk 33,000 is left and there are 5,000 shares, each share has a claim on Tk 6.60. To find the profit left, we work down from EBIT, taking away each claim in the order of the table above.

> Five subtractions and one division take EBIT to earnings per share.

*Given.* The case file above. *Find.* Earnings per share. *Formula.* In words: take EBIT, subtract interest to reach profit before tax, subtract tax, subtract the preferred dividend, and divide by the number of common shares. In symbols, with I for interest, T for the tax rate, Dp for the preferred dividend and N for the number of common shares: earnings per share = [(EBIT − I) × (1 − T) − Dp] ÷ N. *Steps.* Profit before tax: 80,000 − 20,000 = Tk 60,000. Tax at 25%: 0.25 × 60,000 = Tk 15,000. Profit after tax: 60,000 − 15,000 = Tk 45,000. Less preferred dividend: 45,000 − 12,000 = Tk 33,000. Divide by shares: 33,000 ÷ 5,000 = Tk 6.60. *Answer.* Earnings per share is Tk 6.60. *Check.* The profit left, Tk 33,000, is below profit after tax, Tk 45,000, as it must be, because the preferred owners were paid first.

> A rise in EBIT shows the swing: earnings per share moves by much more.

Now raise EBIT. At 9,000 packs, Chapter 11 gives EBIT of Tk 120,000. Profit before tax is 120,000 − 20,000 = Tk 100,000; tax is Tk 25,000; profit after tax is Tk 75,000; less the preferred dividend of Tk 12,000 leaves Tk 63,000. Earnings per share is 63,000 ÷ 5,000 = Tk 12.60. EBIT rose by 50%, from Tk 80,000 to Tk 120,000, but earnings per share rose from Tk 6.60 to Tk 12.60, which is a rise of 6.00 ÷ 6.60 = 90.9%.

@ Degree of financial leverage | the percentage change in earnings per share caused by a one percent change in EBIT

> The degree of financial leverage gives the swing as one number.

The **degree of financial leverage** is the percentage change in earnings per share caused by a one percent change in EBIT. Here a 50% rise in EBIT caused a 90.9% rise in earnings per share, so a one percent rise in EBIT causes about 1.82 percent. In words: degree of financial leverage equals the percentage change in earnings per share divided by the percentage change in EBIT. Here 90.9% ÷ 50% = 1.82.

> The same number can be found from one set of figures, without changing EBIT.

We can find the same number from the base figures alone. Interest comes out before tax, but the preferred dividend comes out after it, so we first convert the dividend to its before-tax equivalent by dividing by (1 − T). In symbols: degree of financial leverage = EBIT ÷ [EBIT − I − Dp ÷ (1 − T)]. *Given.* EBIT Tk 80,000; I Tk 20,000; Dp Tk 12,000; T 25%. *Steps.* 12,000 ÷ 0.75 = Tk 16,000. The bottom line is 80,000 − 20,000 − 16,000 = Tk 44,000. Then 80,000 ÷ 44,000 = 1.8182. *Answer.* The degree of financial leverage is 1.82. *Check.* It matches the 90.9% ÷ 50% found from the two EBIT levels, and 1.8182 × 50 = 90.9.

:pause 12.p1 | A business has EBIT of Tk 50,000, interest of Tk 10,000 and no preferred stock. Find its degree of financial leverage.

> Common slips come from the preferred dividend and from using the number far from its base.

Watch for these slips. Forgetting to divide the preferred dividend by (1 − T) gives a wrong answer, because the dividend is paid after tax. Using after-tax interest is also wrong, because interest already stands before tax in the formula. The number holds near the EBIT at which it was found, and it changes at other levels of EBIT. With no fixed financing charges the degree is exactly 1.00, and as EBIT falls toward the charges the degree grows without limit.

> The section's ideas are earnings per share and the degree of financial leverage.

*Before moving on.* Earnings per share is the profit left for common stock owners divided by the number of common shares. The degree of financial leverage shows how many percent earnings per share moves for each one percent move in EBIT. For the printing unit it is 1.82.

* * *

## 12.3 Degree of Total Leverage

> Two levers in a row multiply their effects, and each has been measured.

Think of two levers joined end to end. A push on the first moves the second, and the second lifts the weight. The printing unit has two such levers. Operating leverage turns a change in sales into a larger change in EBIT. Financial leverage turns a change in EBIT into a larger change in earnings per share. Chapter 11 measured the first lever with the degree of operating leverage.^3 Section 12.2 measured the second. What does the whole chain do?

^3: Chapter 11, 'Operating Leverage and Break-even Analysis', section 11.3 'Degree of Operating Leverage', measured the first link in total leverage.

> The table follows one rise in sales through both levers.

The table follows the rise from 8,000 to 9,000 packs. Read each row from left to right: the item, its value at 8,000 packs, its value at 9,000 packs, and the percentage change. Sales rise by 12.5%, EBIT by 50%, and earnings per share by 90.9%. Each change is larger than the one before.

:table One rise in sales through both levers
| Item | At 8,000 packs | At 9,000 packs | Change |
| Sales | Tk 720,000 | Tk 810,000 | 12.5% |
| EBIT | Tk 80,000 | Tk 120,000 | 50.0% |
| Earnings per share | Tk 6.60 | Tk 12.60 | 90.9% |

> The figure shows the three changes as connected bars that grow.

To read the next figure, look at the three bars from left to right. The height of each bar is the percentage change in sales, in EBIT and in earnings per share. The lines between the bars show the multiplier from one to the next: 4.00 from sales to EBIT, and 1.82 from EBIT to earnings per share.

:fig Percentage changes in sales, EBIT and earnings per share, joined by the two degrees | ch12-fig01.svg

@ Degree of total leverage | the percentage change in earnings per share caused by a one percent change in sales

> The degree of total leverage measures the whole chain from sales to earnings per share.

The **degree of total leverage** is the percentage change in earnings per share caused by a one percent change in sales. In words: degree of total leverage equals the percentage change in earnings per share divided by the percentage change in sales. From the table, 90.9% ÷ 12.5% = 7.27. A one percent rise in sales therefore lifts earnings per share by about 7.27 percent.

> Because the levers are joined, the two degrees multiply.

The same number comes from the two degrees. The degree of operating leverage was 4.00, since the contribution margin of Tk 320,000 (8,000 packs at Tk 40) divided by EBIT of Tk 80,000 is 4.00. The degree of financial leverage was 1.8182. *Formula.* Degree of total leverage = degree of operating leverage × degree of financial leverage. *Steps.* 4.00 × 1.8182 = 7.2727. *Answer.* The degree of total leverage is 7.27. *Check.* A second route gives the same result: contribution margin ÷ [EBIT − I − Dp ÷ (1 − T)] = 320,000 ÷ 44,000 = 7.27. Also 7.27 × 12.5% = 90.9%, which agrees with the table.

> The lever works downward too, and the fall is equally sharp.

Now apply the lever to a fall. At 7,000 packs, sales fall by 12.5%. The contribution margin is 7,000 × Tk 40 = Tk 280,000, and EBIT is 280,000 − 240,000 = Tk 40,000, a fall of 50%. Profit before tax is 40,000 − 20,000 = Tk 20,000; tax is Tk 5,000; profit after tax is Tk 15,000; less the preferred dividend of Tk 12,000 leaves Tk 3,000. Earnings per share is 3,000 ÷ 5,000 = Tk 0.60, a fall of 90.9%. The same 12.5% change in sales that nearly doubled earnings per share has almost wiped it out.

> The section's ideas are the product rule and the downward effect.

*Before moving on.* The degree of total leverage is the percentage change in earnings per share for a one percent change in sales, and it equals the degree of operating leverage times the degree of financial leverage. For the printing unit it is 7.27, and it works downward as strongly as upward.

* * *

## 12.4 Leverage and the Risk of a Firm

> The two kinds of risk map onto the two levers.

Business risk is the risk that operating profit varies, and operating leverage raises it. Financial risk is the extra risk to owners from borrowing, and financial leverage raises it. Total leverage joins them, so the degree of total leverage is a rough measure of the total risk that owners of common stock carry. A higher number means a wider swing in earnings per share for the same change in sales.

> A business can choose its financing more freely than its trade.

The two levers are not equally easy to change. The trade fixes much of a business's operating leverage: a printing unit needs machines whatever the owners prefer. The financing is a choice. A business with a high degree of operating leverage may therefore choose to borrow little, to keep the total from growing too large. A business with steady sales and little operating leverage can bear more borrowing.

> The section's idea is that total leverage is a measure of total risk.

*Before moving on.* Total leverage joins business risk and financial risk. Because the financing is a choice, owners can lower the total by borrowing less.

* * *

## Worked Problem: Debt Replaced by Equity

> A reshaped problem tests the same method on two financing plans.

An illustrative business, not the case file, has EBIT of Tk 80,000, a contribution margin of Tk 240,000 and no preferred stock; the tax rate is 25%. Under Plan A it borrows Tk 200,000 at 10% (interest Tk 20,000) and has 5,000 common shares. Under Plan B it replaces the loan by selling 2,000 more common shares at Tk 100 each, giving 7,000 shares and no interest. We compare the plans.

> Both plans are worked from EBIT down to earnings per share.

*Given.* The data above. *Find.* Earnings per share, the degree of financial leverage and the degree of total leverage for each plan, then the effect of a 50% change in EBIT. *Steps for Plan A.* Earnings per share = (80,000 − 20,000) × 0.75 ÷ 5,000 = 45,000 ÷ 5,000 = Tk 9.00. Degree of financial leverage = 80,000 ÷ 60,000 = 1.33. The degree of operating leverage is 240,000 ÷ 80,000 = 3.00, so the degree of total leverage is 3.00 × 1.33 = 4.00. *Steps for Plan B.* Earnings per share = 80,000 × 0.75 ÷ 7,000 = 60,000 ÷ 7,000 = Tk 8.57. The degree of financial leverage is 80,000 ÷ 80,000 = 1.00, and the degree of total leverage is 3.00 × 1.00 = 3.00.

> The table shows what each plan does when EBIT changes by half.

The table lists earnings per share at three levels of EBIT. Read each row from left to right: the level of EBIT, then the earnings per share and the change for each plan.

:table Earnings per share under the two plans
| EBIT | Plan A | Plan A change | Plan B | Plan B change |
| Tk 40,000 | Tk 3.00 | −66.7% | Tk 4.29 | −50.0% |
| Tk 80,000 | Tk 9.00 | 0% | Tk 8.57 | 0% |
| Tk 120,000 | Tk 15.00 | +66.7% | Tk 12.86 | +50.0% |

> Plan A gives more in good years and less in poor years, so it carries more risk.

*Answer.* Plan A pays more at the base level, Tk 9.00 against Tk 8.57, and swings by 66.7% for a 50% change in EBIT, against 50.0% for Plan B. *Check.* Each swing equals the degree of financial leverage times 50%: 1.33 × 50% = 66.7% and 1.00 × 50% = 50%. Neither plan is right in every case. Plan A suits owners who accept more swing for a higher base figure, and Plan B suits owners who value steadiness.

* * *

## Summary

> Fixed financing charges magnify earnings per share, and two degrees measure the effect.

A fixed financing charge is interest or preferred dividend owed at any level of EBIT. Financial leverage is the extra swing in earnings per share that such charges cause, and the degree of financial leverage measures it. The degree of total leverage equals the degree of operating leverage times the degree of financial leverage. For the printing unit the three degrees are 4.00, 1.82 and 7.27, and all three work downward as well as upward.

## Think It Through

:q 12.t1 | A business has a high degree of operating leverage. Explain in plain words why its owners might choose to borrow little.

## Where People Go Wrong

> A common error is to think that borrowing always raises profit for owners.

*Error:* "Borrowing always increases earnings per share." It does so only while EBIT is high enough to cover the charges. In a poor year the same borrowing lowers earnings per share more than EBIT falls.

> A second error is to treat a preferred dividend like interest.

*Error:* "Preferred dividend is deducted before tax." Interest is deducted before tax, but the preferred dividend is paid out of profit after tax. That is why the formula divides it by (1 − T).

> A third error is to add the two degrees.

*Error:* "Total leverage is operating leverage plus financial leverage." The degrees multiply: 4.00 × 1.82 = 7.27, and not 5.82.

> A fourth error is to treat a degree as a fixed property of the business.

*Error:* "The degree of financial leverage never changes." It is found at one level of EBIT and one financing plan, and it changes when either changes.

## In History

> A record debt-financed buyout showed how borrowing magnifies gains and losses.

In 1988 Kohlberg Kravis Roberts, an American investment firm usually called KKR, won a bidding contest to buy RJR Nabisco, a large American maker of tobacco and food products. The price was about 25 billion dollars, or 109 dollars a share, the largest takeover of its time, and most of it was paid for with borrowed money.^4 Such a purchase is called a leveraged buyout. The new owners hoped that profit from the business would exceed the interest, which would give them large gains on the small part they had paid themselves.

> The heavy debt forced the business to sell parts of itself.

The lever turned out to be heavy. With so much interest to pay every year, the business sold parts of itself in the following years to reduce its debt. The episode is told in the book *Barbarians at the Gate*, by Bryan Burrough and John Helyar. It remains a plain lesson in the two edges of financial leverage: the owners gain when profit is high and carry a heavy burden when it is not.

^4: Sources describe the price as about 25 billion dollars; the amount differs slightly with the way debt is counted.

## Review Questions

:q 12.1 | A business has EBIT of Tk 150,000, interest of Tk 30,000, a preferred dividend of Tk 18,000, a tax rate of 25% and 10,000 common shares. Find earnings per share.

:q 12.2 | For the business in question 12.1, find the degree of financial leverage.

:q 12.3 | A business has a degree of operating leverage of 2.50 and a degree of financial leverage of 1.60. Find its degree of total leverage.

:q 12.4 | The degree of total leverage is 4.00 and sales rise by 10%. By about what percentage does earnings per share rise? If earnings per share was Tk 5.00, what is it now?

:q 12.5 | Two plans give the same EBIT of Tk 100,000 and ignore tax. Plan X pays interest of Tk 40,000 and has 4,000 shares. Plan Y pays no interest and has 8,000 shares. Compare earnings per share at EBIT of Tk 100,000 and Tk 60,000, and say which plan is riskier.

:read Bryan Burrough and John Helyar, Barbarians at the Gate: The Fall of RJR Nabisco, 1990
