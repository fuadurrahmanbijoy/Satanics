:chapter I | Money, Finance and the Firm
:mood Where does a business find its money, and what does it do with it?
:desc This chapter introduces finance: what it is, where it sits among the main kinds of work in a business, and how money moves between owners, lenders and the business. A family bookshop in Dhaka supplies the figures, and a banking house in Florence supplies the history.
:plate ch01-plate.svg | A money-changer at his counter, with coin scales, stacked coins and an open ledger, 1850s

> A stall owner has a full table of goods but too little money to buy more.
Picture a woman who sells vegetables at a market stall. On Monday evening her table still holds tomatoes, onions and gourds, and at the prices on her sign they are worth Tk 5,000.^1 Yet at five o'clock on Tuesday morning, at the wholesale market, her purse holds only Tk 1,200, and the onions she needs cost Tk 2,000. The stall is full, and she still cannot buy what she needs. Her trouble is older than any bank: the goods a person owns and the money a person holds are not the same thing.

^1: Tk is the written short form of taka, the money of Bangladesh. The book writes amounts as Tk 5,000, with a comma after each group of three digits.

> Her choices raise three questions, and finance exists to answer them.
She has choices. She may buy fewer onions. She may ask a cousin for a loan until Friday. She may sell the tomatoes cheaply this evening to receive money at once. Each choice raises the same questions. Where will the money come from? What will it be spent on? What will she owe, and to whom, afterwards? These questions are the beginning of finance. This chapter turns them into plain ideas and gives each idea a name.

> You need nothing beforehand except your own experience of spending and borrowing.
*You will need:* nothing beyond your own experience of spending, saving and borrowing. Every other word is explained when it first appears.

> Each idea is built in the same order, and small signs help you follow it.
This book builds each idea in the same order: a plain statement, an example, a rule, and then the limits of the rule. A short note in the side column sums up each paragraph in one line. When a new term appears, it is printed in bold, defined at once and repeated in the side column; a fuller meaning is in the glossary. Questions marked Pause let you test yourself before reading on, and their answers are given at the back. This first chapter goes slowly on purpose, because every term in it is new.

> The chapter takes three steps, from the idea of finance to the flow of funds.
The chapter takes three steps. Section 1.1 explains what finance is. Section 1.2 shows where finance sits among the kinds of work that a business performs. Section 1.3 follows money from the people who supply it to the things the business buys with it. A running case, the bookshop Meghna and Sons in Dhaka, appears from section 1.2 onward.

* * *

## 1.1 What Finance Is

> Every household already practises finance on a small scale.
Begin with your own week. Money reaches you from somewhere: an allowance, a wage, a gift from a relative. Money leaves you for a purpose: bus fares, food, a phone, fees. Sometimes you keep part of it for later. Sometimes you borrow from a friend and promise to repay. In each case, someone decides where money should come from and where it should go. That someone is practising finance, on a small scale.

@! Go slowly here.
@ Finance | The work of finding money and deciding how to use it, so a business or person can reach chosen aims.
> Finance is finding money and deciding how to use it.
**Finance** is the work of finding money and deciding how to use it, so that a business or a person can reach chosen aims. The stall owner who asks her cousin for Tk 800 and decides to spend it on onions is doing finance twice: once to find the money, and once to choose its use.

> Finance has two halves, and the same two halves appear in every business.
Words first, then numbers. The first half asks: where can money be found? The second half asks: what is the best use of it? Suppose the Tk 800 buys onions that she sells for Tk 1,000. She finds Tk 800 and uses Tk 800. After she repays her cousin, she keeps Tk 200. The example is small on purpose, because the same two halves govern a bookshop that handles millions of taka.

> Finance is not only for banks, not the same as having money, and not a promise of good choices.
Finance has limits worth knowing. It is not only for banks or very large businesses; the stall owner uses it every day. It is also not the same as having money: a business with no money may need finance more than a rich one. And finance is a method for choosing, not a promise that every choice will be right, because a loan used badly must still be repaid.

> Each person connected to a business sees finance from a different side.
The viewpoint changes with the person. The owner wants the business to grow. A lender wants to be repaid on the agreed day. An employee wants wages paid on time. A customer wants the shop to be open next month. All four depend on how well the money has been found and used.

@! Go slowly here.
@ Funds | Money that a business has available to spend, save or invest.
> Funds are money that is available to use.
**Funds** are money that a business has available to spend, save or invest. To invest means to use money now in the hope of earning more later. Funds may be notes in a purse or a balance held at a bank. On a morning when the stall owner's purse holds Tk 1,200, her funds are Tk 1,200. The tomatoes on her table are not funds, because she cannot spend a tomato at the wholesale market until it has been sold.

@ Cash flow | Money moving into or out of a business during a period.
> Cash flow is money in motion over a period of time.
**Cash flow** is money moving into or out of a business during a period. A period is any stretch of time, such as a day, a month or a year. On Monday customers pay the stall owner Tk 3,000, which is a cash flow into the business, and she pays Tk 2,000 to the wholesaler, which is a cash flow out. Funds are measured at one moment; cash flow is measured over a stretch of time.

> The table sets the two ideas side by side.
The table below compares the two ideas. Read each row from left to right: the first column names the idea, the second says how it is measured, and the third gives an example from the stall.

:table Funds and cash flow compared
| Idea | How it is measured | Example from the stall |
| Funds | At one moment | Tk 1,200 in her purse at five in the morning |
| Cash flow | Over a period | Tk 3,000 received and Tk 2,000 paid during Monday |

@ Profit | Word in use. In daily life, the money you gain from a sale. In business, what a sale earns after the costs of making it, counted when the sale is made, even if the customer pays later.
> A sale and its cash flow can fall in different months.
A sale and a cash flow are different events. Suppose a customer takes goods worth Tk 5,000 on 28 June and promises to pay on 28 July. The sale happens in June, but the cash flow into the business happens in July. In the business sense of the word, the profit from that sale is counted in June, while the money reaches the business in July. A business can therefore show a good profit and still lack money to pay wages on Friday. This is why finance watches cash flow closely.

:pause 1.p1 | A tailor accepts an order worth Tk 3,000 today. The customer promises to pay when the suit is ready next week. Is there a cash flow into the business today? Give a reason.

@ Wealth | The total value of what a person or business owns, after taking away what is owed.
> Wealth is what is owned after taking away what is owed.
**Wealth** is the total value of what a person or business owns, after taking away what is owed. Suppose the stall owner owns a table, scales and Tk 1,200 in cash, worth Tk 4,000 together, and owes her cousin Tk 800. Her wealth is Tk 4,000 less Tk 800, which is Tk 3,200. Wealth can be large while funds are small: her table is part of her wealth, but it is not funds.

> The section ends with a short recap.
*Before moving on.* Finance is the work of finding money and deciding how to use it. Funds are money available at one moment, cash flow is money moving over a period, and wealth is what is owned after taking away what is owed. *You should now be able to say* in one sentence what finance is, and why owning goods is not the same as having funds.

* * *

## 1.2 Finance Among the Business Functions

> A bookshop needs more than one kind of work, and someone must look after each.
Think of a bookshop on a busy street. Someone chooses and buys the books. Someone serves the readers. Someone records what was sold. Someone makes sure the shop can pay its suppliers. These are different kinds of work, and no one person can do all of them well at all times. Where does the work of finance sit among them?

@ Business function | One main kind of work in a business, such as selling, making or managing money.
> A business function is one main kind of work in a business.
A **business function** is one main kind of work in a business, such as selling, making or managing money. In a bookshop, buying books from publishers is one function, selling to readers is another, and looking after money is a third. Larger businesses give each function its own team; a small business may give several functions to one person.

@ Account | Word in use. In daily life, a record of money in a bank. In accounting, a named record of one kind of item, such as Cash or Sales.
> The running case shows two functions shared between two brothers.
:case Case file, illustrative. Meghna and Sons is a family-run bookshop in Dhaka, founded on 12 January 1998 by Abdur Rahim Chowdhury. Since 2019 it has been run by his sons Imran and Tanvir. Imran is responsible for the shop and buying. Tanvir is responsible for accounts and money.

> Managers decide; finance supplies the money to carry out each decision and the facts to judge it.
Managers decide what a business will do. They choose goods, prices, staff and suppliers. Every such decision has a money side. Suppose a bookshop wishes to add a shelf of stationery. Someone must find the money for the new goods and the shelf. Someone must judge whether the new goods will bring in enough to repay that money. Finance serves the other functions in this way, by supplying funds and by judging the money side of their decisions. It informs the decision; it does not replace it.

> Finance depends on the other functions as much as they depend on it.
The dependence runs both ways. A business with perfect money records but no customers will fail, because finance cannot create sales. In a larger business, the person who leads this function is called the financial manager; Chapter 2, The Financial Manager's Work, describes the role. In the running case, one brother holds that duty beside his work on accounts.

> Finance is close to accounting and to economics, but its main question differs.
Two nearby subjects are often confused with finance. Accounting is the work of recording and reporting what has happened to the money of a business. Economics studies how people and societies choose when money and resources are limited. Finance draws on both, but its main question looks forward: what should we do with money, and where do we find it? The table below sets the three side by side, using a tailor's shop. Read each row from left to right: the subject, the question it asks, and an example.

:table Finance, accounting and economics compared
| Subject | Main question | Example at a tailor's shop |
| Accounting | What has happened to our money? | Recording that Tk 6,000 was received this month |
| Finance | What should we do with money, and where do we find it? | Deciding whether to borrow to buy a second sewing machine |
| Economics | How do people and societies choose when resources are limited? | Why the price of cloth rises when cloth is scarce |

> The three subjects overlap, so a real decision often uses all three.
The three overlap. The tailor uses accounting records to see how much money was received, uses economics to understand why cloth costs more, and uses finance to decide about the machine. A common confusion is to think that finance is only keeping records. Records belong to accounting; finance uses them to make decisions about the future.

> The section ends with a short recap.
*Before moving on.* A business function is one main kind of work in a business. Finance is one function: it supplies funds to the others and judges the money side of their decisions. It differs from accounting, which records what has happened, and from economics, which studies choice in society.

* * *

## 1.3 Where Funds Come From and Where They Go

> Every book on a shelf was bought with someone's money, so whose money was it?
Walk into a bookshop and look along the shelves. Every book there was bought with money before it was sold. Somebody supplied that money; the shop did not create it. In any business, then, two questions come before all others: who supplied the money, and what was it used for?

> The case file gives the figures that the rest of the section sorts.
:case Case file, illustrative. At 1 January 2024, Meghna and Sons held stock of Tk 1,850,000, a cash and bank balance of Tk 240,000 and fittings of Tk 310,000, which together come to Tk 2,400,000. The funds came from a bank loan of Tk 600,000 at 10% a year and from the family's own funds of Tk 1,800,000. Sales in 2023 were Tk 7,200,000.

> Two words in the case have special meanings in the shop.
Two words in the case file need care. Stock here means the books held for sale. Fittings means the shelves and counters fixed in the shop. Both belong to the shop, and both were bought with money.

@! Go slowly here.
@ Source of funds | A place a business gets money from, such as its owners or a lender.
> A source of funds is where the money came from.
A **source of funds** is a place a business gets money from, such as its owners or a lender. Meghna and Sons has two: the family and a bank. Each supplied part of the Tk 2,400,000.

@ Use of funds | A purpose a business spends money on, such as stock or equipment.
> A use of funds is what the money was spent on.
A **use of funds** is a purpose a business spends money on, such as stock or equipment. The shop used funds for books to sell and for shelves and counters. Keeping money at the bank is also a use, because the business chose to hold it for later.

@ Asset | Something of value that a business owns and uses to earn money.
> An asset is something the business owns that helps it earn money.
An **asset** is something of value that a business owns and uses to earn money. The shop's books, its shelves and counters, and its cash and bank balance are assets. Each asset is the result of a use of funds.

> The rule: on any one date, the money obtained equals the assets held.
Now the rule that joins the two halves. On any one date, the total from all sources of funds equals the total of the assets that those funds bought or kept. For Meghna and Sons, add the sources: Tk 600,000 plus Tk 1,800,000 is Tk 2,400,000. Add the assets: Tk 1,850,000 plus Tk 240,000 plus Tk 310,000 is also Tk 2,400,000. The two totals agree.

> A source does not choose its use, and the rule holds for one date only.
Two confusions are common. First, a source does not choose the use. The bank lent Tk 600,000 without saying whether it should buy books or shelves, because money from any source is the same money once it is in the business. Second, the rule describes one date. The totals will change when the business borrows more, repays a loan or earns a profit, and they will agree again on the new date.

@ Equity | Money put in by the owners, who share the business profit or loss.
@ Capital | Word in use. In daily life, the main city of a country, or a large letter. In finance, money put into a business to start or run it.
> Equity is the owners' money, and the owners share profit or loss.
**Equity** is money put in by the owners, who share the business profit or loss. The family's Tk 1,800,000 is equity. Money from owners is often called capital. Owners are not promised a fixed payment: if the shop earns a profit they share it, and if it makes a loss they bear it.

@ Debt | Money borrowed that must be repaid, with an extra charge for using it.
> Debt is borrowed money that must be repaid with an extra charge.
**Debt** is money borrowed that must be repaid, with an extra charge for using it. The bank loan of Tk 600,000 is debt, and its charge is 10% a year.^2 The lender is promised repayment on agreed dates, whether the shop earns a profit or not.

^2: A charge of 10% a year means Tk 10 for each Tk 100 borrowed, for each year the money is used. Later chapters show how the charge is calculated.

> The table compares equity and debt on four points.
The table below compares equity and debt. Read down a column to see one kind of source; read across a row to compare the two on one point.

:table Equity and debt compared
| Point | Equity | Debt |
| Who supplies it | The owners | A lender |
| Repayment | No fixed repayment; owners share profit or loss | Must be repaid on agreed dates |
| Extra charge | None promised; a share of any profit | Agreed in advance: 10% a year |
| At Meghna and Sons | Tk 1,800,000 from the family | Tk 600,000 from the bank |

:pause 1.p2 | A new bakery begins with Tk 300,000 of the owner's savings and a Tk 100,000 loan from a bank. Which amount is equity and which is debt? Who must be repaid on agreed dates?

@ Liability | An amount a business owes to someone else.
> A liability is any amount the business owes.
A **liability** is an amount a business owes to someone else. The bank loan of Tk 600,000 is a liability. Debt is one kind of liability; an unpaid bill to a supplier is another. Now the wealth of the family in the shop can be found: assets of Tk 2,400,000 less the liability of Tk 600,000 leave Tk 1,800,000, which equals the family's equity.

@ Financial market | A place or network where buyers and sellers trade money, loans and ownership parts of businesses.
> A financial market is where money, loans and ownership parts are traded.
A **financial market** is a place or network where buyers and sellers trade money, loans and ownership parts of businesses. A bank branch where one borrower meets one lender is a very small example. Large markets let a business find many sources at once. Chapter 13, Valuing Bonds, and Chapter 14, Valuing Common and Preferred Stock, show how such trades set prices.

> The figure shows the shop's flows of money in one picture.
The figure below shows the same flows as a picture. Read it from left to right. A solid arrow shows money going into the shop from its owners or its lender. A dashed arrow shows what goes back to them. The arrow on the right shows the shop spending funds on assets. Each arrow carries a label in plain words, and the amounts match the case file.

:fig Funds flowing between the owners, the lender, the shop and its assets, Meghna and Sons, 1 January 2024 | ch01-fig01.svg

> The section ends with a short recap.
*Before moving on.* A source of funds is where money comes from, a use of funds is what it buys or keeps, and assets are the things the business owns. Equity is the owners' money and debt is borrowed money, and on any one date the sources equal the assets. *You should now be able to say* which part of a business's funds is equity, which is debt, and what each one bought.

* * *

## Worked Case: Sources and Uses at Meghna and Sons

> The worked case sorts each figure into its place.
:case Case file, illustrative. *Situation.* At 1 January 2024, Meghna and Sons records stock of Tk 1,850,000, a cash and bank balance of Tk 240,000 and fittings of Tk 310,000. It owes a bank loan of Tk 600,000 at 10% a year, and the family's own funds are Tk 1,800,000. Sales in 2023 were Tk 7,200,000.

> Three tasks are set: sort, compare, and find wealth.
*Question.* First, which figures are sources of funds and which are uses? Second, do the totals agree? Third, what is the family's wealth in the shop, and does the sales figure belong in the sorting?

> The first step asks of each figure: did the money come from here, or go to here?
*Reasoning.* Begin by sorting. The bank loan and the family's own funds answer the question "where did the money come from?", so they are sources: debt of Tk 600,000 and equity of Tk 1,800,000. Stock, the cash and bank balance and fittings answer the question "what did the money buy or keep?", so they are uses, and each one is an asset.

> The second step adds each side and compares the totals.
Next, compare the totals. Sources: Tk 600,000 plus Tk 1,800,000 is Tk 2,400,000. Assets: Tk 1,850,000 plus Tk 240,000 plus Tk 310,000 is Tk 2,400,000. Then find wealth. Assets of Tk 2,400,000 less the liability of Tk 600,000 leave Tk 1,800,000.

> The sales figure describes a year, while the sorting describes one date.
Last, consider sales. The figure of Tk 7,200,000 describes the whole of 2023, which is a period. The sorting describes one date, 1 January 2024. Sales therefore do not belong in the list of sources or uses. They belong with the ideas of period and cash flow, and sales are not the same as cash received if customers pay later.

> The conclusion states what the sorting shows.
*Conclusion.* Two sources supplied the shop: debt of Tk 600,000, which is one quarter of the total, and equity of Tk 1,800,000, which is three quarters. Three assets hold the funds: stock, the cash and bank balance, and fittings. The family's wealth in the shop is Tk 1,800,000.

> The check confirms that nothing is missing or counted twice.
*Check.* The totals agree at Tk 2,400,000, and the wealth equals the equity. If the totals had differed, a figure would be missing or counted twice. Note also that the cash and bank balance sits among the assets and not among the sources: it is money held, not money obtained.

* * *

## Summary

> The chapter in brief.
Finance is the work of finding money and deciding how to use it. Funds are money available at one moment, cash flow is money moving over a period, and wealth is what is owned after taking away what is owed. Finance is one business function, beside selling, buying and managing people, and it differs from accounting and economics. A business obtains funds from sources, equity from owners and debt from lenders, and uses them on assets. On any one date, the sources equal the assets.

## Think It Through

:q 1.t1 | A cinema owner takes Tk 40,000 in ticket sales, owes Tk 25,000 for film hire next month and pays a Tk 10,000 loan instalment. Classify each of the three movements, and say which are cash flows today.
:q 1.t2 | What is the net cash flow for the cinema owner today? Which of the three movements is a liability, and what will it become next month?

## Where People Go Wrong

> Mistake: finance belongs only to banks and large businesses.
Some students believe that finance belongs only to banks and large businesses. In fact, every stall owner who finds money and decides how to use it practises finance. Size changes the amounts, not the questions.

> Mistake: goods on the shelves count as funds.
Some students count the books on the shelves as funds. Books are assets; they become funds only when they are sold and paid for. Meghna and Sons holds stock of Tk 1,850,000 but a cash and bank balance of only Tk 240,000.

> Mistake: profit and cash flow are the same thing.
A sale made in June and paid for in July creates profit in June, but its cash flow arrives in July. The two measure different things, and a business needs to watch both.

> Mistake: equity is free money, or debt is always bad.
Owners supply equity, but they expect a share of any profit, so equity is not free. Debt carries an agreed charge and must be repaid, but it lets a business obtain funds that its owners cannot supply. Neither is good or bad in itself; each comes with terms.

## In History

> A Florentine banking house moved money between cities without moving coin.
In 1397, in Florence, a trading city in what is now Italy, a merchant named Giovanni di Bicci de' Medici founded the Medici Bank. Before founding it he had worked in banking in Rome. His bank grew to have branches in other cities, among them Rome, Bruges and London, and it lasted until 1494.

> The bill of exchange solved the problem of carrying coin from city to city.
A merchant of that time faced a problem: carrying coin from one city to another was slow and dangerous. The bank offered a solution, the bill of exchange. A merchant paid money to the bank in one city and received a written order. The order told a branch or agent in another city to pay an agreed sum there. No coin travelled; only the paper did. The bank earned its charge from the difference in the rates at which currencies were exchanged.

> In this chapter's words, the bank gathered sources of funds and put them to use.
Seen with this chapter's words, the bank received money from depositors, which was a source of funds, and used it to make loans and to finance trade, which were uses. It also moved funds between cities, so that merchants did not have to. The historian Raymond de Roover told the story in *The Rise and Decline of the Medici Bank, 1397-1494* (1963). The bank ended in 1494, when the Medici were expelled from Florence.

## Review Questions

:q 1.1 | A stall owner has Tk 1,200 in her purse and a table full of vegetables. In your own words, explain what finance means for her. Name one thing she must find and one thing she must decide.
:q 1.2 | A tailor records the money received each month and also decides whether to borrow to buy a second sewing machine. Which task is accounting and which is finance? Explain the difference.
:q 1.3 | A new bakery begins with the owner's savings and a loan. Name its two sources of funds, say which is equity and which is debt, and give two uses of the funds.
:q 1.4 | A customer takes goods on 28 June and pays on 28 July. Explain why the sale and the cash flow fall in different months.
:q 1.5 | On Monday customers pay the stall owner Tk 3,000, and she pays the wholesaler Tk 2,000. State the cash flow in, the cash flow out and the net movement.
:q 1.6 | The same stall owner now takes a loan of Tk 800 from her cousin. Is this a source or a use of funds? Is it equity or debt? What does she owe afterwards?
:q 1.7 | A school canteen is run by a committee, using money from a school fund. Name one source of funds and one use of funds for the canteen.
:q 1.8 | A small clinic is funded by its owners' savings and a bank loan. Name its sources of funds and two assets it might hold. Where does finance sit among the clinic's business functions, and what does it do for the others?

:read Raymond de Roover, The Rise and Decline of the Medici Bank, 1397-1494, 1963
