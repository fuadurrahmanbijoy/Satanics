:chapter II | The Financial Manager's Work
:mood Who decides where the money goes, and how do they decide well?
:desc This chapter introduces the financial manager and the three decisions this person makes about money: what to buy, how to pay for it, and how much profit to pay out. It ends by showing how these decisions affect the daily success of a business. A bookshop in Dhaka supplies the figures, and a London bank supplies a warning from history.
:plate ch02-plate.svg | A counting-house master reviewing papers at a standing desk while two clerks write in tall ledgers

> One sum of money has three fair claims on it, and only one can win.
Suppose you hold Tk 100,000 that you do not need to spend this month. Three people ask for it. A friend wants to start a juice stall and needs equipment. Your parents would like a share, because you could not have saved it without them. A bank is waiting for a loan to be repaid, and every month of waiting adds a charge. Each request is reasonable, and the money cannot go to all three. Who should receive it?

> Every business meets this puzzle on a larger scale, and someone must answer it.
A business meets the same puzzle in larger form. It earns a profit, and its owners, its lenders and its own plans for growth all ask for the money. Somebody must hear the claims, weigh them and choose. That person does not guess. The person follows a method, and the method has three parts. This chapter names the person, names the three parts, and shows how the choices appear in the daily life of a shop.

> You need the idea of sources and uses of funds from Chapter 1.
*You will need:* Chapter 1, section 1.3, "Where Funds Come From and Where They Go": sources and uses of funds, equity and debt. If those words feel uncertain, read that section again before starting.

> The chapter has three sections, a worked case and a short history.
Section 2.1 describes the person who does finance in a business. Section 2.2 explains the three decisions this person makes, and it goes slowly, because the three decisions sound alike. Section 2.3 shows how finance affects the daily success of a business. A worked case then follows one day of decisions at Meghna and Sons, and a history shows what can happen when control fails.

* * *

## 2.1 The Financial Manager's Role

> Recall: business function, Chapter 1, section 1.2, "Finance Among the Business Functions".
> A small shop shows that a role can exist before it has a title.
:case Case file, illustrative. Meghna and Sons is a family-run bookshop in Dhaka. Since 2019 it has been run by Imran, who is responsible for the shop and buying, and by Tanvir, who is responsible for accounts and money.

> Tanvir holds the money function, and a name exists for the person who does so.
In Chapter 1 we called finance one business function. Someone must perform it, even in a small shop. In the case file above, Tanvir does so, beside his work on accounts. The person who holds this duty has a name.

@ Financial manager | The person who plans, raises and controls the money of a business.
> The financial manager is whoever plans, raises and controls the money.
A **financial manager** is the person who plans, raises and controls the money of a business. In a small shop this may be one brother. In a large business it may be a team led by a senior person with a grander title, such as chief financial officer.^1 The title varies from business to business. The duties are what count.

^1: Chief financial officer is the title of the most senior person in charge of finance in a large business. This book uses "financial manager" for the role in every size of business.

> Each of the three verbs describes a separate part of the duty.
Look closely at the three verbs. To plan is to decide in advance what money will be needed and when. To raise is to find the money, from owners or from lenders. To control is to check that money is used as intended, and to correct matters when it is not. A tailor who foresees a large order, borrows to buy cloth and later compares what she spent with what she expected performs all three duties, though nobody has given her a title.

@ Financial planning | Deciding in advance how much money a business will need and when.
> Financial planning decides in advance how much money is needed and when.
**Financial planning** means deciding in advance how much money a business will need and when. Suppose the tailor expects to pay Tk 30,000 for cloth on 1 March and Tk 8,000 for rent on 5 March. By 20 February she knows she needs Tk 38,000 in the first week of March, and she has time to arrange it. Without a plan she learns of the shortage on the day the supplier asks for payment. A plan also gives a standard to check against later.

@ Financial control | Checking that money is spent and recorded as planned, and acting when it is not.
> Financial control compares what happened with the plan and acts on any difference.
**Financial control** means checking that money is spent and recorded as planned, and acting when it is not. Suppose the tailor planned Tk 30,000 for cloth but the bill is Tk 36,000. Control notices the difference of Tk 6,000 and asks why. Perhaps cloth became more expensive, or perhaps she bought cloth she does not need. Then comes the act: change a price, change a supplier or change the plan. Control that finds a difference and does nothing has no value.

> The owner, the lender and the employee each depend on the financial manager in a different way.
The viewpoint changes with the person. Owners rely on the financial manager to use their money wisely and to report on it honestly. A lender relies on the manager to repay on the agreed day. Employees rely on the manager to make sure money is available for wages. The financial manager therefore answers to several groups at once, which is part of what makes the work demanding.

> Recall: finance beside accounting, Chapter 1, section 1.2, "Finance Among the Business Functions".
> The role has limits: it is not accounting, and it does not replace the other managers.
The role has limits. The financial manager is not the accountant of Chapter 1, section 1.2. The accountant records what has happened, while the financial manager uses those records to decide what should happen next. The financial manager also does not choose which books the shop stocks; Imran does. The role supplies money and judges its use, but it does not run the other functions. In a very small business one person may hold both roles, though the two kinds of work remain different.

> The section ends with a short recap.
*Before moving on.* A financial manager is the person who plans, raises and controls the money of a business, whatever the title. Planning decides in advance how much money is needed and when. Control checks what happened against the plan and acts on the difference. *You should now be able to say* what each of the three verbs means and give a small example of each.

* * *

## 2.2 The Three Core Decisions

@! Go slowly here.
> Even a household faces three separate questions about the same money.
Begin at home. A household has saved Tk 60,000 and has some spare income each month. It faces three questions. First, what should we buy with our money? Perhaps a fridge. Second, how should we pay for it: from our savings, or by borrowing from a relative? Third, how much of our spare income should we give to the grandparents, and how much should we keep? These questions sound alike, because each one concerns the same money. Yet each asks something different, and a household that mixes them up chooses badly.

> A business asks the same three questions, and each has a name.
A business asks the same three questions, and each question has a name. We take them one at a time, because the names are similar and the questions are not.

@ Investment decision | Choosing which long-lasting assets or projects a business should buy.
> The investment decision asks what to buy.
The first is the investment decision. The **investment decision** is choosing which long-lasting assets or projects a business should buy. A project is a planned piece of work that needs money, such as opening a second branch. A bakery that must choose between a new oven and a delivery van makes an investment decision, because either would serve the bakery for many years.

> The case file shows the investment decision at Meghna and Sons.
:case Case file, illustrative. On 10 February 2024 the owners of Meghna and Sons decided to open a stationery corner costing Tk 350,000. This is an investment decision: the corner is a long-lasting asset, bought to earn money over many years.

@ Stock | Word in use. In daily life, a supply of something kept for later use. In a shop, the goods held for sale. In finance, stock can also mean ownership parts of a company, taught in Chapter 14, "Valuing Common and Preferred Stock".
> The rule is that an investment commits money for a long time, so it is hard to reverse.
The rule is that an investment decision commits money to assets for a long time, so it is hard to undo. A corner, once built, cannot be returned to the supplier. There are two limits to the meaning. Here, investment means spending the business's own funds on its own assets, not saving in a bank. And a shorter-lived use of funds, such as the textbook stock that the shop buys before each school term, is treated in Chapter 15, "Working Capital and the Cash Cycle". The method for judging whether a project is worth buying is taught in Chapter 7, "Capital Budgeting: Decisions and Cash Flows".

> The first decision is complete: it asks what to buy.
So far, one idea only: the investment decision asks what to buy.

@ Financing decision | Choosing how to raise the money for purchases, from owners or lenders.
> The financing decision asks how to pay.
The second is the financing decision. The **financing decision** is choosing how to raise the money for purchases, from owners or lenders. Recall that equity is money from owners and debt is borrowed money. A bakery that buys an oven may pay from its owners' funds, take a bank loan, or use both. The purchase is the same in each case, but the way of paying is different.

> Recall: sources of funds, equity and debt, Chapter 1, section 1.3, "Where Funds Come From and Where They Go".
> The case file shows how the corner was paid for.
:case Case file, illustrative. The corner of Tk 350,000 is funded by Tk 150,000 of profit the business had kept and a new bank loan of Tk 200,000 at 10% a year. That choice is the financing decision. The yearly charge on the new loan, called interest, is Tk 20,000. After the new borrowing, the bank loan stands at Tk 800,000.

> A preview: the kept profit has a name, which this section gives a little further on.
The kept profit has a name that this section gives a little further on. For now, read it as owners' funds, which are a source of funds, while the loan is debt.

:pause 2.p1 | A bakery buys an oven for Tk 200,000. It pays Tk 80,000 from the owners' funds and borrows Tk 120,000. Which part of this is the investment decision, and which part is the financing decision?

> The two decisions use the same money but ask different questions.
Notice how the two decisions differ. Investment asks what to buy; financing asks how to pay. A loan with a low charge does not make a poor purchase wise, and a good purchase can still fail if it is paid for in a way the business cannot repay. A common slip is to answer "should we buy?" with "the loan is cheap". That answers the second question, not the first.

@ Dividend decision | Choosing how much profit to pay out to owners and how much to keep.
> The dividend decision asks how much profit goes to the owners.
The third is the dividend decision. The **dividend decision** is choosing how much profit to pay out to owners and how much to keep. A shopkeeper who earns a profit of Tk 90,000 may take Tk 30,000 home and leave Tk 60,000 in the business. Neither choice is wrong in itself. A payout rewards the owners now. Keeping profit leaves more to fund growth later, without asking a lender.

@ Dividend | A share of profit paid out to the owners of a business.
@ Retained earnings | Profit kept in the business instead of being paid out to owners.
> The part paid out is the dividend; the part kept is retained earnings.
The part of profit paid out is called a **dividend**, and the part kept is called **retained earnings**. In the shopkeeper's example, the dividend is Tk 30,000 and the retained earnings are Tk 60,000. A business owned by one family may call its payout a withdrawal. This book uses the word dividend for any share of profit paid to owners.

@ Profit | Word in use. In daily life, any money gained. In business, what is left of sales after all costs, and tax, are taken away.
> The case file records the dividend decision for 2023.
:case Case file, illustrative. Profit after tax for 2023 was Tk 480,000.^2 The family withdrawal, which is the dividend, was Tk 120,000, so the retained earnings were Tk 360,000.

^2: Tax is money that a business pays to the government on its profit. Profit after tax is the profit left once that payment has been made.

> Retained earnings link the dividend decision to the financing decision.
Retained earnings connect the third decision to the second. Profit that stays in the business still belongs to the owners, so it is a source of funds from the owners, which Chapter 1 called equity. It is also the easiest source to use, because nobody new must be asked. This is why the decisions cannot be fully separated: the more profit is paid out, the less is left to fund purchases, and the more the business may need to borrow. At Meghna and Sons, Tk 150,000 of the Tk 360,000 kept went into the corner. This is the kept profit that the financing paragraph above described.

:pause 2.p2 | A tailor earns a profit of Tk 90,000 and pays Tk 25,000 of it to her family, who own the shop. How much is the dividend, and how much are the retained earnings?

> The table compares the three decisions side by side.
The table below sets the three decisions side by side. Read each row from left to right: the decision, the question it asks, and the choice made at Meghna and Sons.

:table The three core decisions compared
| Decision | Question it asks | At Meghna and Sons |
| Investment | Which long-lasting assets should we buy? | A stationery corner costing Tk 350,000 |
| Financing | How should we raise the money? | Tk 150,000 of kept profit and a Tk 200,000 bank loan |
| Dividend | How much profit do we pay out, and how much do we keep? | Tk 120,000 paid out; Tk 360,000 kept |

> The figure shows the three decisions as three arrows around the funds of a business.
The figure below draws the same decisions as three arrows around a box of funds. Read it arrow by arrow. The arrow into the box shows money arriving from owners and lenders. The arrow to the right shows money leaving to buy assets. The dashed arrow downward shows money leaving as dividends. Each arrow carries the name of its decision in plain words.

:fig The three decisions as three arrows around the funds of a business | ch02-fig01.svg

> The section ends with a short recap.
*Before moving on.* The investment decision asks what to buy, the financing decision asks how to pay, and the dividend decision asks how much profit to pay out and how much to keep. Retained earnings, the profit kept, can fund purchases. *You should now be able to say* which of the three questions a given choice answers, and to give one example of each.

* * *

## 2.3 How Finance Shapes Business Success

> Choices matter because of what they do to a business every day.
Everything so far has described choices. Choices matter because of their effect on a business each day. A shop that buys what it cannot sell, or sells below what the goods cost, or cannot pay a supplier on time, will struggle however loyal its customers are. Three qualities show whether finance is serving the business well.

@ Operating efficiency | How little money and effort a business uses to produce each unit of sales.
> Operating efficiency measures how little is used for each unit of sales.
**Operating efficiency** means how little money and effort a business uses to produce each unit of sales. Suppose a tailor spends Tk 70 on cloth, thread and labour for every Tk 100 she sells, while a rival spends Tk 80 for the same Tk 100. The first tailor is more efficient. Size does not decide this: a small shop can be more efficient than a large one.

@ Liquidity | How easily a business can pay its bills on time from cash it has or can quickly raise.
> Liquidity is the ability to pay bills on time.
**Liquidity** means how easily a business can pay its bills on time from cash it has or can quickly raise. Weak liquidity disrupts daily work: a supplier refuses a delivery, wages are late, a chance to buy cheaply passes.

> The case file shows why stock is not the same as cash.
:case Case file, illustrative. At 1 January 2024, Meghna and Sons held stock of Tk 1,850,000 and a cash and bank balance of Tk 240,000. Books on the shelves cannot pay a supplier until they are sold, but the balance at the bank can.

@ Profitability | How much profit a business earns compared with the money invested or the sales made.
> Profitability compares profit with money invested or with sales.
**Profitability** means how much profit a business earns compared with the money invested or the sales made. A profit of Tk 20,000 on Tk 200,000 invested is 10% of the money invested. Compare ratios, not amounts, because a large profit can be a poor result on a very large investment.

> The case file gives the profit and sales of 2023.
:case Case file, illustrative. Profit after tax for 2023 was Tk 480,000, and sales in 2023 were Tk 7,200,000. The profit is about Tk 6.67 for each Tk 100 of sales.

> The three qualities can pull in different directions.
The three qualities can pull in different directions. Buying more stock may raise sales and profit, yet it spends cash and so lowers liquidity. The financial manager's work is to keep all three in view, and each of the three decisions of section 2.2 affects at least one of them.

> The section ends with a short recap.
*Before moving on.* Operating efficiency measures how little is used for each unit of sales. Liquidity measures the ability to pay bills on time. Profitability compares profit with the money invested or with sales. *You should now be able to say* which of the three a business lacks if it earns a profit but cannot pay its wages on time.

* * *

## Worked Case: Three Decisions at Meghna and Sons

> The worked case sets out the situation of 10 February 2024.
:case Case file, illustrative. *Situation.* On 10 February 2024 the owners of Meghna and Sons review the year 2023. Profit after tax was Tk 480,000, and the family withdrew Tk 120,000. The owners decide to open a stationery corner costing Tk 350,000. They fund it with Tk 150,000 of retained earnings and a new bank loan of Tk 200,000 at 10% a year. The other Tk 210,000 of retained earnings buys textbook stock before the new term.

> The questions ask for each decision, each amount and the cost of the loan.
*Question.* Which choice is the investment decision, which the financing decision and which the dividend decision? How much profit was kept? What does the new loan cost each year, and how large is the bank loan afterwards?

> The first step is the dividend decision, which fixes how much profit stays.
*Reasoning.* Begin with the profit. The family withdrew Tk 120,000, which is the dividend, so the retained earnings are Tk 480,000 less Tk 120,000, which is Tk 360,000. The choice of how much to pay out and how much to keep is the dividend decision.

> The next steps separate what is bought from how it is paid for.
Next, the corner. Opening it commits Tk 350,000 to a long-lasting asset, so this is the investment decision. Paying for it is a separate choice. The owners supply Tk 150,000 of retained earnings and a lender supplies Tk 200,000, and Tk 150,000 plus Tk 200,000 is Tk 350,000, which matches the cost. Choosing this mixture of owners and lender is the financing decision.

> The last steps count the remaining profit, the loan and its yearly charge.
Then count what remains. Tk 360,000 less Tk 150,000 leaves Tk 210,000 of retained earnings, which buys textbook stock. The bank loan was Tk 600,000, and the new loan adds Tk 200,000, so it becomes Tk 800,000. The yearly charge on the new loan is 10% of Tk 200,000, which is 10 divided by 100 times Tk 200,000, or Tk 20,000.

> The conclusion names each decision and the resulting figures.
*Conclusion.* The dividend decision kept Tk 360,000. The investment decision chose the corner at Tk 350,000. The financing decision paid for it with Tk 150,000 of retained earnings and a Tk 200,000 loan. The loan costs Tk 20,000 a year, and the bank loan after the new borrowing is Tk 800,000.

> The check confirms that the money is fully accounted for.
*Check.* The Tk 150,000 for the corner and the Tk 210,000 for stock add to Tk 360,000, so all retained earnings are used and none is counted twice. The two sources of the corner add to its cost. The loan grew by one third of its old size, from Tk 600,000 to Tk 800,000, which is a sensible rise for a purchase partly paid by borrowing.

* * *

## Summary

> The chapter in brief.
The financial manager plans, raises and controls the money of a business, and this duty exists in every business whatever the title. Three decisions make up the work. The investment decision chooses what to buy, the financing decision chooses how to pay, and the dividend decision chooses how much profit to pay out and how much to keep as retained earnings. The success of the business each day shows in its operating efficiency, liquidity and profitability.

## Think It Through

:q 2.t1 | A bakery has Tk 150,000 of spare profit and must weigh three options: a new oven, a payout to the owners, or repaying a loan. Name the decision type in each option.
:q 2.t2 | In the bakery, say what changes in its sources of funds if it repays the loan, and what changes if it pays the owners a dividend instead. Which choice leaves more profit inside the business?

## Where People Go Wrong

> Mistake: investment and financing are the same decision.
Some students treat buying an asset and paying for it as one decision. They are two. The first asks what to buy, and the second asks how to pay. A cheap loan does not make a poor purchase sensible.

> Mistake: retained earnings are a pile of cash.
Some students picture retained earnings as cash lying in the bank. Retained earnings are profit the business has kept, and it may already have spent that profit on stock or fittings. At Meghna and Sons, Tk 210,000 of retained earnings buys textbook stock.

> Mistake: a profitable business always has money to pay its bills.
A business can earn a profit and still lack cash on wage day, because customers may pay late or the profit may be tied up in stock. Profit and liquidity are different things.

> Mistake: the financial manager and the accountant do the same work.
The accountant records what has happened. The financial manager plans, raises and controls money to decide what should happen next. In a small shop one person may do both, but the two kinds of work stay different.

## In History

> A London bank collapsed in 1995 because one trader's work was never checked.
In 1762 a family founded Barings in London. It was a merchant bank, which means a bank that serves trade and large clients. By 1995 it was 233 years old. On 26 February 1995 it collapsed. The cause lay in Singapore, where a Barings subsidiary employed a trader named Nick Leeson. A trader buys and sells financial contracts for a bank. Leeson dealt in contracts called futures, which are agreements to buy or sell at a fixed price on a later date.

> Leeson held both the trading and the records of it, so no one checked him.
Leeson was allowed to control both the trading and the recording of those trades. Normally two people hold these tasks, so that each checks the other. With one man in both roles, his losses stayed hidden while they grew. Reports put the losses at about £827 million, more than the bank could absorb.

> The inquiry found weak control and weak management, as well as one man's wrongdoing.
The Bank of England, which is Britain's central bank and supervises banks, had a board inquire into the collapse. Its report in July 1995 found that several people at Barings had failed to do their jobs properly. The Dutch group ING bought the bank for £1, and in December 1995 a Singapore court sentenced Leeson to six and a half years in prison. In this chapter's words, weak financial control, not bad luck, brought down the bank: the money moved without checks that would have shown the problem in time.

## Review Questions

:q 2.1 | Describe the roles of a financial manager in a small firm, such as a bookshop run by two brothers. Name the three duties and give one example of each.
:q 2.2 | A clinic decides to buy a scanner for Tk 2,000,000 and to pay for it with a bank loan. Name the investment decision and the financing decision in this choice. Which of the three core decisions has not yet been made?
:q 2.3 | Explain the difference between financial planning and financial control, using a tailor who expects to pay Tk 30,000 for cloth.
:q 2.4 | A shop earns a profit every month but cannot pay its suppliers on time. Explain how weak liquidity disrupts the daily operations of the shop.
:q 2.5 | A household must decide between buying a new fridge with its savings and repaying a loan with the same savings. Name the decision type of each option.
:q 2.6 | A corner shop owner earns a profit of Tk 90,000. She spends Tk 40,000 of it on a new freezer and pays herself Tk 50,000. Name the decisions and state the dividend and the retained earnings.
:q 2.7 | A small manufacturer, in one year, buys a new machine, pays for it partly with a loan, and pays its owners a share of profit. List the three decisions and explain how the dividend decision affects the financing decision.
:q 2.8 | Tailor A spends Tk 70 for each Tk 100 of sales and Tailor B spends Tk 80. Which has the greater operating efficiency, and why does efficiency differ from profitability?

:read Board of Banking Supervision, Report of the Inquiry into the Circumstances of the Collapse of Barings, 1995
