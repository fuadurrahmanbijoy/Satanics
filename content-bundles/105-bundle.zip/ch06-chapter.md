:chapter VI | Uneven Cash Flows
:mood Can two plans that pay the same total be worth different amounts?
:desc This chapter extends present value and future value to payments that change in size from year to year. It shows how to value such a series, how to split it into a level part and an odd part, and how to compare two series at a common rate.
:plate ch06-plate.svg | A clerk seals a deed beside shelves of deed boxes and an hourglass

:box YOU WILL NEED
Chapter 5, section 5.3: the present value of an annuity. Chapter 4, section 4.3: the present value of a single sum.

> Two plans that pay the same total may still differ in value, because the order of the payments differs.

Two stalls at a book fair each promise you Tk 6,000 over three years, paid at the end of each year. The first stall pays Tk 1,000, then Tk 2,000, then Tk 3,000. The second pays the same amounts in the opposite order: Tk 3,000, then Tk 2,000, then Tk 1,000. Both plans total Tk 6,000. Are they worth the same to you? Most people feel that the second plan is better, because the largest payment arrives soonest. The feeling is correct, but a feeling is not a number. How much better is it?

> The shortcut for equal payments cannot be used here, because these payments are not equal.

Chapter 5 gave a fast way to value equal payments. That way cannot be used directly now, because the payments differ from year to year. Yet real receipts seldom stay equal. A shop's sales grow as customers learn of it. A machine earns less as it ages. A loan may be repaid in large amounts first and small amounts later. If we could value only equal payments, we could value very little of business life.

> The remedy is to return to single sums, and to learn a tidy way of working with them.

The remedy lies in Chapter 4. Each payment, taken alone, is a single sum received on one date, and a single sum can be discounted. Once every payment has been discounted, the results can be added. This chapter shows the method, shows where the shortcut of Chapter 5 still helps, and shows how to compare two series fairly.^1

^1: Chapter 4, 'The Time Value of Money: Single Sums', section 4.3 'Present Value of a Single Sum'; Chapter 5, 'Annuities', section 5.3 'Present Value of an Annuity'.

* * *

## 6.1 What a Mixed Stream Is

> Wages that rise, fees that change and takings that follow the seasons all have payments of different sizes.

Begin with everyday life. A worker's wage may rise by a fixed amount each year. School fees change when a child moves to a higher class. The takings of a shop are larger before a festival and smaller after it. In each case a series of money amounts arrives over time, and the amounts are not equal. Finance has a name for this shape.

> A mixed stream is a series of payments or receipts that differ in size from one period to the next.
@ Mixed stream | A series of payments or receipts that differ in size from one period to the next.
@ Stream | Word in use. In daily life, a small river or a flow of water. In finance, a series of payments or receipts arriving over time.

That name is **mixed stream**. A mixed stream is a series of payments or receipts that differ in size from one period to the next. Receipts of Tk 1,000, Tk 2,000 and Tk 3,000 at the ends of three successive years form a mixed stream. A receipt is money coming in; a payment is money going out. The valuing method is the same for both, and in this chapter we use receipts. The word *mixed* tells us that the sizes are mixed, not equal.

> A single sum, an annuity and a mixed stream differ in how many payments there are and whether they are equal.

Three shapes of cash flow now stand side by side. A single sum is one payment on one date. An annuity is several equal payments at equal intervals. A mixed stream is several payments whose sizes may differ. The table lists them. Read a row from left to right: the shape, the number of payments, the sizes, and the tool for valuing it.

:table Three shapes of cash flow
| Shape | Number of payments | Sizes | Tool for valuing it |
| Single sum | One | Not applicable | One discounting step |
| Annuity | Several | All equal | The annuity factor |
| Mixed stream | Several | May differ | Discount each, then total |

> A mixed stream is the general shape; the other two are special cases of it.

Notice that the shapes are nested. An annuity is a mixed stream whose sizes happen to be equal, and a single sum is a mixed stream with one payment. The method for a mixed stream therefore works for every shape, although it is slower. The annuity factor is a shortcut for the equal case.

> The owner, the manager and the lender each meet mixed streams in different places.

The shape appears from several viewpoints. The owner of a shop sees a mixed stream in yearly profit that grows as the business matures. The financial manager sees it in the cash that a new machine will bring. A lender sees it in a loan whose repayments are uneven. Each of them must turn the stream into one number before deciding anything.

> Recap: a mixed stream has payments of different sizes, and single sums and annuities are special cases.

*Before moving on.* A mixed stream is a series of payments or receipts that differ in size from one period to the next. A single sum and an annuity are special cases of it. Because the sizes differ, we value each payment alone and then total the results.

* * *

## 6.2 Present and Future Value of a Mixed Stream

> Discounted cash flow turns each future amount into a present value and totals the results.
@ Discounted cash flow | A way of valuing a series of future cash flows by turning each one into a present value.

The method has a name. **Discounted cash flow** is a way of valuing a series of future cash flows by turning each one into a present value. The present values share one date, today, so they can be added. We begin with the smallest numbers, so that the method is the only new thing to learn.^2

^2: Recall: present value and discounting, Chapter 4, 'The Time Value of Money: Single Sums', section 4.3 'Present Value of a Single Sum'.

> Worked example 1 discounts three uneven receipts at 10% and totals the present values.

*Given.* Receipts of Tk 1,000, Tk 2,000 and Tk 3,000 at the ends of years 1, 2 and 3; discount rate 10% a year.
*Find.* The present value of the stream.
*Formula.* Present value of a single sum = amount ÷ (1 + discount rate) to the power of the number of years until it is received.
*Steps.* Year 1: Tk 1,000 ÷ 1.10 = Tk 909.091. Year 2: Tk 2,000 ÷ 1.21 = Tk 1,652.893. Year 3: Tk 3,000 ÷ 1.331 = Tk 2,253.944. The total is Tk 909.091 + Tk 1,652.893 + Tk 2,253.944 = Tk 4,815.928, or Tk 4,815.93.
*Answer.* The present value of the stream is Tk 4,815.93.
*Check.* The present value must be less than the Tk 6,000 received in total, and it is.

:pause 6.p1 | Value the opposite stream, Tk 3,000, Tk 2,000 and Tk 1,000 at the ends of years 1, 2 and 3, at 10%. Is it worth more or less than Tk 4,815.93, and why?

> The rule for a mixed stream: present value is the total of each receipt divided by its own growth multiplier.

The rule, in words first: the present value of a mixed stream equals the total of each receipt divided by (1 + discount rate) to the power of its year. In symbols:
PV = C₁ ÷ (1 + r) + C₂ ÷ (1 + r)² + C₃ ÷ (1 + r)³ + … 
Here PV stands for the present value, C₁, C₂ and C₃ for the receipts of years 1, 2 and 3, and r for the discount rate per year, written as a decimal. The three dots mean that the pattern continues for as many years as the stream lasts. Each term is a single sum from Chapter 4, and the formula only totals them.

> The future value of a mixed stream grows each receipt to the last date and totals the results.

The future value of a mixed stream is the sum that all receipts reach on the date of the last receipt, when each has grown at compound interest. A receipt in year 1 grows for two years, one in year 2 grows for one year, and one in year 3 does not grow. In the clean example: Tk 1,000 × 1.21 = Tk 1,210; Tk 2,000 × 1.10 = Tk 2,200; and Tk 3,000 stays Tk 3,000. The future value is Tk 1,210 + Tk 2,200 + Tk 3,000 = Tk 6,410. Check: Tk 4,815.93 × 1.331 = Tk 6,410, because the future value equals the present value grown for three years.

> The case file gives two stall plans, and their figures are valued at 12% in the tables.

:case Case file, illustrative. Meghna and Sons, 10 October 2024. Two book-fair stall plans, with receipts at year end for 5 years. Stream A: Tk 40,000; Tk 55,000; Tk 60,000; Tk 70,000; Tk 80,000. Stream B: Tk 80,000; Tk 70,000; Tk 60,000; Tk 55,000; Tk 40,000. Both total Tk 305,000. At 12% a year, the present value of A is Tk 212,147.18 and of B Tk 227,589.53. The future value at year 5 of A is Tk 373,875.81 and of B Tk 401,090.51.

> The first table discounts every receipt of both plans at 12%; the totals are the present values.

Worked example 2 repeats the method with realistic figures. Read each row of the first table from left to right: the receipt, multiplied by the discount multiplier for its year, gives its present value. The multipliers are shown to six places, and the present values are calculated from unrounded multipliers.

:table Present value of each receipt at 12% (Tk)
| Year | Discount multiplier | Receipt A | Present value A | Receipt B | Present value B |
| 1 | 0.892857 | 40,000 | 35,714.29 | 80,000 | 71,428.57 |
| 2 | 0.797194 | 55,000 | 43,845.66 | 70,000 | 55,803.57 |
| 3 | 0.711780 | 60,000 | 42,706.81 | 60,000 | 42,706.81 |
| 4 | 0.635518 | 70,000 | 44,486.27 | 55,000 | 34,953.49 |
| 5 | 0.567427 | 80,000 | 45,394.15 | 40,000 | 22,697.07 |
| Total | | 305,000 | 212,147.18 | 305,000 | 227,589.53 |

> The entries of B, rounded to the poisha, total two poisha less than the case figure, because of rounding.

The present value of A is Tk 212,147.18, and of B Tk 227,589.53, as in the case file. The five rounded entries of B total Tk 227,589.51, two poisha less, because each entry was rounded separately; the unrounded sum is the case figure. A poisha is one hundredth of a taka.

> The second table grows each receipt to year 5 at 12% and totals the results.

For the future value, each receipt is grown to the end of year 5. A receipt of year 1 grows for four years, so its growth multiplier is 1.12⁴ = 1.573519. The multiplier for year 2 is 1.12³ = 1.404928, for year 3 it is 1.12² = 1.2544, for year 4 it is 1.12, and year 5 has none.

:table Future value at year 5 of each receipt, at 12% (Tk)
| Year | Growth multiplier | Future value A | Future value B |
| 1 | 1.573519 | 62,940.77 | 125,881.55 |
| 2 | 1.404928 | 77,271.04 | 98,344.96 |
| 3 | 1.254400 | 75,264.00 | 75,264.00 |
| 4 | 1.120000 | 78,400.00 | 61,600.00 |
| 5 | 1.000000 | 80,000.00 | 40,000.00 |
| Total | | 373,875.81 | 401,090.51 |

> The check: a present value grown for five years gives the future value, to within a few poisha.

*Check.* The future value equals the present value grown for five years, and 1.12⁵ = 1.762342. For stream A, Tk 212,147.18 × 1.762342 is about Tk 373,876. For stream B, Tk 227,589.53 × 1.762342 is about Tk 401,091. Both agree with the tables to within the rounding of the multiplier.

> Streams that contain a level part can use the annuity factor for that part.

Many streams contain a stretch of equal receipts with one or two odd amounts. Then the stream can be split into an annuity part and an odd part. The annuity part is valued with the annuity factor of Chapter 5, and the odd part as a single sum. The two present values are added. Chapter 5 gave the factor for 10% and 3 payments as 2.486852.

> Worked example 3 splits a stream of Tk 20,000, Tk 20,000 and Tk 30,000 into a level part and an odd part.

*Given.* Receipts of Tk 20,000, Tk 20,000 and Tk 30,000 at the ends of years 1, 2 and 3; discount rate 10% a year.
*Find.* The present value of the stream.
*Formula.* Present value = annuity payment × annuity factor + odd amount × discount multiplier of its year.
*Steps.* The level part is Tk 20,000 in each of 3 years: Tk 20,000 × 2.486852 = Tk 49,737.04. The odd part is the extra Tk 10,000 in year 3: Tk 10,000 ÷ 1.331 = Tk 7,513.15. The total is Tk 49,737.04 + Tk 7,513.15 = Tk 57,250.19.
*Answer.* The present value of the stream is Tk 57,250.19.
*Check.* Discount each receipt alone: Tk 18,181.82 + Tk 16,528.93 + Tk 22,539.44 = Tk 57,250.19. The two methods agree.

> A stream's value depends only on the sizes of the receipts, their dates and the discount rate.

Three things fix the value of a stream: the size of each receipt, the date of each receipt, and the discount rate. Nothing else matters to the arithmetic. The name of the project, the person who pays and the total of the receipts do not enter the formula. This is why two plans that look very different can have the same present value, and two plans that look alike can differ. When you meet a new stream, list the receipts with their years first, as in the tables of this chapter, and only then begin to discount.

> A tidy table prevents most errors: one row for each year, one column for each quantity.

A table is the safest way to value a stream by hand. Write the years down the left side. Next to each year write the receipt, then the multiplier, then the product. The total of the last column is the present value. If a year has no receipt, write zero and keep the row, so that no year is skipped. Check the table by reading the multipliers down the column: they must fall steadily, because each later year has a smaller multiplier.

> Recap: discount each receipt, or split the stream into an annuity part and an odd part, and total the present values.

*Before moving on.* Discounted cash flow values a stream by turning each receipt into a present value and adding. The future value grows each receipt to the last date and adds. A level part may use the annuity factor. *Common slip:* using the wrong year for a receipt, so that it is discounted too much or too little.

* * *

## 6.3 Comparing Streams with a Common Rate

> Two streams can be compared fairly only at the same date and the same discount rate.

A buyer who must choose between two streams needs one number for each. Totals do not serve, because they ignore timing. The fair way is to value both at the same date, usually today, and at the same discount rate. The stream with the higher present value is worth more. The same ranking appears if both are grown to the same later date, because every future value is the present value grown by the same multiplier.

> The figure draws the receipts of the two stall plans side by side, year by year.

The figure shows the two stall plans of the case file. Its horizontal axis lists the years, and each year has two bars. The line-hatched bar is stream A, which rises; the cross-hatched bar is stream B, which falls. The height of a bar is the receipt of that year, and the number above it gives the receipt in thousands of taka. Both streams total Tk 305,000, but the bars of B are taller at the left, where money is worth more.

:fig Yearly receipts of two five-year streams: A rising, B falling, with the same total | ch06-fig01.svg

> The case file shows that B is worth more at 12%, although both streams total the same.

:case Case file, illustrative. Meghna and Sons, 10 October 2024. At 12% a year, B is worth more than A because larger receipts come sooner. The present value of A is Tk 212,147.18 and of B Tk 227,589.53. The future value at year 5 of A is Tk 373,875.81 and of B Tk 401,090.51.

> The gap of Tk 15,442.35 in present value is the price of receiving the large amounts later.

The difference in present value is Tk 227,589.53 − Tk 212,147.18 = Tk 15,442.35. The difference in future value is Tk 401,090.51 − Tk 373,875.81 = Tk 27,214.70. Neither gap comes from the totals, which are equal. Both come from timing alone. Stream B delivers Tk 80,000 in year 1, and that money can start earning interest at once.

> The ranking of two streams may depend on the discount rate, so it is wise to test more than one rate.

A discount rate is rarely known with certainty, so a careful reader tests the ranking at more than one rate. Sometimes the ranking holds at every rate, as with A and B. Sometimes it reverses. Take stream E, which pays Tk 30,000 at the end of each of 5 years, and stream F, which pays Tk 200,000 once, at the end of year 5. At 5% a year, E is worth Tk 30,000 × 4.329477 = Tk 129,884, using the annuity factor of Chapter 5, and F is worth Tk 200,000 × 0.783526 = Tk 156,705. At 15% a year, E is worth Tk 30,000 × 3.352155 = Tk 100,565 and F is worth Tk 200,000 × 0.497177 = Tk 99,435. At 5% F wins; at 15% E wins.

> The ranking reverses because a higher rate punishes the distant payment of F more than the early payments of E.

The reason is plain. A higher discount rate shrinks distant money faster than near money. The single large payment of F lies five years away, so it loses most. The yearly payments of E are nearer on average, so they lose less. The lesson is not to fear the reversal but to expect it: when two streams have different totals and different timing, test the rate. When they have the same total, as A and B do, the stream with earlier receipts wins at every positive rate.

> To test a rate, repeat the whole comparison at a lower and a higher rate and watch whether the ranking changes.

The test has three steps. First choose a low rate and a high rate that bracket the likely one, for example 5% and 15%. Second, value each stream at both rates, using the same method each time. Third, compare the rankings. If the same stream wins at both rates, the decision is secure. If the winner changes, there is a rate between the two at which the streams are worth the same, and the decision depends on which side of that rate the true rate lies. A reader who meets such a case should say so plainly and name the rates, instead of hiding the dependence.

> A viewpoint matters: an owner who needs cash early values early receipts more than the arithmetic alone shows.

The viewpoint of the decision-maker also counts. An owner who must repay a loan next year may prefer the stream with early receipts even at a low rate, because the cash is needed on that date. A saver who will not need the money for ten years may care little about timing. The discount rate expresses these needs in one number, so choosing the rate is itself a decision, to be made with care and stated openly.

> Recap: compare streams at the same date and rate, test the rate, and expect the earlier-heavy stream to win at equal totals.

*Before moving on.* Compare streams by present value at one common rate. Test the ranking at several rates, because it can reverse when totals differ. With equal totals, the stream with the larger early receipts has the higher value.

* * *

## Worked Example: Two Streams at Three Rates

> The worked example compares a rising and a falling stream, with equal totals, at 9%, 12% and 15%.

Here we compare a rising stream R of Tk 1,000, Tk 2,000 and Tk 3,000 with a falling stream F of Tk 3,000, Tk 2,000 and Tk 1,000, all at year ends. Both total Tk 6,000. The multipliers below are the discount multipliers for years 1, 2 and 3.

> The steps follow the standard order from Given to Check, with the work at 12% shown in full.

*Given.* Stream R: Tk 1,000; 2,000; 3,000. Stream F: Tk 3,000; 2,000; 1,000. Discount rates 9%, 12% and 15% a year.
*Find.* The present value of each stream at each rate, and which is worth more.
*Formula.* Present value = total of (receipt × discount multiplier of its year), where the multiplier is 1 ÷ (1 + rate) to the power of the year.
*Steps.* At 12%: R = Tk 892.857 + Tk 1,594.388 + Tk 2,135.341 = Tk 4,622.59. F = Tk 2,678.571 + Tk 1,594.388 + Tk 711.780 = Tk 4,984.74. The steps at 9% and 15% use the multipliers in the table.
*Answer.* F is worth more than R at all three rates. The results are in the second table.
*Check.* At a rate of 0% both streams are worth Tk 6,000, so the gap must vanish as the rate falls. The gap in the table shrinks as the rate falls, which agrees.

> The first table lists the discount multipliers for the three rates and three years.

Read the first table by choosing a rate in the left column and moving right to the multiplier for each year.

:table Discount multipliers
| Rate | Year 1 | Year 2 | Year 3 |
| 9% | 0.917431 | 0.841680 | 0.772183 |
| 12% | 0.892857 | 0.797194 | 0.711780 |
| 15% | 0.869565 | 0.756144 | 0.657516 |

> The second table shows that the gap between the falling and rising streams widens as the rate rises.

Read the second table by rate. For each rate it gives the present value of R, of F, and the difference between them.

:table Present values of the two streams (Tk)
| Rate | Present value of R | Present value of F | Gap (F − R) |
| 9% | 4,917.34 | 5,207.84 | 290.50 |
| 12% | 4,622.59 | 4,984.74 | 362.15 |
| 15% | 4,354.40 | 4,778.50 | 424.10 |

> Both patterns agree with the rule: earlier receipts matter more, and more so at higher rates.

The table repeats the lesson of section 6.3. The falling stream wins at every rate, and the gap grows with the rate, because a higher rate makes early money more valuable compared with late money. From the viewpoint of an owner choosing between two plans with equal totals, the safe choice is the plan that pays sooner.

* * *

## Summary

> A mixed stream is valued by discounting each receipt; streams are compared at a common rate.

A mixed stream is a series of payments or receipts that differ in size from one period to the next. Discounted cash flow values it by turning each receipt into a present value and adding. The future value grows each receipt to the last date and adds. A level part of a stream may use the annuity factor, and the rest is valued as single sums. Streams are compared at one date and one discount rate; the ranking may change with the rate, so test more than one.

## Think It Through

:q 6.t1 | A supplier offers two payment plans for the same machine. Plan X pays Tk 90,000, Tk 60,000 and Tk 30,000 at the ends of years 1, 2 and 3. Plan Y pays Tk 30,000, Tk 60,000 and Tk 90,000 at the same dates. At 10% a year, which plan costs less in present value, and why?
:q 6.t2 | Explain in plain words why two streams with the same total can have different present values.

## Where People Go Wrong

> The total of a stream is not its value, because the total ignores timing.

*Mistake: "The two plans total the same, so they are worth the same."* The total adds money from different dates as if the dates did not matter. Timing changes value, and the present value shows it.

> Each receipt needs the multiplier for its own year, not the multiplier of another year.

*Mistake: using one multiplier for all years.* The multiplier for year 3 is smaller than that for year 1. Using one multiplier for every year treats the stream as if every receipt came on the same date.

> The annuity factor applies only to the level part of a stream, never to the whole stream.

*Mistake: using the annuity factor on unequal receipts.* The factor assumes equal payments. Split the stream into a level part and an odd part first, or discount each receipt alone.

> A ranking found at one rate may not hold at another.

*Mistake: ranking streams at one rate and then trusting the result.* Where totals differ, the ranking can reverse. Test a low rate and a high rate before deciding.

## In History

> Benjamin Franklin's bequest of 1790 grew for two centuries with withdrawals at set dates.

Benjamin Franklin (1706–1790) died in Philadelphia on 17 April 1790. In a codicil to his will he left 1,000 pounds each to Boston, where he was born, and to Philadelphia, where he lived most of his adult life. The money was to be lent to young married craftsmen who had served an apprenticeship. Part of it could be used after 100 years, and the rest after 200 years, in 1990.

> The bequest is a mixed stream: nothing for a century, then a withdrawal, then the remainder.

Franklin's plan is a mixed stream seen from the owner's side. No money left the fund for a century, one part was then withdrawn, and the remainder was withdrawn two centuries after his death. Compound interest worked on the fund during all that time. Accounts of the sums reached in 1990 differ; they are usually given as a few million dollars for each city, with the Boston fund the larger.

## Review Questions

:q 6.1 | Find the present value of receipts of Tk 20,000, Tk 35,000 and Tk 50,000 at the ends of years 1, 2 and 3, at 10% a year.
:q 6.2 | Find the future value at the end of year 3 of the stream in question 6.1, at 10% a year.
:q 6.3 | A stream pays Tk 15,000 at the end of each of years 1 to 4 and Tk 40,000 at the end of year 5. Split it into an annuity part and an odd part, and find its present value at 10% a year. The annuity factor for 10% and 5 payments is 3.790787.
:q 6.4 | Compare the rising stream of question 6.1 with the falling stream Tk 50,000, Tk 35,000 and Tk 20,000, at 9% and at 15% a year. Which is worth more at each rate?
:q 6.5 | Explain how a mixed stream differs from an annuity, and say why the annuity factor cannot be used for a mixed stream as a whole.

:read Brealey, Myers and Allen, Principles of Corporate Finance, 2020
:read Franklin, Last Will and Testament, with codicil, 1789
