:chapter X | Risk, Required Return and Market Efficiency
:mood Why must an uncertain gain promise more than a certain one?
:desc This chapter explains why a risky investment must promise more than a safe one, and how much more. You will separate risk that can be removed from risk that cannot, measure how strongly an investment moves with the whole market, and turn that measure into a required return. The chapter ends with the question of how markets use information.
:plate ch10-plate.svg | Dealers crowd the floor beneath a board of chalked prices

> A certain gain and an uncertain gain raise one question: how much more must the second promise?

Suppose a relative offers you a choice. You may lend Tk 10,000 to the government for three months and receive 8% a year with certainty. Or you may lend the same sum to a stranger who plans to sell tea from a cart, and the stranger offers 9%. Would you accept the stranger's offer? Most people say no. One extra percentage point seems too little for the chance that the stranger repays nothing. What if the stranger offered 12%? Or 20%?

> Different people give different answers, so we need a principle rather than a feeling.

Two people may answer differently, and neither is foolish. Yet a business meets this question every day, with real money. It must decide whether a project that might earn 14% is worth the danger that it earns far less. If managers answered by feeling, a business would accept a good project in one month and refuse it in the next, for no reason that anyone could explain.

> The chapter gives a rule for the extra return, a way to separate removable danger from the rest, and a view of how markets use information.

This chapter builds the principle in four steps. First: how much extra return does a given danger demand? Second: is all danger paid for, or can some of it be removed at no cost? Third: can we turn the answer into one formula that gives a required return? Fourth: how quickly do markets take in what is known? By the end you will calculate a required return by hand and use it to accept or reject an investment.

> The chapter relies on earlier ideas about risk, return and the benchmark for projects.

You will need Chapter 9, 'Return and Risk', sections 9.2 to 9.4, which define risk and show how to measure it with the expected value and the standard deviation. You will also need Chapter 8, 'Capital Budgeting: Evaluation Techniques', section 8.2 'Net Present Value', where the required return is the benchmark for a project.

* * *

## 10.1 Risk Premium

> Lenders ask for more from a borrower who is less likely to repay.

Return to the tea seller and the government. Both want to borrow Tk 10,000 for three months. The government will almost certainly repay. The tea seller may have a poor season and repay only part. A sensible lender asks the tea seller for a higher rate. The extra is the price of the added uncertainty, and its size depends on how much danger the lender sees.

@ Risk-free rate | the return on an investment with no chance of loss, such as a short government bill

> The risk-free rate is the reward for waiting alone, with no uncertainty in it.

To measure the extra, we need a starting point that has none. The **risk-free rate** is the return on an investment with no chance of loss, such as a short government bill. A *government bill* is a loan to the government, repaid within a year or less. No investment is perfectly free of risk, but a short loan to a stable government comes very close. The risk-free rate pays only for waiting, which is the time value of money. In the running case the natural choice would be a Bangladesh government bill; the 8% used below is assumed for illustration.

@ Premium | Word in use. In daily life, a payment for insurance, or an extra charge added to a price. In finance, the extra return demanded for bearing risk.

@ Risk premium | the extra return investors demand for taking on risk above the risk-free rate

> The extra return above the risk-free rate is the price of bearing risk.

Now the extra has a name. A **risk premium** is the extra return investors demand for taking on risk above the risk-free rate. Risk, as Chapter 9 defined it, is the chance that results differ from those expected.^1 In words: risk premium equals required return less risk-free rate. If the risk-free rate is 8% and the tea seller must offer 12% before you will lend, the risk premium is 12% − 8% = 4%.

^1: Chapter 9, 'Return and Risk', section 9.2 'What Risk Is', defines risk.

> Turned round, the same relation builds the required return from its two parts.

The relation can be turned round. Required return equals the risk-free rate plus the risk premium. Here 8% + 4% = 12%. The required return is the least return at which the investor accepts the danger. A return below it does not pay enough for the risk; a return above it leaves a gain.

> A short worked example shows the two steps in the standard order.

*Given.* Risk-free rate 8%; the lender demands 12% from the tea seller. *Find.* The risk premium. *Formula.* Risk premium equals required return less risk-free rate. *Steps.* 12% − 8% = 4%. *Answer.* The risk premium is 4 percentage points. *Check.* Adding the premium back to the risk-free rate, 8% + 4%, gives 12%, which is the required return we began with.

> The table lists three loans in order of rising danger, with the premium rising too.

The table sets three loans in order of rising danger. Read each row from left to right: the borrower, the premium the lender demands, and the required return, which is the risk-free rate of 8% plus that premium. The figures are illustrative.

:table Required return rising with risk (illustrative figures)
| Borrower | Risk premium | Required return |
| Government, three-month bill | 0% | 8% |
| Long-established bookshop | 2% | 10% |
| New tea seller with a cart | 4% | 12% |

> Each person who sees the same loan sees a different side of the premium.

The viewpoints differ. The lender asks what extra return would make the loan worth the danger. The borrower sees the premium as a cost of funds. The financial manager sees both, because the required return is the benchmark for judging a project, as Chapter 8 taught,^2 and the manager must therefore know what premium to add.

^2: Chapter 8, 'Capital Budgeting: Evaluation Techniques', section 8.2 'Net Present Value', uses the required return as the benchmark for a project.

> The premium is a demand and not a promise, and it changes with the mood of the market.

Two limits matter. First, the premium is what investors *demand*, not what they receive. An investment that promises 12% may pay 12%, more, or nothing; the premium is the reason investors accept the danger, not a guarantee. Second, the premium is not the same for every investor or in every period. It rises when people grow fearful and falls when they grow confident. A common slip is to call the premium itself the required return, and to forget to add the risk-free rate.

> The section's ideas are the risk-free rate, the risk premium and the required return.

*Before moving on.* The risk-free rate pays for waiting alone. The risk premium is the extra that investors demand for risk, and the required return is the sum of the two. *You should now be able to say* why a loan to a tea seller must offer more than a government bill.

* * *

## 10.2 Diversification and Beta

@! Go slowly here.

> Two stalls that suffer in opposite weather make a steadier living than one.

Imagine a trader who sells umbrellas. In a wet week the profit is Tk 20,000, and in a dry week it is nothing. Each kind of week is equally likely, so the expected value is Tk 10,000 a week, with a wide spread around it. A long dry spell could ruin the trader. Now suppose the trader puts half the money into a sunshade stall. In a wet week the umbrellas earn Tk 10,000 and the sunshades nothing; in a dry week the reverse. Either way the profit is Tk 10,000.

> Holding both kinds of stall removes the swings, although real life is never so tidy.

The expected value is still Tk 10,000, but the spread has gone: the standard deviation has fallen from Tk 10,000 to zero. Real investments never cancel each other so perfectly. The idea still holds. When one investment does badly for a reason that helps another, the pair is steadier than either alone.

@ Portfolio | a collection of investments held together by one investor

> A portfolio is the whole set of investments that one investor holds.

The trader's two stalls form a **portfolio**. A portfolio is a collection of investments held together by one investor. A person who owns common stock in five businesses holds a portfolio of five holdings. So does a business that owns a shop, a warehouse and a loan to a customer. What matters about a portfolio is the combined result, not the result of each part on its own.

@ Diversification | spreading money across different investments so that one loss hurts less

> Diversification spreads money across different investments.

Building such a portfolio has its own name. **Diversification** is spreading money across different investments so that one loss hurts less. The trader's move from one stall to two is diversification. The word *different* matters. Ten stalls that all sell umbrellas spread the money but not the danger, because one wet season hurts all ten.

> Diversifying removes some risk but not all, and the two kinds of risk need names.

Does diversifying remove all risk? It does not. Think of two kinds of bad news. A fire at one factory, a strike at one shop or a failed new product harms one business and leaves the others alone. A rise in the cost of borrowing, a fall in demand across the whole country or a war reaches almost every business at once.

@ Firm-specific risk | risk that affects one business only and can be reduced by diversifying

> Firm-specific risk strikes one business and can be diversified away.

The first kind is **firm-specific risk**: risk that affects one business only and can be reduced by diversifying. An investor who holds many businesses feels one failure as a small part of the portfolio, and good news at some businesses offsets bad news at others.

@ Market | Word in use. In daily life, a place where people buy and sell goods, such as a bazaar. In finance, all the buyers and sellers of one kind of investment, taken together.

@ Market risk | risk that affects all investments in a market and cannot be removed by diversifying

> Market risk reaches every investment and remains however many are held.

The second kind is **market risk**: risk that affects all investments in a market and cannot be removed by diversifying. Here *market* means all the buyers and sellers of a kind of investment, taken together. A fall in demand across the whole country lowers the profit of nearly every business, so no mixture of businesses escapes it.

> The figure shows risk falling as different assets are added, until only market risk is left.

To read the next figure, look first at the two axes. The horizontal axis counts how many different assets the portfolio holds. The vertical axis shows the total risk of the portfolio. The curve falls steeply at first, because each new asset removes much firm-specific risk, and then flattens at a floor. The shaded area above the floor is firm-specific risk; the floor itself is market risk.

:fig Risk of a portfolio falling as different assets are added, then levelling at a floor | ch10-fig02.svg

> Investors are paid for market risk and not for risk that anyone can remove.

Here is the idea that carries the rest of the chapter. Because an investor can remove firm-specific risk by diversifying, the market does not pay extra for bearing it. Only market risk earns a premium. To find a fair required return for one investment, we must therefore measure how much market risk it carries. There is one exception to remember: a family that owns a single bookshop cannot diversify its wealth, so for that family firm-specific risk is real. The theory fits best an investor who holds many different assets.

> Several shops in one bazaar follow the crowd by different amounts.

Picture ten shops in one bazaar. When the number of visitors rises by 10%, a shop selling festival goods may see its sales rise by 15%, and a shop selling rice may see a rise of only 6%. Each shop follows the crowd, but by a different amount. The crowd plays the part of the market, and the amount of following is what we want to measure.

@! Go slowly here.

@ Beta | a number showing how strongly an investment moves with the whole market

> Beta compares the movement of an investment with the movement of the whole market.

The **beta** of an investment is a number showing how strongly it moves with the whole market. By agreement the whole market has a beta of exactly 1. An investment with a beta of 1.5 tends to move one and a half times as far as the market: when the return of the market rises by 10%, the return of this investment tends to rise by about 15%, and when the market falls by 10%, it tends to fall by about 15%. An investment with a beta of 0.6 moves about six-tenths as far.

> The table gives four betas and what each means.

The table lists four betas. Read each row from left to right: the beta, what it means, and the usual movement of the investment when the return of the market changes by 10%.

:table How to read a beta
| Beta | Meaning | Usual movement for a 10% market change |
| 0 | Does not move with the market | 0% |
| 0.6 | Moves less than the market | 6% |
| 1.0 | Moves as the market does | 10% |
| 1.5 | Moves more than the market | 15% |

:pause 10.p1 | An investment has a beta of 2. The market return rises by 5%. By about how much would you expect its return to rise?

> Beta is found from past records, and it measures market risk only.

Two limits apply. First, beta is found by comparing the past returns of an investment with those of the market, and data services publish it; this book uses betas that are given and does not teach the estimation. Past movement may not repeat. Second, beta measures only market risk. The standard deviation of Chapter 9 measures total risk, which holds both kinds,^3 so an investment can have a high standard deviation and a low beta when most of its risk is firm-specific.

^3: Chapter 9, 'Return and Risk', section 9.4 'Measuring the Spread of Outcomes', shows that standard deviation measures total risk.

> The section's ideas are the portfolio, diversification, the two kinds of risk and beta.

*Before moving on.* A portfolio is the set of investments one investor holds, and diversification spreads money across different investments. It removes firm-specific risk but not market risk, and beta shows how strongly an investment moves with the market. *You should now be able to say* why diversifying cannot remove market risk.

* * *

## 10.3 The Capital Asset Pricing Model

> After Markowitz measured risk, one question remained: which risk should the market pay for?

In 1952 Harry Markowitz showed how to measure the risk of an investment by the spread of its returns. A question stayed open. If investors diversify, which part of that spread should the market pay for? In 1964 William Sharpe, an American economist, gave the answer: only market risk, measured by beta. John Lintner in 1965 and Jan Mossin in 1966, working separately, reached similar results. Sharpe later shared the 1990 Nobel Memorial Prize in Economic Sciences for this line of work.

@! Go slowly here.

@ Capital asset pricing model | a formula setting required return as risk-free rate plus beta times the market risk premium

> The model builds the required return from the risk-free rate and a premium scaled by beta.

The **capital asset pricing model** is a formula setting required return as risk-free rate plus beta times the market risk premium. The *market risk premium* is the premium for the whole market: the return of the market less the risk-free rate. In words: required return equals the risk-free rate plus beta times (market return less risk-free rate). In symbols, with Rf for the risk-free rate, Rm for the market return and β for beta: required return = Rf + β × (Rm − Rf).

> The first example uses small, clean numbers so that only the method must be learned.

*Given.* Risk-free rate 6%; market return 10%; beta 1.0. *Find.* The required return. *Formula.* Required return = Rf + β × (Rm − Rf). *Steps.* First, the market risk premium: 10% − 6% = 4%. Second, beta times the premium: 1.0 × 4% = 4%. Third, add the risk-free rate: 6% + 4% = 10%. *Answer.* The required return is 10%. *Check.* A beta of 1 means the investment moves as the market does, so it must require the market return, 10%, and it does.

> Two more betas show the formula at the ends of its range.

Try two other betas with the same rates. With a beta of 0 the required return is 6% + 0 × 4% = 6%, the risk-free rate, because an investment that does not move with the market carries no market risk. With a beta of 2 it is 6% + 2 × 4% = 14%, because the investment carries twice the market's risk and earns twice the market's premium.

:pause 10.p2 | With a risk-free rate of 6% and a market return of 10%, find the required return for an investment with a beta of 0.5.

@ Security market line | the straight line that shows required return rising with beta

> The security market line draws the formula as a picture.

The formula can be drawn. The **security market line** is the straight line that shows required return rising with beta. Beta runs along the horizontal axis and required return up the vertical axis. At a beta of 0 the line starts at the risk-free rate. For each whole step of beta, the line climbs by the market risk premium. At a beta of 1 it passes through the market return.

> The figure places two investments on the line by their betas.

To read the next figure, find an investment by its beta on the horizontal axis. Go up to the line, then across to the vertical axis. The height of the dot is the required return for that beta. An investment whose expected return lies above the line promises more than it must; one below the line promises less.

:fig The security market line, with the required returns of two product lines | ch10-fig01.svg

> The decision rule compares the expected return with the line.

The model gives a rule for decisions. Accept an investment when its expected return is equal to or above its required return, which means it lies on or above the line. Reject it when the expected return is below the required return. This is the same test as Chapter 8 used with net present value: a project is worth accepting when it earns at least the benchmark.

> The model rests on simplifying assumptions, so it guides and does not prove.

The model has limits. It assumes that investors hold diversified portfolios and that one market return and one beta explain required returns. Betas change over time, and the market return and risk-free rate are estimates, so different estimates give different required returns. Even so, it is the standard first tool, because it turns a feeling about risk into a number that can be argued about.

> The section's ideas are the pricing formula and the line that draws it.

*Before moving on.* The capital asset pricing model sets required return as the risk-free rate plus beta times the market risk premium. The security market line draws it as a straight line. *You should now be able to say* how a higher beta raises the required return.

* * *

## 10.4 Efficient Markets

> If a business announces good news, when should its share price change?

Suppose a business announces a large new order. When should the price of its common stock rise: before the news, when the news is announced, or a week later? If buyers and sellers are quick and well informed, the price should move at the moment of the announcement, and not after. A reader who waits a week to buy finds that the gain has gone.

@ Efficient market | a market in which prices already reflect the information available

> In an efficient market the price already contains what is known.

An **efficient market** is a market in which prices already reflect the information available. If a market is efficient, the market value of an investment is a fair summary of what is known about it. New information moves the price, and since new information cannot be predicted, price changes look random. Efficient does not mean that every price is right, or that nobody ever loses money.

> The strength of the claim depends on which information is meant.

How much information do prices contain? There are three answers, each stronger than the one before. They differ in the kind of information that prices already reflect.

@ Weak-form efficiency | prices already reflect all past price information

> The weak form covers past prices only.

**Weak-form efficiency** means that prices already reflect all past price information. If it holds, studying old price charts cannot show which investment will rise next, because the pattern is already in the price.

@ Semi-strong-form efficiency | prices reflect all public information, not only past prices

> The semi-strong form covers everything that is public.

**Semi-strong-form efficiency** means that prices reflect all public information, not only past prices. Annual reports, news and announcements are public. If this form holds, reading them after they appear brings no gain, because the price has already moved.

@ Strong-form efficiency | prices reflect all information, public and private

> The strong form covers private information too.

**Strong-form efficiency** means that prices reflect all information, public and private. Even a manager's secret knowledge would be in the price. Few people believe this form holds, and in many countries trading on secret information is a crime.

> The table sets the three forms side by side.

The table lists the three forms. Read each row from left to right: the form, the information already in the price, and an example of what would not help an investor if the form holds.

:table The three forms of market efficiency
| Form | Information in the price | Would not help |
| Weak | Past prices | Studying last year's price chart |
| Semi-strong | All public information | Reading a report published this morning |
| Strong | Public and private information | Using a secret known only to managers |

> Efficiency varies between markets and periods, so claims must be made with care.

Efficiency is a matter of degree. Studies of large, busy markets have found support for the weak form and mixed results for the others. Smaller markets, where fewer people trade and less information is published, may be less efficient. A student should say which market and which period a claim concerns. For a financial manager, the lesson is practical: where prices reflect information quickly, the market value of the business is a fair guide to the quality of the manager's decisions.

> The section's ideas are the efficient market and its three forms.

*Before moving on.* An efficient market is one whose prices already reflect the information available. The weak form covers past prices, the semi-strong form all public information and the strong form all information. *You should now be able to say* why new information, and not old information, moves prices.

* * *

## Worked Case: Two Product Lines on the Line

> The case file gives the market rates and the beta and expected return of each line.

:case Case file, illustrative. Meghna and Sons, 20 March 2025. The risk-free rate is 8%, a short government bill, assumed for illustration. The market return is 14%, so the market risk premium is 6%. Study-guide line: beta 0.6, expected return 12%, found in Chapter 9. Art-supplies line: beta 1.5, expected return 14%.

> The first line is worked in full, in the standard order.

*Given.* Rf = 8%; Rm = 14%; study-guide beta 0.6; expected return 12%. *Find.* The required return, and whether to accept the line. *Formula.* Required return = Rf + β × (Rm − Rf). *Steps.* Market risk premium: 14% − 8% = 6%. Beta times premium: 0.6 × 6% = 3.6%. Required return: 8% + 3.6% = 11.6%. Compare: expected return 12% is above 11.6%. *Answer.* The required return is 11.6%. The expected return is higher, so accept. *Check.* A beta between 0 and 1 must give a required return between 8% and 14%, and 11.6% does.

> The second line is worked the same way and reaches the opposite decision.

*Given.* Art-supplies beta 1.5; expected return 14%; same rates. *Find.* The required return, and whether to accept. *Steps.* Beta times premium: 1.5 × 6% = 9.0%. Required return: 8% + 9.0% = 17.0%. Compare: expected return 14% is below 17.0%. *Answer.* The required return is 17.0%. The expected return is lower, so reject. *Check.* A beta above 1 must give a required return above the market return of 14%, and 17.0% does.

> Ranking by expected return alone would have chosen the wrong line.

Chapter 9 found that art supplies had the higher expected return, 14% against 12%. Here the higher return does not pay for the higher market risk. The two lines also agree with the standard deviation of Chapter 9, which found art supplies the riskier, although beta and standard deviation measure different things. The owner sees a line that fails the test, and the financial manager sees the reason: its return is too low for its beta.

> The table places both lines against the security market line.

The table combines the two results. Read each row from left to right: the beta, the required return from the line, the expected return, and the line's position.

:table Both lines against the security market line
| Line | Beta | Required return | Expected return | Position and decision |
| Study guides | 0.6 | 11.6% | 12% | 0.4 points above the line: accept |
| Art supplies | 1.5 | 17.0% | 14% | 3.0 points below the line: reject |

> Common slips arise at each step of the formula.

Watch for three slips. Some students multiply beta by the market return and not by the premium. Some forget to add the risk-free rate at the end. Some compare the expected return with the market return and not with the required return.

* * *

## Summary

> The chapter's rule is that only market risk earns a premium, and beta sets its size.

The required return equals the risk-free rate plus a risk premium. Diversification removes firm-specific risk but not market risk, so only market risk earns a premium. Beta shows how strongly an investment moves with the market. The capital asset pricing model sets required return as the risk-free rate plus beta times the market risk premium, and the security market line draws it. An efficient market is one whose prices already reflect the information available.

## Think It Through

:q 10.t1 | The risk-free rate is 8% and the market return is 14%. A stationery line has a beta of 1.0 and an expected return of 13%. Find the required return, say whether the line lies above or below the security market line, and decide whether to accept it.

## Where People Go Wrong

> A common error is to think that diversifying removes all risk.

*Error:* "A large portfolio has no risk." Diversification removes firm-specific risk. Market risk remains, however many different assets are held.

> A second error is to think that a high beta marks a bad investment.

*Error:* "A high beta means a bad investment." A high beta means that the investment moves strongly with the market, in both directions. It raises the required return; it does not make the investment good or bad. The test is whether the expected return meets the required return.

> A third error is to think that an efficient market is always right.

*Error:* "An efficient market never makes mistakes." Efficiency means prices reflect the information available, which may be incomplete. Prices can still fall sharply, and investors can still lose.

> A fourth error is to treat the required return as a forecast.

*Error:* "The required return is what the investment will earn." It is the benchmark: the least return that pays for the market risk. The expected return is the estimate of what the investment may earn.

## In History

> On one day in 1987 the market fell by about a fifth, and no single business was to blame.

On Monday 19 October 1987, the Dow Jones Industrial Average, an index that follows the share prices of 30 large United States businesses, fell by 508 points, a little over 22% in one day.^4 Markets in many other countries fell as well. Nearly every business lost value together, whatever news it had announced, which is what market risk means: an investor who held many different businesses could not escape the fall.

> The crash tested how markets take in information.

The crash also tested the idea of an efficient market. No single piece of public news seemed large enough to explain so great a fall in a day, and economists still debate the causes; a presidential commission later pointed to trading by computer programs among them. Yet the market absorbed the shock within a day, and the index regained its loss in about two years.

^4: Sources round the figures differently; the index closed at about 1,739, a fall of about 22.6%.

## Sources

> Sharpe, 1964, and Fama, 1970, are the landmark works for this chapter.

William Sharpe, "Capital Asset Prices: A Theory of Market Equilibrium under Conditions of Risk" (*Journal of Finance*, 1964), set out the model that links required return to beta. Eugene Fama, "Efficient Capital Markets: A Review of Theory and Empirical Work" (*Journal of Finance*, 1970), gave the three forms of efficiency their names and reviewed the evidence. Harry Markowitz, 1952, whose work is described in Chapter 9, supplied the idea of measuring risk by spread.

## Review Questions

:q 10.1 | The risk-free rate is 7%, the market return is 13% and an investment has a beta of 1.2. Find the required return.

:q 10.2 | Explain why diversification lowers some risk but not all.

:q 10.3 | Draw a security market line with a risk-free rate of 6% and a market return of 10%, with beta from 0 to 2. Read from it the required return at a beta of 0.5 and at a beta of 1.5.

:q 10.4 | Name the three forms of market efficiency and give one example for each of information that would not help an investor if the form holds.

:q 10.5 | An investor finds an asset whose expected return sits below the security market line. Should the investor accept it? Explain in plain words.

:read William F. Sharpe, Capital Asset Prices: A Theory of Market Equilibrium under Conditions of Risk, 1964
:read Eugene F. Fama, Efficient Capital Markets: A Review of Theory and Empirical Work, 1970
:read Burton G. Malkiel, A Random Walk Down Wall Street, 1973
