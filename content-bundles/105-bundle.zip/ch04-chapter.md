:chapter IV | The Time Value of Money: Single Sums
:mood Is a taka today worth the same as a taka next year?
:desc Money has a price that depends on time. This chapter explains why a taka received sooner is worth more than a taka received later, and teaches two moves with one amount at a time: forward in time to find what it will grow to, and back in time to find what it is worth today.
:plate ch04-plate.svg | A pocket watch, a stack of coins and a young plant: time works on money as it works on a seed.

> What to bring from Chapter 1.

You will need two ideas from Chapter 1, section 1.1: *funds* and *cash flow*.^1 Debt, equity and wealth are used here as they were taught earlier.

^1: Chapter 1, 'Money, Finance and the Firm', section 1.1 'What Finance Is': funds and wealth define what is being timed.

> A friend offers the same amount today or a year from today.

A friend offers you a choice. You may take Tk 100,000 today, or you may take Tk 100,000 one year from today. The friend is honest, and you are certain you will be paid on the agreed day. Which do you choose? Nearly everyone chooses today. Yet the two amounts are equal. The choice seems to say that the same number of taka is not the same thing at two different times.

> Raising the later amount shows where people change their minds.

Now suppose the friend raises the later offer to Tk 105,000, then to Tk 110,000, then to Tk 120,000. At some amount you will change your answer and choose to wait. The amount at which you change measures how much you value time. It differs between people, but it is never zero. The habit is not foolish. Money in hand can be used, kept safe or put to work, and money promised for later can do none of these things until the day arrives.

> The chapter turns this feeling into arithmetic.

This chapter turns that feeling into arithmetic. Section 4.1 explains the idea and the words around it. Section 4.2 moves an amount forward in time to find what it will grow to. Section 4.3 moves an amount back in time to find what it is worth today. Section 4.4 allows growth to happen more than once a year. A set of worked examples closes the chapter, and every one of them can be done by hand. We study one amount at a time here; payments that repeat are the subject of Chapter 5, 'Annuities'.

* * *

## 4.1 Why Time Changes the Value of Money

@! Go slowly here.

> A farmer's seed shows why money in hand early can become more later.

Begin with a farmer who has 10 kilograms of rice seed. The farmer can eat the seed today, or sow it and wait for the harvest. If the farmer sows it, the harvest in six months may be 40 kilograms. Ten kilograms today is therefore worth more than ten kilograms after the harvest, because the seed of today can become forty. Keep this picture in mind. Seed that is sown grows, and seed that is eaten is gone. Money in hand can be sown in the same way, as a deposit in a bank or as stock for a shop.

@ Time value of money | The idea that money received sooner is worth more than the same amount received later.

> The farmer's lesson has a name: the time value of money.

We can now name the idea. The **time value of money** is the idea that money received sooner is worth more than the same amount received later. Tk 100,000 received today is worth more than Tk 100,000 received in a year, because today's money can be put to work for that year. The idea does not depend on prices rising. It holds even when every price stays the same, because the reason is the earning power of funds, not the cost of goods.

> Three reasons support the idea, and this chapter uses the first.

Three reasons support the idea. First, money in hand can earn: it can be lent, deposited or used to buy stock that will be sold at a profit. Second, prices usually rise over time, so a taka buys a little less each year. Third, a promise for later may fail, while money in hand is certain. This chapter works with the first reason and treats every future amount as certain. Chapter 9, 'Return and Risk', deals with uncertainty.

@ Interest | The price paid for using money for a period, received by the lender.
@ Interest | Word in use. In daily life, a wish to learn about something, or the benefit a person gains from a result. In finance, a payment for the use of money.

> Interest is the price of using money for a period.

The earning power of money has a price, and the price has a name. **Interest** is the price paid for using money for a period, received by the lender. If you lend Tk 100,000 to a bank for a year and the bank pays you Tk 8,000 for the use of it, the Tk 8,000 is interest. The borrower pays the interest and the lender receives it. A business that borrows through debt pays interest, and a business that deposits spare funds receives it.

@ Interest rate | The interest for one period, shown as a percentage of the amount lent or borrowed.
@ Rate | Word in use. In daily life, a speed or a count in a period, such as a rate of travel. In finance, a percentage of an amount for a period, such as 8% a year.

> The interest rate puts the price as a percentage, so loans of different sizes can be compared.

The amount of interest depends on how much is lent, so we also need a way to compare loans of different sizes. The **interest rate** is the interest for one period, shown as a percentage of the amount lent or borrowed. Tk 8,000 earned on Tk 100,000 in one year gives Tk 8,000 ÷ Tk 100,000 = 0.08, which is 8% a year. When no period is named, this book means one year. In formulas we write the rate as a decimal, so 8% becomes 0.08, and we use the letter i for it.

@ Opportunity cost | The value of the best choice given up when you pick another.

> The farmer who eats the seed gives up the harvest, and that loss is an opportunity cost.

The farmer who eats the seed gives something up. **Opportunity cost** is the value of the best choice given up when you pick another. The farmer's opportunity cost of eating the seed is the harvest that sowing would have given. In the same way, Tk 100,000 kept idle in a drawer for a year has an opportunity cost: the interest a bank would have paid, which is Tk 8,000 at 8%. The cost is real although no one sends a bill, because it is a gain that never arrived.

> Lender, borrower and owner see the same idea in different words.

The words change with the viewpoint, but the idea stays the same. A lender sees interest as a reward for waiting. A borrower sees it as the price of using money before it is earned. An owner or manager sees it as the opportunity cost of the funds placed in the business. Chapter 3 explained why earlier wealth is preferred, because wealth maximisation looks at the market value of the owners' stake over time.^2 A manager who prefers wealth sooner, and an owner who asks what the funds could have earned elsewhere, both apply the time value of money.

^2: Chapter 3, 'The Goal of the Firm and Agency', section 3.2 'Wealth Maximisation': why a manager prefers earlier wealth.

> The effect depends on the rate and on the later amount being certain.

The idea has limits. The size of the effect depends on the interest rate available: at a higher rate, waiting costs more. The idea also assumes that the later amount is certain. If the friend might not pay, the later promise is worth less for that reason as well. We set that matter aside until Chapter 9.

> A short summary of section 4.1 with a test sentence.

*Before moving on.* The time value of money is the idea that money received sooner is worth more than the same amount received later. Interest is the price of using money for a period, the interest rate is that price as a percentage per period, and opportunity cost is the value of the best choice given up. You should now be able to say why Tk 100,000 today is worth more than Tk 100,000 in a year.

## 4.2 Future Value of a Single Sum

@! Go slowly here.

> A small deposit shows interest added year by year.

Take the smallest numbers first. You deposit Tk 10,000 in a bank that pays 10% a year, and you leave it for two years. After one year the bank pays Tk 1,000, which is 10% of Tk 10,000, and your account holds Tk 11,000. Now the second year begins. How much does the bank pay? There are two possible answers, and the difference between them is the centre of this section.

@ Single sum | One payment or receipt made at one point in time.

> A single sum is one payment at one moment.

We first need a name for the Tk 10,000. A **single sum** is one payment or receipt made at one point in time. The deposit of Tk 10,000 today is a single sum. Payments that repeat each year are not single sums; Chapter 5 handles them.

@ Simple interest | Interest worked out on the original amount only.

> The first answer: interest on the original amount only.

The first answer is **simple interest**, which is interest worked out on the original amount only. Under simple interest the second year's interest is again 10% of Tk 10,000, which is Tk 1,000, so the account holds Tk 12,000 after two years. Each year adds the same amount. In words: interest = original amount × interest rate × number of years.

@ Compound interest | Interest worked out on the original amount plus interest already earned.

> The second answer: interest on the amount plus earlier interest.

The second answer is **compound interest**, which is interest worked out on the original amount plus interest already earned. In the second year the bank pays 10% of Tk 11,000, which is Tk 1,100, so the account holds Tk 12,100. The extra Tk 100 is interest earned on the first year's interest. Interest on interest is the source of the extra growth. Repeating this addition year after year is called compounding.

:pause 4.p1 | Using the deposit of Tk 10,000 at 10% a year, find the amount in the account after three years under compound interest. Work year by year.

> Simple interest ignores earlier interest; compound interest includes it.

*Before moving on to the shortcut.* Simple interest uses the original amount every year. Compound interest uses the original amount plus the interest already earned, so it grows faster.

@ Future value | What an amount today will grow to after a stated time at a stated rate.

> Future value is the amount an account will hold later, found by multiplying once for each year.

Year-by-year working becomes slow when the time is long, so a shortcut is useful. Each year the amount is multiplied by (1 + i). In the example it is multiplied by 1.10, and after two years it has been multiplied twice. The **future value** is what an amount today will grow to after a stated time at a stated rate. In words: future value = single sum × (1 + interest rate) to the power of the number of years. In symbols: FV = S × (1 + i) to the power of n, where FV is the future value, S is the single sum today, i is the interest rate for one period as a decimal, and n is the number of periods.

> The future value factor is a number that can be used for any amount.

The number (1 + i) to the power of n is called the future value factor. It does not depend on the size of the single sum, so it can be worked out once and used for any amount. For 10% and 2 years it is 1.10 × 1.10 = 1.21.

> First worked example: given, find and formula.

*Given.* S = Tk 10,000; i = 10% a year = 0.10; n = 2 years.
*Find.* The future value, FV.
*Formula.* In words: future value equals the single sum times one plus the interest rate, to the power of the number of years. In symbols: FV = S × (1 + i) to the power of n.

> First worked example: steps, answer and check.

*Steps.* (1) 1 + i = 1 + 0.10 = 1.10. (2) 1.10 to the power of 2 = 1.10 × 1.10 = 1.21. (3) FV = Tk 10,000 × 1.21 = Tk 12,100.
*Answer.* The Tk 10,000 will grow to Tk 12,100 in two years.
*Check.* Year by year, Tk 10,000 became Tk 11,000 and then Tk 12,100, so the two methods agree. The result is Tk 100 above the simple interest total of Tk 12,000, as expected.

> The business case uses the same method on a larger deposit.

:case Case file, illustrative. Date: 1 July 2024. Meghna and Sons deposits Tk 200,000 at 8% a year for 5 years. Simple interest gives Tk 200,000 × (1 + 0.08 × 5) = Tk 280,000. Compound interest gives Tk 200,000 × 1.08 to the power of 5 = Tk 293,865.62, using a future value factor of 1.469328.

> The table shows the account at the end of each year under both kinds of interest.

The table shows the account at the end of each year. Read across a row: the year, then the total under simple interest, then the total under compound interest.

:table Tk 200,000 at 8% a year (Tk)
| Year | Simple interest | Compound interest |
| 0 | 200,000.00 | 200,000.00 |
| 1 | 216,000.00 | 216,000.00 |
| 2 | 232,000.00 | 233,280.00 |
| 3 | 248,000.00 | 251,942.40 |
| 4 | 264,000.00 | 272,097.79 |
| 5 | 280,000.00 | 293,865.62 |

> In year 1 the two agree; after that compounding pulls ahead.

In year 1 the two totals agree, because there is no earlier interest to earn on. After that, compounding pulls ahead. By year 5 the compound total is Tk 13,865.62 above the simple total, and the gap grows each year.

> How to read the figure.

The figure draws the same two lines. To read it, look at the horizontal axis first: it shows the years from today. The vertical axis shows the amount in thousands of taka, and each point shows what the account holds at the end of that year. The dashed line is simple interest and the solid line is compound interest. A straight line means the same amount is added each year. A line that bends upward means each year adds more than the year before.

:fig Growth of Tk 200,000 at 8% a year over five years: simple interest against compound interest | ch04-fig01.svg

> Three cautions apply to the formula.

Three cautions apply. The rate and the time must use the same period: a yearly rate needs the time counted in years. The rate enters the formula as a decimal, so 8% is 0.08. And the formula assumes interest is added once a year; section 4.4 changes that. Compounding also works against borrowers, because a debt grows in the same way.

> A short summary of section 4.2 with a test sentence.

*Before moving on.* A single sum is one payment at one point in time. Simple interest is worked out on the original amount only, and compound interest on the original amount plus interest already earned. Future value is what an amount today will grow to, and FV = S × (1 + i) to the power of n. You should now be able to say how much Tk 10,000 becomes in two years at 10% a year, and why the answer is above Tk 12,000.

## 4.3 Present Value of a Single Sum

@! Go slowly here.

> A target amount shows the need to work backwards.

Now reverse the question. You know that you will need Tk 12,100 in two years, and a bank pays 10% a year with yearly compounding. How much must you deposit today? Section 4.2 gave a way from today to a later date. This section gives the way back. Think of one road: in section 4.2 we travelled forward along it, and here we travel the same road in the opposite direction.

@ Present value | What an amount to be received later is worth today at a stated rate.
@ Present | Word in use. In daily life, the time now, or a gift. In finance, the worth today of an amount due later.

> Present value is the worth today of a later amount.

The answer to the question has a name. The **present value** is what an amount to be received later is worth today at a stated rate. If Tk 12,100 is due in two years and the rate is 10%, its present value is the deposit that grows to Tk 12,100 in two years. Section 4.2 showed that Tk 10,000 grows to Tk 12,100 in two years at 10%. So the present value of Tk 12,100 is Tk 10,000.

@ Discounting | Finding a present value by working backwards from a future amount at a rate.

> Discounting moves an amount back in time by dividing once for each year.

The working has a name too. **Discounting** is finding a present value by working backwards from a future amount at a rate. Compounding multiplies by (1 + i) for each year, and discounting divides by (1 + i) for each year. Year by year: Tk 12,100 ÷ 1.10 = Tk 11,000, and Tk 11,000 ÷ 1.10 = Tk 10,000. Each step back removes one year of interest.

:pause 4.p2 | Using the same rate of 10% a year, find the present value of Tk 13,310 due in three years. Divide by 1.10 once for each year.

@ Discount rate | The rate used to turn a future amount into a present value.

> The discount rate is the rate used when working backwards.

The rate used in discounting has its own name. The **discount rate** is the rate used to turn a future amount into a present value. In our example it is 10%, the same number as the interest rate, because 10% is what the money could earn. One number serves in two directions: it is the interest rate when we move forward and the discount rate when we move back. Chapter 7, 'Capital Budgeting: Decisions and Cash Flows', and the chapter after it use the discount rate to value projects.

> The formula mirrors the one in section 4.2.

The shortcut mirrors the one in section 4.2. In words: present value = future amount ÷ (1 + interest rate) to the power of the number of years. In symbols: PV = FV ÷ (1 + i) to the power of n. Dividing by a factor is the same as multiplying by its reciprocal, 1 ÷ (1 + i) to the power of n, which is called the present value factor. For 10% and 2 years it is 1 ÷ 1.21 = 0.826446.

> Second worked example: given, find and formula.

*Given.* FV = Tk 12,100; i = 10% a year = 0.10; n = 2 years.
*Find.* The present value, PV.
*Formula.* In words: present value equals the future amount divided by one plus the interest rate, to the power of the number of years. In symbols: PV = FV ÷ (1 + i) to the power of n.

> Second worked example: steps, answer and check.

*Steps.* (1) 1 + i = 1.10. (2) 1.10 to the power of 2 = 1.21. (3) PV = Tk 12,100 ÷ 1.21 = Tk 10,000.
*Answer.* The present value of Tk 12,100 due in two years is Tk 10,000.
*Check.* Grow the answer forward: Tk 10,000 × 1.21 = Tk 12,100. The present value is below the future amount, as it must be when the rate is above zero.

> Tables of factors save repeated multiplication.

Tables of factors save repeated arithmetic. To read a table, find the row for the number of years, move across to the column for the rate, and read the factor. The first table gives future value factors and the second gives present value factors. A calculator can replace the tables, but the tables are useful for checking and for finding a missing rate or time, as the worked examples show.

:table Future value factors, (1 + i) to the power of n
| Years | 6% | 8% | 10% |
| 1 | 1.060000 | 1.080000 | 1.100000 |
| 2 | 1.123600 | 1.166400 | 1.210000 |
| 3 | 1.191016 | 1.259712 | 1.331000 |
| 4 | 1.262477 | 1.360489 | 1.464100 |
| 5 | 1.338226 | 1.469328 | 1.610510 |
| 6 | 1.418519 | 1.586874 | 1.771561 |

:table Present value factors, 1 ÷ (1 + i) to the power of n
| Years | 6% | 8% | 10% |
| 1 | 0.943396 | 0.925926 | 0.909091 |
| 2 | 0.889996 | 0.857339 | 0.826446 |
| 3 | 0.839619 | 0.793832 | 0.751315 |
| 4 | 0.792094 | 0.735030 | 0.683013 |
| 5 | 0.747258 | 0.680583 | 0.620921 |
| 6 | 0.704961 | 0.630170 | 0.564474 |

> The business case needs a future amount to be met by a deposit today.

:case Case file, illustrative. Date: 1 July 2024. Meghna and Sons needs Tk 500,000 on 30 June 2029 for a premises deposit. The present value at 8% a year is Tk 340,291.60, using a present value factor of 0.680583.

> Working of the case file: five years, factor, answer and check.

The time from 1 July 2024 to 30 June 2029 is 5 years. The table gives 0.680583 for 5 years at 8%, and Tk 500,000 × 0.680583 = Tk 340,291.50. A calculator that keeps every digit of the factor gives Tk 340,291.60, which is the figure in the case file; the gap of Tk 0.10 comes from rounding the factor. So a deposit of Tk 340,291.60 today at 8% will grow to Tk 500,000 on the date needed. Check: Tk 340,291.60 × 1.469328 is about Tk 500,000.

> How to read the timeline figure.

The figure shows a timeline. Time runs from left to right, and the first mark is today. The upper arrow points forward and is labelled compounding: moving along it multiplies by (1 + i) for each year. The lower arrow points back, is drawn with a dashed line and is labelled discounting: moving along it divides by (1 + i) for each year.

:fig Compounding moves an amount forward in time and discounting moves it back | ch04-fig02.svg

> Four cautions apply to present value.

Four cautions apply. A present value is below the future amount whenever the rate is above zero. A higher rate or a longer time makes the present value smaller: Tk 1 due in 5 years is worth 0.680583 at 8% but only 0.620921 at 10%. Rounding the factors can change the last digits of an answer. And the rate and the time must use the same period, as in section 4.2.

> A short summary of section 4.3 with a test sentence.

*Before moving on.* Present value is what an amount to be received later is worth today at a stated rate. Discounting finds it by dividing by (1 + i) once for each year, and the rate used is the discount rate. You should now be able to say why Tk 12,100 due in two years at 10% is worth Tk 10,000 today.

## 4.4 Compounding Within the Year

@! Go slowly here.

> A bank that adds interest twice a year pays more than one that adds it once.

A bank offers 12% a year on Tk 10,000 but adds interest every six months. Is that the same as adding 12% once at the end of the year? Work it through. After six months the bank adds half a year's interest, 6% of Tk 10,000, which is Tk 600, so the account holds Tk 10,600. After twelve months it adds 6% of Tk 10,600, which is Tk 636, so the account holds Tk 11,236. Adding once a year would give Tk 11,200. The bank that adds twice pays Tk 36 more.

@ Compounding period | The time between one addition of interest and the next.

> The compounding period is the time between additions of interest.

The reason lies in the **compounding period**, which is the time between one addition of interest and the next. In the example it is six months. Because the bank adds interest twice a year, the second addition earns interest on the first. The shorter the compounding period, the sooner interest starts to earn interest.

> Method: change the rate and the time to match the period.

To handle this by hand, change both the rate and the time to match the period. The rate for one period is the yearly rate divided by the number of periods in a year. The number of periods is the years times the number of periods in a year. In symbols: FV = S × (1 + i ÷ m) to the power of (m × t), where m is the number of periods in a year and t is the number of years. In the example, i ÷ m = 0.12 ÷ 2 = 0.06 and m × t = 2, so FV = Tk 10,000 × 1.06 to the power of 2 = Tk 11,236.

@ Effective annual rate | The single yearly rate that gives the same growth as compounding within the year.

> The effective annual rate lets us compare banks that add interest at different times.

To compare banks that add interest at different times, we turn each offer into one yearly figure. The **effective annual rate** is the single yearly rate that gives the same growth as compounding within the year. In symbols: effective annual rate = (1 + i ÷ m) to the power of m − 1. In the example, 1.06 × 1.06 − 1 = 0.1236, so the effective annual rate is 12.36%. The advertised 12% is a yearly rate that ignores compounding within the year, and the effective rate is higher.

> The business case compounds half-yearly.

:case Case file, illustrative. Date: 1 July 2024. A deposit of Tk 200,000 at 8% a year is compounded half-yearly at 4% for 10 periods and grows to Tk 296,048.86. The effective annual rate is 8.16%.

> Working of the case file and a comparison with yearly compounding.

The working is Tk 200,000 × 1.04 to the power of 10 = Tk 200,000 × 1.480244 = Tk 296,048.86. The effective annual rate is 1.04 × 1.04 − 1 = 0.0816, which is 8.16%. Yearly compounding gave Tk 293,865.62 in section 4.2, so compounding twice a year earns Tk 2,183.24 more over the five years. A common slip is to use 8% for each half-year, or to use 5 periods with the half-year rate. Always change both the rate and the number of periods.

> A short summary of section 4.4 with a test sentence.

*Before moving on.* The compounding period is the time between additions of interest. The rate per period is the yearly rate divided by the periods in a year, and the number of periods is the years times the periods in a year. The effective annual rate is the yearly rate that gives the same growth. You should now be able to say why 12% compounded half-yearly is the same as 12.36% compounded once a year.

## Worked Examples

> The examples here are a little harder than those in the sections.

These examples are a little harder than those in the sections. Each follows the same order: Given, Find, Formula, Steps, Answer and Check.

### A realistic future value

> Third worked example: given, find and formula.

*Given.* S = Tk 36,500; i = 7.5% a year = 0.075; n = 6 years.
*Find.* The future value, FV.
*Formula.* In words: future value equals the single sum times one plus the interest rate, to the power of the number of years. In symbols: FV = S × (1 + i) to the power of n.

> Third worked example: steps, answer and check.

*Steps.* (1) 1 + i = 1.075. (2) Multiply by 1.075 six times, keeping six decimal places: 1.075, 1.155625, 1.242297, 1.335469, 1.435629, 1.543302. So 1.075 to the power of 6 = 1.543302. (3) FV = Tk 36,500 × 1.543302 = Tk 56,330.52. A calculator that keeps every digit gives Tk 56,330.51; the one paisa gap comes from rounding the factor.
*Answer.* Tk 36,500 grows to about Tk 56,331 in six years.
*Check.* Simple interest would give Tk 36,500 × (1 + 0.075 × 6) = Tk 36,500 × 1.45 = Tk 52,925. The compound result is higher, as it should be.

### Finding a missing rate

> Fourth worked example: a rate to be found from the table.

*Given.* S = Tk 25,000; FV = Tk 33,275; n = 3 years.
*Find.* The interest rate, i.
*Formula.* Future value factor = FV ÷ S. Then find that factor in the row for n years.
*Steps.* (1) 33,275 ÷ 25,000 = 1.331. (2) In the row for 3 years of the future value table, the factors are 1.191016 at 6%, 1.259712 at 8% and 1.331000 at 10%.
*Answer.* The interest rate is 10% a year.
*Check.* Tk 25,000 × 1.331 = Tk 33,275, which agrees with the given amount.

### Finding a missing time

> Fifth worked example: a time to be found from the table.

*Given.* S = Tk 40,000; FV = Tk 58,773.12; i = 8% a year.
*Find.* The number of years, n.
*Steps.* (1) 58,773.12 ÷ 40,000 = 1.469328. (2) In the 8% column of the future value table, the factor 1.469328 appears in the row for 5 years.
*Answer.* The time is 5 years.
*Check.* Tk 40,000 × 1.469328 = Tk 58,773.12.

### Comparing two offers

> Sixth worked example: two offers compared by present value at two rates.

*Given.* Offer A pays Tk 70,000 in 3 years. Offer B pays Tk 85,000 in 5 years. Money can earn 8% a year. Later we try 12%.
*Find.* The better offer at each rate.
*Formula.* PV = FV × present value factor. Offers received at different times can be compared fairly only after each is turned into its present value.
*Steps at 8%.* A: Tk 70,000 × 0.793832 = Tk 55,568.24. B: Tk 85,000 × 0.680583 = Tk 57,849.56.
*Steps at 12%.* The factors are 1 ÷ 1.12 to the power of 3 = 0.711780 and 1 ÷ 1.12 to the power of 5 = 0.567427. A: Tk 70,000 × 0.711780 = Tk 49,824.60. B: Tk 85,000 × 0.567427 = Tk 48,231.30.
*Answer.* At 8% Offer B is better, by about Tk 2,281. At 12% Offer A is better, by about Tk 1,593.
*Check.* A higher rate shrinks every present value, and it shrinks the later amount by more. So the nearer offer gains ground as the rate rises, and the ranking can change.

### Common slips

> Four slips appear often, and each has a simple defence.

Four slips appear again and again. The table gives each slip and a way to avoid it. Read each row from left to right.

:table Common slips and how to avoid them
| Slip | How to avoid it |
| Using 8 in the formula instead of 0.08 | Write the rate as a decimal and say it aloud: 8% is 0.08 |
| Using a yearly rate with half-years | Divide the rate and multiply the years by the periods in a year |
| Multiplying when you should divide, or the reverse | Forward in time multiplies; back in time divides; a present value is below the later amount |
| Forgetting the 1 in (1 + i) | The factor is (1 + i) to the power of n, never i to the power of n |

## Summary

> Summary of the chapter.

Money received sooner is worth more than the same amount received later: this is the time value of money. Interest is the price of using money, and the interest rate states it as a percentage of the amount per period. Compound interest earns interest on interest, and future value is FV = S × (1 + i) to the power of n. Present value is found by discounting, PV = FV ÷ (1 + i) to the power of n, at the discount rate. When interest is added within the year, divide the rate and multiply the periods, and compare offers by the effective annual rate.

## Think It Through

:q 4.t1 | A student chooses between Tk 90,000 today and Tk 130,000 in 5 years. Money can earn 7% a year, compounded yearly. Find the present value of Tk 130,000, decide which offer is better, and show a check by finding the future value of Tk 90,000.
:q 4.t2 | Tk 15,000 grows to Tk 21,277.79 at 6% a year. Use the future value table to find the number of years.

## Where People Go Wrong

> Five common misunderstandings are stated and corrected in the table.

The table lists five common mistakes. Read each row from left to right: the first column gives the mistake and the second gives the correction.

:table Common mistakes and corrections
| Mistake | Correction |
| Tk 100,000 today and Tk 100,000 in a year are worth the same because the numbers match | Money today can be put to work, so the later amount has a lower present value |
| Simple and compound interest are equal | They agree only in the first period; after that compound interest is larger |
| Present value is the amount you will receive | Present value is today's worth of that amount; the amount received later is the future value |
| The discount rate and the interest rate are unrelated | They can be the same number, used in opposite directions |
| A yearly rate can be used for half-years without change | Divide the rate by the periods in a year and multiply the years by the same number |

## In History

> In 1683 Jacob Bernoulli asked what happens when interest is added more and more often.

In 1683 the Swiss mathematician Jacob Bernoulli (1654–1705) studied a question about compound interest. Suppose Tk 1 is lent at 100% a year. Added once, the interest gives Tk 2 at the end of the year. Added twice, at 50% each half-year, it gives Tk 2.25. Bernoulli asked what happens if interest is added more and more often. The amount keeps rising, but each step adds less than the one before.

> Bernoulli showed the amount stays between 2 and 3, and the limit became the number e.

Bernoulli showed that the amount never reaches Tk 3, and that it stays above Tk 2. The limit is the number now written *e*, about 2.71828; the letter was introduced later by Leonhard Euler, who first used it in a letter in 1731. In this chapter the same idea appears in a smaller form. At 12% a year, the effective annual rate rises from 12% to 12.36% with half-yearly compounding and to 12.55% with quarterly compounding, but it can never rise above about 12.75%, however often interest is added.

## Sources

> Bernoulli's 1683 problem is the early source of the limit that became the number e.

Jacob Bernoulli's study of compound interest in 1683 is the first known step towards the number e. It matters here because it showed that adding interest more often raises the total, but only up to a limit.

> Euler's book of 1748 gave the number its full treatment.

Leonhard Euler, *Introductio in analysin infinitorum* (1748), gave the full treatment of e and showed that it is the limit of Bernoulli's expression. It matters because it fixed the number and its notation for later use in finance and science.

## Review Questions

:q 4.1 | Find the future value of Tk 15,000 at 9% a year for 6 years.
:q 4.2 | Find the present value of Tk 80,000 due in 4 years at 11% a year.
:q 4.3 | Compare simple interest with compound interest on Tk 25,000 over 8 years at 6% a year, and state the difference.
:q 4.4 | Find the effective annual rate for 12% a year compounded quarterly.
:q 4.5 | Explain the opportunity cost of idle cash in plain words, with a small example.

:read Jacob Bernoulli, work on compound interest, 1683
:read Leonhard Euler, Introductio in analysin infinitorum, 1748
