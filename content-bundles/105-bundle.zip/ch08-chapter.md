:chapter VIII | Capital Budgeting: Evaluation Techniques
:mood Two ships sail tomorrow: which cargo deserves the merchant's money?
:desc A business that has measured the cash flows of a project must still decide whether the project is worth its money. This chapter teaches four tools for that judgement: payback period, net present value, internal rate of return and the profitability index. It also shows what to do when the tools give different answers.
:plate ch08-plate.svg | A merchant weighs two cargo manifests while two ships wait in the harbour

> A merchant must choose one cargo, and the two manifests point in different directions.
> You will need: Chapter 7, section 7.3, and Chapter 6, section 6.2.

A merchant in a busy port has money for one cargo only. Two captains bring him lists of goods, called manifests, and each captain asks for the same sum. The first captain promises that the merchant will have his money back within a year, but the cargo then earns little. The second captain needs longer, but his cargo earns far more in the end. Which captain should the merchant choose?

> Speed, size and timing each pull the choice a different way.

The merchant can argue for either captain. Speed is attractive, because money returned early can be used again, and because the future may disappoint. Size is attractive, because the larger total is worth more. Timing complicates both: a coin received in a year's time is worth less than a coin received today, so the totals cannot be compared as they stand.

> This chapter gives four tools for the judgement.

In Chapter 7 you learned to measure the cash flows of a project. This chapter teaches how to judge them. We study four tools in turn, and we apply each one to the same pair of projects at Meghna and Sons, the family bookshop in Dhaka, so that you can compare the answers. Where the tools disagree, the last sections explain which one to trust and why.

* * *

## Payback Period

> The first question most owners ask is how soon the money returns.

An owner who has paid Tk 10,000 for a machine soon asks a plain question: when will I have my money back? Suppose the machine brings in Tk 5,000 at the end of each year for three years. After year 1 the owner has recovered Tk 5,000, after year 2 the full Tk 10,000. The answer is two years, and that answer has a name.

@ Payback period | The time a project takes to recover its initial investment from its cash flows.

> Payback period is the time needed to recover the initial investment.

The **payback period** is the time a project takes to recover its initial investment from its cash flows. For the machine above, the payback period is 2 years. A shorter payback period means the money is tied up for less time, which is why many owners like the tool. It also means the business is exposed to the unknown future for less time.

> Equal inflows allow a one-step formula.

*Given.* Initial investment Tk 10,000; inflows of Tk 5,000 at the end of each of 3 years. *Find.* The payback period. *Formula.* With equal inflows, payback period (years) equals initial investment divided by the yearly inflow. *Steps.* 10,000 ÷ 5,000 = 2. *Answer.* The payback period is 2 years. *Check.* Two years of Tk 5,000 equal Tk 10,000, so the money is recovered exactly at the end of year 2.

> Unequal inflows need a running total.

Real projects rarely give equal inflows, so we need a second method. Add the inflows year by year to make a running total, called the cumulative cash flow, starting from the negative initial investment. Find the year in which the total changes from negative to positive. Then use this rule: payback period equals the number of full years before recovery, plus the amount still unrecovered at the start of the recovery year, divided by the inflow of that year. This assumes the inflows arrive evenly through the year.

> Case: two projects with the same initial investment compete.

:case Case file, illustrative. 2 February 2025: Meghna and Sons compares two mutually exclusive projects. Project Press: initial investment Tk 900,000; inflows Tk 276,000 in years 1 to 4 and Tk 456,000 in year 5. Project Fit-out: initial investment Tk 900,000; inflows Tk 400,000; 300,000; 250,000; 200,000; 150,000. Required return 12%.

> The calculation for Press goes year by year.

*Press.* After year 1 the cumulative cash flow is −900,000 + 276,000 = −624,000; after year 2, −348,000; after year 3, −72,000; after year 4, +204,000. Recovery therefore falls in year 4. Unrecovered at the start of year 4: Tk 72,000. Fraction of year 4: 72,000 ÷ 276,000 = 0.26. Payback period = 3 + 0.26 = 3.26 years.

> Fit-out recovers its money sooner.

*Fit-out.* The running total of inflows is 400,000 after year 1 and 700,000 after year 2, still short of 900,000. In year 3 the inflow is 250,000. Unrecovered at the start of year 3: 900,000 − 700,000 = Tk 200,000. Fraction of year 3: 200,000 ÷ 250,000 = 0.80. Payback period = 2 + 0.80 = 2.80 years. *Check.* After 3 years the inflows total 950,000, which is above 900,000, so recovery does fall in year 3.

> The figure shows the running total rising through zero.

Figure 8.1 shows the cumulative cash flow of Press. The horizontal axis shows years from the start; the vertical axis shows the running total in thousands of taka. Each point is the total at the end of a year. The line starts at −900 and rises with each inflow. The point where it crosses the zero line is the payback period, here at 3.26 years.

:fig Cumulative cash flow of Project Press, crossing zero at the payback point | ch08-fig01.svg

> A decision rule needs a limit set by management.

To turn the tool into a decision rule, managers set a maximum acceptable payback period, for example 3 years. A project is accepted if its payback period is no longer than the limit. With a limit of 3 years, Fit-out passes at 2.80 years and Press fails at 3.26 years. The limit is a judgement, not a fact, and a different limit gives a different answer.

> Payback ignores later cash and the timing of money.

The tool has real limits. It ignores all cash flows after the payback point: Press earns Tk 456,000 in year 5, and payback never looks at it. It treats a taka in year 1 and a taka in year 3 as equal, so it ignores the time value of money. And the limit has no firm basis. Payback remains useful as a quick check of how long money is at risk, but it cannot be the only test.

> Different people use payback for different reasons.

The owner may like payback because it speaks of risk: the sooner the money returns, the less time the future has to spoil the plan. The financial manager values it as a quick screen, which removes weak proposals before slower work begins. A lender may care about it too, since a short payback suggests that loan instalments will be met. An employee or customer rarely sees the figure, but both feel its effects when a business cannot recover its money and must cut costs.

:pause 8.p1 | Project A has an initial investment of Tk 60,000 and inflows of Tk 30,000 in each of years 1 and 2, then nothing. Project B has the same initial investment and inflows of Tk 20,000 in each of years 1 to 6. Find each payback period. What does payback miss?

> Recap: payback measures the speed of recovery only.

*Before moving on.* The payback period is the time to recover the initial investment. Add the inflows into a running total, find the recovery year, and add the fraction of that year. It is simple but blind to later cash and to timing.

* * *

## Net Present Value

> A promise of more taka later is worth less than it seems.

Return to the machine of Tk 10,000 with inflows of Tk 5,000 for three years. The inflows total Tk 15,000, so the machine seems to gain Tk 5,000. But money received later is worth less than money received today, because today's money can be used or invested at once. To compare fairly we convert every inflow into its worth today, using the method of Chapter 6, section 6.2, in which each receipt of a mixed stream is discounted separately.

@ Net present value | The present value of a project's cash inflows minus its initial investment.

> Net present value is the worth today of the inflows, less what we pay.

**Net present value** is the present value of a project's cash inflows minus its initial investment. Net present value is often shortened to NPV. For a project with a negative result, the inflows are worth less today than the initial investment. The discount rate used to find each present value is chosen next.

@ Return | Word in use. In daily life, the act of giving something back. In finance, the gain from an investment, shown as a percentage of the money invested.
@ Required return | The lowest return a project must earn to be worth accepting.

> The required return is the discount rate and the test.

The **required return** is the lowest return a project must earn to be worth accepting. Other books call it the required rate of return or the hurdle rate. In this chapter we use it as the discount rate. It depends on the risk of the project and on the cost of the funds; Chapter 10 and Chapter 17 explain how it is found. For Meghna and Sons it is 12%.

> The decision rule follows from the meaning of zero.

The rule is: accept the project when its net present value is zero or positive, and reject it when it is negative. A zero net present value means the project earns exactly the required return. A positive value means it earns more, and the amount is the extra worth added, in taka today.

> A clean example shows the method.

*Given.* Initial investment Tk 10,000; inflows of Tk 5,000 at the end of years 1, 2 and 3; discount rate 10%. *Find.* The net present value. *Formula.* The present value of an inflow equals the inflow divided by (1 + r) to the power of t, where r is the discount rate and t the year. Net present value equals the sum of these present values minus the initial investment. *Steps.* Year 1: 5,000 ÷ 1.10 = 4,545. Year 2: 5,000 ÷ 1.21 = 4,132. Year 3: 5,000 ÷ 1.331 = 3,757. Sum = 12,434. NPV = 12,434 − 10,000 = Tk 2,434. *Answer.* Net present value is Tk 2,434, so the machine should be accepted. *Check.* The inflows are equal, so Chapter 5 gives a shortcut: 5,000 × 2.4869 = 12,434, the same.

:pause 8.p2 | A project has an initial investment of Tk 20,000 and inflows of Tk 12,000 at the end of each of years 1 and 2. The discount rate is 10%. Find the net present value and say whether to accept.

> Net present value has its own limits.

Net present value also has limits, and an honest student should know them. Its answer depends on the forecast cash flows, and forecasts can be wrong. It depends on the chosen required return too: a higher rate lowers every present value, so a project that passes at 12% might fail at 18%. Because of this, a careful business tests a project at more than one rate. Many students find this uncomfortable, because the method looks exact. The arithmetic is exact; the inputs are estimates.

> A realistic example uses five unequal inflows.

Now take Fit-out at 12%. Table 8.1 sets out the work. Read each row as one year: the inflow, the divisor (1.12 to the power of the year number) and the present value, which is the inflow divided by the divisor. The last row adds the present values.

:table Present value of Project Fit-out at 12%, in taka
| Year | Inflow | Divisor | Present value |
| 1 | 400,000 | 1.120000 | 357,143 |
| 2 | 300,000 | 1.254400 | 239,158 |
| 3 | 250,000 | 1.404928 | 177,945 |
| 4 | 200,000 | 1.573519 | 127,104 |
| 5 | 150,000 | 1.762342 | 85,114 |
| Total | | | 986,464 |

> Fit-out has a positive net present value.

NPV = 986,464 − 900,000 = Tk 86,464. The value is positive, so Fit-out is acceptable at 12%. *Check.* The inflows total 1,300,000, and the present value is much lower, as we expect from discounting.

> Press uses the annuity shortcut for years 1 to 4.

For Press the inflows in years 1 to 4 are equal, so they form an annuity. The present value factor for 4 years at 12% is (1 − 1.12 to the power of −4) ÷ 0.12 = 3.0373493. Then 276,000 × 3.0373493 = 838,308. The year 5 inflow is 456,000 ÷ 1.762342 = 258,747. The total is 838,308 + 258,747 = 1,097,055, so NPV = 1,097,055 − 900,000 = Tk 197,055. Press is also acceptable.

> When only one project can be accepted, the larger net present value wins.

Press and Fit-out are mutually exclusive, so the shop can accept only one. When both pass the test, choose the larger net present value, because it measures the extra worth in taka today: Tk 197,055 against Tk 86,464. Press is the better project on this measure.

> Recap: discount every inflow, subtract the initial investment, accept if the result is not negative.

*Before moving on.* Net present value equals present value of inflows minus the initial investment. The required return is the discount rate and the hurdle. Accept when the value is zero or positive; among exclusive projects, choose the highest.

* * *

## Internal Rate of Return and Profitability Index

> Sometimes owners prefer one percentage to a sum of taka.

Net present value answers in taka. Many owners prefer an answer in percent, which is easy to compare with a loan rate. Two further tools give that kind of answer, and both build on net present value.

@ Rate | Word in use. In daily life, speed or price per unit. Here, the rate in internal rate of return is a yearly return on the money invested, not a charge set by a lender.
@ Internal rate of return | The discount rate at which a project's net present value is exactly zero.

> The internal rate of return is the discount rate that makes the net present value zero.

The **internal rate of return** is the discount rate at which a project's net present value is exactly zero. Often shortened to IRR, it is the yearly return the project itself earns. Figure 8.2 shows how it is found. The horizontal axis shows the discount rate; the vertical axis shows the net present value of Press in thousands of taka. As the discount rate rises, the value falls. The point where the line crosses zero, near 19.9%, is the internal rate of return.

:fig Net present value of Project Press at different discount rates, crossing zero at the internal rate of return | ch08-fig02.svg

> Trial and interpolation find the rate by hand.

To find it by hand, calculate the net present value at two rates, one giving a positive value and one a negative value, then interpolate. For Press, NPV at 15% is +114,687 and at 20% is −2,253. The rate is 15 + 5 × 114,687 ÷ (114,687 + 2,253) = 15 + 4.90 = 19.9%.^1 The decision rule is to accept when the internal rate of return is at least the required return: 19.9% exceeds 12%. For Fit-out, NPV at 15% is +27,975 and at 20% is −56,925, giving about 16.6%, which also exceeds 12%.

^1: A spreadsheet finds the rate with a built-in function. It works by the same repeated trial, only faster.

@ Profitability index | The present value of a project's inflows divided by its initial investment.

> The profitability index shows the present value earned for each taka invested.

The **profitability index** is the present value of a project's inflows divided by its initial investment. Press: 1,097,055 ÷ 900,000 = 1.22. Fit-out: 986,464 ÷ 900,000 = 1.10. A value above 1 means each taka invested returns more than a taka in present value. Accept when the index is at least 1, which is the same test as a net present value of zero or more.

> Both tools have limits.

Both tools have limits. The internal rate of return can mislead when projects differ much in size or timing. The profitability index ignores the size of the gain: a small project can have a high index and still add little. Here the two projects have equal initial investments, so neither problem arises.

* * *

## When the Methods Disagree

> The same two projects now receive four different tests.

Table 8.2 collects the results for Press and Fit-out. Read each row as one tool and each column as one project. The last column names the project that tool prefers.

:table Results for the two projects
| Tool | Press | Fit-out | Prefers |
| Payback period | 3.26 years | 2.80 years | Fit-out |
| Net present value at 12% | Tk 197,055 | Tk 86,464 | Press |
| Internal rate of return | 19.9% | 16.6% | Press |
| Profitability index | 1.22 | 1.10 | Press |

> Payback disagrees because it ignores late cash.

Payback prefers Fit-out; the other three prefer Press. The reason is the shape of the cash flows. Fit-out is front-loaded, so it recovers its money first. Press brings large cash in year 5, which payback ignores and the discounted tools count.

> Net present value decides because it measures worth in taka.

When rankings conflict for mutually exclusive projects, let net present value decide. It uses all cash flows, respects timing and states the result as a gain in taka. Payback still has a role as a second check, for example when the business is short of cash. Even net present value and the internal rate of return can disagree when projects differ in size or timing; again, net present value is the guide.

> The choice also depends on the business's situation.

Situation matters as well. An owner with plenty of funds will weigh the extra Tk 110,591 of value heavily. An owner who must repay a loan soon may value the early cash of Fit-out. Even so, this is a reason to look at the cash plan, not to change the ranking by value. The ranking stays the same; only the owner's readiness to accept a lower value for speed changes.

* * *

## Worked Example: Choosing Between Press and Fit-out

> The four tools meet in one decision.

We now combine the tools and justify a choice, in the standard order: Given, Find, Formula, Steps, Answer and Check.

> Given and Find: the data and the question.

*Given.* The case file of 2 February 2025: Press and Fit-out, each with an initial investment of Tk 900,000, a required return of 12% and the inflows stated earlier. *Find.* Which project Meghna and Sons should accept. *Formula.* Payback period as above; net present value equals present value of inflows minus initial investment; accept if the value is at least zero; choose the highest value among exclusive projects.

> Steps: check each project on the discounted tools.

*Steps.* Press by year: 246,429 + 220,026 + 196,451 + 175,403 + 258,747 = 1,097,056. This differs from the earlier 1,097,055 by Tk 1, because each term was rounded; the unrounded total is 1,097,055.07. Both agree that NPV is Tk 197,055 for Press, and Table 8.1 gives Tk 86,464 for Fit-out. The profitability indices are 1.22 and 1.10.

:box IN SHORT
Among mutually exclusive projects that pass the test, choose the highest net present value. Use payback only as a second look at how long the money is tied up.

> Answer and check: accept Press.

*Answer.* Accept Press. Both projects pass the net present value test, but Press adds Tk 197,055 against Tk 86,464, and the internal rate of return and the profitability index agree. The only tool that prefers Fit-out is payback, and its advantage is a recovery 0.46 years earlier, in exchange for Tk 110,591 less value. *Check.* 197,055 − 86,464 = 110,591. Press passes a stricter test as well: its internal rate of return is 19.9%, well above 12%. A common slip is to compare payback figures first and stop; another is to compare projects at different discount rates.

* * *

## Summary

> The four tools and the rule for conflict.

The payback period is the time to recover the initial investment; it is simple but ignores later cash and timing. Net present value discounts the inflows at the required return and subtracts the initial investment; accept when it is zero or more. The internal rate of return is the discount rate that makes the net present value zero. The profitability index is the present value of inflows divided by the initial investment. When rankings conflict for mutually exclusive projects, net present value decides.

## Think It Through

> Two questions to test your judgement.

:q 8.t1 | Two mutually exclusive projects each have an initial investment of Tk 500,000 and a required return of 10%. Project X has inflows of 300,000, 200,000, 100,000 and 100,000 in years 1 to 4. Project Y has inflows of 100,000, 150,000, 200,000 and 400,000. Find each payback period and net present value, rank the projects by each tool, and decide.
:q 8.t2 | In plain words, explain why a project's net present value is exactly zero when the discount rate equals its internal rate of return.

## Where People Go Wrong

> A short payback is not the same as a good project.

Many students believe the project with the shorter payback is the better one. It is only the faster one. Project A in the pause question recovers its money in 2 years but never earns more than its cost.

> Discount rates must stay the same when comparing.

Another mistake is to compare net present values worked out at different discount rates. Use one required return for all projects of similar risk. Otherwise the comparison measures the choice of rates, not the projects.

> The internal rate of return is not always the whole story.

A third mistake is to treat the internal rate of return as a guaranteed yearly gain. It is the rate at which the net present value reaches zero. It also does not state the size of the gain in taka.

> Cash flows, not accounting profit, go into every tool.

A fourth mistake is to use accounting profit instead of the cash flows built in Chapter 7. Depreciation, for example, must be added again, as that chapter showed.

## In History

> Two writers shaped the idea of discounting in business.

Irving Fisher (1867–1947) was an American economist at Yale University. In The Theory of Interest (1930) he set out the idea behind net present value: the worth of an investment is the present value of the cash it will bring. For many years, however, most firms judged projects by simpler rules such as payback.

> Dean carried discounting into company practice.

Joel Dean (1906–1979) was an American economist who wrote Capital Budgeting (Columbia University Press, 1951). Later writers often credit this book, and his consulting work, with moving discounted cash flow methods into company practice. The tools of this chapter descend from their work.

## Sources

> Fisher gave the theory.

Irving Fisher, The Theory of Interest (1930). It matters because it explains why a sum due later is worth less today and shows how to value a stream of future receipts.

> Dean gave the practice.

Joel Dean, Capital Budgeting (1951). It matters because it is an early book that treats the choice of investments as a management method for companies, and it helped to spread discounting.

## Review Questions

:q 8.1 | Find the payback period of a project with an initial investment of Tk 400,000 and inflows of 120,000, 150,000, 180,000 and 200,000 in years 1 to 4.
:q 8.2 | Find the net present value of the same project at a required return of 10%. Should it be accepted?
:q 8.3 | State the accept-or-reject rule for payback period, net present value, internal rate of return and the profitability index.
:q 8.4 | For the same project, calculate the net present value at 20% and at 25%, then estimate the internal rate of return by interpolation.
:q 8.5 | Project M has inflows with a present value of Tk 330,000 and an initial investment of Tk 300,000. Project N has a present value of Tk 540,000 and an initial investment of Tk 500,000. Find the profitability index and net present value of each. Which ranks first by each measure?
:q 8.6 | In one sentence each, say what the payback period, net present value, internal rate of return and profitability index measure.
:q 8.7 | When two mutually exclusive projects rank differently by payback and by net present value, which should decide, and why?

:read Fisher, The Theory of Interest, 1930
:read Dean, Capital Budgeting, 1951
