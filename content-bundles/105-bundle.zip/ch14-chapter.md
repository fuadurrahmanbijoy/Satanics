:chapter XIV | Valuing Common and Preferred Stock
:mood What is a piece of a business worth when you cannot see the profit it will make?
:desc This chapter explains what the owners of a business hold and how to give that holding a price. You will value preferred stock and common stock with level dividends, then common stock whose dividends grow at a steady rate. You will end by comparing stock with bonds.
:plate ch14-plate.svg | Merchants inspect cargo chests beside a ship at an Amsterdam quay

:box YOU WILL NEED
Chapter 12, section 12.1 'Borrowing and Fixed Financing Charges'; Chapter 5, section 5.1 'What an Annuity Is'; and Chapter 13, section 13.2 'The Idea of Value'.

> A neighbour offers a piece of her business for Tk 80. Is that fair?

Suppose a neighbour offers to sell you a small piece of her business. The piece pays its owner Tk 5 at the end of every year, and she expects the payments to continue for ever. She asks Tk 80 for it. Is that a fair price? You cannot see the future payments, and you cannot ask the business to return your money on demand. All you would hold is a paper that says you own a part. How would you decide what the paper is worth?

> The fair price depends on the payments and on the return you require.

Most people begin by asking what they could earn elsewhere. Suppose a safe deposit pays 10% a year. Then Tk 50 in that deposit gives you Tk 5 each year. A price of Tk 80 now looks too high, because Tk 80 in the deposit would give Tk 8. A price of Tk 40 looks like a bargain. This reasoning carries most of the chapter: the worth of a piece of a business is linked to the payments it makes and to the return that you require from your money.

> Three questions remain, and the chapter answers each in turn.

The neighbour's offer still hides three questions. What exactly do you own when you hold the paper? What if the yearly payment is not level but grows? And how does the paper differ from a bond, which also pays regular amounts? We take the questions in that order, beginning with the rights that come with ownership.

* * *

## 14.1 Rights of Shareholders

> Owning stock makes you an owner, and ownership brings a voice and a claim.

@ Stock | Word in use. In a shop, the goods kept ready for sale. In finance, ownership of a business, held in units called shares.
@ Share | Word in use. In daily life, a part of something divided among people, such as a share of a meal. In finance, one unit of ownership in a business.

Chapter 12 introduced common stock and preferred stock as the two kinds of stock that a business can issue.^1 Here we ask a new question: what does an owner actually hold? Picture a market stall owned by three cousins. Each cousin may speak and vote when the family meets to decide how to run the stall, and each is entitled to a part of whatever remains after the bills are paid. A voice and a claim: these two ideas are the centre of ownership, and each has a name. A person who owns shares is a shareholder.

^1: Chapter 12, 'Financial and Total Leverage', section 12.1 'Borrowing and Fixed Financing Charges': common stock and preferred stock were first defined there.

> The first right is a vote on how the business is guided.

@ Voting right | the right of a shareholder to vote on matters such as choosing directors

The first right is the voice. A **voting right** means the right of a shareholder to vote on matters such as choosing directors. Directors are the people who guide a business on behalf of its owners. A holder of common stock usually receives one vote for each share held, so a holder of 100 shares casts 100 votes at the yearly meeting. The details differ between countries and between businesses, because the law of each country and the rules of each business set them.

> The second right is to whatever is left after everyone else is paid.

@ Residual claim | the right to what is left of a business's income and assets after all others are paid

The second right is the claim. Owners of common stock hold a **residual claim**, which means the right to what is left of a business's income and assets after all others are paid. The word *residual* means left over. Suppose a business has Tk 100 available after paying its suppliers and staff. It pays Tk 30 of interest to its lender and Tk 20 of dividends to its preferred stockholders. The Tk 50 that remains belongs to the common stockholders. The directors may pay all of it as dividends or keep some of it inside the business.

> The claim has no fixed size: it can be large, or it can be nothing.

The residual claim has a main limit: it has no fixed size. A lender is promised a fixed amount, but an owner is promised nothing. When the business does well, the remainder can be large and the owner gains. When the business does badly, the remainder can be small or nothing. If the business ends, the common stockholders are paid last, after lenders and preferred stockholders, and they may receive nothing. This is why common stock carries more risk than a bond, and why owners expect a higher return for holding it.

> A second reward is selling stock for more than you paid.

@ Capital gain | the profit made when an asset is sold for more than it cost

Dividends are not the only reward. A **capital gain** is the profit made when an asset is sold for more than it cost. If you buy stock for Tk 50 and later sell it for Tk 56, your capital gain is Tk 6. Dividends and capital gain together form your return from holding the stock. If you sell for less than you paid, you have a loss instead.

> Preferred stock pays a fixed dividend ahead of common stock, usually without a vote.

Preferred stock is a different bargain. Its holders usually receive a fixed dividend, for example Tk 8 on each share every year. The business must pay the preferred dividend before it pays any dividend to common stockholders. If the business ends, preferred stockholders are paid before common stockholders, though after lenders. In return for this priority, preferred stockholders usually give up the voting right, and their dividend does not rise when the business prospers. Terms differ from one issue to another. Some preferred stock is cumulative, which means that a skipped dividend is still owed and must be paid before any common dividend. Unlike interest on a loan, a preferred dividend is not a legal debt, so the directors can skip it, although doing so harms the business's standing with investors.

> Recap of the section on rights.

*Before moving on.* Stock makes you an owner. Common stock carries a voting right and a residual claim, and its owner may also gain from selling it at a higher price. Preferred stock pays a fixed dividend ahead of common stock, usually without a vote.

* * *

## 14.2 Valuing Preferred Stock and Level Dividends

> The value of stock is the present value of the dividends it will pay.

How much should you pay for a stream of payments that never ends? The answer comes from an idea that you have used before: the value of any asset is the present value of the cash that it will bring. For stock, the cash is the dividends. A fixed dividend paid at the end of every year for ever is a perpetuity.^2 Because the dividend is level, the present values of all the payments add up to a short formula.

^2: Chapter 5, 'Annuities', section 5.1 'What an Annuity Is': a fixed dividend for ever is a perpetuity.

> For a level dividend, divide the yearly dividend by the required return.

The rule is short. The value of stock with a level dividend equals the yearly dividend divided by the required return. In symbols, P = D ÷ r. Here P is the value of one share today, D is the dividend paid each year, and r is the required return written as a decimal, so 12% becomes 0.12. Preferred stock fits this rule directly, because its dividend is fixed. Common stock fits it only in the special case where the dividend stays level.

> A clean example: a Tk 6 dividend and a 12% required return.

*Given.* A preferred share pays a fixed Tk 6 each year for ever. The required return is 12%, which is 0.12.
*Find.* The value of one share today.
*Formula.* Value equals the yearly dividend divided by the required return, or P = D ÷ r.
*Steps.* P = Tk 6 ÷ 0.12 = Tk 50.00.
*Answer.* One share of this preferred stock is worth Tk 50.00.
*Check.* Tk 50.00 placed in a deposit that pays 12% gives Tk 6 each year, which equals the dividend. An investor who requires 12% should therefore pay no more than Tk 50.00.

> The same rule fits common stock only if its dividend really stays level.

The rule has limits. A preferred dividend is fixed by the terms of the issue, so the rule suits it well. A common dividend is decided by the directors year by year, so a level dividend is only an assumption. A business that earns more profit may raise its dividend, and a business that earns less may cut it. The rule also takes the required return as steady, although investors change their minds. The next section removes the first limit by letting the dividend grow.

> Recap of the section on level dividends.

*Before moving on.* Stock is worth the present value of its dividends. When the dividend is level, the value is the dividend divided by the required return. This rule fits preferred stock well and common stock only when the dividend is level.

* * *

## 14.3 Valuing Stock with Growing Dividends

> A growing dividend has no last payment, yet its value is not endless.

A publishing business paid a dividend of Tk 4.00 on each share this year, and its directors expect to raise the dividend by 6% every year for ever. Each payment is larger than the one before, and there is no final payment. Must we add up an endless list of present values? The answer is no, because a short formula does the work. First we must see how the dividends behave.

> Each dividend is the one before it multiplied by one plus the growth rate.

The dividend paid most recently is the last dividend, written D₀. The next dividend, D₁, is the last dividend increased by the growth rate g: D₁ = D₀ × (1 + g). With D₀ = Tk 4.00 and g = 6%, D₁ = 4.00 × 1.06 = Tk 4.24. The dividend after that is 4.24 × 1.06 = Tk 4.49, and so on. The figure below shows the first five payments. To read it, look at the horizontal axis, which shows the year, and at the height of each bar, which shows the dividend paid in that year in taka. The first bar is the dividend already paid. The rising bars are the dividends to come.

:fig Dividends growing at 6% a year, from Tk 4.00 to Tk 5.35 | ch14-fig01.svg

> The dividend growth model values stock as next dividend over required return minus growth.

@ Dividend growth model | a formula valuing stock as next dividend divided by required return minus growth rate

The pattern gives us the tool. The **dividend growth model** is a formula valuing stock as next dividend divided by required return minus growth rate. In words: value today equals the next dividend divided by the difference between the required return and the growth rate. In symbols, P₀ = D₁ ÷ (r − g), where P₀ is the value today, D₁ is the next dividend, r is the required return and g is the growth rate, both written as decimals. The formula comes from the endless list of present values. Each dividend grows by the factor 1 + g, yet is discounted by the factor 1 + r. When r is larger than g, each present value is a little smaller than the one before, and the endless total settles at D₁ ÷ (r − g).

:box IN SHORT
Value today = next dividend ÷ (required return − growth rate). The next dividend is the last dividend × (1 + growth rate).

:pause 14.p1 | A stock's next dividend is Tk 10, its required return is 15% and its growth rate is 5%. What is its value today?

> The formula fails when growth equals or exceeds the required return.

The formula has firm limits. First, the growth rate must stay below the required return. If g equals r, the bottom of the fraction is zero. If g is larger than r, the answer is negative, which has no meaning. No business can keep raising its dividends faster than the required return for ever. Second, the formula assumes steady growth for ever, so it suits mature businesses better than young ones. Third, the answer is very sensitive when r and g are close. With D₀ = Tk 4.00 and r = 12%, a growth rate of 11% gives 4.44 ÷ 0.01 = Tk 444.00, though a growth rate of 6% gives only Tk 70.67. Fourth, a growth rate of zero returns us to the level formula of the last section.

> The required return on stock reflects its risk and comes from the capital asset pricing model.

Where does r come from? A stock is risky, so its required return is higher than that of a safe deposit. The capital asset pricing model, which you met earlier, builds r in steps: start with the return on a safe investment, then add the stock's beta multiplied by the extra return that the market pays above the safe rate. Take a safe return of 6%, a market return of 11% and a beta of 1.2. Then r = 6% + 1.2 × (11% − 6%) = 6% + 6% = 12%. Every input is an estimate, so the value we find is an estimate too. It is the stock's intrinsic value, which can differ from the price at which the stock trades.

> Recap of the section on growing dividends.

*Before moving on.* A growing dividend is valued by the dividend growth model: next dividend divided by the required return minus the growth rate. The growth rate must stay below the required return. The required return comes from the capital asset pricing model.

* * *

## 14.4 Comparing Bonds and Stock

> A bond holder is a lender, and a stockholder is an owner.

Both a bond and a stock bring cash to their holder, and both are valued by discounting that cash at the required return.^3 The difference lies in the promise. A bond holder is a lender who is promised fixed interest and repayment of the amount lent. A stockholder is an owner who is promised nothing, but who holds a vote and a residual claim. The table below sets out six features. Read each row from left to right: the first cell names a feature, and the next two cells describe the bond and the common stock.

:table Bond and common stock compared
| Feature | Bond | Common stock |
| Holder is | A lender | An owner |
| Payment | Interest fixed by contract | Dividend decided by the directors |
| Voting right | None | Usually one vote a share |
| Claim if the business ends | Paid before owners | Residual claim, paid last |
| Reward | Interest and repayment | Dividends and capital gain |
| Risk to the holder | Lower | Higher |

^3: Chapter 13, 'Valuing Bonds', section 13.4 'Discount, Par and Premium Bonds': bond value is worked in the same way.

> From the investor's viewpoint, the choice trades certainty for possible reward.

Viewpoint matters. A cautious investor values certain payments and chooses the bond. An investor who accepts risk for a chance of greater reward may choose the stock. The business has its own view. Interest on a bond must be paid on time, whatever the business earns, but a dividend can be reduced when profit falls. Preferred stock sits between the two: its dividend is fixed like interest, yet it is not a legal debt.

> Recap of the section comparing bonds and stock.

*Before moving on.* A bond holder lends and is paid first, in fixed amounts. A stockholder owns and is paid last, in amounts that can vary. Both are valued as the present value of the cash they bring.

* * *

## Worked Case: Valuing Three Stocks

> The case file records three valuations made on one date.

:case Case file, illustrative. Meghna and Sons Limited, 7 September 2025. Preferred stock paying a fixed Tk 8 a year, required return 10%: value Tk 80.00. Common stock with a level dividend of Tk 5 and required return 10%: value Tk 50.00. Common stock of a publishing business: last dividend Tk 4.00, growth 6% a year for ever, required return 12%: next dividend Tk 4.24; value 4.24 / (0.12 - 0.06) = Tk 70.67.

> The first two entries use the level formula; each step is shown.

We now check each entry, beginning with the two that use the level formula.
*Given.* For the preferred stock, D = Tk 8 and r = 10% = 0.10. For the common stock, D = Tk 5 and r = 0.10.
*Find.* The value of each.
*Formula.* P = D ÷ r.
*Steps.* Preferred: P = 8 ÷ 0.10 = Tk 80.00. Common: P = 5 ÷ 0.10 = Tk 50.00.
*Answer.* The preferred stock is worth Tk 80.00 and the common stock Tk 50.00.
*Check.* Tk 80.00 at 10% gives Tk 8.00 a year, and Tk 50.00 at 10% gives Tk 5.00 a year. Both match their dividends. The common result also answers the opening puzzle: a piece paying Tk 5 each year is worth Tk 50.00 to an investor who requires 10%, so Tk 80 was too much.

> Now the growing stock: data, formula, steps, answer and check.

*Given.* Last dividend D₀ = Tk 4.00; growth rate g = 6% = 0.06; required return r = 12% = 0.12.
*Find.* The value of one share today, P₀.
*Formula.* Value today equals the next dividend divided by the required return minus the growth rate, or P₀ = D₁ ÷ (r − g), with D₁ = D₀ × (1 + g).
*Steps.* First, D₁ = 4.00 × 1.06 = Tk 4.24. Second, r − g = 0.12 − 0.06 = 0.06. Third, P₀ = 4.24 ÷ 0.06 = Tk 70.67, rounded to two decimal places.
*Answer.* One share of this common stock is worth Tk 70.67.
*Check.* With no growth, the value would be 4.24 ÷ 0.12 = Tk 35.33, so a higher value for a growing dividend is sensible. A second check: the next dividend is 4.24 ÷ 70.67 = 0.06, which is 6% of the value, and the value itself grows 6% a year as a capital gain. Together they give 12%, equal to the required return.

> Four slips are common when using these formulas.

Many students make the same slips here, so check for them. First, writing the percentage as a whole number: 8 ÷ 10 gives 0.8, not 80.00, so convert 10% to 0.10 before dividing. Second, using the last dividend where the formula needs the next one: 4.00 ÷ 0.06 gives Tk 66.67, which is wrong because D₁ is Tk 4.24. Third, adding the growth rate to the required return instead of subtracting it. Fourth, using the formula when the growth rate is not below the required return. Always write the unit, Tk, with the answer.

* * *

## Summary

> The chapter's main ideas in a few lines.

Stock makes its holder a part-owner. Common stock carries a voting right and a residual claim, and its owner can also make a capital gain. Preferred stock pays a fixed dividend ahead of common stock. Stock is valued as the present value of its dividends: a level dividend gives P = D ÷ r, and a dividend growing at a steady rate g gives P₀ = D₁ ÷ (r − g), provided g is below r. A bond holder lends and a stockholder owns, so the stockholder carries more risk for a chance of greater reward.

## Think It Through

:q 14.t1 | A cautious investor with Tk 10,000 wants steady yearly income and fears losing money. She can buy a bond or common stock in a growing business. Which would you advise, and why? Give two reasons from this chapter.

## Where People Go Wrong

> Mistake: believing all stock pays a fixed amount.

Mistake: "All stock pays a fixed amount, as a bond does." Correction: only preferred stock has a fixed dividend. The directors decide each common dividend, and they may raise it, lower it or skip it.

> Mistake: treating the formula value as the price.

Mistake: "The formula value is the price I must pay." Correction: the formula gives intrinsic value, which rests on estimates of growth and required return. The price in the market may be higher or lower.

> Mistake: thinking the growth model ignores capital gain.

Mistake: "The model counts dividends only, so it ignores capital gain." Correction: the model values the whole stream of dividends, and a rising price follows from rising dividends. The check in the worked case found a 6% dividend part and a 6% capital gain part.

> Mistake: letting growth reach or pass the required return.

Mistake: "A fast-growing business can be given any growth rate." Correction: g must stay below r. When it does not, the formula breaks down or gives a negative value, and the assumption of such growth for ever must be rejected.

## In History

> In 1602 the Dutch East India Company's shares were traded in Amsterdam.

Amsterdam in 1602 was a busy trading city in the Dutch Republic. In that year the Vereenigde Oost-Indische Compagnie, known in English as the Dutch East India Company, was formed to carry on trade with Asia. A voyage to Asia took many months each way, and the cost of ships and cargo was high. The company therefore raised money by selling shares to the public.

> Shares that could be sold gave each investor a way out.

The new feature was that the shares could be transferred. An investor who did not want to wait for the voyages to finish could sell the shares to another person, and buyers began to trade them in Amsterdam within days of the launch (Petram, 2014). Every sale needed a price, and a price needs a way to value a part of a business that cannot be seen. Buyers asked the questions of this chapter: what will the share pay, and what return do I require? Many historians treat the company as the first widely traded joint-stock company, meaning a business whose capital is divided into shares held by many owners. The historian Fernand Braudel cautioned that Amsterdam was not strictly the first stock market, so the claim is best made with care.

## Sources

> Three works shaped how stock is valued.

John Burr Williams, in *The Theory of Investment Value* (1938), argued that a stock is worth the present value of the dividends it will pay. This is the idea of the whole chapter. Myron Gordon and Eli Shapiro (1956) set out the growth formula that is often called the Gordon model, and that this book calls the dividend growth model. William Sharpe (1964) built the capital asset pricing model, which supplies the required return used in section 14.3. Lodewijk Petram (2014) tells the history of trade in the Dutch East India Company's shares.

## Review Questions

:q 14.1 | Preferred stock pays Tk 9 a year for ever. The required return is 12%. What is the value of one share?
:q 14.2 | Common stock has a last dividend of Tk 3.50, a growth rate of 5% and a required return of 11%. Find its value today.
:q 14.3 | Explain why the growth rate must stay below the required return in the dividend growth model.
:q 14.4 | Give three differences between a bond and a stock.
:q 14.5 | A common stock pays a level dividend of Tk 6 for ever. The required return rises from 12% to 15%. Find the new value and the fall in value.
:q 14.6 | Two stocks each have a last dividend of Tk 4.00 and a required return of 12%. Stock A grows at 4% a year and stock B at 7%. Find the value of each and explain the gap.
:q 14.7 | An investor requires 10%. She is offered a bond paying Tk 80 a year for 3 years plus Tk 1,000 at the end of year 3, and a common stock with a last dividend of Tk 2.00 and growth of 5% a year. Value one bond and ten shares, and give the total.

:read John Burr Williams, The Theory of Investment Value, 1938
:read Lodewijk Petram, The World's First Stock Exchange, 2014
