:chapter XI | Operating Leverage and Break-even Analysis
:mood Why can a small rise in sales bring a large rise in profit?
:desc Some costs stay the same however much a business sells, and others grow with every unit. This chapter separates the two kinds, finds the sales volume at which a business neither gains nor loses, and measures how strongly a change in sales moves profit. It closes by linking these ideas to risk.
:plate ch11-plate.svg | A factory floor where belts drive a line of machines and a foreman checks his watch

> Sales rise by one eighth, yet profit rises by one half; the reason is the subject of this chapter.

Consider two numbers from the case file of the printing unit of Meghna and Sons, the family-run bookshop in Dhaka that appears throughout this book. In one scenario the unit sells 8,000 packs in a year and earns an EBIT of Tk 80,000. EBIT is the profit of a business before interest and tax are taken away.^1 In the next scenario the unit sells 9,000 packs. Sales have grown by one eighth, which is 12.5%. A reader might expect EBIT to grow by about the same share. It does not. EBIT rises from Tk 80,000 to Tk 120,000, a rise of 50%.

> A tea seller shows the same effect: once the rent is paid, each extra cup adds mostly profit.

Think of a tea seller who rents a stall. The rent is the same on a quiet day and on a busy day. The tea leaves and milk, however, are used up one cup at a time. On a quiet day the seller may barely cover the rent. On a busy day, once the rent is covered, almost every extra cup adds to the seller's profit. A rise in cups sold of one tenth can therefore raise profit by far more than one tenth. The printing unit behaves in the same way, and so does every business that has costs which do not move with sales.

> The chapter answers three questions: where the loss ends, how strongly profit responds to sales, and what this means for risk.

This chapter answers three questions. First, how many units must a business sell before it stops making a loss? Second, by what percentage does profit change when sales change by one percent? Third, why does the answer matter to anyone who owns, lends to or works for the business? We shall build each answer one idea at a time, starting with the way costs behave.

:box YOU WILL NEED
Chapter 9, 'Return and Risk', section 9.2 'What Risk Is': business risk. Chapter 7, 'Capital Budgeting: Decisions and Cash Flows', section 7.3 'Cash Flow from an Investment': EBIT.

^1: Recall: EBIT, Chapter 7, 'Capital Budgeting: Decisions and Cash Flows', section 7.3 'Cash Flow from an Investment'. From here on the book uses the short form EBIT.

* * *

## 11.1 Fixed and Variable Costs

> A business pays some costs whatever it sells and other costs only as it sells.

Start with a small business that you could run yourself. A seller rents a table in a market for Tk 8,000 a year and sells notebooks. Each notebook is bought from a wholesaler for Tk 12 and sold for Tk 20. The seller soon notices that two kinds of money leave the business. One kind is the same whether the table sells ten notebooks or a thousand. The other kind grows with every notebook sold. Businesses of every size, from this table to a large factory, contain both kinds, and separating them is the first step of this chapter.

@ Cost | Word in use. In daily life, the price you pay for something. In business, any money given up to run the business, such as rent, wages or materials.
@ Fixed | Word in use. In daily life, fastened in place or repaired. Here, describing a cost that does not change with the number of units sold.
@ Fixed operating cost | an operating cost that stays the same whatever the number of units sold
> The table rent is a fixed operating cost: it does not change with the notebooks sold.

An operating cost is money spent on the everyday work of the business, before any interest or tax is paid. A **fixed operating cost** means an operating cost that stays the same whatever the number of units sold. The market rent of Tk 8,000 a year is a fixed operating cost, because it is the same for ten notebooks or for a thousand. The depreciation of a machine and the salary of a shop manager are further examples.

@ Variable operating cost | an operating cost that rises and falls with the number of units sold
> The Tk 12 paid for each notebook is a variable operating cost, because it grows with each unit sold.

A **variable operating cost** means an operating cost that rises and falls with the number of units sold. The Tk 12 paid for each notebook is variable. If the seller sells 100 notebooks, this cost is Tk 1,200; if the seller sells 200, it is Tk 2,400. Each unit adds the same amount. Materials, packing and sales commission are other examples.

> Total operating cost equals the fixed cost plus the variable cost per unit multiplied by the units sold.

We can now write a rule for the whole bill. In words: total operating cost equals fixed operating cost plus variable operating cost per unit multiplied by units sold. In symbols, TC = F + v × Q. Here TC is total operating cost, F is fixed operating cost, v is variable operating cost per unit, and Q is the number of units sold. Suppose the seller sells 500 notebooks. Then TC = 8,000 + 12 × 500 = 8,000 + 6,000 = Tk 14,000. Sales revenue is 500 × 20 = Tk 10,000, so EBIT is 10,000 − 14,000, a loss of Tk 4,000.

@ Contribution margin | selling price per unit minus variable operating cost per unit
@ Margin | Word in use. In daily life, the empty edge of a page or a small safety gap. In business, a difference between a price and a cost, as here.
> Each unit sold contributes its price less its variable cost towards the fixed cost.

The **contribution margin** is the selling price per unit minus the variable operating cost per unit. Each notebook gives 20 − 12 = Tk 8. We call it a contribution because those Tk 8 go first towards the fixed cost and, once that is paid, towards profit.

> The printing unit's record of 6 April 2025 gives the price, costs and contribution margin used later.

:case Case file, illustrative. Meghna and Sons, 6 April 2025, printing unit. Selling price Tk 90 per pack. Variable operating cost Tk 50 per pack. Contribution margin Tk 40 per pack. Fixed operating cost Tk 240,000 a year.

> Real costs are only roughly fixed or variable, and a fixed cost holds only within a range of volume.

Real costs seldom divide so neatly. An electricity bill may have a standing charge, which is fixed, and a charge for each unit of power used, which is variable; such a cost is part fixed and part variable. A cost is also fixed only within a range of volume. If the seller doubles sales, one table may no longer suffice, and a second table brings a second rent. In this chapter we assume that the selling price, the variable cost per unit and the fixed cost stay the same across the volumes we study. The manager must judge whether this holds in practice, and the owner, who bears the fixed costs in a poor year, has most reason to ask.

> A fixed cost stays the same as units sold change, a variable cost grows with them, and the contribution margin links the two.

*Before moving on.* A fixed operating cost stays the same whatever the units sold, and a variable operating cost grows with each unit. The contribution margin is the price less the variable cost per unit, which for the printing unit is Tk 40.

* * *

## 11.2 The Operating Break-even Point

> The seller wants to know how many notebooks must be sold before the loss ends.

Return to the seller who lost Tk 4,000 on 500 notebooks. Each notebook gives Tk 8 of contribution, and the fixed cost of Tk 8,000 must be covered first. How many notebooks are needed? Each one pays Tk 8 towards Tk 8,000, so we need 8,000 ÷ 8 = 1,000 notebooks. At that volume the seller neither gains nor loses. Below it the seller has a loss, and above it a profit.

@ Operating break-even point | the sales volume at which EBIT is exactly zero
> The operating break-even point is the volume at which EBIT is exactly zero.

The **operating break-even point** means the sales volume at which EBIT is exactly zero. For the seller it is 1,000 notebooks. It is measured in units, such as notebooks or packs, and not in taka. The word *operating* reminds us that we look at EBIT, before interest and tax.

:box THE BREAK-EVEN RULE
EBIT equals contribution minus fixed cost. EBIT is zero when contribution equals fixed cost, so break-even volume equals fixed operating cost divided by contribution margin.

### Clean numbers first

> The first example uses small round numbers so that the method is the only new thing.

*Given.* Selling price Tk 20 per notebook, variable operating cost Tk 12 per notebook, fixed operating cost Tk 8,000 a year. *Find.* The operating break-even point.

> The formula divides the fixed cost by the contribution margin, in words and in symbols.

*Formula.* In words: break-even volume equals fixed operating cost divided by contribution margin. In symbols, Q = F ÷ CM. Here Q is the number of units at break-even, F is the fixed operating cost, and CM is the contribution margin per unit, which is the price minus the variable cost per unit.

> The steps find the contribution margin first and then divide the fixed cost by it.

*Steps.* First, CM = 20 − 12 = Tk 8 per notebook. Second, Q = 8,000 ÷ 8 = 1,000 notebooks. *Answer.* The seller reaches break-even at 1,000 notebooks a year. *Check.* At 1,000 notebooks, revenue is 20 × 1,000 = Tk 20,000. Total operating cost is 8,000 + 12 × 1,000 = Tk 20,000. EBIT is 20,000 − 20,000 = 0, as it should be.

:pause 11.p1 | A stall has a contribution margin of Tk 25 per unit and a fixed operating cost of Tk 5,000 a year. How many units must it sell to reach the operating break-even point?

### EBIT at different volumes

> A table of three volumes shows loss below break-even, zero at break-even and profit above it.

The break-even point is one volume out of many, so it helps to see EBIT on both sides of it. The table below uses the notebook seller. Each row multiplies the units sold by the contribution margin of Tk 8, then subtracts the fixed cost of Tk 8,000. Read across a row to follow that calculation.

:table EBIT of the notebook seller at three volumes
| Notebooks sold | Contribution (Tk) | Fixed cost (Tk) | EBIT (Tk) |
| 800 | 6,400 | 8,000 | −1,600 |
| 1,000 | 8,000 | 8,000 | 0 |
| 1,200 | 9,600 | 8,000 | 1,600 |

> Each extra 200 notebooks adds the same Tk 1,600 to EBIT, because the fixed cost does not grow.

Notice the pattern. Moving from 800 to 1,000 notebooks adds Tk 1,600 to EBIT, and so does moving from 1,000 to 1,200. Each step of 200 notebooks adds 200 × 8 = Tk 1,600, because the fixed cost does not grow. Below 1,000 notebooks the EBIT is negative, which means a loss.

### Realistic numbers

> The printing unit applies the same method to larger, realistic figures.

:case Case file, illustrative. Meghna and Sons, 6 April 2025, printing unit. Break-even: 240,000 ÷ 40 = 6,000 packs. EBIT at 7,000 packs: Tk 40,000. EBIT at 8,000 packs: Tk 80,000. EBIT at 9,000 packs: Tk 120,000.

> The steps behind the case file repeat the method: contribution first, then subtract the fixed cost.

We now follow the arithmetic behind these lines. *Given.* Price Tk 90, variable cost Tk 50, fixed cost Tk 240,000 a year. *Find.* The break-even point, and EBIT at 7,000, 8,000 and 9,000 packs. *Formula.* The same two rules as before: Q = F ÷ CM, and EBIT = Q × CM − F. *Steps.* CM = 90 − 50 = Tk 40. Break-even Q = 240,000 ÷ 40 = 6,000 packs. At 7,000 packs, EBIT = 7,000 × 40 − 240,000 = 280,000 − 240,000 = Tk 40,000. At 8,000 packs, EBIT = 320,000 − 240,000 = Tk 80,000. At 9,000 packs, EBIT = 360,000 − 240,000 = Tk 120,000. *Answer.* The unit breaks even at 6,000 packs, and each extra 1,000 packs adds Tk 40,000 to EBIT. *Check.* 1,000 packs × Tk 40 = Tk 40,000, which matches each step in the list.

> The chart shows revenue and total cost as two lines, with loss and profit as the gaps between them.

Figure 11.1 shows the same unit as a chart. The horizontal axis shows packs sold in a year, and the vertical axis shows taka a year. Each point on a line shows the money at that volume. The revenue line starts at zero and rises by Tk 90 per pack. The total cost line starts at the fixed cost of Tk 240,000 and rises by Tk 50 per pack. The lines cross at 6,000 packs, which is revenue of 6,000 × 90 = Tk 540,000. To the left of the crossing the cost line lies above revenue, and the gap is the loss. To the right, revenue lies above cost, and the gap is profit.

:fig Revenue and total cost of the printing unit, crossing at the break-even point | ch11-fig01.svg

> Common slips are dividing by the price, mixing the periods, and forgetting that break-even is a number of units.

Three slips are common. The first is dividing the fixed cost by the price instead of the contribution margin; 240,000 ÷ 90 gives about 2,667 packs, far too low, because it ignores the variable cost. The second is mixing periods, such as a fixed cost for a year with a volume for a month. The third is giving the answer in taka. If the division leaves a fraction, such as 2,666.7, round up to the next whole unit, because part of a unit cannot be sold.

> Break-even analysis assumes that price, variable cost and fixed cost stay the same across the volumes studied.

The break-even rule has limits. It assumes that price and variable cost per unit do not change as volume grows, and that the fixed cost stays the same across the range studied. A manager who plans to sell far more than today may meet a new fixed cost, such as a second machine, and then the rule must be applied again with the new figures.

> The break-even point is found by dividing the fixed cost by the contribution margin, and EBIT rises with every unit above it.

*Before moving on.* The operating break-even point equals the fixed operating cost divided by the contribution margin. For the printing unit it is 6,000 packs. Below it EBIT is negative, and above it EBIT rises by the contribution margin with each extra pack.

* * *

## 11.3 Degree of Operating Leverage

> At the printing unit, a rise in sales of one eighth lifts EBIT by one half; we can now explain why.

Return to the puzzle that opened the chapter. At 8,000 packs EBIT is Tk 80,000, and at 9,000 packs it is Tk 120,000. Why does a rise of 12.5% in sales give a rise of 50% in EBIT? Each extra pack adds Tk 40 of contribution, and no extra fixed cost. The extra 1,000 packs therefore add Tk 40,000, and all of it reaches EBIT. Measured against a base EBIT of only Tk 80,000, that is a rise of 50%.

@ Operating leverage | the effect of fixed operating costs in making EBIT change by more than sales change
> Operating leverage means fixed costs make EBIT move by a larger percentage than sales.

The word comes from the lever, where a small push at one end moves a heavy load at the other. **Operating leverage** is the effect of fixed operating costs in making EBIT change by more than sales change. A business with no fixed operating cost has none, because its EBIT would change by the same percentage as its sales. The larger the fixed cost, the stronger the effect.

@ Degree of operating leverage | the percentage change in EBIT caused by a one percent change in sales
> The degree of operating leverage puts a number on the effect: the percentage change in EBIT per one percent change in sales.

We want one number that measures the strength of this effect. The **degree of operating leverage** is the percentage change in EBIT caused by a one percent change in sales. A value of 4.00 means that each 1% change in sales changes EBIT by 4%. It is found from contribution and EBIT at one starting volume. In words: degree of operating leverage equals contribution divided by EBIT. In symbols, DOL = (Q × CM) ÷ EBIT. The formula arises because a 1% change in sales changes contribution by 1% of Q × CM, all of which reaches EBIT, and dividing by EBIT states that change as a percentage of EBIT.

### The printing unit at two volumes

> The worked steps find the degree of operating leverage at 8,000 packs and at 9,000 packs.

*Given.* Price Tk 90, variable cost Tk 50, contribution margin Tk 40, fixed cost Tk 240,000. *Find.* The degree of operating leverage at 8,000 packs and at 9,000 packs. *Formula.* DOL = (Q × CM) ÷ EBIT, where Q is the starting volume. *Steps.* At 8,000 packs, contribution = 8,000 × 40 = Tk 320,000, EBIT = 320,000 − 240,000 = Tk 80,000, and DOL = 320,000 ÷ 80,000 = 4.00. At 9,000 packs, contribution = 9,000 × 40 = Tk 360,000, EBIT = 360,000 − 240,000 = Tk 120,000, and DOL = 360,000 ÷ 120,000 = 3.00.

> The case file records both values, and the check agrees with the percentages in the puzzle.

:case Case file, illustrative. Meghna and Sons, 6 April 2025, printing unit. Degree of operating leverage at 8,000 packs = 320,000 / 80,000 = 4.00. At 9,000 packs = 360,000 / 120,000 = 3.00. A 12.5% rise in sales from 8,000 to 9,000 packs lifts EBIT by 50%.

> The check multiplies the sales change by the degree of operating leverage and compares it with the direct change.

*Answer.* The degree of operating leverage is 4.00 at 8,000 packs and 3.00 at 9,000 packs. *Check.* The rise in sales is 1,000 ÷ 8,000 = 12.5%. Multiplying, 12.5% × 4.00 = 50%. Directly, (120,000 − 80,000) ÷ 80,000 = 50%. The two results agree. The value must be taken at the starting volume, which is 8,000 packs for this rise.

> Figure 11.2 shows the two changes side by side, scaled so that each starting value equals 100.

Figure 11.2 shows the result in pictures. Each pair of bars compares a value before and after the rise in sales. Both starting values are scaled to 100, so the height of the second bar shows the new value as a share of the first. The sales pair rises from 100 to 112.5, and the EBIT pair rises from 100 to 150. The second pair climbs four times as far as the first.

:fig Sales rise by 12.5% while EBIT rises by 50%, with each starting value set to 100 | ch11-fig02.svg

:pause 11.p2 | A business has a contribution of Tk 60,000 and an EBIT of Tk 20,000. What is its degree of operating leverage, and by what percentage would EBIT change if sales fell by 10%?

> The lever works in both directions, so a fall in sales cuts EBIT by the same multiple.

The lever works downward as well. If sales fall from 8,000 to 7,000 packs, a fall of 12.5%, EBIT falls from Tk 80,000 to Tk 40,000. That is a fall of 50%, which is 12.5% × 4.00. The case file lists this EBIT of Tk 40,000 for 7,000 packs. The same fixed cost that magnified the gain now magnifies the loss.

> The degree of operating leverage is highest near break-even, falls as volume grows, and cannot be used at break-even.

Four points limit the use of the number. First, it changes with volume: it falls from 4.00 to 3.00 as the unit moves from 8,000 to 9,000 packs. Second, it is highest close to break-even, where EBIT is small. Third, at break-even EBIT is zero, so the division cannot be performed and the value is undefined. Fourth, below break-even EBIT is negative and the value has no useful meaning. Common slips include dividing EBIT by contribution, which turns the answer upside down, and using the starting volume of a different rise.

> The degree of operating leverage is contribution divided by EBIT, and it is large when EBIT is small relative to contribution.

*Before moving on.* Operating leverage is the effect of fixed cost in making EBIT move more than sales. The degree of operating leverage equals contribution divided by EBIT at the starting volume, which is 4.00 at 8,000 packs for the printing unit.

* * *

## 11.4 Operating Leverage and Business Risk

> Leverage that magnifies gains also magnifies losses, which raises business risk.

Is high operating leverage good? If sales were certain to rise, the answer would be yes, because EBIT would rise faster. Sales are not certain. Business risk is the uncertainty about a business's EBIT.^2 The printing unit shows both sides: a rise of 12.5% in sales at 8,000 packs lifts EBIT by 50%, and a fall of the same size cuts it by 50%. The fixed cost of Tk 240,000 must be paid in a poor year and in a good one alike.

^2: Recall: business risk, Chapter 9, 'Return and Risk', section 9.2 'What Risk Is'.

> The more of a business's costs are fixed, the higher its leverage, the larger its swings in EBIT, and the higher its business risk.

The rule follows. The larger the share of fixed cost in total cost, the higher the degree of operating leverage, the larger the swings in EBIT, and the higher the business risk. Owners may accept this in return for larger gains in good years. Lenders worry that EBIT may fall too low to pay what is owed. Employees may fear lost jobs when sales fall. Operating leverage is only one source of business risk, because demand and input prices also change.

> Fixed costs raise risk because they cannot be reduced when sales fall.

*Before moving on.* Higher fixed cost means higher leverage and a larger swing in EBIT in both directions. That swing is why operating leverage raises business risk.

* * *

## Worked Example: Break-even and Leverage Together

> The notebook seller's numbers are used to find break-even and leverage at two volumes in one problem.

*Given.* Selling price Tk 20, variable cost Tk 12, fixed cost Tk 8,000 a year. *Find.* The break-even point, and the EBIT and degree of operating leverage at 1,200 and at 2,000 notebooks, then test the result with a rise of 10% in sales from 2,000. *Formula.* Q = F ÷ CM, EBIT = Q × CM − F, and DOL = (Q × CM) ÷ EBIT.

> The steps compute the contribution margin, then the break-even point, then EBIT and leverage at each volume.

*Steps.* CM = 20 − 12 = Tk 8. Break-even Q = 8,000 ÷ 8 = 1,000 notebooks. At 1,200 notebooks, contribution = 1,200 × 8 = Tk 9,600, EBIT = 9,600 − 8,000 = Tk 1,600, and DOL = 9,600 ÷ 1,600 = 6.00. At 2,000 notebooks, contribution = 2,000 × 8 = Tk 16,000, EBIT = 16,000 − 8,000 = Tk 8,000, and DOL = 16,000 ÷ 8,000 = 2.00.

> The answer and check show leverage is higher close to break-even and agree with a direct calculation.

*Answer.* Break-even is 1,000 notebooks. The degree of operating leverage is 6.00 at 1,200 notebooks and 2.00 at 2,000 notebooks. *Check.* A rise of 10% in sales from 2,000 gives 2,200 notebooks. EBIT is then 2,200 × 8 − 8,000 = 17,600 − 8,000 = Tk 9,600. The rise is 1,600 on 8,000, which is 20%, and 10% × 2.00 = 20%. The volume closer to break-even has the higher leverage.

* * *

## Summary

> Fixed and variable costs lead to a break-even point and a degree of operating leverage, which together describe business risk.

A fixed operating cost does not change with units sold, and a variable operating cost does. The contribution margin is price minus variable cost per unit. The operating break-even point equals fixed cost divided by contribution margin. EBIT equals units sold times contribution margin, minus fixed cost. The degree of operating leverage equals contribution divided by EBIT; it is highest near break-even and shows how strongly EBIT responds to sales. Greater leverage raises business risk.

## Think It Through

> A printer, separate from Meghna and Sons, is deciding between two cost structures for the same price.

A printer sells at Tk 90 per pack. Today the variable operating cost is Tk 50 per pack and the fixed operating cost is Tk 240,000 a year. A new machine would cut the variable cost to Tk 30 per pack and raise the fixed cost to Tk 480,000 a year.

:q 11.t1 | Find the operating break-even point before and after the new machine.
:q 11.t2 | At 9,000 packs, find the EBIT and the degree of operating leverage before and after the new machine. Which cost structure carries more business risk?

## Where People Go Wrong

> Fixed cost per unit is not fixed: only the total fixed cost stays the same.

Some students say that a fixed cost is the same for every unit. This is wrong. The total fixed cost stays the same, so the fixed cost per unit falls as more units are sold. The printing unit spreads Tk 240,000 over 6,000 packs at Tk 40 each, but over 8,000 packs at Tk 30 each.

> The break-even point divides by the contribution margin, not by the price.

Some students divide the fixed cost by the selling price. The price includes the variable cost, which must be paid for each unit. Only the contribution margin is left to cover the fixed cost, so it is the divisor.

> High leverage is not always good, because it magnifies losses as well as gains.

Some students think a high degree of operating leverage is always an advantage. It multiplies gains when sales rise and multiplies losses when sales fall. Whether it helps depends on the likely path of sales.

> The degree of operating leverage is not one fixed number for a business: it changes with the volume.

Some students quote one degree of operating leverage for a whole business. It depends on the starting volume. The printing unit has 4.00 at 8,000 packs and 3.00 at 9,000 packs, and no value at break-even.

## In History

> Henry Ford's moving assembly line raised fixed cost, lowered variable cost per car, and led to a fall in the Model T's price.

Henry Ford (1863–1947) was an American car maker who founded the Ford Motor Company in 1903 in Detroit, Michigan. The Model T went on sale in 1908. From 1913, at the Highland Park plant, on the edge of Detroit, Ford's factory used a moving assembly line, in which the car moved past the workers instead of the workers moving to the car. The line needed heavy spending on plant and machinery, which is fixed cost, and it cut the labour needed per car, which is variable cost.

> The price of the Model T fell from about 850 dollars to 260 dollars, as high volume spread the fixed cost.

The price of a Model T was about 850 dollars at its launch in 1908 and had fallen to 260 dollars for the Runabout model by 1925. Ford sold the car in far greater numbers than any maker before him. Large fixed costs are carried well only at high volume, which is the lesson of this chapter. A business that raises its fixed costs must be sure its sales will stay above its break-even point.

## Review Questions

:q 11.1 | Explain the difference between a fixed operating cost and a variable operating cost, and give one example of each from a bookshop.
:q 11.2 | A business sells at Tk 150 per unit, with a variable operating cost of Tk 95 per unit and a fixed operating cost of Tk 330,000 a year. Find the contribution margin and the operating break-even point.
:q 11.3 | For the business in Question 11.2, find EBIT at 5,000, 6,000 and 7,000 units.
:q 11.4 | For the same business, find the degree of operating leverage at 8,000 units.
:q 11.5 | Explain why the degree of operating leverage is higher near the break-even point than far above it. Use the printing unit's figures.
