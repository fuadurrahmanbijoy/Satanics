:glossary 01
Finance | The work of finding money and deciding how to use it, so that a business or a person can reach chosen aims. It has two halves: finding money, and choosing its use. A stall owner who borrows Tk 800 and spends it on onions to sell is doing finance.
Funds | Money that a business has available to spend, save or invest at one moment. Funds may be notes in a purse or a balance held at a bank. Goods waiting to be sold are not funds until they are sold and paid for.
Cash flow | Money moving into or out of a business during a period such as a day, a month or a year. A customer paying Tk 3,000 on Monday is a cash flow in; paying a supplier Tk 2,000 is a cash flow out.
Wealth | The total value of what a person or business owns, after taking away what is owed. Owning goods and cash worth Tk 4,000 and owing Tk 800 gives wealth of Tk 3,200. Wealth can be large while funds are small.
Business function | One main kind of work in a business, such as selling, buying or making, managing people, and managing money. Finance is one business function. A small business may give several functions to one person; a larger one gives each its own team.
Source of funds | A place a business gets money from, such as its owners or a lender. Meghna and Sons has two: the family and a bank. Each source supplies part of the total money that the business has obtained.
Use of funds | A purpose a business spends money on, such as stock or equipment. Keeping money at the bank for later is also a use. Each use of funds usually gives the business an asset.
Asset | Something of value that a business owns and uses to earn money, such as books for sale, shelves or a bank balance. Each asset is the result of a use of funds, so on any one date the assets equal the sources.
Equity | Money put in by the owners, who share the business profit or loss. Owners are not promised a fixed payment. At Meghna and Sons, the family's Tk 1,800,000 is equity. Money from owners is often called capital.
Debt | Money borrowed that must be repaid, with an extra charge for using it. The lender is promised repayment on agreed dates. The bank loan of Tk 600,000 at 10% a year is debt.
Liability | An amount a business owes to someone else. Debt is one kind of liability; an unpaid bill to a supplier is another. Assets less liabilities gives the owners' wealth in the business.
Financial market | A place or network where buyers and sellers trade money, loans and ownership parts of businesses. A bank where one borrower meets one lender is a very small example; large markets let a business find many sources at once.

:glossary 02
Financial manager | The person who plans, raises and controls the money of a business, whatever the job title. In a small shop one brother may hold the duty; in a large business a team may. The manager answers to owners, lenders and employees.
Financial planning | Deciding in advance how much money a business will need and when. A tailor who knows she must pay Tk 38,000 for cloth and rent in the first week of March can arrange the money before the day arrives.
Financial control | Checking that money is spent and recorded as planned, and acting when it is not. If cloth planned at Tk 30,000 costs Tk 36,000, control finds the Tk 6,000 difference, asks why, and changes something.
Investment decision | Choosing which long-lasting assets or projects a business should buy. It asks what to buy, and it commits money for a long time. A bakery choosing between a new oven and a delivery van makes one.
Financing decision | Choosing how to raise the money for purchases, from owners or lenders. It asks how to pay, not what to buy. An oven may be paid for from owners' funds, a bank loan, or both.
Dividend decision | Choosing how much profit to pay out to owners and how much to keep in the business. A payout rewards owners now; keeping profit leaves more to fund growth later without asking a lender.
Dividend | A share of profit paid out to the owners of a business. If a shop earns Tk 90,000 and pays Tk 30,000 to its owners, the dividend is Tk 30,000. A family may call its payout a withdrawal.
Retained earnings | Profit kept in the business instead of being paid out to owners. If the shop earns Tk 90,000 and pays out Tk 30,000, retained earnings are Tk 60,000. They belong to the owners and may already be spent on assets.
Operating efficiency | How little money and effort a business uses to produce each unit of sales. A tailor who spends Tk 70 for every Tk 100 of sales is more efficient than one who spends Tk 80 for the same Tk 100.
Liquidity | How easily a business can pay its bills on time from cash it has or can quickly raise. Books on shelves are not liquid until sold, while a bank balance is. Weak liquidity can delay wages and stop deliveries.
Profitability | How much profit a business earns compared with the money invested or the sales made. A profit of Tk 20,000 on Tk 200,000 invested is 10% of the money invested; compare ratios, not amounts.

:glossary 03
Profit maximisation | The aim of earning the largest profit possible in a period, usually one year. A shop that always picks the plan with the largest profit for the year follows this aim, even if the plan harms later years.
Market value | The price at which something could be sold today in a market. A used bicycle that a buyer would pay Tk 6,000 for today has a market value of Tk 6,000.
Wealth maximisation | The aim of making the market value of the owners' stake as large as possible over time. It takes account of when profits arrive and how certain they are, because buyers pay for both.
Stakeholder | Any person or group affected by a business, such as workers, customers, lenders and owners. A bookshop's stakeholders include its staff, the schools that buy from it and the bank that lent it money.
Principal | A person who hires another person to act for them. The owners of a bookshop are principals when they hire someone to run a branch for them.
Agent | A person who acts for a principal and takes decisions in the principal's name. A hired branch manager is an agent of the owners.
Agency conflict | A clash between what a principal wants and what an agent chooses to do. A manager paid on sales may choose discounts that raise sales, while the owners want profit.
Agency cost | The loss in value, plus the cost of prevention, that comes from an agency conflict. If a bad choice costs the owners Tk 105,000 and checking the records costs more, both amounts count.

:glossary 04
Time value of money | The idea that money received sooner is worth more than the same amount received later, because money in hand can be put to work. Tk 100,000 today is worth more than Tk 100,000 in a year.
Interest | The price paid for using money for a period, received by the lender. If a bank pays Tk 8,000 for the use of Tk 100,000 for a year, the Tk 8,000 is interest.
Interest rate | The interest for one period, shown as a percentage of the amount lent or borrowed. Tk 8,000 earned on Tk 100,000 in a year is an interest rate of 8% a year.
Opportunity cost | The value of the best choice given up when you pick another. Cash kept idle in a drawer has an opportunity cost equal to the interest a bank would have paid on it.
Simple interest | Interest worked out on the original amount only, so the same amount is added each period. Tk 10,000 at 10% earns Tk 1,000 every year.
Compound interest | Interest worked out on the original amount plus interest already earned, so interest earns interest. Tk 10,000 at 10% earns Tk 1,000 in year 1 and Tk 1,100 in year 2.
Single sum | One payment or receipt made at one point in time. A deposit of Tk 10,000 made today is a single sum, unlike payments that repeat each year.
Future value | What an amount today will grow to after a stated time at a stated rate, found by FV = S × (1 + i) to the power of n. Tk 10,000 at 10% for two years has a future value of Tk 12,100.
Present value | What an amount to be received later is worth today at a stated rate. At 10%, Tk 12,100 due in two years has a present value of Tk 10,000.
Discounting | Finding a present value by working backwards from a future amount at a rate, dividing by (1 + i) once for each year. Tk 12,100 becomes Tk 11,000 and then Tk 10,000.
Discount rate | The rate used to turn a future amount into a present value. It is the same number as the interest rate when the money could earn that rate, used for working backwards.
Compounding period | The time between one addition of interest and the next. A bank that adds interest every six months has a compounding period of six months.
Effective annual rate | The single yearly rate that gives the same growth as compounding within the year. A rate of 12% compounded half-yearly has an effective annual rate of 12.36%.

:glossary 05
Annuity | A series of equal payments made at equal time intervals for a set number of periods. Three deposits of Tk 1,000, one at the end of each of three years, form an annuity, as do monthly loan instalments over two years.
Ordinary annuity | An annuity whose payments fall at the end of each period. Loan instalments and bank interest are usually of this kind. When no kind is stated, an annuity is taken to be ordinary.
Annuity due | An annuity whose payments fall at the start of each period. Rent paid in advance is an example. Each payment comes one period earlier, so the annuity due is worth 1 + i times an ordinary annuity.
Perpetuity | An annuity that never ends, such as a fund paying a scholarship of Tk 50,000 every year for ever. Its present value is the payment divided by the interest rate.
Factor table | A printed table of ready-made multipliers for given rates and numbers of periods. A reader finds the row for the number of periods, reads the column needed, and multiplies the factor by the payment.
Sinking fund | Money put aside in equal deposits to reach a target sum by a set date. The deposit equals the target divided by the future value factor. A business may use one to replace a vehicle.
Amortisation | Repaying a loan by equal payments that cover the interest and part of the amount borrowed. The instalment equals the loan divided by the present value factor, and the loan falls to zero at the last payment.

:glossary 06
Mixed stream | A series of payments or receipts that differ in size from one period to the next. Receipts of Tk 1,000, Tk 2,000 and Tk 3,000 at the ends of three years form a mixed stream. An annuity is the special case in which all sizes are equal.
Discounted cash flow | A way of valuing a series of future cash flows by turning each one into a present value and adding the results. For example, Tk 1,000 in year 1 and Tk 2,000 in year 2 at 10% are valued as Tk 909.09 plus Tk 1,652.89.

:glossary 07
Capital budgeting | The process of planning, evaluating and choosing long-term investments, such as a machine that will work for five years. It covers finding proposals, estimating their cash flows, choosing among them and later reviewing the results.
Capital expenditure | Spending on assets that will serve the business for many years. A machine, a delivery van and a new shop floor are examples; a month of electricity is not, because it is used up at once.
Independent projects | Projects where accepting one has no effect on whether another is accepted. A print-on-demand machine and a new set of shelves are independent: a business may accept both, either or neither.
Mutually exclusive projects | Projects where accepting one means rejecting the others. A machine and a branch fit-out that cannot be run together are an example, as are two scanners when only one will be bought.
Relevant cash flow | Cash flow that changes only because a project is accepted. It must be cash, lie in the future and differ with the decision. A sunk cost, such as a survey already paid, is not relevant.
Initial investment | Cash spent at the start to get a project going. It includes the price of the asset, delivery, installation and any working capital needed. It is paid at time zero, before year one begins.
Depreciation | The part of an asset cost charged as an expense in each year of its use. With the straight-line method, the yearly charge is cost less resale value, divided by years. No cash leaves in those years.
EBIT | Earnings before interest and tax: the profit from operations before paying lenders or the tax office. It equals revenue less cash costs less depreciation. The book uses EBIT in place of the term operating profit.
Operating cash flow | Cash a project produces each year from running it, after tax. It equals EBIT, less tax on EBIT, plus depreciation, since depreciation reduced EBIT but no cash was paid.
Terminal cash flow | Cash received at the end of a project life, such as the resale value of equipment. It also includes working capital that returns, and is reduced by tax on any gain from the sale.

:glossary 08
Payback period | The time a project takes to recover its initial investment from its cash flows. With equal inflows it is the initial investment divided by the yearly inflow; otherwise add the inflows into a running total. Tk 10,000 repaid by Tk 5,000 a year takes 2 years.
Net present value | The present value of a project's cash inflows minus its initial investment. It shows, in taka today, how much worth the project adds. Accept a project when the value is zero or positive; among exclusive projects, choose the highest.
Required return | The lowest return a project must earn to be worth accepting. Also called the required rate of return or hurdle rate. It is used as the discount rate, and it reflects the risk of the project and the cost of the funds. Meghna and Sons uses 12%.
Internal rate of return | The discount rate at which a project's net present value is exactly zero. It is the yearly return the project itself earns. Find it by trial between two rates and interpolation; accept when it is at least the required return.
Profitability index | The present value of a project's inflows divided by its initial investment. A value above 1 means each taka invested returns more than a taka in present value. For Press, 1,097,055 ÷ 900,000 gives 1.22.

:glossary 09
Return | The total gain or loss from an investment over a period, found by adding the income received to any change in value. A bond bought for Tk 100,000 that pays Tk 6,000 and later sells for Tk 104,000 gives a return of Tk 10,000.
Rate of return | The return shown as a percentage of the amount first invested, found by dividing the return by that amount and multiplying by 100. It lets investments of different size be compared. A return of Tk 10,000 on Tk 100,000 is 10%.
Risk | The chance that actual results differ from those expected, especially for the worse. The wider the range of possible results, the greater the risk. A certain loss carries no risk, because nothing is uncertain. A fixed-payment savings bond has little risk.
Business risk | The risk that operating profit varies because of sales, costs and trade conditions. It belongs to the trade, whatever the way the business is funded. A bookshop whose sales fall in the school holidays meets business risk.
Financial risk | The extra risk to owners that comes from funding part of a business by borrowing. Interest must be paid in poor years as well as good ones, so what is left for owners varies more. A bookshop with a loan of Tk 600,000 at 10% a year faces it.
Probability | A number from 0 to 1 showing how likely an outcome is. Zero means the outcome cannot happen and one means it is certain. A fair coin landing heads has a probability of 0.5. Heavy traffic on 25 days in 100 has a probability of 0.25.
Probability distribution | A list of possible outcomes with the probability of each, adding up to one. Exactly one outcome must happen, so the probabilities total one. Route times of 10, 25 and 40 minutes with probabilities of 0.25, 0.50 and 0.25 form a probability distribution.
Expected value | The average outcome, found by multiplying each outcome by its probability and adding the products. It is a long-run average and not a forecast for one trial. Outcomes of 9%, 12% and 15% with probabilities 0.25, 0.50 and 0.25 give an expected value of 12%.
Standard deviation | A measure of how widely outcomes spread around the expected value. Find each deviation from the expected value, square it, weight it by its probability, add the results and take the square root. A small figure means outcomes lie close to the expected value.
Coefficient of variation | The standard deviation divided by the expected value, showing risk for each unit of return. It allows choices with different expected values to be compared. A standard deviation of 8.49% on an expected value of 14% gives a coefficient of 0.61.

:glossary 10
Risk-free rate | The return on an investment with no chance of loss, such as a short government bill. It pays for waiting alone. No investment is perfectly free of risk, but a short loan to a stable government comes close. The case file assumes 8%.
Risk premium | The extra return investors demand for taking on risk above the risk-free rate. It equals the required return less the risk-free rate. If the risk-free rate is 8% and a lender demands 12%, the risk premium is 4 percentage points.
Portfolio | A collection of investments held together by one investor. What matters is the combined result of the whole collection. A trader with an umbrella stall and a sunshade stall holds a portfolio of two stalls.
Diversification | Spreading money across different investments so that one loss hurts less. The investments must differ in what affects them. Ten umbrella stalls do not diversify the trader's risk from wet weather, but one umbrella stall and one sunshade stall do.
Firm-specific risk | Risk that affects one business only and can be reduced by diversifying. A fire at one factory or a failed new product are examples. An investor who holds many businesses feels such a loss as a small part of the whole portfolio.
Market risk | Risk that affects all investments in a market and cannot be removed by diversifying. A fall in demand across a whole country is an example. Because it cannot be removed, it is the only risk that earns a premium in the pricing model.
Beta | A number showing how strongly an investment moves with the whole market. The whole market has a beta of 1. An investment with a beta of 1.5 tends to rise or fall about 15% when the market return changes by 10%.
Capital asset pricing model | A formula setting required return as risk-free rate plus beta times the market risk premium. With a risk-free rate of 8%, a market return of 14% and a beta of 0.6, the required return is 8% + 0.6 × 6% = 11.6%.
Security market line | The straight line that shows required return rising with beta. It starts at the risk-free rate when beta is 0 and passes through the market return when beta is 1. An investment above the line promises more than its required return.
Efficient market | A market in which prices already reflect the information available. New information moves prices, and since it cannot be predicted, price changes look random. Efficient does not mean that prices are always right or that investors never lose.
Weak-form efficiency | The condition in which prices already reflect all past price information. If it holds, studying old price charts cannot show which investment will rise next, because any pattern in past prices is already in the current price.
Semi-strong-form efficiency | The condition in which prices reflect all public information, not only past prices. If it holds, reading a published annual report or news item after it appears brings no gain, because the price has already moved.
Strong-form efficiency | The condition in which prices reflect all information, public and private. If it holds, even secret knowledge held by managers is already in the price. Few people believe it holds, and trading on secret information is a crime in many countries.

:glossary 11
Fixed operating cost | An operating cost that stays the same whatever the number of units sold. Shop rent of Tk 8,000 a year is the same for ten notebooks or a thousand, so it is a fixed operating cost.
Variable operating cost | An operating cost that rises and falls with the number of units sold. If each notebook costs Tk 12 to buy, then 100 notebooks cost Tk 1,200 and 200 notebooks cost Tk 2,400.
Contribution margin | The selling price per unit minus the variable operating cost per unit. It is the amount each unit sold contributes towards the fixed operating cost and then towards profit. A pack sold at Tk 90 with a variable cost of Tk 50 has a contribution margin of Tk 40.
Operating break-even point | The sales volume at which EBIT is exactly zero. It equals the fixed operating cost divided by the contribution margin, and is stated in units. With fixed cost Tk 240,000 and contribution margin Tk 40, it is 6,000 packs.
Operating leverage | The effect of fixed operating costs in making EBIT change by more than sales change. The larger the fixed cost compared with the contribution, the stronger the effect. A business with no fixed operating cost has none.
Degree of operating leverage | The percentage change in EBIT caused by a one percent change in sales. It equals contribution divided by EBIT at the starting volume. A value of 4.00 means a 1% change in sales changes EBIT by 4%.

:glossary 12
Fixed financing charge | Interest or preferred dividend that must be paid whatever the level of EBIT. It is owed to those who supplied funds, not to those who supply the trade. Interest of Tk 20,000 a year on a bank loan is a fixed financing charge.
Common stock | Ownership shares that receive what remains after all other claims, with no fixed dividend. Owners of common stock take the most risk and keep any gain. Some countries call these ordinary shares or equity shares. If Tk 33,000 remains, it belongs to them.
Preferred stock | Ownership shares with a fixed dividend that is paid before any dividend on common stock. The holder cannot claim more than the fixed amount. Tk 100,000 of preferred stock at 12% promises Tk 12,000 a year ahead of common stock owners.
Financial leverage | The effect of fixed financing charges in making earnings per share change by more than EBIT. With no fixed charges the two change by the same percentage. With interest of Tk 2,000, a 20% change in EBIT of Tk 10,000 moves the profit for each share by 25%.
Earnings per share | The profit left for common stock owners divided by the number of common shares. It is found by taking interest, tax and preferred dividend from EBIT in turn. Tk 33,000 left for 5,000 shares gives earnings per share of Tk 6.60.
Degree of financial leverage | The percentage change in earnings per share caused by a one percent change in EBIT. It equals EBIT divided by EBIT less interest less preferred dividend divided by one minus the tax rate. For the printing unit, 80,000 ÷ 44,000 = 1.82.
Degree of total leverage | The percentage change in earnings per share caused by a one percent change in sales. It equals the degree of operating leverage times the degree of financial leverage. For the printing unit, 4.00 × 1.8182 = 7.27.

:glossary 13
Bond | A loan sold to investors, repaid at a set date with fixed interest along the way. The business that borrows is the issuer. For example, a business may divide a loan of Tk 5,000,000 into 5,000 bonds of Tk 1,000 each.
Par value | The amount printed on a bond that is repaid at maturity. It is also called face value. A bond with a par value of Tk 1,000 repays Tk 1,000 to the investor on the date of maturity.
Coupon interest | The fixed interest a bond pays each period, set as a percentage of par value. The percentage is the coupon rate. A par value of Tk 1,000 and a coupon rate of 9% give coupon interest of Tk 90 a year.
Maturity | The date on which a bond is repaid. A bond with five years to maturity pays its par value, with its last coupon interest, at the end of year 5.
Valuation | The work of finding what an asset is worth from the cash it is expected to bring. It needs the expected cash and the required return of the investor.
Intrinsic value | The worth of an asset worked out from the present value of its expected cash flows. An asset that pays Tk 1,100 in one year has an intrinsic value of Tk 1,000 at a required return of 10%.
Discount bond | A bond that sells for less than its par value. This happens when the required return is above the coupon rate. The case bond at 12% sells for Tk 891.86.
Premium bond | A bond that sells for more than its par value. This happens when the required return is below the coupon rate. The case bond at 7% sells for Tk 1,082.00.
Yield to maturity | The yearly return an investor earns by buying a bond at its price and holding it to maturity. It is the rate that makes the present value of all payments equal the price. The case bond at Tk 920 has a yield to maturity of about 11.2%.

:glossary 14
Voting right | The right of a shareholder to vote on matters put to the owners, such as choosing the directors who guide the business. Voting rights usually come with common stock, often one vote for each share, and usually not with preferred stock.
Residual claim | The right to whatever is left of a business's income and assets after lenders, suppliers, staff and preferred stockholders are paid. Common stockholders hold it. When the business does well the remainder can be large, and when it does badly it can be nothing.
Capital gain | The profit made when an asset is sold for more than it cost. For example, stock bought for Tk 50 and sold for Tk 56 gives a capital gain of Tk 6. Together with dividends, it forms the owner's return from holding the stock.
Dividend growth model | A formula valuing stock as the next dividend divided by the required return minus the growth rate. It assumes the dividend grows at a steady rate for ever, and that this rate is below the required return. A next dividend of Tk 4.24, required return of 12% and growth of 6% give Tk 70.67.

:glossary 15
Working capital | The money a business has tied up in short-term assets such as stock and money owed by customers. It is the money that moves daily from cash to goods to customers' promises and back to cash. A stall's rice, cash and customer debts are an example.
Current asset | An asset expected to turn into cash within about a year. Cash, inventory and accounts receivable are examples. A delivery cart used for many years is not a current asset.
Current liability | An amount owed that must be paid within about a year. A bill owed to a supplier and due next week is an example. A loan repayable over five years is not.
Inventory | Goods held for sale or for use in making goods. A bookshop's books, a tailor's cloth and a baker's flour are examples. Shopkeepers often call it stock.
Accounts receivable | Money owed to a business by customers who bought on credit. A school that took books in March and will pay in April creates accounts receivable for the bookshop.
Accounts payable | Money a business owes to suppliers for goods bought on credit. One business's accounts payable is its supplier's accounts receivable.
Net working capital | Current assets minus current liabilities. If the stall holds Tk 11,200 in current assets and owes Tk 10,000, its net working capital is Tk 1,200. A negative result warns that short-term debts exceed short-term assets.
Operating cycle | The days from buying stock to collecting cash from the customer. It equals the inventory days plus the receivable days. For Meghna and Sons Limited, 75 + 20 = 95 days.
Cash conversion cycle | The operating cycle minus the days a business takes to pay its suppliers. It equals inventory days plus receivable days minus payable days. For Meghna and Sons Limited, 75 + 20 − 45 = 50 days.
Float | Money that has been paid by one person but cannot yet be used by the receiver. It has three parts: mail float, processing float and clearing float. A cheque with 2, 1 and 3 days of these parts has 6 days of float.

:glossary 16
Short-term financing | Money borrowed or raised for up to one year. It suits needs that last a short time. For example, a bank overdraft cleared in two months, or a supplier's trade credit of 30 days, is short-term financing.
Intermediate-term financing | Money borrowed or raised for between one and five years. It suits assets that last a few years. For example, a loan for a delivery van, repaid in instalments over three years, is intermediate-term financing.
Long-term financing | Money borrowed or raised for more than five years. It suits needs that never end or assets that last a long time. Money that owners put into a business as equity, and a bond, are examples.
Trade credit | A supplier allowing a business to pay for goods some days after delivery. It is a loan that appears with each purchase and is the most common source of short-term financing. A bookshop that receives books on the 1st and pays on the 30th is using trade credit.
Credit terms | The discount offered and the days allowed for payment, written like 2/10, net 40. This means 2% off if paid within 10 days, and otherwise the full amount due by day 40. The code lets a buyer compare the saving with the cost of waiting.
Cash discount | A reduction in price for paying a supplier early. On an invoice of Tk 500,000 with a 2% cash discount, the discount is Tk 10,000. Refusing it is a costly loan from the supplier, so the buyer should compare its yearly cost with the interest rate of a bank.
Bank overdraft | A bank allowing an account to go below zero up to an agreed limit, with interest charged on the amount used. Interest runs only for the days used. For example, using Tk 50,000 for 30 days at 12% costs Tk 493.15.
Matching principle | The rule that short-term needs are financed with short-term funds and long-term needs with long-term funds. It protects the business from having to renew money in a hurry and from paying interest on idle cash. It is a guide, not a law.
Permanent working capital | The minimum working capital a business needs all year. A bookshop always needs some stock, some money in the till and some money owed by customers, whatever the month. This level of need is normally financed with long-term funds.
Seasonal working capital | Extra working capital needed only at the busiest times of the year. A bookshop buys extra books before the school term opens and needs the extra money for a few months. This peak is normally financed with short-term funds.

:glossary 17
Term loan | A loan repaid in instalments over a fixed period of more than one year. Each instalment usually holds some interest and some repayment of the amount borrowed. A bank loan of Tk 600,000 repaid yearly over 5 years is an example.
Collateral | An asset a borrower pledges so the lender can take it if the loan is not repaid. It lowers the lender's risk, and so often lowers the interest rate. A press machine bought with the loan can be the collateral.
Covenant | A promise in a loan agreement that limits what the borrower may do. It may set a minimum level of owners' equity or limit new borrowing. If it is broken, the lender may ask for early repayment.
Debenture | A bond backed only by the general standing of the borrower, with no particular asset pledged. Its holder trusts the borrower's record and profit, and so carries more risk than a lender with collateral.
Capital market | The market where long-term loans and shares are issued and traded. Securities are first sold there by the business that issues them, and later traded between investors. A stock exchange is part of it.
Initial public offering | The first sale of a business shares to the general public. After it, the shares are usually listed on a stock exchange. A family printing business selling 30% of its shares to strangers for the first time is an example.
Rights issue | An offer of new shares to existing shareholders in proportion to what they already hold. An owner with 10% of the shares who buys the offered share of a 1-for-5 issue keeps 10% of the business.
Cost of capital | The average return a business must earn on its funds to satisfy those who supplied them. It is a rate, not an amount, and it serves as the discount rate for judging projects. For Meghna and Sons Limited it is 12.85%.
Weighted average cost of capital | The cost of each source of funds multiplied by its share of the total and added together. Debt is counted after tax. For Meghna and Sons Limited: 1.25% + 0.40% + 11.20% = 12.85%.

:glossary 18
Lease | A contract in which the owner of an asset lets another party use it in return for regular payments. The owner keeps ownership throughout. Example: a baker pays a yearly sum to use an oven for five years while the oven stays the property of its owner.
Lessor | The owner who lets an asset out under a lease. The lessor receives the lease payments and keeps the asset, together with any resale value at the end. Example: a business that owns machines in order to let other businesses use them.
Lessee | The party who pays to use an asset under a lease. The lessee gains the use of the asset but does not own it. Example: a clinic that pays each month to use a scanner owned by another business.
Operating lease | A short or cancellable lease where the lessor keeps most of the risks of owning the asset, such as repairs and the chance that the asset becomes out of date. Example: a portable scanner hired by the month, with the right to return it.
Financial lease | A long lease that cannot be cancelled, in which the lessee in effect carries the cost and risk of owning the asset. The payments usually cover most of the price plus the lessor's return. Example: a six-year oven lease with no right to leave early.
Sale and leaseback | Selling an asset to a lessor and at once leasing it back. The business receives cash today and keeps using the asset, but makes lease payments from then on. Example: a baker sells a delivery van to a lessor and leases the same van back.
After-tax cash outflow | Cash paid out in a year after taking away the tax saved by that payment. Example: a lease payment of Tk 100 at a tax rate of 25% saves Tk 25 of tax, so the after-tax cash outflow is Tk 75.
