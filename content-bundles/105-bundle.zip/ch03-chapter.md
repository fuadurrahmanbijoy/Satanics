:chapter III | The Goal of the Firm and Agency
:mood What should a business aim for, and who makes sure it does?
:desc A business needs one clear aim. This chapter explains why the aim is the wealth of the owners, not only this year's profit, and why hired managers may follow a different aim. It names the clash that follows and the cost it brings.
:plate ch03-plate.svg | Owners gather in a long hall to hear the people who manage their business.

> What you should already know before you begin.

You will need two ideas from earlier chapters. The first is *wealth*, first defined as a stock of value (Chapter 1, section 1.1).^1 The second is *profitability* (Chapter 2, section 2.3).^2 Terms such as dividend, retained earnings and financial manager are used here as they were taught earlier.

^1: Chapter 1, 'Money, Finance and the Firm', section 1.1 'What Finance Is': wealth was first defined there as a stock of value.
^2: Chapter 2, 'The Financial Manager's Work', section 2.3: profitability was taught there. Section 2.2 'The Three Core Decisions' shows what owners give up or gain through dividend and financing decisions.

> A puzzle: which of two shops was run better?

Two friends each run a small shop that sells school supplies. At the end of the year the first friend reports a larger profit than the second. Most people answer at once that the first friend ran the better business. Then we learn more. The first friend stopped buying new stock in the last months, and the shelves are nearly bare. The second friend kept the shelves full, and a large order from a school is already waiting for the new year. The answer is now less certain.

> A second puzzle: what happens when the owner is not the manager?

Now change the story. The owner of one shop moves to another city and hires a manager to run it. The owner wants a business that stays strong for many years. The manager is paid a bonus that depends on this year's results. Will the manager choose what the owner would choose? The manager may be honest and hard-working and still face a different set of rewards.

> The chapter answers two questions, one about aims and one about people.

These two stories lead to two questions. What should a business aim for? And what happens when the people who own a business are not the people who run it? The first question is answered by the *goal of the business*. The second is answered by a body of ideas called agency theory. We take the first question in sections 3.1 and 3.2 and the second in section 3.3. A worked case then uses the facts of Meghna and Sons to test every idea.

* * *

## 3.1 Profit Maximisation and Its Limits

@! Go slowly here.

> A market stall shows how a bigger profit today can hurt the stall tomorrow.

Begin with a stall in a market. The stall holder sells tomatoes and could earn more this week by mixing in spoiled fruit and charging the usual price. This week the profit is larger. Next week the buyers who were cheated stay away, and the profit falls below its old level. The choice that gave the best result today gave a poor result over a longer time. Keep this picture in mind, because the whole of section 3.1 repeats it in business form.

@ Profit maximisation | The aim of earning the largest profit possible in a period, usually one year.

> The first and oldest answer to the question of aims is profit maximisation.

The oldest answer to the question "what should a business aim for?" has a name. **Profit maximisation** is the aim of earning the largest profit possible in a period, usually one year. A bookshop that chooses between two plans for its stock, and picks the plan with the larger profit for the year, follows this aim. The aim has real strengths. It is easy to state, it is easy to measure from the records, and it is linked to profitability, the idea you met in Chapter 2.

> A business that never earns a profit cannot survive, so the aim has a true core.

Profit matters for every person connected with a business. For the owner, it is the reward for the money placed in the business. For the manager, it is a sign of good work. For the employee, it is a sign that the job is likely to last. For the lender, it is a source of the money needed to repay a loan. We do not reject profit. We ask whether the *largest profit in one year* is the right aim, and the answer is that it is not complete.

### The problem of timing

> The same profit has different usefulness at different times.

Profit is earned in a particular period, and a plan that raises profit in one period may lower it in another. The following case file shows the difficulty with figures.

> A choice that raises this year's profit and lowers the next year's.

:case Case file, illustrative. Date: 15 May 2024. Business: Meghna and Sons, a bookshop in Dhaka. Choice: cut restocking, meaning the buying of new books to replace those sold. Effect on this year's profit: an increase of Tk 80,000. Effect on next year's profit: a decrease of Tk 150,000.

> Adding the two years shows a net loss, though the rule favours the cut.

A rule that says "earn the largest profit this year" favours the cut, because Tk 80,000 is a gain. Look at both years together and the picture changes: Tk 80,000 gained, then Tk 150,000 lost, which is a net fall of Tk 70,000. There is a second point. Money received this year can be used at once, for example to repay a loan or to buy stock, and money received next year cannot. So the two amounts are not equal in usefulness. Chapter 4 teaches how to compare money at different times with exact arithmetic. For now, remember only that *when* a profit arrives matters.

### The problem of risk

> Two plans may promise the same profit and still differ in how likely the profit is.

The second problem is risk, meaning the chance that the result will differ from what was expected. Imagine two plans for a small tailoring shop. Plan one promises Tk 50,000 from a school uniform order that has been signed and will be paid. Plan two promises Tk 50,000, but only if a large crowd comes to a festival. The promised profit is the same. Nobody who understood the difference would treat the plans as equal. The rule "largest profit" cannot see this difference, because it looks only at the number promised.

> Profit is an accounting figure, and some choices change it without improving the business.

There is a third and smaller limit. Profit for a year is a figure produced by accounting for that period. Choices about when to spend, such as delaying the restocking of the shelves, change the figure for the year without making the business better. A person who is judged only by the figure may be tempted to change it.

> Profit maximisation is useful but incomplete.

The rule to remember is short. Profit maximisation is a useful first aim, but it ignores when profits arrive and how certain they are. A better aim must take both into account. Section 3.2 supplies it.

> A short summary of section 3.1 with a test sentence.

*Before moving on.* Profit maximisation means earning the largest profit in a period, usually one year. Its limits are timing, risk, and the fact that a yearly profit can be shaped by choices about spending. You should now be able to say why a larger profit this year is not always a better result for the owner.

## 3.2 Wealth Maximisation

@! Go slowly here.

> Everyday items teach us what the words "worth" and "price" mean.

Suppose you own a used bicycle and a friend asks what it is worth. You do not answer with the price you paid two years ago, and you do not answer with how much you enjoy riding it. You think about what a buyer would hand over today. A shop nearby might say Tk 6,000. That answer is the idea we need first.

@ Market value | The price at which something could be sold today in a market.

> Market value is the price a buyer would pay now.

The name for this idea is **market value**. Market value is the price at which something could be sold today in a market. The used bicycle has a market value of Tk 6,000 if a buyer would pay that amount now. Notice that market value looks at what others will pay, so it reflects what buyers believe about the future. A bicycle that is likely to last many more years sells for more than one that is about to fail.

@ Value | Word in use. In daily life, how much we like or need something. In finance, an amount of money that a market would pay for something.

> The owners' share in a business also has a market value.

The owners of a business hold a stake in it, meaning a share of what the business owns after its debts are paid. That stake also has a market value: the price at which it could be sold today. For a large business whose common stock is traded in a public market, the price can be read each day. For a small family business, no daily price exists, so owners estimate what a buyer would pay.

@ Wealth maximisation | The aim of making the market value of the owners' stake as large as possible over time.

> Wealth maximisation is the improved answer to the question of aims.

We can now state the improved answer. **Wealth maximisation** is the aim of making the market value of the owners' stake as large as possible over time. Remember that wealth, from Chapter 1, is a stock of value. Wealth maximisation says that the owners' stock of value should grow, and that the growth is measured by market value, not by the profit of one year. A bookshop that gives up a small profit this year to win a large loyal customer group has chosen this aim if buyers would pay more for the business afterwards.

:box IN SHORT
Wealth maximisation means making the market value of the owners' stake as large as possible over time.

:pause 3.p1 | A shop owner can raise this year's profit by cutting the quality of goods, but customers will leave later. Explain in two sentences why wealth maximisation would reject the cut.

> The market looks forward, so it responds to timing and risk.

Why does this aim solve the two problems from section 3.1? A buyer who wants to purchase a business thinks about all the profits that the business is likely to earn, not the profit of the last year only. A buyer pays more for profit that comes sooner, because it can be used sooner. A buyer pays less for profit that is uncertain, because it may not arrive. So market value already contains an opinion about timing and about risk. When we aim at market value, we aim at what the owners could gain by selling their stake. Return to the restocking choice of 15 May 2024. A buyer would see that the cut lowers the next year's profit by more than it raises this year's, and would pay less for the business. The cut lowers the owners' wealth.

> A table compares the two aims on four matters.

The table that follows compares the two aims. Read each row from left to right: the first column names a matter, and the next two columns say how each aim treats it.

:table The two aims compared
| Matter | Profit maximisation | Wealth maximisation |
| What is measured | Profit of one period | Market value of the owners' stake |
| Time | Looks at one year | Looks at all future years |
| Risk | Not considered | Included in the price a buyer will pay |
| Main weakness | Can favour a short-term gain | Needs a market price, or a careful estimate |

@ Stakeholder | Any person or group affected by a business, such as workers, customers, lenders and owners.

> A stakeholder is anyone affected by the business, not only its owners.

A business affects many people besides its owners. A **stakeholder** is any person or group affected by a business, such as workers, customers, lenders and owners. A bookshop's stakeholders include its staff, the schools that buy from it, the bank that lent money and the family that owns it. Wealth maximisation does not tell the business to ignore these people. Treating them badly usually lowers market value in the end, because staff leave, customers go elsewhere and lenders refuse further loans. The law and honest dealing also set limits that no aim may break.

> Wealth maximisation has limits too.

The aim has limits that you should know. A market price may be wrong for a time, and prices change as news arrives. A business whose common stock is not traded has no price to read, so its value must be estimated, and different people may estimate differently. Even so, the aim gives a more useful guide than profit alone, and it is the aim this book uses.

> A short summary of section 3.2 with a test sentence.

*Before moving on.* Market value is the price at which something could be sold today. Wealth maximisation aims to make the market value of the owners' stake as large as possible over time, and it takes account of timing and risk. Stakeholders are all the people affected by a business, and treating them well usually supports long-run value. You should now be able to say, in one sentence, why wealth maximisation is a better aim than profit maximisation.

## 3.3 Agency Theory

@! Go slowly here.

> A historical hook: in 1776 Adam Smith doubted that hired directors guard other people's money as owners do.

In 1776 the Scottish thinker Adam Smith (1723–1790) published *The Wealth of Nations*. In it he doubted that the directors of large companies would guard the money of their shareholders with the same care that owners give to their own. Directors, he wrote, manage other people's money. Two hundred years later, in 1976, the economists Michael Jensen and William Meckling gave this old worry a precise form and a name. This section explains their idea in layers, beginning with an everyday case.

> An everyday bridge: a neighbour paid for each sack sold.

A farmer cannot go to the market, so a neighbour sells the rice harvest and receives a payment for every sack sold. The farmer wants a good price for the whole harvest. The neighbour earns more by selling many sacks quickly, even at a low price. The two people want different things, though each may be honest. Write this picture down, because every idea in this section is a version of it.

@ Principal | A person who hires another person to act for them.

> The person who hires is called the principal.

The word for the farmer in the story is **principal**. A principal is a person who hires another person to act for them. The owners of a business are its principals. The owners of a bookshop, for example, are the principals when they hire someone to run a branch.

@ Agent | A person who acts for a principal and takes decisions in the principal's name.

> The person hired is called the agent.

The word for the neighbour is **agent**. An agent is a person who acts for a principal and takes decisions in the principal's name. A hired branch manager is an agent. The relation between the two is called an agency relation, and it exists wherever one person decides on behalf of another: a taxi owner and a driver, a school principal and a bursar, a business owner and a manager.

> The agent decides, but the principal bears much of the result.

Two facts make this relation difficult. First, the agent decides, and the principal often cannot see every decision. Second, the result of the decision falls mainly on the principal. A manager who spends the owner's money freely gives up nothing personally, while the owner gives up the money.

@ Agency conflict | A clash between what a principal wants and what an agent chooses to do.

> The clash of aims has a name: agency conflict.

When the aims of the two people differ, a clash may follow. An **agency conflict** is a clash between what a principal wants and what an agent chooses to do. The owners of a business want wealth maximisation. The manager may want a large bonus, a quiet life or a bigger business to run. The conflict is not a sign of dishonesty. It arises because the agent's rewards differ from the principal's.

> The figure shows two aims pointing in different directions with a gap between them.

Before the figures, look at a picture of the idea. Read the figure from the bottom upwards. The two boxes at the bottom name the people, and each arrow shows the direction of that person's aim. The dotted space between the arrows, marked by a dashed line with two heads, is the gap between the aims. The wider the gap, the greater the risk of an agency conflict.

:fig Owner and hired manager with the gap between their aims | ch03-fig01.svg

> The case file shows two plans and an agent who gains while the owners lose.

The following case file shows an agency conflict with exact figures.

> A manager paid a share of sales is offered two plans.

:case Case file, illustrative. Date: 1 April 2024. Business: Meghna and Sons opens a second branch and hires Mr Shafiq to run it. His pay is a yearly bonus of 5% of branch sales. Plan X (steady pricing): sales Tk 1,500,000; profit before bonus Tk 150,000; bonus Tk 75,000; owners keep Tk 75,000. Plan Y (deep discounts and credit to schools): sales Tk 2,000,000; profit before bonus Tk 70,000; bonus Tk 100,000; owners keep minus Tk 30,000.

> The table shows the plans side by side.

The next table puts the figures in one place. Read down each plan's column: the sales come first, then the profit before the bonus, then the bonus, and last the amount the owners keep.

:table Plan X and Plan Y for the second branch (Tk)
| Item | Plan X | Plan Y |
| Sales | 1,500,000 | 2,000,000 |
| Profit before bonus | 150,000 | 70,000 |
| Bonus (5% of sales) | 75,000 | 100,000 |
| Owners keep | 75,000 | -30,000 |

> Each side prefers a different plan.

The manager gains Tk 25,000 more under Plan Y, because Tk 100,000 less Tk 75,000 is Tk 25,000. The owners are worse off by Tk 105,000, because Tk 75,000 less minus Tk 30,000 is Tk 105,000. The manager's bonus rises with sales, while the owners' share depends on profit. Deep discounts raise sales and lower profit, so the bonus rule rewards the plan that the owners would reject. The manager prefers Plan Y and the owners prefer Plan X.

:pause 3.p2 | In the case file, which figure in the manager's pay rule causes the conflict, and why?

> Viewpoints: the same rule looks different to owner, manager and lender.

The viewpoints differ. The owner sees a bonus rule that pays for sales whatever the result for profit. The manager sees a rule to follow, and a manager who follows it has not broken any promise. A lender, who is a person that gives money to the business and expects repayment with interest, sees a business whose owners now keep less, and so has less safety.

@ Interest | Word in use. In daily life, a wish to learn more about something, or the benefit a person gains from a result. In finance, the price paid for the use of borrowed money.

> Agency conflict has a cost.

Conflicts of this kind have a price, and the price has a name.

@ Agency cost | The loss in value, plus the cost of prevention, that comes from an agency conflict.

> The loss and the cost of preventing it are together the agency cost.

An **agency cost** is the loss in value, plus the cost of prevention, that comes from an agency conflict. In the case file the loss in value is Tk 105,000 if the manager chooses Plan Y. The cost of prevention is the money and time spent to stop such a choice, for example the owners' time spent reading branch records each month. Jensen and Meckling showed that the loss and the cost of prevention belong together, because the owners can reduce one only by paying for the other.

:box IN SHORT
An agency cost is the loss from an agency conflict plus the cost of preventing it.

> Owners reduce the conflict by lining up the rewards of the agent with their own aim.

Owners cannot remove agency cost completely, but they can reduce it by bringing the interests of the agent closer to their own. Common ways are these. They can pay the manager by a measure of long-term value, not only one year. They can give the manager a stake in the business, so that a loss is a loss for the manager too. They can check records and require reports. They can also rely on pressure from outside: a manager who does poor work finds it harder to be hired again. Each way costs something, and the owners choose where the cost of prevention is smaller than the loss prevented.

> The restocking choice shows how a short-term measure tempts an agent.

Return to the restocking choice of 15 May 2024. A manager who is judged only on this year's profit sees a gain of Tk 80,000 and does not feel the fall of Tk 150,000 that comes later. The owners, who own the business in both years, see a net fall of Tk 70,000. The conflict here is again a difference in the time that each person looks at.

> The theory has limits as well.

Agency theory also has limits. It does not say that managers are selfish, and many managers act in the owners' interest without any rule that forces them. It does not say that every cost of prevention is worth paying. It describes a pressure that exists, so that owners will think about pay rules before the pressure does harm.

> A short summary of section 3.3 with a test sentence.

*Before moving on.* A principal hires an agent, who takes decisions in the principal's name. An agency conflict is a clash between what the principal wants and what the agent chooses. An agency cost is the loss from the conflict plus the cost of preventing it. You should now be able to say who the principal and the agent are in a simple case, and why their aims may differ.

## Worked Case: The Second Branch

> The worked case follows five steps: situation, question, reasoning, conclusion, check.

A worked case applies the ideas of the chapter to one situation. We follow five steps: *Situation, Question, Reasoning, Conclusion, Check.*

> The situation is the case file facts for the second branch and the restocking choice.

*Situation.* Meghna and Sons opened a second branch on 1 April 2024 and hired Mr Shafiq, paid 5% of branch sales as a yearly bonus. Plan X gives sales of Tk 1,500,000 and owners keep Tk 75,000. Plan Y gives sales of Tk 2,000,000 and owners keep minus Tk 30,000. On 15 May 2024 a second choice arose: cutting restocking would raise this year's profit by Tk 80,000 and lower next year's profit by Tk 150,000.

> The question asks which aim each side follows and what the conflict costs.

*Question.* Which plan does each side prefer, and what is the loss in value from the conflict? Which aim, profit or wealth, favours the restocking cut?

> Reasoning works through the plans and then through the restocking choice.

*Reasoning.* First we find the bonus under each plan: 5% of Tk 1,500,000 is Tk 75,000, and 5% of Tk 2,000,000 is Tk 100,000. Second we find what the owners keep: Tk 150,000 less Tk 75,000 is Tk 75,000 under Plan X, and Tk 70,000 less Tk 100,000 is minus Tk 30,000 under Plan Y. Third we compare: the manager gains Tk 25,000 more under Plan Y and the owners lose Tk 105,000. Fourth we turn to the restocking choice. This year's profit rises by Tk 80,000, and next year's falls by Tk 150,000, so the two years together show a fall of Tk 70,000.

> The conclusion names the preferences and the aim that favours the cut.

*Conclusion.* The manager prefers Plan Y and the owners prefer Plan X. The loss in value from the conflict is Tk 105,000, and the cost of preventing it, such as checking the records, is added to that loss to find the agency cost. A rule of one-year profit favours the restocking cut, while wealth maximisation rejects it, because the market would pay less for the owners' stake.

> The check confirms the arithmetic and the sense of the result.

*Check.* Tk 75,000 plus Tk 30,000 is Tk 105,000, which agrees with the loss. Tk 100,000 less Tk 75,000 is Tk 25,000, which agrees with the manager's gain. The result is sensible, because a bonus on sales rewards sales and does not reward profit.

### The same idea in four situations

> A ladder of situations shows the idea in new settings.

The idea is useful only if you can recognise it elsewhere. Each situation below changes the setting while keeping the idea.

> Familiar case: a tailor paid on monthly profit.

*A familiar case.* A tailor manages a shop for its owner and is paid on the monthly profit. The tailor skips the buying of fabric to show a larger profit this month. The owner loses the sales of later months. Here the tailor is the agent and the owner is the principal.

> Reshaped case: a driver paid per trip.

*A reshaped case.* A taxi owner pays a hired driver for each trip. The driver takes many short trips and drives hard, and the car wears out faster. The driver's reward is the number of trips, and the owner's reward is the condition and profit of the car.

> New setting: a school principal and a bursar.

*A new setting.* The principal of a school wants the best use of limited fees. The bursar, who keeps the school accounts, is judged on spending less than the budget. The bursar may delay repairs that the principal wants. The setting has no profit, yet the pattern is the same.

> Combined case: three aims at once.

*A combined case.* A hired manager wants a larger bonus, the owners want a larger market value, and a lender wants safe repayment with interest. All three may prefer different plans, and the manager's choice affects the other two.

## Summary

> Summary of the chapter.

The goal of the business is wealth maximisation, which is the aim of making the market value of the owners' stake as large as possible over time. Profit maximisation, the aim of the largest profit in a period, ignores timing and risk. Stakeholders are affected by the business and should not be treated badly. When owners hire managers, a principal and an agent exist, and an agency conflict may follow. An agency cost is the loss from the conflict plus the cost of prevention.

## Think It Through

:q 3.t1 | A manager is paid 4% of branch sales. Plan P gives sales of Tk 1,000,000 and profit before bonus of Tk 120,000. Plan Q gives sales of Tk 1,400,000 and profit before bonus of Tk 60,000. Find the bonus and the amount the owners keep under each plan, say which plan each side prefers, and find the loss in value to the owners if the manager chooses Plan Q.
:q 3.t2 | Suppose Mr Shafiq were paid 5% of the change in profit over the two years instead of 5% of sales. Using the restocking choice of 15 May 2024, find his gain or loss and say whether he would now cut restocking.

## Where People Go Wrong

> Four common misunderstandings are stated and corrected in the table.

The table lists four common mistakes. Read each row from left to right: the first column gives the mistake and the second gives the correction.

:table Common mistakes and corrections
| Mistake | Correction |
| The plan with the largest profit this year is always best | It may lower later profit or carry more risk; wealth maximisation weighs both |
| Wealth maximisation means ignoring workers and customers | Stakeholders affect long-run value, and the law and honest dealing still apply |
| An agency conflict means the manager is dishonest | The conflict comes from different rewards; an honest manager may still follow the pay rule |
| Agency cost exists only in large companies | It exists wherever one person decides for another, even in a small shop |

## In History

> Smith in 1776 and Jensen and Meckling in 1976 form the history of agency.

In 1776 Adam Smith, a Scottish thinker (1723–1790), published *The Wealth of Nations* in London. In the part on companies owned by many shareholders, he doubted that the directors, who manage other people's money, would watch it with the care that owners give to their own. He expected carelessness and waste.

> Jensen and Meckling gave the worry a precise form exactly two hundred years later.

In 1976 two economists of the University of Rochester in the United States, Michael C. Jensen and William H. Meckling, published "Theory of the Firm: Managerial Behavior, Agency Costs and Ownership Structure" in the *Journal of Financial Economics* (volume 3, pages 305–360). They defined agency costs, related them to the separation of ownership from control, and studied the agency costs created by debt and by outside owners. They also grouped the costs under three heads: the cost of watching the agent, the cost the agent bears to give assurance, and the loss that remains.

## Sources

> Smith's book is the early source for the worry about other people's money.

Adam Smith, *An Inquiry into the Nature and Causes of the Wealth of Nations* (1776), is a founding work of economics. It matters here for its early warning about directors who manage the money of others.

> The paper by Jensen and Meckling is the founding work of agency theory in finance.

Michael C. Jensen and William H. Meckling, "Theory of the Firm: Managerial Behavior, Agency Costs and Ownership Structure", *Journal of Financial Economics*, volume 3 (1976), is the landmark work. It matters because it defined agency cost and applied it to the way a business is owned and financed.

## Review Questions

:q 3.1 | Explain why profit maximisation can mislead when returns come at different times or carry different risk.
:q 3.2 | Explain wealth maximisation in plain words to a village shopkeeper who has never heard the term.
:q 3.3 | Describe an agency conflict between a taxi owner and a driver who is paid for each trip.
:q 3.4 | Name three ways in which owners can bring the interests of a manager closer to their own, and say what each costs.

:read Adam Smith, An Inquiry into the Nature and Causes of the Wealth of Nations, 1776
:read Michael C. Jensen and William H. Meckling, Theory of the Firm: Managerial Behavior, Agency Costs and Ownership Structure, 1976
