:answers 01
:a 1.p1 | No. The tailor has accepted an order, but no money has moved today. The cash flow into the business will come next week, when the customer pays.
:a 1.p2 | The Tk 300,000 of savings is equity, and the Tk 100,000 loan is debt. The bank must be repaid on agreed dates; the owner shares any profit or loss.
:a 1.t1 | Ticket sales of Tk 40,000 are a cash flow into the business today. The film hire of Tk 25,000 is owed next month, so it is not a cash flow today. The Tk 10,000 loan instalment is a cash flow out today.
:a 1.t2 | The net cash flow today is Tk 40,000 less Tk 10,000, which is Tk 30,000 in. The film hire of Tk 25,000 is a liability; it will become a cash flow out next month, when it is paid.
:a 1.1 | For her, finance is finding money and deciding how to use it. She might find Tk 800 by asking her cousin, and decide to spend it on onions to sell.
:a 1.2 | Recording the money received is accounting, because it records what has happened. Deciding whether to borrow for the machine is finance, because it looks forward and asks where to find money and how to use it.
:a 1.3 | The two sources are the owner's savings, which are equity, and the loan, which is debt. Two uses might be ovens and other equipment, and ingredients to bake with, or money kept at the bank.
:a 1.4 | The sale is counted in June, when the goods are taken. The money moves only on 28 July, so the cash flow into the business falls in July.
:a 1.5 | Cash flow in is Tk 3,000, and cash flow out is Tk 2,000. The net movement is Tk 3,000 less Tk 2,000, which is Tk 1,000 in.
:a 1.6 | The Tk 800 is a source of funds, and it is debt, because it must be repaid. Afterwards she owes her cousin Tk 800, which is a liability, plus any extra charge they agree.
:a 1.7 | A source might be the school fund; a use might be buying ingredients for the canteen. The canteen's daily sales bring cash flow into it.
:a 1.8 | The sources are the owners' savings, which are equity, and the bank loan, which is debt. Two assets might be medical equipment and a cash and bank balance. Finance is one business function beside the clinic's other work; it finds funds and judges the money side of the other functions' decisions.

:answers 02
:a 2.p1 | The decision to buy the oven for Tk 200,000 is the investment decision. Paying Tk 80,000 from owners' funds and borrowing Tk 120,000 is the financing decision.
:a 2.p2 | The dividend is Tk 25,000, the part of the profit paid out. The retained earnings are Tk 90,000 less Tk 25,000, which is Tk 65,000.
:a 2.t1 | The new oven is an investment decision. The payout to the owners is a dividend decision. Repaying the loan changes how the business is funded, so it is a financing decision.
:a 2.t2 | Repaying the loan reduces debt, so lenders supply less of the funds. A dividend takes money out to the owners, so the business keeps less profit as owners' funds. Repaying the loan leaves the Tk 150,000 of profit used inside the business; a dividend sends it out.
:a 2.1 | Planning: decide in advance what money the shop will need, such as stock for the new term. Raising: find that money from the family or a bank. Control: compare spending with the plan and act on any difference.
:a 2.2 | Buying the scanner is the investment decision; choosing a bank loan to pay for it is the financing decision. The dividend decision, how much profit to pay out and how much to keep, has not yet been made.
:a 2.3 | Planning decides in advance that Tk 30,000 will be needed for cloth and arranges it. Control compares the actual bill with Tk 30,000 afterwards, finds any difference, and acts on it.
:a 2.4 | Profit is not cash. If cash is short, suppliers may refuse deliveries, wages may be late and chances to buy cheaply may pass, even though the shop earns a profit.
:a 2.5 | Buying the fridge is an investment decision. Repaying the loan changes how the household is funded, so it is a financing decision.
:a 2.6 | The freezer is an investment decision, and paying herself is a dividend decision. The dividend is Tk 50,000, and the retained earnings are Tk 40,000. Using kept profit to pay for the freezer is also part of the financing decision.
:a 2.7 | The three decisions are investment (the machine), financing (the loan) and dividend (the payout). The more profit is paid out, the less is retained to pay for the machine, so the more the manufacturer may need to borrow.
:a 2.8 | Tailor A is more efficient, because A uses Tk 70 for each Tk 100 of sales against Tk 80. Efficiency looks at the cost per unit of sales; profitability compares profit with the money invested or the sales made.

:answers 03
:a 3.p1 | Wealth maximisation looks at the market value of the owners' stake over time. A buyer would pay less for a business that has lost its customers, so the cut lowers the owners' wealth even though this year's profit rises.
:a 3.p2 | The bonus is 5% of branch sales. It rises with sales whatever happens to profit, so Plan Y, with more sales and less profit, pays the manager more while the owners lose.
:a 3.t1 | Plan P: bonus 4% of Tk 1,000,000 = Tk 40,000; owners keep Tk 120,000 - Tk 40,000 = Tk 80,000. Plan Q: bonus 4% of Tk 1,400,000 = Tk 56,000; owners keep Tk 60,000 - Tk 56,000 = Tk 4,000. The manager prefers Q (Tk 16,000 more) and the owners prefer P. If the manager chooses Q, the owners lose Tk 80,000 - Tk 4,000 = Tk 76,000.
:a 3.t2 | The change in profit over the two years is Tk 80,000 - Tk 150,000 = minus Tk 70,000. Five per cent of that is minus Tk 3,500, a loss to him, so he would not cut restocking. The new rule lines his reward up with the owners' result.
:a 3.1 | Profit maximisation looks at one period only. It cannot see that money arriving earlier is more useful, or that one plan may be less certain than another, so a larger profit now can leave the owners worse off.
:a 3.2 | Tell the shopkeeper: the aim is to make the shop worth as much as possible if someone wished to buy it, now and in the coming years. Choices that win loyal customers and keep the shelves full raise that worth, while quick gains that lose customers lower it.
:a 3.3 | The taxi owner wants a car in good condition and a steady profit. The driver is paid per trip, so takes as many trips as possible, perhaps driving hard and wearing out the car. Their rewards differ, so their choices differ.
:a 3.4 | Examples: pay the manager by long-term value (cost: a harder pay rule to design); give the manager a stake in the business (cost: a share of the owners' return); check records and require reports (cost: time and money for the owners).

:answers 04
:a 4.p1 | Year 1: Tk 11,000. Year 2: Tk 12,100. Year 3: Tk 12,100 × 1.10 = Tk 13,310. Check: Tk 10,000 × 1.331 = Tk 13,310.
:a 4.p2 | Year by year: Tk 13,310 ÷ 1.10 = Tk 12,100, then ÷ 1.10 = Tk 11,000, then ÷ 1.10 = Tk 10,000. The present value is Tk 10,000.
:a 4.t1 | PV = Tk 130,000 ÷ 1.07 to the power of 5 = Tk 130,000 ÷ 1.402552 = about Tk 92,688. This is above Tk 90,000, so waiting is better. Check: Tk 90,000 × 1.402552 = about Tk 126,230, which is below Tk 130,000.
:a 4.t2 | Factor = 21,277.79 ÷ 15,000 = 1.418519. In the 6% column of the future value table this factor is in the row for 6 years, so n = 6 years.
:a 4.1 | Factor = 1.09 to the power of 6 = 1.677100. FV = Tk 15,000 × 1.677100 = Tk 25,156.50.
:a 4.2 | Factor = 1 ÷ 1.11 to the power of 4 = 1 ÷ 1.518070 = 0.658731. PV = Tk 80,000 × 0.658731 = Tk 52,698.48.
:a 4.3 | Simple: Tk 25,000 × (1 + 0.06 × 8) = Tk 37,000. Compound: Tk 25,000 × 1.06 to the power of 8 = Tk 25,000 × 1.593848 = Tk 39,846.20. Compound interest is Tk 2,846.20 higher.
:a 4.4 | Rate per quarter = 12% ÷ 4 = 3%. Effective annual rate = 1.03 to the power of 4 − 1 = 1.125509 − 1 = 12.55%.
:a 4.5 | Opportunity cost of idle cash is the interest it could have earned. Example: Tk 50,000 kept in a drawer for a year loses the Tk 4,000 that a bank paying 8% would have given.

:answers 05
:a 5.p1 | Factor = (1.10⁴ − 1) ÷ 0.10 = (1.4641 − 1) ÷ 0.10 = 4.641. Future value = Tk 1,000 × 4.641 = Tk 4,641.
:a 5.p2 | Tk 3,310 × 1.10 = Tk 3,641, or Tk 1,331 + Tk 1,210 + Tk 1,100 = Tk 3,641.
:a 5.t1 | Present value of the plan = Tk 90,000 × 3.790787 = about Tk 341,171. This is less than Tk 400,000, so the payment plan costs less today. The delay in paying is worth something at 10%.
:a 5.t2 | Each payment of an annuity due is made one period earlier, so it earns one more period of interest, or is discounted one period less. Every payment is therefore worth 1 + i times as much.
:a 5.1 | Factor = (1.09⁶ − 1) ÷ 0.09 = 7.523335. Ordinary: Tk 12,000 × 7.523335 = about Tk 90,280. Due: Tk 90,280 × 1.09 = about Tk 98,405.
:a 5.2 | Factor = (1 − 1.10⁻⁵) ÷ 0.10 = 3.790787. Present value = Tk 45,000 × 3.790787 = about Tk 170,585.
:a 5.3 | Factor = (1.07⁴ − 1) ÷ 0.07 = 4.439943. Deposit = Tk 300,000 ÷ 4.439943 = about Tk 67,568.
:a 5.4 | Factor = (1 − 1.12⁻³) ÷ 0.12 = 2.401831. Payment = Tk 250,000 ÷ 2.401831 = about Tk 104,087.
:a 5.5 | An ordinary annuity pays at the end of each period and an annuity due at the start. The annuity due has the higher future value, because each payment earns one more period of interest.
:a 5.6 | Present value = Tk 20,000 ÷ 0.05 = Tk 400,000. A fund of Tk 400,000 earns 5% × Tk 400,000 = Tk 20,000 a year, so paying out only the interest leaves the fund whole.

:answers 06
:a 6.p1 | Tk 3,000 ÷ 1.10 + Tk 2,000 ÷ 1.21 + Tk 1,000 ÷ 1.331 = Tk 2,727.27 + Tk 1,652.89 + Tk 751.31 = about Tk 5,131.48. It is worth more, because the larger receipts come sooner.
:a 6.t1 | Plan X: Tk 81,818.18 + Tk 49,586.78 + Tk 22,539.44 = Tk 153,944.40. Plan Y: Tk 27,272.73 + Tk 49,586.78 + Tk 67,618.33 = Tk 144,477.84. Plan Y costs less in present value, because its larger payments fall later.
:a 6.t2 | Money has a time value, so a taka received sooner is worth more than a taka received later. The same total, paid in a different order, gives a different present value.
:a 6.1 | Tk 18,181.82 + Tk 28,925.62 + Tk 37,565.74 = Tk 84,673.18.
:a 6.2 | Tk 20,000 × 1.21 + Tk 35,000 × 1.10 + Tk 50,000 = Tk 24,200 + Tk 38,500 + Tk 50,000 = Tk 112,700.
:a 6.3 | Annuity part: Tk 15,000 for 5 years, Tk 15,000 × 3.790787 = Tk 56,861.80. Odd part: Tk 25,000 extra in year 5, Tk 25,000 × 0.620921 = Tk 15,523.03. Present value = Tk 72,384.83.
:a 6.4 | At 9%: rising Tk 86,416.60, falling Tk 90,774.03. At 15%: rising Tk 76,732.14, falling Tk 83,093.61. The falling stream is worth more at both rates, and the gap is larger at 15%.
:a 6.5 | In an annuity all payments are equal, in a mixed stream they differ. The annuity factor assumes equal payments, so it fits only a level part of a stream; the rest must be discounted as single sums.

:answers 07
:a 7.p1 | No. The survey was paid in December 2024 and cannot be recovered whether or not the machine is bought, so it is a sunk cost and does not change the decision.
:a 7.t1 | Asset cost 560,000 + 40,000 = Tk 600,000; initial investment 600,000 + 50,000 = Tk 650,000. Depreciation (600,000 − 100,000) ÷ 4 = 125,000. EBIT 500,000 − 260,000 − 125,000 = 115,000; tax 28,750; operating cash flow 115,000 − 28,750 + 125,000 = Tk 211,250. Terminal cash flow 100,000 + 50,000 = 150,000. Net cash flows: year 0 −650,000; years 1 to 3 211,250; year 4 361,250.
:a 7.t2 | They are mutually exclusive, because buying one means rejecting the other. The first step is to find and list the proposals, then estimate the cash flows of each scanner.
:a 7.1 | Capital budgeting is the process of planning, evaluating and choosing long-term investments. A business needs it because such decisions are long, large for the business and hard to reverse, so a mistake is costly and lasts for years.
:a 7.2 | Find proposals (which oven, which supplier); estimate cash flows (price, extra sales, running costs); evaluate and choose (judge the cash flows against the cost of funds); implement (buy, install, train the staff); review (compare real cash flows with the forecast).
:a 7.3 | Independent projects do not affect each other, such as a new oven and a new delivery bicycle. Mutually exclusive projects allow only one, such as two different ovens for the same space, or a machine against a branch fit-out that cannot be run together.
:a 7.4 | Relevant: (a) the price, (c) the extra electricity and (d) the extra stock, because each changes only if the freezer is bought. Not relevant: (b) the report, a sunk cost, and (e) the rent, which is the same either way.
:a 7.5 | EBIT = 240,000 − 120,000 − 40,000 = Tk 80,000. Tax = 0.25 × 80,000 = Tk 20,000. Operating cash flow = 80,000 − 20,000 + 40,000 = Tk 100,000. Check: 240,000 − 120,000 − 20,000 = 100,000.
:a 7.6 | Gain = 70,000 − 50,000 = 20,000; tax = 0.25 × 20,000 = 5,000; sale after tax = 65,000. Add working capital of 20,000: terminal cash flow = Tk 85,000.

:answers 08
:a 8.p1 | Project A: 60,000 ÷ 30,000 = 2 years. Project B: 3 years (3 × 20,000 = 60,000). Payback misses the cash after the payback point: A returns only its cost, while B returns Tk 120,000 in all.
:a 8.p2 | Present values: 12,000 ÷ 1.10 = 10,909 and 12,000 ÷ 1.21 = 9,917, total 20,826. NPV = 20,826 − 20,000 = Tk 826. It is positive, so accept.
:a 8.t1 | Payback: X = 2.00 years; Y = 3 + 50,000 ÷ 400,000 = 3.13 years. NPV at 10%: X = 272,727 + 165,289 + 75,131 + 68,301 − 500,000 = Tk 81,449; Y = 90,909 + 123,967 + 150,263 + 273,205 − 500,000 = Tk 138,344. Payback prefers X, net present value prefers Y. Choose Y, because it adds Tk 56,895 more value and net present value uses all the cash and its timing.
:a 8.t2 | Net present value is the present value of the inflows minus the initial investment. At the internal rate of return the discounted inflows are exactly equal to the initial investment, so the difference is zero.
:a 8.1 | After 2 years the inflows total 270,000; unrecovered 130,000. Year 3 inflow is 180,000: 130,000 ÷ 180,000 = 0.72. Payback period = 2.72 years.
:a 8.2 | Present values: 109,091 + 123,967 + 135,237 + 136,603 = about 504,897. NPV = about Tk 104,897. It is positive, so accept.
:a 8.3 | Payback: accept if no longer than the limit set by managers. Net present value: accept if zero or more. Internal rate of return: accept if at least the required return. Profitability index: accept if at least 1.
:a 8.4 | NPV at 20% = +4,784; at 25% = −33,920. IRR = 20 + 5 × 4,784 ÷ (4,784 + 33,920) = 20 + 0.62 = about 20.6%.
:a 8.5 | M: index 330,000 ÷ 300,000 = 1.10; NPV = Tk 30,000. N: index 540,000 ÷ 500,000 = 1.08; NPV = Tk 40,000. M ranks first by index; N ranks first by net present value.
:a 8.6 | Payback period: the time to recover the initial investment. Net present value: the worth today of the inflows minus the initial investment, in taka. Internal rate of return: the discount rate at which net present value is zero. Profitability index: present value of inflows per taka of initial investment.
:a 8.7 | Net present value should decide, because it uses all the cash flows, respects their timing and states the gain in taka. Payback ignores later cash and timing, so it serves only as a second look at how long the money is tied up.

:answers 09
:a 9.p1 | No. The probabilities add up to 0.2 + 0.5 + 0.4 = 1.1, and a probability distribution must add up to exactly one.
:a 9.p2 | Deviations below the expected value are negative and those above are positive, so they would cancel to zero. Squaring makes every deviation positive, so the spread shows.
:a 9.t1 | Coefficient of variation: Project X = 10,000 ÷ 50,000 = 0.20; Project Y = 24,000 ÷ 80,000 = 0.30. Project Y carries more risk for each unit of return.
:a 9.1 | Return = 5,600 + (82,000 − 80,000) = Tk 7,600. Rate of return = 7,600 ÷ 80,000 = 0.095, or 9.5%.
:a 9.2 | Business risk comes from the trade: sales, costs and trade conditions, for example a rise in the price of paper. Financial risk comes from borrowing: interest of Tk 60,000 a year on a loan of Tk 600,000 at 10% must be paid in poor years too, so what is left for the owners varies more.
:a 9.3 | Expected value = 0.25 × 6 + 0.50 × 10 + 0.25 × 14 = 1.5 + 5.0 + 3.5 = 10%. Deviations −4, 0, +4; squares 16, 0, 16; weighted 4 + 0 + 4 = 8; standard deviation = √8 = 2.83%.
:a 9.4 | Asset M: 3 ÷ 10 = 0.30. Asset N: 9 ÷ 18 = 0.50. Asset N carries more risk for each unit of return, although its expected return is higher.

:answers 10
:a 10.p1 | About 10%. A beta of 2 means the investment moves about twice as far as the market, so 2 × 5% = 10%.
:a 10.p2 | Market risk premium = 10% − 6% = 4%. Required return = 6% + 0.5 × 4% = 8%.
:a 10.t1 | Premium = 14% − 8% = 6%. Required return = 8% + 1.0 × 6% = 14%. The expected return of 13% is below 14%, so the line lies below the security market line. Reject it.
:a 10.1 | Market risk premium = 13% − 7% = 6%. Required return = 7% + 1.2 × 6% = 7% + 7.2% = 14.2%.
:a 10.2 | Firm-specific risk hits one business only, so losses at some businesses are offset by gains at others when many are held. Market risk hits all businesses at once, so holding more of them cannot remove it.
:a 10.3 | The line starts at 6% at beta 0 and rises 4 points for each whole step of beta, reaching 10% at beta 1 and 14% at beta 2. At beta 0.5 the required return is 8%; at beta 1.5 it is 12%.
:a 10.4 | Weak form: studying past price charts does not help. Semi-strong form: reading a public report after it appears does not help. Strong form: using secret information known only to managers does not help.
:a 10.5 | No. An expected return below the line is less than the required return for that much market risk, so the investment does not pay enough for the risk. The investor should reject it, or accept only if its expected return rises to the line.

:answers 11
:a 11.p1 | 5,000 ÷ 25 = 200 units.
:a 11.p2 | DOL = 60,000 ÷ 20,000 = 3.00. A fall of 10% in sales lowers EBIT by 3.00 × 10% = 30%.
:a 11.t1 | Before: CM = 90 − 50 = Tk 40, so break-even is 240,000 ÷ 40 = 6,000 packs. After: CM = 90 − 30 = Tk 60, so break-even is 480,000 ÷ 60 = 8,000 packs.
:a 11.t2 | Before: contribution 9,000 × 40 = Tk 360,000, EBIT Tk 120,000, DOL 3.00. After: contribution 9,000 × 60 = Tk 540,000, EBIT 540,000 − 480,000 = Tk 60,000, DOL 540,000 ÷ 60,000 = 9.00. The new machine carries more business risk, because its break-even point and its leverage are both higher.
:a 11.1 | A fixed operating cost stays the same whatever the units sold, such as shop rent. A variable operating cost grows with each unit, such as the price paid for each book bought for resale.
:a 11.2 | CM = 150 − 95 = Tk 55. Break-even = 330,000 ÷ 55 = 6,000 units.
:a 11.3 | At 5,000 units: 5,000 × 55 − 330,000 = −Tk 55,000, a loss. At 6,000 units: EBIT is 0. At 7,000 units: 385,000 − 330,000 = Tk 55,000.
:a 11.4 | Contribution = 8,000 × 55 = Tk 440,000. EBIT = 440,000 − 330,000 = Tk 110,000. DOL = 440,000 ÷ 110,000 = 4.00.
:a 11.5 | Near break-even EBIT is small compared with contribution, so the quotient is large. For the printing unit it is 4.00 at 8,000 packs and 3.00 at 9,000 packs. At break-even EBIT is zero and the value cannot be found.

:answers 12
:a 12.p1 | Degree of financial leverage = 50,000 ÷ (50,000 − 10,000) = 50,000 ÷ 40,000 = 1.25.
:a 12.t1 | A high degree of operating leverage already makes EBIT swing widely when sales change. Borrowing adds a second lever, and the two multiply, so earnings per share would swing even more. Owners who dislike a wide swing may borrow little to keep total risk lower.
:a 12.1 | Profit before tax = 150,000 − 30,000 = 120,000. Tax = 30,000. Profit after tax = 90,000. Less preferred dividend 18,000 = 72,000. Earnings per share = 72,000 ÷ 10,000 = Tk 7.20.
:a 12.2 | Preferred dividend before tax = 18,000 ÷ 0.75 = 24,000. Degree of financial leverage = 150,000 ÷ (150,000 − 30,000 − 24,000) = 150,000 ÷ 96,000 = 1.56.
:a 12.3 | Degree of total leverage = 2.50 × 1.60 = 4.00.
:a 12.4 | Earnings per share rises by about 4.00 × 10% = 40%. From Tk 5.00 it becomes about Tk 5.00 × 1.40 = Tk 7.00.
:a 12.5 | Plan X: at EBIT 100,000, (100,000 − 40,000) ÷ 4,000 = Tk 15.00; at 60,000, 20,000 ÷ 4,000 = Tk 5.00, a fall of 66.7%. Plan Y: at 100,000, 100,000 ÷ 8,000 = Tk 12.50; at 60,000, 60,000 ÷ 8,000 = Tk 7.50, a fall of 40%. Plan X is riskier, because its earnings per share swings more for the same fall in EBIT.

:answers 13
:a 13.p1 | 8% × 500 = Tk 40 each year.
:a 13.p2 | The investor receives 50 + 1,000 = Tk 1,050 in one year. Value = 1,050 ÷ 1.10 = Tk 954.55.
:a 13.t1 | More than the coupon rate. At 10% the value is Tk 962.09, above Tk 940. At 11% it is Tk 926.08, below Tk 940. The required return lies between 10% and 11% (about 10.6%), above 9%.
:a 13.t2 | A discount bond, because Tk 940 is below par. If the required return fell to 9%, the price would become Tk 1,000.00, equal to par.
:a 13.1 | C = Tk 80, a = 3.169865, f = 0.683013. Coupons: 80 × 3.169865 = 253.589. Par value: 1,000 × 0.683013 = 683.013. Value = Tk 936.60.
:a 13.2 | Discount bond: the required return is above the coupon rate, so the fixed coupon is less attractive and the price falls below par. Par bond: the two rates are equal, so the price equals par. Premium bond: the required return is below the coupon rate, so the coupon is more attractive and the price rises above par.
:a 13.3 | Coupon Tk 30, 4 periods, 4% per half-year: a = 3.629895, f = 0.854804. Coupons: 30 × 3.629895 = 108.897. Par value: 1,000 × 0.854804 = 854.804. Value = Tk 963.70.
:a 13.4 | At 10% the value is Tk 962.09; at 11% it is Tk 926.08. The fraction is (962.09 − 950) ÷ (962.09 − 926.08) = 12.09 ÷ 36.01 = 0.336. The yield to maturity is about 10.3%.
:a 13.5 | The coupons and the par value are fixed. A higher required return means each future payment is discounted more heavily, so its present value is smaller and the total falls.

:answers 14
:a 14.p1 | Value = 10 ÷ (0.15 − 0.05) = 10 ÷ 0.10 = Tk 100.00.
:a 14.t1 | The bond suits her better. It pays fixed interest by contract, and a lender is paid before owners if the business ends. Common stock pays dividends the directors may cut, and its holder has only a residual claim, paid last, so the risk of loss is higher.
:a 14.1 | P = 9 ÷ 0.12 = Tk 75.00.
:a 14.2 | D₁ = 3.50 × 1.05 = 3.675. Then r − g = 0.11 − 0.05 = 0.06, so P₀ = 3.675 ÷ 0.06 = Tk 61.25.
:a 14.3 | If g equals r, the bottom of the fraction is zero and no value exists. If g is above r, the value is negative, which has no meaning. A business also cannot raise dividends faster than the required return for ever.
:a 14.4 | Any three: a bond holder lends and a stockholder owns; bond interest is fixed while dividends are decided by the directors; a bond gives no vote while common stock does; a lender is paid before owners; the stockholder carries more risk.
:a 14.5 | At 12%: 6 ÷ 0.12 = Tk 50.00. At 15%: 6 ÷ 0.15 = Tk 40.00. The value falls by Tk 10.00, because a higher required return lowers the present value.
:a 14.6 | A: D₁ = 4.16, so P₀ = 4.16 ÷ 0.08 = Tk 52.00. B: D₁ = 4.28, so P₀ = 4.28 ÷ 0.05 = Tk 85.60. The gap of Tk 33.60 arises because higher growth shrinks r − g from 0.08 to 0.05.
:a 14.7 | Bond: 80 × 2.48685 + 1,000 × 0.75131 = 198.95 + 751.31 = Tk 950.26. Stock: D₁ = 2.00 × 1.05 = 2.10, so P₀ = 2.10 ÷ 0.05 = Tk 42.00; ten shares are Tk 420.00. Total = Tk 1,370.26.

:answers 15
:a 15.p1 | 40 + 15 = 55 days.
:a 15.p2 | 70 − 30 = 40 days. For 40 days the business must use its own money.
:a 15.t1 | Each item rises by one fifth, so the net investment is Tk 1,010,959 × 1.2 = about Tk 1,213,151. The extra money needed is about Tk 202,192. More sales means more inventory and more money owed by customers, and the amount owed to suppliers rises less than the total.
:a 15.1 | Operating cycle: 60 + 25 = 85 days. Cash conversion cycle: 85 − 35 = 50 days.
:a 15.2 | Inventory: 7,300,000 × 60 ÷ 365 = Tk 1,200,000. Receivables: 10,950,000 × 25 ÷ 365 = Tk 750,000. Payables: 7,300,000 × 35 ÷ 365 = Tk 700,000. Net investment: 1,200,000 + 750,000 − 700,000 = Tk 1,250,000.
:a 15.3 | The parts are mail float, processing float and clearing float. The days lost are 3 + 2 + 2 = 7 days.
:a 15.4 | Customers then pay in fewer days, so the receivable days fall. The operating cycle and the cash conversion cycle fall by the same number of days, and less of the business's own money is tied up.

:answers 16
:a 16.p1 | Cost = 0.01 ÷ 0.99 × 365 ÷ 20 = 0.010101 × 18.25 = 0.1843, or 18.43% a year.
:a 16.t1 | Fund the permanent Tk 300,000 long term: 300,000 × 0.10 = Tk 30,000. Fund the seasonal Tk 150,000 short term: 150,000 × 0.13 × 4 ÷ 12 = Tk 6,500. Total Tk 36,500. All long term: 450,000 × 0.10 = Tk 45,000. Interest saved: Tk 8,500.
:a 16.1 | Cost = 0.02 ÷ 0.98 × 365 ÷ 20 = 0.020408 × 18.25 = 37.24% a year.
:a 16.2 | Cost = 0.03 ÷ 0.97 × 365 ÷ 35 = 0.030928 × 10.4286 = 32.25% a year.
:a 16.3 | Discount = Tk 4,000, so the payment on day 10 is Tk 196,000. Interest for 30 days = 196,000 × 0.13 × 30 ÷ 365 = Tk 2,094, which is less than Tk 4,000. Giving up the discount costs 24.83%, above 13%. Borrow and take the discount, gaining about Tk 1,906.
:a 16.4 | 3/10, net 30: 0.03 ÷ 0.97 × 365 ÷ 20 = 56.44%. 1/10, net 60: 0.01 ÷ 0.99 × 365 ÷ 50 = 7.37%. The first is more costly to give up, by about 49.07 percentage points.
:a 16.5 | Short: up to one year, for example trade credit or a bank overdraft. Intermediate: one to five years, for example a loan for a van repaid in instalments. Long: more than five years, for example equity from the owners or a bond.
:a 16.6 | Fund the permanent need, the stock held all year, with long-term money. Fund the extra December stock with short-term money, such as an overdraft, and repay it in January when the stock is sold.
:a 16.7 | Permanent working capital is the minimum the shop needs all year, such as basic stock and money in the till. Seasonal working capital is the extra stock and money needed only before the school term opens.
:a 16.8 | An overdraft charges interest only on the amount used and only for the days used, while a short loan charges interest on the whole amount for the whole period. A business whose need rises and falls may prefer the overdraft.

:answers 17
:a 17.p1 | No. A debenture has no particular asset pledged. Here the building is pledged, so this is a loan secured by collateral, a mortgage.
:a 17.p2 | Debt: 200,000 ÷ 1,000,000 = 20%. Common equity: 800,000 ÷ 1,000,000 = 80%.
:a 17.t1 | A machine and a shop fit-out last for years and pay for themselves slowly. A short-term loan would fall due long before they have earned the money, so the business would have to sell them or borrow again. Long-term funds stay for as long as the assets take to pay for themselves.
:a 17.1 | Any three. Collateral: the lender can take an asset if the loan is not repaid, which lowers its risk. A covenant, such as a minimum level of owners' equity: it protects the cushion behind the loan. A limit on new borrowing or on profit paid out: it stops money leaving the business. A schedule of instalments: it returns the money along the way.
:a 17.2 | A public issue offers shares to the general public. It reaches many buyers and can raise large sums, but it brings fees, disclosure and new owners. A rights issue offers new shares only to existing shareholders in proportion to their holdings. It is cheaper and keeps control with the old owners, but it raises only what they are willing to pay.
:a 17.3 | Any four. Commercial banks: term loans. Bangladesh Development Bank Limited: long-term loans to industrial projects. Investment Corporation of Bangladesh: money invested in shares and securities. IDCOL: long-term loans for infrastructure and renewable energy. Dhaka Stock Exchange and Chittagong Stock Exchange: places where shares are issued and traded.
:a 17.4 | 11% × (1 − 0.25) = 11% × 0.75 = 8.25%.
:a 17.5 | 0.25 × 7.5% = 1.875%. 0.05 × 12% = 0.60%. 0.70 × 14% = 9.80%. Sum: 12.275%, or about 12.28%.

:answers 18
:a 18.p1 | 60,000 × (1 − 0.25) = Tk 45,000. The payment saves Tk 15,000 of tax.
:a 18.t1 | Lease P: 60,000 × 0.75 = Tk 45,000 a year; 45,000 × 2.600527 = Tk 117,024. Lease Q: 45,000 × 0.75 = Tk 33,750 in years 1 and 2, worth 33,750 × 1.795566 = Tk 60,600; year 3 hire 70,000 × 0.75 = Tk 52,500, worth 52,500 × 0.804961 = Tk 42,260; total about Tk 102,861. Lease Q is cheaper by about Tk 14,163.
:a 18.t2 | The minibus hired for one week is an operating lease. The six-year oven lease that cannot be cancelled is a financial lease. The press sold and leased back is a sale and leaseback.
:a 18.1 | The owner is the lessor and the puller is the lessee. A lease is a contract in which the owner of an asset lets another party use it in return for regular payments.
:a 18.2 | An operating lease is short or cancellable and the lessor keeps most risks, for example a scanner hired by the month. A financial lease is long and cannot be cancelled, and the lessee in effect carries the cost and risk of owning, for example a six-year oven lease.
:a 18.3 | 80,000 × (1 − 0.25) = Tk 60,000. The payment lowers taxable profit by Tk 80,000, which saves Tk 20,000 of tax.
:a 18.4 | First, find the after-tax cash outflow of leasing each year. Second, find the after-tax cash outflow of buying each year. Third, convert each outflow to a present value at the after-tax cost of debt and add. Fourth, compare the totals and choose the lower.
:a 18.5 | Discount rate = 8% × 0.75 = 6%. Lease: 100,000 × 0.75 = 75,000 a year; 75,000 × 2.673017 = about Tk 200,476. Buy: 70,000 ÷ 1.06 + 72,000 ÷ 1.1236 + 74,000 ÷ 1.191016 = about Tk 192,249. Buying costs about Tk 8,227 less, so buy.
