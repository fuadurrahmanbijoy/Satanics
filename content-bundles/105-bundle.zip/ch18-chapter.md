:chapter XVIII | Leasing
:mood Must a business own everything it uses?
:desc This chapter explains what a lease is, who the two parties are and how the two main kinds differ. It then shows how to compare leasing with buying by turning each year's after-tax cash outflow into a present value.
:plate ch18-plate.svg | A carriage-hire yard, where the owner and the hirer agree their terms

:box YOU WILL NEED
Chapter 17, "Long-Term Financing and the Cost of Capital", section 17.5 "The Cost of Capital", for the after-tax cost of debt; Chapter 8, "Capital Budgeting: Evaluation Techniques", section 8.2 "Net Present Value", for the method of discounting; Chapter 5, "Annuities", section 5.4 "Finding the Payment", for the payments on a loan.

> A traveller hires a cab and owns nothing, yet the work is done.

A visitor to London in the 1870s who wished to cross the city did not buy a carriage, a horse and a stable. He hired a cab for an hour, paid the driver and walked away owning nothing. The cab did his work as well as any carriage would have done. His neighbour, who crossed the city twice every day, took the opposite view and kept a carriage of his own.

> Hiring and owning differ in when the money is paid.

Both men were sensible. Their choices differed because their needs differed, and because the two roads carry different costs. Hiring is paid in small amounts as time passes. Owning is paid mostly at the start, and the owner must also meet repairs, idle days and the day when the carriage is worth less than before.

> A business meets the same puzzle with larger sums.

A modern business meets the same puzzle with larger sums. Meghna and Sons Limited needs a second machine. The seller wants Tk 780,000 now. Another business, one that owns machines in order to let others use them, offers the same machine for a payment at the end of each year. Which road costs less? To answer, we must compare payments made in different years, with tax changing each payment. You already own the tools for that task. This last chapter brings them together.

* * *

## 18.1 What a Lease Is

> A student who rents a room already knows the idea.

@ Rent | Word in use. In daily life, the money paid to live in a room or use a shop. In this chapter, the regular payment under a lease is called a lease payment.

Begin with something familiar. A student who rents a room pays the owner each month. The student may use the room but may not sell it, and must leave when the agreement ends. A lease follows the same pattern, applied to the assets of a business.

@ Lease | A contract in which the owner of an asset lets another party use it for regular payments.
> A lease lets one party use what another party owns.

A **lease** is a contract in which the owner of an asset lets another party use it in return for regular payments. A baker, for example, may lease an oven for five years instead of buying it. The baker uses the oven every day, but the oven stays the property of its owner.

@ Lessor | The owner who lets an asset out under a lease.
@ Lessee | The party who pays to use an asset under a lease.
> Every lease has two parties: the one who owns and the one who uses.

Every lease has two parties. The **lessor** is the owner who lets an asset out under a lease. The **lessee** is the party who pays to use the asset. In the cab story the cab owner is the lessor and the traveller is the lessee. Many students swap these two words, because they differ by one letter. The ending *-or* belongs to the one who does the letting; the ending *-ee* belongs to the one who receives the use.

> Several reasons lead a manager to lease instead of buy.

Why would a business lease? Consider the manager's viewpoint first. A new business may need a machine on its first day but lack the cash to buy it, and a lease asks for small payments instead of one large sum. A business may need an asset for a short time only. A business may also wish to keep its borrowing power for other uses, or may fear that the asset will become out of date before it wears out.

> The lessor has reasons too, and the tax rules matter.

Now consider the lessor. The lessor owns many assets of one kind, can buy them at a good price and knows how to resell them. The lessor earns a return from the payments. Tax rules matter as well, because in many countries the lease payment reduces the lessee's taxable profit, as section 18.3 shows. Rules differ from country to country, so this chapter uses the tax rate of 25% assumed for illustration in the Meghna and Sons case.^1

^1: Names and legal details of leasing contracts differ between countries. The ideas in this chapter are common to all of them.

> Leasing is not free, and resale value passes to the lessor.

Leasing has limits. The lessor must earn a return, so the payments over the whole lease usually add up to more than the price of the asset. The lessee must pay even if the asset is idle. When the lease ends, any resale value belongs to the lessor, not to the lessee. Leasing is therefore a different way of paying for use, not a cheaper way by nature. Section 18.3 shows how to test whether it is cheaper in a given case.

> Recap of section 18.1.

*Before moving on.* A lease lets a lessee use an asset owned by a lessor in return for regular payments. A business leases to save cash, to use an asset for a short time, or to share risk. Leasing is not free: the lessor must earn a return, and the lessee gives up any resale value.

## 18.2 Kinds of Lease

> Leases range from one day to many years; risk sorts them.

Leases range from a cab hired for an hour to a machine held for most of its working life. Two main kinds help us sort them, and both depend on one question: who carries the risks of owning the asset? These risks include repairs, damage and the chance that the asset becomes out of date.

@ Operating lease | A short or cancellable lease where the lessor keeps most of the risks of owning the asset.
> A short lease the user may cancel, with the owner holding the risk.

An **operating lease** is a short or cancellable lease where the lessor keeps most of the risks of owning the asset. A clinic that hires a portable scanner by the month, with the right to return it, holds an operating lease. The lessor pays for repairs and bears the risk that the scanner becomes out of date.

@ Financial lease | A long lease that cannot be cancelled, where the lessee in effect carries the cost and risk of owning.
> A long, fixed lease where the user bears the burden of owning.

A **financial lease** is a long lease that cannot be cancelled, in which the lessee in effect carries the cost and risk of owning. A bakery that signs for an oven for six years, with no right to leave early, holds a financial lease. The payments usually cover most of the oven's price plus the lessor's return, which is why the lessee in effect pays for the asset.

> The table sets the two kinds side by side on four features.

The two kinds are easier to remember side by side. The table below compares them on four features. Read each row from left to right: the feature, then how an operating lease treats it, then how a financial lease treats it.

:table Operating lease and financial lease compared
| Feature | Operating lease | Financial lease |
| Length | Short, often well below the asset's working life | Long, close to the asset's working life |
| Cancellation | Usually allowed | Not allowed |
| Repairs and risk of becoming out of date | Mostly with the lessor | Mostly with the lessee |
| Typical use | Cabs, copiers, scanners for a short need | Machines and vehicles kept for years |

> The lease-or-buy test fits financial leases best.

The five-year lease offered to Meghna and Sons is treated here as a financial lease. The comparison with buying in section 18.3 suits financial leases best. An operating lease also gives the lessee a service, such as repairs, so a comparison of cost alone would leave out part of what is bought.

@ Sale and leaseback | Selling an asset to a lessor and at once leasing it back.
> Selling an asset and leasing it back turns it into cash.

A third arrangement is a **sale and leaseback**, which means selling an asset to a lessor and at once leasing it back. A baker who owns a delivery van may sell it to a lessor for cash and then lease the same van back. The business receives cash today and keeps using the van, but it now makes lease payments for as long as it needs the van.

> Accounting rules change the records, not the contract.

Accounting rules affect how a lease appears in a business's records, but they do not change what the contract is.^2 The risk question stays useful, because it still tells us who bears the burden of owning.

^2: Under International Financial Reporting Standard 16, which applies to reporting periods beginning on or after 1 January 2019, a lessee records most leases as an asset and a liability. Standards differ by place.

> Recap of section 18.2.

*Before moving on.* An operating lease is short, can be cancelled and leaves most risk with the lessor. A financial lease is long, cannot be cancelled and leaves most risk with the lessee. A sale and leaseback turns an owned asset into cash while the business keeps using it.

## 18.3 The Lease or Buy Decision

> The question: which road costs the business less?
> Recall: net present value, Chapter 8, section 8.2 "Net Present Value".

Suppose a business has decided that it needs a machine. The investment decision is made. One question remains: should the business lease the machine, or buy it with money borrowed from a bank? The answer cannot come from adding the payments, because a taka paid in year five is worth less today than a taka paid in year one. The answer must come from present values, using the method of net present value.

@ After-tax cash outflow | Cash paid out in a year after taking away the tax saved by that payment.
> Tax saved lowers the true cost of each payment.

Tax changes each payment, so we need one more idea. The **after-tax cash outflow** is the cash paid out in a year after taking away the tax saved by that payment. Suppose a lease payment is Tk 100 and the tax rate is 25%. The payment lowers taxable profit by Tk 100, so tax falls by Tk 25, and the after-tax cash outflow is Tk 75.

:pause 18.p1 | A lease payment is Tk 60,000 and the tax rate is 25%. What is the after-tax cash outflow?

> For leasing, the whole payment is a deduction.

For leasing, the rule is direct. The lessee deducts the whole lease payment from taxable profit. In words: the after-tax cash outflow of leasing equals the lease payment multiplied by one minus the tax rate.

> Buying with a loan has two tax savings; repayment of the loan is not one.

For buying with a loan, the rule needs more care. Each yearly instalment repays part of the loan and pays interest. Only the interest is deducted from taxable profit. The business may also deduct depreciation each year, although depreciation is not a cash payment. Many students find this step confusing, because the instalment is cash but depreciation is not. The explanation is that depreciation sends no cash out, yet it lowers the tax bill, so it still leaves the business with more cash. The after-tax cash outflow of buying therefore equals the instalment minus the tax rate multiplied by the sum of interest and depreciation.

> Recall: after-tax cost of debt, Chapter 17, section 17.5 "The Cost of Capital".
> The discount rate is the after-tax cost of borrowing.

Which discount rate should we use? Both streams are fixed by contract, so they carry about the same risk as a loan. The fitting rate is therefore the after-tax cost of debt: the interest rate multiplied by one minus the tax rate. At an interest rate of 10% and tax of 25%, this is 10% × 0.75 = 7.5%.

> Recall: loan payments, Chapter 5, section 5.4 "Finding the Payment".
> Four steps make the decision orderly.

The decision follows four steps. First, find the after-tax cash outflow of leasing in each year. Second, find the after-tax cash outflow of buying in each year, using the loan payments of Chapter 5. Third, convert each year's outflow into a present value at the after-tax cost of debt, and add. Fourth, compare the two totals: the lower total is the cheaper road. If the machine can be sold at the end, subtract the present value of the after-tax sale proceeds from the total for buying.

> A resale value would lower the cost of buying.

A resale value changes the comparison, so we note it now. Suppose, in a different case, that a machine can be sold for Tk 10,000 at the end of year 5, with no tax on the sale. That sum reaches the business only if it owns the machine. Its present value at 7.5% is 10,000 × 0.696559 = Tk 6,966, and this amount is subtracted from the present value of buying. The lessor, who keeps the machine, receives the resale value, which is one reason a lessor can offer a lease at all.

> The test counts cost only, so a close result needs more thought.

The test has limits. It counts cost only. It does not weigh the service that an operating lease may include, the risk of the asset becoming out of date, or the chance that the lessee earns no profit against which to deduct the payments. When the gap is small, such as two or three per cent, the manager should weigh these other facts before choosing.

> Recap of section 18.3.

*Before moving on.* The lease-or-buy decision compares present values of after-tax cash outflows at the after-tax cost of debt. Leasing deducts the whole payment; buying deducts interest and depreciation. The lower present value wins, if cost is all that matters.

* * *

## Worked Example: Lease or Buy the Second Machine

> We learn the method on small numbers first, with no tax.

We first practise the method on small, clean numbers with no tax, and then repeat it on the case file.

> A bicycle example in the standard order.

*Given.* A delivery bicycle can be leased for Tk 4,000 at the end of each of 2 years, or bought now for Tk 7,000. There is no tax and no resale value. The discount rate is 10%. *Find.* The cheaper road. *Formula.* Present value is each payment divided by one plus the rate, once for every year of waiting. In symbols: PV = P₁ ÷ (1 + r) + P₂ ÷ (1 + r)², where P is a payment and r is the discount rate. *Steps.* 4,000 ÷ 1.10 = Tk 3,636.36. 4,000 ÷ 1.21 = Tk 3,305.79. The sum is Tk 6,942.15. Buying costs Tk 7,000.00 today. *Answer.* Leasing is cheaper by Tk 57.85. *Check.* The lease payments add to Tk 8,000, more than Tk 7,000, yet the second payment is worth less today, so a lower present value is sensible.

> Recall: loan payments, Chapter 5, section 5.4 "Finding the Payment".
> The case file gives every figure for the second machine.

:case Case file, illustrative. 3 December 2025. Meghna and Sons Limited needs a second machine costing Tk 780,000. *Given.* The lease asks Tk 210,000 at each year end for 5 years. To buy, the business borrows Tk 780,000 at 10% a year and repays it in 5 equal year-end instalments of Tk 205,762.04. Depreciation is Tk 156,000 a year, and no resale value is assumed. Tax is 25%, assumed for illustration only. The discount rate is the after-tax cost of debt, 7.5%.

> Find: the present value of each road, and the cheaper one.

*Find.* The present value of leasing and of buying, and the lower of the two. *Formula.* In words: the after-tax outflow of leasing is the lease payment times one minus the tax rate; the after-tax outflow of buying is the instalment minus the tax rate times interest plus depreciation; the present value is the sum of each year's outflow divided by one plus the rate for each year of waiting. In symbols: L = P × (1 − T); B = I − T × (X + D); PV = C₁ ÷ (1 + r) + C₂ ÷ (1 + r)² + … + C₅ ÷ (1 + r)⁵. Here L and B are the after-tax outflows of leasing and buying, P is the lease payment, T the tax rate, I the instalment, X the interest in the year, D the depreciation, C the outflow in a year and r the discount rate.

> Step 1 finds the lease outflow; step 2 finds the interest each year.

*Steps.* Step 1, leasing: 210,000 × (1 − 0.25) = Tk 157,500 in each of the 5 years. Step 2, buying: the interest in year 1 is 10% × 780,000 = Tk 78,000. The instalment of Tk 205,762.04 repays Tk 127,762.04 of the loan, leaving Tk 652,237.96 owed, so year 2 interest is 10% × 652,237.96 = Tk 65,223.80. The same method gives the later years. The table that follows is read across each row: the year, the interest, the tax saved (25% of interest plus Tk 156,000 of depreciation) and the after-tax outflow, which is the instalment minus the tax saved.

:table After-tax outflow of buying, in taka to the nearest taka
| Year | Interest | Tax saved | After-tax outflow |
| 1 | 78,000 | 58,500 | 147,262 |
| 2 | 65,224 | 55,306 | 150,456 |
| 3 | 51,170 | 51,792 | 153,970 |
| 4 | 35,711 | 47,928 | 157,834 |
| 5 | 18,706 | 43,676 | 162,086 |

> Step 3 converts each outflow to a present value at 7.5%.

Step 3, present values at 7.5%. Leasing is an ordinary annuity, so the 5-year annuity factor of 4.045885 applies: 157,500 × 4.045885 = Tk 637,227. For buying, each year's outflow is multiplied by its present value factor: 147,262 × 0.930233 = 136,988; 150,456 × 0.865333 = 130,195; 153,970 × 0.804961 = 123,940; 157,834 × 0.748801 = 118,186; 162,086 × 0.696559 = 112,902. The present values add to Tk 622,210; the yearly figures here are rounded, so their sum can differ from this total by a taka.

> The figure shows the two outflow streams side by side.

Figure 1 draws the two streams. To read it, look at one row at a time: each bar is one year's after-tax outflow, and a taller bar means more cash paid out that year. The top row, with line hatching, is leasing; the bottom row, with cross hatching, is buying. Bars above one another belong to the same year.

:fig Yearly after-tax outflows of leasing and of buying, aligned by year | ch18-fig01.svg

> Answer and check: buying is cheaper by about Tk 15,000.

*Answer.* Leasing has a present value of Tk 637,227 and buying has Tk 622,210. Buying costs Tk 15,017 less, so on cost alone the business should buy. *Check.* The five outflows of leasing add to Tk 787,500 and those of buying to Tk 771,608, so buying is lower before and after discounting; the sign of the answer is sensible. The gap is about 2.4% of the lease figure, which is small, so other facts could change the choice.

> The owners' viewpoint: a lower cost adds to the value of the business.

From the owners' viewpoint, the saving of Tk 15,017 is a gain in present value, because the same machine does the same work for less. The lender's viewpoint differs: buying with a loan adds Tk 780,000 of debt, while leasing adds no loan but does add a fixed promise to pay each year. A manager should weigh that fixed promise before signing either contract.

> Common slips: wrong deduction, forgotten depreciation, wrong rate or period.

Common slips are these. Deducting tax on the whole instalment wrongly treats loan repayment as a tax saving. Leaving out depreciation overstates the cost of buying. Discounting at the loan rate of 10% instead of 7.5% mixes a before-tax rate with after-tax cash. Placing the year-5 payment in year 4 mixes up the periods.

* * *

## Summary

> The chapter in a few lines.

A lease is a contract in which a lessor lets a lessee use an asset in return for regular payments. An operating lease is short and leaves risk with the lessor; a financial lease is long and leaves risk with the lessee. To choose between leasing and buying, find each year's after-tax cash outflow, convert it to a present value at the after-tax cost of debt, and choose the lower total. For the second machine of Meghna and Sons Limited, buying costs Tk 15,017 less in present value.

## Think It Through

:q 18.t1 | A clinic needs a scanner for 3 years. Lease P asks Tk 60,000 at each year end for 3 years. Lease Q asks Tk 45,000 at each year end for 2 years, after which the clinic must hire a scanner for the third year at Tk 70,000. Tax is 25% and the discount rate is 7.5%. Which is cheaper in present value?
:q 18.t2 | Name the kind of arrangement in each case: a school hires a minibus for one week; a bakery signs a six-year lease of an oven that cannot be cancelled; a printer sells its press to a lessor and leases it back.

## Where People Go Wrong

> Wrong idea: leasing is cheaper because no cash is paid at the start.

*Wrong:* leasing is cheaper because no large sum is paid at the start. *Correct:* the lessor must earn a return, so total payments usually exceed the price. Only a present value comparison shows which road costs less.

> Wrong idea: tax applies to the whole loan instalment.

*Wrong:* the tax saved on buying is the tax rate times the whole instalment. *Correct:* only interest and depreciation reduce taxable profit; the part of the instalment that repays the loan does not.

> Wrong idea: the lessee owns the asset at the end of a lease.

*Wrong:* the lessee owns the asset when the lease ends. *Correct:* the asset stays with the lessor unless the contract says otherwise, which is why this chapter assumes no resale value for the lessee.

> Wrong idea: the two kinds of lease are defined by length alone.

*Wrong:* the difference between the two kinds of lease is only length. *Correct:* length matters, but the key question is who carries the risks of owning the asset.

## In History

> Leasing is old, but the lease business is modern.

Some historians trace leasing to the ancient Near East, around 2000 BC, when owners let farm tools to farmers under written agreements. In 1877 the Bell Telephone Company began to let telephones to customers instead of selling them. The United States Leasing Corporation, formed in San Francisco in 1952, is usually named as the first business to treat equipment leasing as its main work. Leasing then spread to Europe in the late 1950s and early 1960s, helped in the United States by tax rules that favoured it.

> Why leasing grew: scarce credit and favourable tax rules.

Why did leasing grow so fast? One reason, in the United States, was a shortage of medium-term credit, which left businesses wanting machines they could not pay for at once. Another was the tax treatment of lease payments and depreciation, which differs from country to country and can favour the lessor, the lessee or both. Banks and manufacturers later formed their own leasing businesses. A lease is therefore both a way of financing and a way of sharing tax savings, which is why the comparison in this chapter always counts tax.

## Review Questions

:q 18.1 | A rickshaw owner lets a puller use a rickshaw each day for an agreed payment under a contract. Name the lessor and the lessee, and say what a lease is.
:q 18.2 | Explain the difference between an operating lease and a financial lease, with one example of each.
:q 18.3 | A lease payment is Tk 80,000 a year and the tax rate is 25%. Find the after-tax cash outflow and say why it is lower than the payment.
:q 18.4 | State the four steps of the lease-or-buy decision in order.
:q 18.5 | A clinic can lease a scanner for Tk 100,000 at each year end for 3 years, or buy it with a loan. The after-tax outflows of buying are Tk 70,000, Tk 72,000 and Tk 74,000. The loan interest rate is 8% and the tax rate is 25%. Find the discount rate and the present value of each road, then decide.

:read Richard A. Brealey, Stewart C. Myers and Franklin Allen, Principles of Corporate Finance, 2020
