:chapter IX | Return and Risk
:mood Which is the better bet: a small sure gain, or the chance of a large one?
:desc This chapter shows how to state what an investment pays and how uncertain that payment is. You will describe a gain as a percentage, list the outcomes that might happen, find their average and measure how widely they scatter. Meghna and Sons uses these tools to compare two product lines.
:plate ch09-plate.svg | An underwriter weighs the dangers of a sea voyage

> Two jobs, one certain and one uncertain: which would you take?

Imagine that you are offered two jobs selling books at a fair. The first pays Tk 12,000 every month, whatever happens. The second pays Tk 2,000 in a poor month, Tk 14,000 in an ordinary month and Tk 26,000 in a busy month, and nobody can tell you in advance which kind of month will come. Which job would you take?

> Neither choice is foolish, because the question is about how much uncertainty you will accept.

Many people choose the first job, although the second pays more over a long run of months. Others choose the second. Both groups answer a question that the amount of money cannot settle alone: how much uncertainty will you accept for the chance of a larger gain? A business meets the same question each time it buys stock, borrows money or starts a project.

> This chapter gives three tools: a way to state a gain, a way to describe uncertainty, and a way to compare choices.

Three smaller questions follow from the puzzle. How do we state what an investment pays, in one number that can be compared? How do we describe uncertainty in numbers rather than in feelings? How do we compare two choices when one pays more and also varies more? By the end of the chapter you will answer each question with a figure that you can calculate by hand.

> The chapter relies on one earlier idea, required return, from Chapter 8.

You will need the idea of required return from Chapter 8, 'Capital Budgeting: Evaluation Techniques', section 8.2 'Net Present Value'. Required return is the least return that makes a project worth accepting. Here we learn to measure the returns that are compared with it.

* * *

## 9.1 What Return Is

> Money put to work earns a gain or suffers a loss, and we need a name for it.

Suppose you lend Tk 1,000 to a cousin, who repays Tk 1,100 after one year. You have gained Tk 100. Suppose instead that you buy a goat for Tk 1,000 and sell it a year later for Tk 900. You have lost Tk 100. In both cases you placed funds in something and later counted the result.

@ Return | the total gain or loss from an investment over a period, income plus any change in value

@ Return | Word in use. In daily life, to give back or to come back. In finance, the gain or loss from an investment.

> Return is everything gained or lost on an investment during a period.

Finance gives the name **return** to this result. Return means everything you gain or lose from an investment in a period: the payments you receive, plus any rise or fall in its price. An *investment* is money placed in something in the hope of gain. If a bond pays Tk 60 in interest and its price rises by Tk 40, the return is Tk 100.

> Return as an amount cannot be compared between investments of different size.

A return stated in taka has a weakness. A return of Tk 100 is large on an investment of Tk 500 and small on an investment of Tk 50,000. To compare fairly, we scale the return by the size of the investment.

@ Rate of return | the return shown as a percentage of the amount first invested

> Rate of return divides the return by the amount first invested.

The **rate of return** is the return shown as a percentage of the amount first invested. In words: rate of return equals return divided by amount first invested, multiplied by 100. In symbols, with R for the return and P for the amount first invested, the rate is (R ÷ P) × 100%. The Tk 100 gained on the loan of Tk 1,000 is a rate of return of 10%.

> The case file gives the first full example of both ideas.

:case Case file, illustrative. Meghna and Sons, 2 March 2025. A savings bond bought for Tk 100,000 pays Tk 6,000 interest in the year and could be sold at Tk 104,000. Return = Tk 6,000 + (Tk 104,000 − Tk 100,000) = Tk 10,000. Rate of return = Tk 10,000 ÷ Tk 100,000 = 0.10, or 10%.

> The same example set out in the standard order shows each step.

*Given.* Amount first invested Tk 100,000; interest received Tk 6,000; price at the end of the year Tk 104,000. *Find.* The return and the rate of return. *Formula.* Return equals income received plus the change in value, where the change in value is the end price less the start price. *Steps.* The change in value is 104,000 − 100,000 = Tk 4,000. The return is 6,000 + 4,000 = Tk 10,000. The rate is 10,000 ÷ 100,000 × 100% = 10%. *Answer.* The bond gave a return of Tk 10,000, a rate of return of 10% for the year. *Check.* Ten percent of Tk 100,000 is Tk 10,000, so the two answers agree.

> Return can be negative, depends on the period and may exist only on paper.

Three limits deserve care. First, a return can be negative: if the bond could be sold only at Tk 96,000, the change in value would be −Tk 4,000 and the return would be Tk 2,000. Second, a rate means little unless the period is stated, so we say "10% a year". Third, an unsold gain is a gain on paper only, because the price may change before the sale. Different people also read return differently: the owner sees a reward for waiting, the financial manager sees a figure to set against the required return, and a lender sees only the interest.

> The section's two ideas are return and rate of return.

*Before moving on.* Return is the total gain or loss over a period, income plus any change in value. The rate of return divides it by the amount first invested, so that investments of different size can be compared.

* * *

## 9.2 What Risk Is

@! Go slowly here.

> Two routes with the same average time still feel different.

You can walk to a shop by two routes. On average each takes 25 minutes. Route A takes between 20 and 30 minutes, whatever the day. Route B takes 10 minutes on a quiet day and 40 minutes when the traffic is heavy. If you must catch a bus at a fixed hour, which route do you choose? Most people choose route A, although the averages are equal. The difference between the routes is not the average. It is the uncertainty of the arrival time.

@ Risk | the chance that actual results differ from those expected, especially for the worse

@ Risk | Word in use. In daily life, the danger of harm, such as the risk of a fall. In finance, the chance that results differ from what was expected.

> Risk is the chance that results differ from what was expected, especially for the worse.

Finance gives the name **risk** to this uncertainty. Risk means the chance that actual results will differ from those we expected, especially for the worse. A savings bond that pays a fixed amount has very little risk. A shop that hopes to sell Tk 7,200,000 of books in a year, but may sell less, has more. The word does not mean certain loss. A certain loss has no uncertainty, so it carries no risk.

> The more widely the possible results are scattered, the greater the risk.

How do we recognise more risk? Look at the possible results. If every possible result lies close to the expected one, the risk is small. If some results lie far above and others far below, the risk is large. Route B has more risk than route A for exactly this reason. The rest of this chapter turns that idea into numbers.

> The reader gains a plain test for the amount of risk.

*Test.* To judge the risk of a choice, ask how far the actual result could fall from the expected result, and how likely that is. A choice whose results all lie near the expected one has low risk.

> People bear risk only when they expect something in return.

The puzzle at the start of the chapter shows why risk matters to a business. Owners and lenders can place their funds in safe or in uncertain uses. They accept the uncertain use only if they expect a higher return. This link between a higher expected return and greater risk is the main idea of Chapter 10, 'Risk, Required Return and Market Efficiency'. Here we must first learn how to measure each side.

> Risk has more than one source, and two sources matter most to a business.

A business meets risk from two different directions. The first comes from the work it does. The second comes from the way it pays for that work.

@ Business risk | the risk that operating profit varies because of sales, costs and trade conditions

> Business risk comes from the trade itself.

**Business risk** is the risk that operating profit varies because of sales, costs and trade conditions. A bookshop shows the idea. Sales rise before school terms and fall in the holidays. A rival may open nearby, and the price of paper may rise. Every business in the same trade shares these dangers, whatever the way it is funded. Business risk grows when a business has many fixed operating costs, such as rent, which must be paid even when sales are poor. Chapter 11, 'Operating Leverage and Break-even Analysis', section 11.1 'Fixed and Variable Costs', teaches this link.

@ Financial risk | the extra risk to owners that comes from funding part of a business by borrowing

> Financial risk comes from borrowing.

**Financial risk** is the extra risk to owners that comes from funding part of a business by borrowing. Suppose a bookshop borrows Tk 600,000 at 10% a year. The interest is Tk 60,000 every year, in a busy year and in a poor one. After the interest is paid, what remains for the owners rises and falls more sharply than operating profit does. Chapter 12, 'Financial and Total Leverage', section 12.1 'Borrowing and Fixed Financing Charges', teaches this link in full.

> The two kinds differ in cause and in who bears the extra risk.

:table How the two kinds of risk differ
| Point | Business risk | Financial risk |
| Source | Sales, costs and trade conditions | Borrowing, which brings fixed interest |
| Who meets it | Every business in the trade | Owners of a business that borrows |
| Can the business avoid it? | Not by changing its funding | Yes, by borrowing less |

> To read the table, move along a row and compare the two columns.

Read each row from left to right. In the first row the source differs: the trade creates one kind and borrowing creates the other. In the last row the difference is choice: the owners decide how much to borrow, but they cannot choose the conditions of the trade.

> The section ends with a recap and a test sentence.

*Before moving on.* Risk is the chance that results differ from those expected, especially for the worse. Business risk comes from the trade, and financial risk comes from borrowing. *You should now be able to say* what risk means in finance, and why a certain loss is not risk.

* * *

## 9.3 Describing Uncertain Outcomes

@! Go slowly here.

> A list of possible outcomes needs a number for how likely each one is.

Return to the two routes. On any day the traffic is clear, usual or heavy, and we cannot know which in advance. We can say how often each one happens. Suppose that over 100 days the traffic is heavy on 25 of them. Then heavy traffic has a chance of 25 in 100. Finance writes such a chance as one number.

@ Probability | a number from 0 to 1 showing how likely an outcome is

> Probability puts a chance on a scale from 0 (cannot happen) to 1 (certain).

**Probability** is a number from 0 to 1 showing how likely an outcome is. Zero means the outcome cannot happen, and one means it is certain. A fair coin landing heads has a probability of 0.5. Heavy traffic on 25 days in 100 has a probability of 25 ÷ 100 = 0.25.

@ Probability distribution | a list of possible outcomes with the probability of each, adding up to one

> A probability distribution lists every possible outcome with its probability.

A **probability distribution** is a list of possible outcomes with the probability of each, adding up to one. The probabilities add up to one because exactly one of the outcomes must happen. The distribution for route B is: 10 minutes with probability 0.25, 25 minutes with 0.50, and 40 minutes with 0.25. The sum is 0.25 + 0.50 + 0.25 = 1.00.

:pause 9.p1 | A list of outcomes gives probabilities of 0.2, 0.5 and 0.4. Is it a probability distribution? Say why.

> Probabilities come from records or from judgement, so they are estimates.

Where do probabilities come from? A business may use its past records or the judgement of people who know the trade. Either way they are estimates, not promises. A careful manager states them openly so that other people can question them.

> A whole distribution needs to be summed up in one number.

Three outcomes with three probabilities are hard to compare with another set. We want one number that sums up the whole distribution: the average outcome. The plain average of 10, 25 and 40 minutes treats each outcome as equally likely, which is wrong, because 25 minutes happens twice as often as each of the others. We must weight each outcome by its probability.

@ Expected value | the average outcome, weighting each outcome by its probability

> Expected value multiplies each outcome by its probability and adds the products.

**Expected value** is the average outcome, weighting each outcome by its probability. In words: multiply each outcome by its probability, then add the products. In symbols, with x for an outcome and p for its probability, expected value = (p₁ × x₁) + (p₂ × x₂) + (p₃ × x₃). Many students find this idea confusing, because *expected* sounds like a prediction. It is a weighted average and promises nothing about any one day.

> The table sets out the weighted calculation for both routes, one row for each kind of day.

:table Expected time of two routes
| Traffic | Probability | Route A minutes | p × minutes | Route B minutes | p × minutes |
| Clear | 0.25 | 20 | 5.0 | 10 | 2.5 |
| Usual | 0.50 | 25 | 12.5 | 25 | 12.5 |
| Heavy | 0.25 | 30 | 7.5 | 40 | 10.0 |
| Total | 1.00 | | 25.0 | | 25.0 |

> The worked steps repeat the table in the standard order.

*Given.* The distributions of the two routes in the table. *Find.* The expected time of each route. *Formula.* Expected value equals the sum of probability × outcome. *Steps.* Route A: 0.25 × 20 = 5.0; 0.50 × 25 = 12.5; 0.25 × 30 = 7.5; the sum is 25.0 minutes. Route B: 0.25 × 10 = 2.5; 0.50 × 25 = 12.5; 0.25 × 40 = 10.0; the sum is 25.0 minutes. *Answer.* Both routes have an expected time of 25 minutes. *Check.* An expected value must lie between the smallest and the largest outcome: 25 lies between 20 and 30, and between 10 and 40.

> Expected value is a long-run average, and it need not be an outcome that can happen.

Two limits matter. First, the expected value is the average over many repeats, not a forecast for one day. A coin that pays Tk 0 or Tk 10 with equal probability has an expected value of Tk 5, which can never be paid on one toss. Second, the answer is only as good as the probabilities. Common slips are probabilities that do not add up to one, and a plain average used in place of the weighted one.

> The section's ideas are probability, the distribution and the expected value.

*Before moving on.* A probability is a number from 0 to 1. A probability distribution lists the outcomes with their probabilities, which add up to one. The expected value weights each outcome by its probability. *You should now be able to say* what an expected value is and why both routes have the same one.

* * *

## 9.4 Measuring the Spread of Outcomes

@! Go slowly here.

> Equal expected values hide the difference between the two routes.

The routes have the same expected time, yet we chose route A. The difference lies in how far the outcomes lie from 25 minutes. Route A never misses by more than 5 minutes, while route B misses by 15. To measure risk we need a number for this scatter.

@ Spread | Word in use. In daily life, to cover a surface thinly, such as butter on bread. In finance, how far outcomes lie from the expected value.

@ Standard deviation | a measure of how widely outcomes spread around the expected value

> Standard deviation measures the typical distance of outcomes from the expected value.

The **standard deviation** is a measure of how widely outcomes spread around the expected value. A small standard deviation means the outcomes huddle near the expected value. A large one means they lie far from it. We build it in four small steps, each in plain arithmetic.

> The four steps turn distances into one number.

*Step one:* find each outcome's deviation, which is the outcome less the expected value. *Step two:* square each deviation, because some are below the expected value and some above, and without squaring they would cancel to zero. *Step three:* multiply each squared deviation by its probability and add the results; this total is called the variance. *Step four:* take the square root, which returns the answer to the units of the outcomes. In symbols, standard deviation = √[ sum of p × (x − expected value)² ].

> The table works through the four steps for both routes.

:table Standard deviation of two routes (expected time 25 minutes)
| Traffic | Probability | A: deviation | A: p × deviation² | B: deviation | B: p × deviation² |
| Clear | 0.25 | −5 | 6.25 | −15 | 56.25 |
| Usual | 0.50 | 0 | 0.00 | 0 | 0.00 |
| Heavy | 0.25 | +5 | 6.25 | +15 | 56.25 |
| Total (variance) | 1.00 | | 12.50 | | 112.50 |

> Each deviation is squared, weighted, added and then the root is taken.

*Given.* The distributions and the expected time of 25 minutes. *Find.* The standard deviation of each route. *Steps.* Route A: (−5)² = 25, weighted 0.25 × 25 = 6.25, twice, so the variance is 12.50 and the square root is 3.54 minutes. Route B: (−15)² = 225, weighted 0.25 × 225 = 56.25, twice, so the variance is 112.50 and the square root is 10.61 minutes. *Answer.* Route A has a standard deviation of 3.54 minutes, route B 10.61 minutes. *Check.* Route B's deviations are three times larger than route A's, and 10.61 is about three times 3.54.

:pause 9.p2 | Why does the calculation square each deviation before adding?

> The figure shows the spread as the width of a bell-shaped outline.

To read the next figure, look at the horizontal line: it shows the possible outcomes, from low to high. The height of an outline above any point shows how likely outcomes near that point are. Both outlines are centred on the same expected value, marked by the dashed vertical line. The narrow outline is tall because most outcomes lie near the centre. The wide outline is low because the outcomes are scattered far from it.

:fig Two sets of outcomes with the same expected value but different spread | ch09-fig02.svg

> Standard deviation has a limit when the expected values of two choices differ.

Standard deviation is stated in the units of the outcomes, so it fits a comparison only when the expected values are equal. A standard deviation of Tk 8,000 is small beside an expected value of Tk 500,000 and large beside one of Tk 10,000. We need risk for each unit of return.

@ Coefficient of variation | the standard deviation divided by the expected value, showing risk for each unit of return

> The coefficient of variation divides the standard deviation by the expected value.

The **coefficient of variation** is the standard deviation divided by the expected value, showing risk for each unit of return. In symbols, coefficient of variation = standard deviation ÷ expected value. For route A it is 3.54 ÷ 25 = 0.14, and for route B it is 10.61 ÷ 25 = 0.42. A larger figure means more risk for each unit of the expected result. The coefficient cannot be used when the expected value is zero or negative.

> The section ends with a recap and a test sentence.

*Before moving on.* The standard deviation measures spread around the expected value in four steps: deviate, square, weight and add, then take the root. The coefficient of variation divides it by the expected value so that choices of different size can be compared. Common slips are forgetting the root and forgetting to weight by probability. *You should now be able to say* what the standard deviation measures and why we divide it by the expected value.

* * *

## Worked Case: Two Product Lines

> Meghna and Sons compares two product lines, using every tool of the chapter.

The case file gives the facts. We will find the expected value, the standard deviation and the coefficient of variation for each line, and then judge.

> The case file gives the trade states, their probabilities and the returns of each line.

:case Case file, illustrative. Meghna and Sons, 2 March 2025. Two product lines are compared on Tk 100,000 invested in each. Trade is slow with probability 0.25, normal with probability 0.50 and busy with probability 0.25. Study guides return 9%, 12% and 15% in those states. Art supplies return 2%, 14% and 26%.

> The figure shows the returns of each line in each kind of trade.

To read the figure, look at the three groups of bars: slow, normal and busy trade. In each group, the left bar is study guides and the right bar is art supplies. The height of a bar is the return in that kind of trade, and the label under the group gives its probability.

:fig Returns of two product lines in slow, normal and busy trade | ch09-fig01.svg

> The first step weights each return by its probability.

*Given.* The distributions above. *Find.* The expected value, standard deviation and coefficient of variation of each line. *Steps for expected value.* Study guides: 0.25 × 9 = 2.25; 0.50 × 12 = 6.00; 0.25 × 15 = 3.75; the sum is 12%. Art supplies: 0.25 × 2 = 0.50; 0.50 × 14 = 7.00; 0.25 × 26 = 6.50; the sum is 14%.

> The second step finds the spread of each line around its own expected value.

*Steps for standard deviation.* Study guides: the deviations are −3, 0 and +3. The squares are 9, 0 and 9. Weighted: 2.25 + 0 + 2.25 = 4.50, the variance. The square root is 2.12%. Art supplies: the deviations are −12, 0 and +12. The squares are 144, 0 and 144. Weighted: 36 + 0 + 36 = 72, the variance. The square root is 8.49%.

> The third step divides each spread by its expected value and a judgement follows.

*Steps for the coefficient.* Study guides: 2.12 ÷ 12 = 0.18. Art supplies: 8.49 ÷ 14 = 0.61. *Answer.* Art supplies have the higher expected return, 14% against 12%, and much more risk for each unit of return, 0.61 against 0.18. *Check.* Art supplies' deviations are four times as large as those of study guides, and 8.49 is about four times 2.12. Whether the extra return is worth the extra risk depends on the required return and on how much risk the owners will accept.

> A reshaped case tests the same method on takings in taka.

*Reshaped case.* Two market stalls have weekly takings with the same probabilities, 0.25, 0.50 and 0.25. Stall X takes Tk 8,000, Tk 10,000 or Tk 12,000. Stall Y takes Tk 6,000, Tk 12,000 or Tk 18,000. Stall X: expected value 2,000 + 5,000 + 3,000 = Tk 10,000; deviations ±2,000; variance 0.25 × 4,000,000 × 2 = 2,000,000; standard deviation Tk 1,414; coefficient 0.14. Stall Y: expected value 1,500 + 6,000 + 4,500 = Tk 12,000; deviations ±6,000; variance 0.25 × 36,000,000 × 2 = 18,000,000; standard deviation Tk 4,243; coefficient 0.35. Stall Y takes more and carries more risk for each taka.

> A combined case ranks three assets by average outcome, spread and spread per unit of return.

*Combined case.* Three assets have expected values and standard deviations as shown. The table introduces them in a row each, with the coefficient calculated as standard deviation ÷ expected value.

:table Three assets compared
| Asset | Expected value | Standard deviation | Coefficient of variation |
| P | 8% | 2% | 0.25 |
| Q | 15% | 6% | 0.40 |
| R | 11% | 5.5% | 0.50 |

> Asset Q has the highest return, and asset R has the most risk for each unit of return.

Read each row across. Q has the highest expected value. P has the lowest risk for each unit of return, at 0.25. R has the highest, at 0.50, yet its expected value lies below Q's, so R is the weakest choice of the three on both counts.

* * *

## Summary

> The chapter's tools are return, risk, probability, expected value, standard deviation and the coefficient of variation.

Return is the gain or loss on an investment, and the rate of return scales it by the amount invested. Risk is the chance that results differ from those expected. A probability distribution lists outcomes with probabilities adding to one. The expected value is its weighted average, the standard deviation measures the spread around it, and the coefficient of variation shows the risk for each unit of return.

## Think It Through

:q 9.t1 | Project X has an expected value of Tk 50,000 and a standard deviation of Tk 10,000. Project Y has an expected value of Tk 80,000 and a standard deviation of Tk 24,000. Which carries more risk for each unit of return? Show the figures.

## Where People Go Wrong

> A common error is to think that risk means a loss.

*Error:* "Risk is the chance of losing money." Risk is the chance that results differ from those expected. A result better than expected is also a difference, and the standard deviation counts it. A certain loss carries no risk at all.

> A second error is to treat the expected value as a forecast.

*Error:* "The expected value is what will happen." It is a weighted average over many repeats. In one trial the actual result may differ widely, and may never equal the expected value.

> A third error is to compare standard deviations when the expected values differ.

*Error:* "The line with the smaller standard deviation is the safer one." A smaller standard deviation is safer only when the expected values are equal. When they differ, compare the coefficients of variation. Also check that the probabilities add up to one, and do not forget the square root.

## In History

> Merchants who shared the risk of ships began the great insurance market of London.

Edward Lloyd kept a coffee house in Tower Street, in the City of London near the River Thames. The London Gazette first mentioned it in 1688. Lloyd did not insure ships himself. He provided premises and reliable news of shipping, and the ship owners, merchants and captains who met there arranged insurance among themselves.^1 Each wealthy person took a share of the risk of a ship and its cargo, and signed his name beneath the policy with the amount he would cover. For this reason such people were called underwriters. No single storm could ruin one of them, because each had placed only a part of the cargo at risk.

> Harry Markowitz was the first to measure investment risk by spread.

In 1952 Harry Markowitz, an American economist, published a paper called "Portfolio Selection". He measured the risk of an investment by the spread of its returns around their expected value, which is the idea of this chapter, and he showed that investors should weigh expected return against spread.

^1: The date 1688 is the first recorded mention of the coffee house. Its exact opening date is not known.

## Sources

> The landmark works behind the chapter are Knight, 1921, and Markowitz, 1952.

Frank Knight, in *Risk, Uncertainty and Profit* (1921), argued that profit is the reward for bearing uncertainty, and he separated risks that can be measured from those that cannot. Harry Markowitz, in "Portfolio Selection" (*Journal of Finance*, 1952), first treated the spread of returns as the measure of investment risk. The Lloyd's account draws on the history pages published by Lloyd's of London.

## Review Questions

:q 9.1 | A bond costs Tk 80,000, pays Tk 5,600 and could be sold for Tk 82,000. Find the return and the rate of return.

:q 9.2 | Explain the difference between business risk and financial risk, with one example of each.

:q 9.3 | An asset returns 6%, 10% or 14%, with probabilities 0.25, 0.50 and 0.25. Find the expected value and the standard deviation.

:q 9.4 | Asset M has an expected return of 10% and a standard deviation of 3%. Asset N has an expected return of 18% and a standard deviation of 9%. Find each coefficient of variation and say which carries more risk for each unit of return.

:read Harry Markowitz, Portfolio Selection, 1952
:read Frank H. Knight, Risk, Uncertainty and Profit, 1921
:read Peter L. Bernstein, Against the Gods: The Remarkable Story of Risk, 1996
