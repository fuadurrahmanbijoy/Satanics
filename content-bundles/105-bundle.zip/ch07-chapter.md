:chapter VII | Capital Budgeting: Decisions and Cash Flows
:mood Which purchase will still be paying for itself in five years?
:desc Some decisions tie up a business's money for many years and are hard to undo. This chapter explains what such decisions are called, the steps a business follows to make them, and how to measure the cash that one project spends and receives. We follow one machine from its first payment to its last.
:plate ch07-plate.svg | An engineer checks his survey plan beside a half-built pier

> A rickshaw owner faces a choice that is hard to undo.
> You will need: Chapter 2, section 2.2, the investment decision.

Imagine a man in Dhaka who hires out three rickshaws by the day. He has saved Tk 90,000, and a dealer offers him a fourth rickshaw for exactly that sum. The dealer promises that the new rickshaw will repay its price within a year. Should the owner agree?

> The dealer's promise leaves many questions open.

The owner should hesitate, and the reasons are worth listing. The rickshaw will not earn money on every day. Some days bring rain, some weeks bring repairs, and a rival may begin work on the same road. The Tk 90,000 leaves his hands today, but the money it earns returns slowly, over years. And once the rickshaw is bought, he cannot easily recover his money, because a used rickshaw sells for much less than a new one.

> Three questions turn hope into a method.

So the owner needs more than hope. He must ask which payments will really happen, and when. He must ask which of them exist only because he buys the rickshaw. And he must ask whether the money coming in is worth more than the money going out, remembering that money received later is worth less than money received today. You met that idea in Chapters 4 to 6. Each question has a method, and the method has a name.

> This chapter measures the cash; the next chapter judges it.

This chapter teaches the first half of that method. It explains what a decision of this size is called, why it deserves careful work, and which steps a business follows. Then it shows how to measure the cash that a project spends and receives. Chapter 8, 'Capital Budgeting: Evaluation Techniques', shows how to judge whether those cash flows are good enough. Our running example is a print-on-demand machine for Meghna and Sons, the family bookshop in Dhaka. The shop and its figures are illustrative.

* * *

## What Capital Budgeting Is and Why It Matters

> Spending on onions and spending on a new room are different kinds of choice.

Begin with a choice from home. A family spends Tk 3,000 a week on food. If it buys too many onions, the harm is small, because the onions are eaten or wasted within days. Now suppose the same family decides to build a second room for Tk 400,000. The room cannot be returned to the builder, and it will serve the family for thirty years. Both choices are spending, but they are not the same kind of choice. The second is large, slow to repay and hard to reverse.

> Businesses face the same difference between small and large choices.
> Recall: the investment decision, Chapter 2, 'The Financial Manager's Work', section 2.2 'The Three Core Decisions'.

A business meets the same difference. In Chapter 2 you learned that the investment decision is the choice of which assets the business should hold, and that the financial manager shares in that choice. Most investment decisions are small and repeat every week, such as restocking a shelf. A few are large and rare. The large ones need a method of their own, and the name of that method is capital budgeting.

@ Capital | Word in use. In daily life, money or wealth that a person owns. In finance, the long-term funds and assets that a business uses to earn profit.
@ Capital budgeting | The process of planning, evaluating and choosing long-term investments.

> Capital budgeting is the planning of long-term investments.

**Capital budgeting** means the process of planning, evaluating and choosing long-term investments. When Meghna and Sons asks whether to buy a print-on-demand machine that will work for five years, the shop is doing capital budgeting. The word *budgeting* appears because the business plans in advance how much money to commit and what it expects to receive. The word *capital* needs care, as the side note explains: here it means long-term funds and the assets bought with them, not a person's savings.

> Three marks identify a capital budgeting decision.

How do you recognise a decision that belongs to capital budgeting? Look for three marks. First, the money is committed for a long time, usually many years. Second, the amount is large compared with the size of the business. Third, the decision is hard to reverse, because a used machine sells for far less than a new one. At 1 January 2024, a year before the machine was considered, the assets of Meghna and Sons were Tk 2,400,000. A machine with an initial cost of Tk 900,000 is therefore more than a third of everything the shop owned. All three marks are present.

> Size is relative, and the marks work together.

Notice that size is measured against the business, not in taka alone. A sum of Tk 900,000 is large for a bookshop but small for a national bank. The marks also work together. A cheap item that lasts for years is not a capital budgeting decision, because a mistake costs little. A large payment that the seller returns in full is easier to manage, because the mistake can be undone. The decisions that need the most care are those with all three marks.

@ Capital expenditure | Spending on assets that will serve the business for many years.

> The money paid out on such assets has its own name.

The money paid out has a name too. **Capital expenditure** means spending on assets that will serve the business for many years. A machine, a delivery van and a new shop floor are capital expenditure. A month of electricity is not, because it is used up at once. Capital budgeting is the planning; capital expenditure is the payment.

> Four reasons make careful appraisal worth the effort.

Why spend time on weighing a proposal before accepting it? There are four reasons. The first is size: one mistake can use a large part of the business's funds. The second is length: the machine works for years, so a wrong decision is paid for in every one of those years. The third is that the asset is hard to sell, so the owner cannot escape a poor choice cheaply. The fourth is that funds spent on the machine cannot also be spent on the next proposal, so every decision closes other doors.

> Careful work cannot remove error, but it exposes assumptions.

Careful work has limits. The future is uncertain, and forecasts will sometimes be wrong. What careful work does is to put every assumption on paper, so that others can question it and the business can check it later. A forecast that is written down can be improved; a hope that is never written down cannot.

> Each viewpoint sees the decision differently.

Different people see the same decision differently. The owner asks whether the funds will earn more than they cost. The financial manager must prepare the forecasts and defend them. An employee may gain work when a machine arrives, or lose it if the decision goes wrong. A customer gains a new service if the decision is good, and may face higher prices if it is not.

> Recap: capital budgeting is planning for large, long and hard-to-reverse choices.

*Before moving on.* Capital budgeting is the planning of long-term investments, and capital expenditure is the money paid. A decision belongs here when it is long, large for the business and hard to reverse. Careful appraisal matters because errors are costly and last for years.

* * *

## The Steps of the Process

> A large task becomes manageable when it is split into steps.

A builder who must cross a river does not begin by pouring concrete. She first asks where a bridge might go, then measures the ground, then chooses a design, then builds, and later inspects the work. A business facing a large choice also works in order. Following the same steps each time keeps the decision orderly and makes mistakes easier to find.

@ Project | Word in use. In daily life, a piece of work such as a school project. In capital budgeting, one proposed investment, such as a machine or a branch, treated as a single choice.

> The capital budgeting process has five steps.

The capital budgeting process has five steps, and the word *project* in them has the special meaning shown in the side note. Step one is to find proposals: ideas come from owners, staff, customers and changes in the market. Step two is to estimate the cash flows of each proposal, year by year. Step three is to evaluate the cash flows and choose. Step four is to implement the choice by buying, installing and training. Step five is to review the results by comparing real cash flows with the forecast.

> The figure shows the five steps in order.

Figure 7.1 shows the sequence. Read it from left to right. Each box is one step, and each solid arrow means that the next step begins when the last one ends. The dashed arrow below the boxes returns from the last step to the first: lessons from the review improve the next search for proposals. The labels under two boxes show where this book teaches that step.

:fig The five steps of the capital budgeting process | ch07-fig01.svg

> Each step has an owner and a question.

Each step answers a question. Step one asks what we could do. Step two asks what money will move, and when. Step three asks whether the money is worth the cost of the funds; Chapter 8 teaches the tools. Step four asks how to do it well. Step five asks what we learn. The financial manager is most active in steps two, three and five, because they need figures and honest comparison.

> The steps are a guide, not a rigid rule.

The steps have exceptions. In a small business one person may perform several steps in a week, and the steps may overlap. A proposal may return to step two when new facts appear. Step two is usually the hardest, because it forecasts the future; an error there passes into every later step. This is why the rest of this chapter concentrates on it.

> Case: two proposals compete for the same funds.
:case Case file, illustrative. 5 January 2025: Meghna and Sons holds two proposals. One is a print-on-demand machine with an initial investment of Tk 900,000. The other is a branch fit-out that needs Tk 900,000. The two cannot be run together. A feasibility survey for the machine, costing Tk 15,000, was paid in December 2024.

> The case shows why every proposal needs measured cash flows.
The case file shows why the rest of the process matters. Two proposals compete, and each needs a measured set of cash flows before any choice is made. Two new names describe how proposals relate to each other.

@ Independent projects | Projects where accepting one has no effect on whether another is accepted.

> Independent projects do not affect each other.

**Independent projects** are projects where accepting one has no effect on whether another is accepted. For example, the print-on-demand machine and a new set of shelves for the front room are independent: the shop may accept both, either or neither.

@ Mutually exclusive projects | Projects where accepting one means rejecting the others.

> Mutually exclusive projects compete: one only.

**Mutually exclusive projects** are projects where accepting one means rejecting the others. The machine and the branch fit-out are mutually exclusive, because the case file says they cannot be run together. Two clinics choosing between two scanners, when only one will be bought, face the same relation.

> Recap: five steps, and two kinds of relation between projects.

*Before moving on.* The process has five steps: find proposals, estimate cash flows, evaluate and choose, implement, and review. Projects are independent when one does not affect another, and mutually exclusive when choosing one rejects the rest.

* * *

## Cash Flow from an Investment

> Measuring cash flow means deciding which money to count.

Return to the rickshaw owner. He pays Tk 90,000 for the rickshaw today. Last month he paid Tk 2,000 for a mechanic's report about rickshaws, and that money cannot be recovered. He also pays Tk 500 a month for the garage where his three rickshaws stand, and he pays the same whether or not he buys a fourth. Which of these amounts should he count against the new rickshaw? The answer decides whether his forecast is honest.

### Relevant Cash Flow

@ Relevant cash flow | Cash flow that changes only because a project is accepted.

> Only cash that changes because of the project counts.

A **relevant cash flow** is a cash flow that changes only because a project is accepted. If the garage rent stays at Tk 500 a month with or without the new rickshaw, it is not relevant. Three tests help. The item must be cash, meaning money that really moves, not an accounting entry. It must lie in the future, because money already spent cannot be recovered. And it must change if the project goes ahead; an item that would be the same either way is not relevant.

> A cost already paid is not a reason for or against a project.

The second test needs a name. A sunk cost is money already spent that cannot be recovered, whatever the owner decides. Sunk costs do not change with the decision, so they are not relevant. Many students find this hard to accept, because the money feels lost if the project is rejected. But the money is lost in both cases, so it cannot help to choose between them.

> Case: the survey is sunk, so it is left out.
:case Case file, illustrative. 5 January 2025: a feasibility survey for the print-on-demand machine, costing Tk 15,000, was paid in December 2024. It is a sunk cost and is not a relevant cash flow.

:pause 7.p1 | A friend says the Tk 15,000 survey makes the machine less attractive, because the shop has already paid for it. Is the friend right? Answer in one or two sentences.

### Initial Investment

> The first cash flow is what must be paid to start.

@ Initial investment | Cash spent at the start to get a project going.

Before a machine earns anything, someone must pay for it. The **initial investment** is the cash spent at the start to get a project going. It includes the price of the asset and everything needed to make it ready for work, such as delivery and installation. It also includes working capital where the project needs it. In this book, working capital means the money tied up in stock and unpaid customer bills that a project needs in order to run; Chapter 15, 'Working Capital and the Cash Cycle', teaches it in full. The initial investment is paid at time zero, which means today, before year one begins.

> Case: the initial investment adds three payments.
:case Case file, illustrative. 5 January 2025: the print-on-demand machine for Meghna and Sons needs an initial investment of Tk 900,000. It is made up of the machine at Tk 780,000, installation at Tk 60,000 and working capital of Tk 60,000. The machine and installation together, Tk 840,000, are the cost of the asset.

### Operating Cash Flow

> Operating cash flow is not the same as profit.

Once the machine works, it brings in cash each year. Take a tailor's machine that adds Tk 100,000 of revenue in a year, meaning extra money from customers, and costs Tk 40,000 in cash to run. Is the yearly cash flow Tk 60,000? Not quite, for two reasons: depreciation changes the tax, and the tax itself is a payment. We take them in turn, using small clean figures so that the method is the only thing to learn.

@ Cost | Word in use. In daily life, the price paid for something. Here, a cash cost is money paid out in a year to run the project; depreciation is also called a cost in accounts, but no cash leaves.
@ Depreciation | The part of an asset cost charged as an expense in each year of its use.

> Depreciation spreads the cost of an asset over its years of use.

The first reason is **depreciation**. Depreciation means the part of an asset cost charged as an expense in each year of its use. A machine that costs Tk 100,000, works for five years and then has no resale value is charged at Tk 20,000 in each year. Charging the same amount each year is called the straight-line method. If a resale value is expected, subtract it first: the yearly charge is the cost, less the resale value, divided by the number of years. No cash leaves the business in those years, because the cash was paid at the start. But the charge lowers the profit on which tax is calculated, so it still changes the tax paid.

@ EBIT | Earnings before interest and tax: the profit from operations before paying lenders or the tax office.

> EBIT is the profit from operations before interest and tax.

The second tool is **EBIT**, which stands for earnings before interest and tax. EBIT is the profit from operations before paying lenders or the tax office. For the tailor, EBIT equals revenue, less cash costs, less depreciation: 100,000 − 40,000 − 20,000 = Tk 40,000. Some writers call EBIT operating profit, but this book uses EBIT from here on. Interest is left out on purpose. The cost of the funds is allowed for in the discount rate, which Chapter 8 teaches, so counting interest here as well would count the same cost twice.

@ Operating cash flow | Cash a project produces each year from running it, after tax.

> Operating cash flow is the cash a project makes each year after tax.

The **operating cash flow** is the cash a project produces each year from running it, after tax. Calculate it in three moves. First find EBIT. Second subtract the tax on EBIT. Third add depreciation again, because depreciation was subtracted to reach EBIT but no cash was paid. For the tailor, with tax at 25%, the tax is 0.25 × 40,000 = Tk 10,000. Then 40,000 − 10,000 = 30,000, and adding depreciation of 20,000 gives an operating cash flow of Tk 50,000.

:box IN SHORT
Operating cash flow = EBIT − tax on EBIT + depreciation. In symbols, OCF = EBIT − (T × EBIT) + D, where OCF is operating cash flow, T is the tax rate and D is depreciation.

> A second route gives the same answer, which is a useful check.

There is a second route to the same answer: revenue, less cash costs, less tax. For the tailor, 100,000 − 40,000 − 10,000 = Tk 50,000. The two routes agree, and a good habit is to run both. If they differ, the error is usually a forgotten step. Tax rules also differ by country and change over time, and the rate of 25% used in the running case is assumed for illustration only; always check the current rules of the place concerned.

### Terminal Cash Flow

@ Terminal cash flow | Cash received at the end of a project life, such as the resale value of equipment.

> At the end of its life a project may return cash.

When the project ends, some cash may return. The **terminal cash flow** is cash received at the end of a project life, such as the resale value of equipment. It has two parts: the sale of the asset, and the working capital that comes back as stock is sold and customers pay what they owe. These amounts are not earned by operating, so they are kept apart from the operating cash flow.

> Case: resale and working capital make up the terminal cash flow.
:case Case file, illustrative. End of year 5 of the print-on-demand machine: resale Tk 120,000, equal to book value, so no tax on the sale; working capital of Tk 60,000 returned. Terminal cash flow Tk 180,000.

> Book value decides whether a sale creates a taxable gain.
Here book value means the cost of the asset less the depreciation charged so far. If an asset sells for more than its book value, the gain is usually taxed. For example, a machine with a book value of Tk 120,000 that sells for Tk 140,000 has a gain of Tk 20,000, and tax at 25% is Tk 5,000, so the business keeps Tk 135,000. Rules for taxing such gains differ by country, so a student must always read the local rule.

> Recap: four kinds of cash flow, and which ones count.

*Before moving on.* A relevant cash flow changes only because the project is accepted; sunk costs do not count. The initial investment is paid at the start, the operating cash flow each year, and the terminal cash flow at the end. Operating cash flow equals EBIT, less tax, plus depreciation.

* * *

## Worked Example: Cash Flows of the Print-on-Demand Machine

> The same method now meets realistic figures.

The tailor's figures were small so that the method stood out. Now we use the same method on the machine for Meghna and Sons, in the standard order: Given, Find, Formula, Steps, Answer and Check.

> Given: the facts of the case, as recorded.
:case Case file, illustrative. *Given.* 5 January 2025. Machine Tk 780,000; installation Tk 60,000; working capital Tk 60,000. Each year for five years: added revenue Tk 700,000; cash costs Tk 380,000; depreciation Tk 144,000, straight line over 5 years; tax at 25%, assumed for illustration only. End of year 5: resale Tk 120,000, equal to book value; working capital Tk 60,000 returned. The Tk 15,000 survey is a sunk cost.

> Find and Formula: the question and the rule.
*Find.* The net cash flow of each year from year 0 to year 5, counting relevant cash flows only.
*Formula.* In words, net cash flow in a year equals the initial investment (year 0 only, shown as a negative number), plus the operating cash flow, plus the terminal cash flow (year 5 only). In symbols, NCF = −I + OCF + TCF, where NCF is net cash flow, I is the initial investment and TCF is terminal cash flow.

> Steps 1 and 2: the initial investment and depreciation.

*Steps.* Step 1, the initial investment: 780,000 + 60,000 + 60,000 = Tk 900,000. The survey of Tk 15,000 is left out, because it is sunk. Step 2, a check on depreciation: the asset cost is 780,000 + 60,000 = Tk 840,000, so (840,000 − 120,000) ÷ 5 = 720,000 ÷ 5 = Tk 144,000, which matches the case. After five years the book value is 840,000 − (5 × 144,000) = Tk 120,000, equal to the resale value, so the sale brings no tax.

> Steps 3 and 4: operating and terminal cash flow.

Step 3, the operating cash flow. EBIT = 700,000 − 380,000 − 144,000 = Tk 176,000. Tax = 0.25 × 176,000 = Tk 44,000. EBIT less tax = 176,000 − 44,000 = Tk 132,000. Adding depreciation gives 132,000 + 144,000 = Tk 276,000 each year. Step 4, the terminal cash flow: resale 120,000 + working capital 60,000 = Tk 180,000, so year 5 brings 276,000 + 180,000 = Tk 456,000.

> Table 7.1 collects the results: read by column and by row.

Table 7.1 gathers the results. Read each column as one year, and each row as one kind of cash flow. A negative number is cash paid out; a positive number is cash received.

:table Net cash flow of the machine, in taka
| Item | Year 0 | Year 1 | Year 2 | Year 3 | Year 4 | Year 5 |
| Initial investment | -900,000 | 0 | 0 | 0 | 0 | 0 |
| Operating cash flow | 0 | 276,000 | 276,000 | 276,000 | 276,000 | 276,000 |
| Terminal cash flow | 0 | 0 | 0 | 0 | 0 | 180,000 |
| Net cash flow | -900,000 | 276,000 | 276,000 | 276,000 | 276,000 | 456,000 |

> Answer: the shop pays Tk 900,000 now and receives Tk 276,000 a year, with Tk 456,000 in year 5.

*Answer.* The machine needs Tk 900,000 at the start, brings Tk 276,000 in each of years 1 to 4, and brings Tk 456,000 in year 5. *Check.* Run the second route for operating cash flow: 700,000 − 380,000 − 44,000 = Tk 276,000, the same as before. Adding the net cash flows gives 4 × 276,000 + 456,000 − 900,000 = Tk 660,000. That sum ignores the time value of money, so it does not yet show whether the machine is worth buying; Chapter 8 completes that step. For the present value of level cash flows, which it will use, see Chapter 5, 'Annuities', section 5.3 'Present Value of an Annuity'.

> Three slips are common in this calculation.

Watch for three common slips. The first is to forget the sign: the initial investment is cash paid out, so it is negative. The second is to forget depreciation in the second move, so that EBIT is reported as the cash flow. The third is to mix periods, such as placing the working capital at the end of year 1 instead of at year 0. Writing the units, taka, on every line catches many errors.

* * *

## Summary

> The chapter's ideas in a few lines.

Capital budgeting is the process of planning, evaluating and choosing long-term investments. Such decisions are large, long and hard to reverse, so they follow five steps: find proposals, estimate cash flows, evaluate and choose, implement, and review. Projects may be independent or mutually exclusive. Only relevant cash flows count. The initial investment is paid at the start, the operating cash flow equals EBIT less tax plus depreciation, and the terminal cash flow arrives at the end.

## Think It Through

> Two situations to test the chapter's ideas.

:q 7.t1 | A shop is considering a delivery van. Price Tk 560,000; registration and fitting Tk 40,000; working capital Tk 50,000. The van works for 4 years and then sells for Tk 100,000, equal to its book value. Each year it adds revenue of Tk 500,000 and cash costs of Tk 260,000. Depreciation is straight line on the asset cost less the resale value. Tax is 25%. Build the table of net cash flows for years 0 to 4.
:q 7.t2 | A clinic must choose between two scanners and can buy only one. Are the proposals independent or mutually exclusive, and what is the first step of the process that the clinic should take?

## Where People Go Wrong

> Profit and cash flow are different things.

A common belief is that profit and cash flow are the same. They are not. Depreciation reduces profit but no cash leaves; so operating cash flow is higher than EBIT less tax. The correction is to add depreciation again.

> A sunk cost is not a reason to continue or to stop.

Another belief is that money already spent must count against a project. It cannot, because the money is gone either way. Only cash that changes with the decision is relevant.

> Working capital is both paid and returned.

A third mistake is to forget working capital, or to treat it as lost. It is paid at the start and returns at the end of the project, so it appears twice, with opposite signs.

> Interest on loans is allowed for elsewhere.

A fourth mistake is to subtract loan interest in the yearly cash flow. In this method the cost of funds is allowed for in the discount rate, taught in Chapter 8, so interest is left out of the cash flows. This also keeps one cost from being counted twice.

## In History

> A very large public project, judged on long-run cash and benefit.

The Padma Bridge in Bangladesh carries road traffic over the Padma River near Dhaka. It was inaugurated on 25 June 2022 and opened to traffic the next day. According to the Bangladesh Bridge Authority, as reported in the press, it cost Tk 307.70 billion, paid from the government's own funds. In 2012 the World Bank decided not to fund the project after it found signs of corruption involving a Canadian construction firm, and the government then decided to build with its own money.

> The bridge shows all three marks and a loan repaid from tolls.

The bridge shows all three marks of this chapter: it was large, long-lived and impossible to reverse. Its early estimate, near Tk 101.62 billion in 2007, rose after several revisions. The finance ministry gave the funds to the Bridge Authority as a loan, to be repaid over 35 years in 140 quarterly instalments from toll revenue and other income. This is not a full analysis, but it shows the central question of capital budgeting: will the cash and the wider benefit over a long life justify the money spent today?

## Review Questions

:q 7.1 | What is capital budgeting, and why does a business need it? Give the three marks of such a decision.
:q 7.2 | A bakery plans to buy a second oven. Apply the five steps of the capital budgeting process to this decision, with one sentence for each step.
:q 7.3 | Explain independent projects and mutually exclusive projects, with two examples of each.
:q 7.4 | A shop is considering a freezer. Which of these items are relevant cash flows, and why? (a) The freezer price, Tk 200,000. (b) Tk 5,000 paid last month for a report on freezers. (c) Tk 8,000 a year of extra electricity. (d) Tk 30,000 of extra stock needed at the start. (e) Shop rent of Tk 40,000 a year, paid with or without the freezer.
:q 7.5 | A project adds revenue of Tk 240,000 a year with cash costs of Tk 120,000 and depreciation of Tk 40,000. Tax is 25%. Find EBIT, tax and the operating cash flow.
:q 7.6 | A machine with a book value of Tk 50,000 sells for Tk 70,000 at the end of its life. Tax is 25%, and Tk 20,000 of working capital returns. Find the terminal cash flow.

:read Brealey, Myers and Allen, Principles of Corporate Finance, 2020
:read Brigham and Ehrhardt, Financial Management: Theory and Practice, 2021
