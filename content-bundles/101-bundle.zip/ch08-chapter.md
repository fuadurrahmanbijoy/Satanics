:chapter VIII | The Partnership
:mood Who answers when two people own one business?
:desc This chapter explains how two or more people can own a business together. It shows what the law expects of partners, how they share profit and how a partnership ends. It closes by comparing the partnership with the sole proprietorship.
:plate ch08-plate.svg | A solicitor's office in the 1880s, where two partners sign their deed

> A signed order that one owner never saw leads to the central question of this chapter.
> You will need: Chapter 7, 'Forms of Business Ownership and the Sole Proprietorship', section 7.2 'The Sole Proprietorship', and section 7.3 'Formation and Management'.
Suppose that you and a friend own a bookshop together. On a Monday morning your friend, without telling you, signs an order for several hundred books from a supplier. You think the choice of books is poor. The supplier delivers the order, and the bill arrives on Friday. Who must pay it? Your friend alone? The business? Or you as well, even though you never saw the order?

> Most people answer the question wrongly at first, and the correct answer explains the chapter.
Many students expect that only the person who signed is bound. The law of partnership gives a different answer. The reasons for that answer explain nearly everything that follows, so keep the question in mind as you read.

> One owner has limits, so many owners ask what would change if someone joined them.
> Recall: sole proprietorship, Chapter 7, section 7.2 'The Sole Proprietorship'.
Chapter 7 described the sole proprietorship, where one owner decides everything and answers for everything. That arrangement is simple, but it has limits. One person has only so much money to invest. One person has only so many skills and only so many hours in a day. When the owner is ill or away, the business may stop. Many owners therefore ask a natural question: what if someone joined me?

> Joining brings questions that a sole owner never faces.
A second owner brings new problems. Who decides when two owners disagree? How is profit divided when one person invests more money and the other works longer hours? What happens when one person wishes to leave, or dies? And, as our opening question shows, who answers to outsiders for what one owner does? This chapter answers these questions in order.

> The chapter moves from the idea, to the kinds of partner, to the rules, to a comparison.
First we describe the partnership and the agreement on which it rests. Then we study the kinds of partner and the kinds of partnership. Next we examine the rights and duties that the law gives to partners, the sharing of profit and the ending of a partnership. Last, we compare the partnership with the sole proprietorship. A case file, a worked case and a true story from history will help to fix each idea.

* * *

## 8.1 Idea and Base of Partnership

> Joining owners together solves problems that one owner cannot solve alone.
Think of two friends who share a market stall. One has savings, and the other has a talent for selling. Alone, neither can keep the stall open every day. Together they can. They agree to share the work and to share whatever money the stall earns. Without using the word, they have formed the arrangement that this chapter studies.

> A partnership is an agreement among owners to run a business and share its profit.
@ Partnership | A business owned by two or more people who have agreed to run it together and share its profits.
The law gives the name **partnership** to this arrangement. A partnership is a business owned by two or more people who have agreed to run it together and to share its profits.^1 Each owner is called a partner. Everyday speech also uses the words firm, enterprise and concern for such a business; this book always says business. A partnership belongs to the private sector, because private persons own it and no government does.

^1: In Bangladesh the Partnership Act 1932 governs partnerships and defines them in much the same way. The Partnership Act 1890 of the United Kingdom speaks of persons carrying on a business in common with a view to profit. Laws differ between countries, so always check the law of the place where the business operates.

> The partners record their bargain in a written agreement.
@ Partnership deed | A written agreement setting out partners' capital, duties, profit shares and rules for ending the firm.
@ Deed | Word in use. In daily life, an action, as in a good deed. In law, a formal written document that records a binding agreement.
A partnership begins with an agreement, and the agreement may be spoken or written. A written agreement is called a **partnership deed**. It states the capital that each partner supplies, the duties of each partner, the shares in which profit is divided and the rules for ending the business. Suppose that two partners later disagree about what each promised. A spoken promise is hard to prove, but a signed deed settles the matter. Careful partners therefore write a deed, even where the law of their country does not require one.

> The case file shows what a deed records.
:case Case file, illustrative. Deed dated 1 July 2026, Meghna and Sons: three partners supply capital. Nurul Meghna supplies Tk 2,500,000, Rafiq Meghna supplies Tk 1,000,000 and Tariq Meghna supplies Tk 600,000, a total of Tk 4,100,000. The deed fixes the profit ratio at 5:3:2. Of every ten parts of profit, five go to Nurul, three to Rafiq and two to Tariq.

> Four features together make a partnership, and the law looks for all four.
What exactly makes a relationship a partnership? The law seeks four features, which together we call the base of partnership. The first is an agreement between two or more persons. The second is a business, meaning a lawful activity carried on to earn gain. The third is the sharing of profit among the persons. The fourth is that each person can act for all the others in the business. The fourth feature answers our opening question, so we study it with care.

:box IN SHORT
A partnership needs four features: an agreement, a business, the sharing of profit and mutual agency.

> Each partner acts for all the partners and can bind them.
> Recall: unlimited liability, Chapter 7, section 7.3 'Formation and Management'.
@ Mutual agency | The rule that each partner can act for the firm and bind all the other partners.
@ Agency | Word in use. In daily life, an office that arranges services, such as a travel agency. In law, the relation in which one person acts for another and can bind that person.
In law, an agent is a person who acts for another person and can bind that person by the act. Under **mutual agency**, each partner is the agent of all the other partners. The rule is called mutual because the agency works in both directions. So when your friend signs the order for books, all the partners must pay the supplier, because the friend acted as the agent of all. Chapter 7 showed that a sole owner has unlimited liability. In a partnership every partner shares that liability, and mutual agency means that it can arise from the act of another person.

:pause 8.p1 | A partner signs a contract in the ordinary course of the business with a supplier who has never met the other partners. Can the supplier demand payment from a partner who did not sign? Give your reason.

> Mutual agency has limits, and sharing profit alone does not make a partnership.
Two limits matter. First, mutual agency covers acts in the ordinary course of the business. A partner who buys a car for private use does not bind the others. Second, the deed may limit the power of a partner, for example by forbidding any partner to sign a large order alone. Such a limit protects the partners from each other. It does not stop an outsider who did not know of it from holding all the partners to the contract. Sharing profit is not enough by itself: an assistant who receives a share of profit as a bonus is not a partner, because no agreement exists to run the business together. The law also needs at least two partners, and it sets a maximum. In Bangladesh the maximum is 20 partners, or 10 in banking.^2

^2: This limit comes from the Companies Act 1994 of Bangladesh. Other countries set different limits, and some set none for certain professions.

> The same rule looks different to a partner, a supplier and an employee.
The rule of mutual agency looks different from each viewpoint. A partner gains a colleague who can act when he or she is absent, but also accepts the risk of the colleague's mistakes. A supplier gains security, because the supplier can ask any partner to pay. An employee should know that any partner may give instructions for the business, so the employee may need to ask which partner decides a matter. Each viewpoint explains why partners must choose each other with care.

> The first section ends with a recap of the idea and the base.
*Before moving on.* A partnership is a business owned by two or more people who agree to share its profit. Its base has four features: an agreement, a business, the sharing of profit and mutual agency. The partnership deed records the agreement in writing. Because of mutual agency, each partner can bind all the others.

## 8.2 Kinds of Partner and Partnership

> Partners differ in what they give and in how much they do.
Return to the two friends and the stall. Suppose that a retired neighbour, who has savings but no time to serve customers, wishes to join them. Should the neighbour be a partner in the same way as the friends? The law allows partners of several kinds. An active partner supplies capital, usually, and also manages the business every day. The neighbour in our example could be a different kind of partner.

> A sleeping partner provides money but does not manage.
@ Sleeping partner | A partner who supplies capital and shares profit but takes no active part in running the business.
A **sleeping partner** is a partner who supplies capital and shares profit but takes no active part in running the business. The neighbour in our example would be one. Sleeping partners are useful because they bring money without needing a daily role. They are not free of risk, however. Where the law gives every partner unlimited liability, as the Partnership Act 1932 does in Bangladesh, a sleeping partner answers for the debts of the business to the same extent as an active partner. Mutual agency also still applies, so the acts of the active partners bind a sleeping partner.

> A nominal partner only lends a name to the business.
A nominal partner lends a name to the business, perhaps because the name is respected. This person supplies no capital, receives no profit and takes no part in management. Outsiders who trusted the name may still hold the person liable for the debts of the business, because the person allowed them to believe that he or she was a partner.

> A limited partner risks only the money invested, where the law allows it.
A limited partner is a partner whose liability for the debts of the business stops at the capital that the partner has invested. Such a partner may not manage the business. In many laws, a limited partner who does manage loses the protection. Some countries allow this kind of partner; the United Kingdom does so under its Limited Partnerships Act 1907.^3 The Partnership Act 1932 of Bangladesh makes no provision for it, so in Bangladesh every partner has unlimited liability. Always ask which law applies before you accept any statement about a partner's risk.

^3: Other countries have their own laws on limited partners. The rules for registration and for the partner's role in management differ, so read the law of the place concerned.

> A table compares the four kinds of partner on three questions.
The table below compares the four kinds of partner on three questions. Does the partner supply capital? Does the partner manage the business? To whom is the partner liable, and how far? Read each row from left to right. For example, the row for the sleeping partner says yes to capital, no to management and unlimited liability.

:table Four kinds of partner
| Kind of partner | Supplies capital | Manages the business | Liability to outsiders |
| Active | Usually | Yes | Unlimited |
| Sleeping | Yes | No | Unlimited |
| Nominal | No | No | Unlimited, to outsiders who trusted the name |
| Limited | Yes | No | Limited to capital invested, where the law allows |

> Partnerships also differ in how long they are meant to last.
So far we have studied the partners. Partnerships also differ in their length of life. A partnership for a term is formed for a fixed period, such as five years, or for one venture, such as building a single block of shops. It ends when the period expires or the venture is complete. A partnership at will has no fixed period. It continues until a partner gives notice that he or she wishes to end it. The deed should state which kind the partners choose. When the deed fixes no period and no single venture, the law treats the partnership as one at will.

> Two bakers at a fair show why the deed should state the length of life.
Consider two bakers who agree to run a stall at a fair that lasts three weeks. Their partnership is for one venture, and it ends when the fair ends. Suppose instead that they say nothing about its length. The law then treats the partnership as one at will, so either baker could end it by notice in the busiest week of the fair. The example shows why the deed should state the length of life.

> The second section ends with a recap of the kinds of partner and partnership.
*Before moving on.* A sleeping partner supplies capital and shares profit but does not manage. A nominal partner lends only a name. A limited partner risks only the capital invested, where the law allows it. A partnership for a term ends with the term or the venture; a partnership at will ends when a partner gives notice.

## 8.3 Rights, Duties and Dissolution

> The law fills the gaps that the deed leaves.
What happens when the deed says nothing about a matter, such as who may inspect the books, or what to do when partners disagree? The law answers with implied rules. They apply unless the partners agree otherwise. Each partner has the right to manage the business, to inspect and copy the books of account, to be repaid money spent for the business, and to share in the profit. Ordinary matters are decided by a majority of the partners. A basic change, such as a new kind of business or a new partner, needs the consent of all.

> Partners owe each other honesty, true accounts and care.
The same rules place duties on each partner. A partner must act for the common benefit of all the partners and must deal honestly and fairly with them. A partner must keep true accounts and give full information on request. A partner must not earn a secret gain from the business, for example by taking a payment from a supplier without telling the others; such a gain belongs to the business. A partner must not run a competing business without consent. A partner who causes loss by wilful neglect must repay that loss. Because of mutual agency, every act of a partner puts the property of all the partners at risk, and for this reason trust is essential.

> Without an agreement, profit is shared equally, and the deed usually fixes a ratio.
Partners most often disagree about profit. When the deed is silent, the law says that partners share profit equally, whatever capital each has supplied.^4 It gives no salary to a partner for working in the business and no interest on capital, unless the deed provides for them. Equal shares often seem unfair, so partners usually fix a ratio in the deed. A ratio such as 5:3:2 divides the profit into 5 + 3 + 2 = 10 equal parts. The partners receive 5, 3 and 2 of those parts. Unless the deed says otherwise, losses are shared in the same ratio as profit.

^4: This is the rule of the Partnership Act 1932 in Bangladesh and of the Partnership Act 1890 in the United Kingdom.

> The case file applies the ratio to six months of profit.
:case Case file, illustrative. Under the deed of 1 July 2026, the profit for 1 July to 31 December 2026 is Tk 420,000. Shared in the ratio 5:3:2, Nurul Meghna receives Tk 210,000, Rafiq Meghna receives Tk 126,000 and Tariq Meghna receives Tk 84,000.

> A divided bar shows each partner's share of the capital and of the profit.
The figure below has two bars of equal length. The upper bar stands for the whole capital, Tk 4,100,000, and the lower bar stands for the whole profit, Tk 420,000. Each bar is divided into three parts, one for each partner. The width of a part shows that partner's share of the whole. Compare the same partner in both bars to see how the deed treats that partner.

:fig Capital and profit shares of the three partners | ch08-fig01.svg

> The profit ratio is a bargain among the partners, not a copy of the capital.
The figure shows an important point. Nurul supplies the largest part of the capital and receives the largest part of the profit, but his part of the profit is smaller than his part of the capital. Rafiq and Tariq receive larger parts of the profit than of the capital. The law does not require a reason for this. The ratio is a bargain among the partners, who may wish to reward work, skill or risk. The deed records the bargain, and the law enforces it.

> A partnership ends by dissolution.
@ Dissolution | The formal ending of a partnership or company, after which it no longer operates as before.
Partnerships do not last for ever. The formal ending of a partnership is called **dissolution**. After dissolution the partnership no longer operates as before. Dissolution is not always the end of the business itself, because the remaining partners may agree to continue it under a new agreement. When the business ends, the partners settle the accounts in a fixed order. The assets pay debts to outsiders first, then any loans from partners, then the partners' capital. Any remainder is shared in the profit ratio.

> A table lists the five modes of dissolution.
The law gives several ways in which a partnership ends, which we call the modes of dissolution. Read the table row by row. The left column names the mode, and the right column says when it happens.

:table Modes of dissolution
| Mode | When it happens |
| By agreement | All the partners agree to end it, or the deed provides for its end. |
| Compulsorily | All the partners but one become unable to pay their debts, or the business becomes unlawful. |
| On a stated event | A fixed term ends, a venture is complete, or a partner dies or becomes unable to pay debts, unless the deed says otherwise. |
| By notice | A partner gives notice to end a partnership at will. |
| By the court | A court orders it, for example when a partner is permanently unable to work or acts dishonestly. |

> The third section ends with a recap of rights, duties, profit and dissolution.
*Before moving on.* When the deed is silent, the law supplies rights and duties, and it shares profit equally. A deed usually fixes a profit ratio, and the ratio need not follow the capital. Dissolution is the formal ending of a partnership. It may happen by agreement, compulsorily, on a stated event, by notice or by order of a court.

## 8.4 Partnership Compared with Sole Proprietorship

> The two forms differ in owners, capital, decisions, profit and liability.
The table below sets the sole proprietorship beside the partnership. Read each row to compare one feature of the two forms.

:table Sole proprietorship and partnership compared
| Feature | Sole proprietorship | Partnership |
| Owners | One | Two or more |
| Capital | From one person | Pooled from all partners |
| Decisions | The owner alone | Shared among the partners |
| Profit | Kept by the owner | Shared in the agreed ratio |
| Liability | Unlimited for the owner | Unlimited for each partner, including for the acts of the others |
| Agreement | None needed | An agreement, ideally a written deed |

> A partnership gains capital and skill but loses sole control.
The advantages of a partnership are more capital, more skills and shared work. Its disadvantages are shared control, shared profit, the risk of disagreement and the liability that each partner carries for the acts of the others. A person who values full control, and who can supply enough capital and skill alone, may prefer the sole proprietorship. People who need each other's capital or skills, and who trust each other, may prefer a partnership with a careful deed.

> The fourth section ends with a short recap.
*Before moving on.* A partnership adds capital, skill and shared work to the sole proprietorship. It also adds shared control, shared profit and shared liability.

## Worked Case: Sharing Six Months of Profit

> A worked case applies an idea to a situation in five parts.
A worked case applies an idea to a situation. It has five parts: Situation, Question, Reasoning, Conclusion and Check. We use the case file of Meghna and Sons.

> The situation states the facts of the deed and the profit.
*Situation.* The deed of 1 July 2026 records capital of Tk 2,500,000 from Nurul Meghna, Tk 1,000,000 from Rafiq Meghna and Tk 600,000 from Tariq Meghna. The profit ratio is 5:3:2. The profit for 1 July to 31 December 2026 is Tk 420,000.

> The question asks for the shares under the deed and under the default rule.
*Question.* How much does each partner receive under the deed? How would the shares differ if the deed were silent?

> The reasoning divides the profit into equal parts, then compares it with the default rule.
*Reasoning.* Many students find the ratio confusing, because the word part is new here. A part is one of ten equal pieces of the profit. First, add the parts: 5 + 3 + 2 = 10. Second, find the value of one part: Tk 420,000 ÷ 10 = Tk 42,000. Third, multiply by each partner's number of parts. Nurul receives 5 × Tk 42,000 = Tk 210,000. Rafiq receives 3 × Tk 42,000 = Tk 126,000. Tariq receives 2 × Tk 42,000 = Tk 84,000. Fourth, apply the default rule. With no deed, the three partners would share equally: Tk 420,000 ÷ 3 = Tk 140,000 each.

> The conclusion compares the deed with equal shares.
*Conclusion.* Under the deed, Nurul receives Tk 70,000 more than an equal share. Rafiq receives Tk 14,000 less than an equal share, and Tariq receives Tk 56,000 less. The deed therefore favours the partner who supplied the most capital, but it does not divide the profit in proportion to capital.

> The check adds the shares and tests the return on each partner's capital.
*Check.* The shares add to the whole: Tk 210,000 + Tk 126,000 + Tk 84,000 = Tk 420,000. Dividing each share by Tk 42,000 gives 5, 3 and 2, the ratio of the deed. As a further test, compare each share with the partner's capital for the six months. Nurul earns Tk 210,000 on Tk 2,500,000, which is 8.4 per cent. Rafiq earns Tk 126,000 on Tk 1,000,000, which is 12.6 per cent. Tariq earns Tk 84,000 on Tk 600,000, which is 14 per cent. The smallest investor earns the highest return, which agrees with the figure in section 8.3.

* * *

## Summary

> A short summary of the chapter.
A partnership is a business owned by two or more people who agree to run it together and share its profits. The partnership deed records the agreement. Mutual agency lets each partner bind all the others, and every partner shares unlimited liability in Bangladesh. Partners may be active, sleeping, nominal or limited, where the law allows. Where the deed is silent, the law fixes rights, duties and equal profit shares. Dissolution ends the partnership.

## Think It Through

> The problem tests mutual agency on an invented case.
Suppose that Anwar, Bilkis and Chandan are partners in a furniture business. Their deed forbids any one partner to sign an order above Tk 50,000. Without asking the others, Anwar signs an order for timber worth Tk 90,000 with a supplier who has never seen the deed. This case is invented, to practise the ideas of the chapter.

:q 8.t1 | Are Bilkis and Chandan bound to pay the supplier? Give your reason.
:q 8.t2 | What may Bilkis and Chandan do about Anwar?
:q 8.t3 | How could the partners reduce the chance of a similar order in future?

## Where People Go Wrong

> Mistake one: only the partner who signs is bound.
Some readers think that only the partner who signed a contract must pay. This is wrong. Under mutual agency, an act in the ordinary course of the business binds all the partners, even those who never saw it.

> Mistake two: a sleeping partner has no risk.
Some readers think that a partner who takes no part in management cannot lose more than the capital invested. In Bangladesh this is wrong. A sleeping partner has unlimited liability, like every other partner, unless the law of the country provides for limited partners.

> Mistake three: profit must follow capital.
Some readers think that the partner with the largest capital must receive the largest share in proportion. This is wrong. When the deed is silent, the law shares profit equally. When the deed fixes a ratio, the ratio is a bargain among the partners and need not follow the capital.

> Mistake four: a limit in the deed protects the partners against outsiders.
Some readers think that a limit written in the deed protects the partners against every supplier. This is wrong. The limit protects the partners against each other. An outsider who did not know of it may still hold all the partners to the contract.

## In History

> Two engineers formed a partnership in 1939, and it later changed its form.
Bill Hewlett and David Packard studied engineering at Stanford University in California, in the United States. In 1938 they began work in a garage at 367 Addison Avenue in Palo Alto, California. Their first product was an audio oscillator, an instrument for testing sound equipment. The film studio of Walt Disney ordered eight of a later version of it for the film *Fantasia*.

> The partnership was formalised on 1 January 1939 and became a company in 1947.
On 1 January 1939 they formalised their venture as a partnership. A coin toss decided the order of their names, which is why the business is called Hewlett-Packard and not Packard-Hewlett. For eight years it remained a partnership. It was incorporated on 18 August 1947, which means that it became a company. By 1950 it had 70 products and revenue of about 2 million United States dollars.

> The story shows the features of this chapter and the change of form that may follow.
The story shows the features of this chapter: two people, an agreement, shared profit and shared risk. It also shows that a partnership may later change its form. Chapter 9, 'The Joint Stock Company', explains the form that the two partners chose in 1947.

## Review Questions

:q 8.1 | Two friends share the profit of a market stall in the ratio 3:2. The profit for the year is Tk 60,000. Find each friend's share.
:q 8.2 | The friends in question 8.1 wrote no deed. How would they share the Tk 60,000, and which rule gives the answer?
:q 8.3 | The partners of Meghna and Sons agree to change the profit ratio to 4:3:3. Find each partner's share of the profit of Tk 420,000 for 1 July to 31 December 2026.
:q 8.4 | A retired teacher offers capital to a baker but wishes to take no part in running the business. Name the kind of partner she would be, state her liability under the law of Bangladesh, and name the feature of the base of partnership that still binds her to the baker's acts.

:read David Packard, The HP Way, 1995
