:chapter XV | Institutions that Promote Business in Bangladesh
:mood Who stands behind a business that wishes to grow?
:desc A business that wishes to grow needs money, rules and friends. This chapter describes the share market, where a company can raise money from the public, and the regulator and exchange that keep that market orderly. It then describes the bodies that help trade and industry in Bangladesh, from the chambers of commerce to the zones built for exporters. The chapter moves slowly, because there are many names to keep apart.
:plate ch15-plate.svg | A chamber of commerce hall, with merchants at a long table

> You will need: Chapter 9 'The Joint Stock Company', section 9.1 'What a Company Is', and section 9.3 'Forming a Company'; Chapter 12 'Foreign Trade', section 12.3 'Regulating Trade'.
> Shares, the prospectus and the rules of trade from earlier chapters are the background here.

Imagine a family bookshop that has grown for thirty years and now wishes to open ten more shops. The cost is Tk 5,000,000. The family has savings, but not so much. A bank may lend the money, yet a loan must be repaid, with interest, whether or not the new shops succeed. Another way exists. The bookshop could invite thousands of strangers, and each stranger would give a small amount of money in return for a small part of the business. No stranger risks much, and the business does not have to repay the money on a fixed day.

> Strangers who give money need a safe way to do it.

This idea raises a puzzle. Why should a stranger give money to a business that the stranger cannot see, run or control? And how could the stranger ever get the money back if it were needed for a different purpose? The answer is a set of institutions. One institution is a market where parts of businesses are sold and resold. Another is an official body that watches the market, so that no one cheats the strangers. Others help the business itself: they speak for it, guide its exports and lower its costs.

> This chapter moves slowly, because many names must be kept apart.

Many students find this chapter difficult, not because any one idea is hard, but because there are many names, and each name sounds like the next. We therefore go slowly. We take one idea at a time, we begin each with an example from everyday life, and we end each with a short test that you can set for yourself. Four verbs will help you to hold the institutions apart: some institutions *regulate*, some *trade*, some *promote* and some *serve*. The figure in Section 15.3 draws them on one map.

* * *

## The Share Market

> A share market is a place, or system, where shares are bought and sold.
@ Market | Word in use. In daily life, a place where goods are sold, such as a vegetable market. In finance, any system in which buyers and sellers deal in one kind of thing, such as shares; it may have no building at all.
@! Go slowly here.

We begin with an everyday bridge. A shop sells a new bicycle to a student for Tk 10,000. The shop keeps the money. Two years later the student sells the same bicycle, now used, to a neighbour for Tk 6,000. The student keeps that money, and the shop receives nothing. Two different sales have taken place, and they must not be mixed: one sale gave new money to the maker's side of the trade, and the other moved an existing thing from one person to another.

> The two sales of a bicycle show two kinds of sale of a share.

Shares behave in the same way. A share was defined in Chapter 9, and it is one equal part of a company. A *share market* is a system in which shares are bought and sold. It has two parts, and the bicycle shows them both. The *primary market* is where a company sells new shares for the first time, and the company keeps the money. The *secondary market* is where people who already own shares sell them to other people, and the company receives nothing from these sales.

> Recall: shares, Chapter 9, 'The Joint Stock Company', section 9.1 'What a Company Is'.
> The company is paid in the primary market and not in the secondary market.

Now we use the smallest possible numbers. Suppose a company creates 100 new shares and sells them to the public at Tk 10 each. The company receives 100 × Tk 10 = Tk 1,000. That sale is in the primary market. Next, one buyer, whom we call Rina, sells her 10 shares to another person for Tk 12 each, or Tk 120 in all. That sale is in the secondary market. Rina receives the Tk 120, and the company receives nothing, although the company is affected, because it now has a different owner for those 10 shares.

:pause 15.p2 | In the example of Rina, who receives money in the primary sale of 100 shares, and who receives money when Rina sells her 10 shares?

> Why the secondary market matters: owners can leave without harming the company.

Why do we need the secondary market, if the company receives nothing from it? The reason is trust. A stranger gives money for a share more readily if the stranger knows that the share can be sold again, as the student could sell the bicycle. Without a secondary market, a person who needed money back in a hurry would have no way to leave the company. The company would then find it difficult to sell new shares in the primary market. The two parts support each other.

> You should now be able to say how the two markets differ.

*Before moving on.* You should now be able to say: in the primary market a company sells new shares and receives the money; in the secondary market owners sell existing shares to each other and the company receives nothing. One exception is worth noting: a company may later buy back or issue more shares, but each such act is a new sale and has to be considered on its own.

> An initial public offering is a company's first sale of shares to the public.
@ Initial public offering | The first time a company sells its shares to the public, so that they can later be traded.
@! Go slowly here.

A company reaches the primary market in a special way. An **initial public offering** means the first time a company sells its shares to the public, so that they can later be traded. For example, a family company that has never offered shares to strangers, and now does so, makes an initial public offering. The words *public offering* are often shortened to the letters IPO. An IPO is a single event, and it happens once; the sales that come after it are the sales of the secondary market.

> The offer needs a prospectus, which states the company and the risks.

The company must prepare carefully before it makes the offer. Chapter 9, in Section 9.3 'Forming a Company', taught the *prospectus*, the published invitation that describes the company and its risks. An IPO needs one, and the prospectus must be truthful, because strangers will rely on it. We will see in Section 15.2 that an official body examines the offer before the public sees it.

> Recall: the prospectus, Chapter 9, 'The Joint Stock Company', section 9.3 'Forming a Company'.
> An offer states a price per share, made of a face value and a premium.

Every offer states a price for each share, and the price has two parts that need names. The *face value* is the amount printed on the share as its nominal value, for example Tk 10. The *premium* is the extra amount above the face value that the public is asked to pay, because the company is worth more than the face value shows. Suppose a share has a face value of Tk 10 and an offer price of Tk 25. The premium is Tk 25 − Tk 10 = Tk 15.

> The case file states the plan for an offer of 200,000 shares at Tk 25.

:case Case file, illustrative. The plan of 20 October 2026 states that Meghna and Sons Limited considers an initial public offering of 200,000 shares at Tk 25 each, with a face value of Tk 10 and a premium of Tk 15. The offer would raise Tk 5,000,000. The plan is illustrative only.

:pause 15.p1 | In the case file, which part of the price of Tk 25 is the face value, which part is the premium, and which market does the sale belong to?

> An IPO does not guarantee success, for either the company or the buyer.

An IPO has limits that a careful reader should know. Not every offer sells all its shares, and a company may withdraw if the response is weak. A buyer takes a risk, because the price of a share can rise or fall after the offer, and the buyer may lose money. The law of limited liability, from Chapter 9, means that the buyer can lose at most what was paid for the shares, but it does not promise any profit. A prospectus is a description and not a promise.

> Recall: limited liability, Chapter 9, 'The Joint Stock Company', section 9.1 'What a Company Is'.
> Many viewpoints see an IPO differently: owner, investor, employee.

The viewpoints differ. An owner of the company gains money but gives up some control. An investor gains a chance of profit and a voice in decisions, and takes a risk. An employee may gain security if the company grows, but may also see new demands from owners who must report results to the public. Each viewpoint is real, and a decision to make an IPO should weigh all three.

> A stock broker is a licensed go-between who buys and sells shares for others.
@ Stock broker | A licensed intermediary who buys and sells shares for clients and earns a commission.
@! Go slowly here.

The last idea of this section answers a practical question: how does an ordinary person buy or sell a share? The person does not walk into the company. The person goes to a **stock broker**, which means a licensed intermediary who buys and sells shares for clients and earns a commission. A commission is a fee for the service. For example, suppose a broker charges 1 per cent. A client who buys shares worth Tk 10,000 pays a commission of Tk 100. The rate here is only an illustration.

> A broker needs a licence, because clients trust the broker with money.

A broker is licensed because clients give the broker money and instructions, and a dishonest broker could do great harm. The licence is a sign that the broker has met the rules of the institution that grants it, a body we meet in Section 15.2. A broker acts for the client, and the client decides what to buy or sell; a broker who trades without instructions breaks the rules.

> Before moving on: the share market in one paragraph.

*Before moving on.* A share market has a primary part, where a company sells new shares and receives the money, and a secondary part, where owners sell to each other. The first sale to the public is an initial public offering, and its price has a face value and a premium. A person buys and sells through a stock broker, who earns a commission. You should now be able to say who is paid in each kind of sale.

* * *

## The Regulator and the Exchange

> The secondary market needs a place to trade and an official to guard it.

The share market of Section 15.1 raises two needs. Buyers and sellers need a fixed place, with fixed times and rules, where they can meet. And someone must watch the whole system, because a market of strangers who cannot see each other invites cheating. Two institutions answer these needs. The first runs the place where shares are traded, and it is called a stock exchange. The second makes and enforces the rules, and it is called a regulator. Students often mix the two, so we take them in turn, and we then compare them.

> A stock exchange is an organised market for shares already issued.
@ Stock exchange | An organised market where shares and bonds already issued are bought and sold.
@ Exchange | Word in use. In daily life, to give one thing and receive another, or a place where money changes hands. In finance, the market where shares are traded under fixed rules.

A **stock exchange** means an organised market where shares and bonds already issued are bought and sold. A bond is a loan to a company or government, recorded in a certificate. An exchange has members, fixed hours and written rules, and trades take place through the stock brokers of Section 15.1. In Bangladesh the main one is the Dhaka Stock Exchange. A second, the Chittagong Stock Exchange, began in 1995.^1 A company whose shares are accepted for trading on an exchange is said to be listed.

^1: The Dhaka Stock Exchange was incorporated on 28 April 1954 and began formal trading in 1956. Its legal form and name have changed over time, and its ownership has since been reorganised. Check the exchange's own pages for the present details.

> A listed company's shares are traded in the secondary market on the exchange.

Listing connects the two parts of the share market. A company that makes an IPO usually asks the exchange to list its shares, so that the buyers of the primary market can later sell in the secondary market. The exchange has conditions for listing, such as a minimum amount of capital and the publication of accounts. Listing is a benefit, because it makes the shares easy to trade, and it is a duty, because the company must publish information and follow the exchange's rules.

> A regulator makes and enforces the rules of a market.
@ Regulator | An official body that makes and enforces the rules for an industry or market.

A **regulator** means an official body that makes and enforces the rules for an industry or market. The word regulate means to control by rules. For example, a regulator of the food industry may decide that every packet must show its ingredients, and may punish a business that does not. In the share market of Bangladesh the regulator is the Bangladesh Securities and Exchange Commission. The law of 1993 established it.^2

^2: The Bangladesh Securities and Exchange Commission was established on 8 June 1993 under the Bangladesh Securities and Exchange Commission Act, 1993.

> The Commission approves offers, licenses brokers and punishes cheating.

The Commission performs three main tasks. It examines and approves a company's offer of shares to the public, including the prospectus, before the offer is made. It supervises the exchanges and licenses stock brokers and other market professionals. And it investigates and punishes dishonest conduct, such as the use of secret information to trade before the public knows it. These tasks serve one aim, which is investor protection.

> Investor protection means rules that keep strangers' money safe from cheating.

*Investor protection* is the name for the rules and acts that keep the money of investors safe from cheating and from false information. A prospectus that must be truthful is one example. The licensing of brokers is another. Rules that require a listed company to publish its accounts, and penalties for those who break the rules, are two more. Protection does not remove risk: it cannot stop the price of a share from falling, but it can stop a person from being deceived.

> The exchange runs the market, and the regulator writes and enforces the rules.

Now we can compare the two institutions. The exchange is the organised market itself: it provides the place, the trading system and its own rules for its members. The regulator stands above it, and above the brokers: it makes the national rules and enforces them on the exchange, the brokers and the companies. A useful picture is a football match. The exchange is the pitch and the teams that play on it, and the regulator is the referee together with the body that writes the laws of the game.

:table The exchange and the regulator compared
| Feature | Stock exchange | Regulator |
| Main work | Provides the market where shares are traded | Makes and enforces rules for the market |
| Who deals with it | Brokers and listed companies | Exchanges, brokers and companies |
| Example in Bangladesh | Dhaka Stock Exchange | Bangladesh Securities and Exchange Commission |

> The table lists work, those who deal with the institution, and an example.

Read the table row by row. The first row says what each institution does. The second says who comes to it: brokers and companies come to the exchange, and the exchange, brokers and companies all answer to the regulator. The third row names the institution in Bangladesh. If you keep the football picture in mind, the rows are easy to recall.

:pause 15.p3 | A broker is accused of using secret information to trade. Which institution investigates the broker, and which institution runs the market where the trade took place?

> Before moving on: exchange and regulator in one paragraph.

*Before moving on.* A stock exchange is an organised market where shares already issued are traded through brokers. A regulator makes and enforces the rules, and in Bangladesh it is the Bangladesh Securities and Exchange Commission, which approves offers, licenses brokers and punishes cheating. Investor protection is the aim of these rules, and it does not remove risk.

* * *

## Bodies for Trade and Industry

> Many bodies help a business; four verbs hold them apart.

The institutions of Section 15.2 guard one market. A business also meets many bodies that help trade and industry in general. Some speak for businesses, some build the places where factories work, some guide exports, and some trade for the state. The figure that follows draws all of the institutions of this chapter on one map. Read it as four boxes. The box labelled Regulates holds the rule-maker, the box labelled Trades holds the market and its brokers, the box labelled Promotes holds the bodies that help exporters, and the box labelled Serves holds the bodies that speak for business or supply goods.

:fig Institutions as a map of who regulates, trades, promotes and serves | ch15-fig01.svg

> FBCCI is the apex body that speaks for the private business community.

The first body in the Serves box is the Federation of Bangladesh Chambers of Commerce and Industry, called FBCCI. A chamber of commerce is an association of local businesses that act together. FBCCI is the apex body: it stands at the top, and the chambers and trade associations of the country are its members. It was established in 1973. It speaks for private business to the government, helps to organise trade fairs and training, and assists in settling trade disputes.^3 Individual chambers, such as the Metropolitan Chamber of Commerce and Industry in Dhaka, which dates from 1904, serve their own members.

^3: The Federation's own publications list its present functions and members. They change over time.

> A trade body costs its members a subscription and gives them a voice.

A business pays a subscription to join a trade body. A subscription is a regular fee for membership. In the running case, the file records a trade body subscription of Tk 12,000 a year, which is Tk 12,000 ÷ 12 = Tk 1,000 a month. The business receives information, contacts, a voice with the government and a place at trade fairs. The business must judge whether these benefits are worth the fee. A very small shop may find that they are not, and a large exporter may find that they are.

> An export processing zone is a planned area that attracts exporters.
@ Export processing zone | A planned area with special rules and benefits to attract factories that make goods for export.

The first body in the Promotes box is not an office but a place. An **export processing zone** means a planned area with special rules and benefits to attract factories that make goods for export. For example, a foreign company that wishes to make shirts for export may build its factory in a zone, where the buildings, power and port links are ready, and where the paperwork is reduced. The benefits may include relief from some taxes and from some duties on imported machines and materials. Bangladesh has several zones, run by a government authority.^4

^4: The zones are managed by the Bangladesh Export Processing Zones Authority. The list of zones and the benefits offered change with government policy.

> Recall: tariffs and trade rules, Chapter 12, 'Foreign Trade', section 12.3 'Regulating Trade'.
> A zone gives relief from tariffs, which the earlier chapter introduced.

A zone works because it removes a barrier that Chapter 12, in Section 12.3 'Regulating Trade', introduced: the duty on imported goods. A factory in a zone imports machines and materials, makes goods, and sends them abroad. If the factory had to pay duty on the machines and materials, its costs would be higher. The zone lowers those costs, and in return the country gains jobs, foreign money and skill. A limit exists: goods sold inside the country from a zone usually face the ordinary rules.

> The Export Promotion Bureau helps exporters find customers and information.

The second body in the Promotes box is the Export Promotion Bureau, a government body. It collects information on foreign markets, helps exporters to join trade fairs abroad, and gives guidance on the steps of Chapter 13. An exporter who is looking for a first customer abroad may begin with the Bureau. It does not buy or sell for the exporter; it guides and informs.

> The Trading Corporation of Bangladesh trades for the state.

The last body of the Serves box is the Trading Corporation of Bangladesh, a state-owned trading business under the Ministry of Commerce. It was established on 1 January 1972, after the war of 1971, to ensure the supply of essential goods and industrial materials. It distributes essential goods to the public at fair prices, so that the market stays steady. It differs from the other bodies: it buys and sells goods itself, as a business does.^5

^5: This chapter's plan lists the body as TCCB. The established name and abbreviation of the state trading body is Trading Corporation of Bangladesh (TCB), and this book follows that name. The Corporation's duties have changed since 1972.

> Other institutions also help: the central bank, standards and investment bodies.

Several other institutions complete the picture. Bangladesh Bank, the central bank, controls the supply of money and the banks that open the letters of credit of Chapter 13. The Bangladesh Standards and Testing Institution sets and tests standards of quality for goods. Government bodies for investment help new businesses, and in particular foreign investors, to begin. We name them so that a reader who meets them will know that they exist; this book does not study them further.

> Before moving on: the four groups of institutions.

*Before moving on.* The map of the chapter has four boxes. The Securities and Exchange Commission regulates. The exchange and the brokers trade. The Export Promotion Bureau and the export processing zones promote. FBCCI and the chambers, together with the Trading Corporation of Bangladesh, serve. You should now be able to name one institution for each verb.

* * *

## Worked Case: Should Meghna and Sons Limited Offer Shares to the Public?

> The worked case follows Situation, Question, Reasoning, Conclusion, Check.

This section applies the chapter to the running case. We follow five parts in order: the situation, the question, the reasoning, the conclusion and a check. The case is illustrative, and it is not a model answer to any question.

> The situation restates the plan in full.

:case Case file, illustrative. *Situation.* A plan of 20 October 2026 states that Meghna and Sons Limited considers an initial public offering of 200,000 shares at Tk 25 each. The face value is Tk 10 and the premium is Tk 15. The offer would raise Tk 5,000,000. The company also pays a trade body subscription of Tk 12,000 a year. The plan is illustrative only.

> The question asks about money, institutions and judgement.

*Question.* How is the sum of Tk 5,000,000 made up? Which institution would approve the offer, which would list the shares, and who would handle later trading? Is the trade body subscription large or small beside the profit of Tk 750,000 reported for 2025?

> Reasoning step one: the face value and the premium parts of the sum.

*Reasoning.* We begin with the money. The price is Tk 25 for each share. For 200,000 shares the total is 200,000 × Tk 25 = Tk 5,000,000. The face value part is 200,000 × Tk 10 = Tk 2,000,000, and the premium part is 200,000 × Tk 15 = Tk 3,000,000. The price is 25 ÷ 10 = 2.5 times the face value, and the premium is 15 ÷ 25 = 60 per cent of the price.

> Reasoning step two: each institution has one task in the plan.

Next we place the institutions. The offer is a sale in the primary market, because the company sells new shares and receives the money. The Bangladesh Securities and Exchange Commission, the regulator, would examine the offer and the prospectus before the public sees them. After the sale, the company would ask a stock exchange, such as the Dhaka Stock Exchange, to list the shares. Later, owners who wish to sell would use stock brokers, in the secondary market, and the company would receive nothing from those sales.

> Reasoning step three: the subscription is small beside the profit.

Now we judge the subscription. Tk 12,000 ÷ Tk 750,000 = 0.016, which is 1.6 per cent of the profit of 2025. This is a small share of profit. The benefit to the business cannot be counted as exactly as the fee, so the business must judge whether the contacts and the voice with the government are worth it. A figure alone does not decide the matter.

> Conclusion and check: the sums agree, and each institution has its task.

*Conclusion.* The offer would raise Tk 5,000,000, of which Tk 2,000,000 is face value and Tk 3,000,000 is premium. The Commission would approve it, the exchange would list the shares, and brokers would carry the later trading. The subscription is about 1.6 per cent of the profit of 2025. *Check.* Tk 2,000,000 + Tk 3,000,000 = Tk 5,000,000, which equals the amount in the case file. The check passes.

* * *

## Summary

> Summary of the chapter in a few lines.

A share market has a primary part, where a company sells new shares and keeps the money, and a secondary part, where owners sell to each other. A company first sells to the public in an initial public offering, and people buy and sell through licensed stock brokers. A stock exchange is the organised market, and the regulator, in Bangladesh the Securities and Exchange Commission, makes and enforces the rules to protect investors. Other bodies help trade and industry: FBCCI speaks for business, export processing zones and the Export Promotion Bureau promote exports, and the Trading Corporation of Bangladesh trades for the state.

## Think It Through

:q 15.t1 | Give two reasons why a company might choose to list its shares, and one reason why it might choose not to.
:q 15.t2 | A bakery earns a profit of Tk 400,000 a year and is asked to pay a trade body subscription of Tk 20,000 a year. Compare the fee with the profit, and say what else the owner should weigh.

## Where People Go Wrong

> A company is paid in the primary market and not in the secondary market.

Many students believe that a company receives money every time its shares are traded. It does not. The company receives money only when it sells new shares. When owners sell to each other, the money passes between the owners.

> The exchange and the regulator are different institutions.

A second error is to treat the stock exchange and the regulator as one body. The exchange is the organised market, and the regulator makes and enforces the rules for the exchange, the brokers and the companies. One runs the pitch, and the other acts as the referee.

> Investor protection does not guarantee a profit.

A third error is to think that a regulator makes shares safe to buy. The regulator can prevent cheating and false information, but it cannot prevent the price of a share from falling. A buyer still takes a risk.

## In History

> In 1792, twenty-four brokers in New York agreed to trade among themselves.

In New York, before 1792, brokers traded shares and public debt on the street, with few rules. On 17 May 1792, twenty-four brokers signed a short agreement, known as the Buttonwood Agreement, near 68 Wall Street. They agreed to trade with each other and to charge fixed commissions. The New York Stock Exchange traces its beginning to that agreement. In 1817 the group wrote a constitution, and in 1863 it took the name New York Stock Exchange.

> Dhaka's exchange began in 1954, as a place for the shares of a young country.

The share market of Bangladesh has a younger and different story. The Dhaka Stock Exchange was incorporated on 28 April 1954, under the name East Pakistan Stock Exchange Association Limited, and began formal trading in 1956. Its name changed in later years, and it became the Dhaka Stock Exchange. The Securities and Exchange Commission was established in 1993, to watch over the market. Both stories show the same idea: a market of strangers needs a shared place and shared rules.

## Review Questions

:q 15.1 | Sort the following by their role, regulate, trade, promote or serve: the Securities and Exchange Commission, the Dhaka Stock Exchange, the Export Promotion Bureau, FBCCI, a stock broker.
:q 15.2 | A company sells 50,000 new shares at Tk 30 each, with a face value of Tk 10. Find the total raised, the face value part and the premium part, and name the market in which the sale takes place.
:q 15.3 | In the example of Question 15.2, an owner later sells 1,000 of these shares to another person for Tk 35 each. Which market is this, who receives the money, and does the company receive anything?
:q 15.4 | A foreign company wishes to build a factory to make goods for export in Bangladesh. Name one body or place that could help it, and explain the help in two sentences.
:q 15.5 | A company that is listed on an exchange wishes to sell new shares to raise money for a new factory and to export from a zone. List the institutions it would deal with, in the order of the steps, and say what each does.
