:chapter XII | Foreign Trade
:mood Why does a country buy what it could make itself?
:desc This chapter explains why nations buy and sell goods across their borders, how that trade is counted and recorded, and how governments control it. It follows one bookshop in Dhaka that buys books abroad and sells books abroad, and it ends with a famous argument from 1817.
:plate ch12-plate.svg | A sailing ship loaded at a quay with bales and barrels

> Two earlier chapters give the ideas that this chapter builds on.
:box YOU WILL NEED
Chapter 1 'What Business Is', section 1.2 'Trade, Commerce and Industry'; Chapter 11 'State Enterprise and Comparing the Forms', section 11.1 'Why Government Owns Businesses'.

> Everyday objects come from many countries, so where do they come from?
Examine the things on your desk. Perhaps there is a pen, a phone and a shirt. Ask where each one was made. The pen may come from one country, the parts of the phone from three others, and the cotton of the shirt from a fourth. Very few people live only on goods made inside their own country. The question is why.

> A country that makes everything best seems to need nothing from others.
This question troubled thinkers for centuries. Imagine a country that grows better wheat, weaves better cloth and brews better tea than every other country. Would it still gain by buying goods from abroad? Most people first answer no. If you are the best at everything, you need nothing from anyone. The answer feels sensible. It is wrong, and the reason is worth discovering slowly.

> A busy doctor gains by hiring a slower typist, and the same logic applies to nations.
To see why, begin with a smaller case. A doctor in Dhaka types faster than her assistant. She could type every letter herself. She does not, because each hour of typing is an hour she cannot spend treating patients, and her patients value that time far more. She gains by leaving the typing to her assistant, although he types more slowly than she does.

> Nations face the same choice, because every country has limited workers, land and machines.
Nations face the same choice. Each has a limited number of workers, a limited amount of land and a limited number of machines. An hour of work spent on one good is not spent on another. This chapter shows how that plain fact explains why nations trade, how we count the trade, and why governments watch it closely. We follow one running case, a bookshop that both buys and sells across a border.

* * *

## 12.1 Why Nations Trade

> Foreign trade is buying and selling across a national border.
> Recall: trade, Chapter 1 'What Business Is', section 1.2 'Trade, Commerce and Industry'.
@ Foreign trade | The buying and selling of goods and services between people or firms in different countries.
@ Trade | Word in use. In Chapter 1, trade means buying and selling. In this chapter it also names the whole flow of goods between countries.
Chapter 1 explained trade as buying and selling. Most of it happens inside one country, between a shop and the people who live nearby. This chapter follows the trade that crosses a border. **Foreign trade** is the buying and selling of goods and services between people or firms in different countries. A bakery in Dhaka that buys wheat from a farmer in another country takes part in foreign trade.

> Exports leave a country; imports arrive in it.
@ Export | A good or service sold to a buyer in another country.
@ Import | A good or service bought from a seller in another country.
Foreign trade runs in two directions, and each direction has its own name. An **export** is a good or service sold to a buyer in another country. An **import** is a good or service bought from a seller in another country. A tea garden in Sylhet that sells tea to a customer in the United Kingdom makes an export. The bakery that buys foreign wheat makes an import. One sale carries both names: the wheat is an export for the country that sells it and an import for the country that buys it.

> Countries differ in resources and skills, so each can make some goods more cheaply.
Why do nations trade at all? The first reason is that countries differ. Bangladesh has a large workforce and fertile river land, and the hills of Sylhet have the rain that tea needs. Other countries have oil, copper or wide plains for wheat. No country holds every resource. The second reason is skill and scale. A country that makes one good in large numbers learns to make it cheaply, and customers abroad then benefit from the lower price.

> Two neighbours show how trade helps even when one is better at everything.
The opening puzzle asked whether a country that is best at everything can still gain. We answer it first with two neighbours, Rina and Salim, who each work for one day. Rina is better at both jobs, but she is much better at growing rice than at sewing shirts. The table shows what each can produce in a full day if they do only one job.

:table What each neighbour can produce in one full day
| Neighbour | Rice, if only rice | Shirts, if only shirts |
| Rina | 8 kilograms | 4 shirts |
| Salim | 2 kilograms | 2 shirts |

> Compare how much rice each neighbour loses for every shirt made.
Read one row at a time. Rina can grow 8 kilograms of rice or sew 4 shirts in a day, but not both. For Rina, one shirt costs 2 kilograms of rice, because 8 divided by 4 is 2. For Salim, one shirt costs only 1 kilogram of rice, because 2 divided by 2 is 1. Salim is worse than Rina at both jobs. Yet he loses less rice for every shirt he sews.

> A comparative advantage means a lower cost in other goods, not the best skill.
The idea now has a name: comparative advantage. A person or a country has a comparative advantage in a good when making it costs less of other goods than it costs others. Salim has the comparative advantage in shirts, and Rina has it in rice. David Ricardo, an English economist, set out this idea in 1817. Notice the rule: comparative advantage compares costs inside each country, not the skill of one country against another.^1

^1: Economists use the phrase absolute advantage for being able to make a good with fewer workers or less time than others. Rina has an absolute advantage in both jobs, yet that does not decide who should do which.

:pause 12.p1 | Suppose Salim could grow 4 kilograms of rice or sew 2 shirts in a day. Would Rina and Salim still gain by trading? Explain.

> Both neighbours gain when they trade at a price between their two costs.
Now test the gain. Let Rina grow rice and Salim sew shirts, and let them agree a price of 1 shirt for 1.5 kilograms of rice. If Rina made the shirt herself, it would cost her 2 kilograms of rice. By buying it, she pays 1.5 kilograms, so she saves half a kilogram. If Salim grew 1.5 kilograms of rice himself, he would lose 1.5 shirts. By trading, he gives one shirt, so he saves half a shirt. Both are better off. Any price between 1 and 2 kilograms of rice per shirt would work.

> Trade brings gains to many people, but it can cost some workers their jobs.
Economists call the benefit the gains from trade: more goods, lower prices and wider choice for customers. The owner of a business that exports reaches more customers. A customer who buys imports finds goods that no local business makes. Yet the gains are not shared evenly. An employee in an industry that faces cheaper imports may lose work, and moving to a new job takes time. Transport costs and delays also reduce the gain. For these reasons, governments often control trade, as section 12.3 shows.

> The section ends with the main points on why nations trade.
*Before moving on.* Foreign trade is buying and selling between countries. Exports are sold abroad, and imports are bought from abroad. Countries trade because they differ, and because each gains by making the goods that cost it least in other goods. That is comparative advantage, and it works even when one country is better at everything.

* * *

## 12.2 Measuring Foreign Trade

> Goods and services need separate names, because they are counted in different ways.
Governments want to know how much a country buys and sells abroad. The first step is to separate what is traded into two kinds. Visible trade is the trade in goods: things you can see, touch and count as they cross the border, such as books, tea, garments and wheat. Invisible trade is the trade in services: work done for a customer that leaves no object, such as shipping, insurance, banking and tourism. A ship from Chattogram carries garments, which are visible trade. The freight charge that the ship's owner earns for carrying them is invisible trade.

> The two kinds of trade differ in what is traded and how it is counted.
The table below compares the two kinds. Read each row from left to right: the first cell names the feature, and the next two cells give the answer for visible trade and for invisible trade.

:table Visible trade and invisible trade compared
| Feature | Visible trade | Invisible trade |
| What is traded | Goods you can touch | Services you cannot touch |
| Examples | Books, tea, garments, wheat | Shipping, insurance, banking, tourism |
| How it is counted | Customs officers count the goods at the border | Banks and statistics offices record the payments |

> A foreign visitor who pays for a hotel room buys an export of a service.
Many students find it strange that a service can be an export, because nothing visible leaves the country. The definition of export covers services as well as goods. A visitor from abroad who pays for a hotel room in Cox's Bazar buys a service from Bangladesh. Money comes into the country, as it does when a foreign customer buys tea, although no object crosses the border. So the visitor's payment is an export of a service, and it belongs to invisible trade.

> The balance of trade compares the value of goods sold abroad with goods bought abroad.
@ Balance of trade | The difference in value between a country's exports and imports of goods over a period.
@ Balance | Word in use. In daily life, the money left in a bank account. Here, the gap between two totals.
Once goods are counted, we compare the two directions. The **balance of trade** is the difference in value between a country's exports and imports of goods over a period. Suppose a small country exports goods worth 100 units of money in one year and imports goods worth 130 units. The balance is 100 minus 130, which is minus 30. We call this a deficit of 30. If exports were larger than imports, the balance would be a surplus. Services are not counted here, because the definition covers goods only.

> A deficit is not always bad, and a surplus is not always good.
A deficit sounds like a loss, but the picture is more complex. A country that is building factories must import machines before it can export anything. Its deficit then pays for future earnings. A surplus can also hide a weakness: a country that sells much abroad but buys little may leave its own customers short of goods. Judge the balance of trade together with the reasons for it, and with the other money flows described next. A single business can keep such a balance as well, as the worked case shows.

> The balance of payments records every flow of money across the border, not goods only.
@ Balance of payments | A record of all money flowing into and out of a country over a period.
The balance of trade is only one part of a larger record. The **balance of payments** is a record of all money flowing into and out of a country over a period. It includes payment for goods and for services. It also includes money sent home by workers abroad, and money that moves for investment and loans. A Bangladeshi worker who sends money to family in Dhaka adds to the money flowing in. A Bangladeshi business that pays a supplier abroad adds to the money flowing out.

> The two records answer different questions about the same country.
Why keep two records? The balance of trade is easy to count, because customs officers see the goods. The balance of payments is wider. It shows whether the country as a whole receives more foreign money than it pays out. The two can point in different directions: a country with a deficit in goods may still receive much money from workers abroad. Owners and managers watch both, because a shortage of foreign money can make imported inputs harder to buy.

> An exchange rate lets us compare money from different countries.
@ Exchange rate | The price of one country's money measured in another country's money.
To add or compare payments made in the money of different countries, we need one more tool. The **exchange rate** is the price of one country's money measured in another country's money. In this book we use an illustrative rate of Tk 120 per US dollar.^2 At that rate, USD 10 equals Tk 1,200, because 10 times 120 is 1,200. Tk 600 equals USD 5, because 600 divided by 120 is 5.

^2: Real exchange rates differ from bank to bank and change from day to day. The rate of Tk 120 per US dollar is chosen for easy arithmetic, not as a record of any day.

> When the exchange rate changes, the price of imports and the earnings from exports change.
Rates move. Suppose an importer must pay USD 100 for a book. At Tk 120 per dollar the book costs Tk 12,000. If the rate rises to Tk 130 per dollar, the same book costs Tk 13,000. The taka now buys fewer dollars, so imports cost more taka. An exporter gains in the opposite way: each dollar earned abroad now brings Tk 130 instead of Tk 120. A customer at home sees the rise in the price of imports, and the owner of an exporting business sees the rise in earnings.

> The section ends with the main points on measuring foreign trade.
*Before moving on.* Visible trade is goods, and invisible trade is services. The balance of trade compares exports and imports of goods, while the balance of payments records all money flowing in and out. The exchange rate lets us convert one country's money into another's, so that we can compare totals.

* * *

## 12.3 Regulating Trade

> Governments regulate trade to protect local producers, raise money and keep supplies steady.
Left alone, trade follows prices. Governments seldom leave it alone. They control trade for several reasons: to protect local businesses from cheaper foreign goods, to raise money from taxes, to keep out unsafe goods, and to keep supplies of essential goods steady. The tools differ from country to country, and rates change often, so we name the country whenever a rule depends on place. The two oldest tools are the tariff and the quota.

> A tariff is a tax on imported goods, so it raises their price.
@ Tariff | A tax charged on imported goods, which raises their price.
A **tariff** is a tax charged on imported goods, which raises their price. Suppose a pair of shoes costs Tk 2,000 when it reaches the port, and the tariff is 10 per cent. The tax is 10 per cent of Tk 2,000, which is Tk 200, so the shoes cost Tk 2,200 after the tax. In Bangladesh, customs officers collect the tariff, also called customs duty, when goods enter the country. Tariff rates differ by country and by good.

> A tariff helps local producers but raises prices for customers.
A tariff has winners and losers. A local shoemaker gains, because imported shoes now cost more and customers may buy local shoes. The government gains tax. The customer loses, because prices rise and choice may shrink. A foreign supplier may lose sales. Another danger is retaliation: a country that is hurt by a tariff may answer with its own tariff, and both countries then trade less. A tariff is therefore a trade-off, not a free benefit.

> A quota limits the quantity of an import instead of raising its price.
A quota is a limit on the quantity of a good that may be imported in a period. For example, a government may allow only 50,000 tonnes of sugar to enter in one year. Once the limit is reached, no more may enter, whatever the price. A tariff works through price, while a quota works through quantity. A quota raises price only indirectly, because a limited supply makes the good scarce. A quota by itself raises no tax, unlike a tariff.

> A short table sets the two tools side by side.
The table sets the two tools side by side. Read each row across, from the feature to the answer for a tariff and for a quota.

:table Tariff and quota compared
| Feature | Tariff | Quota |
| What it controls | The price of imports | The quantity of imports |
| Who collects money | The government, as tax | Usually nobody |
| Effect on price | Rises directly | Rises because supply is limited |

> Some governments use state enterprises to control the import of essential goods.
> Recall: state enterprise, Chapter 11 'State Enterprise and Comparing the Forms', section 11.1 'Why Government Owns Businesses'.
A third tool is direct. A government may give one state enterprise the task of importing an essential good, such as a grain or a fuel, in large amounts, so that supply stays steady and the price stays under control. The state enterprise may be a public corporation with its own board, or a departmental undertaking run inside a ministry. Chapter 11 explains why governments own businesses. Here we note that they can also act as traders.

> Agreements and bodies lower barriers by making rules that many countries accept.
Countries also reduce barriers by agreement. A trade agreement is a set of rules that two or more countries accept, such as lower tariffs on each other's goods. The European Union is a well-known example: its member countries charge no tariffs on trade among themselves. On a larger scale, the World Trade Organization began on 1 January 1995 and has its headquarters in Geneva. It provides rules, and a place to settle disputes, for most of the world's trade.^3 Bangladesh has been a member since the start.

^3: The World Trade Organization replaced an older arrangement, the General Agreement on Tariffs and Trade, which began in 1947.

> Foreign trade matters greatly to Bangladesh because it earns foreign money and supplies needed goods.
Foreign trade is important to Bangladesh for three reasons. First, exports earn foreign money and give work to many people; ready-made garments are the largest export, by a wide margin. Second, imports supply goods that the country cannot easily make, such as fuel, machinery, raw cotton and food grains. Third, money sent home by Bangladeshis who work abroad adds greatly to the money flowing in. Dependence has a risk: a country that sells mostly one good is exposed when customers abroad buy less of it. Owners, managers and employees all feel these changes.

> The section ends with the main points on regulating trade.
*Before moving on.* A tariff taxes imports and raises their price, and a quota limits their quantity. Governments may also use state enterprises, and countries make agreements and join bodies such as the World Trade Organization. For Bangladesh, foreign trade earns foreign money, supplies needed goods and brings in money from workers abroad.

* * *

## A Worked Case: Meghna and Sons Counts Its Foreign Dealings

> A worked case applies the ideas of this chapter to the shop's own records.
This worked case applies the chapter to one set of records. It has five parts: the situation, the question, the reasoning, the conclusion and a check. Many students find the conversion step confusing, because two kinds of money appear together. The plan is to keep the two kinds apart until the last step.

### Situation

> The shop's foreign dealings of 2026 are recorded in dollars and in taka.
:case Case file, illustrative. Foreign dealings 2026, at an illustrative rate of Tk 120 per US dollar. On 10 March 2026 Meghna and Sons imported 800 English-language titles worth USD 18,000 (Tk 2,160,000). It sold 150 Bangla titles to a Kolkata bookseller worth USD 2,500 (Tk 300,000).

### Question

> The question asks for the shop's balance of trade, in dollars and in taka.
What is the shop's balance of trade for these dealings? Give the answer in US dollars and in taka.

### Reasoning

> Reasoning proceeds in three steps: classify, subtract in dollars, then convert.
First we classify. Books are goods, so both dealings are visible trade, and both count in a balance of trade. The sale of Bangla titles is an export, and the purchase of English-language titles is an import. Second, we subtract in one kind of money only. Exports are USD 2,500 and imports are USD 18,000. The balance is 2,500 minus 18,000, which is minus 15,500. The minus sign means that imports are larger, so there is a deficit of USD 15,500. Third, we convert. USD 15,500 times Tk 120 is Tk 1,860,000.

> The figure draws the shop's exports and imports as two columns, so the gap shows the deficit.
The figure shows the same facts as two columns. Read it as follows. The vertical line on the left is a scale of value in US dollars, from 0 at the bottom to 18,000 at the top. The left column is the shop's exports, and the right column is its imports. The height of each column is its value. The gap between the tops of the two columns is the balance of trade. When the right column is taller, the balance is a deficit.

:fig Balance of trade shown as two columns | ch12-fig01.svg

### Conclusion

> The shop bought far more from abroad than it sold abroad.
:case Case file, illustrative. The shop's own balance of trade is a deficit of USD 15,500 (Tk 1,860,000).

> The deficit is explained by what the shop must stock, but the exchange rate needs watching.
The deficit does not signal failure. The shop must stock English-language titles that its customers want, and it earns the money to pay for them from sales inside Bangladesh. The owner should still watch the exchange rate. If the taka buys fewer dollars at the next order, the same books will cost more taka.

### Check

> A second route to the answer confirms that the result is sensible.
Check by a second route. Convert each value to taka first. Imports are Tk 2,160,000 and exports are Tk 300,000. The difference is 2,160,000 minus 300,000, which is Tk 1,860,000. This equals the first answer. The sign is also sensible, because the shop bought 800 titles and sold only 150, and the purchase was worth much more than the sale.

* * *

## Summary

> The summary lists the main ideas of the chapter in a few lines.
Foreign trade is buying and selling between countries. Exports are goods or services sold abroad, and imports are goods or services bought from abroad. Nations trade because they differ, and because each gains by making the goods that cost it least in other goods, which is comparative advantage. Visible trade is goods, and invisible trade is services. The balance of trade compares exports and imports of goods, while the balance of payments records all money flowing in and out. The exchange rate converts one country's money into another's. Governments regulate trade with tariffs, quotas, state enterprises and agreements. For Bangladesh, foreign trade earns foreign money and supplies goods that the country cannot easily make.

## Think It Through

> This case asks you to apply a tariff to a price on paper.
A country makes few bicycles but imports many. An imported bicycle costs Tk 10,000 when it reaches the port, before any tariff. The government now charges a tariff of 20 per cent on imported bicycles. A local maker sells a similar bicycle for Tk 11,500.

:q 12.t1 | Find the tariff on one imported bicycle and the new price after the tariff.
:q 12.t2 | Before the tariff, which bicycle would a customer prefer? After the tariff? Say who gains and who loses.

## Where People Go Wrong

> Many students think that a deficit in the balance of trade always means losing money.
A common error says that a deficit in the balance of trade means a country is losing money. A deficit means only that the value of goods bought abroad is larger than the value of goods sold abroad. A country may import machines now in order to export more later. Judge a deficit by its cause.

> The balance of trade and the balance of payments are not the same record.
Another error treats the balance of trade and the balance of payments as one record. The first counts goods only. The second records all money flowing in and out, including payment for services, money from workers abroad, and money for investment and loans.

> Comparative advantage is about lower cost in other goods, not about being the best.
A third error says that a country has a comparative advantage only where it is the best producer. Rina is better at sewing than Salim, yet Salim has the comparative advantage in shirts. Compare the costs inside each country.

> Dollars and taka must never be mixed in one subtraction.
A fourth error mixes two kinds of money. A student subtracts Tk 300,000 from USD 18,000 and obtains a meaningless number. Subtract in one kind of money, then convert once. Other common slips are a wrong sign and a forgotten period, such as a year.

> The importer usually pays a tariff first, and the customer often pays it in the end.
A fifth error says that the foreign supplier pays a tariff. The importer pays it at the border and usually passes it to customers in the price. The foreign supplier is affected only if its price must fall to keep its sales.

## In History

> David Ricardo's example of 1817 used English cloth and Portuguese wine.
David Ricardo was an English economist and a successful stockbroker. In 1817 he published *On the Principles of Political Economy and Taxation*. At that time Britain restricted grain imports by law, and Ricardo argued against such limits. To make his case, he used a small example of two countries and two goods: Portugal, known for its wine, and England, known for its cloth.

> Portugal could make both goods with less labour, yet trade still helped both countries.
Ricardo imagined that in Portugal wine needed the labour of 80 men for a year, and cloth needed 90 men. In England cloth needed 100 men and wine needed 120 men. Portugal was therefore better at both goods. A reader who thinks like the opening puzzle would say that Portugal needs nothing from England.

> Comparing costs inside each country shows who should make which good.
Ricardo compared costs inside each country. In England, a unit of cloth takes 100 men for a year and a unit of wine takes 120, so England loses less than one unit of wine for each unit of cloth it makes. In Portugal, cloth takes 90 and wine takes 80, so Portugal loses more than one unit of wine for each unit of cloth. England therefore has the comparative advantage in cloth, and Portugal has it in wine. He concluded that England should export cloth and import wine, and that Portugal should do the reverse. Together the two countries would then produce more.

> Ricardo's figures were imagined to teach an idea, not measured from real costs.
His numbers were chosen to teach, not measured from real workshops. Yet the idea has lasted more than two centuries. It helps explain why Bangladesh, with a large workforce, sells garments and buys machines, and why the shop in our case buys English-language titles from abroad.

## Review Questions

> These questions climb from a familiar case to a case that combines earlier ideas.
:q 12.1 | Classify each transaction as visible trade or invisible trade: (a) a Dhaka shop buys books from a publisher abroad; (b) a foreign visitor pays a hotel in Cox's Bazar; (c) Bangladesh sells tea to the United Kingdom; (d) a foreign shipping company charges freight to carry garments; (e) a Bangladeshi bank charges a foreign business a fee.
:q 12.2 | Suppose that in another year Meghna and Sons imported books worth USD 18,000 and sold Bangla titles worth USD 6,000. Find the balance of trade in US dollars and in taka at Tk 120 per US dollar.
:q 12.3 | A tea exporter in Sylhet sells tea worth USD 60,000 abroad and imports a machine worth USD 25,000 in the same year. Counting only these two items, find the balance of trade in US dollars and in taka at Tk 120 per US dollar.
:q 12.4 | A customer in Dhaka imports a laptop priced at USD 500 at Tk 120 per US dollar. The tariff is 10 per cent of the taka price. Find the price in taka before the tariff, the tariff, and the total.
:q 12.5 | In your own words, explain why a doctor who types faster than her assistant should still leave the typing to him. Then link your answer to two countries.

:read Ricardo, David, On the Principles of Political Economy and Taxation, 1817
:read Smith, Adam, An Inquiry into the Nature and Causes of the Wealth of Nations, 1776
