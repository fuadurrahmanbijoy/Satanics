:chapter VI | Social Responsibility of Business
:mood If a business may choose its own goals, what does it still owe to everyone else?
:desc A business earns its money from people, uses the work of people and affects the lives of people who never entered its door. This chapter asks what a business owes to society, to its suppliers, to those who put money into it and to its own staff, and how a firm can tell whether it keeps these duties.
:plate ch06-plate.svg | A charitable school room of the nineteenth century, paid for by the giving of others

> Two earlier ideas are needed before this chapter.

*You will need* two earlier ideas. The first is the set of social aims a business may hold: see Chapter 3, 'Objectives of Business and What Makes It Succeed', section 3.2 'Social and Human Objectives'. The second is the outside forces that act on a business: see Chapter 5, 'The Business Environment', section 5.2 'Outside the Business'.

> A shop owner must choose between a legal profit and a harmful one.

Imagine the owner of a small shop that sells medicine. A supplier offers him a cheaper brand of cough syrup. The syrup costs half as much as the usual brand, and the owner could double his profit by selling it at the same price. Then he learns that the cheaper syrup has not been tested for safety. No law in his town forbids selling it. No inspector will visit this year. No customer will ever know. Should he sell it?

> The law does not answer every question about right and wrong in trade.

Most people answer quickly that he should not. Yet the answer reveals something important. The law did not stop him, and the market did not stop him, but his conscience did. A business meets many such moments. The law sets a minimum, and above that minimum there is a wide space where the owner chooses. This chapter studies how a business should choose in that space: what it owes to its neighbours, to its suppliers, to the people who lend it money and to its staff. It follows one documented case, a bookshop in Dhaka, and it ends with a real decision made in 1982.

## The Idea of Social Responsibility

> A person belongs to many groups at once, and each group expects something.

Think first of one person in daily life. She is a daughter, a neighbour, a colleague and a member of a community. Each role brings duties. She is expected to care for her parents, to keep the street clean and to do her share of work. No one may punish her for failing at some of these duties, but a person who ignores all of them loses the respect of others. A business is in a similar position, though it has more power than most people.

> Social responsibility is a duty to benefit society and not only the owners.
@ Social responsibility | A business's duty to act in ways that benefit society as well as its owners.
@ Responsibility | Word in use. In daily life, a task given to you, or a duty to care for someone. In business, a duty that a business owes to a person or group its actions affect.

**Social responsibility** is a business's duty to act in ways that benefit society as well as its owners. Here *society* means all the people who live in the places where the business works and who feel its effects. For example, a factory that treats its waste water before returning it to the river shows social responsibility, because it protects the people who live downstream. The word *responsibility* has a special meaning here. It does not mean a task assigned to one person. It means a duty that the business owes to others.

> Social responsibility is the way social aims turn into action.

Chapter 3 showed that a business may hold social aims beside its aim to earn profit.^1 Social responsibility is the way those aims turn into action. The business that holds a social aim decides to give, to protect or to treat people fairly. The business that holds no such aim may still keep the duty, because the law and public opinion expect it. Duty and aim often point in the same direction, though they are not the same thing.

^1: Recall: social aims, Chapter 3, section 3.2 'Social and Human Objectives'.

> A business owes duties because it depends on society and affects it.

Why should a business have these duties at all? There are two reasons. First, the business depends on society. Its customers come from society, its workers come from society, and the roads, courts and schools that support it were built by society. Second, the business affects society. Its smoke enters the air, its goods enter homes and its wages enter families. A group that takes so much from others, and changes so much for others, cannot fairly claim that its only duty is to itself. This is why social responsibility matters.

> Responsible conduct also builds goodwill and helps the business to survive.

A second argument concerns the business itself. A firm that is known for honest dealing earns the trust of its customers, and that trust is its goodwill. A firm that harms others may lose customers, suffer fines or lose its licence to trade. The effect on survival can be serious. Responsible conduct is therefore not only a gift to society; it often protects the business too. It takes time to build, and it can be lost in a day.

> Not every thinker agrees that business should carry social duties.

The idea has opponents, and a fair account must state their case. Some argue that the duty of a business is to earn profit for its owners within the law, and nothing more. They say that owners, not managers, should decide how to spend profit on good works, and that a manager who spends the money of others on social aims is spending what is not his. They also say that a business which tries to solve every social problem will neglect its real work. Governments, they say, exist to care for society.

> The case against is serious, but the case for answers part of it.

Defenders of social responsibility answer in three ways. First, many responsible acts also improve the business, as the argument about goodwill showed. Second, the law cannot foresee every case, as the shop owner's cough syrup shows. Third, a business that ignores society invites stricter laws, which cost it more in the end. Most modern writers hold a middle position: a business must first obey the law and stay alive, and then do what it reasonably can for others, in proportion to its size and its means.

:pause 6.p1 | State one argument for and one argument against the view that a business should spend money on social aims.

> The sketch shows the groups a business owes duties to, from the centre outward.

Now we read a sketch of the groups to whom a business owes duties. It is a set of circles, each inside a larger one, like the rings that spread when a stone falls into water. The smallest circle in the centre stands for the owners and lenders, the people nearest to the business. Each larger circle stands for a wider group, and the largest stands for society as a whole. The labels name the groups. A circle further from the centre is not less important; it is only further from the daily work.

:fig Circles of responsibility, from owners and lenders outward to society | ch06-fig01.svg

> Before moving on: this section gave three ideas.

*Before moving on.* Social responsibility is a business's duty to act in ways that benefit society as well as its owners. A business owes such duties because it depends on society and affects it, and responsible conduct also builds goodwill. Some argue that profit within the law is the only duty; most writers accept a middle view.

## Responsibility to Society

> A business that lives in a community owes the community a fair return.

The first group in the wider circle is the community: the people who live and work near the business. A business uses its roads, employs its people and shares its air and water. In return, a responsible business obeys local laws, pays its taxes, avoids noise and danger, and offers fair work to local people. Many businesses also give directly. A firm may give money to a hospital, give time to a school or lend a building for a public event. Such gifts are not required, and they differ widely in size.

> Gifts are one form of duty, but fair daily conduct is the larger form.

Gifts are the most visible form of duty, but they are not the most important. A firm that gives to charity while it pays its workers late, or sells unsafe goods, has not shown responsibility. The larger duty is fair conduct every day: honest advertising, safe goods, lawful hiring and the keeping of promises. A gift cannot repair a daily wrong. For this reason, when we judge a business, we look first at how it earns its money and only after that at how it spends part of it.

> Waste and pollution harm people who are not customers.

The second duty concerns the natural world. Every business uses materials and produces waste. Smoke, chemicals, plastic and unsold goods all have to go somewhere. Pollution, which means harm to air, water or land by waste, falls on people who never bought anything from the business and who had no choice. A responsible business reduces its waste, treats what remains and, where possible, collects materials for reuse. Recycling is one example. It means processing used material, such as paper, so that it can be made into new goods.^2

^2: Recall: the natural surroundings of a business, Chapter 5, section 5.2 'Outside the Business'.

> Sustainability asks a business to meet today's needs without harming the future.
@ Sustainability | Running a business so that it meets today's needs without harming the ability of later generations to meet theirs.

Thinking about waste leads to a wider idea. **Sustainability** means running a business so that it meets today's needs without harming the ability of later generations to meet theirs. A paper maker that cuts trees without replanting meets today's need and harms tomorrow's. A paper maker that plants a tree for each tree cut may continue for many years. Sustainability is a test of time: it asks whether the way the business works could continue for a hundred years without exhausting what it depends on.

> The law on pollution and waste differs by country and changes over time.

Laws on waste and pollution differ widely. Some countries set strict limits and inspect factories often. Others have limits that are weak or poorly enforced. A business that obeys only the law may therefore do very little in one country and a great deal in another. A responsible business does not ask only what the law allows in each place. It asks what harm its work causes and whether it can reduce that harm at a reasonable cost.

> A person who uses goods is a consumer, and consumers hold certain rights.
@ Consumer | A person who uses goods or services, whether or not that person also paid for them.

The third duty concerns the people who use the goods. A **consumer** is a person who uses goods or services, whether or not that person also paid for them. A customer is the person who buys; the consumer is the person who uses. A father who buys milk is the customer, and his child who drinks it is the consumer. The difference matters, because a business that wishes to be responsible must think of the child as well as the father. Both may suffer if the milk is unsafe.

> Consumers are commonly said to have rights to safety, information and a fair hearing.

Many countries and international bodies have listed the rights of consumers. Four are widely accepted. The right to safety means that goods must not harm the person who uses them. The right to information means that labels and advertisements must be truthful. The right to choose means that a buyer should have real alternatives. The right to be heard means that a complaint should receive a fair answer. A responsible business respects these rights even where the law does not enforce them, and the exact legal rights differ by country.

> Before moving on: this section gave three duties to society.

*Before moving on.* A business owes its community fair conduct every day, and gifts are a smaller part of this duty. It owes the natural world care with waste, and the idea of sustainability tests whether its methods could last. It owes consumers safety, truthful information, choice and a fair hearing, whether or not the law forces it to do so.

## Responsibility to Suppliers

> A supplier sells inputs to the business and depends on its fair dealing.

A supplier is a person or firm that sells materials or goods to a business. A bookshop buys its books from publishers, and a bakery buys its flour from a mill. The relation is one of trust, since the supplier delivers goods first and usually receives payment later. The supplier is therefore also a lender, though no one calls the supplier by that name. This is why the business owes the supplier particular duties.

> Fair dealing means honest terms, honest weights and honest quality claims.

The first duty is fair dealing. It means that the business agrees terms that it intends to keep, that it does not use its size to force an unfair price, and that it does not return goods without good cause. A large business often has great power over a small supplier. If a large shop is the supplier's main customer, the supplier may accept a very low price because it fears the loss of the order. A responsible business does not use this power to harm the supplier's survival, since a supplier that fails cannot supply tomorrow.

> Prompt payment means paying on the day that was agreed.

The second duty is prompt payment, which means paying the supplier on or before the date that was agreed. Late payment is a form of borrowing without permission. The supplier must wait for money that it has earned, and it may have to borrow to pay its own staff. A small supplier may suffer severely from a delay of a few weeks. A business that pays late may save a little in the short term, but it damages the trust on which its supply depends.

> A promise to pay in thirty days is a promise, and its keeping is measurable.

This duty is easy to measure. If the agreed payment time is 30 days and the business pays on average after 47 days, then it pays 17 days late, because 47 − 30 = 17. A late average of 17 days is more than half of the agreed time. The numbers do not by themselves prove an unfair motive: the business may have had a cash shortage, or a delay in its own invoices. They show, however, whether the promise was kept, and a responsible business records and reviews this figure.

> Before moving on: this section gave two duties to suppliers.

*Before moving on.* A supplier sells materials or goods to a business and usually waits to be paid. The business owes the supplier fair dealing, which means honest terms and no abuse of power, and prompt payment, which means paying on the agreed date. The average payment time compared with the agreed time shows whether the promise was kept.

## Responsibility to Investors and Stakeholders

> Those who put money into a business also have claims on it.
@ Investor | A person who puts money into a business expecting to receive a return.
@ Investment | Word in use. In daily life, time or effort spent for a later benefit. In business, money put into a business in order to receive a return.

An **investor** is a person who puts money into a business expecting to receive a return. A *return* is the extra money that comes back to the investor, such as a share of profit or interest. For example, a person who buys a share in a company, or who lends money to a shop, is an investor. The word *investment* has a special meaning in business: it means the money put in, not the time or effort. Owners who put in their own money are investors in their own business, and a bank that lends money is also an investor in this sense.

> Owners and lenders are owed honest accounts, a fair return and care of their money.

What do owners and lenders have a right to expect? First, honest accounts: they must be told truthfully how the business is doing. Second, care of their money: the managers must not waste it or place it in needless danger. Third, a fair return: the owners may expect profit when the business earns one, and lenders may expect interest and repayment on the agreed dates. A business that hides losses or pays its lenders late breaks all three duties. The duty to a lender is firm, because the lender's claim is a debt.

> Employees give their time and skill, and they too have claims.

The next group is the employees. An employee is a person who works for the business in return for pay. A responsible business pays wages on the agreed date, provides a safe workplace, treats its workers with respect and does not require work that is dangerous or unlawful. It also gives fair chances to advance. The employees are inside the business, so their treatment shapes its internal environment, and a firm that treats them badly will find work done carelessly or staff leaving.^3

^3: Recall: internal and external environment, Chapter 5, 'The Business Environment'. Employees belong to the internal environment; the community and consumers to the external environment.

> A stakeholder is any person or group affected by what the business does.

All the groups of this chapter share one feature: each is affected by the business. Writers call such a group a *stakeholder*, which means any person or group with something to gain or lose from the business. This book uses the word only in this plain sense. Owners, lenders, employees, suppliers, consumers and the community are all stakeholders. The word is useful because it reminds us that the owners are not the only people with a claim.

> The groups sometimes want opposite things, so the business must balance them.

The groups do not always want the same thing. Employees may want higher wages, while owners want higher profit. Consumers want low prices, while suppliers want high prices. A community may want a quiet street, while the business wants longer hours. No business can satisfy every group in full. Balancing means weighing each claim, giving each fair attention and explaining the decision honestly. The balance will differ with the size and the means of the business, and a small shop cannot do what a large company can.

> A responsible business can be recognised by its records and conduct over time.

How can an observer recognise a responsible business? Four signs help. It keeps its promises to suppliers and pays on time. It treats staff fairly. Its goods are safe and truthfully described. It deals openly with owners and lenders and takes care of its surroundings. A single act proves little. A pattern over many years is the best evidence, because it is difficult to keep up a false appearance for long.

> Before moving on: this section gave the duties to owners, lenders and staff.

*Before moving on.* An investor puts money into a business expecting a return. Owners and lenders are owed honest accounts, care of their money and a fair return. Employees are owed fair pay, safety and respect. A stakeholder is any person or group affected by the business, and a responsible business balances their claims and can be recognised by its conduct over time.

* * *

## A Worked Case: The Meghna and Sons Record for 2025

> A worked case applies the ideas to a recorded situation and is not a model answer.

A worked case applies an idea to a situation. It has five parts: the situation, the question, the reasoning, the conclusion and a check. We apply the duties of this chapter to one case file.

> The situation is a record of the bookshop's dealings in 2025.
:case Case file, illustrative. Record for 2025, Meghna and Sons. Supplies were bought from 14 publishers. On 31 December 2025 the amounts owed to publishers were Tk 1,150,000. The agreed payment time was 30 days, and the actual average was 47 days. In March 2025 the shop gave 200 books, with a retail value of Tk 90,000, to a school library in Kalabagan. The shop sent 380 kg of unsold paper for recycling. A bank loan of Tk 600,000 is held.

> The table matches each fact in the record to the group it concerns.

The table below matches each fact to a group from this chapter. Read each row from left to right: the first column gives the fact, the second the group, and the third the duty.

:table Facts in the 2025 record, with the group and the duty
| Fact | Group | Duty |
| Owes Tk 1,150,000 to 14 publishers | Suppliers | Prompt payment |
| Pays in 47 days, not 30 | Suppliers | Prompt payment |
| Gave 200 books to a school library | Community | Gift |
| Sent 380 kg of paper for recycling | Society and nature | Care with waste |
| Holds a bank loan of Tk 600,000 | Lenders | Repayment on agreed terms |

> The question asks which duties the record shows kept and which it shows strained.

*Question.* From the record, which duties does the shop appear to keep, and which does it appear to strain?

> Reasoning first measures the lateness, then compares the gift with the profit.

*Reasoning.* First we measure the delay. The agreed time is 30 days and the actual average is 47 days, so 47 − 30 = 17 days late. As a fraction of the agreed time, 17 ÷ 30 = 0.57, which is 57 per cent when rounded to a whole number. Second, we compare the gift with the profit. The profit of Tk 750,000 in 2025 is a base fact of the case. The gift has a retail value of Tk 90,000, so 90,000 ÷ 750,000 = 0.12, which is 12 per cent. Retail value is the price at which the shop would sell the books, not the cost to the shop, so the true cost of the gift is lower. Third, we note the care with waste: 380 kg of paper went to recycling instead of the rubbish.

> The conclusion balances the strengths of the record with its weakness.

*Conclusion.* The record shows a firm that gives to its community and recycles its waste, which are real duties kept. It also shows a firm that pays its suppliers 17 days later than it agreed, which strains the duty of prompt payment. The record does not state why the payments are late, so we cannot say that the cause is carelessness. The duty to lenders cannot be judged from this record, since it does not state whether the bank loan is repaid on time. A responsible firm would examine why payment is late and try to close the gap.

> The check tests the sums against the figures in the record.

*Check.* We add back: 30 + 17 = 47, which agrees with the record. For the gift, 12 per cent of Tk 750,000 is 0.12 × 750,000 = Tk 90,000, which equals the retail value. The results are sensible: the lateness is large enough to matter, and the gift is a modest part of the year's profit.

* * *

## Summary

> The summary lists the main ideas of the chapter.

Social responsibility is a business's duty to act in ways that benefit society as well as its owners. A business owes duties because it depends on society and affects it, and responsible conduct also helps goodwill and survival. It owes the community fair daily conduct and care with waste, and it must keep sustainability in mind. It owes consumers safety, information, choice and a fair hearing, suppliers fair dealing and prompt payment, and investors, lenders and staff honest and fair treatment.

## Think It Through

> The questions below change the situation step by step.

Questions 6.t1 and 6.t2 use the case file in the worked section. Questions 6.t3 and 6.t4 change the setting.

:q 6.t1 | The shop reduces its average payment time from 47 days to 38 days. How many days late is it now, and what fraction of the agreed time is that, rounded to two decimal places?

:q 6.t2 | Suppose the shop had given 200 books but the retail value were Tk 150,000 instead of Tk 90,000. What fraction of the profit of Tk 750,000 would that be? Does the size of the gift alone show that the shop is responsible?

:q 6.t3 | A small supplier of paper is paid late by its main customer for several months. Describe the effect on the supplier, and say what the supplier could do and what the customer should do.

:q 6.t4 | A garment maker in a country with weak pollution laws can save money by releasing waste water into a river. Which groups are affected, which duties are involved, and what would a responsible firm decide?

## Where People Go Wrong

> Four common mistakes about social responsibility, each with its correction.

*Mistake.* Social responsibility means giving money to charity. *Correction.* Gifts are one part of it. Honest dealing, safe goods, prompt payment and care with waste are larger parts, and a gift cannot repair a daily wrong.

> The law is the minimum and not the full duty.

*Mistake.* If an act is legal, a business owes nothing more. *Correction.* The law sets a minimum. In the space above it, a responsible business considers the harm and benefit of its choices, as the shop owner with the cough syrup did.

> Responsibility is not opposed to profit in every case.

*Mistake.* A responsible business must always earn less. *Correction.* Many responsible acts protect goodwill and survival, and may raise profit over time. Some acts cost money, and the business must weigh the cost against its means.

> A customer and a consumer may be different people.

*Mistake.* The customer and the consumer are always the same person. *Correction.* The customer is the person who buys, and the consumer is the person who uses. A business owes duties to both.

## In History

> In 1982 a firm chose to recall its product at great cost to protect its customers.

Johnson and Johnson is a large company in the United States that made, among many products, a pain-relief medicine named Tylenol. In September 1982, seven people in the Chicago area died after taking Tylenol capsules that had been poisoned with cyanide. The first reported death was on 29 September. Investigators found that the poison had been added after the bottles reached the shops. No person was ever convicted of the poisonings.

> The company recalled the product before it knew the full cause.

On 5 October 1982 the company issued a recall of Tylenol products across the United States, covering an estimated 31 million bottles with a retail value of more than 100 million United States dollars. It stopped production and advertising, warned hospitals and the public, and offered to exchange capsules for solid tablets. The recall protected consumers, though it cost the firm a great deal. Afterwards, tamper-resistant packaging became common for medicines. The case shows a firm placing the safety of consumers before its short-term profit.

## Review Questions

> The questions below ask the reader to apply the chapter.

:q 6.1 | Explain social responsibility in your own words and give one example from a business you know.

:q 6.2 | Match each duty to the group it is owed to: prompt payment; honest accounts; a safe workplace; truthful labels; care with waste water. Choose from suppliers, owners and lenders, employees, consumers, and the community.

:q 6.3 | Give two arguments for and two arguments against the view that a business should accept social duties.

:q 6.4 | Explain the difference between a customer and a consumer, and give an example in which they are different people.

:q 6.5 | Explain sustainability and give an example of a business that is not sustainable.

:q 6.6 | Explain why late payment to a supplier is a breach of duty even if the law does not forbid it.
