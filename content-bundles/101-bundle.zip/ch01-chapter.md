:chapter I | What Business Is
:mood Who made the shirt you are wearing, and why did they sell it to you?
:desc This chapter explains in plain words what a business is and why people establish one. It shows how business work divides into trade, commerce and industry, and into four main branches. It follows one bookshop in Dhaka, Meghna and Sons, as a case file. It also teaches you how to read this book and its special words.
:plate ch01-plate.svg | A draper's shop in the 1880s, where cloth is bought and sold across a long counter

> This chapter needs no earlier knowledge, only your own experience of buying and selling.
*You will need:* nothing. This chapter begins at the beginning. It assumes only that you have bought and sold things in daily life.

> A puzzle: you made almost nothing that you use, yet all of it reached you.
Look at what you are wearing and holding at this moment. Perhaps there is a shirt, a pen, a phone and a cup of tea. Now ask a harder question: how many of these did you make yourself? For almost every reader, the honest answer is none.

> Many people worked to bring one shirt to you.
Yet every one of these things reached you. Someone grew the cotton for the shirt. Someone spun it into thread, wove the thread into cloth and sewed the cloth into a shirt. Someone carried the shirt to a shop. Someone in the shop handed it to you, and you handed over money in return.

> The puzzle: why do strangers work for you and then sell you the result?
Here is the puzzle. Dozens of people worked to produce that shirt, and not one of them knew you. Why did they not keep the shirt for themselves? Why does a stranger spend days of work on something and then give it to you for a few notes and coins?

> The answer is an arrangement in which each person does one kind of work and depends on others for the rest.
The answer is not kindness, although kindness exists. The answer is an old and very useful arrangement between people. Each person does one kind of work well, and each person depends on others for everything else. The arrangement has a name, and that name is the subject of this book. Section 1.1 begins with its simplest form: two neighbours and a bag of rice.

> The book marks new words, gives recaps and asks pause questions; slow going at first is normal.
A word about how to use this book. A new word appears in heavy type the first time it is used, and a plain definition follows at once. The same definition is repeated in a short note beside the text and again in the glossary. Each section ends with a short recap that begins with the words *Before moving on.* Questions marked Pause and check let you test yourself before you continue. Many students find the first chapters slow, because every word is new. That is normal, and the book goes slowly on purpose. A note in the margin that reads Go slowly here marks the places where it takes most care.

> Case-file paragraphs describe one invented bookshop whose facts stay the same in every chapter.
Paragraphs that begin with the words *Case file, illustrative.* describe one bookshop, Meghna and Sons, in Dhanmondi, a district of Dhaka, the capital of Bangladesh. The shop is an example made for this book. Its dates and figures are kept as in a file of records, and they are the same in every chapter.

* * *

## 1.1 Why People Do Business

> Two neighbours swap what each has in excess; the swap is exchange.
@! Go slowly here.
Imagine a village with two neighbours. One is a farmer whose field gave more rice than her family can eat. The other is a fisher whose boat brought more fish than his family can eat. Each has something extra, and each lacks something. The farmer has no fish, and the fisher has no rice. They agree to swap: 2 kg of rice for 1 kg of fish.

> An exchange is giving something to receive something; a need is something people must or strongly wish to have.
This swap is an example of exchange. An exchange happens when one person gives something to another person and receives something in return. Both people gain, because each now holds something more useful to them than what they gave. The reason for the swap is a need. A need is something a person must have, or strongly wishes to have, such as food, clothing, shelter or learning.^1

^1: Swapping one thing for another without using money has a special name, *barter*. Barter still exists today in some local markets, but it is slow, as the next paragraph shows.

> Money removes the need to find a partner who wants exactly what you have.
Direct swapping has a weakness. The farmer wants fish today, but the fisher may not want rice today. Each must find a partner who has what they want and who wants what they have. Money removes this weakness. Money is what everyone in a country accepts as payment. With money, the farmer sells rice to anyone who wants it. She then buys fish from anyone who sells fish. The number of possible exchanges grows greatly.

> Some people give all their working time to supplying others, and this is the start of business.
As exchanges grow, some people give all their working time to supplying things to others. One person grows rice only to sell it. Another weaves cloth only to sell it. A third teaches children and receives fees. For these people, exchange is no longer an occasional swap. It is their daily occupation, and their income depends on it.

> Goods are physical things, a service is work done for someone, and a customer pays for either.
@ Goods | Word in use. In daily life, "good" describes quality, as in a good meal. In business, goods are physical things that are bought and sold.
Before we name this occupation, three words need plain meanings. Goods are physical things that a person can touch and keep, such as rice, a shirt or a book. A service is work done for someone, such as teaching or cutting hair; the person receives the work, not a thing to keep. Section 1.3, 'Branches of Business', defines service fully. A customer is a person or organisation that pays for goods or services. People also say buyer or client; this book uses the word customer.

> Business is an activity that provides goods or services to others for money, aiming to earn a profit.
@ Business | An activity that provides goods or services to others in exchange for money, aiming to earn a profit.
The occupation has a name. **Business** means an activity that provides goods or services to others in exchange for money, aiming to earn a profit. A shop that sells exercise books to schoolchildren is a business. A family that grows rice only to eat is not, because it provides nothing to others in exchange for money. People also say enterprise, firm or concern; this book uses the word business. The word profit is explained in a few paragraphs.

:box DEFINITION
Business: an activity that provides goods or services to others in exchange for money, aiming to earn a profit.

> The definition has four parts, and a failed business still fits it.
Read the definition in parts. First, an activity: regular work, not one act. Second, goods or services: something is provided. Third, to others in exchange for money: the buyer pays. Fourth, aiming to earn a profit: the intention matters. A business that fails to earn a profit is still a business, because it aimed at one. A charity that gives its goods away free is not, because it asks for no money.

:pause 1.p1 | A neighbour cooks lunch every day for her own family. A café cooks lunch every day for strangers and takes payment. Which of the two matches the definition of business, and which part of the definition decides it?

> Profit is income less all costs, and a loss is the reverse.
@ Profit | What remains of a business's income after all its costs have been paid.
@ Profit | Word in use. In daily life, profit can mean any benefit, as in "she profited from the advice". In business, it means money only: income less costs.
Why does anyone establish a business? The main reason is **profit**. Profit is what remains of a business's income after all its costs have been paid. Income is the money a business receives from its customers. Costs are the money it pays out in order to operate, for example for goods bought from suppliers, for rent and for wages. A supplier is a business that sells goods to another business. People also say vendor; this book uses supplier.

> A fruit seller shows profit with the smallest numbers.
@! Go slowly here.
Take the smallest example we can. A fruit seller buys 10 mangoes from a supplier at Tk 20 each. Her cost is 10 × Tk 20 = Tk 200. She sells all 10 mangoes at Tk 30 each. Her income is 10 × Tk 30 = Tk 300. In words, profit equals income minus costs, so her profit is Tk 300 − Tk 200 = Tk 100. For this first example we ignore every other cost, such as the fare to the market.

> If costs exceed income, the result is a loss.
Now change one number. Suppose the market is quiet and she sells all 10 mangoes at Tk 15 each. Her income is 10 × Tk 15 = Tk 150. Her cost is still Tk 200. Her income is Tk 50 less than her cost, so she has a loss of Tk 50. A loss is the opposite of a profit: it happens when costs are greater than income. This is why the definition says "aiming to earn a profit". Aiming is not the same as earning.

> The shop's 2025 figures show profit with real-sized numbers.
:case Case file, illustrative. Meghna and Sons, a family-run bookshop in Dhanmondi, Dhaka, was opened on 4 April 1996 by its owner, Nurul Meghna, with Tk 400,000. The owner is the person who owns the business; people also say proprietor, but this book uses owner. In 2025 the shop's income from sales was Tk 14,400,000. Its costs were purchases Tk 9,800,000, rent Tk 720,000, wages Tk 2,940,000 and other costs Tk 190,000, a total of Tk 13,650,000. Profit for 2025 was Tk 14,400,000 − Tk 13,650,000 = Tk 750,000.

> The figure below shows business as a cycle: resources in, goods and services out, money back.
Everything in this section can be drawn as one cycle. To read the figure, begin at the left and follow the arrows. Solid arrows show goods, services and resources. Dashed arrows show money. The business takes in resources, such as workers, materials and a building. It uses them to provide goods or services. Customers receive these and pay money. Part of the money pays for new resources, and the cycle begins again. Any money left after all costs is the profit.

:fig The business cycle: resources go in, goods and services go out, money comes back | ch01-fig01.svg

> Recap: exchange, business, profit and loss.
*Before moving on.* People exchange because each has needs and each has something extra. Business is exchange made into a regular occupation: it provides goods or services to others for money and aims at profit. Profit is income less costs; if costs are higher, the result is a loss. You should now be able to say, in one sentence, what a business is and what profit means.

* * *

## 1.2 Trade, Commerce and Industry

> A puzzle: many different kinds of work stand behind one schoolbook.
Pick up a schoolbook from any shelf. Before it reached the shelf, it passed through many hands. Someone cut the trees that gave the wood pulp for the paper. Someone made the paper, and someone printed the pages and bound them. A driver carried the finished books to the shop. A shop assistant placed one on the shelf. These people do very different work. Is there a plain way to sort their work into groups?

> Three words sort this work: trade, commerce and industry.
Business people use three words for this sorting. We take them one at a time, because students often confuse them. We begin with the one nearest to your own experience, which is buying and selling.

> Trade is buying and selling goods to earn a gain from the difference in price.
@ Trade | The buying and selling of goods, carried out to earn a gain from the difference in price.
**Trade** is the buying and selling of goods, carried out to earn a gain from the difference in price. A trader buys notebooks from a maker at Tk 40 each and sells them at Tk 50 each. The difference of Tk 10 on each notebook is the trader's gain, before any costs are paid. A trader does not make the notebook. The trader brings it from the person who made it to the person who wants it.

> Five services help trade; they are called aids to trade, and each removes one difficulty.
Trade does not work alone. The trader's notebooks must be carried, stored, paid for, protected and made known to customers. The services that help trade in this way are called aids to trade. The next table shows the five main aids. Read each row from left to right: the aid, its work, and the difficulty it removes.

:table Five aids to trade and the difficulty each removes
| Aid to trade | What it does | Difficulty it removes |
| Transport | Carries goods from one place to another | Distance between maker and customer |
| Warehousing | Stores goods until they are wanted | Time between making and buying |
| Banking | Holds money, moves payments and lends | Shortage or risky handling of money |
| Insurance | Pays the owner if goods are lost or damaged | Risk of loss by fire, theft or accident |
| Advertising | Tells customers what is for sale | Customers not knowing what exists |

> Commerce is trade together with its aids.
@ Commerce | Trade together with the services that help goods move from producer to customer, such as transport and banking.
Goods begin with a producer, a person or business that makes or grows them. Put trade and its aids together and you have commerce. **Commerce** is trade together with the services that help goods move from producer to customer, such as transport and banking. The notebook trader, the lorry that carries the notebooks and the bank that holds the trader's money all belong to commerce. Notice that trade is part of commerce, not a rival to it.

> Industry produces or changes goods.
@ Industry | The branch of business that produces or changes goods, from raw material to finished product.
The third word is industry. **Industry** is the branch of business that produces or changes goods, from raw material to finished product. A raw material is a natural material before any work is done on it, such as cotton, clay or timber. The cotton farmer, the mill that spins the cotton and the factory that sews shirts are all in industry. The maker of a notebook is in industry. The trader who sells it is in trade.

> A table compares the three words using the schoolbook.
The next table compares the three words. Each row follows one word. Read across to see what the word covers and who in the schoolbook story belongs to it.

:table Industry, trade and commerce compared
| Word | What it covers | Who belongs to it in the schoolbook story |
| Industry | Producing or changing goods | The tree cutter, the paper maker and the printer |
| Trade | Buying and selling goods | The shop that buys books and sells them |
| Commerce | Trade together with its aids | The shop, the driver, the bank and the insurer |

> The groups overlap, because one business can perform more than one kind of work.
The groups are tidy in an example but untidy in life. A baker mixes and bakes bread, which is industry, and sells it from the same counter, which is trade. One business can therefore belong to two groups. We then ask what the main activity is, and we classify the business by that answer. Notice also the shape of the sorting: commerce contains trade, so the three words are not three equal boxes.

:pause 1.p2 | A courier firm carries parcels for shops. Is it industry, trade or an aid to trade? Give your reason in one sentence.

> Recap: industry produces, trade buys and sells, and commerce adds the aids to trade.
*Before moving on.* Industry produces or changes goods. Trade buys and sells them. Aids to trade, such as transport, warehousing, banking, insurance and advertising, remove difficulties that stand between producer and customer. Commerce is trade together with its aids. You should now be able to say which of industry, trade or an aid to trade describes a given activity, and to give the reason.

* * *

## 1.3 Branches of Business

> A puzzle: four workers do very different work, yet all four belong to business.
Consider four people on one morning. A fisher pulls a net from a river. A potter shapes a clay pot. A builder lays bricks for a school wall. A teacher explains fractions to a class. All four work, and all four are paid. Yet their work is not the same. How shall we sort it?

> Business divides into four main branches, shown as a tree.
Business people sort it into four main branches: extractive industry, manufacturing industry, construction and service. The figure below draws them as a tree. To read it, start at the top, where the whole of business stands, and follow the lines downward. Each lower box is a smaller kind of business. The dashed line near the bottom shows where commerce fits, a point we return to at the end of this section.

:fig The branches of business drawn as a tree | ch01-fig02.svg

> Extractive industry takes natural materials from the earth, sea or land.
@ Extractive industry | Business that takes natural materials out of the earth, sea or land, such as farming or fishing.
The first branch starts nearest to nature. **Extractive industry** is business that takes natural materials out of the earth, sea or land, such as farming or fishing. Mining coal, cutting timber and growing jute also belong here. The fisher's net, the farmer's plough and the miner's drill serve one purpose: to obtain a material that nature provides. Extractive industry usually comes first in a chain of work, because the other branches need its materials.

> Manufacturing industry turns materials into finished goods by making or assembling them.
@ Manufacturing industry | Business that turns materials into finished goods by making or assembling them.
The second branch changes materials into goods that people can use. **Manufacturing industry** is business that turns materials into finished goods by making or assembling them. Making means shaping materials, as a potter shapes clay or a mill spins cotton into thread. Assembling means joining ready-made parts, as a workshop joins wheels, frame and chain to form a bicycle. The potter, the paper mill, the garment factory and the printing press all belong to manufacturing industry.

> Construction builds structures that stay where they are built.
The third branch is construction. Construction is the building of structures that stay where they are built, such as houses, schools, roads and bridges.^2 It uses materials from the other two branches, for example bricks, steel and cement, and joins them on the site. The builder who lays the school wall is in construction.

^2: Some writers place construction inside manufacturing. This book lists it as a separate branch, because its product is fixed in one place and is not carried to customers.

> A service is work done for a customer; the customer owns no physical thing afterwards.
@ Service | Work done for a customer that gives value but is not a physical thing owned afterwards, such as banking or teaching.
@ Service | Word in use. In daily life, a service can be a religious ceremony, a bus route or polite help in a shop. In business, a service is work done for a customer.
The fourth branch is the most varied. A **service** is work done for a customer that gives value but is not a physical thing owned afterwards, such as banking or teaching. The teacher in our morning example provides a service. So do the doctor, the bank clerk, the barber and the driver. The aids to trade in section 1.2 are all services. That is why the tree places them under service, and why commerce, shown by the dashed line, joins trade to those aids.

> A table compares goods and services using new examples.
The next table compares goods with services. Read each row as a question asked about the same two kinds of output.

:table Goods and services compared
| Question | Goods | Services |
| What does the customer receive? | A physical thing | Work done for the customer |
| Does the customer own something afterwards? | Yes | No |
| Example | A bicycle | Repairing a bicycle |
| Another example | A school uniform | Teaching |

> Many businesses supply both, so we classify by what the customer mainly pays for.
Real businesses often supply both. A restaurant provides food, which is a good, and serving at the table, which is a service. When a business supplies both, ask what the customer mainly pays for, and classify by that answer. The restaurant is mainly selling meals; a hospital is mainly selling care.

> Recap: four branches, with goods and services distinguished.
*Before moving on.* Extractive industry takes materials from nature. Manufacturing industry makes or assembles finished goods. Construction builds fixed structures. Service is work done for a customer, and the aids to trade belong to it. You should now be able to name the four branches and to give one example of each.

* * *

## 1.4 Scope and Characteristics of Business

> The scope of business is the full range of activities it covers.
The scope of business is the full range of activities that it covers. From sections 1.2 and 1.3, that range is industry in three forms (extractive, manufacturing and construction), trade, the aids to trade and other services.

> Business has five common features: money, regular dealing, profit, risk and customers' needs.
The characteristics of business are the features that nearly all businesses share. First, business involves exchange for money. Second, it is regular: one sale by a person who does not normally sell is not a business. Third, it aims at profit. Fourth, it carries risk, because profit is not certain and a loss is possible. Fifth, it exists to satisfy customers' needs, because customers pay only for what they need or want.

> A good businessperson combines honesty, knowledge, judgement of risk, steady work and skill with people.
A good businessperson shows five qualities. Honesty, because customers return to those they trust. Knowledge of the goods or services sold. Judgement of risk, which means accepting risks that can be reasoned about and avoiding those that cannot. Steady work, because a business needs attention every day. Skill in dealing with people, including customers, suppliers and staff.

> Recap: scope, five characteristics and five qualities.
*Before moving on.* Scope is the range of activities that business covers. Business is regular, aims at profit, carries risk and serves customers' needs, all in exchange for money. You should now be able to name the characteristics of business and the qualities of a good businessperson.

* * *

## Worked Case: Classifying Meghna and Sons

> A worked case applies the chapter's ideas step by step to one situation.
A worked case applies ideas to a situation. It is not a model answer to a question; it shows how to reason, one step at a time. We use the case file of the bookshop.

> The situation: what the shop does, what it spends and which services it uses.
:case Case file, illustrative. Situation: Meghna and Sons buys new books and stationery from publishers and sells them to schoolchildren, families and libraries. In 2025 its sales were Tk 14,400,000 and its purchases were Tk 9,800,000. It used a bank, a courier and insurance, and the insurance of its stock cost Tk 36,000 a year. The shop manufactures nothing.

> The question has three parts: the group, the branch and the gap between selling and buying.
*Question.* Is the shop in trade, commerce or industry? Which branch does it belong to? What does the gap between sales and purchases show?

> Step one: the shop buys and sells goods without changing them, so it is in trade.
*Reasoning.* Step one. We ask what the shop does with goods. It buys books and stationery from publishers and sells them without changing them. Industry produces or changes goods, and the shop does neither. Trade is the buying and selling of goods for a gain from the difference in price, and the shop does exactly that. The shop is in trade.

> Step two: sales less purchases is Tk 4,600,000, and rent, wages and other costs reduce it to the profit.
Step two. We measure the gain from the difference in price. Sales less purchases is Tk 14,400,000 − Tk 9,800,000 = Tk 4,600,000. This is not yet the profit, because rent, wages and other costs remain. Those three costs total Tk 720,000 + Tk 2,940,000 + Tk 190,000 = Tk 3,850,000. So profit is Tk 4,600,000 − Tk 3,850,000 = Tk 750,000, which agrees with the figure in section 1.1.

> Step three: the bank, courier and insurer are aids to trade, which places the shop within commerce.
Step three. We examine the services the shop uses. The bank removes the difficulty of handling money. The courier removes the difficulty of distance. The insurance removes the risk of loss of stock. All three are aids to trade. Trade together with its aids is commerce, so the shop belongs to commerce through its trade.

> Step four: the shop mainly sells goods, so its branch is trade and none of the four industry branches.
Step four. We choose the branch. The shop does not take materials from nature, does not make goods and does not build. A shop assistant who helps a customer choose a book gives a small service, but customers pay mainly for the book. The main activity is therefore trade, with services around it.

> Conclusion and check: trade within commerce, and each part of the definition of business holds.
*Conclusion.* Meghna and Sons is in trade, inside commerce, and it uses three aids to trade. *Check.* Does the shop fit the definition of business? It is an activity, regular since 4 April 1996. It provides goods, books and stationery, to others, schoolchildren, families and libraries. It receives money, sales of Tk 14,400,000. It aims at profit and earned Tk 750,000 in 2025. All four parts hold.

:box IN SHORT
To classify an activity, ask three questions: does it make or change goods, does it buy and sell goods, or does it help goods move to customers?

* * *

## Summary

> The chapter in a few lines.
Business is an activity that provides goods or services to others in exchange for money, aiming to earn a profit. Profit is income less all costs, and a loss is the reverse. Trade is buying and selling goods. Commerce is trade together with its aids. Industry produces or changes goods and has extractive, manufacturing and construction forms. Service is work done for a customer. Business is regular, risky, aimed at profit and driven by customers' needs.

## Think It Through

> Two problems apply the chapter to new situations.
Reason from the definitions, and write your conclusion in a few sentences.

:q 1.t1 | A tailor makes shirts to order for individual customers. The tailor wants to grow by buying ready-made shirts from a factory and selling them in a second shop. Describe which branches of business are involved before and after the change.

:q 1.t2 | A bakery has a bad year, and its costs are greater than its income. Is it still a business? Use the definition and the word "aiming" in your answer.

## Where People Go Wrong

> Mistake one: confusing profit with income.
Some students think profit is all the money a business receives. It is not. Income is the money received. Profit is what remains after all costs are paid. In 2025 the shop's income was Tk 14,400,000, but its profit was Tk 750,000.

> Mistake two: treating trade and commerce as equals.
Some students treat trade and commerce as two separate groups. Commerce contains trade and adds the aids to trade. Every trader belongs to commerce, but not everything in commerce is trade.

> Mistake three: thinking a loss ends a business.
Some students believe a business that makes a loss has stopped being a business. The definition says aiming to earn a profit, not always earning one. A business with a loss is a business that has not yet reached its aim.

> Mistake four: thinking industry means only factories.
Some students think industry means only factories with chimneys. Farming, fishing and mining are also industry, in its extractive form. A fisher is in industry.

> Mistake five: thinking a service is not real business.
Some students believe that only things that can be held are real business. A teacher or a bank clerk provides a service, and a service is a full branch of business.

## In History

> In 1759 Josiah Wedgwood began his own pottery works, a manufacturing business.
Josiah Wedgwood was born in 1730 in Burslem, a pottery town in Staffordshire, a county in central England. In 1759 he began his own pottery works in Burslem. This was manufacturing industry. Wedgwood and his workers turned clay into plates, cups and ornaments, and then sold them to customers for money, aiming at profit. Each part of the definition in this chapter can be found in his work.

> In 1769 he opened a larger works named Etruria, with a village for its workers.
In 1769 Wedgwood opened a new and larger works in Staffordshire, which he named Etruria, working in partnership with Thomas Bentley, a merchant from Liverpool, a port city in north-west England.^3 A merchant is a person who buys and sells goods in trade. The works included a village where workers and their families could live. The name Wedgwood is still used on pottery today.

^3: Wedgwood named the works after Etruria, an ancient region of Italy, because he believed the ancient vases he admired were Etruscan. Historians say that belief was mistaken.

## Review Questions

:q 1.1 | In the case file, name the group (trade, commerce or industry) that best describes Meghna and Sons, and name the three aids to trade that the shop used.

:q 1.2 | Classify each activity as industry, trade or an aid to trade, and say which of them belong to commerce: (a) a farmer growing jute; (b) a stall selling bananas; (c) a courier carrying parcels for a bookshop; (d) a bakery baking bread; (e) a bank lending money to a shop.

:q 1.3 | Suppose, as a what-if only, that Meghna and Sons began to print its own notebooks in a workroom behind the shop. Which new branch would it enter, and would it still be in trade?

:q 1.4 | Give one example of a good and one example of a service that are not in this chapter, and explain the difference between the two.

:q 1.5 | A vegetable stall in a market buys from farmers each morning. List the aids to trade the stall is likely to use, and say which difficulty each one removes.

:q 1.6 | A stationery stall buys 50 notebooks at Tk 20 each and sells all 50 at Tk 25 each. It also pays Tk 100 to carry the notebooks to the stall. Find the profit, showing each step.

:q 1.7 | Follow a cotton shirt from field to customer. Name each stage, state its branch of business, and name two aids to trade used along the way.

:q 1.8 | Name four characteristics of business, and explain why risk is one of them.
