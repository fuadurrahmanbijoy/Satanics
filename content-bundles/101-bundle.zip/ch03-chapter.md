:chapter III | Objectives of Business and What Makes It Succeed
:mood If profit is the point of a business, why would a shop give books away?
:desc This chapter explains why a business exists and what aims it sets for itself. It separates economic, social and human aims and shows how a business balances them. It then describes what a business needs in order to last: planning, goodwill and sound finance. The bookshop Meghna and Sons supplies the case file.
:plate ch03-plate.svg | A Victorian model village beside a works: cottages, a green and a tall chimney

> This chapter builds on profit from Chapter 1 and on capital from Chapter 2.
*You will need:* Chapter 1, 'What Business Is', section 1.1 'Why People Do Business', where profit is defined; and Chapter 2, 'Factors of Production', section 2.3 'Capital and Enterprise', where capital and enterprise are taught.

> A puzzle: the shop wrote down four aims for 2026, and only one is about profit.
:case Case file, illustrative. Meghna and Sons wrote down four aims for 2026. First, raise profit from Tk 750,000 to Tk 900,000. Second, supply 12 schools' libraries; in 2025 it supplied 4 schools. Third, train 7 staff in customer service, for 14 hours each. Fourth, give 200 books a year to a school library.

> The fourth aim costs the shop money and brings in nothing directly.
Read the four aims slowly. The first aim raises profit directly. The second aim adds to the shop's customers. The third uses 14 hours of each staff member's time. The fourth is the strangest. The shop will give away 200 books that it has bought, and it will receive no money for them.

> The puzzle: if business aims at profit, why write down aims about training and gifts?
In Chapter 1 we learned that a business aims at profit. Here is the puzzle. If profit is the point, why does the shop write down aims about training and gifts? Is the shop careless with its money? Or does it understand something about business that the definition alone does not show?

> The chapter answers in three steps: why profit matters, what other aims exist and what a business needs to last.
This chapter answers in three steps. Section 3.1 explains why profit matters. Section 3.2 explains the other aims and how they fit with profit. Section 3.3 explains what a business needs in order to last, because an aim is useless to a business that does not survive. Many students find this chapter slow, because aims and good names cannot be touched. For that reason, every idea here is tied to a number or an example.

* * *

## 3.1 The Purpose of a Business

> A household shows what a good plan looks like: an amount, a time and a purpose.
> Recall: profit, Chapter 1, 'What Business Is', section 1.1 'Why People Do Business'.
@! Go slowly here.
Begin with a household. A family says, "We will save Tk 1,000 each month for 12 months, to pay school fees." This is more useful than saying, "We will save some money one day." The first plan has an amount, a time and a purpose. We can also check it: after 12 months the family holds Tk 12,000, or it does not.

> An objective is a clear aim to be reached within a stated time.
@ Objective | A clear aim that a business tries to reach within a stated time.
@ Objective | Word in use. In daily life, "objective" can mean fair and free of personal feeling, as in an objective report. In business, an objective is an aim.
A business makes plans of the same kind. An **objective** is a clear aim that a business tries to reach within a stated time. The wish "the shop should do better" is not an objective, because it has no amount and no time. The aim "raise profit from Tk 750,000 to Tk 900,000 during 2026" is an objective, because it has both.

> An economic objective is an aim measured in money, such as profit, sales or market share.
@ Economic objective | An aim that can be measured in money, such as profit, sales or market share.
Some objectives can be counted in money. An **economic objective** is an aim that can be measured in money, such as profit, sales or market share. Sales means the money a business receives from selling. Market share means the part of all sales in one area that a single business wins. If readers in a town spend Tk 1,000,000 on books in a year, and one shop receives Tk 200,000 of it, the shop's market share is 20%.

> Survival is the ability to keep operating by covering costs year after year, and profit makes it possible.
@ Survival | A business's ability to keep operating by covering its costs year after year.
@! Go slowly here.
Why is profit the first economic objective? The reason is survival. **Survival** is a business's ability to keep operating by covering its costs year after year. Take the smallest example. A stall receives Tk 1,000 a month and pays costs of Tk 1,100 a month. It loses Tk 100 each month. If the owner holds Tk 300 in savings, the savings last 3 months, and then the stall must close. A stall that earns a profit has the opposite experience. Each month leaves money in hand for repairs, for a bad month and for the owner's reward.

> The rule: profit is the owner's reward and, first, the sign of survival.
Here is the rule. Profit is the owner's reward, but before that it is the sign of survival. A business that covers its costs this year and next year is able to continue. A business that does not is slowly spending the money it started with.

:pause 3.p1 | A stall receives Tk 2,000 a month and pays costs of Tk 2,250 a month. The owner holds savings of Tk 1,000. If nothing changes, after how many months are the savings used up?

> Return on capital compares a year's profit with the money invested, as a percentage.
> Recall: capital and enterprise, Chapter 2, 'Factors of Production', section 2.3 'Capital and Enterprise'.
@! Go slowly here.
Owners ask a second question: is the profit large enough for the money I put in? Capital is the money and equipment that the owner puts into the business; Chapter 2 teaches it fully. The measure is called return on capital. In words, return on capital equals profit divided by capital, multiplied by 100. In symbols, R = P ÷ C × 100, where R is the return as a percentage, P is the profit for a year and C is the capital. With the smallest numbers, a profit of Tk 100 on capital of Tk 1,000 gives 100 ÷ 1,000 × 100 = 10%. Each Tk 100 of capital earned Tk 10 of profit. The worked case at the end of this chapter applies the formula to the shop.

> Growth means becoming larger; it serves more customers but needs money to support it.
Growth is the second aim of this kind. Growth means an increase in the size of a business, measured by sales, customers, staff or number of shops. A business grows in order to serve more customers, to compete with larger rivals and to earn a larger profit. The shop's second aim is a growth aim. It plans to supply 12 schools' libraries, which is three times the 4 schools of 2025, and the sales to those libraries can be measured in money.

> Fast growth is dangerous when a business grows faster than its money allows.
Growth has limits, and fast growth can threaten survival. A business that grows must usually buy stock or hire staff before the new customers have paid. It then needs enough money to wait. A larger business that cannot pay its bills fails, while a smaller business that pays them survives. Section 3.3 returns to this point under the heading of sound finance.

> Owner, manager and employee look at these aims differently.
Different people see these aims differently. The owner looks first at profit and return on capital. A manager, who directs the daily work, looks at sales and market share, which the manager can influence. An employee, who is paid to work for the business, looks at whether the business will last long enough to keep the job.

> Recap: objective, economic objective, survival, return on capital and growth.
*Before moving on.* An objective is a clear aim with an amount and a time. An economic objective is an aim measured in money. Profit is the first such aim because it makes survival possible, and return on capital tests whether the profit is large enough for the money invested. Growth increases the size of a business but needs money to support it. You should now be able to say why a business needs profit even when it has other aims.

* * *

## 3.2 Social and Human Objectives

> A puzzle: why would a business give away books it paid for?
Return to the fourth aim in the case file. The shop will give 200 books a year to a school library and will receive nothing. Why would a business give away books that it paid for?

> A social objective is an aim to benefit people outside the business.
An aim to benefit people outside the business is called a social objective. Examples are gifts to schools, fair prices, honest dealing and care for the neighbourhood. The gift of 200 books is a social objective. It helps children to read, and the benefit goes to the school and not to the shop.^1

^1: Chapter 6, 'Social Responsibility of Business', studies the duties of business towards society in full.

> A human objective is an aim to benefit the people who work in the business.
A second group of aims concerns the people who work in the business. An aim to benefit them is called a human objective. Examples are fair pay, safe conditions, respect and training. The shop's third aim is a human objective. Training 7 staff for 14 hours each is 7 × 14 = 98 hours of learning, and the benefit goes first to the staff, who gain skill.

> A table compares the three kinds of aim using the case file.
The next table sets the three kinds of aim side by side. Read each row from left to right: the kind of aim, who gains most from it, and the aim from the case file that matches it.

:table Economic, social and human aims compared
| Kind of aim | Who gains most | Aim from the case file |
| Economic | The business and its owner | Raise profit from Tk 750,000 to Tk 900,000 |
| Economic (growth) | The business and its customers | Supply 12 schools' libraries |
| Social | People outside the business | Give 200 books a year to a school library |
| Human | The people who work in the business | Train 7 staff, 14 hours each |

> Aims can pull in different directions, because money spent on one aim is not available for another.
@! Go slowly here.
Now we meet a difficulty. Money spent on a gift or on training is money not kept as profit. The 200 books were bought with the shop's money. The 98 hours of training may be hours when staff are not selling. In this way, social and human aims may conflict with the economic aim. Many students find this hard at first, because it seems that a business must choose between doing good and earning money. The next paragraphs show why the choice is seldom so sharp.

> Three ways to balance the aims: limit the cost, choose aims that serve both, and keep survival first.
A business balances its aims in three ways. First, it limits the cost. The gift is 200 books a year, not all of the shop's stock, so the sacrifice has a known size. Second, it chooses aims that serve more than one purpose. Training that improves customer service also helps sales. Third, it keeps survival first, because a business that fails can help no one. Balancing means giving each aim its place and not allowing one aim to destroy another.

> The limit: a business must not raise profit by breaking the law or harming people.
There is a limit on the other side. A business must not raise profit by harming people or by breaking the law. Paying staff less than the law allows, or selling unsafe goods, may raise profit for a short time, but it is neither social nor human. In every country national law sets some minimum standards, and the owner must learn those of the country where the business operates.

> The figure below shows three kinds of aim as three overlapping rings.
The figure below draws the three kinds of aim as three rings. Each ring is one kind of aim. Where two rings overlap, one action serves both kinds at once. Training staff in customer service, for example, serves the human aim and, by pleasing customers, the economic aim. The centre, where all three rings overlap, is an action that serves every kind of aim together. The best plans try to place their actions where the rings meet.

:fig Economic, social and human aims as three overlapping rings | ch03-fig01.svg

:box THREE KINDS OF AIM
An economic aim is measured in money. A social aim benefits people outside the business. A human aim benefits the people who work in it.

> Recap: social and human objectives, and three ways to balance them with profit.
*Before moving on.* A social objective benefits people outside the business. A human objective benefits the people who work in it. These aims cost money and may conflict with profit, but a business can balance them by limiting the cost, choosing aims that serve more than one purpose and keeping survival first. You should now be able to name the three kinds of aim and give one example of each.

* * *

## 3.3 What a Business Needs to Succeed

> A puzzle: two shops with the same aims, one thriving and one closed.
Imagine two shops that open on the same day in the same street. Both write down the same aims. Five years later one thrives and the other has closed. What differed? Luck may play a part. But the two shops also differed in what they had in place, and those differences can be studied.

> A prerequisite is something needed before something else can happen; a business has several.
> Recall: factors of production, land and labour, Chapter 2, 'Factors of Production'.
@! Go slowly here.
Start with the meaning of one word. A prerequisite is something that must be in place before something else can happen. A journey has prerequisites: a map, fuel and a road. A business has prerequisites of success too. The factors of production, such as land and labour, supply the inputs, and a product that customers want gives the business a reason to exist. Beyond these, three prerequisites matter to every business: planning and foresight, customer goodwill and sound finance.

> Planning is deciding in advance what to do, and foresight is judging what may happen.
Planning is deciding in advance what to do, with what means, and by when. Foresight is looking ahead to judge what may happen. A plan answers four questions: What do we want? How much? By when? With what means? The shop's aim to supply 12 schools' libraries shows why this matters. Before the aim can be reached, the shop must decide how many books to buy, when to buy them and how to pay for them.

> Plans can fail when the world changes, so they must be reviewed.
Plans have limits. The future cannot be known, and a plan made in January may not fit September. A sensible owner therefore reviews the plan at fixed times and changes it when the facts change. Foresight is not prediction. It is preparation.

> Goodwill is the good name a business earns with customers, which brings them back and is worth money.
@ Goodwill | The good name a business earns with customers, which brings them back and is worth money.
The second prerequisite cannot be touched or counted in a cash box. **Goodwill** is the good name a business earns with customers, which brings them back and is worth money. A customer who found honest prices, careful advice and the right book in stock returns, and tells friends. Each return visit is a small payment that the shop did not have to win again.

> Goodwill takes years to earn and can be lost quickly.
Goodwill takes years to earn and can be lost at once. One act of dishonesty can undo what hundreds of honest sales built. For the owner, goodwill is something of value that does not appear on any shelf. If the owner sells the business, the buyer may pay more for a shop whose customers return than for one whose customers do not. The shop was opened on 4 April 1996, and every year since has added to its name or taken from it.

:pause 3.p2 | Name one thing a shop could do this week to earn goodwill, and explain how goodwill could later be worth money.

> Sound finance means having enough money at the right times, keeping records and borrowing with care.
@ Interest | Word in use. In daily life, interest means curiosity or attention, as in an interest in music. In finance, interest is the price paid for borrowing money, shown as a percentage of the amount borrowed each year.
The third prerequisite is sound finance. This means three habits. The first is to have enough money at the right times, so that bills are paid when they are due. The second is to keep records of money received and paid. The third is to borrow with care. Borrowed money must be repaid with interest. Interest is the price of borrowing, shown as a percentage of the amount borrowed each year. If a business borrows Tk 1,000 at 10% a year, it pays 1,000 × 10 ÷ 100 = Tk 100 in interest each year.

> Interest uses part of the profit, so borrowing must earn more than it costs.
Consider what this means. Suppose the borrowed Tk 1,000 helps the business to earn an extra Tk 80 of profit in the year. The business pays Tk 100 in interest to earn Tk 80, and it ends the year Tk 20 worse off. Borrowing is wise only when the extra profit is greater than the interest. Fast growth with borrowed money is therefore risky, as section 3.1 warned.

> A table compares the three prerequisites and what goes wrong without each.
The next table compares the three prerequisites. Read each row as a pair: what the prerequisite gives and what is likely to go wrong without it.

:table Three prerequisites of success
| Prerequisite | What it gives | What goes wrong without it |
| Planning and foresight | Direction and preparation | Surprises, and stock bought too late or in the wrong amount |
| Customer goodwill | Customers who return | Customers go elsewhere |
| Sound finance | Money to pay bills on time | Unpaid bills and survival at risk |

> Recap: prerequisites, planning and foresight, goodwill and sound finance.
*Before moving on.* A prerequisite is something needed beforehand. Planning and foresight give direction. Goodwill brings customers back and is worth money. Sound finance keeps bills paid and borrowing under control. You should now be able to name three prerequisites of success and say what goes wrong without each.

* * *

## Worked Case: Reading the Aims of Meghna and Sons for 2026

> A worked case applies the chapter to the shop's written aims for 2026.
A worked case applies the chapter to one situation, step by step. We use the aims in the case file.

> The situation: four written aims, the 2025 profit and the 2025 capital.
:case Case file, illustrative. Situation: the aims written down for 2026 are to raise profit from Tk 750,000 to Tk 900,000; to supply 12 schools' libraries, against 4 schools in 2025; to train 7 staff in customer service, for 14 hours each; and to give 200 books a year to a school library. The shop's profit in 2025 was Tk 750,000, and its return on capital in 2025 is found from capital of Tk 4,100,000.

> The question has four parts: classify the aims, measure the profit rise, count the training hours and find return on capital.
*Question.* (a) Is each aim economic, social or human? (b) By how much, and by what percentage, does the profit aim raise profit? (c) How many hours of training are planned? (d) What was the return on capital in 2025?

> Step one asks who gains from each aim.
*Reasoning.* Step one, part (a). We ask who gains. The profit aim is economic, because profit is measured in money. Supplying 12 schools' libraries is an economic growth aim, because the sales to those libraries can be measured in money. Training the staff is human, because the staff gain. Giving 200 books is social, because the school library, outside the business, gains.

> Step two finds the profit rise as Tk 150,000, which is 20%.
Step two, part (b). *Given:* profit now is Tk 750,000, and the target is Tk 900,000. *Find:* the rise and the percentage rise. *Formula:* in words, rise equals target minus present profit, and percentage rise equals rise divided by present profit, multiplied by 100. *Steps:* 900,000 − 750,000 = 150,000. Then 150,000 ÷ 750,000 = 0.2, and 0.2 × 100 = 20. *Answer:* the aim raises profit by Tk 150,000, which is 20%. *Check:* 20% of Tk 750,000 is Tk 150,000, which matches the rise.

> Step three multiplies 7 staff by 14 hours to give 98 hours.
Step three, part (c). The plan trains 7 staff for 14 hours each, so the total is 7 × 14 = 98 hours. *Check:* 10 × 7 = 70 and 4 × 7 = 28, and 70 + 28 = 98.

> Step four applies the return-on-capital formula to give 18.3%.
Step four, part (d). *Given:* profit Tk 750,000 and capital Tk 4,100,000. *Find:* return on capital for 2025. *Formula:* in words, profit divided by capital, multiplied by 100; in symbols, R = P ÷ C × 100. *Steps:* 750,000 ÷ 4,100,000 = 0.1829 to four decimal places. Then 0.1829 × 100 = 18.29, which rounds to 18.3.^2 *Answer:* the return on capital in 2025 was 18.3%. *Check:* 18.3% of Tk 4,100,000 is about Tk 750,300, which is close to Tk 750,000. The small difference comes from rounding.

^2: Rounding to one decimal place means keeping one digit after the decimal point and adjusting it by the digit that follows. Here 18.29 becomes 18.3.

> Conclusion and check: the aims cover all three kinds, and each has an amount and a period.
*Conclusion.* The four aims include two economic aims, one human aim and one social aim. The profit aim raises profit by 20%, the training totals 98 hours, and the 2025 return on capital was 18.3%. *Check.* Does each aim fit the definition of an objective in section 3.1? Each states an amount, and each is tied to 2026 or to a year, so each is an objective.

:box IN SHORT
To classify an aim, ask who gains: the business (economic), people outside it (social) or the people who work in it (human).

* * *

## Summary

> The chapter in a few lines.
An objective is a clear aim with an amount and a time. An economic objective is measured in money, and profit comes first because it makes survival possible. Social objectives benefit people outside the business, and human objectives benefit the people who work in it; a business balances all three kinds and keeps survival first. To last, a business needs planning and foresight, customer goodwill and sound finance.

## Think It Through

> Two problems apply the chapter to new situations.
Reason from the definitions, and write your conclusion in a few sentences.

:q 3.t1 | When does a social aim conflict with profit? Give one example from a shop, and say how the shop might reduce the conflict.

:q 3.t2 | A baker plans to double the number of customers in one year. Name two things the baker must have in place first, and explain why growth that is too fast could threaten survival.

## Where People Go Wrong

> Mistake one: believing that profit is the only objective.
Some students believe that profit is the only objective of a business. Profit comes first, because survival depends on it, but businesses also set social and human objectives. The shop's four aims for 2026 show all three kinds.

> Mistake two: treating a wish as an objective.
Some students treat any wish as an objective. A wish such as "do better" has no amount and no time. An objective states both, so that we can check afterwards whether it was reached.

> Mistake three: thinking survival means a large profit.
Some students think survival means earning a large profit. Survival means covering costs year after year. A small, steady profit can allow survival, and a large profit in one year does not guarantee it.

> Mistake four: confusing goodwill with friendliness alone.
Some students think goodwill is only friendliness. Goodwill is the good name a business earns with customers, which brings them back and is worth money. Friendliness helps, but honesty, quality and reliability matter as well.

> Mistake five: believing that social aims always reduce profit.
Some students believe that social aims always reduce profit. They cost money at first, but they may build goodwill, which brings customers back. The effect depends on the aim and on its cost.

## In History

> In 1879 the Cadbury brothers moved their chocolate factory to a new site and named it Bournville.
In 1879 the brothers George and Richard Cadbury moved their cocoa and chocolate factory out of the centre of Birmingham, a large city in central England. The new site lay about four miles to the south, and they named it Bournville. The firm was a business in the sense of Chapter 1: it made goods, sold them for money and aimed at profit.

> From 1893 George Cadbury bought land for a model village, built from 1895, to house workers decently.
In 1893 George Cadbury bought 120 acres of land close to the works. From 1895 homes were built there for workers, designed by a young architect, William Alexander Harvey. The aim was decent homes at prices that workers could afford, with open space around them.^3 This was a human objective placed beside the economic one.

^3: The Cadbury family were Quakers, members of a Christian religious group, and historians often link their concern for their workers to their faith.

> In 1900 the village was placed in the care of a trust, so that it would continue beyond the company.
In 1900 the village was placed under the Bournville Village Trust, a body that managed it independently of George Cadbury and of the company. The trust still exists. The lesson for this chapter is that the Cadbury firm earned profit from chocolate and also pursued the welfare of its workers, and it pursued both together.

## Review Questions

:q 3.1 | In the case file, separate the four aims for 2026 into economic, social and human aims, and give a reason for each.

:q 3.2 | Rewrite the wish "the shop should sell more" as an objective that has an amount and a time.

:q 3.3 | A stall has capital of Tk 2,000 and earns a profit of Tk 300 in a year. Find its return on capital, showing each step.

:q 3.4 | Give three prerequisites of success for a florist, and explain each in one sentence.

:q 3.5 | A small clothing workshop states four aims: raise sales by 10%; pay every worker a monthly bonus; give leftover cloth to a girls' school; open a second counter. Classify each aim as economic, social or human.

:q 3.6 | Explain in your own words why a business that does not survive can reach none of its other objectives.

:q 3.7 | A café plans to open three more branches in one year, using borrowed money. Using growth, sound finance and goodwill, explain two dangers of the plan.

:q 3.8 | Describe how goodwill is earned, how it is lost, and why it is worth money.
