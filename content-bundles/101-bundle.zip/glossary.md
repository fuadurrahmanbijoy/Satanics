:glossary 01
Business | An activity that provides goods or services to others in exchange for money, aiming to earn a profit. It is regular work, not a single act. A shop selling exercise books to schoolchildren is a business; a family growing rice only to eat is not.
Profit | What remains of a business's income after all its costs have been paid. In words, profit equals income minus costs. If a fruit seller's income is Tk 300 and her costs are Tk 200, her profit is Tk 100. If costs are greater, the result is a loss.
Trade | The buying and selling of goods, carried out to earn a gain from the difference in price. A trader does not make the goods but brings them from the maker to the customer. Buying a notebook at Tk 40 and selling it at Tk 50 is trade.
Commerce | Trade together with the services that help goods move from producer to customer, such as transport and banking. These helping services are called aids to trade. A notebook trader, the lorry that carries the notebooks and the bank that holds the trader's money all belong to commerce.
Industry | The branch of business that produces or changes goods, from raw material to finished product. It includes extractive industry, manufacturing industry and construction. A cotton farmer, a mill that spins thread and a factory that sews shirts are all in industry.
Extractive industry | Business that takes natural materials out of the earth, sea or land, such as farming or fishing. It often comes first in a chain of work, because other branches need its materials. Mining coal and cutting timber are further examples.
Manufacturing industry | Business that turns materials into finished goods by making or assembling them. Making means shaping materials, as a potter shapes clay. Assembling means joining ready-made parts, as a workshop joins wheels, frame and chain to form a bicycle.
Service | Work done for a customer that gives value but is not a physical thing owned afterwards, such as banking or teaching. The customer receives the work, not a thing to keep. A haircut, a doctor's visit and a bicycle repair are services.

:glossary 02
Factor of production | A resource used to make goods or provide services. Economists name four: land, labour, capital and enterprise. A tea stall uses all four: a spot, the seller's work, a kettle, and the decision to open.
Land | All natural resources a business uses, including ground, water, minerals and forests. Nature provides land; people do not make it. Its reward is rent, such as the rent of a shop space.
Labour | The physical and mental work people give to a business, paid for with wages. A shop assistant who lifts boxes and advises customers gives both kinds of work. Wages are the reward of labour.
Division of labour | Splitting a job into small tasks so that each worker repeats one task and becomes faster. Two workers, one folding and one gluing paper bags, make more bags than two workers who each do both tasks.
Capital | Man-made goods and money used to produce other goods, such as machines, tools and stock. A kettle, a shop's shelves and the books held for sale are capital. Interest is the reward of capital.
Enterprise | The act of organising the other factors and accepting the risk of loss in the hope of profit. Profit is its reward, and unlike rent, wages and interest it is not agreed in advance.

:glossary 03
Objective | A clear aim that a business tries to reach within a stated time. A good objective has an amount and a time. "Raise profit from Tk 750,000 to Tk 900,000 during 2026" is an objective; "do better" is only a wish.
Economic objective | An aim that can be measured in money, such as profit, sales or market share. Market share is the part of all sales in one area that a single business wins. If a shop receives Tk 200,000 of Tk 1,000,000 spent on books in a town, its share is 20%.
Survival | A business's ability to keep operating by covering its costs year after year. A business that earns less than its costs spends the money it started with and must close when that money is gone. Profit is the sign of survival.
Goodwill | The good name a business earns with customers, which brings them back and is worth money. It takes years to earn and can be lost at once. A buyer of a business may pay more for a shop whose customers return.

:glossary 04
Plant location | The place where a business builds its factory or opens its shop. The owner chooses it by weighing several factors, such as materials, customers, transport, workers, power, land and public rules. Example: a bakery that chooses a shop beside a railway station instead of a quiet village.
Footfall | The number of people who walk past or enter a shop in a given time. It measures the chance of sales, not the sales themselves. Example: an owner counts 410 people passing the door on an average day over five days.
Industrial estate | An area planned and serviced by an authority where many factories are grouped together. The authority provides roads, power, water and waste removal for all of them. Example: a group of workshops and small factories sharing one road and one power supply on a planned site.

:glossary 05
Environment | All the forces and conditions, inside and outside a business, that affect how it operates. It includes staff, prices, laws and machines as well as weather. The shop's environment includes its seven staff and an online seller's price cut.
Internal environment | Forces within the business that it can control, such as its staff, resources and rules. The owner can change opening hours or how stock is recorded, so these belong to the internal environment.
External environment | Forces outside the business, such as customers, laws and prices, that it cannot control directly. Examples are a competitor's price cut and a school curriculum change. The business can adapt to them or influence them within limits.
Stakeholder | Any person or group affected by a business or able to affect it, such as staff or customers. Owners, managers and employees are internal stakeholders; customers, suppliers, lenders and the government are external stakeholders.

:glossary 06
Social responsibility | A business's duty to act in ways that benefit society as well as its owners. The duty includes honest dealing, safe goods and care with waste. Example: a factory that treats its waste water before returning it to a river.
Sustainability | Running a business so that it meets today's needs without harming the ability of later generations to meet theirs. Example: a paper maker that plants a tree for each tree it cuts can continue for many years, but one that does not replant may exhaust its supply.
Consumer | A person who uses goods or services, whether or not that person also paid for them. The customer is the person who buys. Example: a father who buys milk is the customer; the child who drinks it is the consumer.
Investor | A person who puts money into a business expecting to receive a return, such as a share of profit or interest. Example: a person who buys a share in a company, or a bank that lends money to a shop.

:glossary 07
Private sector | The part of an economy owned and run by individuals and private firms rather than by government. A family bakery, a tailor and a privately owned bank belong to it.
Public sector | The part of an economy owned and run by government. A national railway or a government hospital belongs to it. Many countries have both a private sector and a public sector.
Sole proprietorship | A business owned and run by one person, who keeps all profit and bears all losses. The owner may employ staff, but the staff own no part of it. Example: a family bookshop with one founder-owner.
Unlimited liability | A duty on the owner to pay the business's debts from personal wealth if the business cannot pay them. There is no upper limit. Example: a business owes Tk 500,000 and holds Tk 200,000, so the owner must find Tk 300,000.
Trade licence | Official permission from a local authority to carry on a stated trade in a stated place. Example: a bookseller in Dhaka holds a licence naming the trade, books, and the address of the shop, and must renew it each year.

:glossary 08
Partnership | A business owned by two or more people who have agreed to run it together and to share its profits. The agreement may be spoken or written. Two friends who share a market stall and its earnings form a partnership, even if they never use the word.
Partnership deed | A written agreement among partners. It states the capital that each partner supplies, the duties of each partner, the shares in which profit is divided and the rules for ending the business. A signed deed settles later disputes about what each partner promised.
Mutual agency | The rule that each partner is the agent of all the other partners, so that each partner can act for the business and bind every partner. If one partner signs an order for books, all the partners must pay for it, even those who never saw the order.
Sleeping partner | A partner who supplies capital and shares in the profit but takes no active part in running the business. A retired neighbour who invests savings in a stall, and never serves customers, is a sleeping partner. Where the law gives unlimited liability, the risk remains.
Dissolution | The formal ending of a partnership, or of a company, after which it no longer operates as before. A partnership may be dissolved by agreement, compulsorily, on a stated event, by notice or by a court. Afterwards the partners settle the accounts in a fixed order.

:glossary 09
Joint stock company | A business whose capital is divided into equal parts, owned by many people, and treated by law as a person separate from them. It owns property, makes contracts and continues when owners change. Example: a bakery owned by two hundred people.
Limited liability | A rule that owners of a company lose, at most, the money they paid for their parts, never their personal wealth. The company's debts belong to the company. Exceptions include personal guarantees signed by owners and fraud. Example: a failed company cannot take its owners' houses.
Share | One equal part of a company's capital, giving its holder a claim on profit and a voice in decisions. A person who holds shares is a shareholder. Example: 100 shares of Tk 100 in a company of 1,000 shares give one tenth of the company.
Private limited company | A company that restricts the transfer of its shares and cannot invite the public to buy them. Owners may sell only by the company's rules. In Bangladesh the name ends with Private Limited. Example: three partners who convert a family business into a company.
Public limited company | A company that may invite the public to buy its shares, which are often traded on a stock exchange. Its owners can usually sell shares to others without asking permission. In Bangladesh the name ends with Limited. Example: a large bank.
Memorandum of association | The founding document stating a company's name, objects, registered office, liability and share capital. The objects are its purposes; the registered office is its official address. It describes the company's outer relations with the world.
Articles of association | The document setting the company's internal rules, such as the duties of directors and the holding of meetings. A private company uses it to restrict the transfer of shares. It describes the company's inner life.
Prospectus | A published invitation to the public to buy shares or debentures, describing the company and the risks. It usually states the objects, directors, number and price of shares, use of the money, risks and how to apply. A debenture is a loan to the company.

:glossary 10
Cooperative society | A business owned and run by members who join to meet a common need, each with one vote. It exists to serve its members and not to enrich outside owners. Example: thirty families who own the flour shop they buy from.
Cooperative principle | A basic rule of cooperatives, such as open membership, one vote per member and fair sharing of what remains after costs. The rules guide how the society is run. Example: a society that admits any family in the town, whatever its wealth, follows the rule of open membership.
Marketing cooperative | A cooperative that sells its members' products together to obtain better prices. Example: a hundred small jute farmers who collect, grade and sell their crop together can bargain with many buyers instead of accepting one trader's price.
Surplus | In a cooperative, what remains after costs, shared among members instead of paid to outside owners. Example: a society that charges members a little more than its costs may share the remainder by reserve, dividend and interest on shares.

:glossary 11
State enterprise | A business owned or controlled by government, usually to provide essential goods or services. A national post service or a government-owned railway is a state enterprise. State enterprises together form the public sector.
Nationalisation | The transfer of a privately owned business to government ownership. The government may take over a coal industry that private owners held, and many laws then require compensation to the former owners. The opposite step, selling a state enterprise to private owners, is called privatisation.
Departmental undertaking | A state enterprise run directly as part of a government department. The minister is responsible, the money comes from the government budget and the staff are government employees. It has no separate existence in law, so the government itself answers for its debts.
Public corporation | A state enterprise set up by law as a separate body with its own managers and accounts. It can make contracts, own property and be sued in its own name. It has no shareholders, because government is its only owner. The Tennessee Valley Authority is an example.

:glossary 12
Foreign trade | The buying and selling of goods and services between people or firms in different countries. It includes goods such as tea and wheat, and services such as shipping and banking. A bakery in Dhaka that buys wheat from a farmer abroad takes part in foreign trade.
Export | A good or service sold to a buyer in another country. The seller earns foreign money. Tea is a visible export, and a hotel room paid for by a foreign visitor is an export of a service. The same sale is an import for the country that buys.
Import | A good or service bought from a seller in another country. The buyer pays foreign money, or its value in local money. A Dhaka shop that orders books from a publisher abroad makes an import. The same sale is an export for the country of the seller.
Balance of trade | The difference in value between a country's exports and imports of goods over a period, such as a year. It leaves out services. If exports are larger, the balance is a surplus; if imports are larger, it is a deficit. Exports of 100 and imports of 130 give a deficit of 30.
Balance of payments | A record of all money flowing into and out of a country over a period. It covers payment for goods and services, money sent home by workers abroad, and money that moves for investment and loans. It is wider than the balance of trade, which counts goods only.
Exchange rate | The price of one country's money measured in another country's money. At an illustrative rate of Tk 120 per US dollar, USD 10 equals Tk 1,200. Rates change from day to day, so the taka price of an import can change even when the foreign price stays the same.
Tariff | A tax charged on imported goods, which raises their price. The importer pays it at the border and usually passes it to customers. With a tariff of 10 per cent, shoes costing Tk 2,000 at the port cost Tk 2,200 after the tax.

:glossary 13
Letter of credit | A bank's written promise to pay an exporter on the customer's behalf once stated documents are presented. The bank pays only if the papers match the letter in every detail. Example: a Kolkata bank promises to pay a Dhaka bookseller when the invoice and bill of lading arrive.
Customs clearance | The official checking of goods at a border and the payment of any duty before they are released. Duty is a tax charged on goods that cross the border. Example: printing paper is released to the importer only after the customs office has checked it and the duty is paid.
Commercial invoice | The seller's bill listing the goods, the quantity, the price and the terms for a shipment. The customs officer uses it to value the goods, and the bank uses it to check the letter of credit. Example: an invoice for 150 titles with the price of each.
Bill of lading | A document from a shipping line that receipts the goods, states their terms of carriage and shows who may claim them. It is a receipt, a record of the carriage contract and a document of title. Example: the customer needs it to collect books at the port.
Charter party | A contract by which a shipowner hires a whole ship, or part of it, to a merchant. A voyage charter hires the ship for one journey; a time charter hires it for a period. Example: a grain trader who hires a ship for one cargo.

:glossary 14
Multinational corporation | A company that owns or controls operations in more than one country, managed from a home country. It differs from an exporter, which keeps all its operations in one country. A shoe company with its head office in one country and its own factories in three others is an example.
Home country | The country where a multinational company has its headquarters, which is its main office. Each multinational company has one home country. A company with its head office in London has the United Kingdom as its home country, whatever the countries of its customers.
Host country | A country where a multinational company operates through a branch or subsidiary. A company has one home country but may have many host countries. A company based in London with an office in Dhaka has Bangladesh as one of its host countries.
Subsidiary | A company controlled by another company, called the parent, which owns most of its shares. The subsidiary is a company in its own right, under the law of its host country. If a parent owns 60 of every 100 shares, it controls the company.
Foreign direct investment | Money a foreign company invests to build or buy a lasting business in another country. Building a factory abroad is an example. Buying a few shares for a quick sale is not, because no lasting business is built or controlled.

:glossary 15
Initial public offering | The first time a company sells its shares to the public, so that they can later be traded. It happens once and takes place in the primary market. The price has a face value and a premium. Example: a family company that offers shares to strangers for the first time.
Stock broker | A licensed intermediary who buys and sells shares for clients and earns a commission, which is a fee for the service. The client decides what to buy or sell. Example: with a commission of 1 per cent, a purchase of Tk 10,000 costs Tk 100 in commission.
Stock exchange | An organised market where shares and bonds already issued are bought and sold. It has members, fixed hours and written rules, and trades pass through stock brokers. Example: the Dhaka Stock Exchange, where listed shares are traded.
Regulator | An official body that makes and enforces the rules for an industry or market. It can license, inspect and punish. Example: the Bangladesh Securities and Exchange Commission, which approves offers of shares and licenses brokers.
Export processing zone | A planned area with special rules and benefits to attract factories that make goods for export. Buildings, power and port links are ready, and some taxes and duties are reduced. Example: a foreign company that builds a shirt factory in a zone.

:glossary 16
Business combination | Two or more businesses joining under common control, in order to gain strength or reduce competition. The joining may be by purchase, by agreement or by owning shares. Example: two bookshops on one lane that come under one owner.
Merger | A combination in which one company absorbs another and only one remains. The absorbed company's property and staff pass to the survivor, and its name ends. Example: Alpha Books absorbs Beta Stationers, and only Alpha Books remains.
Takeover | Gaining control of a company by buying most of its shares. The company bought usually continues to exist. It is friendly if its directors agree and hostile if they refuse. Example: a buyer holds most of the shares of a bakery company.
Cartel | A group of independent firms that agree to fix prices or output to limit competition. Nothing is bought or merged, and each member stays free. In many countries it is unlawful. Example: three mill owners agree one price for cloth.
Horizontal integration | Combining firms at the same stage of making or selling the same kind of product. The joined firms were usually competitors. Example: two bookshops on one lane that become one business.
Vertical integration | Combining firms at different stages of making and selling one product, such as printer and bookseller. It moves toward the source of supply or toward the customer. Example: a bookseller that buys a printer.
