:answers 01
:a 1.p1 | The café. The definition asks for goods or services provided to others in exchange for money, and the café is paid by strangers; the neighbour provides lunch only to her own family and receives no money.
:a 1.p2 | An aid to trade, because it carries goods for shops and does not buy, sell or make them. As an aid to trade it belongs to commerce.
:a 1.t1 | Before: the tailor makes shirts, which is manufacturing industry, and sells them, which is trade. After: the tailor also buys ready-made shirts and sells them in a second shop, so trade grows. The factory that supplies the shirts is manufacturing industry, and transport, banking and insurance may be needed as aids to trade.
:a 1.t2 | Yes. The definition says aiming to earn a profit, not always earning one. A bakery that sells bread to customers for money and aimed at profit is a business, although this year it has a loss.
:a 1.1 | Trade, which is part of commerce. The aids to trade used were banking (the bank), transport (the courier) and insurance.
:a 1.2 | (a) Industry, extractive. (b) Trade. (c) An aid to trade (transport). (d) Industry, manufacturing. (e) An aid to trade (banking). Items (b), (c) and (e) belong to commerce, because commerce is trade together with its aids.
:a 1.3 | It would enter manufacturing industry, because printing notebooks makes finished goods. It would still be in trade as well, because it would continue to buy and sell books and stationery.
:a 1.4 | Example answer: a mobile phone is a good, and repairing the phone is a service. A good is a physical thing the customer owns afterwards; a service is work done for the customer, and no physical thing remains to own.
:a 1.5 | Likely aids: transport, to bring vegetables from farm to market (removes distance); banking, to hold the stall's money (removes risky handling of money); insurance, if the stall insures its stock (removes risk of loss). Advertising and warehousing may also apply.
:a 1.6 | Income = 50 × Tk 25 = Tk 1,250. Costs = 50 × Tk 20 + Tk 100 = Tk 1,000 + Tk 100 = Tk 1,100. Profit = Tk 1,250 − Tk 1,100 = Tk 150.
:a 1.7 | Growing cotton: extractive industry. Spinning, weaving and sewing: manufacturing industry. Selling the shirt in a shop: trade. Aids to trade could be transport (carrying shirts), banking (payments), insurance (stock) or advertising.
:a 1.8 | Any four of: exchange for money, regular dealing, aim of profit, risk, satisfying customers' needs. Risk is a characteristic because profit is not certain, and a business can make a loss.

:answers 02
:a 2.p1 | The kettle is capital, because people made it. The river water and the corner of pavement are land, because nature supplied them.
:a 2.p2 | Profit is not agreed in advance. It depends on how the year goes, so the person who receives it may gain a lot, a little, or make a loss.
:a 2.t1 | The machine is capital, and the three workers are labour. Buying the machine brings a cost of purchase or interest; the workers bring wages.
:a 2.t2 | The owner carries the risk, because profit is what remains after the payments agreed in advance. The owner supplies enterprise.
:a 2.t3 | The owner supplies labour for the work of operating the machine, and enterprise for organising the workshop and accepting the risk.
:a 2.1 | The landlord supplies land and earns rent. The shop assistant supplies labour and earns wages. The lender supplies capital and earns interest. The owner supplies enterprise and earns profit.
:a 2.2 | Labour is work paid with wages, which are agreed in advance, so a member of staff is paid even in a poor year. Nurul Meghna supplies enterprise: organising the shop and accepting the risk, with a profit of Tk 750,000 that was not agreed in advance.
:a 2.3 | Shop A relies mostly on the owner's labour, a little capital in the cart, and a rented spot as land. Shop B relies heavily on capital in shelves, scanners and stock, and on many staff as labour, with more land in its larger space. Both need an owner supplying enterprise.
:a 2.4 | The field is land and earns rent. The two helpers are labour and earn wages. The tractor is capital and earns interest. The farmer's decisions and risk are enterprise and earn profit.
:a 2.5 | Land: the rented shop space or stall. Labour: an assistant who sells the cloth. Capital: the stock of cloth or the shelves. Enterprise: the trader's organising of the business and acceptance of risk.
:a 2.6 | Division of labour splits a job into small tasks so that each worker repeats one. In the bag example, folding and gluing by two workers gave close to 60 bags in an hour instead of 40. One cost is that repeating one task can become dull.

:answers 03
:a 3.p1 | The stall loses Tk 2,250 − Tk 2,000 = Tk 250 each month. The savings last Tk 1,000 ÷ Tk 250 = 4 months.
:a 3.p2 | Example: answer a customer's question honestly and find the right book. The customer returns and tells others, and a buyer of the business would later pay more for a shop whose customers return.
:a 3.t1 | A social aim conflicts with profit when it costs money that would otherwise be kept as profit, as when books are given away. The shop can reduce the conflict by limiting the gift to a fixed number, choosing gifts that also build goodwill, and keeping survival first.
:a 3.t2 | The baker needs enough money (sound finance) to buy ingredients and pay helpers before new customers pay, and a plan for how many customers can be served well. Growth that is too fast can leave bills unpaid, which threatens survival, and poor service can damage goodwill.
:a 3.1 | Economic: raise profit to Tk 900,000 (measured in money), and supply 12 schools' libraries (a growth aim, measured through sales). Human: train 7 staff for 14 hours each, because the staff gain. Social: give 200 books a year to a school library, because people outside the business gain.
:a 3.2 | Example: "Raise the shop's sales by 10% during 2026." It has an amount (10%) and a time (during 2026).
:a 3.3 | R = P ÷ C × 100 = 300 ÷ 2,000 × 100 = 0.15 × 100 = 15%. Check: 15% of Tk 2,000 is Tk 300.
:a 3.4 | Any three, each with a reason. Examples: a product customers want (fresh flowers of good quality from a reliable supplier); planning and foresight (order more stock before busy times, since flowers do not keep); goodwill (customers return if the flowers last); sound finance (do not buy more than can be sold, and pay the supplier on time).
:a 3.5 | Raise sales by 10%: economic. Pay a monthly bonus: human. Give leftover cloth to a girls' school: social. Open a second counter: economic (growth).
:a 3.6 | Every other aim needs the business to exist. A business that cannot cover its costs year after year stops, so it can pay no wages, serve no customers and give no gifts.
:a 3.7 | Borrowed money must be repaid with interest, and new branches cost money before they earn, so the café may be unable to pay its bills (sound finance). Fast growth may also spread attention thin, so service falls and goodwill suffers.
:a 3.8 | Goodwill is earned by honest dealing and good service over years. It is lost by one act of dishonesty or poor treatment. It is worth money because customers return, and a buyer of the business would pay more for a business whose customers return.

:answers 04
:a 4.p1 | The bakery. Bread spoils within hours, so it must reach customers quickly. Bricks do not spoil, so a brick works can stand nearer its clay.
:a 4.t1 | Mirpur. Its rent of Tk 38,000 is the lowest of the three, and its rent per square foot, Tk 54.29, is also the lowest.
:a 4.t2 | 40,000 ÷ 800 = Tk 50.00 per square foot, which is below Mirpur's Tk 54.29, so Uttara now wins on rent per square foot. Footfall per Tk 1,000 of rent is 380 ÷ 40 = 9.50, below Mirpur's 13.68, so Mirpur still leads on that measure.
:a 4.t3 | Most important: a supply of skilled workers, reliable electricity and a stable internet link. Least important: nearness to raw material and footfall, because the office makes no heavy goods and sells to customers at a distance.
:a 4.t4 | The owner weighs the cost of moving (a new lease or building, and moving equipment), the goodwill that may be lost if customers do not follow, and the effect of the new road on sales income. These are set against lower cost on the cheaper land and the shared services of the estate.
:a 4.1 | Plant location is the place where a business builds its factory or opens its shop, chosen by weighing several factors. Example: a bookshop that chooses a busy street in Dhaka because many people pass its door.
:a 4.2 | A site is a fixed commitment because leaving it costs money and time. A business may lose customers who knew the old address, and with them some goodwill; it may also lose a lease or a building it has already paid for.
:a 4.3 | A reasonable order: nearness to customers, power, labour, land cost, transport, then services. First, because bread spoils and customers buy locally. Last, because banks and insurers can be reached by other means. Other orders can be defended with reasons.
:a 4.4 | A reasonable order: nearness to raw material, water and power, transport, land, labour, then nearness to customers. First, because ore and coal are heavy and costly to carry. Last, because steel can be carried over long distances.
:a 4.5 | A reasonable order: labour supply, communication, power, rent, then nearness to customers. First, because the work depends on skilled people. Last, because the office makes no goods that need a nearby market.
:a 4.6 | Footfall is the number of people who pass or enter a shop; sales are what customers actually buy. Many people may pass and buy nothing, so footfall shows an opportunity but not income.

:answers 05
:a 5.p1 | External. A competitor's price cut happens outside the business, and the business cannot control it directly. It is an economic force.
:a 5.t1 | The competitor is part of the external environment, in the economic group, because it concerns competition and price.
:a 5.t2 | Examples: the skill and number of staff, the stock the shop holds and how it is recorded, the money available, and the shop's culture of service.
:a 5.t3 | Adapt: change the stock, improve service or reduce costs. Influence: build goodwill with customers or join other shops in a trade association. Either answer should stay within the law.
:a 5.1 | Internal: (a), (c), (e), (h), (j). External: (b), (d), (f), (g), (i).
:a 5.2 | The textbook price cut and the curriculum change would matter less. The internal facts, 7 staff and stock listed on paper cards, would still matter for the remaining books.
:a 5.3 | The rise in flour prices is external, in the economic group. Hiring a new baker is internal, because the bakery decides it.
:a 5.4 | Internal: the owner, the managers, the employees. External: customers, suppliers, lenders, competitors or the government. Any five such stakeholders, correctly placed, are acceptable.
:a 5.5 | A fall in sales caused by an external change can reduce income until the business cannot continue, and lost customers weaken goodwill. A site with more footfall or a stronger local market may lower the risk, though no site removes it.

:answers 06
:a 6.p1 | For: the business depends on society and affects it, and responsible conduct builds goodwill. Against: the duty of a business is profit within the law, and spending the owners' money on social aims is not the manager's choice.
:a 6.t1 | 38 − 30 = 8 days late. 8 ÷ 30 = 0.27 of the agreed time (about 27 per cent).
:a 6.t2 | 150,000 ÷ 750,000 = 0.20, or 20 per cent of the profit. No. A gift alone does not show responsibility, because honest dealing, prompt payment and safe goods matter more than gifts.
:a 6.t3 | The supplier must wait for money it has earned and may have to borrow to pay its own staff, which harms its survival. It may raise the matter, ask for firm payment dates or seek other customers. The customer should pay on the agreed date or agree new terms in advance.
:a 6.t4 | Affected: people downstream (the community), consumers of the river's water and fish, and later generations. Duties involved: care with waste and sustainability. A responsible firm would treat its waste even though the law is weak and accept the extra cost.
:a 6.1 | Social responsibility is a business's duty to act in ways that benefit society as well as its owners. Example: a factory that treats its waste water before returning it to a river.
:a 6.2 | Prompt payment: suppliers. Honest accounts: owners and lenders. A safe workplace: employees. Truthful labels: consumers. Care with waste water: the community.
:a 6.3 | For: the business depends on society and affects it; responsible conduct builds goodwill and survival. Against: profit within the law is the owners' aim; a manager should not spend the owners' money on social aims; governments, not businesses, care for society.
:a 6.4 | The customer buys; the consumer uses. A father who buys milk is the customer, and the child who drinks it is the consumer.
:a 6.5 | Sustainability is running a business so that it meets today's needs without harming later generations' ability to meet theirs. Example: a paper maker that cuts trees without replanting.
:a 6.6 | The supplier delivered first and must wait for money it has earned, so late payment is borrowing without permission; it also damages trust, even where the law is silent.

:answers 07
:a 7.p1 | Tk 300,000. The debt of Tk 800,000 less the Tk 500,000 held by the business leaves Tk 300,000 for the owner to pay from personal wealth.
:a 7.t1 | New total debts: Tk 1,150,000. New ratio: 1,150,000 ÷ 4,100,000 = 0.28 (to two decimal places), assuming capital stays at Tk 4,100,000.
:a 7.t2 | The owner alone bears the loss of Tk 750,000. Unlimited liability adds that if the loss left debts the business could not pay, he would have to pay them from personal wealth.
:a 7.t3 | He must repay the Tk 2,000,000 from personal wealth if the farm cannot, which may mean selling land or savings. Before borrowing he could have borrowed less, saved a reserve, bought insurance for the crop, or chosen a form with limited liability.
:a 7.t4 | Helpful: full control, quick decisions, all profit. Limiting: unlimited liability across five shops, her own time, and the money one person can raise. She might consider other owners or another form, taught in later chapters.
:a 7.1 | Sole proprietorship, partnership, company and cooperative society are in the private sector. State enterprise is in the public sector.
:a 7.2 | Full control, so decisions are quick; all profit, so effort is rewarded; easy and cheap to begin; few legal steps; close contact with customers.
:a 7.3 | Unlimited liability means the owner must pay the business's debts from personal wealth if the business cannot, with no upper limit. Example: a business owes Tk 500,000 but holds Tk 200,000, so the owner finds Tk 300,000.
:a 7.4 | A barber's shop needs little money and personal attention, which one owner can provide. A power station needs very large sums and many skills, which one person cannot provide.
:a 7.5 | A trade licence is official permission from a local authority to carry on a stated trade in a stated place. A shop trading without a current licence may be fined or closed.
:a 7.6 | Mixed money hides the true result of the business, so the owner cannot tell whether it earns a profit.

:answers 08
:a 8.p1 | Yes. Under mutual agency each partner is the agent of all the others, so a contract signed in the ordinary course of the business binds every partner, including a partner who did not sign.
:a 8.t1 | Yes. Anwar acted in the ordinary course of the business, and the supplier did not know of the limit. The limit in the deed protects the partners against each other, not against an outsider who did not know of it.
:a 8.t2 | Anwar broke the deed and his duty to act for the common benefit. They may claim that he must bear the loss that his order causes, and they may agree a firmer rule for large orders.
:a 8.t3 | They may tell their regular suppliers of the limit in writing, so that an informed supplier cannot hold them to a larger order. They may also require a second partner to approve every large order.
:a 8.1 | 3 + 2 = 5 parts, and Tk 60,000 ÷ 5 = Tk 12,000 for one part. The first friend receives 3 × Tk 12,000 = Tk 36,000 and the second receives 2 × Tk 12,000 = Tk 24,000. Check: Tk 36,000 + Tk 24,000 = Tk 60,000.
:a 8.2 | They would share equally, Tk 30,000 each. The rule is that partners share profit equally when the deed is silent, whatever capital each has supplied.
:a 8.3 | 4 + 3 + 3 = 10 parts, and Tk 420,000 ÷ 10 = Tk 42,000 for one part. Nurul receives Tk 168,000, Rafiq receives Tk 126,000 and Tariq receives Tk 126,000. Check: the three shares add to Tk 420,000.
:a 8.4 | She would be a sleeping partner. Her liability would be unlimited, because the Partnership Act 1932 of Bangladesh makes no provision for limited partners. Mutual agency still binds her, because the acts of the baker bind all the partners.

:answers 09
:a 9.p1 | The business continues unchanged. The owner sells or gives up the shares, and the company, as a separate legal person, keeps its building, contracts and staff.
:a 9.t1 | For: limited liability protects the sisters' homes if the bank loan cannot be repaid. Against: a bank may still ask them for personal guarantees, so the protection may be weaker than it seems.
:a 9.t2 | A private limited company suits two owners who want control and no public offer. It limits their loss and keeps control with them. A public company would add costs and rules. They could change later if they need much more money.
:a 9.1 | A company is a separate legal person, so it continues when owners change, but a partnership has no existence apart from its partners. A company limits owners' loss to the money they paid; each partner may have to pay debts from personal wealth.
:a 9.2 | Company A is private: few owners, restricted transfer of shares, no invitation to the public. Company B is public: many owners, free transfer of shares, an open invitation to the public, and trading on a stock exchange.
:a 9.3 | Any five of: the name and objects, the directors, the number and price of the shares offered, the use of the money, the risks, how to apply.
:a 9.4 | A public limited company. Steps in order: promoters form the plan; write the memorandum and articles; register and obtain the certificate of incorporation; issue the prospectus and collect share money; obtain the certificate of commencement.
:a 9.5 | Owners (shareholders) and controllers (directors and managers) may be different people with different aims. Meetings, published accounts and independent checks of the accounts reduce the risk.

:answers 10
:a 10.p1 | Open membership protects the right of anyone with the need to join. One member one vote protects equal voice, so wealth cannot buy control. (Control by members, fair sharing and education are also correct.)
:a 10.t1 | 2,400,000 × 0.09 = Tk 216,000. 216,000 ÷ 10,000 = 21.6 times the cost of the shares.
:a 10.t2 | With limited liability the most it can lose on shares is 25 × 1,000 = Tk 25,000. It still has one vote, because each member has one vote whatever the number of shares held.
:a 10.t3 | The farmers could collect, grade and store their jute and sell the large amount together, so they gain bargaining power and a better price. A risk is poor management, or members selling to the trader instead of the society.
:a 10.t4 | Helpful: limited liability and the trust of members. Limiting: the society may raise little money, since members are poor and share holdings are restricted, and decisions may be slow. The bakers might consider a company, which can raise more money from many shareholders.
:a 10.1 | A cooperative society is a business owned and run by members who join to meet a common need, each with one vote. Example: thirty families who own the flour shop they buy from.
:a 10.2 | Purpose: a cooperative serves members; a company seeks a return for shareholders. Voting: one vote per member; votes in a company follow shares held. Return: surplus shared by use; profit paid by shares. Liability: limited in both, usually to the money paid for shares.
:a 10.3 | Open membership protects the right of anyone with the need to join. One vote per member protects equal voice. Fair sharing of the surplus protects members from outside owners taking the gain. (Control by members and education are also correct.)
:a 10.4 | Consumer: buyers who want fair prices. Producer: makers who want shared work and income. Marketing: growers who want better prices for their crops. Credit: savers and borrowers who want fair loans from shared savings.
:a 10.5 | The members form the general meeting and vote there. The meeting elects the management committee. The committee directs the society and reports to the members, so authority returns to where it began.
:a 10.6 | A surplus is what remains after costs, shared among members instead of paid to outside owners. Uses: a reserve for future losses and growth; a dividend in proportion to use; interest on shares; spending on education or the community.

:answers 11
:a 11.p1 | A public corporation. It is a separate body set up by law, with its own managers and accounts. A departmental undertaking is run as part of a government department.
:a 11.t1 | For keeping: the village routes serve people whom a private owner might not serve, and the service is essential. Government can accept a loss for a public aim. For selling: the loss is paid by taxpayers, and a private owner may manage staff and costs more closely.
:a 11.t2 | Government may pay a grant for the village routes only and let the company set fares freely on the busy routes, or it may reduce staff on routes where the work does not need them.
:a 11.t3 | A public corporation, because it has its own board and accounts and does not need ministry permission for each decision. A government company also has freedom, but a departmental undertaking has the least.
:a 11.1 | (a) A sole proprietorship. (b) A state enterprise, as a departmental undertaking or a public corporation. (c) A company, because it can raise large capital from many shareholders. (d) A cooperative society, because the farmers serve their own needs together.
:a 11.2 | The first arrangement is a departmental undertaking. The second is a public corporation.
:a 11.3 | The price difference is Tk 92 − Tk 85 = Tk 7 a bottle. The yearly saving is 2,000 × Tk 7 = Tk 14,000. Check: 2,000 × Tk 85 = Tk 170,000 and 2,000 × Tk 92 = Tk 184,000, a difference of Tk 14,000.
:a 11.4 | A state enterprise, probably a public corporation, suits it. Water is essential, needs large capital and serves everyone at a price that families can pay. One risk is loss from low prices or political orders, which taxpayers would then cover.

:answers 12
:a 12.p1 | No. If Salim's cost of one shirt were also 2 kilograms of rice, both neighbours would pay the same price in rice for a shirt. Neither would have a comparative advantage, so trade would bring no gain.
:a 12.t1 | The tariff is 20 per cent of Tk 10,000, which is Tk 2,000. The new price is Tk 10,000 plus Tk 2,000, which is Tk 12,000.
:a 12.t2 | Before the tariff, the imported bicycle at Tk 10,000 is cheaper than the local one at Tk 11,500. After it, the local bicycle at Tk 11,500 is cheaper than the imported one at Tk 12,000. The government gains tax and the local maker gains sales. The customer loses, because the lowest price rises from Tk 10,000 to Tk 11,500.
:a 12.1 | (a) visible; (b) invisible; (c) visible; (d) invisible; (e) invisible. Goods are visible trade, and services such as hotel stays, freight and bank fees are invisible trade.
:a 12.2 | Balance = 6,000 minus 18,000 = minus 12,000, a deficit of USD 12,000. In taka, 12,000 times 120 = Tk 1,440,000.
:a 12.3 | Balance = 60,000 minus 25,000 = plus 35,000, a surplus of USD 35,000. In taka, 35,000 times 120 = Tk 4,200,000.
:a 12.4 | Price before the tariff: 500 times 120 = Tk 60,000. Tariff: 10 per cent of Tk 60,000 = Tk 6,000. Total: Tk 66,000.
:a 12.5 | An hour of the doctor's time treating patients is worth more than an hour of typing, so she loses less by hiring the assistant. In the same way, two countries each gain by making the goods that cost them least in other goods and trading, even if one country is better at making everything.

:answers 13
:a 13.p1 | The letter removes the risk of not being paid by a stranger, because a bank promises payment. The risk that remains is that the papers may not match the letter, so the bank may refuse.
:a 13.t1 | The exporter asks the customer to amend the letter or corrects the invoice, then presents the papers again before the time limit ends. The exporter bears the delay and its costs, because the error was in the exporter's paper.
:a 13.t2 | Reason to accept: the customer may be reliable and the sale may be large. Reasons to refuse: the exporter then has no bank promise of payment, and the customer may fail to pay.
:a 13.1 | Accepting the order; receiving the letter of credit; shipping the goods; presenting the documents to the bank; receiving payment. The letter comes before shipping so that payment is promised before the goods leave.
:a 13.2 | Gain: less cost and paperwork. Risk: the exporter has no bank promise and must trust the customer to pay after the goods have been delivered.
:a 13.3 | Register as an importer and obtain any licence; send an indent to the supplier; ask the bank for a letter of credit; receive the goods and the papers; complete customs clearance and pay duty; collect the goods.
:a 13.4 | A charter party hires the ship; it proves that the ship was hired. A bill of lading receipts the goods; it proves loading, states the terms of carriage and shows who may claim the goods.
:a 13.5 | Tariff: government talks and information from the Export Promotion Bureau. Standard of quality: training in quality for exporters. Lack of finance: export finance through banks and Bangladesh Bank.

:answers 14
:a 14.p1 | The home country is Canada, where the headquarters stands. The host countries are Bangladesh and Kenya, where the company operates through a factory and a shop.
:a 14.t1 | Gains: jobs for 500 people and the wages they earn; money, skills and taxes that the company brings. Losses: profit sent to the home country; fewer chances for local managers; possible harm to local garment businesses.
:a 14.t2 | Two examples: a rule that the company train local managers, which protects local employees' chances to rise; and a rule that it meet standards for safety and pay, which protects workers and the environment. Other sensible conditions are accepted, if the protection is named.
:a 14.1 | Gains: jobs, money for building, skills, taxes, exports, better goods for customers (any three). Losses: profit sent abroad, strong competition for local owners, dependence on decisions made abroad, lower standards where the law is weak (any three).
:a 14.2 | No. A host country is one where the company operates through a branch or subsidiary. Shipping books from London is exporting, and Larkspur would control no operation in Bangladesh.
:a 14.3 | The parent is the company in India, and the subsidiary is the garment company in Bangladesh, because the parent owns 70 of every 100 shares and so controls it. The home country is India and the host country is Bangladesh. It is foreign direct investment, because the money buys a lasting business.
:a 14.4 | List value: 500 times GBP 16 is GBP 8,000, and 8,000 times 150 is Tk 1,200,000. Discount: 25 per cent of Tk 1,200,000 is Tk 300,000. Price after discount: Tk 900,000.
:a 14.5 | An exporter makes its goods at home and sends them across the border, so it controls no operation abroad. A multinational company owns or controls operations in more than one country, usually by owning most of the shares of a company or by running a branch.

:answers 15
:a 15.p1 | Tk 10 is the face value and Tk 15 is the premium. The sale is in the primary market, because the company sells new shares and keeps the money.
:a 15.p2 | The company receives Tk 1,000 in the primary sale of 100 shares. When Rina sells her 10 shares, Rina receives the Tk 120 and the company receives nothing.
:a 15.p3 | The Securities and Exchange Commission, the regulator, investigates the broker. The stock exchange runs the market where the trade took place.
:a 15.t1 | Reasons to list: shares become easy to trade, and the company can raise money from the public. Reason not to list: the company must publish information and follow the exchange's rules.
:a 15.t2 | Tk 20,000 ÷ Tk 400,000 = 5 per cent of profit. The owner should also weigh the information, contacts and voice with the government that membership gives.
:a 15.1 | Regulate: the Securities and Exchange Commission. Trade: the Dhaka Stock Exchange and a stock broker. Promote: the Export Promotion Bureau. Serve: FBCCI.
:a 15.2 | Total: 50,000 × Tk 30 = Tk 1,500,000. Face value part: 50,000 × Tk 10 = Tk 500,000. Premium part: 50,000 × Tk 20 = Tk 1,000,000. It is a sale in the primary market.
:a 15.3 | It is the secondary market. The selling owner receives 1,000 × Tk 35 = Tk 35,000, and the company receives nothing.
:a 15.4 | An export processing zone, where buildings, power and port links are ready and some taxes and duties are reduced; or the Export Promotion Bureau, which gives information on foreign markets and help with fairs.
:a 15.5 | The Securities and Exchange Commission approves the offer; the exchange lists and trades the new shares; stock brokers handle sales for investors; the export processing zone authority gives the site and its benefits.

:answers 16
:a 16.p1 | A cartel. The sellers agree on a price but each keeps their own stall, so they stay independent; nothing is bought or merged.
:a 16.t1 | Vertical. The mill and the bakery stand at different stages of one product, flour and bread, so joining them is vertical, toward the source.
:a 16.t2 | Opportunity: a secure supply of flour. Threat to the baker: being tied to her own mill when another is cheaper. Threat to the other bakers: the mill may refuse them flour or raise the price.
:a 16.1 | Horizontal. Both bakeries stand at the same stage, making and selling bread, so they were competitors.
:a 16.2 | Vertical, moving toward the source. Opportunity: a secure supply of paper. Threat: being tied to its own mill even when another is cheaper.
:a 16.3 | A cartel. Each owner stays independent and no mill is bought, while in a merger one company absorbs another and only one remains.
:a 16.4 | A takeover. The buyer controls the main decisions of the second company, which continues to exist; a buyer that holds shares in several companies in this way acts as a holding company.
:a 16.5 | Lower cost appears in the Tk 360,000 yearly rent saving. The payment of the price of Tk 1,800,000, and whether the customers and staff of Padma Stationers would stay, need more facts.
