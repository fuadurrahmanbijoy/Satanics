:chapter VII | Forms of Business Ownership and the Sole Proprietorship
:mood Who owns the business, and who pays when it fails?
:desc Every business belongs to someone, and the kind of owner changes who decides, who gains and who loses. This chapter surveys the main ways a business can be owned, then studies the simplest form in full: one owner, one business, and one person answerable for everything.
:plate ch07-plate.svg | A cobbler at work alone in his shop, the oldest picture of one-owner trade

> Two earlier ideas are needed before this chapter.

*You will need* two earlier ideas. The first is business activity: see Chapter 1, 'What Business Is', section 1.1 'Why People Do Business'. The second is what makes a business last: see Chapter 3, 'Objectives of Business and What Makes It Succeed', section 3.3 'What a Business Needs to Succeed'.

> A cobbler faces a choice about who will own his new shop.

Picture a cobbler, a maker and mender of shoes, who has saved enough money to open a small shop. He has the tools, the skill and a street full of walkers with worn shoes. Then a neighbour makes an offer. The neighbour will give him money for the shop, and in return he asks for a share of every profit. A second neighbour says the cobbler should ask many people for small sums, so that no single person carries the risk. The cobbler must decide who will own his business.

> Each choice gives different answers to who decides, who gains and who pays.

The cobbler does not yet know it, but three questions sit inside his decision. Who will decide what the shop does? Who will receive the profit when the shop does well? Who will pay the bills if the shop fails? A different owner, or a different number of owners, gives different answers to all three. The questions are the same for a bookshop in Dhaka, a bakery in Lagos or a factory in Osaka. This chapter shows how business owners answer them, and it studies in detail the form the cobbler would choose if he kept the shop to himself.

## Choosing an Ownership Form

> A family choosing how to own a house meets the same three questions.

Think first of a family that wishes to buy a house. One person may buy it alone and make every decision alone. Two relatives may buy it together and share the cost. A large group may buy a block of flats and each own one flat. In each case the family must decide who owns, who decides and who is responsible for the debt. A business meets the same questions, but it adds the daily work of making and selling.

> The law and custom of each country offer several ways to organise ownership.

A type of business organisation is a way of arranging who owns a business and who answers for it. Each country has its own laws, and the names and rules differ by place. Even so, most countries offer the same few basic forms. One person may own the business alone. Two or more people may own it together. A large number of people may buy shares in a company. People with a shared need may form a society owned by its members. A government may own the business on behalf of all citizens. The next chapters study these forms in turn, and the figure below shows how they relate.

> The sketch is a family tree that begins with all businesses and splits twice.

Now we read the family tree. It begins at the top with one box labelled for every business. The box splits into two branches, one for the private sector and one for the public sector, both defined in the next paragraph. Under the private sector branch stand four forms of ownership. Under the public sector branch stands one. Each box names a form, and a line shows the branch that the form belongs to. The words in the lower boxes are previews: the chapter named beside each one will teach it.

:fig A family tree of ownership forms, from all businesses to the five forms | ch07-fig01.svg

> The words private sector and public sector divide an economy by who owns and runs.
@ Private sector | The part of the economy owned and run by individuals and private firms rather than government.
@ Public sector | The part of the economy owned and run by government.
@ Sector | Word in use. In daily life, an area or a section of a town or a field. In business, one of the two large parts of an economy: private or public.

An economy is all the making, buying and selling in a country. Economists divide it into two large parts, called sectors. The **private sector** is the part of the economy owned and run by individuals and private firms rather than government. A family bakery belongs to it. The **public sector** is the part owned and run by government. A national railway or a government hospital belongs to it. Many countries have both sectors, and the share of each differs from country to country. Both sectors may be active in the same trade, such as schools or banking.

> A government-owned business will be studied later, so this chapter names it and moves on.

The public sector includes the business form named *state enterprise*, which means a business owned by the government. The words are previewed here for the family tree only. Chapter 11, 'State Enterprise and Comparing the Forms', teaches state enterprise in full. In the same way, *partnership* means a business owned by two or more people, and Chapter 8 teaches it. The words *company* and *cooperative society* are previewed for Chapters 9 and 10. These are not bold here, because they are not defined here.

> The right form depends on the objective, the money and the risk the owner accepts.

How does an owner choose among these forms? The choice rests on four questions. How much money does the business need to begin? How much control does the owner wish to keep? How much risk can the owner bear? How large will the business grow? A small shop that needs little money and little help suits one owner. A business that needs very large sums suits a form with many owners. An owner who values full control and speed will often prefer a small number of owners. No form is best for every business, because each form has advantages and costs.

> Law, tax and standards differ by country, so each owner must check local rules.

The choice is also shaped by law. Each country sets its own rules on which forms are allowed, how each is formed and how it is taxed. This chapter names the country whenever the rule depends on place, and the running case is set in Bangladesh. An owner should not rely on a book alone. Before choosing a form, an owner should read the current law of the place where the business will stand, or ask a person who knows it.

> Before moving on: this section gave three ideas.

*Before moving on.* A type of business organisation is a way of arranging who owns a business and who answers for it. The economy has two sectors: the private sector, owned and run by individuals and private firms, and the public sector, owned and run by government. The right form depends on money, control, risk and size, and the rules of each country differ.

## The Sole Proprietorship

> A person who works alone for himself is the simplest form of owner.

Return to the cobbler who keeps the shop for himself. He needs no neighbour to agree with him and no group to approve his plans. He buys leather, mends shoes and sets his own prices. When a customer pays, the money goes to him. When a supplier sends a bill, the bill comes to him. This is the oldest and simplest form of business: one person who owns it, runs it and answers for it.

> A sole proprietorship is a business owned and run by one person.
@ Sole proprietorship | A business owned and run by one person, who keeps all profit and bears all losses.

A **sole proprietorship** is a business owned and run by one person, who keeps all profit and bears all losses. The owner is called the owner, or the proprietor. An example is a family bookshop whose founder owns it alone. Other names are *sole trader* and *one-person business*. This book uses the word *sole proprietorship* for the form and *owner* for the person. The word *sole* means *only*. The owner may employ staff, but the staff do not own any part of the business.

> The key feature is that all profit belongs to the owner, and all losses fall on him.

The first feature follows from the definition: the owner keeps all profit. If the business earns Tk 750,000 in a year after paying its costs, all of it belongs to the owner. He may spend it, save it or put it back into the business. The same rule applies to losses. If the business loses money, the owner alone bears the loss. This gives the owner a strong reason to work hard, since every taka earned is his, and a strong reason to take care, since every taka lost is also his.

> Control is complete, and the owner decides without asking anyone.

The second feature is control. The owner decides what to sell, where to stand, what to charge and whom to employ. No meeting is needed and no vote is taken. Decisions can be made quickly, and the owner can change direction when conditions change. This speed is an advantage, though it also removes a check. When no one else shares the decision, a mistake by the owner may pass without warning from anyone.

> Unlimited liability is the third feature, and it is the greatest risk.
@ Liability | Word in use. In daily life, a duty or a responsibility. In business, a debt that a person or business is bound to pay.
@ Unlimited liability | A duty on the owner to pay the business's debts from personal wealth if the business cannot.

The third feature is the most important to understand. **Unlimited liability** is a duty on the owner to pay the business's debts from personal wealth if the business cannot. Here *liability* means a debt that a person is bound to pay, and *unlimited* means there is no upper limit to this duty. Suppose a small business owes Tk 500,000 to its suppliers but has only Tk 200,000 in money and goods. The owner must find the remaining Tk 300,000. In many countries he may have to sell his own savings, land or home. The law treats the business and the owner as one person for this purpose.^1

^1: This is the usual rule for a sole proprietorship in many countries, including Bangladesh. Exact rules on what may be taken, and in what order, differ by country, so an owner should check the local law.

:pause 7.p1 | A sole proprietor owes Tk 800,000 to suppliers. The business holds Tk 500,000 in money and goods. How much must the owner find from personal wealth?

> Another feature is ease of formation and of ending the business.

Other features follow from the first three. A sole proprietorship is easy to begin: there is no partner to persuade and no group to form. It is also easy to close, since no one else must agree. The owner's skill and character decide the success of the business, so customers often trust the person as much as the shop. This trust, the goodwill of the business, belongs to the owner, and it ends if he leaves. The business may also end when the owner dies, though the owner's family may continue it under a new arrangement.

> This form suits businesses that are small, personal and local.

Which fields suit a sole proprietorship? It suits work that needs little money, close attention and personal contact with customers. Examples are small shops, tailors, barbers, repairers, farmers, market stalls and professional advisers. The owner can see the whole business and meet every customer. It suits less well a business that needs very large sums, many owners' skills or great size, such as a power station or an airline. Such work needs more money and more people than one person can provide.

> Many sole proprietorships survive because they are easy to run and close to customers.

Why does this old form survive when other forms exist? It survives because it fits real needs. It costs little to begin. It gives the owner full control and all the profit. It allows quick decisions and a personal bond with customers. It needs few legal steps. In most countries the number of sole proprietorships is larger than the number of any other form, though the largest businesses use other forms. The form lasts because many tasks in every economy are small and personal, and one owner is enough for them.

> Weighing these features shows who gains and who bears risk.

A short comparison helps. The table below lists the main features in two columns, one for the advantage to the owner and one for the cost. Read each row from left to right: the first column names a feature, the second shows how it helps the owner, and the third shows how it can hurt.

:table Features of a sole proprietorship, with the gain and the cost of each
| Feature | Gain to the owner | Cost to the owner |
| All profit | Keeps every taka earned | Bears every taka lost |
| Control | Decides quickly and alone | No one to check mistakes |
| Liability | Simple: one person answers | Unlimited, reaching personal wealth |
| Formation | Cheap and quick to begin | Little help from others at the start |
| Money | Owner needs no outside agreement | Limited to what one person can raise |

> Before moving on: this section gave the features of one-owner business.

*Before moving on.* A sole proprietorship is a business owned and run by one person, who keeps all profit and bears all losses. Its features are full control, all profit, unlimited liability and ease of formation. It suits small, personal and local work, and it survives because it is cheap, quick and close to customers.

## Formation and Management

> We now turn from what the form is to how an owner begins and runs it.

The cobbler is ready to begin. This section follows the steps in order: starting the business, obtaining the permission to trade, managing the daily work and recognising the limits of one-person ownership. The steps are described for Bangladesh, where the running case is set, and the rules of other countries are named as different where they differ.

> Starting needs a plan, money, a place and the legal steps that the law requires.

The first step is a plan. The owner decides what the business will sell, to whom, and from where. The second step is money. The owner estimates what he needs to buy tools and goods and to pay the first months of rent, and he lists where it will come from: his own savings, a loan from a bank or credit from suppliers. The third step is the place, chosen as Chapter 4, 'Choosing Where a Business Stands', explains. The fourth is to meet the legal steps. Many sole proprietorships begin without an agreement, a lawyer or a registered name, which is why the form is quick to start.

> A trade licence is the official permission to trade in a stated place.
@ Trade licence | Official permission from a local authority to carry on a stated trade in a stated place.

The legal step common to nearly every shop is the licence. A **trade licence** is official permission from a local authority to carry on a stated trade in a stated place. For example, a bookseller in Dhaka obtains a licence that names the trade, books, and the address of the shop. In Bangladesh the local authority may be a city corporation, a municipality or a union council, according to where the shop stands. The licence must be renewed, usually each year, and a shop that trades without a current licence may be fined or closed.^2

^2: Rules on licences, the fees and the authority that issues them differ by country and by city, and they change over time. Other registrations, such as tax registration, may also apply. Check the current rules before relying on this chapter.

> Management means that one person performs every role, which is a strength and a strain.

Managing a sole proprietorship is different from managing a large business. In a large business many people share the work: one buys, one sells, one keeps records and one leads. In a sole proprietorship the owner often performs all these tasks, with the help of a few staff. The owner buys stock, serves customers, pays wages and records the money. This gives him close knowledge of every part, and it also means that his time is limited. Where the business grows, the owner must decide which tasks to hand to staff and which tasks to keep.

> Records, cash and a clear division of business and personal money are basic habits.

Three habits protect a sole proprietorship. First, the owner keeps written records of every sale and cost, so he can see whether the business earns a profit. Second, he keeps business money apart from his own spending, even though the law treats the two as one person for debts. Mixed accounts hide the true result. Third, he saves a part of his profit as a reserve for a poor year. These habits are easy to name and hard to keep, and many small businesses fail because they are neglected.

> Unlimited liability limits how much risk an owner can safely take.

The final topic returns to unlimited liability, because it limits what an owner can safely do. A large order, a new shop or a big loan may bring great profit, but a failure would be paid from the owner's savings and home. A prudent owner therefore asks, before each decision, how large the worst loss could be and whether he could pay it. A form with limited liability would protect his personal wealth, and later chapters show which forms provide that protection. For this reason a sole proprietorship that grows large often changes its form.

> The owner's personal limits also limit the size of the business.

Other limits are simple to state. The owner can raise only as much money as he and his lender can provide. His skill and time are limited, and if he falls ill, the business may stop. The life of the business is tied to the life of the owner. These limits do not make the form poor; they make it suitable for small work. A business that grows past them must find other money or other owners.

> Before moving on: this section gave the steps and limits of one-owner business.

*Before moving on.* A sole proprietor plans, finds money, chooses a place and meets the legal steps, of which the trade licence is the chief one. Management is performed largely by the owner himself, who needs records, separate money and a reserve. Unlimited liability limits the risk the owner can take, and a growing business often changes its form.

* * *

## A Worked Case: The Meghna and Sons Status Record

> A worked case applies the ideas to a recorded situation and does not give a model answer.

A worked case applies an idea to a situation. It has five parts: the situation, the question, the reasoning, the conclusion and a check. We apply the features of this chapter to one case file.

> The situation is a status record of a one-owner bookshop.
:case Case file, illustrative. Status record, 1 January 2026, for Meghna and Sons, a sole proprietorship. Owner: Nurul Meghna. Capital: Tk 4,100,000. Debts: amounts owed to publishers Tk 1,150,000 and a bank loan Tk 600,000, total Tk 1,750,000. The profit of Tk 750,000 for 2025 belongs entirely to him. One trade licence is kept current for the shop.

> The table puts the debts of the case file in one place.

The table below sets out the debts in the record. Read each row as one debt and the last row as their total.

:table Debts of Meghna and Sons on 1 January 2026
| Debt | Amount (Tk) |
| Owed to publishers | 1,150,000 |
| Bank loan | 600,000 |
| Total debts | 1,750,000 |

> The question asks what the form means for the owner's gain and risk.

*Question.* Using the record, what does the sole proprietorship mean for the owner's profit, his liability and his licence?

> Reasoning starts with the total of the debts, then compares it with capital.

*Reasoning.* First we check the total. Add the two debts: 1,150,000 + 600,000 = Tk 1,750,000. This equals the total in the record. Second, we compare the debts with the capital. Divide the debts by the capital: 1,750,000 ÷ 4,100,000 = 0.43, which is 43 per cent when rounded to a whole number. The debts are therefore a little less than half of the capital. Third, we apply the three features. The profit of Tk 750,000 belongs to the owner alone. The liability is unlimited, so the debts of Tk 1,750,000 are his duty to pay. The single licence covers the single shop, and it must stay current.

> The conclusion gives the owner's gain, his risk and his duty.

*Conclusion.* The owner keeps the whole profit of Tk 750,000 and has full control. In return, he is personally answerable for the debts of Tk 1,750,000, and the law may reach his personal wealth if the business cannot pay. The record does not state how much personal wealth he has, so we cannot say whether he could pay. The licence is current, so the shop may trade lawfully.

> The check compares the sum with the record and tests the sense of the result.

*Check.* The sum agrees with the total in the record. The ratio of 0.43 is below one, which is sensible, because the debts are smaller than the capital. If the ratio were above one, the debts would exceed the capital and the risk to the owner would be greater.

* * *

## Summary

> The summary lists the main ideas of the chapter.

A business may be owned in one of several forms, and the right form depends on money, control, risk and size. The economy has a private sector and a public sector. A sole proprietorship is a business owned and run by one person, who keeps all profit and bears all losses. Its main features are full control, all profit, ease of formation and unlimited liability. The owner usually needs a trade licence, keeps records and limits the risk he takes. A growing business often changes its form.

## Think It Through

> The questions below change the situation step by step.

Questions 7.t1 and 7.t2 use the case file in the worked section. Questions 7.t3 and 7.t4 change the setting.

:q 7.t1 | The bank loan in the case file is repaid in full from the business's money, and nothing else changes. What are the new total debts, and what is the new ratio of debts to capital, rounded to two decimal places?

:q 7.t2 | Suppose the business had lost Tk 750,000 in 2025 instead of earning it. Who bears the loss, and what does unlimited liability add to the risk?

:q 7.t3 | A farmer who owns a small farm alone borrows Tk 2,000,000 to buy machines. A flood destroys the crop and he cannot repay. What does unlimited liability mean for the farmer, and what could he have done before borrowing?

:q 7.t4 | A tailor who is a sole proprietor wishes to open four more shops. Which features of the form help her, and which features limit her? What might she consider?

## Where People Go Wrong

> Four common mistakes about the sole proprietorship, each with its correction.

*Mistake.* A sole proprietor has no employees. *Correction.* The word *sole* refers to ownership, not to staff. One owner may employ many people, and the staff do not own any part of the business.

> The business and the owner are not separate for debts.

*Mistake.* If the business fails, only the business money is lost. *Correction.* Under unlimited liability the owner must pay the remaining debts from personal wealth, which may include savings and a home. The exact rule depends on the law of the country.

> Control does not remove the need for records and care.

*Mistake.* Because the owner decides everything, no records or reserves are needed. *Correction.* Records and a reserve are more important in a one-owner business, since no one else will notice a problem in time.

> A licence is not optional because the owner is the only person involved.

*Mistake.* A very small shop needs no licence. *Correction.* Most local authorities require a trade licence for a stated trade in a stated place. Small shops are often fined or closed for trading without one.

## In History

> A hair-care business of the early 1900s was built by one owner.

Madam C. J. Walker was born Sarah Breedlove in Louisiana, in the United States, in 1867. She lost her hair through scalp illness in adult life, and she made a hair treatment for her own use. She had earlier worked as a sales agent for another hair-care business, owned by Annie Turnbo Malone. In 1906 she married Charles Joseph Walker and began to trade under the name Madam C. J. Walker.

> She made one-owner trade grow by selling door to door and by post.

She sold *Madam Walker's Wonderful Hair Grower* from door to door and by mail order from Denver, Colorado. Her daughter, A'Lelia, managed the mail-order work. In 1908 the business moved to Pittsburgh, and in 1910 to Indianapolis, where she built a factory and her headquarters. She trained women as sales agents and a school was named for her daughter. Later she formed a company named for herself, in which she remained the sole shareholder. Her case shows that one owner can build a large business, and that the owner carries both the gain and the risk.

## Review Questions

> The questions below ask the reader to apply the chapter.

:q 7.1 | Name the five forms of business ownership shown in the family tree and say which are in the private sector and which in the public sector.

:q 7.2 | List the advantages of a one-owner business and give a reason for each.

:q 7.3 | Explain unlimited liability in your own words and give a short example.

:q 7.4 | Explain why a small, personal business, such as a barber's shop, suits a sole proprietorship but a power station does not.

:q 7.5 | What is a trade licence, and what may happen to a shop that trades without one?

:q 7.6 | Explain why a sole proprietor should keep business money apart from his own spending.

