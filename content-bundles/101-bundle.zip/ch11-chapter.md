:chapter XI | State Enterprise and Comparing the Forms
:mood Why does a government run a railway, and who gains?
:desc This chapter explains why governments own and run businesses, and the forms that state ownership takes. It asks how such businesses should be judged. It closes by setting every form of ownership side by side for comparison.
:plate ch11-plate.svg | A railway station hall in the 1880s, with engines, signal box and station master

> A business that loses money every year raises the central question of this chapter.
> You will need: Chapter 7, 'Forms of Business Ownership and the Sole Proprietorship', section 7.1 'Choosing an Ownership Form'; Chapter 9, 'The Joint Stock Company', section 9.1 'What a Company Is'; and Chapter 10, 'The Cooperative Society', section 10.1 'The Cooperative Idea'.
Suppose that a business loses money every year. A private owner would not wait long for a change. The owner would raise prices, reduce the service or close the business. Yet some businesses of this kind stay open for decades. A railway may carry passengers on a line that never earns enough to pay its costs. A post office may deliver a letter to a remote island at the same price as a letter across the street. Who keeps such businesses alive, and why?

> The usual answer is that government owns them and has aims other than profit.
The usual answer is that government owns them. A government does not need to earn profit in order to continue, because it can use money collected from taxes. It may also judge success by other tests, such as whether every citizen can travel, post a letter or obtain clean water. This chapter explains that choice. It asks why governments own businesses, what forms their ownership takes and whether the results justify it.

> Earlier chapters studied private owners, and this chapter adds the last owner.
> Recall: private sector, Chapter 7, section 7.1 'Choosing an Ownership Form'.
Chapter 7 divided ownership into the private sector and the public sector. Chapters 7 to 10 studied the private sector: the sole proprietorship, the partnership, the company and the cooperative society. This chapter studies the public sector, where government is the owner. In the last section we set all the forms side by side, so that you can compare them and judge which form suits which task.

* * *

## 11.1 Why Government Owns Businesses

> A village well shows why some services are provided for everyone.
Think of a village well built by the village council. Everyone may draw water, and no one is turned away because he or she cannot pay. Now suppose that a private owner built the well to earn money. The owner would charge a price, and families that could not pay would go without. Both arrangements supply water, but they serve different aims. The first aims to serve all. The second aims to earn profit.

> A state enterprise is a business that government owns or controls.
@ State enterprise | A business owned or controlled by government, usually to provide essential goods or services.
@ Public | Word in use. In daily life, open to everyone, as in a public park. In business, owned or run by government, as in the public sector.
A **state enterprise** is a business owned or controlled by government, usually to provide essential goods or services. A national post service is one example, and a government-owned railway is another. State enterprises together form the public sector, in the same way that private businesses form the private sector.

> A government may become an owner by creating a business or by taking over a private one.
@ Nationalisation | The transfer of a privately owned business to government ownership.
A government has two routes to ownership. It may create a new business from the beginning, as it might build a new power station. Or it may take over a business that private owners already hold. This second route is called **nationalisation**. Nationalisation is the transfer of a privately owned business to government ownership. The government of the United Kingdom, for example, nationalised the Bank of England in 1946, the coal industry in 1947 and the railways in 1948. In Bangladesh, the government nationalised many large industries soon after independence in 1972.^1 Many laws require the government to pay compensation to the former owners, but the terms differ from country to country.

^1: The President's Order of 1972 on industrial enterprises began this process. Later governments sold or returned many of these businesses to private owners.

> Governments give six main reasons for owning businesses.
Governments give several reasons for state ownership. The first is public service: some goods and services are essential, and government wishes everyone to have them at a price that people can pay. The second is capital: a dam or a railway needs very large sums and many years before it earns a return, and few private owners can wait so long. The third is security: a country may not wish a private owner to control its defence industry. The fourth is fairness: where only one supplier can economically run a business, such as a water network, a private owner could raise prices without fear of competition. The fifth is development: government may build in a poor region where private investors would not. The sixth is revenue and employment.

> Some fields suit state enterprise better than others.
Not every field suits state enterprise. The fields most often chosen share some of the features above. They include defence, the post, railways, electric power, water supply and, in many countries, a part of banking. Fields where many suppliers compete and customers want variety, such as clothes or restaurants, are usually left to private owners. The line is not always sharp, however. The case file later in this chapter shows a government printing press that competes with private suppliers.

> The reasons do not always hold, so government should test them in each case.
The reasons need testing in each case. A government that wishes to protect fair prices should ask whether competition could achieve the same result at lower cost. A government that wishes to develop a region should ask whether a grant to a private investor would work better than ownership. Ownership also brings costs: government must find the capital, accept the risk of loss and manage the business. A reason is therefore a starting point for judgement and not a proof.

> Viewpoints differ: the citizen, the owner, the manager and the employee want different things.
The viewpoints of the people involved differ. A citizen hopes for service at a fair price. The government, as owner, hopes to meet national aims. A manager hopes for clear orders but may receive several aims at once: serve everyone, earn money and keep prices low. An employee often hopes for secure work. Later sections show how these hopes may conflict.

> The first section ends with a recap.
*Before moving on.* A state enterprise is a business owned or controlled by government, usually to provide essential goods or services. Nationalisation transfers a private business to government ownership. Governments own businesses to serve everyone, to find large capital, to protect security, to prevent unfair prices, to develop poor regions and to provide revenue and work.

## 11.2 Forms of State Enterprise

> Government can organise a business in three ways, which differ in independence.
Suppose that the government decides to run a national post service. It must choose how to organise it. Should the post office be a branch of a ministry, with the same rules as any government office? Or should it be a separate body that manages itself? The answer affects speed, freedom and accountability. Three forms are common, and we study them in order of increasing independence.

> A departmental undertaking is run as part of a government department.
@ Departmental undertaking | A state enterprise run directly as part of a government department.
A **departmental undertaking** is a state enterprise run directly as part of a government department. The minister at the head of the department is responsible for it. Its money comes from the government budget, and the revenue that it earns usually returns to the government. Its staff are government employees, who follow government rules for hiring, pay and spending. Many countries have run their post services and railways in this way. Such an enterprise has no separate existence in law, so the government itself owns its property and answers for its debts.

> The strength of this form is direct control, and its weakness is rigid management.
The strength of this form is control: the government can direct the enterprise at once, and its accounts are open to the elected assembly that makes the laws. The weakness is rigidity. A manager may need permission from a government office to spend money or to hire a person. Decisions are therefore slow, and managers have little freedom to respond to customers.

> A public corporation is a state enterprise set up by law with its own managers and accounts.
@ Public corporation | A state enterprise set up by law as a separate body with its own managers and accounts.
A **public corporation** is a state enterprise set up by law as a separate body with its own managers and accounts. The law states its aims, its powers and its rules. Government supplies the capital and appoints a board to manage it. The corporation can make contracts, own property and be sued in its own name. It may keep its earnings and may hire staff on its own terms. This freedom is meant to give the speed of a private business and the aims of a public service. The Tennessee Valley Authority, described in the history section, is a famous example. In Bangladesh, the Bangladesh Petroleum Corporation was created by law in this way.^2

^2: The corporation was created by an ordinance of 1976. Check the current law of the place concerned, because the form of a state enterprise can change.

> A government company is an ordinary company in which government holds most of the shares.
@ Control | Word in use. In daily life, to guide or limit something. In business, the power to decide policy and appoint managers, usually through owning most of the shares.
The third form is the government company. It is registered under the company law, like the companies of Chapter 9, but government holds most of its shares. Government therefore has control through its votes at the general meeting, and it appoints the directors. The company keeps the usual features of a company, such as limited liability and a separate existence in law. A few shares may belong to private persons. In Bangladesh, a government-owned bank such as Sonali Bank Limited is registered as a company in this way.^3

^3: Sonali Bank Limited was converted into a company in 2007 and is owned by the government.

> A public corporation differs from a company because it has no shareholders.
A student who has studied Chapter 9 may ask how a public corporation differs from a company. The difference lies in ownership and aim. A company has shareholders, who own it and share its profit. A public corporation has no shareholders. Government is its only owner, and the public interest is its chief aim. A government company is closer to a private company in its legal form, but government holds most of its shares, so its aims follow the wishes of government.

> A table compares the three forms on law, management, money and separation.
The table below compares the three forms on four points: the law that creates them, who manages them, where their money comes from, and whether they are separate bodies in law. Read each column to learn one form. Read each row to compare one feature across the forms.

:table Three forms of state enterprise
| Feature | Departmental undertaking | Public corporation | Government company |
| Created by | Government order or budget | A special law | The company law |
| Managed by | The ministry | Its own board | Directors appointed by government |
| Money from | Government budget | Government capital and own earnings | Share capital, mostly from government |
| Separate in law | No | Yes | Yes |

:pause 11.p1 | A body with its own managers and its own accounts is set up by a special law to run the national post service. Is it a departmental undertaking or a public corporation? Give your reason.

> Government must control its enterprises and also hold them to account.
Every form of state enterprise raises two linked questions. The first is control: how does government direct the enterprise? The second is accountability: how does the enterprise answer for its use of public money? Government controls through the minister, through the appointment of the board or the directors, through approval of the budget and through its power to give policy directions. Accountability runs the other way. The enterprise reports to the minister, the minister answers questions in the elected assembly, and an independent audit office examines the accounts. In Bangladesh that office is the Comptroller and Auditor General.^4 Too much control makes managers timid. Too little accountability allows waste. A good arrangement balances both.

^4: The Comptroller and Auditor General audits the accounts of government bodies. Other countries have a similar office under a different name.

> The second section ends with a recap of the three forms.
*Before moving on.* A departmental undertaking is part of a government department. A public corporation is a separate body set up by law, with its own managers and accounts. A government company is a company in which government holds most of the shares. Control and accountability must be balanced in all three forms.

## 11.3 Judging State Enterprise

> The first test of a state enterprise is whether it serves its purpose, not only whether it earns profit.
Is a state enterprise that makes a loss a failure? The answer depends on its purpose. A railway that carries a million people to work has value even if its tickets do not pay all its costs. State enterprises matter in many countries because they employ large numbers of people, supply essential goods, build roads and power lines, and sometimes earn revenue for government. A fair judgement therefore asks two questions. Did the enterprise serve its purpose? And did it do so at a reasonable cost?

> The importance of state enterprise is greatest where private capital is scarce.
The importance of state enterprise differs between countries. Where private capital is scarce, as in many developing countries, government may be the only owner able to raise the money for a large power station or a railway network. Where private capital is plentiful, government may prefer to let private owners build and to regulate them. For this reason, the share of the public sector in the whole economy varies widely. Citizens may also judge an enterprise by what it adds to the economy, such as jobs, supplies and connections, as well as by the profit that it reports.

> Losses have several causes, and not all of them are the fault of the managers.
Losses arise for several reasons. Government may fix prices low for social reasons, so that revenue cannot cover costs. Political orders may add staff that the work does not need or place a plant where it is not economical. Managers do not own the enterprise and do not lose their own money, so the incentive to save is weak. Decisions pass through many offices and take a long time. Where no competitor exists, no rival shows what a lower cost looks like. Finally, aims may be unclear: a manager told to earn profit, serve everyone and keep prices low cannot satisfy all three.

> The case file compares a state press with a private supplier.
:case Case file, illustrative. Supplier comparison 2026: Meghna and Sons can buy reams of paper from a state-owned press at Tk 520 each or from a private supplier at Tk 560 each. The shop buys 3,000 reams a year, so the state press saves Tk 120,000 a year. The average delivery takes 18 days from the state press and 6 days from the private supplier.

> The case file shows a gain in price and a cost in time.
The case file shows both a gain and a cost. The price is lower at the state press. The case file does not say why, and the reason might be government support or a price fixed for a public aim. The delivery is slower, so the shop must hold more stock or wait. The worked case at the end of the chapter weighs the two.

> A customer, a taxpayer and a manager read the same price differently.
A customer such as Meghna and Sons gains from the lower price. A taxpayer may ask whether the press sells below its cost and whether taxes cover the difference. A manager of the press may ask whether the price allows the press to keep its machines in repair. The case file does not give these facts, so we cannot answer. The questions show how to judge a state enterprise.

> Supporters and critics of state enterprise each have a case.
The case for state enterprise rests on the reasons in section 11.1: service to all, large capital, security, fair prices and development. The case against it rests on the causes of loss above. Critics say that state enterprises waste public money, that taxpayers pay for their losses and that politicians use them to give favours. Supporters answer that the fault lies in the management and not in the form, and that some state enterprises have performed well. The evidence differs between countries and between enterprises. Some governments have therefore kept certain enterprises and sold others to private owners, which is called privatisation, the opposite of nationalisation.

> The third section ends with a recap of judgement, causes of loss and the case for and against.
*Before moving on.* A state enterprise should be judged on its purpose and on its cost. Losses arise from low prices, political orders, weak incentives, slow decisions, lack of competition and unclear aims. Supporters and critics both have arguments, and the evidence differs by country and by enterprise.

## 11.4 Comparing All the Forms

> A table sets all five forms side by side on owner, liability, life and control.
We can now compare every form studied in Chapters 7 to 11. The table below uses four questions. Who owns the business? How far do the owners answer for its debts? How long does it last? Who holds control? Read each row to see one form complete.

:table The five forms compared
| Form | Owner | Liability | Life | Control |
| Sole proprietorship | One person | Unlimited | Tied to the owner | The owner |
| Partnership | Two or more partners | Unlimited | May end when a partner leaves or dies | The partners, each acting for all |
| Company | Shareholders | Limited to the value of the shares | Continues when shareholders change | Directors chosen by shareholders |
| Cooperative society | Members | Usually limited to the share held | Continues when members change | Members, one vote each |
| State enterprise | Government | Government stands behind it | Continues until government decides otherwise | Government, through a minister or board |

> The figure shows the forms on a line from private to government ownership.
The figure below places the forms on one line. The left end stands for ownership by private persons, and the right end stands for ownership by government. Each form appears at the position that shows who holds its shares or its capital. The government company lies in the middle zone, because government holds most shares but private persons may hold a few.

:fig Forms of business ownership from private to government | ch11-fig01.svg

> Each form has its own main strength.
Each form has a main strength. The sole proprietorship gives quick decisions and full control to one person. The partnership adds capital and skill but also shared liability. The company raises large capital from many investors and limits their risk, but it needs more rules and reports. The cooperative society serves its members and gives each one an equal voice. The state enterprise serves the public and can raise very large capital, but it may suffer from slow decisions and unclear aims. No form is best for every task.

> The choice of form depends on capital, risk, control and purpose.
To choose between forms, ask four questions. How much capital is needed, and from how many people? How much risk can the owners bear? How much control do they wish to keep? Is the aim profit or service? A small shop with modest capital suits a sole proprietorship. A larger business that needs many investors suits a company. Farmers who wish to sell together suit a cooperative society. An essential service for the whole nation suits a state enterprise.

> The fourth section ends with a short recap.
*Before moving on.* The five forms differ in owner, liability, life and control. Private forms aim at profit or at the benefit of members. State enterprise aims chiefly at public service.

## Worked Case: Choosing a Paper Supplier

> A worked case applies the chapter to the supplier comparison in five parts.
A worked case applies an idea to a situation. It has five parts: Situation, Question, Reasoning, Conclusion and Check. We use the supplier comparison of Meghna and Sons.

> The situation states the prices, the quantity and the delivery times.
*Situation.* A state-owned press offers paper at Tk 520 a ream with an average delivery of 18 days. A private supplier offers it at Tk 560 a ream with an average delivery of 6 days. The shop buys 3,000 reams a year.

> The question asks whether the lower price is worth the slower delivery.
*Question.* Is the saving from the state press worth the longer wait?

> The reasoning measures the saving, the delay and the extra stock.
*Reasoning.* First, find the yearly cost from each supplier. The state press costs 3,000 × Tk 520 = Tk 1,560,000. The private supplier costs 3,000 × Tk 560 = Tk 1,680,000. The saving is Tk 1,680,000 − Tk 1,560,000 = Tk 120,000. Second, find the difference in delivery: 18 − 6 = 12 days. Third, estimate the extra stock needed to cover those 12 days. Suppose that the shop uses paper evenly through the year. Then it uses 3,000 ÷ 365, about 8.2 reams a day. Over 12 days it needs about 12 × 8.2 = 99 reams more in stock. At Tk 520 a ream, this stock costs about Tk 51,500.

> The conclusion weighs the yearly saving against the one-time stock.
*Conclusion.* The state press saves Tk 120,000 every year. The extra stock ties up about Tk 51,500 once, and it needs shelf space. The saving is larger, so the state press is the better choice on cost. The shop should still keep some orders with the private supplier, because an average delivery of 18 days hides late deliveries, and a late delivery could cost sales.

> The check tests the saving in a second way.
*Check.* The saving of Tk 120,000 agrees with the case file. A second test: the price difference is Tk 40 a ream, and Tk 40 ÷ Tk 560 is about 7 per cent of the private price. A saving of 7 per cent on 3,000 reams is a sensible size.

* * *

## Summary

> A short summary of the chapter.
A state enterprise is a business owned or controlled by government, usually to provide essential goods or services. Governments create or nationalise businesses to serve all, to find capital, to protect security, to prevent unfair prices and to develop regions. The main forms are the departmental undertaking, the public corporation and the government company. Each form needs a balance of control and accountability. State enterprises should be judged on purpose and on cost. All five forms differ in owner, liability, life and control.

## Think It Through

> The problem asks you to weigh keeping against selling an invented bus service.
Suppose that a government owns a bus service. It loses money every year. Fares are low, the staff are many, and some routes serve remote villages. A minister proposes to sell the service to a private company. This case is invented, to practise the ideas of the chapter.

:q 11.t1 | Give two reasons for keeping the service in government hands and two reasons for selling it.
:q 11.t2 | Suggest one way to keep the village routes while reducing the yearly loss.
:q 11.t3 | Which form of state enterprise would give the bus managers the most freedom, and why?

## Where People Go Wrong

> Mistake one: a state enterprise exists to make profit.
Some readers think that a state enterprise exists chiefly to earn profit, like a private business. This is wrong. Its main purpose is usually to provide an essential good or service, although it may also earn money.

> Mistake two: nobody owns or answers for a state enterprise.
Some readers think that nobody owns a state enterprise, so nobody answers for it. This is wrong. Government owns it on behalf of the public, and it must answer to the minister, the elected assembly and the audit office.

> Mistake three: any rule that government makes for a business is nationalisation.
Some readers think that a business is nationalised whenever government makes rules for it or taxes it. This is wrong. Nationalisation is the transfer of ownership to government. A private business that obeys government rules remains in the private sector.

> Mistake four: state enterprises always lose money.
Some readers think that state enterprises always lose money. The evidence does not support this. Some have earned good results, and many losses have causes that better management and clearer aims could reduce.

## In History

> In 1933 the United States created a public corporation for one river valley.
In 1933 the United States was suffering the Great Depression. The Tennessee Valley, in the south-east of the country, was poor, and private power companies had brought electricity to very few of its farms. For years, Congress had debated whether to sell or keep a government dam site at Muscle Shoals, on the Tennessee River in Alabama. Senator George Norris of Nebraska fought to keep it under public control.

> The act of 18 May 1933 gave the new body wide tasks and a board of three.
On 18 May 1933 President Franklin Roosevelt signed the Tennessee Valley Authority Act. It created the Tennessee Valley Authority as a federal corporation. The act gave it tasks: to control floods, to improve navigation on the river, to replant forests, to develop farming and industry, and to supply cheap electricity. Its powers belonged to a board of three directors, whom the President appointed with the approval of the Senate. In its early years, money voted by Congress paid for its work, and a government audit office examined its accounts. Roosevelt described it as a body with the power of government and the flexibility of a private business. By 1944 it had built 16 dams.

> The story shows a public corporation, the reasons for state ownership and the need for accountability.
The story shows a public corporation at work. It also shows several reasons for state ownership: large capital, the development of a poor region and service to people that private owners had not reached. The Authority was often at the centre of political argument, which reminds us that control and accountability matter.

## Review Questions

:q 11.1 | Match each activity to the most suitable ownership form: (a) a small street tea stall, (b) a national railway, (c) a large paper mill that needs many investors, (d) a group of farmers who sell milk together.
:q 11.2 | A government runs its post service as a branch of a ministry. Later it moves the service to a separate body, set up by law, with its own managers and accounts. Name each arrangement.
:q 11.3 | A clinic buys 2,000 bottles of medicine a year. A state company charges Tk 85 a bottle, and a private supplier charges Tk 92. Find the yearly saving from the state company.
:q 11.4 | A town's water supply needs very large capital, serves every family and must not be priced beyond poor families. Which ownership form suits it? Give one reason for your choice and name one risk of that choice.

:read David E. Lilienthal, TVA: Democracy on the March, 1944
