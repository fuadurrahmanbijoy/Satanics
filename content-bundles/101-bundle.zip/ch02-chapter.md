:chapter II | Factors of Production
:mood How many different things must be gathered before one book is sold?
:desc Every business, large or small, needs the same four kinds of resource, and each kind earns its own kind of payment. This chapter names the four, shows what each one earns, and explains how a business brings them together. We follow one bookshop in Dhaka through 2025 and visit a famous factory in Michigan.
:plate ch02-plate.svg | A brickworks at work: clay, workmen, a kiln and a foreman's ledger

:box YOU WILL NEED
From Chapter 1, 'What Business Is', section 1.1 'Why People Do Business', you need the meaning of business and trade. From the same chapter, section 1.3 'Branches of Business', you need the idea that businesses belong to different branches. Nothing else is assumed.

> One book sold in two minutes depends on many things that existed before the customer arrived.

A customer walks into Meghna and Sons, a bookshop in Dhanmondi, Dhaka, and chooses a novel. She pays at the desk and leaves with the book in a paper bag. The sale takes two minutes. Yet before those two minutes could begin, many things had to exist. A room had to be found. Shelves had to be built. Books had to be bought and carried to the shop. Someone had to find the book and take the payment. Someone had to decide that all this effort was worth making.

> The customer's payment is shared among everyone who helped make the sale possible.

When the customer pays, the money does not stay in one place. Part of it pays the landlord, the person who owns the room and lets it to the shop. Part of it pays the staff. If the year goes well, a part remains for Nurul Meghna, the owner, who opened the shop on 4 April 1996. Here is the question hidden in this scene: why does each person receive a share, and why is each share a different kind of payment?

> Economists sort what every business needs into four kinds, each with its own payment.

Economists study how people use limited resources. They noticed that, whatever a business sells, the things it needs fall into four kinds. A bookshop, a brickworks and a bank all need the same four. Each kind earns its own kind of payment. This chapter names the four kinds, one at a time, and shows what each earns. We shall go slowly, because these words return in almost every later chapter.

* * *

## Land and Natural Resources

> A tea stall shows, on a small scale, what a seller needs before selling anything.

Begin with something smaller than a bookshop: a tea stall on a street corner, where selling tea is a small act of trade.^1 To sell one cup, the seller needs a spot where customers can stand. The seller needs water, tea leaves and sugar, which come from rivers, fields and farms. The seller needs a kettle and a stove. The seller needs the work of making and serving each cup. The seller also needs a plan, and the courage to risk money on it. These needs are of different kinds, and the kinds have names.

^1: Recall: business and trade, Chapter 1, 'What Business Is', section 1.1 'Why People Do Business'.

@! Go slowly here.
> Each kind of resource a business uses is called a factor of production.
@ Factor of production | A resource used to make goods or provide services; economists name four: land, labour, capital and enterprise.

Economists call each kind of resource a **factor of production**. A factor of production is a resource used to make goods or provide services. The tea stall uses several: a spot to stand, the seller's work, a kettle, and the decision to open. The word *factor* means a contributing part, as in "one factor in a success". Economists name four factors: land, labour, capital and enterprise. This section teaches the first. The next two sections teach the others.

> The first factor is land: every natural resource a business uses.
@ Land | All natural resources a business uses, including ground, water, minerals and forests.
@ Land | Word in use. In daily life, land often means a plot of ground that a person owns. In this subject, land means every natural resource a business uses, including water, minerals and forests.

The first factor is **land**. Land means all natural resources a business uses, including ground, water, minerals and forests. The tea stall uses land twice: the spot where customers stand, and the water drawn from nature. A brickworks uses more, because it digs clay from the earth. The key feature of land is that nature provided it. No person made the river or the clay, although people may carry the water or dig the clay.

> Every factor earns a reward; the reward of land is rent.

Every factor has a reward. A reward is the payment that the provider of a factor receives when a business uses it. For land, the reward is rent. Rent is the payment made to the person who lets a business use land or space. If the tea seller rents a corner from a landlord, the monthly payment for that corner is rent. Rent is agreed in advance, and the business pays it in a good year and in a poor year.

> The shop's rent in 2025 shows land and its reward in figures.

:case Case file, illustrative. In 2025 the factor land at Meghna and Sons was the rented shop space of 900 square feet in Dhanmondi, Dhaka. The rent was Tk 60,000 a month, which is Tk 720,000 for the year. Rent is therefore the reward of land in this case file.

> Strictly, buildings are not land, and nature supplies a limited amount of land.

Many students find this point confusing, because a shop is a building, and people make buildings. Economists separate the ground from the building on it. Strictly, ground, water and minerals are land, while a building is made by people and belongs with a later factor in this chapter. In this case file we count the rented shop space as land, because the shop pays one rent for the space in that place. Keep the strict meaning in mind and the confusion disappears. A second limit is that nature supplies a limited amount of land, so good locations are scarce.

> Section 2.1 ends with a recap and a sentence the reader can test.

*Before moving on.* A factor of production is a resource used to make goods or provide services. Land, the first factor, is every natural resource a business uses, and its reward is rent. A building is strictly not land. You should now be able to say, in one sentence, what land is and what it earns.

## Labour

> Most readers already know the second factor from their own experience of work.

You may already know this factor from your own life. Suppose you help in a relative's shop on Friday afternoons, and at the end of the week the relative pays you. You have given time and effort to a business, and you have received a payment for it. The shop could not serve its customers as well without you. This is the second factor in its simplest form.

@! Go slowly here.
> Labour is the work people give a business, whether of the body or of the mind.
@ Labour | The physical and mental work people give to a business, paid for with wages.

The second factor is **labour**. Labour means the physical and mental work people give to a business, paid for with wages. A shop assistant who lifts a heavy box of books gives physical work. An assistant who advises a customer which novel to choose gives mental work. Most jobs contain both. Labour covers every kind of work done for a business, from carrying boxes to keeping the accounts.

> The reward of labour is wages, which are usually agreed in advance.

The reward of labour is wages. Wages are the payment a business makes to people for their work. They are usually agreed before the work is done, and the business pays them whether or not the year is a good one. Some people are paid by the hour and some by the month, but this book uses one word, wages, for all such payments, because the idea is the same.

> At the shop, seven staff received wages of Tk 2,940,000 in 2025.

:case Case file, illustrative. In 2025 the factor labour at Meghna and Sons was its 7 staff. The total wages for the year were Tk 2,940,000. Wages are therefore the reward of labour in this case file.

> If an owner also serves customers, the question arises whether that work is labour.

A question is waiting here. Suppose an owner stands at the desk all day, serving customers. Is that work labour, or is it something else? Section 2.3 answers this. For now, keep the question in mind, and notice that the answer must separate two different things that one person can do.

@! Go slowly here.
> Splitting a job into small tasks can help workers make more.

Now meet an idea that changes how labour is used. Imagine two workers who make paper bags for the shop. Each bag needs two tasks, folding and gluing, and each task takes one minute. A worker who does both tasks alone loses half a minute each time the worker changes tools, so every bag takes three minutes. In one hour, one worker makes 60 ÷ 3 = 20 bags, and two workers make 40.

> Dividing the tasks removes the lost time and raises the output.

Now let one worker only fold and the other only glue. Nobody changes tools. After the first minute, which the folder spends alone, a finished bag appears every minute. In one hour the two workers make close to 60 bags, instead of 40. The same two people, working for the same hour, make one and a half times as many.

> This method has a name: division of labour.
@ Division of labour | Splitting a job into small tasks so that each worker repeats one task and becomes faster.

The method is called **division of labour**. Division of labour means splitting a job into small tasks so that each worker repeats one task and becomes faster. The bag example shows two gains: no time is lost in changing tools, and skill grows from repeating one task. Machines add a third gain, because a machine can be built for one small task.

> Adam Smith described the gain in 1776, using a pin factory.

The Scottish thinker Adam Smith (1723 to 1790) described this idea in 1776, in his book *The Wealth of Nations*. He wrote about a small pin factory where about eighteen operations were shared among ten workers. He reported that the ten, working together, made upwards of 48,000 pins in a day, and that one worker alone could hardly make twenty. His point has lasted: when work is divided well, labour produces more.

> Division of labour also has costs, and it works best where the market is large.

The method has limits. Repeating one task all day can become dull, and a dull task can lead to mistakes. Workers depend on each other, so one absence can slow the whole line. The method also needs a large market, because dividing the work only pays when the business can sell all the extra output. A small shop with a few customers a day gains little from it.

> Section 2.2 ends with a recap and a sentence the reader can test.

*Before moving on.* Labour is the physical and mental work people give to a business, and its reward is wages. Division of labour splits a job into small tasks so that each worker repeats one task. It raises output, but it can make work dull and workers dependent on each other. You should now be able to say what labour is, what it earns, and why dividing tasks can raise output.

## Capital and Enterprise

> A kettle and a plan show the last two factors.

Return to the tea stall. The seller has a spot and the seller's own work, but still cannot sell tea without a kettle, a stove, cups and a store of tea leaves. Where did these come from? Someone made them, and the seller either paid for them or borrowed money to buy them. After the kettle is bought, the seller must also decide how much tea to make, where to stand and what price to ask. These two needs, goods that people have made and the act of deciding, are the third and fourth factors.

@! Go slowly here.
> Capital is man-made goods and money used to produce other goods.
@ Capital | Man-made goods and money used to produce other goods, such as machines, tools and stock.
@ Capital | Word in use. In daily life, capital can mean the chief city of a country, or any large sum of money. In this subject, capital means man-made goods and money used to produce other goods.

The third factor is **capital**. Capital means man-made goods and money used to produce other goods, such as machines, tools and stock. Stock, in this sense, means the goods a business holds ready for sale; for the bookshop, it is the books on its shelves. A kettle is capital. So are a shop's shelves, a baker's oven, a lorry, and the money used to buy such things. Nature gave us land; people made capital.

:pause 2.p1 | A tea seller owns a kettle, draws water from a river, and stands on a corner of pavement. Which of these three is capital, and which are land?

> Capital earns a reward called interest, paid for the use of money or goods.

The reward of capital is interest. Interest is the payment made to the provider of capital for letting the business use it for a period. A small example shows the idea. If a person lends a business Tk 1,000 for a year and is repaid Tk 1,050, the extra Tk 50 is interest. Interest, like rent and wages, is agreed in advance.

> The shop's capital in 2025 was stock plus fittings.

:case Case file, illustrative. In 2025 the factor capital at Meghna and Sons was stock of Tk 3,500,000 plus fittings of Tk 600,000, a total of Tk 4,100,000. The case file gives no separate figure for interest.

> Capital is not only money, and an owner's own money earns its reward inside profit.

Many students believe that capital means money only. The definition shows otherwise: shelves, tools and stock are capital even though they are not cash. Money counts as capital when it is used to buy such goods or to let a business operate. A second point: when owners use their own money, they often pay interest to nobody, and the reward of that capital is then usually counted inside profit.

> The fourth factor is the act of organising the business and accepting the risk of loss.
@ Enterprise | The act of organising the other factors and accepting the risk of loss in the hope of profit.

The fourth factor is **enterprise**. Enterprise means the act of organising the other factors and accepting the risk of loss in the hope of profit. The tea seller who chooses the corner, buys the kettle, hires a helper and accepts that some days nobody may buy is practising enterprise. This person stands to lose money if the plan fails. Some writers also call a business an enterprise, a firm or a concern. In this book, business names the organisation, and enterprise names this factor only.

> The reward of enterprise is profit, which is not agreed in advance and may become a loss.

The reward of enterprise is profit. Profit is different from the other three rewards because it is not agreed in advance. It depends on how the year goes: it may be large, small, or a loss. This is why enterprise differs from labour. A member of staff receives wages even in a poor year. The person who supplies enterprise receives a reward only if something remains.

> One person can supply two factors, and each factor earns its own reward.

Now we can answer the question left open in section 2.2. An owner who serves customers all day gives labour, and the reward for that work is wages. The same owner who organises the shop and accepts the risk gives enterprise, and the reward is profit. One person can supply both factors. Each factor still earns its own kind of reward, and we keep the two apart.

> The shop's enterprise in 2025 was Nurul Meghna, with a profit of Tk 750,000.

:case Case file, illustrative. In 2025 the factor enterprise at Meghna and Sons was Nurul Meghna, the owner. The reward for enterprise was a profit of Tk 750,000.

> A table now sets the four factors and their rewards side by side.

All four factors are now named, and a table can set them side by side. Read each row from left to right: the factor, what it was at the shop in 2025, and the reward it earned. The figures come from the case files above.

:table The four factors at Meghna and Sons, 2025
| Factor | At the shop in 2025 | Reward |
| Land | Rented shop space, 900 square feet | Rent: Tk 720,000 |
| Labour | 7 staff | Wages: Tk 2,940,000 |
| Capital | Stock Tk 3,500,000 plus fittings Tk 600,000; total Tk 4,100,000 | Interest: no separate figure in the case file |
| Enterprise | Nurul Meghna, the owner | Profit: Tk 750,000 |

:pause 2.p2 | Which of the four rewards in the table is not agreed in advance, and why does that matter to the person who receives it?

> Section 2.3 ends with a recap and a sentence the reader can test.

*Before moving on.* Capital is man-made goods and money used to produce other goods, and its reward is interest. Enterprise is the act of organising the other factors and accepting the risk of loss, and its reward is profit. Rent, wages and interest are agreed in advance, but profit is not. You should now be able to name all four factors and the reward each earns.

## How the Factors Combine

> No business can produce with one factor alone, so the question is how to mix them.

Start with a question. Could a bookshop operate with land alone? An empty room sells nothing. Could it operate with labour alone, staff with no books and no room? Again it sells nothing. Every business needs all four factors together, as a cook needs ingredients, a stove, skill and the decision to cook. The figure below shows the pattern. Read it from left to right: each factor on the left earns the reward on the right.

:fig Four factors of production and the reward each earns | ch02-fig01.svg

> The mix of factors differs between businesses, and no single mix suits all.

The proportions differ from one business to another.^2 A brickworks relies heavily on land, because it digs clay, and on capital such as kilns. A bookshop relies on stock, which is capital, and on staff, which is labour. A software business may use almost no land but a great deal of labour. No factor can be removed entirely, but the importance of each depends on the business. Each person also sees the factors differently: the landlord sees rent, the employee sees wages, and the owner sees profit or loss.

^2: Recall: branches of business, Chapter 1, 'What Business Is', section 1.3 'Branches of Business'.

> An owner can often choose between factors, such as a machine instead of workers.

The owner often has a choice of mix. A machine, which is capital, may do the work of several workers, who are labour. Each choice changes the rewards that must be paid. The machine brings a cost of purchase or interest and no wages; workers bring wages. The owner, who supplies enterprise, carries the risk of choosing wrongly.

> Factors differ in how easily they move from one use or place to another.

Factors also differ in how easily they move from one use or place to another. This is called their mobility. The table below introduces the four in words first: land cannot move at all, labour moves with effort, capital moves easily if it is money and slowly if it is a machine, and enterprise moves when a person starts a different business. Read each row as a factor and how freely it moves.

:table How easily each factor moves
| Factor | How easily it moves | Example |
| Land | It cannot move, although its use can change | A plot changes from farm to shop |
| Labour | It moves with effort, training and cost | A worker moves to another city |
| Capital | Money moves easily; machines move slowly | A loan goes to a new business |
| Enterprise | It moves when a person starts again | A baker opens a second business |

> Section 2.4 ends with a recap and a sentence the reader can test.

*Before moving on.* Every business combines all four factors, in a mix that suits its work. An owner may choose a different mix, such as a machine instead of workers, and each choice carries different rewards and risks. Factors differ in mobility. You should now be able to say why no business can do without any one factor.

## A Worked Case: Sorting the Shop's Figures

> The worked case applies the four factors to the shop's 2025 figures.

:case Case file, illustrative. In 2025 Meghna and Sons used rented shop space of 900 square feet at Tk 60,000 a month; 7 staff with total wages of Tk 2,940,000; stock of Tk 3,500,000 and fittings of Tk 600,000; and Nurul Meghna as owner, with a profit of Tk 750,000.

> The question asks for each factor, its reward and one calculation each for land and labour.

*Question.* Name the factor behind each item, give its reward, find the yearly rent for each square foot, and find the average wages for each member of staff.

> Steps one and two sort the land and labour figures and calculate.

*Reasoning, part one.* The rented space is land, and its reward is rent: 12 months × Tk 60,000 = Tk 720,000. Rent for each square foot is Tk 720,000 ÷ 900 square feet = Tk 800 a year. The 7 staff are labour, and their reward is wages of Tk 2,940,000. Average wages are Tk 2,940,000 ÷ 7 = Tk 420,000 for each member of staff.

> Steps three and four sort the capital and enterprise figures.

*Reasoning, part two.* Stock and fittings are capital: Tk 3,500,000 + Tk 600,000 = Tk 4,100,000. The case file gives no separate figure for interest. Nurul Meghna, who organises the shop and accepts the risk, supplies enterprise, and the reward is the profit of Tk 750,000. Rent and wages were agreed in advance, but the profit was whatever remained.

> The conclusion names each factor with its reward, and the check tests the arithmetic.

*Conclusion.* Land earned rent of Tk 720,000, labour earned wages of Tk 2,940,000, capital was worth Tk 4,100,000, and enterprise earned profit of Tk 750,000. *Check.* Multiply back: Tk 800 × 900 = Tk 720,000, and Tk 420,000 × 7 = Tk 2,940,000. Also Tk 4,100,000 − Tk 600,000 = Tk 3,500,000. All three agree with the case file.

* * *

## Summary

> Four factors earn four rewards, and each has its own kind of risk.

Every business combines four factors of production. Land, the natural resources, earns rent. Labour, the work of people, earns wages. Capital, the goods and money that people have made, earns interest. Enterprise, which organises the others and carries the risk, earns profit. Division of labour splits a job into small tasks, with gains and costs. At the shop in 2025, rent was Tk 720,000, wages were Tk 2,940,000, capital was Tk 4,100,000, and profit was Tk 750,000.

## Think It Through

> A workshop owner must choose between one machine and three more workers.

A small workshop sews covers for books. It receives more orders than its two workers can finish. The owner can buy a sewing machine, which one person can operate, or can hire three more workers who sew by hand. Use the four factors to reason about the choice.

:q 2.t1 | Which factor is the machine, and which factor are the three workers? Name the reward paid in each choice.
:q 2.t2 | Both choices commit the owner to payments agreed in advance. Who carries the risk that orders may fall, and which factor does that person supply?
:q 2.t3 | Suppose the owner would also operate the machine personally. Which two factors does the owner then supply?

## Where People Go Wrong

> Capital is not only money; it also includes made goods such as tools and stock.

*Capital means money only.* This is incomplete. Capital means man-made goods and money used to produce other goods, so shelves, ovens and stock are capital too.

> Land is not only farmland; it includes all natural resources.

*Land means farmland.* This is too narrow. Land includes ground, water, minerals and forests, wherever a business uses them.

> An owner's reward is not wages unless the owner also works.

*The owner's reward is wages.* Wages reward work, which is labour. Profit rewards organising and accepting risk, which is enterprise. One person can earn both, but the two rewards are different.

> Division of labour is about small repeated tasks, not equal sharing of tasks.

*Division of labour means sharing all tasks equally.* It means the opposite: each worker repeats one small task. It also has costs, such as dull work and dependence.

## In History

> In 1913 Henry Ford's factory combined labour, capital and division of labour on a moving line.

Henry Ford (1863 to 1947) was an American manufacturer who built the Model T car at the Ford Motor Company, first sold in 1908. In 1913, at the Highland Park factory in Michigan, United States, the company introduced moving assembly lines. Before then, a car stayed in one place while workers brought parts to it. On the moving lines, the work travelled past each worker, who repeated one small task. Assembling a car chassis, which took more than twelve hours, fell to about ninety minutes by 1914. Labour, capital in machines and conveyors, and division of labour were combined, and Ford and his managers took the decision and the risk.

## Review Questions

:q 2.1 | Name the factor and the reward for each income: a landlord who lets a shop room; a shop assistant paid each month; a person who lends money to a business and is repaid with extra; an owner who keeps what remains after all costs.
:q 2.2 | Explain why enterprise differs from labour, using Nurul Meghna and a member of the shop's staff.
:q 2.3 | Compare two shops. Shop A is a street stall with a hand cart. Shop B is a supermarket with shelves, scanners and many staff. Which factors weigh most in each?
:q 2.4 | A farmer rents a field, hires two helpers, buys a tractor and decides which crop to grow. Name each factor and its reward.
:q 2.5 | A trader buys cloth from a supplier and sells it to customers. Give one example of each of the four factors for this trader.
:q 2.6 | Using the paper-bag example, explain division of labour and name one cost of it.

:read Adam Smith, The Wealth of Nations, 1776
:read Alfred Marshall, Principles of Economics, 1890
:read Henry Ford with Samuel Crowther, My Life and Work, 1922
