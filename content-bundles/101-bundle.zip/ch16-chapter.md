:chapter XVI | Business Combination and Integration
:mood Why would two businesses prefer to be one?
:desc This chapter asks why businesses join together and what each way of joining changes. It describes mergers, takeovers, consolidation, holding companies, cartels and trusts. It then separates joining at the same stage from joining at different stages, and weighs the gains against the dangers.
:plate ch16-plate.svg | Mill owners around a map and a ledger, agreeing how to share their trade.

> The earlier chapters that this chapter builds on.

*You will need* Chapter 9, 'The Joint Stock Company', section 9.1 'What a Company Is' (company ownership and shares); Chapter 15, 'Institutions that Promote Business in Bangladesh', section 15.1 'The Share Market' (how shares are bought and sold); and Chapter 12, 'Foreign Trade', section 12.1 'Why Nations Trade' (the ideas behind trade between countries).

> Two rival bookshops on one lane open a question about competition.

Imagine a lane in Dhanmondi, Dhaka, with two bookshops facing each other. Both sell school textbooks and stationery. Both pay rent and wages, and both order many of the same titles from the same suppliers. Each owner watches the other's window every morning and lowers a price whenever the other does.

> The owner of one shop offers to buy the other, and three questions follow.

One day the owner of the first shop offers to buy the second. If the offer is accepted, the competition on the lane ends. Three questions follow. What does the buying owner gain? Why might the selling owner agree? And what do the customers on the lane gain, or lose?

> The answers differ because each person sees the event from a different place.

The answers are not the same for everyone. One customer may welcome a wider range of books under one roof. Another customer may fear higher prices, because no rival window now forces them down. A shop assistant may ask only one thing: will my job remain? Each person sees the same event from a different place, and each sees something true.

> Merchants, and then governments, have asked this question in every age.

Merchants in every age and country have asked this question. Some joined their businesses by agreement, some by purchase, and some by the force of money. Governments have asked in turn whether such joining serves the public or harms it. In this chapter you will learn the names of the main ways of joining, the reasons behind them, and a method for weighing gain against danger. Other books say firm, enterprise or concern for what this book calls a business; we use business throughout.

* * *

## Why Firms Combine

> A business combination is two or more businesses joined under one control.

@ Business combination | Two or more businesses joining under common control, in order to gain strength or reduce competition.
@ Combination | Word in use. In daily life, a mix of things, such as the numbers that open a lock. In business, the joining of separate businesses under common control.

Return to the two bookshops on the lane. If one owner buys the other shop, the two shops become one business. Business study has a name for this kind of joining: **business combination**. A business combination means two or more businesses joining under common control, in order to gain strength or reduce competition. The two bookshops under one owner are a small example. A group of fifty shops that keep separate names but answer to one owner is a larger one.

> Common control means one person or group makes the main decisions.

@ Control | Word in use. In daily life, to hold something in check, as a driver controls a bus. In business, the power to decide how a business is run, usually gained by owning most of its shares.

The phrase *common control* carries the whole idea, so we examine it. Control means the power to decide the main matters of a business: what it sells, whom it employs and how it spends money. Before the joining, two owners decide these matters separately. After it, one owner, or one group of owners, decides for both. This is why a business combination differs from two businesses that only trade with each other.

> The running case for this chapter is a proposal to buy a neighbouring shop.

:case Case file, illustrative. Proposal of 3 December 2026: Meghna and Sons, the family bookshop in Dhanmondi, Dhaka, considers acquiring its neighbouring shop, Padma Stationers (illustrative). Padma Stationers has sales of Tk 6,000,000 a year. The proposed price is Tk 1,800,000. About 40 customers a week shop at both businesses. The expected rent saving is Tk 360,000 a year. Meghna and Sons had sales of Tk 14,400,000 in 2025, so the combined 2025 sales would be Tk 20,400,000.

> We return to these figures in the worked case at the end of the chapter.

The case file records figures and a proposal, and it does not record a decision. Keep the figures in view as you read. Each new idea in this chapter can be tested against them: which reason for combining do they show, which opportunity, and which threat?

> Owners give six main reasons for joining their businesses.

Owners give six main reasons for joining their businesses. The first is lower cost. Two shops under one roof need one rent and one set of accounts, not two. The second is buying power. A supplier gives a better price for one large order than for two small ones. The third is less competition. When two rivals become one, neither can win customers from the other by lowering a price. The fourth is safety. A large business can survive a bad year more easily than a small one. The fifth is growth. Buying a business that already has customers is faster than winning customers one at a time. The sixth is skill or reach. A business may join another that knows a trade, a craft or a country that it does not know.

> The reasons look different from the owner's, the employee's and the customer's viewpoint.

The reasons look different from each viewpoint. The owner seeks growth and profit. The manager seeks a plan that can be run well. The employee asks whether the job and the pay will remain. The customer asks about price, choice and service. A combination that satisfies the owner may trouble the customer, and the reverse can also be true. Keep all four viewpoints in mind in every case in this chapter.

> Reach is the sixth reason, and it often involves trade between countries.

> Recall: Foreign trade, Chapter 12, section 12.1 'Why Nations Trade'.

The sixth reason, reach, deserves an example because it is the hardest to see. Suppose a small Dhaka maker of notebooks wishes to sell to customers in another country. It lacks contacts, knowledge of the foreign market and skill in export. A larger business already has all three. If the two join, the small maker gains a route to those customers, and the larger business gains a product it can offer. Some combinations of this kind place a factory in an export processing zone, which is a planned area with special rules for factories that make goods for export. Neither business could easily gain this reach alone, and this is why reach is a common reason for joining.

> Opportunities are the gains that a combination makes possible.

A reason explains why owners choose to join. An opportunity is a gain that the combination makes possible. Consider two families who live in one building and share one kitchen. They pay one gas bill, buy rice in larger sacks and cook together on busy days. In the same way, a combined business can spread a fixed cost such as rent over more sales, so that each book sold carries a smaller part of the rent. It can order in larger quantities and ask for a lower price. It can offer customers a wider range. It can borrow more easily, because a lender sees a larger and steadier business. And it can reach markets that neither business could reach alone, such as customers in other countries through export.

> Threats are the dangers that a combination can bring.

A threat is a danger that the combination brings. The same two families may quarrel over whose turn it is to use the stove. Businesses meet the same difficulty on a larger scale. The price paid for the other business may be too high. The two ways of working may not agree, and good staff may leave. Customers who liked the old shop may go elsewhere. A larger business can become slow and costly to manage, so that the expected saving does not appear. When competition ends, customers may face higher prices, and the law may forbid the combination. Every opportunity named above has a threat that stands beside it.

> Section recap: reasons, opportunities and threats.

*Before moving on.* A business combination is two or more businesses joined under common control. Owners join for lower cost, buying power, less rivalry, safety, growth and skill. Each opportunity has a threat beside it, and the customer's viewpoint can differ from the owner's.

## Forms of Combination

> Combination happens in several ways, and the way matters as much as the reason.

Owners who have decided to join must still decide how. Some forms end one business completely. Others leave each business alive while one owner or group controls them all. The table below sets six forms side by side. Read each row from left to right: the form, what happens, and what remains of the separate businesses. The paragraphs after the table explain each form in turn.

:table Six forms of combination
| Form | What happens | Do the businesses stay separate? |
| Merger | One company absorbs another | No: only one remains |
| Takeover | A buyer gains most of a company's shares | Yes, but the buyer controls it |
| Consolidation | Two or more companies end and a new one begins | No: a new company replaces them |
| Holding company | One company owns enough shares in others to control them | Yes: each keeps its own name and legal life |
| Cartel | Independent businesses agree on prices or output | Yes: each stays independent |
| Trust | Owners give their shares to trustees who run the group | Yes in law, no in control |

> A merger is a combination in which one company absorbs another.

@ Merger | A combination in which one company absorbs another and only one remains.

A **merger** is a combination in which one company absorbs another and only one remains. To absorb means to take in completely. Suppose a company named Alpha Books absorbs a company named Beta Stationers. Beta's shops, stock and staff now belong to Alpha, and the name Beta ends. The directors of both companies usually agree to a merger, and the owners of each company vote on it. Many countries add legal steps, such as approval by a court or a public authority, so the law of the country concerned must always be checked.

> An acquisition is buying a business; a takeover is buying most of a company's shares.

> Recall: Share market, Chapter 15, section 15.1 'The Share Market'.

@ Takeover | Gaining control of a company by buying most of its shares.

An acquisition means buying a business, or enough of it, to control it. A buyer may acquire the shop, the stock and the name of a business owned by one person. This is the form that Meghna and Sons proposes in the case file. When the business is a company, the buyer may buy its shares instead. This is a **takeover**: gaining control of a company by buying most of its shares. A takeover is friendly when the directors of the company agree. It is hostile when they refuse and the buyer appeals directly to the shareholders. A company whose shares are traded on a stock exchange is easier to acquire in this way, because any investor can buy its shares.

> In consolidation, the old companies end and a new company begins.

Consolidation is different from a merger. In a merger one company survives. In consolidation, two or more companies end together, and a new company begins in their place, owning everything the old companies owned. Imagine that Alpha Books and Beta Stationers both close, and a new company, Alpha-Beta Books, begins. No old name survives. The shareholders of the old companies receive shares in the new one.

> A holding company controls other companies by owning their shares.

> Recall: Share and limited liability, Chapter 9, section 9.1 'What a Company Is'.

A holding company is a company that owns enough shares in other companies to control them. The companies it controls remain legal companies, with their own names, accounts and limited liability. Yet one set of owners decides the main policy for all of them. Compare this with a merger. After a merger there is one business. Under a holding company there are many businesses, and one controller. A holding company needs only a majority of the voting shares, not all the shares, so it can control a company at a lower cost than buying it whole.

> A cartel is an agreement between independent businesses, not a purchase.

@ Cartel | A group of independent firms that agree to fix prices or output to limit competition.

Picture three mill owners in one region who meet around a map and a ledger. They agree on one price for cloth and on a limit to what each mill will make. Each owner keeps their own mill, books and workers. This is a **cartel**: a group of independent firms that agree to fix prices or output to limit competition. Nothing is bought and nothing is merged, so a cartel is the loosest form of combination. It is also the weakest, because any member can break the agreement. In many countries a cartel is unlawful.

> A trust is a firmer form, in which trustees control the shares of many businesses.

A trust is firmer than a cartel. The owners of several businesses give their shares to a small group of trustees. The trustees vote those shares and run the businesses as one group, and the owners receive certificates that show their share of the profit.^1 The best-known trust, Standard Oil, appears in the history section at the end of the chapter.

^1: In law, the word trust also has older and wider meanings, such as property held by one person for the benefit of another. Here it means only this form of combination.

> The choice of form depends on what the owners want to keep and what they can afford.

How do owners choose among these forms? They ask what they wish to keep and what they can afford. If they want one business with one name, they choose a merger or consolidation. If they want to keep the names, the shops and the trusted staff of each business, they choose a holding company or a takeover, because each business stays alive. If they only wish to end price competition and trust one another, they may consider a cartel, but it gives no lasting control and often breaks the law. The cost differs too. Buying a whole business needs more money than buying a majority of its shares, and an agreement needs the least money but gives the least control.

> The law on combinations differs by country, and the place must be named.

The law on combinations differs by country, so we name the place. In the United States, the Sherman Act of 1890 makes illegal any contract, combination or conspiracy that restrains trade between the states. In Bangladesh, the Competition Act 2012 deals with agreements between businesses that harm competition. Not every combination is unlawful. Laws usually aim at combinations that harm customers, and many mergers and acquisitions are lawful.

:box IN SHORT
For each form, ask two questions: who survives, and who controls?

> Section recap: six forms, sorted by what survives and who controls.

*Before moving on.* A merger leaves one company. Consolidation replaces the old companies with a new one. A takeover and a holding company leave the companies alive but under a controller. A cartel is an agreement between independent businesses, and a trust places their shares in the hands of trustees.

:pause 16.p1 | Three tea sellers in a market agree to charge the same price for a cup, but each keeps their own stall. Which form is this, and why does the word independent matter?

## Horizontal and Vertical Integration

> Horizontal integration joins businesses at the same stage of one product.

@ Horizontal integration | Combining firms at the same stage of making or selling the same kind of product.

Forms describe how businesses join. Integration describes which businesses join. **Horizontal integration** means combining firms at the same stage of making or selling the same kind of product. Meghna and Sons and Padma Stationers both sell books and stationery to customers, so they stand at the same stage. Joining them is horizontal. Its opportunity is lower cost and a larger share of the market. Its threat is less choice for customers.

> Vertical integration joins businesses at different stages of one product.

@ Vertical integration | Combining firms at different stages of making and selling one product, such as printer and bookseller.

A book passes through several hands before a customer reads it: the paper maker, the printer, the bookseller. **Vertical integration** means combining firms at different stages of making and selling one product, such as printer and bookseller. A bookseller that buys a printer moves toward the source. A printer that opens bookshops moves toward the customer. Its opportunity is a secure supply and the profit of each stage. Its threat is being tied to one's own supplier even when another is cheaper.

> The figure shows the two kinds of joining as two chains.

The figure below shows both kinds as chains. Each box is one stage, and each arrow shows the product moving toward the customer. A dashed outline marks businesses under one control. In the top chain the outline spans two different stages. In the bottom chain it spans three businesses at the same stage.

:fig Horizontal and vertical combination as two chains | ch16-fig01.svg

> Horizontal integration raises the question of market power.

Horizontal integration raises a question about power. When two of three bookshops on a lane join, one owner now controls two thirds of the shelf space for textbooks. Customers have one rival left to compare. When the last rival joins, customers have no comparison at all, and the owner may raise prices without losing sales. This is why laws watch horizontal combinations most closely.

> Vertical integration raises the question of fair access.

Vertical integration raises a different question: fair access. If a printer owns the only bookshops in a town, other printers may find no place to sell, and other booksellers may find that the printer will not supply them. Customers may then see only one maker's books. Owners answer that vertical integration lowers cost and keeps the quality of every stage under one hand. Both claims can be true, and each case must be weighed on its facts.

> A conglomerate joins businesses in unrelated trades to spread risk.

A conglomerate is a group of businesses in unrelated trades, such as a bookshop, a bus line and a bank under one owner. It joins neither the same stage nor different stages of one product. Its aim is to spread risk, because a bad year in one trade may be balanced by a good year in another.

> No form is good or bad alone; weigh the gain and the danger for each viewpoint.

No form is good or bad alone. Weigh each case with four questions. What does the owner gain? What do customers gain or lose? Can the joined businesses be managed as one? Does the law of the country allow it? A combination that lowers cost and keeps prices fair serves everyone. One that removes all choice invites the attention of the law.

> Section recap: horizontal, vertical and conglomerate joining.

*Before moving on.* Horizontal integration joins the same stage; vertical integration joins different stages. A conglomerate joins unrelated trades. Weigh opportunity against threat from every viewpoint.

## Worked Case: Padma Stationers

> A worked case applies the ideas of the chapter to the proposal of 3 December 2026.

A worked case applies an idea to a situation. It does not give a model answer to a question about the subject. It shows how to reason from the facts, one step at a time. We use the proposal from the case file.

> The situation restates the facts of the proposal.

*Situation.* On 3 December 2026 Meghna and Sons proposes to acquire its neighbour, Padma Stationers. Padma Stationers has sales of Tk 6,000,000 a year. The price is Tk 1,800,000. About 40 customers a week shop at both businesses. The expected rent saving is Tk 360,000 a year. Meghna and Sons had sales of Tk 14,400,000 in 2025, and a profit of Tk 750,000.

> The question asks for the kind of combination and whether the proposal is sound.

*Question.* What kind of combination is this, and does the case file support buying Padma Stationers?

> Step one names the form and the kind of integration.

*Reasoning.* Step one: name the form. Meghna and Sons proposes to buy a business owned by another, so this is an acquisition. The case file does not say that Padma Stationers is a company, so we do not call it a takeover or a merger. Step two: name the kind. Both shops sell books and stationery to customers, so they stand at the same stage. This is horizontal integration.

> Step two measures the size and the saving.

Step three: measure the size. The combined 2025 sales would be the sum of the two. Sales of Tk 14,400,000 plus Tk 6,000,000 give Tk 20,400,000. Step four: compare the price with the saving. In words, the years needed to recover the price equal the price divided by the yearly saving. Tk 1,800,000 divided by Tk 360,000 is 5 years. This counts the rent saving alone, and other gains or losses would change it. For scale, Tk 1,800,000 divided by the 2025 profit of Tk 750,000 is 2.4. The price is 2.4 times a year of profit.

> Step three looks at the overlap in customers and at the threats.

Step five: examine the overlap. About 40 customers a week already shop at both businesses. Buying Padma Stationers cannot win new sales from these customers, because they already buy from Meghna and Sons. It only removes their choice. New sales must come from the customers of Padma Stationers who have not shopped at Meghna and Sons before, and some of them may leave. Step six: list the threats. The case file does not state how the price would be paid. It does not say whether the staff of Padma Stationers would stay. It does not say whether customers would accept the change.

> The viewpoints of the owner, the employee and the customer test the result.

Step seven: test the result from each viewpoint. The owner gains a larger business and a rent saving. The employees of both shops ask whether every job remains, because one rent and one set of accounts may need fewer people. The customers on the lane gain a wider range of books, and lose a rival window that once held prices down. About 40 customers a week know both shops, so they will notice this change first. A sound decision records all three viewpoints before it records a verdict.

> The conclusion weighs the opportunity against the threats.

*Conclusion.* The proposal is a horizontal acquisition with a real saving, equal to half of the Tk 720,000 rent that Meghna and Sons paid in 2025. The rent saving alone repays the price slowly, in 5 years. A decision should wait for three facts: how the price will be paid, how many customers and staff of Padma Stationers will remain, and whether any competition law applies.

> The check repeats the arithmetic.

*Check.* Tk 14,400,000 plus Tk 6,000,000 equals Tk 20,400,000, as in the case file. Five years of saving, 5 times Tk 360,000, equals Tk 1,800,000, which is the price. A profit of Tk 750,000 multiplied by 2.4 also equals Tk 1,800,000.

* * *

## Summary

> The summary gathers the chapter in a few lines.

A business combination joins two or more businesses under common control, to gain strength or reduce competition. Owners combine for lower cost, buying power, less rivalry, safety, growth and skill. Each opportunity has a threat. The forms are merger, takeover, consolidation, holding company, cartel and trust. They differ in what survives and who controls. Horizontal integration joins the same stage; vertical integration joins different stages; a conglomerate joins unrelated trades. Every combination should be weighed from the owner's, the employee's and the customer's viewpoint, and under the law of the country concerned.

## Think It Through

> A baker buys the flour mill that supplies her bakery.

A baker in a town buys the flour mill that supplies her bakery. Before the purchase, the mill sold flour to her and to eight other bakers in the same town.

:q 16.t1 | Is this combination horizontal or vertical? Give a reason from the positions of the bakery and the mill in the chain.
:q 16.t2 | Name one opportunity for the baker, one threat for the baker, and one threat for the eight other bakers.

## Where People Go Wrong

> A merger and a takeover are not the same.

*A merger and a takeover are the same thing.* They are not. In a merger one company absorbs another and only one remains. In a takeover the buyer gains most of the shares, and the company bought can continue to exist under its own name.

> Combination does not always harm customers.

*Every combination is harmful or unlawful.* This is false. Many combinations lower costs and prices, and many are lawful. Laws usually aim at combinations that remove competition and harm customers.

> A holding company owns shares; it does not run each shop.

*A holding company runs every business in the group.* It owns enough shares to control them. The companies remain separate legal bodies, and each keeps its own name and accounts.

> Vertical does not mean joining rivals.

*Vertical integration joins competitors.* It does not. Competitors stand at the same stage, so joining them is horizontal. Vertical integration joins businesses at different stages, such as printer and bookseller.

> A combination is not harmful by size alone.

*A bigger business always has lower prices.* This is not certain. Size can lower cost, but a very large business may become slow and costly to manage, and without rivals it may have no reason to pass any saving to its customers.

## In History

> Standard Oil shows a combination, the public alarm it caused, and the law that followed.

John D. Rockefeller founded Standard Oil in Ohio, in the United States, in 1870. In the years that followed, the business absorbed many rival oil refiners. In 1882 the owners of Standard Oil and of the companies it controlled placed their shares in a trust. Nine trustees managed the whole group on behalf of all the owners, who received trust certificates in return. This was the first large trust in America, and other industries copied the model.

> The public alarm led to the Sherman Act of 1890 and to a court ruling in Ohio.

Many people feared that one business now controlled most of the country's oil. In 1890 the United States Congress passed the Sherman Antitrust Act, named for Senator John Sherman of Ohio. President Benjamin Harrison signed it on 2 July 1890. It was the first federal law against trusts. In March 1892 the Ohio Supreme Court ruled that the Standard Oil Company of Ohio must end its part in the trust.

> The owners changed the form, but the law caught up in 1911.

The owners did not give up control. They kept it through a holding company in New Jersey, another form from this chapter. In 1911 the United States Supreme Court found that the group had broken the Sherman Act and ordered it divided into separate companies. The story shows how forms of combination change. When the law closed one door, the owners used another. It also shows that the name of a form matters less than its effect on customers.

## Review Questions

:q 16.1 | Two bakeries in one town come under one owner. Is this horizontal or vertical integration? Explain.
:q 16.2 | A publisher buys the paper mill that supplies it. Classify the combination, say in which direction it moves, and name one opportunity and one threat.
:q 16.3 | Three mill owners agree to charge the same price but keep their mills. Name the form, and say how it differs from a merger.
:q 16.4 | A company buys most of the shares of another company, and the second company keeps its name. Name the form, and say what the buyer controls.
:q 16.5 | In the case file, which reason for combining appears in the rent saving, and which threat needs more facts before a decision?

:read Alfred D. Chandler Jr., The Visible Hand, 1977
:read Ida M. Tarbell, The History of the Standard Oil Company, 1904
