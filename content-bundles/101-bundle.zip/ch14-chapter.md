:chapter XIV | Multinational Corporations
:mood Whose business is it, when it crosses a border?
:desc This chapter describes companies that own and manage operations in more than one country. It explains what they are, why they spread across the world, and how they help and harm a developing country such as Bangladesh. It ends with a sewing machine company of the nineteenth century.
:plate ch14-plate.svg | A merchant's counting house with a globe, ship models and letters from abroad

> Two earlier chapters give the ideas that this chapter builds on.
:box YOU WILL NEED
Chapter 12 'Foreign Trade', section 12.1 'Why Nations Trade'; Chapter 9 'The Joint Stock Company', section 9.1 'What a Company Is'.

> The same names appear on shop signs in many countries, though their owners live far away.
Walk along a busy street in any large city of the world, and you may see the same names on the shop signs: the same soft drink, the same sports shoes, the same mobile network. The signs look alike in Dhaka, Nairobi and Lima. Yet the businesses behind them began in other places, and their owners often live far away.

> A business from one country that operates in another raises the question of whose business it is.
Here is the puzzle. When a business from one country opens an operation in another, whose business is it? It employs local people, pays local taxes and sells to local customers. Yet its decisions may be made in an office thousands of kilometres away, and its profit may travel there too. Is it a guest that brings gifts, or a competitor that takes the market? Different people give different answers, and each can give reasons.

> A business can reach customers abroad by crossing the border itself.
Chapter 12 explained how goods and services cross borders as exports and imports. There is a second way to reach customers abroad. Instead of sending goods across the border, a business can cross the border itself, and build or buy a business on the other side. This chapter studies the companies that do so. It asks what they bring to a developing country like Bangladesh, and what they may take away.

* * *

## 14.1 What a Multinational Is

> A multinational company is a business that operates in more than one country.
> Recall: joint stock company, Chapter 9 'The Joint Stock Company', section 9.1 'What a Company Is'.
@ Multinational corporation | A company that owns or controls operations in more than one country, managed from a home country.
@ Control | Word in use. In daily life, to make something obey, or the switch that works a machine. In business, the power to decide how a company is run, usually gained by owning most of its shares.
A baker who sells bread in two towns of one country is not a multinational. A **multinational corporation** is a company that owns or controls operations in more than one country, managed from a home country. A shoe company with its head office in one country and its own factories in three others is a multinational. The word *corporation* here names the same kind of business as *company*, so we write multinational company from now on. The home country is the country of the head office, and the next paragraphs explain it. Chapter 9 explained the joint stock company, and most multinational companies are of that kind.

> An exporter keeps its operations at home, but a multinational company crosses the border itself.
> Recall: foreign trade, Chapter 12 'Foreign Trade', section 12.1 'Why Nations Trade'.
How does a multinational company differ from a business that only exports? An exporter makes its goods at home and sends them across the border to customers abroad. All of its operations stay in one country. A multinational company crosses the border itself. It builds a factory, opens a shop or an office, or buys an existing business abroad. A tea packer in Sylhet that sends packets to the United Kingdom is an exporter. A company that builds its own packing plant in a second country, and runs it from its head office, is a multinational company.

> Control usually comes from owning most of a company's shares, but size is not the test.
The word *control* needs care. A company controls an operation when it can decide how that operation is run. The usual way to gain control is to own most of its shares, because ordinary shares carry votes. Ownership is not the only way, since a company may also control an operation through a long contract that fixes how the operation must work. Not every foreign dealing makes a multinational company. A company that buys goods from a foreign supplier does not control that supplier. Size is also not the test. A very large exporter that owns nothing abroad is not a multinational company.

> The home country holds the head office, and a host country holds a branch or subsidiary.
@ Home country | The country where a multinational company has its headquarters.
@ Host country | A country where a multinational company operates through a branch or subsidiary.
@ Home | Word in use. In daily life, the place where you live. Here, the country of the company's headquarters, which may not be where most of its customers live.
Every multinational company has one **home country**, the country where it has its headquarters. The headquarters is the main office, where the top managers sit and the chief decisions are made. A **host country** is a country where a multinational company operates through a branch or subsidiary. A branch is a part of the company itself, working in another country. A subsidiary is a separate company, which the next paragraphs explain. Suppose the shoe company has its head office in Italy and factories in two other countries. Italy is its home country, and the other two are host countries. A company has one home country and may have many host countries.

:pause 14.p1 | A company has its headquarters in Canada. It owns a factory in Bangladesh and a shop in Kenya. Name its home country and its host countries.

> A parent company controls a subsidiary by owning most of its shares.
> Recall: share, limited liability, Chapter 9 'The Joint Stock Company', section 9.1 'What a Company Is'.
@ Subsidiary | A company controlled by another company, called the parent, which owns most of its shares.
How does a company operate abroad through a separate company? It establishes a new company in the host country, or it buys an existing one. A **subsidiary** is a company controlled by another company, called the parent, which owns most of its shares. Suppose a parent owns 60 of every 100 shares of a company abroad. The parent holds most of the votes, so it controls that company, and the company abroad is its subsidiary.

> A subsidiary is a company in its own right, under the law of its host country.
A subsidiary is a company in its own right. It is registered under the law of the host country, it pays that country's taxes, and it must obey that country's rules. Because of limited liability, the parent can lose no more than the money it put in. A parent usually controls its subsidiaries, yet it does not always own every share, and local owners may hold the rest. Many students find this confusing, because the subsidiary seems to belong to the parent. In law, the parent owns the shares of the subsidiary, not the buildings and machines inside it.

> A supplier with a head office in London and an office in Dhaka is an example.
:case Case file, illustrative. Supplier record 2026: Larkspur Academic Press, with its headquarters in London, has subsidiaries in 9 countries and supplies Meghna and Sons. Its Dhaka office employs 24 people.

> The case shows each new word applied to one supplier.
We now apply the words to the case. Larkspur has operations in several countries and is managed from London, so it is a multinational company. Its home country is the United Kingdom. Bangladesh is one of its host countries, because it employs 24 people in Dhaka. Its subsidiaries in 9 countries are companies that Larkspur, the parent, controls. For the shop, an office in Dhaka may make orders easier to arrange.

> A multinational company can enter a host country by building a new operation or buying an existing one.
There are two main ways to enter a host country. The company may build a new operation, such as a factory on empty land. Or it may buy an existing company, which gives it buildings, workers and customers at once. Building is slower, but the company designs everything to suit its own methods. Buying is faster, but the company inherits the habits and the problems of the business it buys. A third way is to share ownership with local owners, who may know the country well. In each case the test of a multinational company is the same: does it control an operation in the host country?

> The figure draws a parent company and its subsidiaries as a hub with spokes.
The figure shows a multinational company as a hub with spokes. The parent company is the hub, and it stands in the home country. Each subsidiary stands at the end of a spoke, in a host country. A solid line shows control, which flows outward from the parent. A dashed line shows profit, which usually returns to the parent. Read the figure by following one spoke from the hub to a subsidiary and back.

:fig Home country, host country and subsidiaries drawn as a hub | ch14-fig01.svg

> A multinational company may choose managers from the home country, the host country or a third country.
Who runs the operation in a host country? A multinational company has three choices. It may send managers from the home country, hire managers from the host country, or use managers from a third country, one that is neither. The table compares the three. Read each row from left to right: the first cell names the choice, and the next two cells give a strength and a risk.

:table Three kinds of manager abroad
| Kind of manager | Strength | Risk |
| From the home country | Knows the parent's methods and is trusted by headquarters | May not know local law, language or customers |
| From the host country | Knows local law, language and customers, and costs less | May not know the parent's methods |
| From a third country | Brings wide experience of many places | May be a stranger to both the parent and the host country |

> Employees in the host country care who is chosen, because it decides who can rise.
Each choice has effects on people. A company that always sends managers from the home country leaves local employees with no path upward, and they may leave. A company that hires only local managers may lose touch with its headquarters. Many companies use a mixture. They send a few managers from the home country at the start, and they train managers from the host country to lead the operation later.

> The section ends with the main points on what a multinational is.
*Before moving on.* A multinational company owns or controls operations in more than one country and is managed from its home country. A host country is where it operates through a branch or subsidiary. A subsidiary is a company controlled by a parent that owns most of its shares. The managers abroad may come from the home country, the host country or a third country.

* * *

## 14.2 Why Multinationals Exist

> Companies go abroad to reach customers, lower costs and secure supplies.
Why would a company take the trouble to build a business in another country? Exporting is easier. The reasons come in several kinds. The first is customers: the home market may be small or crowded, and a new country offers more people to sell to. The second is cost: wages, land or materials may be cheaper in the host country. The third is supply: some materials, such as cotton or minerals, are found only in certain places. The fourth is taxes on imports: a company that cannot send goods across a border cheaply may make them inside it. The fifth is risk: a company with operations in many countries suffers less when one market fails.

> Foreign direct investment is money for a lasting business, not a quick sale of shares.
@ Foreign direct investment | Money a foreign company invests to build or buy a lasting business in another country.
The money that a company brings to build or buy these operations has a name. **Foreign direct investment** is money a foreign company invests to build or buy a lasting business in another country. A company that spends money to build a factory in a host country makes foreign direct investment. A person who buys a few shares for a quick sale does not, because no lasting business is built or controlled.

> A small example shows how lower costs can draw a company abroad.
Consider a small example. A company makes shirts, and labour costs it a fixed sum for each shirt at home. In a host country, the same work costs less, and the cotton is grown nearby. The company then makes shirts there and sells them in many countries. Its customers pay less, and its owners earn more profit. Cost alone does not decide the matter, because transport, skills and the rules of the host country also matter. The company weighs every one of them before it commits its money.

> Host countries gain money, jobs, skills and exports from foreign direct investment.
Host countries welcome this money for reasons of their own. A developing country usually has more workers than machines, and too little money at home to build every factory it needs. Foreign direct investment brings money, and it also brings skills and methods that the host country may lack. The new operation employs local people, buys materials from local suppliers and pays taxes. It may also sell goods abroad, which earns foreign money. The 24 people that Larkspur employs in Dhaka are a small example. Each of these gains depends on the rules the host country sets, as section 14.3 shows.

> A host country may refuse or limit a foreign company, and a company may decide against going.
Not every proposal succeeds. A host country may refuse a company, or limit what it may do. A company may also decide against a country, because its roads, laws or workers do not suit the business. Both sides have a choice, and each weighs gains against losses.

> The section ends with the main points on why multinationals exist.
*Before moving on.* Companies go abroad for customers, lower costs, supplies, ways around import taxes, and spread of risk. Foreign direct investment is money for a lasting business abroad. Host countries welcome it for the money, jobs, skills and exports that it can bring.

* * *

## 14.3 Effects on a Developing Country like Bangladesh

> A multinational company brings both benefits and problems, and the balance depends on the case.
Is a foreign company good for a developing country? A developing country is one whose people have, on average, lower incomes and fewer factories than people in the richest countries, but whose economy is growing. Bangladesh is such a country. The honest answer is that a multinational company brings both benefits and problems, and the balance depends on the case. We take the benefits first, then the problems, then the control that governments use.

> The benefits are jobs, money, skills, taxes, exports and wider choice for customers.
The benefits are easy to name. The company gives jobs and pays wages. It brings money that the country may lack. Its employees learn new skills, and some later use them in local businesses. It pays taxes, which the government spends on roads, schools and hospitals. It may export goods and earn foreign money. A customer in the host country may find better goods and lower prices. A local supplier may gain a large new customer.

> Foreign companies can pass on skills and methods, which local owners may later use.
One benefit deserves a longer look: the spread of skills. A foreign company often brings machines, methods and training that the host country has not used before. Its employees learn them in daily work. Some later leave to start businesses of their own, or to join local ones, and they carry the knowledge with them. Local suppliers learn to meet the standards that the foreign company demands, and those standards help them win other customers. This spread is not automatic, but where it happens, it can last long after the foreign company has gone.

> A benefit is not automatic, because it depends on how the company chooses to operate.
A benefit is not automatic. A factory that employs 500 workers but buys all its parts abroad gives fewer gains than one that buys from local suppliers. A company that sends its best jobs to managers from the home country gives its local employees less chance to learn. The gains depend on what the company does and on what the host country requires.

> The problems are profit sent abroad, strong competition, dependence and lower standards.
The problems are equally real. Much of the profit may be sent to the home country instead of being spent in the host country. A local owner of a small business may lose customers to a company with more money and a famous name. Decisions are made abroad, so the parent may close its subsidiary when costs rise, and the employees lose their work. Some companies pay low wages or ignore safety and the environment where the law is weak. Evidence differs from company to company and from country to country, so we judge each case on its facts.

> Employees, customers and local owners each see the effects from a different position.
The viewpoint matters. An employee sees wages and chances to learn. A customer sees price and choice. A local owner sees a new competitor, or a new customer. A government sees taxes, jobs and the power of an outside company over its own affairs. All four viewpoints are correct, and a good decision weighs them together.

> Governments control foreign companies through laws on ownership, licences, taxes, profits and standards.
> Recall: control, section 14.1 'What a Multinational Is'.
Governments respond with rules. A government may limit the share that a foreign company may own in some industries. It may require a licence before a company starts work. It may tax profits, and it may set rules on how much profit may be sent abroad. It may set standards for pay, safety and the environment. It may ask the company to train local workers or buy local materials. The rules differ by country. Bangladesh, like many developing countries, wishes to attract foreign investment and also to protect local businesses and workers, and its laws try to balance both wishes.

> Control is a balance, because rules that are too strict or too loose both do harm.
Control is a balance. If the rules are too strict, the company may take its money to another country, and the host country loses the jobs. If the rules are too loose, local businesses and workers may be harmed. A government of a host country therefore studies each proposal before it agrees, and it reviews the rules as conditions change.

> The section ends with the main points on effects on a developing country.
*Before moving on.* A multinational company can give a host country jobs, money, skills, taxes and exports. It can also send profit abroad, crowd out local owners, create dependence and lower standards. Governments use laws on ownership, licences, taxes, profits and standards to balance the two.

* * *

## A Worked Case: Meghna and Sons Orders from a Multinational

> A worked case applies the ideas of this chapter to one order from a multinational supplier.
This worked case applies the chapter to one supplier record. It has five parts: the situation, the question, the reasoning, the conclusion and a check. Many students find the arithmetic easy and the classification harder, so we take the classification first. GBP means pounds sterling, the money of the United Kingdom.

### Situation

> The record gives the supplier, the discount and the order in two kinds of money.
:case Case file, illustrative. Supplier record 2026: Larkspur Academic Press (illustrative; London headquarters, subsidiaries in 9 countries) supplies the shop. The trade discount is 35% off list. An order of 400 books at list GBP 20, at an illustrative Tk 150 per GBP, has a list value of Tk 1,200,000 and a price after discount of Tk 780,000.

### Question

> The question asks what kind of company the supplier is and how the price was reached.
What kind of company is Larkspur, and how does its list value of Tk 1,200,000 become a price of Tk 780,000? A trade discount is a reduction from the list price that a supplier gives to a business customer who will resell the goods.

### Reasoning

> Reasoning proceeds in four steps: classify, find the list value, take the discount and subtract.
First we classify. Larkspur is managed from London and has subsidiaries in 9 countries, so it is a multinational company with the United Kingdom as home country. It employs 24 people in Dhaka, so Bangladesh is a host country. Second, we find the list value. Each book lists at GBP 20, so 400 books list at 400 times 20, which is GBP 8,000. At Tk 150 per GBP, GBP 8,000 is 8,000 times 150, which is Tk 1,200,000. Third, we take the discount. The discount is 35 per cent of Tk 1,200,000, which is Tk 420,000. Fourth, we subtract. Tk 1,200,000 minus Tk 420,000 is Tk 780,000.

### Conclusion

> The shop pays Tk 780,000 for 400 books, which is Tk 1,950 for each book.
Larkspur is a multinational company, and the shop pays it Tk 780,000 for the order. Dividing by 400 gives Tk 1,950 a book, against a list price of Tk 3,000 a book. The owner of the shop gains from the discount. The prices are fixed in pounds, so the taka cost depends on the rate for converting pounds to taka, which is illustrative here.

### Check

> A second route to the answer confirms that the price is sensible.
Check by a second route. A discount of 35 per cent leaves 65 per cent to pay. Sixty-five per cent of Tk 1,200,000 is Tk 780,000, which equals the first answer. The price is also below the list value, as a discounted price must be. A third check uses one book: Tk 1,950 times 400 is Tk 780,000.

* * *

## Summary

> The summary lists the main ideas of the chapter in a few lines.
A multinational company owns or controls operations in more than one country and is managed from its home country. A host country is where it operates through a branch or subsidiary, and a subsidiary is a company controlled by a parent that owns most of its shares. Managers abroad may come from the home country, the host country or a third country. Companies go abroad for customers, lower costs, supplies and spread of risk. Foreign direct investment is money for a lasting business abroad. A developing country gains jobs, money, skills, taxes and exports, and it risks profit sent abroad, strong competition, dependence and lower standards. Governments use rules to balance the two.

## Think It Through

> This case asks whether a country should welcome a foreign company.
A foreign company offers to build a garment factory that will employ 500 people in a developing country. It will own all the shares, send most of its managers from the home country, and send its profit to the home country. The government must decide whether to welcome the offer.

:q 14.t1 | List two gains and two losses that the host country may expect.
:q 14.t2 | Name two conditions the government might set, and say what each condition protects.

## Where People Go Wrong

> Many students think that any very large company is a multinational company.
A common error says that any very large company is a multinational company. Size is not the test. The test is whether the company owns or controls operations in more than one country. A large exporter that owns nothing abroad does not pass it.

> A subsidiary is a separate company, so its parent does not own its buildings.
Another error says that a subsidiary is only a part of its parent. A subsidiary is a company in its own right, registered under host-country law. The parent owns its shares, not its buildings and machines.

> The home country is the country of the headquarters, not the country of most customers.
A third error calls the home country the place where the company sells most. The home country is where the headquarters stands. A company may sell most of its goods in a host country.

> Foreign direct investment means lasting investment, not any foreign money.
A fourth error treats all foreign money as foreign direct investment. The term covers money used to build or buy a lasting business. A person who buys a few shares for a quick sale does not make foreign direct investment.

> A multinational company is neither always good nor always bad for a host country.
A fifth error gives one answer for all companies. Some multinational companies give a host country much, and some give little or cause harm. Judge each company on what it does and on the rules it must follow.

## In History

> Singer's factory in Glasgow, opened in the 1860s, was an early overseas factory of an American company.
The Singer Manufacturing Company was an American company that made sewing machines. In 1867 it opened its first factory outside the United States, in Glasgow, Scotland. George Ross McKenzie, a vice-president of the company, chose Glasgow for its iron industry, cheap labour and shipping.

> The company later built a much larger plant at Kilbowie, near Glasgow.
By the early 1880s the Glasgow factory was too small. In 1882 McKenzie began work on a much larger plant on farmland at Kilbowie, in Clydebank, near Glasgow. The plant opened in 1884, and it was finished in 1885. From 1884 until 1943 it made about 36 million sewing machines. It closed in 1980.

> The history shows each new word at work in one company.
The words of this chapter fit the history. The United States was Singer's home country, and Scotland, part of the United Kingdom, was a host country. In 1905 a British company, Singer Manufacturing Company Limited, was registered to run the Clydebank works, which made it a subsidiary of the American parent. Scotland gained jobs, skills and a famous factory. It also depended on decisions made in an office in another country, and the factory closed when those decisions changed.

## Review Questions

> These questions climb from a familiar case to a case that combines earlier ideas.
:q 14.1 | List three gains and three losses that a host country may experience when a multinational company opens a subsidiary there.
:q 14.2 | Suppose Larkspur sold books to Dhaka only by shipping them from London, and kept no office in Bangladesh. Would Bangladesh still be a host country for Larkspur? Explain.
:q 14.3 | A company with its headquarters in India buys 70 of every 100 shares of a garment company in Bangladesh. Name the parent, the subsidiary, the home country and the host country. What kind of investment is this?
:q 14.4 | A second order from Larkspur is for 500 books at list GBP 16. The trade discount is 25 per cent, and the rate is Tk 150 per GBP. Find the list value and the price after discount, in taka.
:q 14.5 | Explain, using the word control, why a company that only exports is not a multinational company.

:read Vernon, Raymond, Sovereignty at Bay, 1971
:read Jones, Geoffrey, Multinationals and Global Capitalism, 2005
