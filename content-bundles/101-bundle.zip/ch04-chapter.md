:chapter IV | Choosing Where a Business Stands
:mood Why does one street reward a business while the next street ruins it?
:desc Every business must stand in some place. This chapter shows how an owner weighs materials, customers, transport, workers, power, land, services and public rules before choosing a site, and why that first choice shapes every later year.
:plate ch04-plate.svg | A canal wharf of the 1860s, where goods, barges and buyers met

> This note names the earlier ideas to know before reading on.

*You will need* two earlier ideas. The first is land and natural resources: see Chapter 2, 'Factors of Production', section 2.1 'Land and Natural Resources'. The second is what a business needs to succeed: see Chapter 3, 'Objectives of Business and What Makes It Succeed', section 3.3 'What a Business Needs to Succeed'.

> Two bakers with equal money face very different surroundings.

Imagine two bakers who begin on the same day. They have the same oven, the same recipe and the same savings. The first baker opens a shop in a quiet village, where the rent is low and flour comes from a mill nearby. The second opens a shop beside a crowded railway station in a large town, where the rent is high and the flour must travel a long way. After one year, which baker is better off?

> Neither low costs nor many passers-by decide the answer alone.

The answer is not obvious, and that is the point. The village baker pays little for the shop and little for flour, yet few people pass the door. The station baker pays more for both, yet many people pass every hour. If bread sells slowly, low costs cannot rescue the village baker. If the rent consumes the money from sales, a busy door cannot rescue the station baker. Neither baker can decide from one fact. Each must weigh several facts together.

> Every business meets this problem before its first sale.

Every business meets this problem before it makes its first sale. A shop must stand somewhere; so must a factory, a workshop or an office. The place is hard to change later, and it affects the money going out and the money coming in for many years. This chapter teaches you how a business weighs the facts that decide its place. It follows one documented case, a bookshop in Dhaka that compares three districts for a second shop, and it ends with a real decision made in India in 1907.

## Why Location Matters

> A family choosing a home weighs several facts, and a business does the same.

Think first about a family that must choose a home. The family compares the rent, the distance to school and to work, the safety of the street and the nearness of shops. No single fact decides the matter. The family weighs the facts together and accepts that no home is perfect. A business makes a choice of the same kind, with more money at stake and with more people affected by the result.

> A plant location is the place chosen for a factory or shop after weighing several factors.
@ Plant location | The place where a business builds its factory or opens its shop, chosen by weighing several factors.
@ Plant | Word in use. In daily life, a living thing that grows in soil. In business, the buildings and machines used to make goods.

A **plant location** is the place where a business builds its factory or opens its shop. The baker in the opening puzzle faced this decision: the village or the station. The word *plant* has a special meaning here. It means the buildings and machines that make goods, and a shop is included in the idea, because a shop also needs a site. A site is one particular piece of land or one particular building. The business compares each possible site with the factors in this chapter and then chooses one.

> The weight of each factor differs from one business to another.

The factors do not carry equal weight for every business. A steel producer gives great weight to iron ore and coal, because both are heavy and costly to carry. A bookshop gives great weight to the number of people who walk past its door. A software office gives great weight to skilled workers and a reliable electricity supply. A wise owner asks which factors matter most for the business before asking which site is best. The first answer differs for each business, so the best site differs too.

> A chosen site is difficult and costly to leave.

A site is also a fixed commitment. To see why, think of moving house. You must pay for transport, pack your goods, and often find a new school, so a move costs money and time. A business that moves faces the same costs on a larger scale. It may have signed a lease, which is a written agreement to rent a building for a fixed period. It may have built a factory or fixed heavy machines to the floor. It may also lose customers who knew the old address. The trust those customers felt for the business, its goodwill, may be harmed.^1

^1: Recall: what a business needs to succeed, Chapter 3, section 3.3 'What a Business Needs to Succeed'. A site that fails the business threatens its survival.

> Some commitments are lighter than others.

The commitment is not equally heavy for every business. A rented shop can be left when the lease ends. A small office with a few desks and computers can move in a weekend. A steel mill cannot move at all without being rebuilt. For this reason the owner must judge a site not only for today but for the years ahead. A site that suits a young business of seven staff may not suit the same business when it has seventy.

> A site changes both the money a business spends and the money it receives.
@ Cost | Word in use. In daily life, the price you pay for something. In business, any money spent to make and sell goods, such as rent, wages and transport.

The site affects two sides of the business at once. On the side of cost, it decides the rent, the price of carrying materials in and goods out, and the wages that workers expect. Here *cost* means any money a business spends to make and sell its goods. On the side of sales income, it decides how many customers can reach the business and how much they will pay. A site that lowers cost may also lower sales income, as the village baker may discover. The money left after cost is taken from sales income is the profit.

> A good site widens the gap between sales income and cost.

A good choice widens the gap between sales income and cost. The objective of the business changes how that gap is judged. A business whose first objective is survival in a hard year may choose the cheaper site. A business whose objective is growth may accept a high rent for a place that brings many customers. The owner should therefore state the objective before comparing sites, because the same site can be right for one objective and wrong for another.

> Before moving on: this section gave three ideas.

*Before moving on.* Plant location is the choice of a place for a factory or shop, made by weighing factors. A site is a fixed commitment, because leaving it costs money, time and goodwill. A site changes both cost and sales income, and its worth depends on the objective of the business.

## Pull of Materials and Markets

> Think of each factor as a pull that draws the site toward it.

Imagine several people holding one rope and pulling in different directions. The knot in the middle settles where the pulls balance. Each factor in this chapter acts like one of those pulls on the site. Two of the strongest pulls come from the two ends of the business: the place where materials begin and the place where customers wait.

> Some businesses stand near their materials because carrying them is costly.

Many businesses gather materials from the land, such as ore, cotton, timber, sugar cane or limestone. When the making process removes much weight, the business saves money by standing close to the source. Cement makers stand near limestone, and sugar mills stand near cane fields, because cane must be crushed soon after cutting. Carrying heavy waste a long distance would raise cost with no gain. This is the pull of nearness to raw material, and it is strongest for heavy materials that lose weight in the making.

> Nearness to materials matters less when transport is cheap or materials come from many places.

The pull has exceptions. A business that imports its materials by ship may stand near a port instead of near a mine. A business that gathers small amounts from many places has no single source to stand beside. A business that makes goods from light materials, such as a software office or a printer, feels almost no pull of this kind. The owner must therefore ask how heavy the materials are, how much weight is lost in the making, and how far they travel.

> Some businesses stand near customers because their goods spoil, break or must be bought quickly.

The opposite pull comes from the customers. Goods that spoil quickly, such as bread, fresh milk or ice, must reach customers within hours. Goods that break easily, such as glass bottles, or that grow bulky in the making, such as furniture, are costly to carry far. Every shop stands near its customers by nature, since a customer must walk or ride to reach it. This is the pull of nearness to market, and here *market* means the customers who buy the goods.

> Footfall is the count of people passing or entering a shop in a given time.
@ Footfall | The number of people who walk past or enter a shop in a given time.

A shop measures this pull by counting people. **Footfall** is the number of people who walk past or enter a shop in a given time. For example, an owner may stand near a possible site for five days and count the people who pass each day, then take the average. Footfall counts people, not buyers. Many people may pass a door and buy nothing, so a high count shows an opportunity, not a certain sale.

:pause 4.p1 | A bakery and a brick works each choose a site. Which should stand nearer its customers, and why?

> Transport and communication join the business to its materials, its workers and its customers.

Materials, goods and workers must all travel. Transport here means roads, railways, rivers, ports and airports, with the vehicles that use them. Communication means the passing of messages by post, telephone and the internet. A site beside a good road or a railway lowers the cost of bringing materials in and sending goods out. Before railways, canals served this purpose in many countries, and the plate at the start of this chapter shows a canal wharf of the 1860s, with barges beside the warehouses. A business also needs reliable communication to receive orders, pay suppliers and answer customers.

> A route is valuable only if it is fast, safe and reliable.

Transport does not only lower cost; it also changes speed and reliability. A cheap road that floods each year may cost more than a dearer road that stays open. A supplier who cannot deliver on time forces the business to hold more stock, which costs money to store. A software office may care little for roads but a great deal for a stable internet link. For this reason the owner examines the quality of each route and not only its price.

> The sketch shows three pulls acting on one possible site.

Now we read a sketch of the three pulls so far. It is a map, not a photograph. The circle in the middle is a possible site. Three arrows leave the circle. Each arrow points toward one thing that pulls the site: the raw material on the left, the customers on the right and the transport route below. The site settles where the three pulls balance, and each label names the pull that its arrow shows.

:fig Three pulls acting on one possible site | ch04-fig01.svg

> Before moving on: this section named three pulls.

*Before moving on.* Nearness to raw material draws heavy, weight-losing businesses toward their sources. Nearness to market draws businesses whose goods spoil, break or need quick sale, and footfall measures it for a shop. Transport and communication join the other two, and their quality matters as much as their price.

## Labour, Power, Land and Services

> Four more pulls come from workers, energy, land and supporting services.

The first two pulls came from the two ends of the business. The next four come from what the business needs every day: workers, energy, space and help from other organisations. A site that is strong on materials and customers can still fail if it is weak on these four.

> A business needs enough workers with the right skills at wages it can pay.

Labour is the work of people, and every site has its own supply of it. The owner asks three questions. Are there enough people living nearby? Do they have the skills the business needs? What wages do they expect? A bookshop needs staff who can reach the shop at opening time. A software office needs trained programmers, who are found mainly in large towns. A garment factory needs many workers, so it seeks a place with a large working population. Workers are also customers of the neighbourhood: a site far from homes and bus routes makes every working day longer.

> Wages and skills differ by place, and machines can lessen the need for workers.

The pull of labour has limits. Wages and skills differ between towns, between regions and between countries. A business that uses many machines needs fewer workers and may care less about this pull. Skilled workers may also be willing to move to a new town if the pay is good, though a move costs them money and time. The owner should compare not only the wage but the output each worker can produce.

> Power and water are daily needs, and a shortage can stop the whole business.

Many businesses depend on power, which means electricity, gas or fuel to run machines, ovens and lights, and on water for washing, cooling and drinking. A bakery needs steady heat for its ovens. A steel mill needs very large amounts of water for cooling. A site where supply fails often forces the business to stop work while wages and rent continue. The owner should discover how reliable each supply is, what it costs, and whether the site is joined to the public network.

> A business may buy its own generator or water store, but this adds cost.

A weak supply can sometimes be repaired at a price. A business may buy a generator to make its own electricity or build a tank to store water. Each choice adds cost for equipment, fuel and care. An office needs little water but needs power and internet without interruption. The question to ask is therefore not "Is there power?" but "How often does the power fail, and what does a failure cost this business?"

> Land cost and land laws limit where a business can afford to stand.

Land is the third pull.^2 A factory needs a large area, while a shop needs a small area in a busy street. The price or rent of land usually rises toward the centre of a town, where customers are many, and falls toward the edge, where customers are few. Land cost is measured per square foot or per acre, so two sites of different size must be compared by that measure. The owner must also remember that land is not free to use. Each country and each city has rules that say where homes, shops and factories may stand, and what permission a business must obtain first.

^2: Recall: land and natural resources, Chapter 2, section 2.1 'Land and Natural Resources'.

> An industrial estate groups factories in one planned area with shared services.
@ Industrial estate | An area planned and serviced by an authority where many factories are grouped together.

An **industrial estate** is an area planned and serviced by an authority where many factories are grouped together. For example, the authority may provide roads, power, water and waste removal for all the factories at once, so that no factory has to build these alone. Public authorities in Bangladesh and in many other countries have established such estates. The advantage is lower cost and fewer problems with local rules. The disadvantage is that an estate may stand far from customers, and that plots and fees are controlled by the authority.

> Banks and insurers lessen risk, and a site near them saves time.

A business also needs banks and insurers. It deposits its takings in a bank, borrows from it, and pays its workers through it. It buys insurance, which is a payment made so that an insurer will cover a loss from fire, theft or flood. A site in a town centre usually has many of these services nearby. Many banking tasks can now be done by telephone or online, so this pull is weaker than it was in the past.

> Before moving on: this section named four daily needs.

*Before moving on.* Labour supply depends on the number, skills and wages of the workers nearby. Power and water are daily needs, and a shortage stops the business. Land cost is compared per unit of area, and local laws limit where a business may stand; an industrial estate groups factories with shared services. Banks and insurers form a lighter pull.

## Government and Community Factors

> Governments and communities shape a site through rules, support and conditions.

The last factors come from outside the business. Governments, climate and the safety of an area are not chosen by the owner, yet each can raise or lower the worth of a site.

> Government policy can reward a business for choosing a place.

Government policy is the set of rules and support that a government applies to business. Many governments offer incentives, which means benefits that encourage a business to choose a place. Examples are lower tax for a number of years, cheaper land and grants. Governments often use them to bring work to areas with few jobs. Rules differ by country and change over time, so an owner must check the current rules before relying on any benefit.

> Heat, rain and flood affect buildings, stock and workers.

Climate and environment also matter. Bangladesh has heavy monsoon rain, and some areas are flooded in many years, so a low site may need protection for its stock. Books and paper suffer from damp, and some foods need cool storage. A business that produces smoke, noise or waste must also respect rules that protect the air and water of nearby people. A site that suits the business today but floods each year carries a hidden cost.

> A site must be safe for staff, customers and goods.

Safety and security complete the list. The owner asks whether the street is safe at night, whether theft or fire is common, and whether staff and customers can travel to the site without danger. A business may pay for locks, lights and guards, and an insurer may charge more for a risky area. A site that looks cheap but needs heavy protection may cost more in the end.

> Weighing the factors means ranking them and accepting a compromise.

Weighing the factors is the last step. The owner lists the factors that matter, ranks them by their importance to the objective of the business, and compares each possible site on each factor. Rarely does one site win every comparison, so the owner accepts a compromise and records the reasons. The decision is not final for ever: if costs, customers or laws change, the business may move, as the history at the end of this chapter shows.

> Before moving on: this section named four outside factors.

*Before moving on.* Government policy and incentives can lower cost, but they change. Climate and environment affect buildings, stock and workers. Safety and security affect staff, customers and insurance cost. Weighing the factors means ranking them by the objective of the business and accepting a compromise.

* * *

## A Worked Case: A Second Shop for Meghna and Sons

> A worked case applies the factors to a documented record and is not a model answer.

A worked case applies an idea to a situation. It has five parts: the situation, the question, the reasoning, the conclusion and a check. Here we apply the factors of this chapter to one case file.

> The situation is a record of three sites for a second shop.
:case Case file, illustrative. On 12 May 2026 the file for Meghna and Sons records a site choice for a second shop. Three sites are listed. Dhanmondi is the existing shop: rent Tk 60,000, 900 square feet, footfall 410 a day. Mirpur: rent Tk 38,000, 700 square feet, footfall 520 a day, with three schools within 600 metres. Uttara: rent Tk 52,000, 800 square feet, footfall 380 a day, with parking available. The footfall counts are five-day averages.

> The table sets the three sites side by side on the same measures.

The table below puts the recorded facts in one place. Read each row as one site and each column as one measure; the rent is taken as Tk per month, as at the existing shop.

:table The three sites in the case file
| Site | Rent (Tk a month) | Area (square feet) | Footfall a day | Other record |
| Dhanmondi (existing) | 60,000 | 900 | 410 | None recorded |
| Mirpur | 38,000 | 700 | 520 | Three schools within 600 metres |
| Uttara | 52,000 | 800 | 380 | Parking available |

> The question asks which site the recorded facts favour.

*Question.* Which site do the recorded facts favour for a second shop, and what further facts are needed?

> Reasoning begins with rent per square foot, so sites of different size can be compared.

*Reasoning.* Sites differ in size, so we first compare rent per square foot. Divide the monthly rent by the area. Dhanmondi: 60,000 ÷ 900 = Tk 66.67. Mirpur: 38,000 ÷ 700 = Tk 54.29. Uttara: 52,000 ÷ 800 = Tk 65.00. All answers are in taka per square foot a month, rounded to two decimal places.

> The second step compares how many people pass for each Tk 1,000 of rent.

Next we compare footfall with rent. Divide the daily footfall by the monthly rent in thousands of taka. Dhanmondi: 410 ÷ 60 = 6.83. Mirpur: 520 ÷ 38 = 13.68. Uttara: 380 ÷ 52 = 7.31. A higher number means more people pass for each Tk 1,000 of rent. The third step uses facts that no calculation can measure: Mirpur has three schools within 600 metres, which may bring students and parents past the door, and Uttara has parking, which helps customers who arrive by car.

> On the figures given, Mirpur leads on rent and footfall but needs more checks.

*Conclusion.* On the recorded figures, Mirpur has the lowest rent per square foot and the highest footfall, and it passes nearly twice as many people per Tk 1,000 of rent as either other site. It is also the smallest site, so part of its lower rent reflects less space. The file does not record how many of the people counted buy books, and footfall counts people, not buyers. The choice needs further facts: the supply of staff who can reach the site, delivery of stock, and the local land rules.

> The check repeats the arithmetic backwards and compares it with the record.

*Check.* Multiply each rate by its area. For Mirpur, 54.29 × 700 = 38,003, which equals Tk 38,000 apart from rounding. For Dhanmondi, 66.67 × 900 = 60,003. The result is sensible, because Mirpur has the lowest rent in the file and also the lowest rent per square foot.

* * *

## Summary

> The summary lists the main ideas of the chapter.

Plant location is the choice of a place for a factory or shop by weighing factors. A site is a fixed commitment that affects cost and sales income for many years. The main pulls come from materials, customers, transport, labour, power and water, land and its laws, services, government policy, climate and safety. Each factor has a different weight for each business, so the owner states the objective, ranks the factors and accepts a compromise.

## Think It Through

> The questions below change the situation step by step.

Use the case file in the worked section for the first two questions. The last two change the setting.

:q 4.t1 | An owner values low rent above every other factor. Which of the three sites does the owner prefer? Give two figures from the case file that support the answer.

:q 4.t2 | Suppose the rent at Uttara falls from Tk 52,000 to Tk 40,000 for the same 800 square feet. Find the new rent per square foot, then say whether Uttara now beats Mirpur on that measure and on footfall for each Tk 1,000 of rent.

:q 4.t3 | A software office with ten staff must choose between a busy city centre and a quiet town. Which factors matter most, and which matter little?

:q 4.t4 | A bakery has stood in one street for ten years. A new road reduces its footfall, and the owner is offered cheaper land in an industrial estate. What must the owner weigh before deciding to move?

## Where People Go Wrong

> Four common mistakes about site choice, each with its correction.

*Mistake.* The cheapest site is the best site. *Correction.* Low rent may come with low footfall, poor transport or weak power. The owner compares the total effect on cost and sales income, not the rent alone.

> A site is not a final decision.

*Mistake.* Once the owner has chosen a site, the choice is final. *Correction.* A site is a heavy commitment, but conditions change. Costs, customers and laws move, and a business may leave a site when staying costs more than leaving.

> Footfall measures people who pass, not people who buy.

*Mistake.* High footfall means high sales. *Correction.* Footfall counts people who pass or enter. Only some of them buy, so a high count shows an opportunity and must be checked against sales.

> One factor does not always decide the matter.

*Mistake.* One factor always decides, such as nearness to customers. *Correction.* The weight of each factor depends on the business. Heavy materials decide for a cement maker; skilled workers decide for a software office.

## In History

> The Tata steel company in 1907 chose its site by weighing materials, water and transport.

In the 1900s India imported much of its steel from Britain. Jamsetji Tata, an Indian industrialist, had planned an iron and steel company for years. After his death his son, Sir Dorabji Tata, registered the Tata Iron and Steel Company on 26 August 1907.

> The company chose Sakchi because several needed factors lay close together.

The company chose a site at Sakchi, a village in the Singhbhum district of what was then Bihar province and is now Jamshedpur in the Indian state of Jharkhand. The reasons match the factors of this chapter. Iron ore lay in the region, found by a geologist named Pramatha Nath Bose at Gorumahisani. Coal came from the Jharia field. The Subarnarekha river supplied water. Railways joined the site to the ore, the coal and the large city of Calcutta, now Kolkata. In 1908 the company acquired about 3,584 acres of land around the village.

> The site later grew into a company town.

Production followed: pig iron in 1911 and steel in 1912. The village grew into a steel town, and in 1919 the Viceroy, Lord Chelmsford, renamed Sakchi as Jamshedpur in honour of Jamsetji Tata. The case shows that the best sites combine several factors, and that a choice made in 1907 shaped the place for generations.

## Review Questions

> The questions below ask the reader to apply the chapter.

:q 4.1 | Explain plant location in your own words and give one example of a business and its site.

:q 4.2 | Explain why a site is a fixed commitment, and name two things a business may lose by moving.

:q 4.3 | Rank the factors in this chapter for a bakery, from most to least important, and give a reason for the first and the last.

:q 4.4 | Rank the factors for a steel mill, from most to least important, and give a reason for the first and the last.

:q 4.5 | Rank the factors for a software office, from most to least important, and give a reason for the first and the last.

:q 4.6 | Explain the difference between footfall and sales, and say why an owner should not rely on footfall alone.

