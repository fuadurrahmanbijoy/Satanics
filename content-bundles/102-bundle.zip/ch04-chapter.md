:chapter IV | The Evolution of Management Thought
:mood Can the work of a shop be studied like a science?
:desc This chapter follows the ideas of management from the early factories to the modern organisation. You will meet Taylor, Fayol, Weber and Mayo, learn what each believed, and see how their ideas still shape a shop floor, an office and a busy kitchen.
:plate ch04-plate.svg | A time-keeper at the clock watches rows of employees at their benches in a Victorian factory

:box YOU WILL NEED
This chapter uses two earlier ideas. The first is whether management can claim to be a science, in Chapter 3 'The Functions of Management and How Management Is Judged', section 3.4 'Science, Art or Profession'. The second is the list of activities that every manager performs, in Chapter 3 'The Functions of Management and How Management Is Judged', section 3.1 'The Management Process'.

> Two shops with the same books and staff can earn very different results.

Picture two bookshops in the same street. They stock the same titles, charge the same prices and employ the same number of people. Yet at the end of the year one shop has sold far more books than the other. The books have not changed, so something else has. What is it? Many students first answer "luck" or "a better owner". Both answers may hold some truth, but neither can be taught, and nobody can learn luck.

> For most of history nobody studied management; people learned by watching.

For thousands of years, people managed armies, farms, trading houses and building sites without a book of management to read. A young person learned by watching an older one, and good methods stayed secret inside families. This worked while work was done in small groups. It failed when factories gathered hundreds of people under one roof, because no one could learn fast enough by watching. Owners needed ideas that could be written down, tested and passed on. This chapter tells how such ideas were found, and in what order.

> Thinkers who share one main idea are placed together in one school.

@ School | Word in use. In daily life, a place where children learn. In management, a group of thinkers who share one main idea about how to manage.

Historians place thinkers who share one main idea in the same school of thought. We shall meet several schools, one after another. The timeline below is a map of the road. Read it from top to bottom: each row is one school, each bar shows the years when its ideas were most active, and the scale along the bottom gives the dates. Do not worry about the names yet; each is explained in its own place.

:fig Timeline of the schools of management thought | ch04-fig01.svg

* * *

## 4.1 Early Management and Scientific Management

> Factories created problems that older ways of managing could not solve.

Why did management ideas appear when they did? Because factories created new problems. From about 1760 in Britain, machines and factory buildings brought many employees together (older books call them workers), and an owner could no longer watch every task. Three early thinkers deserve one line each. Adam Smith, a Scottish thinker, wrote in 1776 that dividing a job into small steps raised output, and he used a pin factory as his example. Robert Owen, a Welsh-born manager of cotton mills at New Lanark in Scotland from 1800, argued that good conditions for employees helped the business. Charles Babbage, an English mathematician, wrote in 1832 that the steps of a task should be studied and measured.

> Taylor noticed that employees worked slower than they could, and asked why.

Each early thinker offered one useful idea, but none joined the ideas into a complete method. That step came from Frederick Winslow Taylor (1856 to 1915), an American engineer who worked in steel works in Pennsylvania and published *The Principles of Scientific Management* in 1911. Taylor noticed that employees often worked more slowly than they could. Each person followed a personal rule of thumb, which means a method learned by habit and not tested by measurement. Some employees also feared that faster work would reduce the number of jobs. Taylor asked a plain question: what is the best way to do this task, and how long should it take?

> Scientific management means finding the one best method by measuring work.

@ Scientific management | The study of work by measurement, aimed at finding the one best method and training workers in it.

His answer was **scientific management**. Scientific management means studying work by measurement, to find the one best method and to train employees in it. For example, a foreman who once chose how to load a wagon by habit would, under this idea, test several ways and measure which was fastest. The word "scientific" matters: Taylor wanted facts from measurement to replace opinion and habit.^1

^1: Whether management can claim to be a science is discussed in Chapter 3 'The Functions of Management and How Management Is Judged', section 3.4 'Science, Art or Profession'.

> Timing each movement removes wasted effort and sets a fair standard.

@ Time and motion study | Timing each movement of a task to remove wasted effort and set a fair standard.

The main tool of scientific management is the **time and motion study**. A time and motion study means timing each movement of a task, to remove wasted effort and to set a fair standard. Taylor timed tasks with a stopwatch. Frank Gilbreth and his wife Lillian Gilbreth, American engineers working in the early 1900s, studied the movements of the hands and body and removed those that gave no benefit. Together the two ideas answer two questions: which movements are needed, and how long they should take.

> The shop timed the unloading of a carton before and after a fixed shelf list.

:case Case file, illustrative. Method change 1 March 2026: unloading a carton of books was timed at 14 minutes before and 9 minutes after a fixed shelf-position list. The shop unloads 10 cartons a day, so the saving is 5 x 10 = 50 minutes a day.

> Taylor set out four principles that turn the idea into rules for managers.

Taylor summarised his ideas in four principles. First, replace rule-of-thumb methods with a science for each element of a job. Second, choose each employee with care, then train and develop that person, instead of leaving the employee to learn alone. Third, cooperate with employees so that the work is done according to the science that has been worked out. Fourth, divide the work and the responsibility between managers and employees: managers plan and prepare, and employees perform.

> Scientific management raised output but treated employees as parts of a machine.

Taylor expected both sides to gain, and he proposed higher pay for employees who reached the standard. Even so, the idea has limits. Critics said that it treated employees as parts of a machine, that it ignored their feelings, and that trade unions feared that standards would be raised again and again. It works best when a task is repeated many times, as in unloading cartons, and works poorly when every task is different. The owner sees higher productivity; the employee may feel constantly watched.

> Section 4.1 in four lines.

*Before moving on.* Scientific management studies work by measurement to find one best method. A time and motion study times each movement. Taylor's four principles replace habit with science, train the employee, share the work with the employee, and divide responsibility. Its limit is that it treats employees as parts of a machine.

* * *

## 4.2 Administrative Principles

> Taylor studied the single task; Fayol studied the whole organisation.

Taylor looked at one employee at one bench. But who looks at the whole organisation: the owner's decisions, the way departments connect, the lines of authority? A French mining engineer asked exactly this question, and his answer has lasted more than a hundred years.

### Who Was Fayol?

> Fayol was a mining engineer who ran a large company and wrote down what he learned.

Henri Fayol (1841 to 1925) trained as a mining engineer in France. In 1888 he became managing director of a French mining and iron company that was in difficulty. In 1916 he published *Administration industrielle et générale* in French; the English translation, *General and Industrial Management*, appeared in 1949. Fayol wrote from his own experience as a senior manager, so his view starts at the top, where Taylor's view started at the bench.

> Fayol sorted a company's activities into six groups, and managing is one of them.

Fayol saw six kinds of activity in any industrial organisation: technical (making things), commercial (buying and selling), financial (finding and using money), security (protecting people and property), accounting (recording and counting), and managerial. He said that managing is a separate activity that needs its own study. He described it through five activities: planning, organising, commanding, coordinating and controlling.^2 These five are an early form of the management process.

^2: The management process is set out in Chapter 3 'The Functions of Management and How Management Is Judged', section 3.1 'The Management Process'.

> Fayol believed management can be taught, so he wrote principles, not laws.

@ Law | Word in use. In daily life, a rule made by the state and enforced by courts. In science, a statement that always holds. Fayol's principles are guides that bend with the situation.

Fayol held one belief that mattered greatly: management can be taught. If it can be taught, it needs principles, which are general guides that managers can learn and apply. He listed fourteen and said that the list was not complete. He called them principles and not laws, because a law in science holds every time, while a principle must bend with the situation.

### The Fourteen Principles

> Fayol's fourteen principles are short rules about work, authority, fairness and order.

The table lists Fayol's fourteen principles with a plain meaning for each. Read across a row: the name is on the left, and what it asks of a manager is on the right.

:table Fayol's fourteen principles in plain words
| Principle | What it asks |
| Division of work | Give each employee a smaller part of the whole job, so that skill grows with practice |
| Authority and responsibility | Match the right to give orders with the duty to answer for results |
| Discipline | Make clear agreements, and apply penalties fairly when they are broken |
| Unity of command | Each employee receives orders from one manager only |
| Unity of direction | One plan and one head for each group of activities with the same goal |
| Subordination of individual interest | The goal of the organisation comes before the interest of one person |
| Remuneration | Pay fairly, so that employee and organisation are both satisfied |
| Centralisation | Decide how much decision making stays at the top and how much is shared |
| Scalar chain | A line of authority runs from the top to the lowest level, with a clear path for messages |
| Order | A place for everything and everyone, and everything and everyone in its place |
| Equity | Treat employees with kindness and justice |
| Stability of tenure | Keep employees long enough to learn, and avoid needless turnover |
| Initiative | Let employees think out a plan and carry it through |
| Esprit de corps | Build team spirit and harmony among employees |

> Sorting the fourteen into three groups makes them easier to remember.

Fourteen items are hard to remember in a list, so the diagram sorts them into three groups. Read it from top to bottom: each band is one group, the strip at its left edge has its own hatching, and the lines inside the band are the principles it holds.

:fig Fayol's fourteen principles in three groups | ch04-fig02.svg

> Six principles concern how work and authority are arranged.

The first group, structure and command, has six principles: division of work, authority and responsibility, unity of command, unity of direction, scalar chain and centralisation. These describe how an organisation is arranged and how orders travel. Take unity of command. If an employee receives opposite orders from two managers, the employee must disobey one of them, and confusion follows. The principle prevents this by giving each employee one manager.

> Five principles concern fairness and the treatment of people.

The second group, fairness and people, has five principles: remuneration, equity, stability of tenure, initiative and *esprit de corps*, a French phrase that means team spirit. These ask managers to treat employees as people with needs. A fair wage, a kind manner and a steady job all encourage loyalty, and loyalty helps the organisation as much as it helps the employee.

> Three principles protect order and the common goal.

The third group, order and purpose, holds discipline, order and the subordination of individual interest. These keep the organisation orderly and pointed toward one goal. For example, if one sales assistant prefers a private method of shelving but the shop needs one shared method, the goal of the shop comes first.

> The shop posted a written list of rules.

:case Case file, illustrative. Rule list posted: 14 rules for the shop.

> Written rules apply the principles of discipline and order.

A written rule list is one way for a shop to apply discipline and order, two of Fayol's principles. The shop's 14 rules and Fayol's fourteen principles share a number by chance only.

### The Limits of Fayol's Principles

> Fayol's principles come from one man's experience, and some pull against each other.

Fayol's work is a landmark because it gave managers a shared language. It also has limits. He drew on his own experience in one industry, and he did not test the principles by measurement. Some principles pull against each other. Unity of command gives clear orders, but in an emergency an employee may need to act on the word of whichever manager is present. Division of work raises skill, but it can make work dull. Fayol knew this and advised judgement: the principles are guides, and a manager must decide how far to apply each one.

> Taylor began at the bench, Fayol at the top, and both believed management can be taught.

Compare the two thinkers. Taylor began at the bench and worked upward; Fayol began at the top and worked downward. Both believed that management could be studied and taught, and both believed in principles. Together they give the first complete picture of management as a subject of study: Taylor supplies the method for the task, and Fayol supplies the principles for the whole organisation.

:pause 4.p1 | An employee in a shop is told by two managers to do two different jobs at the same hour. Which of Fayol's principles is being broken, and what should the shop do?

> Section 4.2 in three lines.

*Before moving on.* Fayol, a French mining engineer, wrote in 1916 that managing is a separate activity with principles that can be taught. He gave fourteen principles in three groups: structure and command, fairness and people, and order and purpose. They are guides and not laws, and some of them pull against each other.

* * *

## 4.3 Bureaucratic and Behavioural Thought

> Weber described a way of organising by written rules, levels and skill.

@ Bureaucracy | A system of management built on written rules, clear levels of authority and appointment by skill.

Max Weber (1864 to 1920), a German scholar of society, studied how large organisations could treat people fairly. He described **bureaucracy**. Bureaucracy means a system of management built on written rules, clear levels of authority, and appointment by skill and not by family favour. In daily speech the word often means slow paperwork, but Weber meant a design for fairness and steady work. A shop with a written rule list and clear roles takes a small step in this direction.

> Studies of employees' feelings and group bonds led to a new school.

@ Human relations school | A school of thought holding that workers' feelings and social bonds strongly affect output.

Rules and measurement were not the whole story. Studies at the Hawthorne Works of the Western Electric Company, near Chicago, led thinkers such as Elton Mayo to the **human relations school**. The human relations school is a school of thought holding that employees' feelings and social bonds strongly affect output. For example, an employee who feels respected by the group may work harder than one who feels ignored, even when pay is the same. The studies are told in the section 'In History' at the end of this chapter.

> Behavioural science tests ideas about human behaviour by careful research.

Behavioural science grew from this school. Behavioural scientists are psychologists, sociologists and others who study how people behave, and they test their ideas by careful research and not by opinion. Their findings help managers understand why employees act as they do. Taylor trusted method and pay; Mayo and the behavioural scientists looked at people.

> Section 4.3 in three lines.

*Before moving on.* Bureaucracy rests on written rules, clear levels of authority and appointment by skill. The human relations school holds that feelings and group bonds affect output. Behavioural science studies human behaviour by research.

* * *

## 4.4 Modern Approaches

> Management science uses mathematics and data to solve problems.

@ Management science approach | The use of mathematical models and data to solve management problems.

During the Second World War (1939 to 1945), teams of scientists in Britain and the United States used mathematics to plan the use of ships, aircraft and supplies. After the war, businesses adopted the same methods, and the **management science approach** was born. The management science approach means using mathematical models and data to solve management problems. For example, a shop can use past sales data to decide how many copies of a title to order. It works well when a problem can be measured, but it cannot measure feelings or judgement.

> The systems approach sees an organisation as connected parts.

The systems approach, popular from the 1950s, views an organisation as a set of connected parts that take in resources, change them, and deliver results. In a bookshop, buying, shelving, selling and accounts are parts of one chain: a delay in one part appears later in another. The approach reminds managers to look at the whole and at the links between the parts.

> The contingency approach says the best way depends on the situation.

@ Contingency approach | The view that the best way to manage depends on the situation.

The earlier thinkers each looked for one best way. From the 1960s, researchers found that no single method suited every situation, and the **contingency approach** grew. The contingency approach is the view that the best way to manage depends on the situation. A fixed procedure suits unloading cartons; a flexible, talkative style may suit a team inventing a new service. The approach does not say that anything is allowed. It asks the manager to read the situation first.

> The comparison shows what each approach does best and where it fails.

The table compares the approaches in this chapter. Read a row from left to right: it gives the school, its main idea, what it does well and where it fails. The timeline near the start of the chapter shows the order of these ideas in time.

:table Comparing the main approaches
| Approach | Main idea | Does well | Limit |
| Scientific management | One best method found by measuring | Raises output on repeated tasks | Treats employees as machine parts |
| Administrative principles | General principles for the whole organisation | Gives a shared language | Principles can conflict |
| Bureaucracy | Written rules and levels of authority | Fairness and steady work | Can be slow and rigid |
| Human relations school | Feelings and group bonds affect output | Values people | Can understate pay and method |
| Management science | Mathematics and data | Solves measurable problems | Cannot measure feelings |
| Contingency approach | Best way depends on the situation | Fits real conditions | Gives no single answer |

> Modern managers borrow from several approaches and choose by situation.

No approach has replaced the others. In practice, managers borrow from several, and the contingency approach tells them to choose according to the situation. A busy shop may time its unloading, write a few clear rules, listen to its employees and count its sales, all in one week.

> Section 4.4 in three lines.

*Before moving on.* The management science approach uses mathematics and data. The systems approach looks at connected parts. The contingency approach holds that the best way depends on the situation, so managers borrow from many approaches.

* * *

## Worked Case: Timing the Unloading of Cartons

> This worked case applies scientific management to the shop's unloading.

This worked case applies the chapter to the shop's own record. It shows how to reason from facts, step by step. Many students find the school-naming step confusing, because the same record can fit more than one school. The steps below separate the arithmetic from the naming.

> The situation is the shop's record of the method change.

*Situation.* Meghna and Sons timed the unloading of one carton of books before and after a fixed shelf-position list. The time was 14 minutes before and 9 minutes after. The shop unloads 10 cartons a day. A list of 14 rules for the shop was also posted.

> The question asks for the school of thought and the time saved.

*Question.* Which school of thought does the method change belong to, and how many minutes does the shop save in a day?

> The reasoning first finds the saving, then names the school.

*Reasoning.* First, find the saving for one carton: 14 minutes minus 9 minutes is 5 minutes. Second, find the saving for the day: 5 minutes for each of 10 cartons is 5 x 10 = 50 minutes. Third, name the idea. The shop timed a task, which is a time and motion study, and it fixed one method, which is the one best method of scientific management. Fourth, notice what the record does not show. The list of 14 rules is a different tool, closer to Fayol's discipline and order, and it does not belong to scientific management.

> The conclusion gives the saving and the school.

*Conclusion.* The shop saves 50 minutes a day, which is 5/6 of an hour. The change belongs to scientific management, supported by a rule list that applies Fayol's discipline and order.

> The check repeats the arithmetic from the other side.

*Check.* Before the change, 10 cartons took 10 x 14 = 140 minutes. After the change, they took 10 x 9 = 90 minutes. The difference is 140 minutes minus 90 minutes, which is 50 minutes. The answer agrees with the first calculation.

* * *

## Summary

> The chapter in a few lines.

Management thought grew as factories grew. Taylor's scientific management measured work to find one best method, using time and motion study. Fayol looked at the whole organisation and gave fourteen principles in three groups. Weber described bureaucracy, and Mayo's followers formed the human relations school. Later thinkers added the management science, systems and contingency approaches. No approach replaced the others; managers choose by situation.

## Think It Through

> Four questions that change the situation step by step.

These four questions start with the shop's case and move to new settings. Each builds on the one before.

:q 4.t1 | In the shop's method change, which of Taylor's four principles does the fixed shelf-position list best show, and why?

:q 4.t2 | Suppose the unloading time after the change had been 11 minutes and not 9 minutes. How many minutes a day would the shop save?

:q 4.t3 | A busy kitchen must prepare many orders in a rush, the cooks differ in skill, and orders change every minute. Which school of thought suits it best, and what would you borrow from another school?

:q 4.t4 | A shop times its employees for every task and also wants them to feel part of one team. Where might scientific management and the human relations school pull against each other, and how could a manager reduce the conflict?

## Where People Go Wrong

> Taylor is wrongly remembered as caring only for speed.

Some students think Taylor wanted only faster work at any cost. This is half true. He also proposed careful selection, training and higher pay for employees who reached the standard. The fair criticism is different: his method treated employees as parts of a machine and ignored their feelings.

> Bureaucracy in Weber's sense is not the same as slow paperwork.

Some students think bureaucracy always means delay and waste. In daily speech it often does. In Weber's sense it is a design with written rules, clear levels and appointment by skill, meant to give fairness and steady work. Delay appears when such a design is applied without judgement.

> Fayol's principles are guides, not laws that hold every time.

Some students treat Fayol's fourteen principles as laws. Fayol himself did not. He wrote that they must bend with the situation, and some of them pull against each other, as unity of command can against speed in an emergency.

> A newer approach does not cancel the older ones.

Some students think each new school proved the earlier one wrong. In fact each school added what the earlier ones missed, and each still helps in some settings. The contingency approach says exactly this: choose according to the situation.

## In History

> The Hawthorne studies began with lighting and ended with group bonds.

In 1924 the Western Electric Company, which made telephone equipment, began studies at its Hawthorne Works near Chicago. With the National Research Council, an American scientific body, it tested whether the quality and amount of light changed how much employees produced. These illumination studies ran until 1927, and their results were puzzling.

> Harvard researchers joined and studied small groups and interviews.

Researchers from Harvard University, among them Elton Mayo and Fritz Roethlisberger, then joined the work. They studied a small group of women assembling telephone relays in a test room while conditions changed. An interview programme later asked employees about their feelings about work, and another study observed the habits of a group of men wiring equipment. The studies lasted until about 1932.

> The studies moved attention to attention, groups and feelings, though later writers dispute some claims.

The researchers concluded that attention from managers and the bonds within a group affected output. This conclusion helped to create the human relations school. Later scholars have questioned how far the original data supports the claim now called the Hawthorne effect, and many experts doubt it. The studies remain important because they turned attention toward the social side of work.

## Review Questions

> Five questions that review the chapter.

:q 4.1 | Match each name to its idea: Taylor, Fayol, Weber, Mayo. The ideas are: written rules and levels of authority; one best method found by timing; fourteen principles for the whole organisation; group bonds affect output.

:q 4.2 | State Taylor's four principles in your own words.

:q 4.3 | Define the contingency approach, and give one example from a shop.

:q 4.4 | Name the three groups of Fayol's principles, and give one principle from each group.

:q 4.5 | Give one strength and one limit of the management science approach.

:read Frederick W. Taylor, The Principles of Scientific Management, 1911
:read Henri Fayol, General and Industrial Management (English translation), 1949
:read Max Weber, The Theory of Social and Economic Organization (English translation), 1947
:read F. J. Roethlisberger and William J. Dickson, Management and the Worker, 1939
