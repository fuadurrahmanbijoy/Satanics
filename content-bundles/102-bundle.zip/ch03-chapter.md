:chapter III | The Functions of Management and How Management Is Judged
:mood Four kinds of work, three ways to ask: was it done well?
:desc This chapter names the four kinds of work that make up management and shows how they repeat in a cycle. It then teaches three measures of results: productivity, effectiveness and efficiency. It ends by asking whether management is a science, an art or a profession, and by introducing the principle of management.
:plate ch03-plate.svg | A drawing office where every line on the wall plans was drawn before the first stone was cut

:box YOU WILL NEED
Chapter 1 "What Management Is", section 1.2 "Nature of Management"; Chapter 2 "Managers and Their Skills", section 2.1 "Levels and Kinds of Manager".

> Two cooks, two different failures: which one managed better?
Two cooks are asked to prepare a wedding feast for 200 guests. The first cook finishes on time, and all 200 guests are served. Afterwards the kitchen shows a large loss: rice thrown away, trays burnt, and many hours of paid overtime. The second cook wastes nothing. The costs are low and the pots are clean. But the food runs out after 150 guests, and 50 guests go home hungry. Which cook managed better?

> Each cook failed in a different way, and each way needs its own name.
Most readers answer that neither did well. The first cook reached the goal at a very high cost. The second cook used resources with great care but did not reach the goal. These are two different failures, and a manager who cannot tell them apart will repair the wrong one. To judge management, we need exact words for the different ways in which it can succeed or fail.

> Behind the feast stand four kinds of work, and a question: do they happen once, or repeat?
A second puzzle stands behind the first. Before the feast, somebody decided the menu and the day. Somebody divided the tasks among the helpers. Somebody kept the helpers working willingly through a hot afternoon, and somebody checked the pots while the cooking was in progress. These are four different kinds of work. Do they happen once, in order, like the steps of a recipe? Or do they come round again and again?

> The chapter answers three questions: what managers do, how results are judged, and what kind of knowledge management is.
There is also a third question. Is cooking a feast a science, with fixed rules that give the same result each time? Is it an art, learnt by practice and feel? Or is it a profession, like medicine, with a licence and a code of conduct? This chapter answers all three questions. It names the four kinds of work, gives three measures for judging results, and asks what kind of knowledge management really is.

* * *

## 3.1 The Management Process

@! Go slowly here.
> A family journey contains all four kinds of work, though nobody in it has studied management.
Before we use the technical words, consider a family travelling to a village for a wedding. Someone chooses the day, the route and the bus. Someone assigns the tasks: who buys the tickets, who packs the sweets, who looks after the grandparents. Someone keeps everyone cheerful when the bus is late. And someone counts the family at every stop, to be sure that nobody is left behind. No member of this family has studied management. Yet the family has used all four kinds of work that this section names.

> Recall: nature of management, Chapter 1, section 1.2 "Nature of Management".
> Chapter 1 said what management is; this chapter says what managers do.
In Chapter 1 you learned that management means reaching an organisation's goals through people and resources. That statement is correct, but it is broad. It does not tell us what a manager does between nine in the morning and five in the afternoon. This section divides the broad statement into four kinds of work and shows how they join together.

> The four kinds of work form one repeating cycle called the management process.
@ Process | Word in use. In daily life, a method of making something, such as a printing process. In management, a repeating cycle of kinds of work.
@ Management process | The continuing cycle of planning, organising, leading and controlling that managers repeat.
Together, the four kinds of work form the **management process**. The management process is the continuing cycle of planning, organising, leading and controlling that managers repeat. The word *cycle* matters: when the last kind of work ends, the first begins again. In a printing works, a process is a fixed method for one product. Here, it means this one repeating cycle of managerial work.

> Each of the four kinds of work is called a function of management.
@ Function of management | One of the four main kinds of work managers do: planning, organising, leading or controlling.
Each of the four kinds of work has its own name, and we call each one a **function of management**. A function of management is one of the four main kinds of work managers do: planning, organising, leading or controlling. Here, *function* means a main kind of work. It does not mean a social event, and it does not mean the rule linking two numbers in algebra.

### Planning

> Planning means choosing goals and deciding in advance how to reach them.
Planning means choosing goals and deciding in advance how to reach them. It comes first because it gives direction to every other kind of work. The family chooses the day and the route before anyone packs a bag. A plan can be wrong, but without any plan nobody can say what the other work is for.^1

^1: Planning is taught in full in Chapter 7, "Planning: Meaning, Nature and Steps", section 7.1 "What Planning Is".

> The shop's 2026 sales target is an act of planning.
:case Case file, illustrative. Meghna and Sons sold Tk 14,400,000 in 2025. The sales target for 2026 is Tk 15,840,000, which is 10% above that figure. Fixing this number is an act of planning, because it states the result the shop intends to reach.

### Organising

> Organising means arranging tasks, people and resources so that the plan can be followed.
Organising means arranging tasks, people and resources so that the plan can be followed. It answers one question: who does what, using which resources? A plan without this arrangement stays a wish. The family decides who buys the tickets and who packs the sweets, and that decision is organising.^2

^2: Organising is taught in Chapter 12, "Organizing and Types of Organization", section 12.1 "What Organizing Is".

> The shop's seven jobs are an act of organising.
:case Case file, illustrative. In 2025 Meghna and Sons employed 7 people: Rafiq Meghna as store manager, Tariq Meghna for accounts and online orders, 3 sales assistants, 1 cashier and 1 stock clerk. Dividing the shop's work among these seven people is organising.

### Leading

> Leading means guiding and encouraging employees so that they work willingly toward the goals.
Leading means guiding, encouraging and influencing employees so that they work willingly toward the goals. Plans and arrangements do not carry themselves; people carry them, and people differ in energy, skill and mood. When the bus is late, the family needs someone who keeps the mood steady. From the employee's side, leading is the part of management felt most directly, in the way a manager speaks, explains and responds.^3

^3: Leading is taught in Chapter 17, "Leadership", section 17.1 "Leader and Manager". A closely linked idea, motivation, is taught in Chapter 16, "Motivation", section 16.1 "What Motivation Is".

### Controlling

> Controlling means checking results against plans and correcting any difference.
Controlling means checking results against plans and correcting any difference. The family counts its members at every stop; if one is missing, it returns for that person. At Meghna and Sons, the sales target of Tk 15,840,000 gives a measure. When 2026 ends, actual sales can be compared with it, and any gap shows what needs correction.^4

^4: Controlling is taught in Chapter 18, "Controlling", section 18.1 "What Controlling Is".

### A Cycle, Not a Line

> Recall: levels of management, Chapter 2, section 2.1 "Levels and Kinds of Manager".
> The four functions repeat, overlap and carry different weight at different levels.
The four functions do not run once, in a straight line, and then stop. Controlling produces information, and that information changes the next plan. In daily work the functions also overlap: a manager who holds a short meeting may be organising, leading and checking in the same ten minutes. Their weight differs by level. A top manager usually spends more time on planning, and a first-line manager more time on leading and checking daily work.

> Other books use other lists of functions; the four used here cover the same ground.
Other books use different lists, for example adding a fifth function called staffing. The four used here cover the same ground, because the work of finding and keeping employees falls within organising and leading. The list is a tool for thinking, not a law of nature.

> Owner, manager, employee and customer each see the cycle from a different position.
Each person sees the cycle from a different position. The owner asks whether the cycle ends in the goals. The manager lives inside the cycle. The employee feels mostly its leading and controlling. The customer sees none of it directly and sees only the results: books on the shelf, a fair price and a correct bill.

> The management process is a repeating cycle of four functions.
*Before moving on.* The management process is the repeating cycle of four functions: planning, organising, leading and controlling. Each function is a main kind of work. They overlap and repeat, and their weight changes with the level of the manager. *You should now be able to say* what the four functions are, and why they form a cycle and not a line.

* * *

## 3.2 Productivity

@! Go slowly here.
> Two market stalls show why a bigger total is not always a better result.
Imagine two stalls in a market. The first stall has 2 sellers and sells 40 melons in a morning. The second stall has 3 sellers and sells 54 melons. The second stall sold more, so is it better run? Many students answer yes at once and then feel unsure, because the sellers are not equal in number. The unease is correct. We must compare the results with what was used to obtain them.

> Output is what an organisation produces; input is what it uses to produce it.
We need two plain words. *Output* is what an organisation produces or sells, such as melons, loaves or books. *Input* is what it uses to obtain that output, such as people's time, money, materials and machines. Now the puzzle resolves. The first stall sold 40 melons using 2 sellers: 40 ÷ 2 = 20 melons for each seller. The second sold 54 melons using 3 sellers: 54 ÷ 3 = 18 melons for each seller. The smaller stall obtained more output for each unit of input.

> Productivity is output divided by input.
@ Productivity | The amount of output an organisation obtains for each unit of input it uses.
This ratio has a name. **Productivity** is the amount of output an organisation obtains for each unit of input it uses. At the stalls, productivity is 20 melons per seller for the first and 18 for the second. In words: productivity equals output divided by input. In symbols, P = O ÷ I, where P is productivity, O is output and I is input.

### Measuring Output per Input

> Measuring needs one unit for output, one for input, and one period for both.
To measure productivity, choose one measure of output and one measure of input, and keep both in the same period. A bookshop may measure output in copies sold and input in employees; the result is copies per employee. Other pairs are possible, such as sales in taka per employee. Two rules guard against error. Use the same period for both figures. Use the same units when comparing two years.

> The shop's productivity is forecast to rise from 5,857 to 6,443 copies per employee.
:case Case file, illustrative. In 2025 Meghna and Sons sold 41,000 copies with 7 staff, which is 5,857 copies per employee. The forecast for 2026 is 45,100 copies with 7 staff, which is 6,443 copies per employee (rounded). The full arithmetic appears in the worked example later in this chapter.

### Raising Productivity

> Productivity rises when output grows, input falls, or output grows faster than input.
Productivity can be raised in three ways. Output can grow while input stays the same, as in the shop's forecast, where copies rise and the staff remain 7. Input can fall while output stays the same. Or output can grow faster than input. A manager chooses among these ways, and each has costs. Reducing input may harm service, and growing output may need longer hours, which are themselves more input.

> Productivity shows quantity only, and a bigger total can hide a lower ratio.
Productivity has limits. It counts quantity and says nothing about quality: a shop could sell more copies by selling worn copies. It does not say whether the output is the right output. And a higher total is not the same as higher productivity. If the stall with 54 melons had hired many more sellers, its total would grow while its output for each seller fell. These limits explain why productivity is only one of three measures in this chapter.

:pause 3.p1 | A shop sells 600 books in one week with 3 employees, and 800 books in the next week with 5 employees. Did productivity rise or fall?

> Productivity is output divided by input, and a larger total does not always mean a higher ratio.
*Before moving on.* Productivity is output divided by input, measured in one period with fixed units. It rises when output grows faster than input. It measures quantity and not quality. *You should now be able to say* why a larger total does not always mean higher productivity.

* * *

## 3.3 Effectiveness and Efficiency

> Productivity cannot separate the two cooks; two further words can.
Return to the two cooks. The first reached the goal at a high cost. The second used resources carefully but missed the goal. Productivity alone cannot describe this difference. Two further words can, and they are easily confused, so we take them one at a time.

> Effectiveness asks whether the goal was reached.
@ Effectiveness | How far an organisation reaches its goals, whatever the cost.
**Effectiveness** is how far an organisation reaches its goals, whatever the cost. The first cook was effective: all 200 guests were served. The question of effectiveness ignores cost completely. It asks only how close the result came to the goal.

> Efficiency asks how little input was used to reach a given result.
@ Efficiency | How little input an organisation uses to reach a given result.
**Efficiency** is how little input an organisation uses to reach a given result. For the same result, less input means higher efficiency. The first cook, who wasted rice and paid for overtime, was not efficient. Efficiency is about the cost of reaching a result, and it says nothing about whether the right result was chosen.

> The shop's target tests effectiveness; the shorter search for stock tests efficiency.
:case Case file, illustrative. Effectiveness check: the 2026 sales target is Tk 15,840,000. Efficiency: staff spent 3 hours a day searching for stock; after the shelves were relabelled on 2 March 2026 the search took 1 hour a day.

> A table sets the four possible combinations side by side.
The next table sets the two words together. Read each row from left to right: the first column names a situation, the second says whether the goal was reached, and the third describes the input used.

:table Four situations compared
| Situation | Goal reached? | Input used |
| Effective and efficient | Yes | Little |
| Effective, not efficient | Yes | Much, with waste |
| Efficient, not effective | No | Little |
| Neither | No | Much, with waste |

> Two short questions separate the words: was the goal reached, and what did it cost?
A short test separates the words. For effectiveness, ask: was the goal reached? For efficiency, ask: how much input did reaching it cost? A manager can be effective without being efficient, as the first cook was. A manager can also be efficient without being effective, as an organisation is when it does the wrong job very cheaply. Good management aims at both.

:box IN SHORT
Effectiveness asks whether the goal was reached. Efficiency asks how much input was used to reach it. Productivity measures output for each unit of input.

:pause 3.p2 | A charity delivers all 500 food parcels it planned to deliver, but spends twice its budget. Is it effective, efficient or both?

> Effectiveness is goals reached; efficiency is least input for a result.
*Before moving on.* Effectiveness is how far goals are reached, whatever the cost. Efficiency is how little input a result needs. The two can differ, and a manager needs to judge each.

:fig Functions as a cycle, with the three measures beside it | ch03-fig01.svg

> The figure shows the cycle on the left and the three measures on the right.
To read the figure, begin with the left side. The four boxes are the functions, and each arrow leads to the next, so that the last arrow returns to the first. The right side lists the three measures with which the results of that cycle are judged.

* * *

## 3.4 Science, Art or Profession

> Management can be called a science, an art or a profession, and each claim demands something different.
Is management a science, an art or a profession? The question matters because each answer asks something different of managers. We take the three claims in turn. The second figure compares them.

> A science rests on tested knowledge, and management has only some of it.
@ Science | Word in use. In daily life, a school subject such as physics. Here, knowledge built by observation and repeated testing, whose rules give the same result each time.
A science is knowledge built by observation and repeated testing, whose rules give the same result each time. Management has scientific parts. A measured rule can be tested and repeated. But management cannot be a full science, because people differ, conditions change, and controlled experiments are seldom possible.

> The shop's reorder rule is the scientific part of its management.
:case Case file, illustrative. Stock reordering at Meghna and Sons follows a measured rule: reorder when 30 days of cover remain. Any employee can apply this rule and reach the same result.

> An art is personal skill in using knowledge, and management needs it everywhere.
@ Art | Word in use. In daily life, painting, music or other creative work. Here, personal skill in using knowledge, gained by practice and shown in judgement.
An art is personal skill in using knowledge, gained by practice and shown in judgement. No rule gives the answer in every case, and the manager must judge. Management needs this skill in every function.

> The shop-window design is the artistic part of its management.
:case Case file, illustrative. The shop-window design for the textbook season depends on Rafiq's judgement.

> A profession has three tests, and management meets them only in part.
@ Profession | An occupation that requires long training, a body of knowledge and a code of conduct enforced by an association.
A **profession** is an occupation that requires long training, a body of knowledge and a code of conduct enforced by an association. Medicine is a clear example: in most countries a doctor must register with a medical council before treating patients. Management has a body of knowledge, but it fails the other tests in most countries. In the United Kingdom, the Chartered Management Institute awards a chartered title to managers who choose to seek it, but employers do not require it.

> No licence or governing body is required to manage the shop.
:case Case file, illustrative. No licence or governing body is required to manage Meghna and Sons.

:fig Three claims about management compared by what each demands | ch03-fig02.svg

> Management is partly a science, largely an art, and only partly a profession.
*Before moving on.* Management uses tested knowledge as a science does, and personal judgement as an art does. It is only partly a profession, because it usually needs no licence and no governing association.

* * *

## 3.5 Importance and Principles in Brief

> Management matters because it directs effort, saves resources and prepares an organisation for change.
Management is important for three plain reasons. It directs the effort of many people toward common goals. It helps an organisation use limited resources with less waste. And it prepares an organisation to meet change, such as new laws, rivals and technologies. Without it, the same people and materials produce less, and the cost falls on owners, employees and customers.

> A principle of management is a broad guide drawn from experience, to be adapted and not obeyed like a law.
@ Principle of management | A broad guide to action drawn from experience, to be adapted and not applied like a law.
Over many years, managers have collected broad guides drawn from experience. Each is a **principle of management**. A principle of management is a broad guide to action drawn from experience, to be adapted and not applied like a law. Water boils at 100 °C at sea level every time. A principle such as "divide work among specialists" may suit a factory and fit badly in a shop with seven people.^5

^5: A well-known list of such principles is taught in Chapter 4, "The Evolution of Management Thought", section 4.2 "Administrative Principles".

> Management is important, and its principles are guides to adapt.
*Before moving on.* Management directs effort, saves resources and prepares for change. A principle of management guides action and must be adapted to the situation.

* * *

## Worked Example and Worked Case

### Worked Example: Productivity

> The first example is small and clean, so that only the method is new.
Many students find rounding confusing here, because a result such as 5,857.14 cannot be a number of copies in daily life. We round at the end and never in the middle. The table below sets out the working in six parts. Read it from the top: the first column names the part, and the second column gives its content.

:table Worked example 1: copies per employee
| Part | Working |
| Given | 2025: 41,000 copies sold by 7 employees. 2026 forecast: 45,100 copies by 7 employees. |
| Find | Copies per employee in each year, and the change. |
| Formula | In words: productivity = output ÷ input. In symbols: P = O ÷ I, where P is productivity, O is output in copies and I is input in employees. |
| Steps | 2025: P = 41,000 ÷ 7 = 5,857.14, so 5,857 copies per employee. 2026: P = 45,100 ÷ 7 = 6,442.86, so 6,443 copies per employee. Change: 6,443 − 5,857 = 586 copies per employee. Percentage change: 586 ÷ 5,857 = 0.1000, which is 10.0%. |
| Answer | Productivity is forecast to rise from 5,857 to 6,443 copies per employee, a rise of 10%. |
| Check | Output rises by 4,100 copies, which is 10% of 41,000. Input stays at 7, so productivity must rise by the same 10%. |

> The second example is messier, because output is measured in taka.
In the second example, output is measured in taka, and the figures do not divide evenly.

:table Worked example 2: sales per employee
| Part | Working |
| Given | Sales 2025: Tk 14,400,000. Sales target 2026: Tk 15,840,000. Employees: 7 in each year. |
| Find | Sales per employee in each year. |
| Formula | Productivity = sales ÷ employees. |
| Steps | 2025: 14,400,000 ÷ 7 = 2,057,142.86, so Tk 2,057,143. 2026: 15,840,000 ÷ 7 = 2,262,857.14, so Tk 2,262,857. |
| Answer | Sales per employee are planned to rise from Tk 2,057,143 to Tk 2,262,857. |
| Check | 2,057,143 × 1.10 = 2,262,857, which is the 10% rise in the target. |

> Four common slips: an upside-down ratio, mixed periods, missing units and early rounding.
Four slips are common. The first is dividing input by output, which turns the ratio upside down. The second is mixing periods, such as monthly output with yearly input. The third is forgetting units: write copies per employee, not copies. The fourth is rounding in the middle of the working. Money also hides a trap. If prices rise 5%, sales per employee rise even when no more copies are sold.

### Worked Case: Effective, Efficient or Both?

> The case table applies the two words to the shop's own facts.
This case applies an idea to a situation. The table gives the five parts in order.

:table Worked case: two facts, two measures
| Part | Working |
| Situation | Meghna and Sons set a 2026 sales target of Tk 15,840,000. Before 2 March 2026, staff spent 3 hours a day searching for stock. After the shelves were relabelled on 2 March 2026, they spent 1 hour. |
| Question | Which fact tests effectiveness, and which tests efficiency? |
| Reasoning | The target is a goal, so comparing actual sales with Tk 15,840,000 tests effectiveness. Search time is input. The result, finding the stock, is unchanged, so less input for the same result shows efficiency. The saving is 3 − 1 = 2 hours a day, which is about 67% of the former search time. |
| Conclusion | The relabelling raised efficiency. Effectiveness cannot be judged until the sales for 2026 are known. |
| Check | If sales miss the target while search time stays at 1 hour, the shop is efficient but not effective. The two judgements are separate. |

### Changing the Situation

> Rung 1 is the familiar case: the shop as it stands.
Rung 1, a familiar case. The shop as described: a clear target, a shorter search for stock, and 7 employees.

> Rung 2 reshapes the case: the target is met, but with more employees.
Rung 2, the same case reshaped. Suppose the shop sells 45,100 copies, but only after hiring 2 more employees. The goal is reached, so the shop is effective. Productivity is 45,100 ÷ 9 = 5,011 copies per employee, which is below the 5,857 of 2025.

> Rung 3 moves to a clinic, where the same two ideas apply to patients and nurses.
Rung 3, a new setting. A clinic sees 60 patients a day with 4 nurses, and later 72 patients with 6 nurses. Productivity moves from 15 to 12 patients per nurse, although the total rises. A manager must also ask about quality of care, which this ratio does not show.

> Rung 4 joins the cycle and the three measures in one chain of events.
Rung 4, a case that combines earlier ideas. Nurul sets the target (planning). Shelves are relabelled (organising and leading). Search times are compared month by month (controlling). The target tests effectiveness, the relabelling raises efficiency, and the monthly comparison closes the cycle, so that the next plan can use the result.

* * *

## Summary

> The chapter in brief.
Management work falls into four functions: planning, organising, leading and controlling. They form a repeating cycle called the management process. Results are judged by three measures: productivity (output for each unit of input), effectiveness (how far goals are reached) and efficiency (how little input a result needs). Management uses a science and an art, but it is only partly a profession. A principle of management is a guide to adapt, not a law.

## Think It Through

:q 3.t1 | A delivery firm promises to deliver 300 parcels in a day. It delivers all 300, but 4 vans each drive twice the distance needed, because the routes were not planned. Explain why the firm was effective but not efficient, and name the function whose improvement would help most.
:q 3.t2 | Meghna and Sons is forecast to reach 6,443 copies per employee in 2026. Suppose the shop hires 1 more employee and sells 45,100 copies. Find the new productivity and say whether it is higher or lower than in 2025.

## Where People Go Wrong

> Mistake: the functions happen once, in a fixed order.
Mistake: "The four functions are steps in a recipe, done once in order." Correction: they repeat and overlap, and controlling gives the information for the next round of planning.

> Mistake: more output always means higher productivity.
Mistake: "More output always means higher productivity." Correction: productivity is output for each unit of input. If input grows faster than output, productivity falls.

> Mistake: effectiveness and efficiency are two names for one idea.
Mistake: "Effective and efficient mean the same." Correction: effectiveness asks whether the goal was reached; efficiency asks how little input was used.

> Mistake: management is a profession like medicine.
Mistake: "Management is a profession, like medicine." Correction: in most countries a manager needs no licence and answers to no single governing association.

> Mistake: a principle of management is a law.
Mistake: "A principle must be followed in every case." Correction: a principle is drawn from experience and must be adapted to the situation.

## In History

> The Toyota Production System grew over thirty years from one engineer's attack on waste.
Taiichi Ohno (1912 to 1990) joined the Toyoda spinning and weaving business in 1932 and was transferred to the Toyota Motor Company in 1943. Japan's car makers then trailed the American producers. Toyota's founder, Kiichiro Toyoda, had already developed in the 1930s the idea of making only what is needed, with no excess stock. Ohno became manager of a machine shop in 1949 and built this idea into a complete system of production over the following decades, aimed at removing waste.

> Ohno's system was a landmark in efficiency: the same result from less input.
The system is called the Toyota Production System. It was developed between the 1940s and the 1970s, and its aim was the same result with less input, which is the meaning of efficiency in this chapter. Ohno became an executive vice president of Toyota in 1975 and retired in 1978. His book on the system first appeared in Japan in 1978, and an English edition followed in 1988. Observers noted that Toyota did well in the oil crisis of the 1970s, when many rivals suffered.

## Review Questions

:q 3.1 | Name the four functions of management in order, and give one example of each from a bookshop.
:q 3.2 | A bakery made 1,800 loaves in a week with 4 bakers. After buying a new oven it made 2,100 loaves with the same 4 bakers. Find the productivity before and after, in loaves per baker, and the percentage change.
:q 3.3 | Explain why a rise in total output does not always mean a rise in productivity. Give a small numerical example.
:q 3.4 | Define effectiveness and efficiency, and describe one situation that is efficient but not effective.
:q 3.5 | State the three parts of the definition of a profession, and say which part is missing when a person manages a small shop.
:q 3.6 | In two sentences, explain why a principle of management is not like a law of physics.

:read Taiichi Ohno, Toyota Production System: Beyond Large-Scale Production, 1988
:read Peter F. Drucker, The Effective Executive, 1967
