:answers 01
:a 1.p1 | Planning: deciding in advance what to cook and buy. Organising: sharing the tasks among family members. Leading: guiding and encouraging the members. Controlling: checking at the month's end whether the money lasted, and correcting any difference.
:a 1.p2 | Yes. The owner employs two drivers, tells each one what to do and answers for the results of their work, which matches the definition of a manager.
:a 1.t1 | Nurul Meghna, the owner-manager of a shop with seven staff. The resources are stock Tk 3,500,000, fittings Tk 600,000 and the seven staff.
:a 1.t2 | Rafiq answers for the assistants' work that week, because a manager answers for the work of the people he directs. Nurul remains the owner.
:a 1.t3 | The stall still has resources and goals. Its owner must decide what to buy, arrange the stall and check the takings, which is management on a very small scale. Only the leading of other people is missing.
:a 1.t4 | The organisation is the club. Two resources are the members and the fund (or the ground). The manager is the person who is responsible for the members' work and its results, such as the person chosen to direct the club.
:a 1.1 | Doctors and nurses (people), money from fees or public funds (money), medicines and equipment (materials), patient records (information).
:a 1.2 | Responsibility is a duty to perform a task and to answer for how well it is done. Authority is the right to give orders and make decisions.
:a 1.3 | Resources are limited, people differ, conditions change and tasks depend on one another, so someone must direct resources toward the organisation's goals.

:answers 02
:a 2.p1 | Nurul works at the top level. Rafiq's weekly stock plan is middle-level work, and his direct supervision of five employees is first-line work.
:a 2.p2 | Human skill. The manager is working with and understanding a person, and giving the employee a reason to speak and to keep learning.
:a 2.t1 | Nurul works at the top level. Rafiq stands at the middle level (weekly stock plan, supervising 5 staff) and at the first-line level (directly supervising 3 sales assistants, 1 cashier and 1 stock clerk).
:a 2.t2 | The new manager stands at the middle level, below Nurul, and is a general manager because the manager answers for a whole shop. If the manager directly supervises employees, the work also stands at the first-line level.
:a 2.t3 | The chairman is the top manager and needs conceptual skill most. The depot manager is a middle manager with a medium mix and large human skill. The driver supervisor is a first-line manager and needs technical skill most.
:a 2.t4 | Human skill. The assistant has strong technical skill, but a manager gets results through the work of other people, so the new supervisor must learn to work with, understand and motivate them.
:a 2.1 | The head of the whole network is a top manager. The loans department manager is a middle manager. The supervisor of the cashiers is a first-line manager.
:a 2.2 | A top manager's decisions affect the whole organisation and the top manager seldom does the daily work, so seeing how the parts connect becomes the main ability. A first-line manager sees the work directly.
:a 2.3 | People (the sales assistants), money (the day's takings), materials (stock and shelves), information (sales records or the list of school customers).
:a 2.4 | A functional manager is in charge of one kind of work, such as the accounts department. A general manager is in charge of several kinds of work together, such as the head of a whole branch.

:answers 03
:a 3.p1 | Week 1: 600 ÷ 3 = 200 books per employee. Week 2: 800 ÷ 5 = 160. Productivity fell, although the total rose.
:a 3.p2 | It is effective, because every planned parcel was delivered. It is not efficient, because it used twice the budget.
:a 3.t1 | The firm reached its goal of 300 parcels, so it was effective. The vans used twice the distance needed, so input was wasted and it was not efficient. Better planning of routes would help most.
:a 3.t2 | 45,100 ÷ 8 = 5,637.5, so about 5,638 copies per employee. This is lower than the 5,857 of 2025, because input grew while output stayed at the forecast level.
:a 3.1 | Planning, organising, leading, controlling. Examples: set the sales target; assign jobs to the 7 employees; encourage the sales assistants; compare actual sales with the target.
:a 3.2 | Before: 1,800 ÷ 4 = 450 loaves per baker. After: 2,100 ÷ 4 = 525. Change: 75 ÷ 450 = 0.1667, a rise of about 16.7%.
:a 3.3 | Productivity is a ratio. If input grows faster than output, the ratio falls. Example: 600 books with 3 employees is 200 each; 800 books with 5 employees is 160 each.
:a 3.4 | Effectiveness is how far goals are reached, whatever the cost. Efficiency is how little input a result needs. A firm that does a wrong job very cheaply is efficient but not effective.
:a 3.5 | Long training, a body of knowledge, and a code of conduct enforced by an association. For a small shop, no licence or governing body is required, so the enforced code and association are missing.
:a 3.6 | A law of physics holds every time. A principle is drawn from experience and must be adapted, because it may suit one organisation and fit another badly.

:answers 04
:a 4.p1 | Unity of command is broken, because the employee has two managers giving different orders. The shop should give each employee one manager, and let the two managers agree on the work before they speak to the employee.
:a 4.t1 | The first principle: replace rule-of-thumb methods with a science. The fixed shelf-position list replaced habit with one tested method, and the timing showed that it saved 5 minutes a carton.
:a 4.t2 | The saving per carton would be 14 - 11 = 3 minutes. For 10 cartons it is 3 x 10 = 30 minutes a day.
:a 4.t3 | A mixed answer fits best. The contingency approach suits a kitchen whose orders change each minute. It can borrow time and motion study for repeated tasks and the human relations school for team spirit in the rush.
:a 4.t4 | Timing every task can feel like constant watching, which weakens team spirit. A manager can explain the reason for the timing, share the saving with employees, and ask them to suggest better methods.
:a 4.1 | Taylor: one best method found by timing. Fayol: fourteen principles for the whole organisation. Weber: written rules and levels of authority. Mayo: group bonds affect output.
:a 4.2 | Replace rule of thumb with a science for each job; select, train and develop each employee; cooperate with employees so work follows the science; divide work and responsibility between managers and employees.
:a 4.3 | The contingency approach is the view that the best way to manage depends on the situation. Example: a fixed method suits unloading cartons, while a flexible style suits a team inventing a new service.
:a 4.4 | Structure and command (for example, unity of command); fairness and people (for example, equity); order and purpose (for example, discipline).
:a 4.5 | Strength: it solves problems that can be measured, such as how many copies to order. Limit: it cannot measure feelings or judgement.

:answers 05
:a 5.p1 | External. The owner of Meghna and Sons cannot direct a rival, so the change lies outside the boundary.
:a 5.t1 | External, because the shop cannot direct the school. It fits the task environment, since the school is a customer, and it also reaches the shop through the political and legal group if an education authority required the change.
:a 5.t2 | The stock clerk is an employee of the shop, so a proposal from the clerk is an internal matter that managers can accept or refuse directly. The school's later choice would still be external. The boundary follows control.
:a 5.t3 | Political and legal group, and outside the boundary because the shop cannot command a government. Adapting: change the price list or the range of books kept. Influencing: join a trade association and present the shop's case to the public body, honestly and lawfully.
:a 5.t4 | The departure of 2 of 5 nurses is internal. The new clinic is external, in the task environment as a rival. The new rule is external, in the political and legal group. Watching them is scanning, which supports planning, the first function of the management process, because plans must fit the conditions in which they will be used.
:a 5.1 | A rival's price cut: external. A new store manager: internal. A change in school book rules: external. The shop's own opening hours: internal.
:a 5.2 | The internal environment is what managers can change directly, such as people, structure and culture. The external environment is every outside force that affects the organisation. The boundary follows control: a condition managers can direct is inside, and one they cannot direct is outside.
:a 5.3 | Economic (a fall in family spending); social and cultural (a shift to reading on screens); political and legal (a new tax on imported books); technological (online selling); global (the price of foreign money). Other correct examples are possible.
:a 5.4 | Scanning is regularly collecting and studying information about outside change. Adapting is changing the organisation to fit an outside force. Influencing is acting on the outside force itself. The price-match list is adapting, because the shop changed its own prices.

:answers 06
:a 6.p1 | (a) is an ethical dilemma, because both options cost someone: dismissing one employee harms that person, and cutting both pays harms both. (b) is only a temptation, because the right answer is known and only the will is tested.
:a 6.t1 | The people affected are the employees, the owner, the customer who ordered, and the families of the employees. Step 2 says power creates a duty of equal size, and the owner has power over the employees' safety. Step 4 says the cost of danger must be counted, not left with the employees. The owner should refuse the unsafe night shift and ask the customer for more time.
:a 6.t2 | Profit: Tk 750,000 in 2025. People: 7 employees, which is a first fact only. Natural environment: 380 kg of unsold paper sent to recycling in 2025. Two missing facts are, for example, measures of pay and of safety for the employees, and a measure of energy or waste use.
:a 6.1 | Corporate social responsibility is an organisation's duty to act for the good of society as well as for profit. Example: a bookshop refuses to sell stolen books and sends waste paper to recycling.
:a 6.2 | For: society gives organisations permission to operate, so harm to society returns as lost trust. Against: the money belongs to the owners, who did not choose to spend it on society. Owners would more likely make the argument against; a manager or an employee would more likely make the argument for.
:a 6.3 | The steps are: 1 social power; 2 responsibility matches power; 3 open dealing with society; 4 social costs counted and priced; 5 help with social problems. The iron law warns that those who do not use power in a way society considers responsible will tend to lose it.
:a 6.4 | In a dilemma every option has a cost to someone, such as dismissing one of two employees or cutting both pays. In a temptation one option is plainly wrong and only the will is tested, such as selling stolen books for profit.
:a 6.5 | (a) Both: the law requires it and it is right. (b) Neither: it is forbidden and wrong. (c) Ethical but not required by law: it is a kind act that no law demands.
:a 6.6 | The rival puts employees and customers at risk, and society bears the cost if harm occurs, so Davis step 4 is ignored. The rival also risks its good name and a stricter law. A manager at our shop should keep our safety standard, not copy the rival, and be ready to explain why to customers.

:answers 07
:a 7.p1 | Answers will differ. A good answer names the action (what was done), the person (who did it) and the time (when), for example "wash the clothes, my sister, before noon on Sunday".
:a 7.p2 | At 10% the average price becomes 2,400 + 240 = Tk 2,640, and the order costs 1,800 × 2,640 = Tk 4,752,000. That is Tk 432,000 more than Tk 4,320,000, and Tk 216,000 more than the plan built on 5%.
:a 7.t1 | The order must be placed by 12 December 2025, because 2 January minus 21 days is 12 December (December has 31 days, so 2 + 31 − 21 = 12). An order placed later arrives after the season starts.
:a 7.t2 | The order costs Tk 216,000 more (5% of Tk 4,320,000). The manager should have forecast the price change, stated it as a premise, and weighed alternatives such as ordering earlier or ordering part of the stock.
:a 7.t3 | Awareness: what chance or problem do we see? Objectives: what exact result, by what date? Premises: what do we assume about customers and costs? Alternatives: what other ways could we reach the aim? Choosing and carrying out: who does what, with what money and by when?
:a 7.t4 | Two alternatives: hold the sports day indoors, or fix a spare dry date. The indoor option removes the weather risk but limits the activities; the spare date keeps the activities but needs a second booking and a second notice to families.
:a 7.1 | Awareness of opportunity (notice a chance or problem); setting objectives (state the exact result and date); planning premises (write down what is assumed); listing and weighing alternatives (compare the possible ways); choosing and carrying out (select one and put it into action).
:a 7.2 | A plan is a statement of what will be done, by whom and by when, to reach an objective; example: "Rafiq places the book order by 12 December". A planning premise is an assumption about future conditions on which a plan is built; example: publishers raise prices by 5%.
:a 7.3 | A forecast is a reasoned estimate of what will happen, such as next season's sales from past records. A planning premise is the assumption written into the plan; a forecast is a good source for a premise.
:a 7.4 | The supplier needs 21 days to deliver, so books ordered after the deadline arrive after the season starts. Waiting for empty shelves means customers go elsewhere.
:a 7.5 | Wrong premises: write them down and check them. Vague or unshared objectives: state the result exactly and tell every employee. Lack of commitment: name a person for each task and review progress. Other reasons are cost, rigidity and an unknown future.

:answers 08
:a 8.p1 | A one-day sale to clear old stock is a single-use plan, because it is made for one occasion. If the shop held the same sale every year with the same steps, it would become a standing plan.
:a 8.p2 | Communication is weak, because the employees who carry out the plan do not know it. The owner should explain the plan to everyone affected, in writing, and answer their questions.
:a 8.t1 | The limit "within 7 days" decides the case, because day 8 is outside it. That part is a policy, so the manager has room for judgement, for example to help if the book was damaged. The manager should record the exception.
:a 8.t2 | The expected sales would exceed the spending by 600,000 − 240,000 = Tk 360,000. The event still seems worth planning, but the margin is smaller, and the cost of the books must be counted before the manager decides.
:a 8.t3 | Standing plan: a procedure for serving lunch each day, or a policy on prices. Single-use plan: the plan for the annual sports day, with its own date and budget.
:a 8.t4 | Change a standing plan when conditions change or it fails to fit the facts. Two signs of an old policy: employees often ask for exceptions, and customers or employees complain about the same point.
:a 8.1 | Standing: returns policy and yearly budget (renewed in form each year). Single-use: book fair stall and the opening of a new branch.
:a 8.2 | A policy is a general guide that sets limits for choices (exchange within a set number of days). A procedure is a fixed series of steps for a repeated task (check receipt, check book, record exchange). A budget states expected income and spending in money for a period (the book fair budget of Tk 240,000).
:a 8.3 | A long-range plan looks several years ahead and a short-range plan a year or less. A strategic plan sets the main direction of the organisation; an operational plan states how one part does its daily work.
:a 8.4 | If senior managers ignore a plan, employees ignore it too. Support gives the plan money, time and example, so people follow it.
:a 8.5 | Review plans on a fixed date and check the premises; plan in proportion, with more detail where an error costs much; keep a margin of money or time.

:answers 09
:a 9.p1 | For example, sales and customer service. In sales, a shop that does not sell cannot survive; in customer service, poor service loses customers.
:a 9.p2 | A cycle suits MBO because results from one period teach what objectives to agree for the next. A straight line would end after one year and waste what was learned.
:a 9.t1 | Sample: (1) key result area: results; measure: share of pupils passing the year-end tests; target 85%; period: the next school year. (2) key result area: staff development; measure: hours of training per teacher; target 14 hours; period: the next school year.
:a 9.t2 | Two ways: objectives imposed by the head teacher, so teachers feel no ownership (fix: agree each objective in a meeting); results judged that a teacher cannot control (fix: agree objectives only for results the teacher can influence, and review them during the year).
:a 9.1 | An objective is a specific result that an organisation or person intends to reach within a stated time. An activity is something done, such as holding a sale; an objective is what is reached, such as selling 2,000 copies.
:a 9.2 | Sample: "Sales to schools of Tk 4,000,000 in 2026"; "Stock turnover of at least 3.2 times in 2026"; "12 hours of customer-service training per employee in 2026". Each names a measure, a target and a period.
:a 9.3 | Average stock = cost of sales ÷ turnover = 9,800,000 ÷ 3.2 = Tk 3,062,500. Check: 3,062,500 × 3.2 = 9,800,000.
:a 9.4 | (1) Organisation states objectives; (2) manager and employee agree individual objectives; (3) employee acts with self-control; (4) progress is reviewed; (5) performance appraisal; (6) results guide the next period. Performance appraisal is stage five.
:a 9.5 | Benefits, any two of: clarity, commitment, coordination, fair appraisal, development of people. Weaknesses, any two of: paperwork, bias towards what is easy to count, short-term focus, rigid objectives, pressure when used badly.

:answers 10
:a 10.p1 | She returns to step 3, develop the alternatives, or to step 2 and the criteria. She could add an alternative such as leaving 20 minutes earlier, or a rickshaw, and test it against the same two criteria.
:a 10.p2 | The price is certain, because the list is fixed for a year and the result is known. The number of customers is uncertainty, because nobody can say the result or estimate its chance. If past records of similar books existed, it would be risk.
:a 10.t1 | Supplier A's price is certainty. Supplier B's delivery times are uncertainty, since no records exist to estimate a chance. Step 1 and step 2 come first, but the manager learns what to find out at step 4, evaluating, where the missing delivery facts stop the test.
:a 10.t2 | The criteria stay the same, but the figures in them change: the expected sales fall, so criterion A (sales per taka spent) and criterion B (sales less rent) fall for Mirpur. Rent and fitting costs do not change. The owner should re-evaluate the options with the corrected figure and compare again.
:a 10.1 | Decision making is choosing one course of action from several, in order to solve a problem or use an opportunity. Example: a shop owner chooses one of two sites for a second shop.
:a 10.2 | A problem is a gap between what is and what should be, and an opportunity is a chance to do better than before. An opportunity is easier to miss, because nobody complains about a chance that was lost.
:a 10.3 | The steps are: name the problem or opportunity; set the criteria; develop the alternatives; evaluate them; choose; implement and follow up. Criteria come first so that they cannot be bent to favour the option already liked.
:a 10.4 | A decision criterion is a standard used to judge which alternative is best. Two examples are the price per copy and the days a supplier takes to deliver.
:a 10.5 | (a) Certainty: the lease fixes the amount. (b) Risk: past records allow the chance to be estimated at 4 in 10. (c) Uncertainty: no records exist, so neither the results nor their chances can be estimated.
:a 10.6 | It is risk, because the chance can be estimated from records. The estimated chance of a late order is 3 out of 12, which is 1/4.
:a 10.7 | She must go back to step 2 and rank the criteria, because no alternative now passes both tests. She must decide whether cost or arrival time counts more.

:answers 11
:a 11.p1 | 0.8 × 500 = 400 and 0.2 × (−1,000) = −200, so the expected value is 400 − 200 = Tk 200.
:a 11.t1 | Worth it: an important, unclear decision that affects many people, or one that needs the support of employees to be carried out. Not worth it: an urgent or simple choice, or one where a single person holds both the knowledge and the authority.
:a 11.t2 | 0.4 × 900,000 = 360,000 and 0.6 × (−300,000) = −180,000, so the expected value is Tk 180,000. This is still above Tk 0, so opening still beats waiting on expected value.
:a 11.t3 | 900,000p − 300,000(1 − p) = 0 gives 1,200,000p = 300,000, so p = 0.25. Check: 0.25 × 900,000 = 225,000 and 0.75 × 300,000 = 225,000, which cancel.
:a 11.1 | The event happens one time in four. The probability that it does not happen is 1 − 0.25 = 0.75.
:a 11.2 | 0.7 × 50,000 = 35,000 and 0.3 × (−80,000) = −24,000, so the expected value is Tk 11,000.
:a 11.3 | 0.2 × 100,000 = 20,000; 0.5 × 40,000 = 20,000; 0.3 × (−60,000) = −18,000. The sum is Tk 22,000, and the probabilities add up to 1.
:a 11.4 | X: 0.6 × 200,000 = 120,000 and 0.4 × (−100,000) = −40,000, so Tk 80,000. Y is Tk 70,000. X is higher by Tk 10,000, but it can lose Tk 100,000, so a manager would also ask whether the firm can bear that loss.
:a 11.5 | A square shows a decision point and a circle shows a chance event. We draw the tree from left to right and calculate from right to left, which is called folding back.
:a 11.6 | It stores and analyses data quickly, and it answers what-if questions. One limit: wrong data give wrong answers, and the system supports the manager but does not decide.
:a 11.7 | Advantages: more information and ideas, and stronger support from those affected. Disadvantages: it is slower and uses the time of several employees; it can also let one member dominate or blur responsibility.
:a 11.8 | Any three of: time, cost, importance, the manager's values and attitude to risk, and authority.
:a 11.9 | A tree works when the possible results and their probabilities are known, which describes risk. Under certainty each choice has one known result, so the manager compares the results directly and needs no probabilities.

:answers 12
:a 12.p1 | Step four, set the relationships, because it decides who answers to whom.
:a 12.p2 | Formal. The job description and the reporting line were set up by management and are written down.
:a 12.t1 | One grouping: stock tasks (ordering books) and counter tasks (serving customers, counting cash). The reason is that the counter tasks happen at the same place and use the same dealing with customers and money.
:a 12.t2 | It could join the group with ordering books if the delivery depends on stock, or it could join a group of tasks for customers away from the counter. Either answer is reasonable, which shows that grouping needs judgement guided by the purpose of organizing.
:a 12.t3 | Informal, because no manager set it up. The manager should be pleased that staff share useful information, and concerned only if private patient details are passed on carelessly or if rumour spreads.
:a 12.t4 | The chart may be out of date, with tasks that nobody owns and reporting lines that are too long. The informal organization may also grow in new groups that spread rumour, because the formal structure no longer links the larger staff.
:a 12.1 | Formal: the cashier's job description and the reporting line from stock clerk to store manager. Informal: the lunch group and the habit of sharing book tips at noon.
:a 12.2 | Identify the tasks (what work must be done?); group the tasks (which tasks belong together?); assign the duties (who will do each group of tasks?); set the relationships (who answers to whom, and who works with whom?).
:a 12.3 | The formal organization is the official structure of jobs, rules and lines of authority that management sets up. The informal organization is the network of friendships that forms on its own. The formal one gives order and stability; the informal one gives speed and goodwill.
:a 12.4 | People join to meet needs such as company, help, information and belonging. A manager can learn which groups exist, listen to them, share honest information and use their strengths, while watching for harm.

:answers 13
:a 13.p1 | The tasks are similar (both routine, in one room) and the employees are near the manager. Either of these, or the small number of other duties, suggests a wider span.
:a 13.p2 | Territory, because each branch is a place with its own manager.
:a 13.t1 | Too wide: one owner cannot follow 12 people and answer all their questions. Acceptable: all 12 do the same counter work in one place, so the tasks are similar and near, and the rules may be clear.
:a 13.t2 | Taller, because a new level has been added. The owner's span falls from 12 to 2 and each manager has 6. A benefit is closer supervision; a cost is the added wages and slower messages through the extra level.
:a 13.t3 | Territory. Grouping by product would give each product its own department, and each department would work in all three cities, so the managers would be responsible for a product everywhere and not for a place.
:a 13.t4 | One reasonable answer: a span of about 3 to 5 for the senior doctor, since the clinic is small and all work in one place (size and nearness), and a grouping by function (doctors, nurses, reception) because the clinic is small and its work is routine. Other reasoned answers are acceptable.
:a 13.1 | His span is 4, because only the 4 report to him directly. The people below him number 4 + (4 × 3) = 16.
:a 13.2 | The accounts work takes his time, so he has less time to lead. A smaller span lets him give each employee enough attention.
:a 13.3 | Function (sales, stock, accounts); product (textbooks, storybooks, stationery); customer (walk-in, schools, online); territory (a branch in each city).
:a 13.4 | A tall structure has many levels and small spans; a flat structure has few levels and wide spans. A cost of tall: slow messages and high cost of many managers. A cost of flat: managers may be overloaded.

:answers 14
:a 14.p1 | The new manager holds the authority, because it belongs to the post. The ten-year employee holds power, because the other employees follow that person's influence. Power can outweigh authority when employees do not yet accept the new manager.
:a 14.p2 | Authority is missing. Rafiq has the duty but not the right to act, so every return waits for Nurul and the task cannot be done as delegated. The three ideas must be in balance.
:a 14.t1 | Tk 5,400 is above Rafiq's limit of Tk 5,000, so Nurul must approve it. Rafiq's authority covers returns up to Tk 5,000 only. Nurul could raise the limit or name another person, such as Tariq, to approve returns in Rafiq's absence.
:a 14.t2 | Telling Nurul to refuse credit is staff authority, which is advice, and it is within his right. Telling a sales assistant to refuse the order is a command to the line's employee, and staff authority does not allow it. The line manager must decide and give the order.
:a 14.1 | Authority is the right to give orders and expect them to be obeyed, given by position. Power is the ability to influence others, whether or not one holds a position. Authority stays with the post, while power leaves with the person.
:a 14.2 | (a) Line authority: it is a manager directing an employee in the chain of command. (b) Staff authority: it is advice and does not command. (c) Functional authority: a specialist commands in one subject only.
:a 14.3 | Delegation is giving an employee the right to make decisions and take action for a stated task. Responsibility, authority and accountability must be kept in balance.
:a 14.4 | Rafiq answers to Nurul for returns he approves, but Nurul still answers to the owners and customers for the shop as a whole. Handing over the task does not remove the answer owed upward.
:a 14.5 | Two reasons are fear of mistakes and fear of losing control. Remedies: match the task to the person and state limits plainly; accept early mistakes and check progress through reports and meetings.
:a 14.6 | Centralization is keeping most decision-making power at the top of the organisation. Conditions favouring decentralization include a large organisation and skilled, trusted employees, or a need for speed near the customer.
:a 14.7 | Coordination is linking the work of different people and departments so that they pull toward the same goal. Basic activities: shared goals, regular communication. Structural techniques: the chain of command, rules, liaison persons or meetings.

:answers 15
:a 15.p1 | Observed fact: the employee arrived late twice. Added by the manager: the belief that the employee does not care about the job.
:a 15.p2 | Yes, it is an unwritten rule that members follow and expect others to follow. It probably helps, because it avoids quarrels over customers, though it could harm the shop if a waiting customer is left unserved.
:a 15.t1 | People differ in traits, abilities and attitudes. A smile shows one trait, and correct answers show another, so one observation is too little. The manager should observe over time and compare impressions with records of work.
:a 15.t2 | The norm is that all three assistants eat lunch together at the same time. The manager could explain the reason, ask the group to propose a rotation that keeps the counter covered, and respect the wish to eat together on some days.
:a 15.t3 | The habit is a quick answer that closes discussion. It teaches employees that suggestions are wasted, so creativity falls and innovation stops. One change: ask what has changed since the last attempt and give a reason for any refusal.
:a 15.t4 | Yes, if the three have different skills that fit together, share one goal (less waiting) and are answerable together for the result. The clinic must make the shared accountability clear, so that all three answer for the result and not each for a part.
:a 15.1 | Human factors are the traits, feelings and relationships of people that affect how they work. They act at the levels of the person, the group and the organisation.
:a 15.2 | A group is two or more people who interact, depend on each other and feel they belong; a team is a small group with joined skills, one common goal and shared accountability. A group example: colleagues at lunch. A team example: staff preparing a school order.
:a 15.3 | Stopping ideas: ridicule, saying we tried that before, or silence in reply. Encouraging ideas: listening, giving time and freedom, making failure safe, or providing a path from idea to action.
:a 15.4 | Creativity is producing a new and useful idea; innovation is putting the idea into use. The 14 suggestions show creativity, and the reading corner, built in April 2026 at Tk 45,000, shows an idea put into use.

:answers 16
:a 16.p1 | Answers vary. A good answer names a goal, such as a skill, a result or the respect of others, that kept the person working without orders.
:a 16.p2 | Esteem. The job is steady and safe, so levels 1 and 2 are met, but the clerk feels unnoticed and wants respect for the work.
:a 16.t1 | Possible answers: the first assistant may feel a need for esteem and belonging (known by regular customers), while the second may feel mainly a need for income and safety, which the pay already meets. The same pay meets one need and leaves the other untouched.
:a 16.t2 | Theory X: it assumes employees must be watched. A result could be distrust, or careless work that matches the low expectation. A Theory Y change: share the till targets with staff and give them responsibility for checking their own sales.
:a 16.t3 | Their lower needs are already met, so extra pay may remove no complaint and add little push. Incentives that touch esteem and growth, such as training, a senior title or responsibility for a project, may work better.
:a 16.1 | Motivation is the inner push that makes a person choose to act and keep acting toward a goal, such as an assistant who tidies shelves each day to be trusted. A need is a lack a person feels and wants to fill, such as the wish for more income.
:a 16.2 | Motivation is inside the person; an incentive is a reward offered from outside. An incentive fails when it does not meet a need the person feels, or when the goal seems out of reach.
:a 16.3 | Physiological, safety, social, esteem, self-actualisation. The order matters because the need pushing now is the one an incentive must meet.
:a 16.4 | Salary: physiological (and safety). Safety shoes: safety. Team outing: social. Title of senior sales assistant: esteem. Designing the window display: self-actualisation (and esteem).
:a 16.5 | Need (wish for income), drive (tension), action (working carefully toward the target), goal (the bonus), need met and tension falls. The loop may restart with a new need.
:a 16.6 | Hygiene factors are the conditions around the job (pay, rules, supervision, security); they prevent unhappiness. Motivators are in the work itself (achievement, recognition, responsibility, advancement); they build effort.
:a 16.7 | Theory X: people dislike work and must be directed and watched. Theory Y: people can enjoy work and seek responsibility. Theory X can suit a dangerous task or a new employee.
:a 16.8 | The record shows that 2 of 7 left but not why. Without knowing which needs are unmet, an incentive may touch the wrong level and be wasted.

:answers 17
:a 17.p1 | Point 5: the manager presents the problem, asks the employees for suggestions, and then makes the decision. The manager keeps the final decision, but only after hearing the group.
:a 17.t1 | Both parts are possible. She is a leader, because colleagues seek her advice and follow it willingly, which is influence without a position. She is not a manager unless she also holds a position of authority.
:a 17.t2 | In the emergency, a point near 1: time is short and danger is high, so the manager decides and announces. For a monthly meeting on the duty roster, a point near 5 or 6, because nurses know their own needs and time allows discussion.
:a 17.1 | Leadership is the process of influencing people to work willingly toward group goals. Its three parts are the leader, the followers and the situation.
:a 17.2 | Any two of: a manager holds a position, a leader holds influence; followers must obey a manager but choose to follow a leader; a leader needs no title. One person can be both when a manager also influences people to follow willingly.
:a 17.3 | Legitimate (position), reward, coercive (punishment), expert and referent power. Referent power comes from liking and admiration: an assistant whom colleagues respect and copy can influence them with no reward to offer.
:a 17.4 | (a) Autocratic: danger and short time. (b) Participative or free-rein: skilled people with knowledge the leader lacks. (c) Free-rein: experienced people with clear goals need little direction.
:a 17.5 | The trait approach looks for personal qualities of leaders; the situational approach says the right way to lead depends on leader, followers and situation. The continuum supports the situational approach, because no point on it is best everywhere.

:answers 18
:a 18.p1 | Deviation = actual − standard = 9 − 5 = 4 spoiled cups above the standard. The manager should first find the cause (for example a machine fault or a new employee) before choosing the correction.
:a 18.p2 | Feedback control. It uses last month's results, after the work is done, to correct later work.
:a 18.t1 | Deviation = 56,000 − 35,000 = Tk 21,000 above the standard. Repayment = 30,000 ÷ 15,000 = 2 years.
:a 18.t2 | It could go too far by taking much of the employees' time and showing distrust, so they may write the log to please the owner and stop using their own judgement. A change that keeps the benefit: log only the key items, such as cash and stock, and check by sample.
:a 18.t3 | The same person does and checks the work, so an error or a theft can pass unseen. The risk falls if another person counts the cash, or if the owner checks the count.
:a 18.1 | Controlling is checking results against plans and taking action to correct any difference. Its halves are the check and the action; a check without action changes nothing.
:a 18.2 | Set a standard (decide the acceptable level); measure performance (find the actual result); compare (find the deviation, actual minus standard); correct (act on the cause).
:a 18.3 | A standard is a level of performance set in advance as the measure of what is acceptable. Examples: sell at least 120 books a day (quantity); serve each customer within 5 minutes (time); keep the stock loss to Tk 35,000 a year (cost).
:a 18.4 | Standard = 0.015 × 200,000 = Tk 3,000. Deviation = 4,200 − 3,000 = Tk 1,200 above the standard.
:a 18.5 | Training before the first day: feedforward. Watching at the till: concurrent. Reviewing last month's sales: feedback. An alarm on a door: concurrent.
:a 18.6 | Feedforward: prevents problems, but depends on forecasts. Concurrent: corrects at once, but costs constant attention. Feedback: easy to apply since results are known, but too late to undo the past.
:a 18.7 | Any three of: timely, accurate, understood, economical, focused on key points. Barriers, any two of: resistance, results hard to measure, cost, too much control.
:a 18.8 | Planning needs controlling to learn whether the plan works. Controlling needs objectives to supply the standards against which results are compared.
