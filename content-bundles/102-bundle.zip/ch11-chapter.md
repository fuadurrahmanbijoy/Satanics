:chapter XI | Decision Tools and Group Decisions
:mood How can a manager make a doubtful choice less doubtful?
:desc Managers seldom know what will happen after they decide; this chapter measures that doubt with numbers, compares choices on one diagram, uses computers for facts, and shows when groups should decide.
:plate ch11-plate.svg | A committee table with members, papers and an inkwell

> This chapter builds on two sections of Chapter 10.

*You will need:* Chapter 10 'Decision Making: Process and Conditions', section 10.3 'Conditions of Decision Making' (certainty and risk); and Chapter 10 'Decision Making: Process and Conditions', section 10.2 'The Decision Process'.

> A manager must choose before the future shows itself.

Imagine that you own a small shop, and a larger shop becomes free in the next street. The rent is high. If customers come, you will earn a good profit. If they do not, you will lose money for a year. You cannot ask the future what will happen. Yet you must answer today, because another trader may take the shop tomorrow.

> Waiting is also a choice, and it has its own cost.

Many people in this position do one of two things. They decide by feeling, and say that the shop looks right. Or they refuse to decide, and say they need more time. Both reactions are understandable. Neither is satisfying, because neither can be explained to a bank, a partner or a family member who asks the plain question: why this choice?

> Numbers can describe a doubt without removing it.

This chapter offers a better way. It does not remove the doubt, because nothing can. It gives the doubt a size. You will learn to say how likely each result is, to weigh each result by its likelihood, and to draw all the choices on one page. You will then see how a computer can supply facts, and when it is wiser to decide together than alone.

* * *

## Probability and Decision Trees

### Probability

> A probability is a number from 0 to 1 that shows how likely an event is.

If you toss a fair coin, how likely is it to land heads up? Most people answer: one chance in two. That answer is already a probability. A probability is a number from 0 to 1 that shows how likely an event is. A probability of 0 means the event cannot happen. A probability of 1 means it is certain. A probability of 0.5 means the event is as likely to happen as not. In plain talk we say *chance*; when we mean the number, we say *probability*.

> A probability comes from counting past records or from honest judgement.

Where does the number come from? There are two sources. The first is counting. A tea-stall owner notes that rain fell on 3 of the last 10 working days, and rain keeps customers away. The probability of rain is 3 divided by 10, which is 0.3.^1 The second source is judgement. When no records exist, an experienced person gives an honest estimate, such as 0.6.

^1: A probability may also be written as a fraction (3/10) or a percentage (30 per cent). The three forms mean the same. This chapter uses decimals, because they multiply easily.

> The probabilities of all possible results of one event add up to 1.

One rule always holds. The probabilities of all possible results of one event add up to 1, because something must happen. If rain has probability 0.3, then no rain has probability 1 − 0.3 = 0.7. Check by adding: 0.3 + 0.7 = 1. When your own numbers do not add up to 1, one of them is wrong.

> Recall: risk and certainty, Chapter 10, section 10.3 'Conditions of Decision Making'.
> For new decisions the probabilities are estimates, and estimates can be wrong.

Now the limit. You met risk in Chapter 10, and probabilities are the numbers that describe it. A manager who plans a new venture, such as a second shop, has no records of that venture. The probabilities are then estimates, and a decision is only as sound as its estimates. The sensible habit is to ask experienced people for the numbers, and then to test whether the decision changes when the numbers change.

> Before moving on: probability is a number from 0 to 1, and all the probabilities of one event add up to 1.

*Before moving on.* A probability is a number from 0 to 1 that shows how likely an event is. It comes from past records or from judgement. The probabilities of all results of one event add up to 1, so the chance that an event does not happen is 1 minus the chance that it does.

### Expected Value

> A fair way to describe an uncertain choice is the average result over many tries.

@! Go slowly here.

Suppose a friend offers you a game. A fair coin is tossed once. If it lands heads, your friend pays you Tk 100. If it lands tails, you pay your friend Tk 20. Would you play? Most people say yes, but cannot say why. The reason is that the game is worth something to you, and we can find out how much. Think about playing ten times. You would expect about five heads and five tails.

> Over ten plays the game pays Tk 400, which is Tk 40 for each play.

Five heads bring 5 × 100 = Tk 500. Five tails cost 5 × 20 = Tk 100. The net gain over ten plays is 500 − 100 = Tk 400. Divided by ten plays, this is Tk 40 for each play. No single play pays Tk 40, because each play pays Tk 100 or costs Tk 20. But Tk 40 is the average, and it tells you what the game is worth.

@ Expected value | The average result of a choice, found by weighting each possible result by its chance.
@ Value | Word in use. In daily life, how much something is worth or how important it is. Here, a number in taka: the average result of a choice.
> Expected value is the average result of a choice, weighted by chance.

That average has a name. **Expected value** means the average result of a choice, found by weighting each possible result by its chance. In the game above, the expected value is Tk 40. The word *expected* does not mean that the result will happen. It means the result you would see on average, if the same choice were made many times.^2

^2: Some books use the longer name *expected monetary value* when all results are sums of money. This book uses *expected value*.

> The formula multiplies each result by its chance and adds the products.

The method has one rule. In words: expected value equals the sum, over every possible result, of the chance of that result multiplied by the result. In symbols: EV = (p₁ × x₁) + (p₂ × x₂) + … Here EV stands for expected value, p stands for the probability of a result, and x stands for the result in taka. The small numbers 1 and 2 label the first and second results. A gain is written as a positive number and a loss as a negative number. The probabilities must add up to 1.

> The first example uses small numbers so that the method is the only new thing.

*Given.* Heads (probability 0.5) pays Tk 100. Tails (probability 0.5) costs Tk 20, written as −20. *Find.* The expected value of one play. *Formula.* EV = (p₁ × x₁) + (p₂ × x₂). *Steps.* Heads: 0.5 × 100 = 50. Tails: 0.5 × (−20) = −10. Add: 50 + (−10) = 40. *Answer.* The expected value is Tk 40 for each play. *Check.* The probabilities add up (0.5 + 0.5 = 1), and Tk 40 lies between the worst result (−20) and the best (100). It also equals the Tk 400 we found over ten plays, divided by ten.

> A second example has three results and is more realistic.

Now a messier case. A trader plans a stall at a three-day fair. A busy fair (probability 0.5) gives a profit of Tk 4,000. A normal fair (probability 0.3) gives Tk 1,500. A wet fair (probability 0.2) gives a loss of Tk 1,000. *Find* the expected value. *Formula.* EV = (p₁ × x₁) + (p₂ × x₂) + (p₃ × x₃). *Steps.* Busy: 0.5 × 4,000 = 2,000. Normal: 0.3 × 1,500 = 450. Wet: 0.2 × (−1,000) = −200. Add: 2,000 + 450 − 200 = 2,250. *Answer.* The expected value is Tk 2,250. *Check.* 0.5 + 0.3 + 0.2 = 1, and 2,250 lies between −1,000 and 4,000.

> The common slips are wrong signs, probabilities that miss 1, and mixed units.

Three slips are common. The first is to forget the minus sign on a loss, which makes a bad choice look good. The second is to use probabilities that do not add up to 1. The third is to mix units, for example profit in thousands of taka in one line and in taka in the next. Write every result in the same unit before you multiply.

> You should now be able to say what expected value is and how it is found.

You should now be able to say: *expected value is the average result of a choice, found by multiplying each result by its probability and adding.*

:pause 11.p1 | A seller may earn Tk 500 with probability 0.8, or lose Tk 1,000 with probability 0.2. Find the expected value.

> Before moving on: expected value is an average, not a promise of any single result.

*Before moving on.* Expected value means the average result of a choice. Multiply each result by its probability, then add. Gains are positive and losses are negative. The probabilities must add up to 1, and no single play need produce the expected value itself.

### Decision Trees

> When a choice leads to chances, which lead to more results, a picture helps.

What if a manager has several choices, and each choice leads to several chance results? The sums are easy one at a time, but the whole problem is hard to hold in the head. Managers therefore draw it. Think of a road map: one road leaves the town, then divides, and divides again. A picture of such roads shows every route at once.

@ Decision tree | A diagram of choices and chance events, drawn as branches, showing the value of each path.
@ Tree | Word in use. In daily life, a plant with a trunk and branches. Here, a diagram whose lines divide like branches.
> A decision tree draws choices and chance events as branches.

A **decision tree** is a diagram of choices and chance events, drawn as branches, showing the value of each path. It is called a tree because the lines divide as branches do, though we draw it on its side, from left to right. Its parts are few. A square marks a *decision point*, where the manager chooses. A circle marks a *chance point*, where events decide the result. Each line is a branch. Each branch that ends the story carries a result in taka.

> A small table shows the parts of a tree and what to do at each.

The table below lists each part, what it means, and what you do at that part. Read each row from left to right: the first cell names the part, the second explains it, and the third tells you the step to carry out.

:table The parts of a decision tree
| Part | Meaning | What you do there |
| Square | A choice the manager makes | Pick the branch with the highest value |
| Circle | A chance event | Calculate the expected value of its branches |
| Branch | One choice or one possible result | Label it with its probability, if it is a chance branch |
| End of branch | The final result in taka | Write profit as positive and loss as negative |

> We read a tree from left to right, but we calculate from right to left.

The order matters. The story runs from left to right, because the choice comes first and the results come later. The calculation runs in the opposite way. Start at the right-hand ends, where the results are known. Work back to each circle and find its expected value. Then come to the square and compare the values of the branches. This backward step is called folding back the tree.

> Recall: risk, Chapter 10, section 10.3 'Conditions of Decision Making'.
> The case file gives a tree for the second shop.

:case Case file, illustrative. Meghna and Sons considered a second shop. The tree has two choices. Opening the second shop leads to a chance event: success with probability 0.6 and a profit of Tk 900,000, or failure with probability 0.4 and a loss of Tk 300,000. Waiting leads to a result of Tk 0. Expected value of opening = 0.6 × 900,000 + 0.4 × (−300,000) = 540,000 − 120,000 = Tk 420,000. Expected value of waiting = Tk 0.

> The figure shows how to read the case tree.

To read the figure, start at the square on the left, which is the choice. The upper branch is opening the second shop. It leads to a circle, where the two chance results appear, each with its probability and its result. The lower branch is waiting, and it ends at Tk 0. The thick line marks the choice with the higher value.

:fig Decision tree for the second shop | ch11-fig01.svg

> The tree's answer depends on its numbers and ignores what has no price.

Now the exceptions. A tree is only as good as its numbers, and the numbers 0.6 and 0.4 are estimates. A tree also needs every result to be written in taka, so it ignores matters that have no price, such as family strain or the shop's name among its customers. Finally, a high expected value does not remove the chance of the loss. The result of Tk 420,000 will never happen: the shop will earn Tk 900,000 or lose Tk 300,000.

> Before moving on: a decision tree is read left to right and calculated right to left.

*Before moving on.* A decision tree shows choices as squares, chance events as circles and results at the branch ends. We fold it back from right to left, finding an expected value at each circle, and then choose at the square. Its answer is only as good as its estimates.

* * *

## Decision Support Systems

### The System Itself

> Hand counting takes days, and by then the answer is old.

A shop owner wants to know which books sell best each week. Counting through paper receipts takes days, and by then the answer is old. A computer can give the same answer in seconds, and can answer follow-up questions as well. Managers have used this idea in every kind of organisation, from banks to hospitals.

@ Decision support system | A computer-based tool that helps managers study data and compare alternatives.
> A decision support system is a computer tool for studying data and comparing alternatives.

A **decision support system** is a computer-based tool that helps managers study data and compare alternatives. A program that stores a firm's sales records and answers questions about them is one example. Such a system usually has three parts: stored data, tools that analyse the data, and a way to ask *what if* questions, such as how profit would change if a price rose by ten per cent.

> The case file shows a small system at work.

:case Case file, illustrative. The sales software of Meghna and Sons lists the top 20 titles each week.

> The system supports the manager, and the manager still decides.

Notice the word *support*. The system does not decide. It prepares facts and comparisons, and the manager judges what they mean. It also has limits. If the stored data are wrong, the answers will be wrong. A system costs money to buy and time to learn. And it cannot see matters that were never recorded, such as a new competitor opening next door.

### Information for Decisions

> Information helps a decision only when it has certain qualities.

Data are only useful when they become information that fits the decision. Good information for a decision has four qualities. It is *accurate*, so that the manager can trust it. It is *timely*, so that it arrives before the decision is due. It is *relevant*, so that it bears on this choice and not another. And it is *understandable*, so that the person using it knows what it means.

> Information has a cost, so a manager should gather only what is worth its price.

A fifth point is about cost. More information is not always better. Collecting it takes time and money, and the Tk spent on it should be less than the improvement it brings to the decision. For the owner, this means asking what a fact would change. For an employee who prepares a report, it means asking what the reader needs to decide.

> Before moving on: a system supports decisions with information that is accurate, timely, relevant and understandable.

*Before moving on.* A decision support system is a computer tool that helps managers study data and compare alternatives. It supports the manager and does not replace the manager. Its value depends on information that is accurate, timely, relevant and understandable, and that is worth what it costs.

* * *

## Deciding in Groups

### The Group Decision

> A manager must choose whether to decide alone or with others.

Who should decide: one person, or several? A single manager can act quickly, but sees the problem from one side. A team sees more sides, but must talk. Both ways are used in every organisation, and the skill lies in choosing the right one for the problem.

@ Group decision | A choice reached by several people discussing and agreeing, instead of one person alone.
> A group decision is a choice that several people reach together.

A **group decision** is a choice reached by several people discussing and agreeing, instead of one person alone. A committee that votes on a new rule makes a group decision. A manager who announces a rule after hearing advice does not, because the manager alone still chooses.

> Recall: the decision process, Chapter 10, section 10.2 'The Decision Process'.
> The case file records how long each way took.

:case Case file, illustrative. A group of three, Nurul, Rafiq and Tariq, took 3 days to reach a decision. Nurul alone took 1 day.

### Advantages and Disadvantages

> A group brings more knowledge and more support, and it costs more time.

The advantages of group decisions are real. A group holds more information than one person, so more alternatives appear. Members who help to choose usually understand the decision and are more willing to carry it out. The disadvantages are also real. A group is slower, as the case file shows: it took two days more than Nurul alone. It uses the time of several employees. One loud member may dominate the others. And a compromise may please everyone while being good for no one. When many people share the choice, nobody may feel fully responsible for it.

> The table compares a group with one manager on five points.

The next table compares the two ways on five points. Read each row across: the left cell names the point, and the other two cells say how a group and a single manager usually compare on it.

:table A group compared with one manager
| Point | Group decision | One manager deciding |
| Speed | Slower | Faster |
| Range of ideas | Wider | Narrower |
| Support from those affected | Stronger | Weaker, unless explained |
| Responsibility | Shared and less clear | Clear |
| Cost in time | Higher | Lower |

> A group suits important, unclear problems; one manager suits urgent, clear ones.

The table suggests a rule. Choose a group when the problem is important, unclear, and affects many people, and when time allows. Choose one manager when the problem is urgent or simple, or when one person holds the authority and the knowledge. The exception is that no rule fits every case, and a manager may still choose to consult before deciding alone.

### Other Factors in Decisions

> Money values and probabilities are not the only things that shape a decision.

A decision tree uses taka and probabilities. Real decisions also depend on other factors. The first is time: some decisions cannot wait for a long study. The second is cost: a study can cost more than the decision is worth. The third is importance: a small choice deserves a small effort. The fourth is the manager's own values and attitude to risk, for two managers may read the same expected value and choose differently. The fifth is authority: who is allowed to decide, and whose agreement is needed.

> Managers rarely find the best answer; they stop at a good one.

One last fact explains much of this. Managers rarely have time or information to compare every alternative. They usually stop when they find one that is good enough. The section *In History*, later in this chapter, tells who named this habit.

> Before moving on: a group decision gains knowledge and support but costs time, and several factors besides money shape any choice.

*Before moving on.* A group decision is a choice reached by several people discussing and agreeing. It brings more ideas and support, and it costs time and can blur responsibility. Time, cost, importance, values and authority also shape a decision.

* * *

## Worked Case: Choosing Between Two Sites

> Selim must compare two sites and waiting, using expected value.

*Situation.* Selim runs a stationery stall and may rent one of two sites. At Site A, success (probability 0.5) gives a profit of Tk 80,000, and failure (probability 0.5) gives a loss of Tk 20,000. At Site B, success (probability 0.8) gives a profit of Tk 30,000, and failure (probability 0.2) gives a loss of Tk 10,000. Waiting gives Tk 0. *Question.* Which choice has the highest expected value, and is that choice automatically the right one?

> We fold back the tree: first each circle, then the square.

*Reasoning.* We fold back the tree from the right. Site A: 0.5 × 80,000 = 40,000, and 0.5 × (−20,000) = −10,000, so the expected value is 40,000 − 10,000 = Tk 30,000. Site B: 0.8 × 30,000 = 24,000, and 0.2 × (−10,000) = −2,000, so the expected value is 24,000 − 2,000 = Tk 22,000. Waiting is Tk 0. *Conclusion.* Site A has the highest expected value, Tk 30,000, against Tk 22,000 for Site B. But Site A can lose Tk 20,000, twice the worst loss at Site B. A trader who cannot bear that loss may rightly prefer Site B. The tree informs the choice and does not make it. *Check.* Each pair of probabilities adds up to 1, and each expected value lies between its best and worst result.

* * *

## Summary

> The summary gathers the main ideas.

A probability is a number from 0 to 1, and the probabilities of one event add up to 1. Expected value is the average result of a choice: multiply each result by its probability and add. A decision tree draws choices and chance events as branches, and we fold it back from right to left. A decision support system supplies data and comparisons, and the manager decides. A group decision gains knowledge and support but costs time.

## Think It Through

:q 11.t1 | The case file shows that a group of three took 3 days, and Nurul alone took 1 day. Name two situations in which the extra 2 days are worth it, and one in which they are not.

:q 11.t2 | In the second-shop tree, suppose the probability of success falls to 0.4 and the probability of failure rises to 0.6, with the same profit and loss. Find the new expected value of opening. Does opening still beat waiting?

:q 11.t3 | Find the probability of success at which opening the second shop has the same expected value as waiting. Write p for this probability, so that failure has probability 1 − p.

## Where People Go Wrong

> A common error is to treat expected value as the result that will happen.

Some students believe that an expected value of Tk 420,000 means the shop will earn Tk 420,000. It will not. The shop earns Tk 900,000 or loses Tk 300,000. The expected value is an average over many tries, and it is a guide for a choice made once.

> Another error is to think that the highest expected value is always best.

Some students believe that the choice with the highest expected value must always be taken. A choice with a large possible loss may be too dangerous for a small firm, as the worked case shows.

> A third error is to trust a tree more than its numbers deserve.

Some students believe that a tree is exact because it uses arithmetic. The arithmetic is exact, but the probabilities are estimates, so the answer is no better than they are.

> A last error is to think that groups are always better, or that a system decides.

Some students believe that a group always decides better than one manager, or that a decision support system makes the decision. A group costs time and a system only supports. Each has a place, and neither replaces judgement.

## In History

> Herbert Simon showed in 1947 that managers settle for a good enough choice.

In 1947 the American social scientist Herbert Simon, born in Milwaukee in 1916, published *Administrative Behavior*. He had studied at the University of Chicago and earned a doctorate in political science there in 1943. Many economists of the time pictured a decision maker who weighs every alternative and picks the best. Simon replied that real managers cannot do this. They have limited time, limited information and a limited power to calculate. So they look for a course of action that is good enough and stop when they find it. He named this habit *satisficing*, a word that joins *satisfy* and *suffice*.

> His idea explains why tools and groups help, but cannot make the search endless.

In 1978 Simon received the Nobel prize in economics, and later in his career he turned to artificial intelligence by computer. His idea fits this chapter. A tree and a decision support system widen what a manager can examine. A group widens what is known. But each costs time, so managers still stop when the choice is good enough.

## Review Questions

:q 11.1 | A probability is 0.25. What does this number mean, and what is the probability that the event does not happen?

:q 11.2 | Find the expected value: probability 0.7 of a profit of Tk 50,000, and probability 0.3 of a loss of Tk 80,000.

:q 11.3 | Find the expected value: probability 0.2 of Tk 100,000, probability 0.5 of Tk 40,000, and probability 0.3 of a loss of Tk 60,000.

:q 11.4 | Choice X gives Tk 200,000 with probability 0.6 and −Tk 100,000 with probability 0.4. Choice Y gives Tk 70,000 for certain. Which has the higher expected value, and what else might a manager weigh?

:q 11.5 | In a decision tree, what do a square and a circle show, and in which direction do we draw the tree and in which do we calculate it?

:q 11.6 | Describe two ways in which a decision support system helps a manager, and one limit.

:q 11.7 | Give two advantages and two disadvantages of a group decision.

:q 11.8 | Name three factors, other than money and probability, that shape a decision.

:q 11.9 | Using Chapter 10, say why a decision tree suits a decision under risk, and what changes when the manager has certainty.

:read Herbert A. Simon, Administrative Behavior, 1947
:read Howard Raiffa, Decision Analysis: Introductory Lectures on Choices under Uncertainty, 1968
