:glossary 01
Management | The work of planning, organising, leading and controlling people and resources to reach an organisation's goals. It means deciding what to do, arranging the work, guiding the people and checking the results. A shop owner who orders books, gives out duties, encourages staff and counts the takings is performing management.
Organisation | A group of people working together in a planned way to reach goals they could not reach alone. The group has a purpose, shared tasks and some rules. A bookshop with its owner and staff is an organisation, and so are a school and a hospital. This book uses one word for all such groups.
Resource | Anything an organisation uses to reach its goals, such as people, money, materials and information. A bookshop's resources include its books, cash, shelves, staff and list of school customers. Every organisation has only a limited amount of each resource, so managers must decide how to use them well.
Manager | A person who is responsible for the work of other people and for the results of their work. A manager does not only do tasks personally, but sees that others do them well. The person who directs the sales assistants and answers for the shop's sales is a manager.
Responsibility | A duty to carry out a task and to answer for how well it is done. A cashier is responsible for counting the cash correctly and for explaining any difference. Responsibility is not the same as authority, which is the right to give orders and make decisions.

:glossary 02
Top manager | A manager at the highest level, who sets the direction of the whole organisation. The top manager decides what the organisation will do and what it will not do. In a bank this is the managing director, and in a small family shop it is the owner-manager.
Middle manager | A manager between top and first-line managers, who turns the direction into plans for departments. The middle manager receives a direction and returns a plan. The manager of a bank's loans department, who decides how many loan officers are needed, is a middle manager.
First-line manager | A manager who directly supervises employees doing the day-to-day work. The people supervised are not themselves managers, so this level is closest to the daily work and to the customer. The supervisor of the cashiers at a bank counter is a first-line manager.
Technical skill | The ability to use the tools, methods and knowledge of a specific job. It is mainly about working with things and methods, and it can be learned by training and practice. A stock clerk who counts and shelves books quickly and correctly shows technical skill.
Human skill | The ability to work with, understand and motivate other people. It includes listening and explaining. A manager needs it at every level, because results come through people. A supervisor who notices a tired cashier and explains a new rule well shows human skill.
Conceptual skill | The ability to see the organisation as a whole and to understand how its parts connect. It is about working with ideas and with the links among them. A manager who sees that late books delay school orders and harm the shop's name shows conceptual skill.

:glossary 03
Management process | The continuing cycle of planning, organising, leading and controlling that managers repeat. When one round ends, the information it produces feeds the next round. Example: a shop owner sets a target, arranges jobs, guides employees, checks results and then plans again.
Function of management | One of the four main kinds of work managers do: planning, organising, leading or controlling. The word means a main kind of work. Example: arranging who does which job is the function of organising.
Productivity | The amount of output an organisation obtains for each unit of input it uses. It equals output divided by input. Example: 41,000 copies sold by 7 employees is 5,857 copies per employee.
Effectiveness | How far an organisation reaches its goals, whatever the cost. It asks whether the goal was met and ignores the input used. Example: a cook who serves all 200 guests is effective, even if food was wasted.
Efficiency | How little input an organisation uses to reach a given result. For the same result, less input means higher efficiency. Example: relabelled shelves cut the daily search for stock from 3 hours to 1 hour.
Profession | An occupation that requires long training, a body of knowledge and a code of conduct enforced by an association. Example: medicine, where doctors normally register with a medical council. Managing a small shop does not require a licence.
Principle of management | A broad guide to action drawn from experience, to be adapted and not applied like a law. It may suit one organisation and fit another badly. Example: dividing work among specialists suits a factory more than a shop of seven people.

:glossary 04
Scientific management | The study of work by measurement, aimed at finding the one best method and training workers in it. Frederick Taylor began it in the 1900s. Example: timing several ways of unloading a carton and choosing the fastest.
Time and motion study | Timing each movement of a task to remove wasted effort and set a fair standard. The tool of scientific management. Example: timing a carton at 14 minutes, changing the method, and timing it again at 9 minutes.
Bureaucracy | A system of management built on written rules, clear levels of authority and appointment by skill. Max Weber described it as a design for fairness. Example: a shop with a written rule list and clear roles for each employee.
Human relations school | A school of thought holding that workers' feelings and social bonds strongly affect output. It grew from the Hawthorne studies. Example: an employee who feels respected by the group may work harder, even when pay is the same.
Management science approach | The use of mathematical models and data to solve management problems. It grew after the Second World War. Example: using past sales data to decide how many copies of a title to order.
Contingency approach | The view that the best way to manage depends on the situation. It grew from the 1960s. Example: a fixed method suits unloading cartons, while a flexible style may suit a team inventing a new service.

:glossary 05
Internal environment | The conditions inside an organisation that its managers can change directly, such as its people, its structure and its culture. When a shop hires a new employee or changes who works the counter, it is changing its internal environment.
External environment | All the forces outside an organisation that affect it, such as customers, rivals, laws and technology. Managers cannot command these forces, but they can study them, prepare for them and sometimes influence them.
Task environment | The outside groups that deal directly with an organisation, such as its customers, suppliers and rivals. For a bookshop, the schools that order books and the publishers that supply them belong to its task environment.
Environmental scanning | The regular collection and study of information about outside changes that could affect an organisation. A shop owner who reads rivals' online prices every week is scanning. Its value lies in meeting change early, when many responses remain open.

:glossary 06
Corporate social responsibility | An organisation's duty to act for the good of society as well as for profit. It applies to every organisation, large or small. A bookshop that pays its employees fairly and recycles its waste paper is acting on this duty.
Business ethics | The moral rules that decide what is right and wrong in business conduct. A moral rule is a belief about how people ought to treat one another, such as "do not deceive". Ethics asks for more than the law requires.
Ethical dilemma | A choice in which every option has a cost to some person's rights or interests. For example, a shop owner may have to dismiss one of two employees or cut the pay of both. It differs from a temptation, where one option is plainly wrong.
Triple bottom line | A way of judging an organisation by its profit, its effect on people and its effect on the natural environment. John Elkington proposed it in 1994. It adds two more "last lines" to the single last line of the accounts, which shows profit.
Sustainability | Running an organisation so that it meets today's needs without harming later generations' ability to meet theirs. It covers the natural environment, people and the organisation's own money. A farmer who plants seedlings after picking fruit follows the same rule.

:glossary 07
Plan | A written or spoken statement of what will be done, by whom and by when, to reach an objective. A plan names the action, the person and the time. Example: "Place the book order by 12 December; the manager will do it."
Planning premise | An assumption about future conditions on which a plan is built. The manager writes it down so that everyone shares it. Example: a shop assumes that publishers raise prices by 5%, and builds its order budget on that assumption.
Forecast | A reasoned estimate of what will happen in the future, used as a base for a plan. It rests on evidence such as past records. Example: estimating next season's sales from the sales of the last three seasons.
Alternative | One of several possible courses of action from which a choice is made. A manager lists alternatives and weighs each one before choosing. Example: order all the books at once, order half now and half later, or order only what schools have promised.

:glossary 08
Standing plan | A plan made once and used again and again for situations that repeat. It saves thought and gives fair, equal treatment. Example: a shop's returns policy, applied to every customer who asks to exchange a book.
Single-use plan | A plan made for one occasion or project and not used again. It has a start and an end. Example: the plan for a 28-day book fair stall, which will not be repeated in the same form.
Policy | A general guide for decisions, setting limits within which choices are made. It guides but leaves room for judgement. Example: "We exchange books within 7 days", where the employee decides about a damaged book on the last day.
Procedure | A fixed series of steps to be followed for a repeated task. It says how to do the work, in a fixed order. Example: ask for the receipt, check the date, check the book, give the new book, record the exchange.
Budget | A plan that states expected income and spending in money terms for a period. It turns plans into figures. Example: a book fair budget with planned spending of Tk 240,000 and expected sales of Tk 900,000.

:glossary 09
Objective | A specific result that an organisation or person intends to reach within a stated time. It names a result, a measure, a number and a date. Example: selling 500 copies of one textbook before 30 June.
Key result area | A part of the organisation's work where results are vital to success. A bookshop might name sales, stock, customer service, returns and profit as its key result areas, and set objectives in each.
Management by objectives | A system in which managers and employees agree objectives together, then judge performance against them. Its cycle runs from agreeing objectives, to acting with self-control, to review and appraisal, and back to agreement. Peter Drucker described it in 1954.
Performance appraisal | A review of how well an employee has done against agreed standards. In management by objectives, the standard is the objective agreed at the start. Example: an employee who agreed 14 training hours and received 10 is told the gap.

:glossary 10
Decision making | Choosing one course of action from several, in order to solve a problem or use an opportunity. It begins when a manager sees a gap to close or a chance to use. For example, a shop owner picks one site for a second shop from two possible sites.
Decision criterion | A standard used to judge which alternative is best. A criterion is a test that every option must pass or be scored against. For example, a student sets two criteria for a journey: arrive by 8:55 and spend no more than Tk 50.
Certainty | A condition in which the result of each alternative is known in advance. A manager can compare the known results and choose the best. For example, a shop that signs a lease knows its rent of Tk 38,000 a month.
Risk | A condition in which the result is not known but its chances can be estimated, usually from past records. The result may be good or bad. For example, a stall owner whose records show rain on 4 of 10 days estimates the chance of rain as 0.4.
Uncertainty | A condition in which neither the results nor their chances can be estimated, often because no records or comparisons exist. A manager must rely on judgement. For example, a stall owner opening in a town with no records cannot say what sales to expect.

:glossary 11
Expected value | The average result of a choice, found by multiplying each possible result by its probability and adding the products. Gains count as positive and losses as negative. It need not equal any single result. For example, a game that pays Tk 100 or costs Tk 20 with equal chances has an expected value of Tk 40.
Decision tree | A diagram of choices and chance events, drawn from left to right as branches. Squares mark choices, circles mark chance events, and the branch ends show results in taka. We calculate from right to left, finding the expected value at each circle, and then choose the highest value at the square.
Decision support system | A computer-based tool that helps managers study data and compare alternatives. It stores data, analyses it and answers what-if questions. It supports the manager and does not decide. For example, sales software that lists the top 20 titles each week helps a shop plan its stock.
Group decision | A choice reached by several people discussing and agreeing, instead of one person alone. It brings more ideas and wider support, but it is slower and costs more time. For example, a committee that votes on a new rule makes a group decision.

:glossary 12
Organizing | The function of arranging tasks, people and resources into a working structure so that goals can be reached. A bookshop owner who decides who buys, who sells and who keeps accounts is organizing. It follows planning in the management process.
Organizational structure | The pattern of jobs, groups and reporting lines that divides and links the work of an organisation. It answers who does which task and who answers to whom, and it exists whether or not anyone has drawn it.
Organization chart | A diagram that shows the jobs in an organisation and who reports to whom. Boxes stand for jobs and lines stand for reporting lines. It records the formal structure at one moment and can become out of date.
Formal organization | The official structure of jobs, rules and lines of authority that management sets up on purpose. It is usually written down in job descriptions, rules and the organization chart, and it gives order and stability.
Informal organization | The network of friendships and social groups that forms among employees on its own. No manager designs it and no document records it. A lunch group that shares book tips is an example. It can help or harm the organisation.

:glossary 13
Span of management | The number of employees who report directly to one manager. Only direct reports count. A store manager with three sales assistants, a cashier and a stock clerk has a span of five. The best span depends on skill, nearness and the kind of work.
Departmentalization | The grouping of jobs into departments according to a common basis, such as function, product, customer or territory. A department is a group of jobs under one manager. A shop may group by function into sales, stock and accounts.
Tall structure | A structure with many levels and small spans of management. Close supervision is possible, but messages pass through many levels and the many managers raise the cost of wages.
Flat structure | A structure with few levels and wide spans of management. Messages travel quickly and employees have more freedom, but each manager may be overloaded when the span is too wide.
Division of labour | The dividing of a large job into smaller tasks done by different people. Each worker becomes skilled in a narrow task, but the divided tasks must be joined again, which creates the need for coordination.

:glossary 14
Authority | The right to give orders and to expect them to be obeyed, given by position. It belongs to the post and passes to each new holder. For example, a store manager may order a till count.
Power | The ability to influence other people's behaviour, whether or not one holds a position. It comes from the person, through knowledge, rewards, punishment or liking, and leaves with the person. For example, a trusted colleague persuades others to follow a plan.
Delegation | Giving an employee the right to make decisions and take action for a stated task. The task has limits, and the manager still checks the result. For example, an owner lets a store manager approve returns up to Tk 5,000.
Accountability | The duty to explain and answer for results to the person who delegated the work. It stays with the person who must answer, even when the task has been handed on. For example, a store manager reports returns to the owner.
Line authority | The right of a manager to direct the work of employees in the chain of command. Orders travel down the line of positions from the top. For example, a store manager directs the sales assistants.
Staff authority | The right to advise and support line managers, without commanding their employees. The line manager still decides. For example, an accounts adviser tells a store manager that a school's credit is too high.
Centralization | Keeping most decision-making power at the top of the organisation. Its opposite is decentralization. For example, an owner who approves every return and every order runs a centralized shop.
Coordination | Linking the work of different people and departments so that they pull toward the same goal. It uses shared goals, communication, plans, rules and meetings. For example, a weekly Sunday meeting lets a shop share news before the week begins.

:glossary 15
Human factors | The traits, feelings and relationships of people that affect how they work. A trait is a lasting feature, such as patience. A feeling is a state of mind, such as worry. A relationship is a link between people, such as friendship. They act on the person, the group and the organisation.
Team | A small group of people with joined skills, working toward a common goal for which all are accountable. Accountable means answerable for the result. Staff who prepare a school order together form a team; colleagues who only eat lunch together are a group.
Group norm | An unwritten rule that members of a group follow and expect others to follow. A norm may say how fast to work or how to treat newcomers. A member who breaks it may be laughed at or left out. Norms can help or harm the organisation.
Creativity | The ability to produce new and useful ideas. Both words matter: an idea that is new but useless is a curiosity, and an idea that is useful but not new is a copy. A quiet corner where customers try a book before buying is an example.
Innovation | Turning a new idea into a new product, service or method that is put to use. Creativity is the seed and innovation is the crop. A suggestion on paper is creativity; a reading corner built and used by customers is innovation.

:glossary 16
Motivation | The inner push that makes a person choose to act and keep acting toward a goal. It is inside the person, so managers see only the behaviour. For example, an assistant who tidies shelves each day to earn trust shows strong motivation.
Need | A lack that a person feels and wants to fill. A need creates tension, called a drive, that pushes the person to act. Needs differ between people. For example, one employee lacks income and another lacks respect.
Incentive | A reward offered to encourage a person to act in a wanted way. It comes from outside the person and works only when it meets a need the person feels. For example, a bonus of one month's pay for meeting a sales target.
Need hierarchy | Maslow's idea that human needs rank in five levels: physiological, safety, social, esteem and self-actualisation. An unmet lower need pushes most strongly, and a higher need matters only after the lower ones are met. The order is a guide, not a fixed law.
Theory X | A set of assumptions, named by Douglas McGregor in 1960, that people dislike work and must be directed and watched. A manager holding it tends to use close control and punishment. For example, a clock-in system for every employee.
Theory Y | A set of assumptions, named by Douglas McGregor in 1960, that people can enjoy work and seek responsibility. A manager holding it tends to share goals and delegate. For example, offering training for a supervisor post.

:glossary 17
Leadership | The process of influencing people to work willingly toward group goals. It involves a leader, followers and a situation, and it does not depend on a title. Example: a friend who persuades five others to share the costs of a trip.
Referent power | Power that comes from other people's liking and admiration for a leader. It belongs to the relationship, not the position. Example: a sales assistant whom colleagues respect and wish to resemble can influence them without any reward.
Leadership style | The usual way a leader makes decisions and treats followers. It is a habit and not a rule. Example: a leader who nearly always decides alone and then informs the group has a different style from one who nearly always asks first.
Emotional intelligence | The ability to notice, understand and manage one's own and other people's feelings. Example: a manager who sees that a tired employee is losing patience and responds calmly.
Transformational leadership | Leading by inspiring followers to look beyond self-interest and to change themselves and the organisation. It differs from a leader who trades pay or praise for work done. Example: an owner who explains why good service matters to the neighbourhood.

:glossary 18
Controlling | Checking results against plans and taking action to correct any difference. It has two halves, the check and the action, and it is the last function in the management process. Its findings go back into the next plan. For example, counting stock each week and fitting tags where losses appear.
Standard | A level of performance set in advance as the measure of what is acceptable. It can be stated in quantity, quality, time or cost. A good standard is measurable and fair. For example, a stock loss of no more than 1% of stock value.
Feedforward control | Control that acts before work begins, to prevent problems. It checks inputs such as people, materials, money and plans. Its strength is prevention, and its weakness is reliance on forecasts. For example, training a new cashier before the first day.
Concurrent control | Control that acts while the work is being done. It checks the process as it happens and corrects at once, but it costs constant attention. For example, a supervisor helping a new cashier at the till, or an alarm that sounds as an item leaves the shop.
Feedback control | Control that acts after the work is done, using the results to correct later work. It is easy to apply because results are known, but it cannot undo what has happened. For example, a year-end stock count.
