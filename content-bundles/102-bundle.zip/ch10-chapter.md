:chapter X | Decision Making: Process and Conditions
:mood How do you choose when you cannot see what comes next?
:desc This chapter explains how managers decide. It shows what a decision is, follows the steps from seeing a problem to checking the result, and then describes the three conditions in which every decision is made: certainty, risk and uncertainty. A second shop in Dhaka and a launch in Florida serve as cases.
:plate ch10-plate.svg | A magistrate at the bench with his clerk

> You will need: Chapter 7, 'Planning: Meaning, Nature and Steps', section 7.1 'What Planning Is'; Chapter 9, 'Objectives and Management by Objectives', section 9.2 'Setting Objectives'.
> A simple choice about travel hides a method that managers use every day.

It is seven in the morning, and your class begins at nine. You can walk, take a bus or hire a rickshaw. You pause for a moment, think of the cost and the time, and choose. By the time you reach the door you have made a decision. Did you do anything that could be written down as a method?

> A short choice already holds several separate acts.

Look again at what you did. You noticed that you had to be somewhere by nine. You asked what mattered to you: the cost, the time, or both. You listed the ways to go, compared them and picked one. Then you went, and you learned something from the journey. Most people perform all of these acts in a few seconds and never name them.

> A manager makes such choices with more at stake and with others affected.

A manager performs the same acts under heavier conditions. The choice may cost thousands of taka, or change the work of seven employees. Other people will live with the result, and the manager cannot test it in advance. A fast habit that works for a bus ride can fail badly when the stakes are high.

> The chapter teaches the method first and the conditions second.

This chapter teaches the method first, in clear steps that a manager can follow and check. It then describes the three conditions in which every decision is made. We follow one real choice, made by a bookshop in Dhaka on 20 August 2026. We also visit a launch pad in Florida, where in January 1986 a different choice ended in disaster.

* * *

## 10.1 What a Decision Is

@! Go slowly here.
> The idea of a decision begins with an everyday choice of one thing from several.

Begin with something small. Rina is a student, and on Friday she has Tk 500 to spend. She can buy a book, buy a cinema ticket or keep the money. She cannot do all three with Tk 500. She must choose.

> Recall: Chapter 7, 'Planning: Meaning, Nature and Steps', section 7.1 'What Planning Is' — planning.
> Rina's choice has the shape of every decision: several options and one choice.
@ Decision making | Choosing one course of action from several, in order to solve a problem or use an opportunity.
@ Decision | Word in use. In daily life, any choice that a person has made, or the act of settling a question. In management, a choice of one course of action from several, made to solve a problem or use an opportunity.

Her choice has a name in management. **Decision making** means choosing one course of action from several, in order to solve a problem or use an opportunity. Rina has three courses of action, and she picks one. A shop owner who chooses between two sites for a new shop does the same thing with larger sums. Notice the word *several*: with only one course of action open, nothing is chosen, and no decision exists.

> Every plan is made of decisions, so decision making lies inside planning.

Chapter 7 taught that planning means deciding in advance what to do and how to do it. We can now see how the two ideas connect. Every plan is built from decisions. A manager who plans next year's work must first choose among the courses of action that are open. Decision making is therefore a part of planning, and it also appears in every other task of a manager.

> A word with two meanings needs a careful reading.

The word *decision* has two meanings, and the second one is the one we use. In daily life a decision may be any choice that someone has made. In management a decision is the choice of one course of action from several, made to solve a problem or use an opportunity. The second meaning always has a purpose and always follows a comparison.

> The first idea is secure when the reader can state it in one sentence.

*You should now be able to say:* a decision is a choice of one course of action from several, made for a purpose.

> Every decision starts when someone sees a problem or an opportunity.

Why do managers decide at all? A decision starts when a manager sees that something needs to change. We use the word problem for a gap between what is and what should be. A stock clerk reports that sales of school books are falling, and the gap between actual and wanted sales is a problem. We use the word opportunity for a chance to do better than before. A school asks the shop to supply all its textbooks, and that offer is an opportunity.

> A problem is felt as pain, but an opportunity is easy to miss.

The two start differently. A problem is usually loud: complaints, losses and shortages press the manager to act. An opportunity is quiet. Nobody complains about a chance that was missed, so a manager must look for it. For this reason, careful managers watch the world outside the organisation and not only the troubles inside it. Both a problem and an opportunity lead to the same act, which is a decision.

> Rina's Friday shows an opportunity: a free offer that she would not have noticed.

Return to Rina. Suppose a friend tells her that the cinema has a half-price show on Friday. Before the friend spoke, she had no problem, only a plan to buy a book. The friend's news is an opportunity, and it makes her choice worth making again. A decision can start with good news as well as with bad.

> The recap of the two ideas so far.

*In one line:* a decision begins when a manager sees a gap to close or a chance to use, and the manager then chooses one course of action from several.

> Managerial decisions differ from private ones in four ways.

Managerial decision making has a special nature. Rina spends her own Tk 500, and only she bears the result. A manager spends the organisation's resources, and many people bear the result. This difference gives managerial decisions four features, and each one is explained below.

> The first feature is that the manager answers for the choice to others.

First, the manager answers for the decision to owners, employees and customers. Second, managers decide with incomplete facts, because the future cannot be seen and time is short. Third, decisions are linked: choosing to open a second shop leads to later choices about staff, stock and prices. Fourth, a decision often changes the work of other people, so how the manager shares the choice matters as much as the choice itself.

> Each position sees the decision differently.

Each person sees a decision from a different place. The owner asks whether the choice is worth the money. The manager asks how to carry it out. An employee asks how the work will change. A customer asks only whether the shop will continue to serve well. A wise manager considers all four views before choosing.

> The recap of section 10.1.

*Before moving on.* Decision making is choosing one course of action from several, in order to solve a problem or use an opportunity. A problem is a gap to close and an opportunity is a chance to use; both start a decision. Managers decide for an organisation, with incomplete facts, and their choices affect many people.

> A sentence to test the reader's grasp of the section.
*You should now be able to say:* a manager decides when a problem or an opportunity makes a choice necessary, and the choice affects other people.

* * *

## 10.2 The Decision Process

@! Go slowly here.
> A bus ride shows each step of the method before we use it on a business.

A method is easier to learn on a small case. Return to the morning at the start of the chapter, and give it numbers. Rina must reach class by 8:55, and she lives 40 minutes away by bus. She has little money. We will follow her through each step, and then apply the same steps to a shop.

> Step 1 is to state the problem or opportunity in plain words.

Step 1: name the problem or opportunity. Rina writes it plainly: "I must be in class by 8:55 and I must not spend much." A vague statement leads to a vague decision. Many students find this step easy to skip, because the problem feels obvious. A decision made on the wrong problem can be perfect in every other way and still fail.

> Step 2 is to decide how the best choice will be judged.
@ Decision criterion | A standard used to judge which alternative is best.

Step 2: set the criteria. A **decision criterion** means a standard used to judge which alternative is best. Rina has two criteria: arrive by 8:55, and spend no more than Tk 50. Each criterion is a test that an option must pass. Criteria come from the goals that the decision serves. Chapter 9 showed how a goal becomes a measurable objective, and a good criterion often comes straight from an objective.

> Criteria should be set before the options are examined.

The order matters. Set the criteria before you look at the options. If you see the options first, you may choose the criteria that favour the option you already like. A manager who sets the criteria first can defend the choice later, because the standard was fixed before the result was known.

> Step 3 is to list the possible courses of action.

Step 3: develop the alternatives. An alternative is one possible course of action. Rina lists three: walk, take the bus and hire a rickshaw. A manager should seek more than two or three, and should look beyond the first idea that comes to mind. A common error is a list of one real option and two weak ones, which only appears to give a choice. Include the option of doing nothing or waiting, because it too has a cost.

> Step 4 is to test each alternative against each criterion.

Step 4: evaluate the alternatives. To evaluate means to test each alternative against each criterion and record the result. Rina's walk takes 70 minutes and costs nothing, so she arrives at 9:10 and fails the first test. The bus takes 40 minutes and costs Tk 20. The rickshaw takes 25 minutes and costs Tk 100. The table below sets these results side by side.

> A table shows which alternatives pass which tests.

Read the table one row at a time. The first cell names an alternative, the next two cells give its results, and the last cell shows whether it passes both criteria. The criteria are on the top row.

:table Rina's three alternatives tested against two criteria
| Alternative | Arrival time | Cost | Passes both criteria? |
| Walk | 9:10 | Tk 0 | No: arrives after 8:55 |
| Bus | 8:40 | Tk 20 | Yes |
| Rickshaw | 8:25 | Tk 100 | No: costs more than Tk 50 |

> Step 5 is to choose the alternative that best meets the criteria.

Step 5: choose. Only the bus passes both tests, so Rina chooses it. Choosing is often the shortest step. The hard work has already been done in the earlier steps. When no alternative passes all the criteria, or when several pass, the manager must rank the criteria by importance and decide which one counts most.

> Step 6 is to carry out the choice and then check what happened.

Step 6: implement and follow up. To implement means to carry out the choice, and to follow up means to check afterwards whether the result matched the plan. Rina leaves at 8:00, takes the bus and notes that it arrived at 8:40 as expected. Had the bus been late, she would change tomorrow's plan. A decision is not finished when the choice is made. It is finished when the results are checked and the lesson is stored.

:box IN SHORT
The decision process has six steps: name the problem or opportunity; set the criteria; develop the alternatives; evaluate them; choose; implement and follow up.

> The figure shows the six steps in order, with a loop back from the last step to the first.

:fig Decision steps as a flow | ch10-fig01.svg

> The figure is read from top to bottom, then back to the top by the dashed line.

Read the figure from the top box downwards. Each box is one step, and each arrow shows that one step leads to the next. The dashed line on the right returns from step 6 to step 1. It means that checking the result may reveal a new problem, so the process begins again.

> Steps 1 to 5 are done in the mind and on paper; only step 6 changes the world.

Steps 1 to 5 take place in thought and on paper. Only step 6 changes anything outside the manager's head. This is why managers should spend care on the first five steps and not rush toward the sixth. A mistake caught on paper costs nothing, and the same mistake caught after implementation may cost a great deal.

> The process has limits that a careful manager must know.

The process has limits. Real managers do not always follow the six steps in strict order. They may return to step 2 after seeing the alternatives, because a new option shows that a criterion was missing. Time may be short, and some information may cost more to gather than the decision is worth. The steps are a guide for thinking, and they work best when a manager treats them as a checklist and not as a ritual.

:pause 10.p1 | Rina finds that the bus will be 20 minutes late on one day. Which step of the process does she return to, and what could she change?

> The recap of section 10.2.

*Before moving on.* A decision criterion is a standard used to judge which alternative is best. The process has six steps: name the problem or opportunity, set the criteria, develop alternatives, evaluate them, choose, then implement and follow up. Criteria are set before options are examined. Following up closes the loop and may start the process again.

> A sentence to test the reader's grasp of the section.
*You should now be able to say:* the steps in order, and why a manager sets the criteria before looking at the options.

* * *

## 10.3 Conditions of Decision Making

@! Go slowly here.
> Every decision faces a different amount of knowledge about the future.

Why do two decisions of the same size feel so different? One may be calm and the other frightening. The difference lies in how much the manager knows about what will happen after the choice. Management names three conditions, from the most knowledge to the least. We take them one at a time, with a small example for each.

> Certainty means the manager knows the exact result of each alternative.
@ Certainty | A condition in which the result of each alternative is known in advance.

The first condition is **certainty**, which means a condition in which the result of each alternative is known in advance. Rina knows that the bus fare is Tk 20, and she knows that the bus takes 40 minutes. A shop that signs a rent of Tk 38,000 a month knows what it will pay each month. Certainty is rare in business, but it does exist for costs that a contract fixes.

> Risk means results are unknown but their chances can be estimated.
@ Risk | A condition in which the result is not known but its chances can be estimated.
@ Risk | Word in use. In daily life, a danger of harm. In management, a condition in which the result is not known but its chances can be estimated, and the result may be good or bad.

The second condition is **risk**. Risk means a condition in which the result is not known but its chances can be estimated. A tea stall owner has kept records for 10 market days. It rained on 4 of them. The owner cannot know whether tomorrow will be wet, but can estimate that the chance of rain is 4 in 10, or 0.4. The word *risk* has an everyday meaning of danger. In management it means that the result is unknown and its chances can be estimated, and the result may be good or bad.

> Risk depends on records or experience that allow a chance to be estimated.

How does a manager estimate a chance? The usual source is past records or experience of similar cases. The owner's 10 days of records give a rough chance of 0.4. More records would give a better estimate. When the records are few, the estimate is weak, and a manager should say so honestly.

> Uncertainty means that neither the results nor their chances can be estimated.
@ Uncertainty | A condition in which neither the results nor their chances can be estimated.

The third condition is **uncertainty**, which means a condition in which neither the results nor their chances can be estimated. Suppose the tea stall owner wants to open in a town where she has no records and no comparison. She cannot say what the sales might be, and she cannot say how likely each result is. Many students find the difference between risk and uncertainty confusing, because both involve not knowing. The test is whether a chance can be estimated: if yes, it is risk; if no, it is uncertainty.

> A table sets the three conditions side by side with their tests.

The table below compares the three conditions. Read each row from the left. The first cell names the condition, the second says what the manager knows, and the third gives the tea stall example.

:table The three conditions of decision making
| Condition | What the manager knows | Tea stall example |
| Certainty | The result of each alternative | The rent for the month, fixed by a contract |
| Risk | The possible results and their chances | Rain on 4 of the last 10 market days |
| Uncertainty | Neither the results nor their chances | A town where the owner has no records |

> The three conditions form a line from full knowledge to little knowledge.

Think of the conditions as points on a line. At one end, the manager knows everything about the result. At the other end, the manager knows almost nothing. Most real decisions lie somewhere between. A single decision can also hold all three conditions at once: the rent may be certain, the sales a risk and the competitor's reaction an uncertainty.

> Managers meet each condition differently.

Each condition asks for a different attitude. Under certainty, a manager can compare the known results and choose the best. Under risk, a manager weighs the chances and accepts that the result may fall short. Under uncertainty, the manager must use judgement, gather more information if time allows, and prefer choices that can be changed later if they prove wrong.

> The conditions apply to the second-shop decision in the case file.

Consider the second-shop decision of 20 August 2026, which the next section works in full. The rents and fitting costs are fixed amounts and so are certain. The expected sales are estimates, and the case file gives no chances for them. We therefore cannot call them a risk, and the sales belong closer to uncertainty. The condition shapes how firmly the owner should trust the numbers.

:pause 10.p2 | A manager of a small shop must choose a new supplier. The supplier's price list is fixed for a year, but nobody can say how many customers will want the new books. Name the condition for the price and the condition for the number of customers, and give a reason for each.

> The recap of section 10.3.

*Before moving on.* Certainty is a condition in which the result of each alternative is known in advance. Risk is a condition in which the result is not known but its chances can be estimated. Uncertainty is a condition in which neither the results nor their chances can be estimated. A single decision may hold all three.

> A sentence to test the reader's grasp of the section.
*You should now be able to say:* what the manager knows under each condition, and how to tell risk from uncertainty.

* * *

## Worked Case: The Second Shop

> The worked case applies the six steps and the three conditions to one decision.

We now apply the whole chapter to one decision in the case file. The worked case has five parts: Situation, Question, Reasoning, Conclusion and Check. It applies the ideas to a situation. It is an application, not a model answer.

> The situation lists three options with their costs and expected sales.

:case Case file, illustrative. Decision, 20 August 2026, Meghna and Sons: open a second shop? Option 1, Mirpur: rent Tk 38,000 a month, fitting Tk 650,000, expected sales Tk 5,400,000 a year. Option 2, Uttara: rent Tk 52,000 a month, fitting Tk 720,000, expected sales Tk 5,100,000 a year. Option 3: wait a year.

> The question asks which option best meets the owner's criteria.

*Question.* Which option should the shop prefer on the figures in the case file? The case file does not state the owner's goal. For this exercise only, we assume that the owner wants the most sales for the money spent in the first year.

> Steps 1 and 2: the problem is a choice of site, and two criteria follow from the assumed goal.

*Reasoning, steps 1 and 2.* The opportunity is a second shop, and the choice to be made is which site, or whether to wait. From the assumed goal we set two criteria. Criterion A: expected sales for each taka spent in the first year on rent and fitting; a higher figure is better. Criterion B: expected sales less one year's rent; a higher figure is better. Both are fixed before we look at the totals.

> Step 3: the three alternatives are already listed in the case file.

*Reasoning, step 3.* The three alternatives are Mirpur, Uttara and waiting. Waiting has no cost for fitting or rent, and it earns nothing from a second shop. The case file gives no other figure for it. We can therefore score waiting on neither criterion, and the owner must judge it by facts that the file does not hold.

> Step 4: the arithmetic for Mirpur is worked line by line.

*Reasoning, step 4, Mirpur.* Rent for one year: 38,000 × 12 = Tk 456,000. Cost in the first year: 456,000 + 650,000 = Tk 1,106,000. Criterion A: 5,400,000 ÷ 1,106,000 = 4.88 taka of expected sales for each taka spent. Criterion B: 5,400,000 − 456,000 = Tk 4,944,000.

> Step 4 continued: the same arithmetic for Uttara.

*Reasoning, step 4, Uttara.* Rent for one year: 52,000 × 12 = Tk 624,000. Cost in the first year: 624,000 + 720,000 = Tk 1,344,000. Criterion A: 5,100,000 ÷ 1,344,000 = 3.79 taka of expected sales for each taka spent. Criterion B: 5,100,000 − 624,000 = Tk 4,476,000.

> A table collects the results so that the options can be compared.

The table collects the results. Read each row from the left: the option, the first-year cost, the two criteria. The last row shows that waiting cannot be scored.

:table Mirpur and Uttara on the two criteria
| Option | First-year cost | A: sales per taka spent | B: sales less rent |
| Mirpur | Tk 1,106,000 | 4.88 | Tk 4,944,000 |
| Uttara | Tk 1,344,000 | 3.79 | Tk 4,476,000 |
| Wait a year | Tk 0 | Not scored | Not scored |

> Steps 5 and 6: Mirpur wins on both criteria, and the follow-up compares actual with expected sales.

*Reasoning, steps 5 and 6.* Mirpur is higher on both criteria, so on these figures it is the better site. If the owner chose Mirpur, the follow-up would record the actual sales and costs in the first year and compare them with Tk 5,400,000 and Tk 1,106,000. The size of any gap would show how far the estimates could be trusted. The condition matters here: rent and fitting are certain, but expected sales hold no estimated chance, and so belong nearer uncertainty.

> The conclusion states what the figures support and what they leave open.

*Conclusion.* On the assumed goal, Mirpur is the better site, because it costs less and expects more sales. The figures do not say whether waiting is better, since they do not measure it. The case file records the options and does not record the final choice. *Check.* Mirpur has the lower rent, the lower fitting cost and the higher expected sales, so every figure points the same way. It follows that both criteria must favour Mirpur, and they do.

### Changing the Situation

> Rung 2 reshapes Rina's case so that no option passes both tests.

The same method works in new situations. Rung 1 is Rina's bus ride, solved above. In rung 2, suppose the bus fare rises to Tk 60. Now no alternative passes both criteria. Rina must rank her criteria and decide which counts more, and the process returns to step 2.

> Rung 3 moves the method to a school with a very different setting.

In rung 3, a school head must choose a place for a class visit. The head sets criteria for cost, distance and safety, lists four places, tests each one and chooses. The steps are the same, though the people and the sums are different. Chapter 7 showed that planning places the choice inside a larger plan, and here the visit is that plan.

> Rung 4 combines the process with the three conditions and with planning.

In rung 4, a small clinic must decide whether to buy a new machine. The price is certain. The number of patients who will need it can be estimated from last year's records, so that part is a risk. The reaction of a rival clinic cannot be estimated, so that part is uncertainty. The owner uses all six steps and treats each part according to its condition.

* * *

## Summary

> A short summary of the chapter's five defined terms and the process.

Decision making is choosing one course of action from several, in order to solve a problem or use an opportunity. The process has six steps: name the problem or opportunity, set the decision criteria, develop alternatives, evaluate them, choose, then implement and follow up. A decision criterion is a standard used to judge which alternative is best. Certainty means the result of each alternative is known, risk means the chances can be estimated, and uncertainty means neither results nor chances can be estimated.

## Think It Through

:q 10.t1 | A manager must choose between two suppliers of paper. Supplier A offers a fixed price for the year. Supplier B offers a lower price, but its delivery times are not known because it is new. Name the condition that applies to each part of the choice, and say which step of the process would tell the manager what to find out first.

:q 10.t2 | In the second-shop case, the expected sales are estimates only. Suppose the owner learns that the Mirpur figure is far too high. Which criteria change, which do not, and what should the owner do next?

## Where People Go Wrong

> Mistake one: believing that a decision is the moment of choosing.

*Mistake: "The decision is the moment when I choose."* The choice is one step of six. The steps before it decide what is chosen from, and the step after it decides whether the choice worked.

> Mistake two: judging a decision by its result alone.

*Mistake: "A good result means the decision was good."* A good decision can end badly through bad luck, and a poor decision can end well. Judge the method used and the facts known at the time, and then check the result.

> Mistake three: believing that more information always gives a better decision.

*Mistake: "I must wait until I know everything."* Full knowledge is rare, and waiting has a cost of its own. A manager should gather the information that is worth its cost and then decide.

> Mistake four: treating risk and uncertainty as the same thing.

*Mistake: "Risk and uncertainty mean the same."* Under risk the chances can be estimated, and under uncertainty they cannot. The tea stall with 10 days of records faces risk, and the stall in a new town without records faces uncertainty.

> Mistake five: setting criteria after seeing the options.

*Mistake: "I will decide on the criteria when I see the choices."* The criteria then tend to favour the option already liked. Fix them first.

## In History

> The launch of Challenger in January 1986 shows a decision under pressure and uncertainty.

On the evening of 27 January 1986, engineers at Morton Thiokol, the company that made the rocket boosters for the United States space shuttle, spoke by telephone with managers of NASA, the national space agency. The shuttle Challenger was due to launch the next morning from Florida, and the forecast was for unusually cold weather. The engineers feared that the rubber seals in the boosters would not work in the cold. They had followed damage to such seals on earlier flights.

> The managers reversed the first advice and the launch went ahead.

Thiokol's managers at first supported a delay, but after discussion with NASA they reversed that advice, and the launch went ahead on 28 January 1986. Challenger broke apart 73 seconds after liftoff, and all seven crew members died. A presidential commission led by William Rogers, a former United States Secretary of State, reported in June 1986. It judged the decision process flawed, and it found that the concerns of the engineers had not been fully passed to the senior managers who approved the launch.

> The case shows each part of the chapter at work.

The case shows the chapter's ideas at work. The criterion of safety in cold weather was set aside under time pressure, and waiting was an alternative that carried a cost but was open. No earlier launch had been so cold, so past records could not give a reliable chance of failure, and the condition lay close to uncertainty. The follow-up on earlier flights had found the damage and had not changed the next decision.

## Review Questions

:q 10.1 | Define decision making in your own words and give one example from a bookshop.

:q 10.2 | Explain the difference between a problem and an opportunity, and say which is easier to miss and why.

:q 10.3 | List the six steps of the decision process in order. For step 2, say why the criteria are set before the alternatives are examined.

:q 10.4 | Define decision criterion. Give two criteria that a shop owner might use to choose between two suppliers.

:q 10.5 | Classify each part of the following as certainty, risk or uncertainty, with a reason: (a) the monthly rent fixed by a lease; (b) the chance of rain based on 10 days of records; (c) the sales of a new kind of product that no shop has sold before.

:q 10.6 | A manager has records showing that 3 of the last 12 school orders arrived late. What condition is this, and what is the estimated chance of a late order as a fraction?

:q 10.7 | The bus fare in Rina's case rises to Tk 60. Explain which step of the process she must repeat, and what she must decide.

:read Herbert Simon, Administrative Behavior, 1947
:read Diane Vaughan, The Challenger Launch Decision, 1996
:read Report of the Presidential Commission on the Space Shuttle Challenger Accident, 1986
