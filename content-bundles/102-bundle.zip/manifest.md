:bundle
status: ok
failures: 0
chapters: 18
appendix: none
changed-duplicates-resolved: 0
glossary-duplicates-removed: 0
chapter | ch01 | I | What Management Is | 3474 | 1 | 5 | 9
chapter | ch02 | II | Managers and Their Skills | 3408 | 1 | 6 | 10
chapter | ch03 | III | The Functions of Management and How Management Is Judged | 3148 | 2 | 7 | 10
chapter | ch04 | IV | The Evolution of Management Thought | 2987 | 2 | 6 | 10
chapter | ch05 | V | The Environment of Organisations | 3350 | 1 | 4 | 9
chapter | ch06 | VI | Social Responsibility, Ethics and Sustainability | 3599 | 1 | 5 | 9
chapter | ch07 | VII | Planning: Meaning, Nature and Steps | 3523 | 1 | 4 | 11
chapter | ch08 | VIII | Kinds of Plans and Making Planning Work | 3236 | 1 | 5 | 11
chapter | ch09 | IX | Objectives and Management by Objectives | 3574 | 1 | 4 | 9
chapter | ch10 | X | Decision Making: Process and Conditions | 3724 | 1 | 5 | 11
chapter | ch11 | XI | Decision Tools and Group Decisions | 3206 | 1 | 4 | 13
chapter | ch12 | XII | Organizing and Types of Organization | 3862 | 1 | 5 | 10
chapter | ch13 | XIII | Structure: Span, Departments and Forces | 3480 | 1 | 5 | 10
chapter | ch14 | XIV | Authority, Delegation and Coordination | 3622 | 2 | 8 | 11
chapter | ch15 | XV | Human Factors, Groups and Creativity | 3416 | 1 | 5 | 10
chapter | ch16 | XVI | Motivation | 3793 | 2 | 6 | 13
chapter | ch17 | XVII | Leadership | 3753 | 1 | 5 | 8
chapter | ch18 | XVIII | Controlling | 3369 | 1 | 5 | 13
