:answers 02
:a 2.p1 | Nurul works at the top level. Rafiq's weekly stock plan is middle-level work, and his direct supervision of five employees is first-line work.
:a 2.p2 | Human skill. The manager is working with and understanding a person, and giving the employee a reason to speak and to keep learning.
:a 2.t1 | Nurul works at the top level. Rafiq stands at the middle level (weekly stock plan, supervising 5 staff) and at the first-line level (directly supervising 3 sales assistants, 1 cashier and 1 stock clerk).
:a 2.t2 | The new manager stands at the middle level, below Nurul, and is a general manager because the manager answers for a whole shop. If the manager directly supervises employees, the work also stands at the first-line level.
:a 2.t3 | The chairman is the top manager and needs conceptual skill most. The depot manager is a middle manager with a medium mix and large human skill. The driver supervisor is a first-line manager and needs technical skill most.
:a 2.t4 | Human skill. The assistant has strong technical skill, but a manager gets results through the work of other people, so the new supervisor must learn to work with, understand and motivate them.
:a 2.1 | The head of the whole network is a top manager. The loans department manager is a middle manager. The supervisor of the cashiers is a first-line manager.
:a 2.2 | A top manager's decisions affect the whole organisation and the top manager seldom does the daily work, so seeing how the parts connect becomes the main ability. A first-line manager sees the work directly.
:a 2.3 | People (the sales assistants), money (the day's takings), materials (stock and shelves), information (sales records or the list of school customers).
:a 2.4 | A functional manager is in charge of one kind of work, such as the accounts department. A general manager is in charge of several kinds of work together, such as the head of a whole branch.
