:chapter II | Managers and Their Skills
:mood Does one kind of ability fit every kind of manager?
:desc This chapter shows that managers work at different levels, and that each level calls for a different mix of abilities. It names three levels of manager, three kinds of skill, and the resources and roles that managers handle. It also asks what makes a manager effective.
:plate ch02-plate.svg | A railway company boardroom, with a station master and a foreman standing apart

> This chapter builds on the first chapter.

*You will need:* Chapter 1 'What Management Is', section 1.1 'The Idea of Management'; Chapter 1 'What Management Is', section 1.4 'A Manager's Responsibility'. *Recall:* management, organisation and manager, Chapter 1, section 1.1; responsibility, Chapter 1, section 1.4.

> Three jobs in one shop need three different abilities.

Imagine the owner of a small bookshop on an ordinary Monday. A shelf has fallen and must be repaired before customers arrive. A school has asked for next year's textbooks, and the owner must decide how many copies to order. Two employees are quarrelling about who closes the till, and neither will speak to the other. Each problem belongs to management, yet each calls for a different ability. Mending a shelf needs skill with tools. Planning next year's orders needs a view of the whole shop. Settling a quarrel needs an understanding of people.

> The puzzle asks whether managers at every level need these abilities equally.

Now the puzzle. Should the owner of a large chain of bookshops spend the day mending shelves? Should the supervisor of one counter spend the day planning the chain's future? Most readers feel that the answer is no, but cannot yet say why. The reason is that managers stand at different levels, and the abilities they need change from one level to the next. This chapter explains the levels first. It then explains the abilities, and last it shows what managers handle and what they do.

* * *

## 2.1 Levels and Kinds of Manager

@! Go slowly here.

> A school shows three levels in a familiar setting.

We begin with a school that you know. At the top, a principal decides what kind of school it will be. Below the principal, the head of each subject turns that direction into plans for the teachers of the subject. At the bottom, teachers guide pupils in the classroom day after day. Nobody finds this strange. The school has levels, and each level has a different job. A business has the same pattern. Management is not one flat group of equals; it is arranged in steps.

@ Level | Word in use. In daily life, a level can mean a floor of a building or a height. In management, a level is a step in the chain of managers, from the top of the organisation to the bottom.

> In this book, level means a step in the chain of managers.

In this book the word *level* always means a step in that chain. It does not describe how important or how clever a person is. A manager at a lower level may be cleverer than one above, and the level still describes only the position in the chain.

@ Top manager | A manager at the highest level, who sets the direction of the whole organisation.

> The top manager sets the direction of the whole organisation.

At the highest level stands the **top manager**. A top manager is a manager at the highest level, who sets the direction of the whole organisation. In a bank, the managing director is a top manager. In a small family shop, the owner-manager is one. Top managers decide what the organisation will do and what it will not do. Two levels lie below them, and the next two paragraphs name them.

@ Middle manager | A manager between top and first-line managers, who turns the direction into plans for departments.

> The middle manager turns direction into plans for departments.

Below the top stands the **middle manager**. A middle manager is a manager between top and first-line managers, who turns the direction into plans for departments.^1 Suppose the top manager of a bank decides that the bank will lend more to small businesses. The manager of the loans department then decides how many loan officers are needed, which customers to visit and in which weeks. Middle managers receive a direction and return a plan.

^1: A department is a part of an organisation that does one kind of work, such as accounts or sales.

@ First-line manager | A manager who directly supervises employees doing the day-to-day work.

> The first-line manager directly supervises the employees who do the daily work.

At the lowest level stands the **first-line manager**. A first-line manager is a manager who directly supervises employees doing the day-to-day work. The supervisor of the cashiers at a bank counter is a first-line manager. The people under this manager are not themselves managers, so this level is the closest to the customer and to the daily work.

> A railway company of the 1800s gives a historical picture of the three levels.

One can picture the same ladder in a railway company of the 1800s. The directors, meeting in a boardroom, set the direction of the whole company. A station master directed the work of one station. A foreman supervised a gang of workers on the track. Each of these three saw a different part of the business, and each answered for a different part of its results.

> The case file shows all three levels in one small shop.

:case Case file, illustrative. Roles at Meghna and Sons in 2026. Top: Nurul sets prices, hires and approves loans. Middle: Rafiq makes the weekly stock plan and supervises 5 staff; Tariq handles accounts and online orders. First-line work: Rafiq directly supervises 3 sales assistants, 1 cashier and 1 stock clerk.

> One person can stand at two levels, as Rafiq does in the case file.

Read the case file with care, because Rafiq appears twice. His weekly stock plan is middle-level work, because it turns the owner's direction into a plan. His direct supervision of five employees is first-line work. Many students find this confusing, because they expect each person to have one level. In a small organisation the levels are thin, and one person often covers two of them. The level belongs to the work, and not only to the person.

:pause 2.p1 | In the case file, at which level does Nurul work? At which two levels does Rafiq's work stand?

> Managers also differ in the width of their area, apart from their level.

Levels describe height in the chain. Managers also differ in width. A *functional manager* is in charge of one kind of work, such as accounts, sales or stock. A *general manager* is in charge of several kinds of work together, and answers for a whole unit. A department head in a large company is a functional manager, and the head of a whole branch is a general manager. At Meghna and Sons, Tariq's work lies in two specialised areas, accounts and online orders, while Nurul answers for the whole shop. Height and width are separate ideas, so a middle manager can be either kind.

> Each level looks different from the employee's side, the customer's side and the owner's side.

The levels also look different from different viewpoints. An employee takes daily directions from a first-line manager and may rarely meet the top manager. A customer meets the first-line level most often, at the counter or on the shop floor. The owner expects the top manager to answer for the whole organisation, as Chapter 1 explained when it described responsibility.

> The recap repeats the three levels and the two kinds of width.

*Before moving on.* A top manager sets the direction of the whole organisation. A middle manager turns the direction into plans for departments. A first-line manager directly supervises the employees who do the daily work. A functional manager looks after one kind of work, and a general manager looks after several. *You should now be able to say* what each of the three levels does.

* * *

## 2.2 Skills Managers Need

@! Go slowly here.

> A cricket captain shows three different abilities in one person.

Think of the captain of a village cricket team. The captain must know the game well: how to bat, how to bowl and how to field. That is one ability. The captain must also keep eleven different players working together, and must notice when one of them is upset. That is a second ability. The captain must also read the whole match: the weather, the score, the overs left and the strength of the other side. That is a third. Management needs the same three kinds of ability, and Robert Katz named them in 1955.

@ Technical skill | The ability to use the tools, methods and knowledge of a specific job.

> Technical skill is the ability to do a specific job with its own tools and methods.

The first kind is **technical skill**. Technical skill is the ability to use the tools, methods and knowledge of a specific job. A stock clerk who counts and shelves books quickly and correctly has technical skill. So does an accountant who keeps a correct record of money. Technical skill is mainly about working with things and methods. It can be learned by training and practice, and a person can see at once whether the work is done well.

@ Human skill | The ability to work with, understand and motivate other people.

> Human skill is the ability to work well with people.

The second kind is **human skill**. Human skill is the ability to work with, understand and motivate other people. To *motivate* means to give a person a reason to begin acting and to keep acting; Chapter 16, 'Motivation', teaches it fully. A first-line manager who notices that a tired cashier needs a short break, and who explains a new rule in a way that the cashier accepts, shows human skill. Human skill is about working with people, and not with things. It also includes listening, because a manager who does not listen cannot understand an employee's difficulty.

@ Conceptual skill | The ability to see the organisation as a whole and to understand how its parts connect.

> Conceptual skill is the ability to see the whole organisation and how its parts connect.

The third kind is **conceptual skill**. Conceptual skill is the ability to see the organisation as a whole and to understand how its parts connect. Suppose a publisher delivers books late. A manager with conceptual skill sees more than a late delivery. Late books delay school orders, late school orders damage the shop's name, and a damaged name reduces future orders. Seeing this chain of effects is the skill. It is about working with ideas and with the links among them.

:pause 2.p2 | A manager notices that a new employee is afraid to ask questions, and arranges a weekly short talk with the employee. Which of the three skills does this show? Give a reason.

> The mix of skills changes with level, but one skill stays large at every level.

Now the main question of the section: does every manager need all three skills equally? Katz found that every manager needs all three, but not in the same amounts. The amounts change with the level. This is the idea of the *skill mix by level*, and we build it in four steps.

> Katz's pattern is easiest to see by following one person up the levels.

Follow one person upward to see the pattern. A cashier who counts money quickly is promoted to supervise the cashiers. Her technical skill is large and helps her at once, because she can teach and check. Later she becomes manager of the whole counter area, and then of the branch. At each step, she uses less of her own counting skill and more of her skill with people and with ideas. The cashier did not lose the skill; the work asked for a different mix.

> Step one: first-line managers need the most technical skill.

First, consider the first-line manager. The team under this manager does the daily work, such as selling, counting or repairing. To teach a new employee, to judge whether work is good, and to help when something goes wrong, the supervisor must understand the job. A first-line manager therefore needs a large amount of technical skill, and only a small amount of conceptual skill, because the daily work is close and the supervisor can see it directly.

> Step two: top managers need the most conceptual skill and less technical skill.

Second, consider the top manager. A top manager's decisions affect the whole organisation, and the top manager seldom does the daily work. Seeing how the parts connect becomes the main ability. A top manager therefore needs a large amount of conceptual skill, and a smaller amount of technical skill than the first-line manager. The middle manager stands between: a medium amount of technical skill and a medium amount of conceptual skill.

> Step three: human skill is needed at every level, because management is work through people.

Third, human skill stays large at every level. Chapter 1 explained that a manager gets results through the work of other people. The first-line manager supervises employees, the middle manager works with department heads and the top manager works with every level and with people outside the organisation. At each level, the results depend on people. The table below gathers the three steps. Read each row from left to right: the level, then the size of need for each skill.

:table Skill need by level
| Level | Technical skill | Human skill | Conceptual skill |
| Top manager | Small | Large | Large |
| Middle manager | Medium | Large | Medium |
| First-line manager | Large | Large | Small |

> The figure shows the same pattern as bars, and it is read from top to bottom.

The figure below shows the same pattern. Read it from top to bottom. Each row is one level, drawn wider as it goes down. The three bars on the right show how much of each skill that level needs. A longer bar means a larger need. Notice that the bar for human skill has the same length in every row.

:fig Three levels of management and the skills each needs | ch02-fig01.svg

:box IN SHORT
The need for technical skill falls as we go up the levels, the need for conceptual skill rises, and the need for human skill stays large at every level.

> Step four: the pattern has exceptions, and a beginner should know them.

Fourth, the exceptions. The table shows a general pattern, and not a law. In a very small organisation, the top manager may still perform technical work every week, because there are too few people to share it. A skilled specialist who is promoted often arrives with plenty of technical skill and little human skill, and must learn the second one. Finally, skills can be learned. A person who is weak in one skill is not fixed in that weakness, and an organisation can train its managers.

> The recap repeats the three skills and the pattern by level.

*Before moving on.* Technical skill uses the tools and methods of a job. Human skill works with people. Conceptual skill sees the whole organisation. The mix changes with level, but human skill stays large at every level. *You should now be able to say* which skill each level needs most.

* * *

## 2.3 Managers and Resources

> A manager handles resources, and the four kinds named in Chapter 1 each need different care.

Chapter 1 defined a resource as anything an organisation uses to reach its goals, such as people, money, materials and information. Managers at every level handle all four kinds, though in different proportions. People need direction and fair treatment. Money needs a record and a careful use. Materials, such as stock and fittings, need storage and protection. Information, such as sales records and customer lists, needs to be accurate and to reach the right person in time. A first-line manager mostly handles people and materials. A top manager spends more time on money and information that concern the whole organisation.

@ Role | Word in use. In daily life, a role is a part played by an actor. In management, a role is a set of tasks that a manager is expected to perform.

> A role is a set of tasks that a manager is expected to perform.

Managers also perform *roles*. In this book a role is a set of tasks that a manager is expected to perform. It is a useful word, because it describes what a manager does and not the manager's title. One person can perform several roles in the same hour.

> Resources and skills fit together, because each resource calls for a different skill.

Resources and skills fit together. Handling people calls mainly for human skill. Handling stock, fittings or a record of money calls mainly for technical skill. Handling information so that it reveals how the parts connect calls mainly for conceptual skill. A manager who sees these links can decide which skill to practise when a new kind of problem appears.

> Four plain roles describe most of what managers do.

Four plain roles describe most of the daily work. In the first, the manager directs people: assigns tasks, answers questions and settles disagreements. In the second, the manager deals with people outside the organisation, such as suppliers, customers and lenders. In the third, the manager handles information: receives it, checks it and passes it to those who need it. In the fourth, the manager decides how to use the organisation's resources. The mix of roles changes with level, in the same way as the mix of skills. A first-line manager spends most of the day in the first role, and a top manager spends more time in the second and fourth.

> A first-line manager and a top manager use the same four roles in different proportions.

Consider two managers in one bank on the same morning. The cashier supervisor spends most of the hour in the first role, because a new employee needs help at the counter and a customer is waiting. The managing director spends the same hour in the second and fourth roles: meeting a lender, and deciding whether the bank can afford a new branch. Both managers perform all four roles during a week. The difference lies in the amount of time given to each, and that difference follows from the level.

> Qualities describe what a person is like, and they support skills.

Qualities are different from skills. A skill is what a person can do, and a quality is what a person is like. Fairness, honesty, reliability and a willingness to learn are qualities that help an effective manager. They matter because employees follow directions more readily from a manager they trust. Qualities do not replace skills, and skills do not replace qualities. A kind but unskilled manager cannot repair a failing process, and a skilled but unfair manager loses the trust of the team.

> The recap repeats resources, roles and qualities.

*Before moving on.* Managers handle people, money, materials and information. A role is a set of tasks that a manager is expected to perform, and four plain roles cover most of the work. Qualities support skills. *You should now be able to say* what a manager handles and what a manager does.

* * *

## Worked Case: Skills in One Week at Meghna and Sons

> The worked case applies the three skills and the pattern by level to one week.

This worked case applies the skills of this chapter to one documented week. It does not model a written answer. It shows one way of reasoning, step by step. *Situation.* Read the case file below first.

> The case file records how Nurul used a typical week of 48 hours.

:case Case file, illustrative. Time use of Nurul, the top manager of Meghna and Sons, in a typical week of 48 hours: 20 hours planning and dealing with publishers; 16 hours on the shop floor; 12 hours on staff and money matters.

> The question asks which skill each block uses and whether the pattern fits a top manager.

*Question.* Which skill does each block of Nurul's week mainly use? Does the pattern fit the usual mix for a top manager?

> The reasoning takes each block in turn.

*Reasoning.* We take the three blocks one at a time.

> Step one: planning and publishers call mainly for conceptual skill.

Step 1. Planning, and dealing with publishers, 20 hours. Planning the shop's year means seeing the whole shop and how its parts connect, so this block uses mainly conceptual skill. Dealing with publishers also needs human skill, because it means working with people outside the shop.

> Step two: the shop floor calls for technical skill.

Step 2. The shop floor, 16 hours. Selling, shelving and serving customers are the methods of specific jobs, so this block uses mainly technical skill.

> Step three: staff and money matters call for human skill and some technical skill.

Step 3. Staff and money matters, 12 hours. Working with the staff uses human skill. Keeping a record of money uses some technical skill. We call this block mainly human skill.

> A common slip is to give every hour to one skill only.

*Common slips.* Readers often give each block of the week to one skill only. Most blocks use more than one skill, so we name the main skill and note the second. Readers also forget that the pattern for a top manager is a general pattern, and not a rule that every top manager must follow.

> Step four: we compare the week with the usual pattern for a top manager.

Step 4. The usual pattern says that a top manager needs a small amount of technical skill. Nurul spends 16 of 48 hours on technical work, which is one third, because 16 ÷ 48 = 1 ÷ 3. This is a larger share than the pattern suggests. The reason is the size of the shop. With few employees, the top level and the shop floor overlap, in the same way that Rafiq's work reaches two levels.

> Step five: the week looks different from the owner's side and the employees' side.

Step 5. The same week can be seen from other viewpoints. The employees see the 16 hours on the shop floor as help at busy times, and as a manager who knows the work. The publishers see the 20 hours as dealing with the person who decides the shop's orders. Nurul, as owner, knows that all three blocks answer to the same duty: results for the shop. Each viewpoint shows a different side of the same week.

> The conclusion states what the week shows and where the pattern bends.

*Conclusion.* Nurul's week uses all three skills. Conceptual skill takes the largest block, as the pattern predicts for a top manager. The large technical block is an exception explained by the small size of the organisation.

> The check confirms that the three blocks add to the whole week.

*Check.* The three blocks add to the week: 20 + 16 + 12 = 48 hours. Each hour has been given to one skill, so nothing is missing or counted twice.

* * *

## Summary

> The summary gathers the chapter into a few sentences.

Managers stand at three levels. A top manager sets the direction of the whole organisation, a middle manager turns it into plans for departments, and a first-line manager directly supervises the employees who do the daily work. Three skills serve them: technical skill, human skill and conceptual skill. The mix changes with level, and human skill stays large at every level. Managers handle people, money, materials and information, and they perform several roles. Qualities such as fairness support these skills but do not replace them. In a small organisation, such as Meghna and Sons, one person may work at two levels, and the top manager may still perform technical work.

## Think It Through

> Four short cases take you from the case file to new settings.

Each case below moves a little further from the case file. Use only the ideas of this chapter.

:q 2.t1 | Use the case file. At which level does Nurul work, and at which levels does Rafiq's work stand?
:q 2.t2 | Suppose Meghna and Sons opens a second shop with its own manager, who answers to Nurul and directs a small team. At which level does the new manager stand, and why?
:q 2.t3 | A bus company has a chairman, a depot manager and a driver supervisor. Place each at a level, and say which skill each one needs most.
:q 2.t4 | A sales assistant who sells books very well is promoted to supervise the other sales assistants. Which of the three skills is the new supervisor most likely to lack at first? Use Chapter 1 to explain why that skill matters.

## Where People Go Wrong

> Five common misunderstandings are stated and corrected.

*Wrong:* Top managers need no technical skill, and first-line managers need no conceptual skill. *Correct:* Every manager uses all three skills. Only the amounts differ from one level to the next.

> A further misunderstanding mixes up the three skills.

*Wrong:* A person who is good with people has conceptual skill. *Correct:* The skills are different. A person can be excellent with people and still fail to see how the parts of an organisation connect.

> A second misunderstanding gives each person one fixed level.

*Wrong:* Each person stands at exactly one level. *Correct:* The level belongs to the work. In a small organisation, one person often performs work at two levels, as Rafiq does.

> A third misunderstanding treats level as a measure of worth.

*Wrong:* A higher level means a more valuable person. *Correct:* Level describes a position in the chain of managers. It says nothing about how valuable or how clever a person is.

> A fourth misunderstanding treats skill as a gift.

*Wrong:* Managers are born with their skills. *Correct:* Skills can be learned. A manager who is weak in one skill can improve it through training and practice.

## In History

> Robert Katz named the three skills in 1955.

In 1955, Robert Katz published an article in the *Harvard Business Review* called "Skills of an Effective Administrator". The journal is an American magazine for business managers. Katz used the word administrator for the person; this book uses manager. He began from a view close to Chapter 1: a person who directs the work of others and answers for the results.

> Katz argued that three skills explain effective management, and that skills differ from traits.

Katz argued that effective management rests on three basic skills, which he called technical, human and conceptual. He also drew a line between skills and traits. A skill is what a person can do, and a trait is what a person is. Because skills can be developed, his article suggested that managers can be trained.

> Katz also noticed how the mix of skills changes with level.

His article also described how the mix of skills changes with level. Technical skill matters less, and conceptual skill matters more, as a person rises in the organisation. Human skill is needed at every level. Later teachers have kept this pattern in many books. It is the pattern that this chapter has used. The article appeared in volume 33, issue 1, of the journal, on pages 33 to 42. Its importance lies in its plain claim: a manager's success depends on what the manager can do, and what a manager can do can be taught.

## Review Questions

> Four questions return to the main ideas of the chapter.

:q 2.1 | Place each job at a level: the head of a bank's whole network of branches; the manager of the loans department of one branch; the supervisor of the cashiers at the counter.
:q 2.2 | Explain why a top manager needs more conceptual skill than a first-line manager.
:q 2.3 | Name the four kinds of resource that a manager handles, and give a short example of each from a bookshop.
:q 2.4 | Explain the difference between a functional manager and a general manager, with one example of each.
