:chapter XIV | Authority, Delegation and Coordination
:mood Why does one person obey an order, and another only a request?
:desc This chapter explains how the right to direct work moves through an organisation. It separates authority from power, shows the three kinds of authority, and teaches how a manager delegates a task, how decisions are spread or kept at the top, and how coordination holds separate work together. A small bookshop and a Brazilian factory serve as cases.
:plate ch14-plate.svg | A general hands a sealed order to a messenger

> You will need: Chapter 12, 'Organizing and Types of Organization', section 12.1 'What Organizing Is'; Chapter 13, 'Structure: Span, Departments and Forces', section 13.1 'Span of Management'.
> A sealed order raises the question of why anyone obeys it.

A general sits in his tent before dawn. He writes an order, seals it and hands it to a young messenger. The messenger bows and rides into the dark. Later that day, a thousand soldiers will move because of the paper in his pocket. None of them has met the general, and none of them has seen the paper. Why do they obey?

> Two different reasons for obeying are easy to confuse.

Perhaps they obey because they fear the general. Perhaps they obey because they respect him, or because the order comes from the office he holds. These are different reasons, and the difference matters. A soldier who obeys out of respect would stop obeying if the respect faded. A soldier who obeys the office would obey whoever held it.

> The same puzzle appears in a bookshop on an ordinary morning.

The same puzzle appears in a bookshop. A store manager asks the cashier to count the till at six o'clock, and the cashier does it. A friendly colleague asks the cashier for a favour, and the cashier does that too. Both requests succeed, yet the reasons are not the same. One request rests on the manager's position. The other rests on liking and trust.

> The chapter has five parts and then applies them to one shop.

This chapter separates these reasons and gives each a name. It shows how the right to direct work is shared among managers, advisers and specialists. It explains how a manager hands a task to another person, how much decision-making stays at the top, and how an organisation keeps separate work moving toward one goal. We follow a Dhaka bookshop and, at the end, a Brazilian factory that went further than most.

* * *

## 14.1 Authority and Power

@! Go slowly here.
> Authority and power are easily confused, so we take them one at a time.

Many students find these two words confusing, because in daily speech they mean nearly the same thing. In management they are different ideas, and a mix-up leads to wrong conclusions. We take authority first, then power, then compare them. Go slowly, and use the examples to test each idea.

> A traffic officer's raised hand stops cars because of the position, not the person.

Begin with a street in Dhaka. A traffic officer in uniform raises one hand, and the cars stop. The officer is not stronger than the drivers, and the drivers may not know the officer's name. The cars stop because of the officer's position. The uniform shows that the position exists, and the law supports it.

> Recall: Chapter 12, 'Organizing and Types of Organization', section 12.1 'What Organizing Is' — organizing.
> Authority is a right that comes with a position and not with the person.
@ Authority | The right to give orders and to expect them to be obeyed, given by position.
@ Authority | Word in use. In daily life, an expert source ("an authority on history") or an official body ("the tax authority"). In management, the right of a position to direct the work of others.

The traffic officer's right has a name. **Authority** means the right to give orders and to expect them to be obeyed, given by position. When a store manager tells a cashier to count the till, the manager uses authority. The shop owner gave the position its authority, and the cashier accepts that it belongs to the position. Chapter 12 showed that organizing creates positions. Authority is what makes a position able to direct other positions.

> Authority can be small or large, but it always belongs to a post.

Authority has a size. A store manager has more authority than a sales assistant, and an owner has more than a store manager. It has a source, which is the organisation. It also has a limit: a store manager may direct the shop's work but may not order a customer to buy. Authority reaches only as far as the organisation has given it.

> The test of authority is whether it would pass to a new holder of the post.

Here is a simple test. If the manager leaves and a new manager is appointed, who holds the authority? The new manager does. Authority stays with the post and passes to each new holder. This is why we say it is given by position.

> Power is a different idea: the ability to influence, with or without a position.
@ Power | The ability to influence other people's behaviour, whether or not one holds a position.
@ Power | Word in use. In daily life, physical strength, or electricity ("a power cut"). In management, the ability to influence what other people do.

Now consider the friendly colleague. The colleague holds no higher position than the cashier, yet the cashier does the favour. **Power** means the ability to influence other people's behaviour, whether or not one holds a position. The colleague has power because the cashier likes and trusts the colleague. If the colleague moved to another shop, the power would move too, since it belongs to the person.

> Power has several sources that managers can name.

Where does power come from? Writers on management name five common sources. The first is position, which is authority itself. The second is the ability to give rewards, such as a bonus or a better shift. The third is the ability to punish, such as a warning. The fourth is knowledge and skill: an employee who knows the stock system better than anyone else is listened to. The fifth is personal liking and respect. Chapter 17, 'Leadership', section 17.1 'Leader and Manager', studies the power of leaders in more detail.

> The two ideas are compared in a table with four questions.

The table below compares authority and power. Read each row from the left. The first cell gives a question, the second answers it for authority, and the third answers it for power.

:table Authority compared with power
| Question | Authority | Power |
| Where does it come from? | The position, given by the organisation | Knowledge, rewards, punishment, liking or position |
| Who holds it? | Whoever holds the post | A person, with or without a post |
| What happens when the holder leaves? | It stays with the post | It leaves with the person |
| Example | A manager orders a till count | A trusted colleague asks for a favour |

> A manager usually has both, and the two can work apart.

A manager may hold both, and the strongest managers do. A manager may also hold one without the other. A newly appointed manager has full authority and may have little power, because the employees do not yet know or trust the new person. A senior employee may have much power and no authority. Employees often follow such a person, and a wise manager notices it.

> Authority works only when the people below accept it.

Authority has a limit that is easy to miss. A right to give orders means little if the orders are not obeyed. In practice, authority works when employees accept it as proper. A manager who uses it fairly, and who adds knowledge and respect to the post, finds that the authority is accepted more easily.

:pause 14.p1 | A new store manager is appointed. On day one, an employee who has worked in the shop for ten years advises the other employees to ignore a new rule, and they do. Who holds authority, and who holds power?

> The recap of section 14.1.

*Before moving on.* Authority is the right to give orders and expect them to be obeyed, and it belongs to the position. Power is the ability to influence others, and it belongs to the person. A manager may have both, or one without the other. Authority works best when the people below accept it.

> A sentence to test the reader's grasp of the section.
*You should now be able to say:* authority comes from the position and stays when the holder leaves, and power comes from the person and leaves with the person.

* * *

## 14.2 Line, Staff and Functional Authority

> A concrete picture of a shop shows why one kind of authority is not enough.

Picture a small shop with an owner, a store manager and a few employees. The owner cannot watch every employee, so the store manager does it. The owner also needs someone to advise on money, and that adviser does not run the shop floor. A second kind of authority is therefore needed. Management names three kinds, and we take them in order.

> Line authority runs down the chain of command from the owner to each employee.
@ Line authority | The right of a manager to direct the work of employees in the chain of command.

The first kind is **line authority**, which means the right of a manager to direct the work of employees in the chain of command. The chain of command is the line of positions from the top of the organisation to the bottom, along which orders travel. In a bookshop, the store manager directs the sales assistants, and an assistant answers to the store manager. Some books call these people subordinates, and this book calls them employees. Line authority is the backbone of every organisation.

> Staff authority is the right to advise, not to command the line's employees.
@ Staff authority | The right to advise and support line managers, without commanding their employees.

The second kind is **staff authority**, which means the right to advise and support line managers, without commanding their employees. A staff person is a specialist who helps the line managers. Think of an adviser on money or law. The adviser studies a problem, gives an opinion and may be consulted before a decision. The line manager still decides, and the adviser's opinion carries weight only through its quality.

> The case file gives one example of staff authority in the shop.
:case Case file, illustrative. Delegation from 1 March 2026, Meghna and Sons: Tariq holds staff authority. He advises on cash and credit.

> Tariq's advice shows staff authority at work.
The case file shows the idea. Tariq is responsible for accounts and online orders, and he advises on cash and credit. He may tell the store manager that a school's unpaid bill is large and that further credit is risky. He does not order the sales assistants to refuse the school. The line manager hears the advice and decides.

> Functional authority is a narrow right to direct others in one specialised subject.

A third kind sits between the first two. We may call it functional authority. It means the right of a staff specialist to direct other people's work, but only in one specialised subject. For example, a specialist in safety may order every department to lock the storeroom each night. The specialist commands in that one subject and in no other. Functional authority is used where a rule must be the same across the organisation.

> The figure shows the three kinds of authority as three kinds of line.

:fig Line, staff and functional authority | ch14-fig01.svg

> The figure is read from the owner at the top, with the line types in a key below.

Read the figure from the owner at the top downwards. The thick lines carry line authority down the chain of command. The dashed line carries staff authority, which is advice only, and it reaches the line manager but not the employees below. The thin line carries functional authority, which is a right to direct in one subject. The key at the bottom repeats these meanings in words, so the figure reads the same in grey.

> The three kinds cause trouble when they are not kept apart.

The three kinds can cause trouble. A staff person who begins to give orders to employees weakens the line manager, and the employee does not know whom to obey. An employee who receives two different orders is in a hard position. The remedy is to say plainly which kind of authority each person holds and in which matters. Where authority is stated in writing, such conflicts are fewer.

> The recap of section 14.2.

*Before moving on.* Line authority is the right to direct employees along the chain of command. Staff authority is the right to advise and support line managers without commanding their employees. Functional authority is a staff specialist's right to direct others in one subject only. In the case file, Tariq holds staff authority.

> A sentence to test the reader's grasp of the section.
*You should now be able to say:* line authority commands, staff authority advises, and functional authority commands in one subject only.

* * *

## 14.3 Delegation

@! Go slowly here.
> A manager cannot do all the work personally, so tasks must be handed on.

Suppose Nurul, the owner of a bookshop, personally approved every return and every purchase. Each task would wait for Nurul to be free, and customers and suppliers would wait too. A manager has a limit on time and attention. Some tasks must therefore be handed to others, and the handing must be done with care.

> Delegation hands a stated task to an employee together with the right to act.
@ Delegation | Giving an employee the right to make decisions and take action for a stated task.

The word for this is **delegation**, which means giving an employee the right to make decisions and take action for a stated task. The phrase *stated task* is important. Nurul does not hand over the whole shop. Nurul hands over one named piece of work, with limits. Delegation also does not mean abandoning the task, since the manager must still check how it goes.

> The case file shows two delegated tasks, each with a money limit.
:case Case file, illustrative. Delegation from 1 March 2026, Meghna and Sons: Rafiq may approve returns up to Tk 5,000, above that Nurul. Tariq may place purchase orders up to Tk 50,000.

> Two delegated tasks each carry a money limit.
The case file shows delegation in two forms. The task for Rafiq is approving returns, and the limit is Tk 5,000; above that, Nurul decides. The task for Tariq is placing purchase orders, and the limit is Tk 50,000. A limit in money keeps the manager's risk small, and it tells everyone where the right to decide ends.

> Managers often fail to delegate, and the reasons are common.

Many managers find delegation hard. Some fear that the employee will make mistakes. Some believe they do the work better themselves. Some fear losing control or being needed less. Employees can also resist, because they fear blame or lack the skill. The cure is to match the task to the person, to state the limits plainly and to accept that early mistakes are part of learning.

> Responsibility, authority and accountability must be kept in balance.
@ Accountability | The duty to explain and answer for results to the person who delegated the work.

Three ideas go together in delegation. Responsibility is the duty to do the task. Authority, as we saw, is the right to act so that the task can be done. **Accountability** means the duty to explain and answer for results to the person who delegated the work. Rafiq has the responsibility to handle returns, the authority to approve them up to Tk 5,000, and accountability to Nurul for how well he does it. If a person is given a duty without the matching authority, the task cannot be done.

> A manager who delegates stays answerable to the person above.

One point surprises many students. A manager may hand over the task and the authority to do it. The manager still answers to the person above for the final result. Nurul, as owner, remains answerable for the shop as a whole. In this way delegation spreads the work but does not remove the answer owed to the owner or to the customer.

:fig Authority, responsibility and accountability triangle | ch14-fig02.svg

> The triangle is read corner by corner, with the centre giving the rule.

Read the triangle one corner at a time. Authority is the right to act, responsibility is the duty to do the task, and accountability is the duty to answer for the result. The sides join the corners because each depends on the others. The words in the centre give the rule: keep the three in balance.

:pause 14.p2 | Rafiq is given the duty to approve returns but is told that every return must first be approved by Nurul. Which of the three ideas is missing, and what will happen to the task?

> The recap of section 14.3.

*Before moving on.* Delegation is giving an employee the right to make decisions and take action for a stated task. Accountability is the duty to explain and answer for results to the person who delegated the work. Responsibility, authority and accountability must be kept in balance. A manager who delegates still answers upward for the final result.

> A sentence to test the reader's grasp of the section.
*You should now be able to say:* delegation hands over a stated task and the right to act, and accountability stays with the person who must answer for the result.

* * *

## 14.4 Centralization and Decentralization

> Every organisation must decide how many decisions to keep at the top.

Delegation raises a larger question. Across the whole organisation, how many decisions should the top keep, and how many should it hand down? The answer is a matter of degree, and it ranges from almost all at the top to almost none.

> Centralization keeps most decision-making power at the top.
@ Centralization | Keeping most decision-making power at the top of the organisation.

**Centralization** means keeping most decision-making power at the top of the organisation. In a very centralized shop, the owner approves every return and every order. The opposite is decentralization, which means spreading decision-making power to lower levels. It is the sum of many acts of delegation. The two ideas mark the ends of a line, and real organisations sit between them.

> Which to choose depends on size, skill, speed and the cost of mistakes.

Which should an organisation choose? Several things point the way. A large organisation cannot decide everything at the top and tends to spread decisions downward. Skilled and trusted employees make decentralization safer. Where speed matters, a decision made close to the customer is faster. Where a mistake is very costly, or where all parts must act in the same way, the top may wish to keep control. Tall structures, with many levels, slow decisions that must climb to the top.

> The recap of section 14.4.

*Before moving on.* Centralization keeps most decision-making power at the top, and decentralization spreads it downward. Neither is always best. Size, skill, speed and the cost of mistakes guide the choice.

* * *

## 14.5 Coordination

> When work is divided among many people, something must join it again.

Division of work brings a problem. When a task is split among departments, each does its part, and the parts must still fit together. A shop whose buyer orders books the sales assistants cannot sell, or whose sales assistants promise books that the stock clerk has not received, is a shop whose parts do not fit.

> Coordination links the work of separate people toward one goal.
@ Coordination | Linking the work of different people and departments so that they pull toward the same goal.

The remedy is **coordination**, which means linking the work of different people and departments so that they pull toward the same goal. Coordination is not a separate task done once. It is a quality that good management gives to all the other tasks. The need grows with the number of people, since each added person adds more links to keep in order.

> Basic activities and structural techniques both help coordinate.

Two groups of methods help. The basic activities are shared goals that everyone understands, regular communication, and plans that show who does what and when. The structural techniques are built into the organisation: the chain of command, rules and procedures, a liaison person who passes news between departments, and committees or meetings that bring people together.

> The case file's weekly meeting is a structural coordination technique.
:case Case file, illustrative. Delegation from 1 March 2026, Meghna and Sons: a weekly meeting each Sunday at 9:00 for 30 minutes.

> A weekly meeting is the shop's coordination technique.
The case file records one technique. A weekly meeting each Sunday at 9:00 lasts 30 minutes. If it is held every week for a year, the time is 52 × 30 = 1,560 minutes, or 26 hours. The case file does not list who attends. The cost is small, and the meeting lets the store manager, the accounts adviser and others share news before the week begins.

> The recap of section 14.5.

*Before moving on.* Coordination links the work of different people and departments so that they pull toward the same goal. Basic activities include shared goals, communication and plans. Structural techniques include the chain of command, rules, liaison persons and meetings. The weekly meeting in the case file is one example.

* * *

## Worked Case: Who May Decide?

> The worked case applies authority, delegation and accountability to the shop's limits.

We now apply the chapter to the decisions in the case file. The worked case has five parts: Situation, Question, Reasoning, Conclusion and Check. It applies the ideas to a situation. It is an application, not a model answer.

> The situation lists the limits set from 1 March 2026.
:case Case file, illustrative. Delegation from 1 March 2026, Meghna and Sons: Rafiq may approve returns up to Tk 5,000, above that Nurul; Tariq may place purchase orders up to Tk 50,000; weekly meeting each Sunday at 9:00 for 30 minutes. Tariq holds staff authority and advises on cash and credit.

> The question asks who may decide in four small situations.

*Question.* Suppose four things happen in one week: a return of Tk 4,800; a return of Tk 6,500; a purchase order of Tk 45,000; and a request for credit from a school. Who may decide each one, and what does each decision show about authority?

> The first test compares each amount with the limit that was delegated.

*Reasoning, part 1: returns.* The limit for Rafiq is Tk 5,000. The first return is Tk 4,800, and 4,800 is less than 5,000, so Rafiq may approve it. The second return is Tk 6,500, and 6,500 is more than 5,000, so it goes to Nurul. The words "up to Tk 5,000" mean that a return of exactly Tk 5,000 is also within Rafiq's right.

> The second test applies the same method to the purchase order.

*Reasoning, part 2: the order.* The limit for Tariq is Tk 50,000. The order is Tk 45,000, and 45,000 is less than 50,000. Tariq may place it. A further order of Tk 62,000 would exceed the limit by 62,000 − 50,000 = Tk 12,000. The case file does not say who approves above the limit, so the shop should write this down. In an owner-managed shop, the owner is the natural choice, but the file does not state it.

> The third test applies staff authority to the credit request.

*Reasoning, part 3: the credit request.* Tariq holds staff authority and advises on cash and credit. He may tell the store manager how large the school's unpaid bill is and whether credit is wise. He may not order the sales assistants to refuse. The line decision stays with the line manager, and Tariq's advice informs it.

> The fourth test names who answers for each result.

*Reasoning, part 4: accountability.* Rafiq answers to Nurul for the returns he approves, because Nurul delegated that right. Tariq answers to Nurul for the orders he places. Nurul remains answerable to the shop's owners and customers for the whole. The Sunday meeting gives each person a place to explain results and to coordinate.

> The conclusion and the check agree with the limits in the case file.

*Conclusion.* Rafiq decides the return of Tk 4,800, Nurul decides the return of Tk 6,500, and Tariq may place the order of Tk 45,000. Tariq advises on the credit request, and the line manager decides. *Check.* Each amount was compared with its limit, and each limit matches the case file. No person was given a task without the matching right to act.

### Changing the Situation

> Rung 2 reshapes the case by changing the amount.

The same ideas apply in new situations. Rung 1 is the case above. In rung 2, suppose a return is worth exactly Tk 5,000 and Rafiq is absent. Rafiq's right does not pass to anyone else, so the return waits for him, or goes to Nurul. This shows that authority belongs to the post and to its holder, and it does not pass without a decision.

> Rung 3 moves the idea to a new setting.

In rung 3, a school head delegates the booking of class visits to a teacher, with a limit of 20,000 taka for each visit. The teacher has the task, the right to book up to the limit, and the duty to report to the head. The three parts match, and the head still answers to the school's governors.

> Rung 4 combines delegation with the ideas of the span of management and coordination.

In rung 4, an owner has 12 employees and delegates to three team leaders. Chapter 13 explained that the span of management is the number of employees a manager can direct well. With three leaders, each has a span of four employees, which is easy to manage. The owner holds a weekly meeting of the leaders to coordinate the three teams.

* * *

## Summary

> A short summary of the chapter's eight defined terms.

Authority is the right to give orders and to expect them to be obeyed, given by position. Power is the ability to influence others, with or without a position. Line authority directs work along the chain of command, and staff authority advises without commanding. Delegation gives an employee the right to decide and act for a stated task, and accountability is the duty to answer for results to the person who delegated. Centralization keeps decisions at the top, and coordination links separate work toward one goal.

## Think It Through

:q 14.t1 | Rafiq is away on a day when a customer returns books worth Tk 5,400. Explain who may approve the return under the case file, what Rafiq's authority does and does not cover, and one way Nurul could change the arrangement so that returns do not wait.

:q 14.t2 | Tariq has been advising Nurul to refuse credit to a school. A sales assistant says Tariq has told her to refuse the order herself. Which kind of authority has Tariq used, and is it within his right? Explain your reasoning.

## Where People Go Wrong

> Mistake one: believing that authority and power are the same.

*Mistake: "Authority and power are the same thing."* Authority comes from a position and stays with the post. Power comes from the person and leaves with the person. A manager may have one without the other.

> Mistake two: believing that delegating gives away accountability.

*Mistake: "If I delegate, the result is no longer my concern."* The employee is accountable to the manager who delegated. The manager still answers to the person above for the final result.

> Mistake three: believing that staff authority is the right to give orders.

*Mistake: "A staff specialist can order the line's employees."* Staff authority is the right to advise. A specialist who commands in one subject holds functional authority, which is a different and narrower right.

> Mistake four: believing that decentralization means no control.

*Mistake: "Decentralization means anyone may decide anything."* Decentralization spreads decisions with limits, as the money limits in the case file show. Control remains through limits, reports and meetings.

> Mistake five: treating coordination as one meeting.

*Mistake: "Coordination means holding a meeting."* A meeting is one structural technique. Shared goals, communication, plans, rules and the chain of command also coordinate.

## In History

> Ricardo Semler's changes at Semco show decentralization pushed far.

In the early 1980s, Ricardo Semler took over Semco, a Brazilian manufacturer of marine pumps and other industrial equipment, which had been founded by his father. Semco was in difficulty, and Semler changed how it was run. He gave workers wide rights to decide. Factory workers set their own production schedules and working hours, and elected committees took part in decisions. Some staff set their own pay, and the company shared its financial figures with employees.

> The case is famous, and it shows both the gain and the demands of the approach.

Semler described these changes in a book, *Maverick*, published in 1993. The case became well known as an example of decentralization carried unusually far. It shows that spreading decisions can work when employees are trusted and well informed. It also shows how much the approach demands: information must be shared, limits must be understood, and managers must accept giving up control.

## Review Questions

:q 14.1 | Define authority and power in your own words, and state one difference between them.

:q 14.2 | Sort each example as line authority, staff authority or functional authority: (a) a store manager tells a sales assistant to restock a shelf; (b) an accounts adviser tells the store manager that a customer's credit is too high; (c) a safety specialist orders every department to lock its storeroom at night.

:q 14.3 | Define delegation and name the three ideas that must be kept in balance when a task is delegated.

:q 14.4 | Explain why accountability cannot be delegated away, using the shop's returns as an example.

:q 14.5 | Name two reasons why a manager may fail to delegate, and give one remedy for each.

:q 14.6 | Define centralization, and name two conditions that favour decentralization.

:q 14.7 | Define coordination. Name two basic activities and two structural techniques that support it.

:read Ricardo Semler, Maverick: The Success Story Behind the World's Most Unusual Workplace, 1993
:read Henri Fayol, General and Industrial Management, 1916
