:chapter VII | Planning: Meaning, Nature and Steps
:mood How does a wish turn into something you can actually do?
:desc This chapter explains what planning is and why every organisation needs it. You will learn the five steps that turn a wish into a workable plan, and you will study the reasons why plans fail. The ideas are built slowly, from a household journey to the order book of a shop.
:plate ch07-plate.svg | An architect at his drawing board, with plans, compasses and a model bridge

:box YOU WILL NEED
This chapter builds on two earlier ideas. The first is the list of activities that every manager performs, in Chapter 3 'The Functions of Management and How Management Is Judged', section 3.1 'The Management Process'. The second is how output is compared with the resources used, in Chapter 3 'The Functions of Management and How Management Is Judged', section 3.2 'Productivity'.

> A family must reach a wedding in another city before the ceremony starts.

@! Go slowly here.

Imagine that a family has been invited to a wedding in a city 300 kilometres away. The ceremony starts at noon on Saturday. Nobody has decided how to travel, what to carry, or when to leave. On Friday evening, one person says, "We will manage somehow." Is that sentence enough? Think about the questions that remain. Which road? Which vehicle? Who pays for fuel? What happens if the road is closed by rain? Each question has an answer, but the family has not found the answers yet.

> Wanting to arrive is not the same as knowing how to arrive.

@ Plan | Word in use. In daily life, an intention, as in "I plan to rest." In management, a statement of what will be done, by whom and by when.

The family wants one thing, which is to arrive on time. Wanting is the easy part. The difficult part is deciding, before the journey begins, what will be done and in what order. A family that sits down on Wednesday, chooses the road, counts the hours, and agrees who will drive has made a plan. A family that waits until Saturday morning has only a wish.

> A shop faces the same puzzle on a larger scale, with money and deadlines.

Now move from a family to a shop. A bookshop must order thousands of textbooks weeks before the school season opens. If the owner waits until the shelves are empty, the books will arrive too late, and customers will buy elsewhere. If the owner orders too many, money is locked in books that do not sell. The puzzle is the same as the family's, but the cost of a wrong answer is greater. This chapter answers a simple question that has no simple answer: how does a manager decide, in advance, what to do?

> Answering that question is the work of planning, which this chapter teaches.

We shall build the answer in layers. First we define planning and see what it does. Then we learn five steps that take a manager from a wish to a decision. Last we study why plans fail, because a plan that fails teaches as much as one that works. Many students find this chapter slow, because the ideas feel obvious after they are explained. They are not obvious before. Take your time.

* * *

## 7.1 What Planning Is

### Planning Defined

> A plan states what will be done, by whom and by when.

@ Plan | A written or spoken statement of what will be done, by whom and by when, to reach an objective.

Begin with the plan itself, because planning is the act of making one. A **plan** is a written or spoken statement of what will be done, by whom and by when, to reach an objective. Here an objective means a result that has been chosen as the target.^1 A family's list of "leave at six, driver is Rahim, fuel bought on Thursday" is a plan. It names the action, the person and the time.

^1: A full account of objectives is given in Chapter 9 'Objectives and Management by Objectives', section 9.1 'Objectives'. Until then, read objective as the result that you have chosen to reach.

> Planning is the management activity that decides the plan before action begins.

Now we can describe planning. Planning is the activity of deciding in advance what to do, how to do it, and who will do it. It is the first of the activities in the management process.^2 Planning comes first because the other activities depend on it. An organisation cannot arrange its people, direct their work or check results until it knows what it wants to achieve.

^2: The management process is set out in Chapter 3 'The Functions of Management and How Management Is Judged', section 3.1 'The Management Process'.

> You should now be able to say what a plan contains.

*Recap.* A plan states what will be done, by whom and by when. Planning is the activity of deciding this in advance. You should now be able to say: "A plan names the action, the person and the time."

### The Case of the Textbook Season

> Meghna and Sons must choose an order size long before the season opens.

@! Go slowly here.

Let us test the idea on a real record. The shop's textbook season is the busiest time of the year. Nurul Meghna, the owner-manager, cannot wait until customers arrive, because the supplier needs time to deliver. The case file below records the first facts of the season.

> The case file gives the season date, the order deadline and the expected order.

:case Case file, illustrative. Planning for the textbook season: the season starts 2 January 2026. The order deadline is 12 December 2025. The expected demand is 1,800 textbook sets at an average of Tk 2,400 each, which is Tk 4,320,000.

> Multiplying the expected sets by the average price gives the value of the order.

Read the record slowly. The deadline of 12 December comes before the season start of 2 January, so the shop must decide first and sell later. The value of the order comes from one multiplication: 1,800 sets × Tk 2,400 = Tk 4,320,000. This sum is large for a family shop. A wrong plan would cost real money, and this is why the shop plans before it acts.

> You should now be able to say why the shop must plan before the season.

*Recap.* The shop orders on 12 December and sells from 2 January. Between those dates it must trust its plan. You should now be able to say: "Planning is needed because action and result are separated by time."

### The Nature of Planning

> Planning has five features that describe it wherever it is found.

@! Go slowly here.

What features does planning have in every organisation, from a shop to a government? Five are worth learning, and the table sets them side by side. Read it row by row: the left column names a feature, and the right column says what it means.

:table The nature of planning
| Feature | What it means |
| Planning looks forward | It concerns the future, and the future is not known |
| Planning is for a purpose | It aims at an objective, and without an objective there is nothing to plan |
| Planning chooses | It selects one course of action and leaves the others |
| Planning is needed at every level | The owner, the manager and the employee all make plans of different size |
| Planning is continuous | Plans are reviewed and renewed as conditions change |

> The five features show that planning is forward-looking, purposeful, choosing, shared and continuous.

Take the second and third features. Planning is for a purpose, because a plan is a tool for reaching an objective. Planning chooses, because the family cannot take two roads at once. These features also explain a common confusion. Planning is not a guess about the future, and it is not a promise that the future will match the plan. It is a reasoned decision, taken now, about what to do.

> Each level of an organisation plans a different size of task.

Consider the viewpoints in the shop. The owner plans the year: how many copies to order and how much to spend. The store manager plans the week: who works at the counter and who unpacks cartons. An employee plans the hour: which shelf to fill first. The plans are different in size, but each one answers the same three questions of action, person and time.

> You should now be able to name the five features.

*Recap.* Planning looks forward, serves a purpose, chooses, happens at every level and never ends. You should now be able to say: "Planning is a reasoned decision about the future, taken in advance."

### The Purposes of Planning

> Planning serves several purposes, from reducing guesswork to making control possible.

@! Go slowly here.

Why plan at all? The family could drive and see what happens. Four purposes answer the question. First, planning reduces uncertainty, because it makes the manager look at the future before it arrives. Second, planning gives direction: every employee knows the aim and the part each person plays. Third, planning saves effort, because it removes wasted work and repeated decisions. Fourth, planning makes control possible, because a manager can check results only against something that was planned.

> Planning improves productivity and effectiveness by directing effort to the aim.

These purposes connect to two ideas from Chapter 3. Planning raises productivity, which compares output with the resources used.^3 It also raises effectiveness, which asks whether the right aim was reached. A shop that orders the correct number of books wastes less money, so it is more productive. It also meets its customers' needs, so it is more effective.

^3: Measures of performance are explained in Chapter 3 'The Functions of Management and How Management Is Judged', section 3.2 'Productivity'.

> Planning has limits, and the last section of this chapter returns to them.

Planning has its limits too, and an honest account must say so. It costs time and money. It can make an organisation rigid if the plan is followed after conditions have changed. These limits do not remove the value of planning. They warn the manager to plan with care, and section 7.3 examines them.

> You should now be able to list the purposes of planning.

*Recap.* Planning reduces uncertainty, gives direction, saves effort and makes control possible. You should now be able to say: "Without a plan there is nothing to check results against."

:pause 7.p1 | Think of a task you did recently without a plan. What would the plan have contained: the action, the person and the time?

> Section 7.1 in three lines.

*Before moving on.* A plan states what will be done, by whom and by when. Planning is the advance decision that produces it, and it is forward-looking, purposeful, choosing, shared and continuous. Its purposes are less uncertainty, direction, saved effort and the possibility of control.

* * *

## 7.2 Steps in Planning

> Planning follows five steps in order, and each step needs the one before it.

Is there a method for planning, or does each manager invent one? Managers have found that good plans usually pass through five steps in the same order. The ladder below shows them. Read it from the bottom rung to the top: each rung is one step, and a manager climbs one rung before reaching the next. Missing a rung is like missing a stair in the dark; the next step becomes unsafe.

:fig The five steps of planning as a ladder | ch07-fig01.svg

### Step One: Awareness of Opportunity

> The first step is to notice a chance or a problem before others do.

@! Go slowly here.

Planning begins before any plan exists. It begins when a manager notices something: a chance to gain, or a problem to remove. We call this awareness of opportunity. The family in our opening puzzle noticed that a wedding invitation had arrived. The shop notices that the textbook season is approaching. Awareness asks the manager to look at the organisation, at its customers and at the world outside, and to ask what could be done better.

> Awareness is a habit of looking, and it prepares the ground for the next step.

An everyday bridge helps. A person who sees that a bus fare has risen thinks of cycling to work. The rise in fare is the signal, and the thought of cycling is the opportunity. Notice that no decision is made at this stage. Awareness only identifies a possibility. It fails when a manager is too busy to look up from daily tasks, and then an opportunity passes unseen.

> You should now be able to say what awareness of opportunity is.

*Recap.* The first step is noticing a chance or problem. You should now be able to say: "Planning starts with seeing something worth acting on."

### Step Two: Setting Objectives

> The second step is to decide exactly what result is wanted, and by when.

Once an opportunity is seen, the manager decides what result to aim for. This is setting objectives. The aim must be stated so exactly that everyone can tell whether it was reached. "Do well in the season" is a wish. "Order 1,800 textbook sets by 12 December" is an objective. Chapter 9 explains objectives in full; for now, remember that a plan cannot be built without one.

> A clear objective tells every person where the effort is going.

Think of the viewpoints. The owner wants a profitable season. The store manager wants every shelf ready on the first day. The customer wants the right book, in stock, at a fair price. A good objective brings these viewpoints together in one sentence that all can read. When the objective is vague, each person fills the gap with a personal guess, and the guesses disagree.

> You should now be able to say why the second step comes second.

*Recap.* The second step states the result wanted, exactly and with a date. You should now be able to say: "An objective is stated so exactly that anyone can tell whether it was reached."

### Step Three: Planning Premises

> The third step is to state what the manager assumes about the future.

@! Go slowly here.

The manager now knows the objective, but the plan will run in the future, and nobody knows the future. What should the manager do? The manager states, in plain words, what is assumed about it. We call each such statement a planning premise. A family might assume that the road will be open and that fuel prices will stay the same. These assumptions are the ground on which the plan is built.

> A planning premise is an assumption about future conditions on which a plan is built.

@ Premise | Word in use. In daily life, a building and its land, as in "the shop premises". In planning, an assumption stated at the start of an argument or a plan.

@ Planning premise | An assumption about future conditions on which a plan is built.

A **planning premise** is an assumption about future conditions on which a plan is built. Suppose a family assumes that it will rain on Saturday. That assumption changes the plan: umbrellas are packed and extra time is allowed. If the assumption is wrong and the day is dry, little harm is done. If the assumption is the opposite, and the family expects sun in a monsoon, the plan fails on the road.

> Premises are a choice of which assumptions matter, so a manager picks the few that count most.

The manager cannot list every possible condition, so the manager picks the few assumptions that would change the plan most. Of all the things that might change, a shop owner asks which ones would make the order too large or too small. Prices, customer numbers and delivery time usually matter most. Choose the few important assumptions and write them down, so that everyone who uses the plan shares them.

> A forecast is a reasoned estimate of what will happen, used as a base for a plan.

@ Forecast | A reasoned estimate of what will happen in the future, used as a base for a plan.

One of the best sources of premises is a **forecast**. A forecast is a reasoned estimate of what will happen in the future, used as a base for a plan. For example, a shop may estimate next season's sales from the sales of the last three seasons. The word "reasoned" matters: a forecast rests on evidence such as past records, and it is more than a hope. Even so, a forecast can be wrong, and a careful manager reviews the forecast when facts change.

> The shop's case file records its main premise and its supplier lead time.

:case Case file, illustrative. Premise for the textbook season: publishers raise prices by 5%. Supplier lead time: 21 days.

> The lead time is the gap between ordering and receiving, and it fixes the deadline.

Read the record carefully. The lead time of 21 days is the gap between placing an order and receiving the books. Count 21 days from the order deadline of 12 December: December has 31 days, so 12 + 21 = 33, which is 2 January. The books ordered on the last day arrive on the first day of the season. This shows why a deadline must be set backward from the date when the result is needed.

> You should now be able to say what a planning premise is and why it is written down.

*Recap.* A planning premise is an assumption about future conditions on which a plan is built, and a forecast is a good source for one. You should now be able to say: "A premise is what we assume about the future, written down so that everyone shares it."

:pause 7.p2 | The shop's plan assumes that publishers raise prices by 5%. Say what would happen to the order value if publishers raised prices by 10% and the shop did not change its plan.

### Step Four: Listing and Weighing Alternatives

> The fourth step is to list the possible ways to reach the objective and compare them.

@! Go slowly here.

With the objective and premises written down, the manager asks how the objective can be reached. There is almost never one way. A family can drive, take a bus or hire a car. We call each possible course of action an alternative. Listing alternatives forces the manager to think beyond the first idea, which is often not the best.

> An alternative is one of several possible courses of action from which a choice is made.

@ Alternative | One of several possible courses of action from which a choice is made.

An **alternative** is one of several possible courses of action from which a choice is made. For example, a shop that must stock textbooks has three alternatives: order the full amount at once, order half now and half later, or order only what schools have promised to buy. Each alternative has costs and risks. Weighing them means comparing what each would cost, what it would earn, and how it would behave if a premise proved wrong.

> Weighing alternatives uses the premises as the standard of comparison.

Weighing is not done in the dark. The manager tests each alternative against the premises. If the premise says that publishers raise prices by 5%, an alternative that delays the order may cost more, because later orders might be priced higher. An alternative that looks cheap today may look poor under the premises. This is why the premises are written before the alternatives are weighed.

> You should now be able to say what an alternative is.

*Recap.* An alternative is one possible course of action. The manager lists several and weighs each against the premises. You should now be able to say: "A good plan chooses from several alternatives, not from one."

### Step Five: Choosing and Carrying Out

> The fifth step is to choose one alternative and put it into action.

The last step has two parts. First the manager chooses the alternative that best reaches the objective under the premises. A choice means giving up the others, and this is difficult, because each alternative has some attraction. Second, the manager carries the plan out. This means turning the choice into tasks: who does what, with what resources, by what date. A choice that is never carried out is no better than no choice.

> Carrying out needs people to understand the plan and to be given the means to act.

Many students find this step easy to skip, because it feels like action and not planning. In fact it belongs to planning, because the plan states who will do what and by when. If employees do not know the plan, they cannot follow it. The manager must communicate the plan and provide the money, time and tools to carry it out. Then the manager watches the results, and the control of those results is taught in Chapter 18.

> Planning is a loop, because results lead to new awareness.

After the plan is carried out, results appear. A good result confirms the premises; a poor result shows that a premise was wrong. Either way the manager sees something new, and this is the first step again: awareness. Planning therefore does not end. It circles back, which is why the fifth feature of planning, continuity, is true.

> Section 7.2 in four lines.

*Before moving on.* The five steps are awareness of opportunity, setting objectives, stating planning premises, listing and weighing alternatives, and choosing and carrying out. Each step needs the one before. Results lead back to awareness, so planning is a loop.

* * *

## 7.3 Why Plans Fail

> Many plans fail, and the causes are known and can be avoided.

Suppose a family makes a careful plan and still arrives late. Does this mean that planning is useless? No. A plan that fails is a lesson. The causes of failure repeat across organisations, and a manager who knows them can avoid most. Three causes appear again and again, and a fourth cause is the limit of planning itself.

> Wrong premises are the most common cause of failure.

The first cause is a wrong premise. If the plan assumes that the road is open and the road is closed, the plan fails however well it was made. A shop that assumes steady prices and meets a large price rise will find its order cost higher than planned. This is why premises are written down and checked: a wrong premise is hard to find when it is hidden.

> A plan fails when the objective is vague or people do not know it.

The second cause is a vague objective, or a plan that is not communicated. Employees cannot follow a plan that they have never seen. The third cause is lack of commitment: the plan is made, then ignored when daily work becomes busy, or no one is named to carry it out. A plan states who will do what, and when no person is named, no action follows.

> Plans can also fail from rigidity, cost and the difficulty of knowing the future.

Planning also has limits. The future cannot be known, so every forecast can be wrong. Planning takes time and money, and a very detailed plan may cost more than it saves. A plan that is followed too strictly stops a manager from using a new chance. The answer is not to stop planning but to plan in proportion: more detail where mistakes are costly, less detail where conditions change fast, and a regular review in every case.

> Section 7.3 in three lines.

*Before moving on.* Plans fail because of wrong premises, vague or unshared objectives, and lack of commitment. Planning has limits: the future is uncertain, it costs time and money, and it can become rigid. A manager reviews plans often.

* * *

## Worked Case: Checking the Textbook Plan

> This worked case tests the shop's plan against its premise.

This worked case follows the standard order for a descriptive chapter: Situation, Question, Reasoning, Conclusion and Check. It applies the five steps to the shop's record. It is a study of the idea and not a model answer.

> The situation collects the facts from the shop's case file.

*Situation.* The season starts on 2 January 2026. The order deadline is 12 December 2025. The shop expects to sell 1,800 textbook sets at an average of Tk 2,400, which is Tk 4,320,000. The premise is that publishers raise prices by 5%. The supplier lead time is 21 days.

> The question asks whether the budget still holds under the premise.

*Question.* If the premise is right, how much will the order cost, and does the deadline still allow the books to arrive on time?

> The reasoning finds the new price, the new order value and the arrival date.

*Reasoning.* First, find the new average price. Five per cent of Tk 2,400 is 2,400 × 5 ÷ 100 = Tk 120, so the new price is 2,400 + 120 = Tk 2,520. Second, find the new order value: 1,800 × Tk 2,520 = Tk 4,536,000. Third, find the increase: Tk 4,536,000 − Tk 4,320,000 = Tk 216,000. Fourth, check the date: 12 December plus 21 days is 2 January, so the books arrive on the day the season starts.

> The conclusion tells the manager what to prepare.

*Conclusion.* If the premise is right, the order costs Tk 4,536,000, which is Tk 216,000 more than the first estimate. The deadline allows the books to arrive on 2 January, with no spare days. A careful manager would raise the budget and consider ordering earlier.

> The check repeats the increase by a second route.

*Check.* Five per cent of Tk 4,320,000 is 4,320,000 × 5 ÷ 100 = Tk 216,000. This equals the increase found in the third step, so the two routes agree.

* * *

## Summary

> The chapter in a few lines.

Planning is deciding in advance what to do, by whom and by when. A plan states these things to reach an objective. Planning looks forward, serves a purpose, chooses, happens at every level and never ends. It follows five steps: awareness of opportunity, setting objectives, stating planning premises, listing and weighing alternatives, and choosing and carrying out. Plans fail through wrong premises, vague objectives and lack of commitment, and planning has limits of cost, uncertainty and rigidity.

## Think It Through

> Four questions that change the situation step by step.

The questions begin with the shop and move to new settings.

:q 7.t1 | The shop's season starts on 2 January 2026 and the supplier lead time is 21 days. By what date must the order be placed, and why?

:q 7.t2 | Suppose the shop built its plan on the premise that prices stay the same, but publishers raise prices by 5%. Show how much more the order costs, and say what the manager should have done.

:q 7.t3 | A family restaurant plans to open a second branch. Name the five steps of planning and give one question the owner should ask at each step.

:q 7.t4 | A school plans a sports day outdoors in the rainy season, and the plan assumes dry weather. List two alternatives the school could weigh and say how each handles the premise.

## Where People Go Wrong

> A plan is not a guarantee about the future.

Some students think that a plan promises what will happen. It does not. A plan is a decision about what to do, based on premises. When the premises change, the plan must change.

> Planning is not only for senior managers.

Some students think that only owners plan. In fact an employee who decides the order of tasks for the morning is planning too. The size of the plan changes with the level; the three questions of action, person and time stay the same.

> Skipping steps produces weak plans.

Some students jump from the first idea to action. The five steps exist because each one removes a kind of error. Without objectives the aim is unclear; without premises the future is ignored; without alternatives the choice is the first idea and not the best one.

> A written plan is not useful if nobody follows it.

Some students believe that writing the plan completes the work. A plan that is not carried out, and not reviewed, is only a document. Planning ends when results have been compared with the plan.

## In History

> A president set a goal and a national team built the plan to reach it.

On 25 May 1961, President John F. Kennedy told the United States Congress that the nation should commit itself to landing a person on the Moon and returning that person safely to Earth before the decade ended. At that time the country had sent a person into space for only a few minutes. The goal was bold, and it was stated with a date.

> Planning turned the goal into many steps carried out by many people.

A goal of this size cannot be reached by wishing. NASA, the space agency of the United States, had to study possible methods, estimate costs and time, build rockets and train astronauts. It listed and weighed different ways of reaching the Moon and chose the method of lunar-orbit rendezvous, in which a small landing craft leaves a larger spacecraft that stays in orbit. The work followed the same pattern that this chapter has described: an objective, premises, alternatives, a choice and then action.

> The plan succeeded when Apollo 11 landed on 20 July 1969.

Apollo 11 left Earth on 16 July 1969. On 20 July, astronauts Neil Armstrong and Buzz Aldrin landed on the Moon while Michael Collins remained in orbit, and the crew returned to Earth on 24 July. The goal set on 25 May 1961 had been reached, about eight years later and within the decade set in the speech.

## Review Questions

> Five questions that review the chapter.

:q 7.1 | Put the five steps of planning in order, and say in one sentence what happens at each.

:q 7.2 | Define a plan and a planning premise, and give one example of each from a shop.

:q 7.3 | What is the difference between a forecast and a planning premise?

:q 7.4 | Explain why the shop cannot wait until the shelves are empty before it decides on its order.

:q 7.5 | Name three reasons why plans fail, and say how a manager can reduce each one.

:read John M. Logsdon, The Decision to Go to the Moon, 1970
