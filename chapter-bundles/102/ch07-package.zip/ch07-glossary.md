:glossary 07
Plan | A written or spoken statement of what will be done, by whom and by when, to reach an objective. A plan names the action, the person and the time. Example: "Place the book order by 12 December; the manager will do it."
Planning premise | An assumption about future conditions on which a plan is built. The manager writes it down so that everyone shares it. Example: a shop assumes that publishers raise prices by 5%, and builds its order budget on that assumption.
Forecast | A reasoned estimate of what will happen in the future, used as a base for a plan. It rests on evidence such as past records. Example: estimating next season's sales from the sales of the last three seasons.
Alternative | One of several possible courses of action from which a choice is made. A manager lists alternatives and weighs each one before choosing. Example: order all the books at once, order half now and half later, or order only what schools have promised.
