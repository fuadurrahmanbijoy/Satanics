:answers 04
:a 4.p1 | Unity of command is broken, because the employee has two managers giving different orders. The shop should give each employee one manager, and let the two managers agree on the work before they speak to the employee.
:a 4.t1 | The first principle: replace rule-of-thumb methods with a science. The fixed shelf-position list replaced habit with one tested method, and the timing showed that it saved 5 minutes a carton.
:a 4.t2 | The saving per carton would be 14 - 11 = 3 minutes. For 10 cartons it is 3 x 10 = 30 minutes a day.
:a 4.t3 | A mixed answer fits best. The contingency approach suits a kitchen whose orders change each minute. It can borrow time and motion study for repeated tasks and the human relations school for team spirit in the rush.
:a 4.t4 | Timing every task can feel like constant watching, which weakens team spirit. A manager can explain the reason for the timing, share the saving with employees, and ask them to suggest better methods.
:a 4.1 | Taylor: one best method found by timing. Fayol: fourteen principles for the whole organisation. Weber: written rules and levels of authority. Mayo: group bonds affect output.
:a 4.2 | Replace rule of thumb with a science for each job; select, train and develop each employee; cooperate with employees so work follows the science; divide work and responsibility between managers and employees.
:a 4.3 | The contingency approach is the view that the best way to manage depends on the situation. Example: a fixed method suits unloading cartons, while a flexible style suits a team inventing a new service.
:a 4.4 | Structure and command (for example, unity of command); fairness and people (for example, equity); order and purpose (for example, discipline).
:a 4.5 | Strength: it solves problems that can be measured, such as how many copies to order. Limit: it cannot measure feelings or judgement.
