:chapter VI | Social Responsibility, Ethics and Sustainability
:mood What does an organisation owe to people it never invited to its table?
:desc This chapter asks what an organisation owes to society beyond its profit. It explains the duty of organisations to society, the moral rules that guide business choices, and the goal of leaving the world fit for later generations. A bookshop in Dhaka and a disaster at Savar serve as cases.
:plate ch06-plate.svg | A public meeting in a Victorian hall

> You will need: Chapter 5, 'The Environment of Organisations', section 5.1 'Inside and Outside the Organisation'; Chapter 1, 'What Management Is', section 1.4 'A Manager's Responsibility'.
> Imagine a cheap offer that no customer could detect, and ask whether you would accept it.

Imagine that you own a small shop. On Monday a supplier offers you goods at a price far below the usual one. The goods look the same as those you buy now. Your customers would not notice any difference, no inspector will visit, and your profit would rise. Do you accept the offer?

> The easy answer becomes hard once we ask who else is affected.

Many people answer at once, but the question is harder than it first appears. Who made these goods, and were those people paid fairly? Who would lose if you bought them? Is the low price lawful? If nobody ever discovers your choice, does it still matter? Each of these questions reaches people who never signed a contract with you.

> Every organisation lives among people whom it affects without asking them.

Every organisation meets this kind of question. It buys from some people, sells to others and employs others. It also uses air, water, roads and land that belong to everyone. Its choices travel far beyond its own door. A manager who reads only the price list sees a small part of the result.

> The chapter asks three questions and ends at a building in Savar.

This chapter asks three questions. First, what does an organisation owe to society? Second, how do we decide what is right and wrong when a choice is hard? Third, how can an organisation continue without using up what later generations will need? We shall meet a small bookshop in Dhaka that faces such a choice on 18 June 2026. We shall also visit Savar, near Dhaka, where in 2013 a disaster showed the cost of failing to ask.

* * *

## 6.1 Social Responsibility

> A family acts freely inside its flat but shares the stairs with its neighbours.

Begin with an everyday picture. A family lives in a block of flats. Inside its own door, the family decides what to cook, when to sleep and how loud to play music. The stairs, the roof and the water tank, however, are shared. A family that leaves rubbish on the stairs harms neighbours who never agreed to it. A good neighbour keeps the stairs clean without being forced to.

> Recall: Chapter 5, 'The Environment of Organisations', section 5.1 'Inside and Outside the Organisation' — external forces from society.
> An organisation lives in a larger block of flats, which is society.

An organisation lives in a much larger block of flats, which we call society. Chapter 5 showed that society is one of the outside forces that press on every organisation. This chapter turns the picture round. It asks what the organisation owes to society in return.

> The duty to act for society's good as well as for profit has a name.
@ Corporate social responsibility | An organisation's duty to act for the good of society as well as for profit.
@ Responsibility | Word in use. In daily life, a task or a person that you must look after. In management, a duty to answer for the results of one's decisions and actions.

The picture has a name in management. **Corporate social responsibility** means an organisation's duty to act for the good of society as well as for profit. A bookshop that refuses to sell stolen goods, pays its employees what it promised and sends its waste paper to recycling is acting on this duty. The word *corporate* once pointed to large companies. The duty, however, applies to every organisation, large or small, owned by the state or by a family.

> A small organisation records one act toward the natural environment.

:case Case file, illustrative. Record for 2025, Meghna and Sons, a family-run bookshop in Dhanmondi, Dhaka: 380 kg of unsold paper was sent to recycling. The record states the weight only. We use it as one small example of care for the natural environment, and section 6.3 returns to the idea.

> Each person affected sees the duty from a different place.

The same duty looks different from each position. The owner asks what it costs now and what trust it earns later. The manager asks how to reach the goals for profit while treating employees, customers and suppliers fairly. An employee sees the duty in wages, safety and respect. A customer sees it in honest prices and honest goods. A neighbour sees it in noise, waste and the state of the street. Each of these people can judge whether the duty is being met.

> Thinkers disagree about whether an organisation should carry this duty at all.

Not everyone agrees that organisations should carry the duty. The disagreement is old, and each side has a serious case. Milton Friedman, an American economist, argued in 1970 that the only social responsibility of a business is to use its resources to increase its profit while keeping to the law.^1 Others answer that society gives organisations their permission to operate, and that society can withdraw the permission.

^1: Friedman published this argument in the *New York Times Magazine* in 1970. Many writers have replied to it since.

> The main arguments for and against appear side by side in a table.

The table below sets out three questions in the debate. Read each row from left to right. The first cell names the question, the second gives the argument for the duty, and the third gives the argument against it.

:table Arguments for and against social responsibility
| Question | Argument for | Argument against |
| Whose money is spent? | Spending on society protects the good name of the organisation and so its profit over time. | The money belongs to the owners, who did not choose to spend it on society. |
| Who decides? | Managers know their own effects and are best placed to limit harm. | Managers are not elected, so they should not decide what society needs. |
| What if the organisation does nothing? | Society may reply with stricter laws and lost customers. | Governments and charities exist for social needs, and the organisation should pay its taxes. |

> Each side rests on a reasonable claim, and most modern writers accept both.

Neither column wins in every case. The argument for stresses time: harm to society often returns to the organisation as lost trust or stricter rules. The argument against stresses ownership and skill: managers are trained to run an organisation, not to solve every social problem. Most modern writers hold that both points are true. For them the question is how much responsibility an organisation should accept, not whether it should accept any.

> Davis built a model in five steps that links an organisation's power to its duty.

A model is a simplified picture of how something works. Keith Davis, an American management scholar, offered one that links power to duty.^2 We call it the Davis model. It has five steps, and each step rests on the one before it.

^2: Davis wrote on this subject from 1960 onwards. Later textbooks present his ideas as a short list of steps.

> Steps 1 and 2: social power creates a duty of equal size.

Step 1: an organisation holds social power. It employs people, buys and sells in large amounts and can change a neighbourhood. Step 2: responsibility grows with that power. Davis stated a warning, which he called the iron law of responsibility. Those who do not use power in a way that society considers responsible will tend to lose it over time. A large garment buyer has more power over its suppliers than a small shop has over its own, and so it owes more.

> Steps 3 to 5: open dealing, costs counted and priced, and help beyond the organisation's own business.

Step 3: the organisation deals openly with society. It listens to people outside and tells them what it does. Step 4: it counts the costs and benefits to society before it acts, and it adds the social costs to its price, so that those who gain from a product also pay for its effects. Step 5: it helps to solve social problems beyond its own activity, where it has the ability to do so.

:fig Davis model as five steps from power to responsibility | ch06-fig01.svg

> The figure is read from the lowest step on the left to the highest on the right.

Read the figure from the lowest step on the left to the highest on the right. Each step is one part of the model, and its height shows that it rests on the steps below. The dashed line joins the steps in order. The numbers and words carry the meaning, so the figure reads the same in grey.

> The model guides thought but does not measure results.

The Davis model has limits. It does not say how much cost is too much, or which social problem an organisation should help first. It assumes that society can see what an organisation does, and in many places society cannot. It gives a smaller organisation a lighter duty, which is fair, but not a duty of zero. A bookshop with seven employees has little power, yet it still owes something to the people it employs and to the neighbours on its street.

> The recap of section 6.1.

*Before moving on.* Corporate social responsibility is an organisation's duty to act for the good of society as well as for profit. Thinkers disagree about it. One side stresses the owners' money, and the other stresses society's permission and the long-term good name of the organisation. The Davis model climbs five steps, from power to responsibility and on to help beyond the organisation's own business.

* * *

## 6.2 Business Ethics

> A first question: can an act be lawful and still be wrong?

Ask two questions about any choice. Is it lawful? Is it right? Most people see that the answers can differ. Telling a friend a hurtful lie breaks no law, yet it may be wrong. In the other direction, an old law may require something that many people now think unfair. Law sets the minimum that society enforces. Ethics asks for more.

> Recall: Chapter 1, 'What Management Is', section 1.4 'A Manager's Responsibility' — responsibility.
> Business ethics is the set of moral rules that judge conduct at work.
@ Business ethics | The moral rules that decide what is right and wrong in business conduct.
@ Ethics | Word in use. In daily life, a person's private sense of right and wrong. In management, shared rules of conduct that guide choices at work and can be written down.

**Business ethics** means the moral rules that decide what is right and wrong in business conduct. A moral rule is a belief about how people ought to treat one another, such as "do not deceive" or "keep your promises". A shop that gives a customer the correct change, even when nobody would notice a mistake, is following such a rule. Chapter 1 explained that a manager answers for results. Ethics adds that a manager also answers for the way the results were reached.

> Ethical beliefs come from many sources and differ among places.

People form their beliefs about right and wrong in many places: in the family, in religion, in the culture around them, in a profession and in the workplace itself. Because these sources differ, ethical beliefs also differ among people and among countries. The same is true of law. A manager who works across borders must therefore name the place whose rule applies before judging an act.

> A table sorts three acts by what the law and ethics say about them.

The table below sorts three acts by what the law and ethics say. Read across each row: the act comes first, then the law, then the ethical view. The text after the table explains a fourth case that the table leaves out.

:table Three acts judged by law and by ethics
| Act | Law | Ethics |
| Paying employees the wages that were promised | Required | Right |
| Praising a book's good points while saying nothing of its badly faded print | Often allowed | Doubtful, because it misleads the buyer |
| Selling a stolen book | Forbidden | Wrong |

> Law and ethics overlap but are not the same thing.

The first and third rows show law and ethics agreeing. The second row shows them parting: the act may be lawful, but many people would still judge it wrong. A fourth case runs the other way. An organisation may give its employees paid leave to attend a funeral when no law requires it. The act is ethical without being required. For this reason a careful manager asks "Is it right?" after asking "Is it lawful?", and never in place of it.

> Some choices have no painless answer.
@ Ethical dilemma | A choice in which every option has a cost to some person's rights or interests.

Some choices have no painless answer. An **ethical dilemma** means a choice in which every option has a cost to some person's rights or interests. Suppose a shop owner can survive a bad year only by dismissing one of two employees or by cutting the pay of both. Each option harms someone. The owner cannot avoid harm, and can only choose which harm to accept and how to reduce it.

> A dilemma differs from a temptation, where one option is plainly wrong.

A dilemma is not the same as a temptation. In a temptation, one option is plainly wrong, and the difficulty is the wish to take it. A shop owner who is tempted to sell stolen books for a high profit does not face a dilemma. The right answer is known, and only the will is tested. In a true dilemma, thoughtful people may disagree about the right answer, and the manager must reason with care.

:pause 6.p1 | Which of these is an ethical dilemma and which is only a temptation? (a) A shop owner must dismiss one of two employees or cut the pay of both. (b) A shop owner can raise profit by selling stolen books. Give your reason.

> Good reasoning about a dilemma follows steps that any manager can use.

A manager can reason through a dilemma in steps. First, state the facts and the choices. Second, list every person affected and the cost each choice puts on that person. Third, ask which moral rules apply, such as honesty or fairness. Fourth, ask whether the law allows each choice. Fifth, choose, and be ready to explain the choice to the people who bear its cost. The steps do not remove the difficulty, but they stop a manager from choosing by habit.

> Organisations can promote ethical conduct in several practical ways.

Managers cannot order people to be good, but they can build conditions in which good conduct is likely. Several ways are in common use. The first is a written code of ethics, which states the rules the organisation expects its people to follow. The second is the example of leaders, because employees watch what managers do far more closely than what managers say. The third is training, in which employees practise real dilemmas before they meet them.

> Reporting channels, rewards and checks complete the set of ways.

Three more ways support the first three. A reporting channel lets an employee raise a concern about wrong conduct without fear of punishment. The organisation should reward ethical conduct and discipline wrong conduct in the same way for every person, whatever their rank. Regular checks of accounts and records then show whether the rules are followed in practice. Each way is weak alone. A code that leaders ignore teaches employees that the code is for show.

> Ethics seen by owner, manager, employee and customer.

Each person sees ethics from a different place. The owner wants a name that customers trust. The manager wants rules that are clear enough to apply on a busy day. An employee wants to know that a refusal to do wrong will not cost a job. A customer wants to know that the price, the product and the promise are honest.

> The recap of section 6.2.

*Before moving on.* Business ethics is the set of moral rules that decide what is right and wrong in business conduct. Law and ethics overlap but are not the same, and a lawful act can still be wrong. An ethical dilemma is a choice in which every option has a cost to someone, and it differs from a temptation. Organisations promote ethics through codes, example, training, reporting channels, fair rewards and checks.

* * *

## 6.3 Sustainability

> A farmer who cuts every tree gains one season and loses all later harvests.

Picture a farmer with an orchard of mango trees. In one hungry year the farmer cuts every tree and sells the wood. The money feeds the family this year, but there will be no fruit next year or in any year after it. A wiser farmer picks the fruit, plants new seedlings and leaves the orchard as healthy as it was found.

> Sustainability is the wiser farmer's rule applied to an organisation.
@ Sustainability | Running an organisation so that it meets today's needs without harming later generations' ability to meet theirs.

The wiser farmer's rule has a name. **Sustainability** means running an organisation so that it meets today's needs without harming later generations' ability to meet theirs. The United Nations asked a group called the World Commission on Environment and Development to study the question. Its report *Our Common Future*, published in 1987, made this meaning widely known.^3 A bookshop follows the rule when it uses paper with care, treats its employees so that they stay healthy, and earns enough to remain open.

^3: The commission is often called the Brundtland Commission, after its chair, Gro Harlem Brundtland of Norway.

> Sustainability reaches beyond nature to people and to money.

Many people think that sustainability concerns only forests, rivers and air. The idea is wider. An organisation that keeps the air clean but ruins the health of its employees is not sustainable. Neither is an organisation that cares for both and then loses all its money and closes. Three things need care together: the natural environment, the people and the organisation's own finances.

> The triple bottom line judges an organisation by three results instead of one.
@ Triple bottom line | A way of judging an organisation by its profit, its effect on people and its effect on the natural environment.

A writer on business, John Elkington of Britain, gave this wider judgement a name in 1994. The **triple bottom line** means a way of judging an organisation by its profit, its effect on people and its effect on the natural environment. The phrase "bottom line" comes from accounts, where the last line shows the profit. Elkington added two more last lines, so that an organisation reports on people and on the natural environment as it reports on profit.

> A single year's record fills the three lines only in part.

:case Case file, illustrative. Record for 2025, Meghna and Sons: profit Tk 750,000; 7 employees (store manager, accounts and online orders, 3 sales assistants, 1 cashier, 1 stock clerk); 380 kg of unsold paper sent to recycling. Read as a triple bottom line, profit fills the first line, the 7 employees give a first fact for the second line, and the recycled paper gives a first fact for the third. The record holds no measure of pay, safety or respect, so it cannot complete the judgement.

> A responsible organisation shows evidence and not only claims.

How can a customer or a student tell whether an organisation is responsible? The best answer is to look for evidence instead of claims. A responsible organisation reports what it does, including its failures. It pays its employees what it promised and keeps their workplace safe. It lets independent people check its suppliers. It keeps to the law and to its own code of ethics, and it admits its mistakes and repairs them.

> Fine reports can hide poor conduct, so the question to ask is who checked.

This test has limits. A handsome report can hide poor conduct, and an organisation can say that it is green while doing little. The useful question is always "Who checked this claim?" Standards also differ by place. Rules on waste, wages and building safety vary from one country to another, so we judge an organisation against the rules of the place where it works and against the higher rules that it sets for itself.

> The recap of section 6.3.

*Before moving on.* Sustainability is running an organisation so that it meets today's needs without harming later generations' ability to meet theirs. The triple bottom line judges an organisation by profit, by its effect on people and by its effect on the natural environment. We recognise a responsible organisation by evidence that an independent person has checked.

* * *

## Worked Case: The Photocopied Textbooks

> The worked case applies the chapter's ideas in five parts to one decision.

We now apply the ideas of this chapter to one decision in the case file. The worked case has five parts: Situation, Question, Reasoning, Conclusion and Check. It shows how the ideas combine. It is an application and not a model answer.

> The situation: a supplier offers cheaper photocopied copies, and the shop declines.

:case Case file, illustrative. Ethical choice, 18 June 2026, Meghna and Sons. A supplier offered 500 photocopied copies of a textbook at Tk 180 each against Tk 260 for genuine copies, a saving of 500 x 80 = Tk 40,000. The shop declined.

> The question is whether the shop should have accepted the offer.

*Question.* Should the shop have accepted the offer? To answer, we apply four tests in turn: the law, the moral rules, the Davis model and the triple bottom line.

> Test 1: copyright law probably forbids the sale of unauthorised copies.

*Reasoning, test 1: the law.* Copyright law gives the author or publisher the right to control the making of copies.^4 The case file does not say whether the supplier held the publisher's permission. Photocopied books sold without such permission are unlawful in most countries, so the offer probably fails the first test.

^4: Copyright law differs from country to country. A student should read the copyright law of the country concerned before judging a real case.

> Test 2: moral rules and the costs to others point against the offer.

*Reasoning, test 2: the moral rules.* Two rules apply: do not take what belongs to others, and do not deceive. The authors and the publisher bear the cost of the sale, because they receive nothing from it. The customers may also receive a poorer product than they believe they are buying. The shop would bear the cost of a damaged name.

> Tests 3 and 4: the model and the triple bottom line weigh the gain against the risk.

*Reasoning, tests 3 and 4: the Davis model and the triple bottom line.* Davis step 3 asks whether the shop could tell its customers openly how it obtained the books. Step 4 asks that the social costs be counted, and here they fall on the authors and the publisher. For profit, the saving of Tk 40,000 compares with the 2025 profit of Tk 750,000 as 40,000 ÷ 750,000 = 0.053, or about 5.3 per cent. Against this, schools bought Tk 3,600,000 of the 2025 sales of Tk 14,400,000, which is 25 per cent of sales. A school that learned of unauthorised copies might stop buying.

> The conclusion and the check agree that the shop should decline.

*Conclusion.* The shop should decline. The offer probably fails the law, fails the moral rules, hides a cost from the authors and the publisher, and risks a much larger share of sales than it gains. *Check.* All four tests point the same way, and the case file records that the shop declined. The shop's own record therefore agrees with the reasoning.

### Changing the Situation

> Rung 2 reshapes the case: the books are genuine old stock.

The same ideas help in new situations. In the second rung, suppose the supplier offers genuine copies of an earlier edition at Tk 180 because the edition is being cleared. The law test is passed. The moral rule of honesty now asks whether customers know that the edition is old.

> Rung 3 moves the case to a garment buyer in another setting.

In the third rung, a clothing buyer in another country is offered garments at a low price from a factory that no one has inspected. The Davis model says that the buyer's power creates a duty, and step 4 says that the safety cost must be counted and not passed to the factory's employees.

> Rung 4 combines the ideas into a choice with costs to several people.

In the fourth rung, a small organisation learns that its supplier keeps prices low by dismissing employees without notice. Dropping the supplier may raise its own costs. The choice is a dilemma, so we list those affected, apply the Davis model and judge the result by the triple bottom line.

* * *

## Summary

> A short summary of the chapter's five defined terms and their links.

Corporate social responsibility is an organisation's duty to act for the good of society as well as for profit. The Davis model links that duty to power in five steps. Business ethics gives the moral rules for judging conduct, and an ethical dilemma is a choice in which every option has a cost to someone. Sustainability asks an organisation to meet today's needs without harming later generations. The triple bottom line judges an organisation by profit, people and the natural environment.

## Think It Through

:q 6.t1 | A small printing shop is offered a rush order. It can finish on time only if its employees work a night shift without the usual safety checks. List the people affected. Then apply Davis step 2 and step 4 to the choice and say what the owner should do.

:q 6.t2 | Using only the facts given in this chapter, judge Meghna and Sons by the triple bottom line. State what each of the three lines shows, and name two facts that you would still need before you could finish the judgement.

## Where People Go Wrong

> Mistake one: believing that whatever is lawful must also be right.

*Mistake: "If an act is legal, it is ethical."* Law sets the minimum that society enforces. Many lawful acts mislead or harm people, and a careful manager asks whether an act is right as well as whether it is lawful.

> Mistake two: believing that social responsibility means giving money away.

*Mistake: "Social responsibility means giving money to charity."* Gifts can be part of it, but the duty begins with the organisation's own conduct. An organisation that gives money while it pays unfairly or ignores safety has not met the duty.

> Mistake three: believing that sustainability concerns only nature.

*Mistake: "Sustainability is only about protecting nature."* Sustainability also covers people and money. An organisation that harms its employees or loses all its money cannot continue, and the triple bottom line counts all three.

> Mistake four: believing that every hard choice is a dilemma.

*Mistake: "Every difficult choice is an ethical dilemma."* A dilemma is a choice in which every option has a cost to someone. When one option is plainly wrong and the difficulty is the wish to take it, the situation is a temptation.

> Mistake five: believing that only large organisations carry the duty.

*Mistake: "Only large organisations need to think about this."* Power grows with size, so a large organisation owes more. A small shop owes less, but its choices still reach employees, customers and neighbours, and the duty is never zero.

## In History

> Rana Plaza in 2013 showed the human cost of ignoring safety and responsibility.

On 24 April 2013, the Rana Plaza building collapsed at Savar, near Dhaka, in Bangladesh. The building housed five garment factories that made clothing for brands sold in many countries. More than 1,100 people died, most of them garment employees, and more than 2,000 others were injured. The disaster was not the first in the industry. Earlier fires in garment factories had already killed many employees.

> Pressure from the public led brands and unions to sign a binding agreement.

In May 2013, brands and retailers signed the Accord on Fire and Building Safety in Bangladesh together with international trade unions. The Accord was a legally binding agreement. It required independent inspections of supplier factories by qualified engineers, and it required the results to be made public. Reports on the events state that pressure from the media and from customers led more companies to sign after the collapse.

> The events show the chapter's ideas at work in a real case.

The events show this chapter's ideas at work. Buyers hold power over their suppliers, which Davis step 2 says creates a duty. Low prices can push costs of safety onto employees, which Davis step 4 says must be counted. The agreement made the dealing between buyers and suppliers more open, as Davis step 3 asks. Finally, the loss of life shows what a triple bottom line would record on the line for people.

## Review Questions

:q 6.1 | Define corporate social responsibility in your own words, and give one example from a bookshop.

:q 6.2 | Give one argument for and one argument against the idea that organisations should carry a duty to society. State which owner, manager or employee would most likely make each argument.

:q 6.3 | Name the five steps of the Davis model in order. For step 2, say what the iron law of responsibility warns.

:q 6.4 | Explain the difference between an ethical dilemma and a temptation, with one example of each.

:q 6.5 | Sort each act as legal, ethical or both, and give a reason: (a) paying employees on the day promised; (b) selling a stolen book; (c) giving employees paid leave for a funeral when no law requires it.

:q 6.6 | A rival bookshop cuts the safety of its storeroom to lower its price. Using ideas from this chapter, explain why this is a problem for society and for the rival, and say what a manager at your own shop should do.

:read Milton Friedman, 'The Social Responsibility of Business Is to Increase Its Profits', 1970
:read World Commission on Environment and Development, *Our Common Future*, 1987
:read John Elkington, *Cannibals with Forks*, 1997
