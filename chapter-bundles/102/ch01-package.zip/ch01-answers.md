:answers 01
:a 1.p1 | Planning: deciding in advance what to cook and buy. Organising: sharing the tasks among family members. Leading: guiding and encouraging the members. Controlling: checking at the month's end whether the money lasted, and correcting any difference.
:a 1.p2 | Yes. The owner employs two drivers, tells each one what to do and answers for the results of their work, which matches the definition of a manager.
:a 1.t1 | Nurul Meghna, the owner-manager of a shop with seven staff. The resources are stock Tk 3,500,000, fittings Tk 600,000 and the seven staff.
:a 1.t2 | Rafiq answers for the assistants' work that week, because a manager answers for the work of the people he directs. Nurul remains the owner.
:a 1.t3 | The stall still has resources and goals. Its owner must decide what to buy, arrange the stall and check the takings, which is management on a very small scale. Only the leading of other people is missing.
:a 1.t4 | The organisation is the club. Two resources are the members and the fund (or the ground). The manager is the person who is responsible for the members' work and its results, such as the person chosen to direct the club.
:a 1.1 | Doctors and nurses (people), money from fees or public funds (money), medicines and equipment (materials), patient records (information).
:a 1.2 | Responsibility is a duty to perform a task and to answer for how well it is done. Authority is the right to give orders and make decisions.
:a 1.3 | Resources are limited, people differ, conditions change and tasks depend on one another, so someone must direct resources toward the organisation's goals.
