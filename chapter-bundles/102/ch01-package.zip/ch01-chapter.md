:chapter I | What Management Is
:mood Who decides what everyone does, and who answers when the work goes badly?
:desc This chapter introduces the central word of the book: management. It explains what management is, what its main features are, why every organisation needs it, and what a manager answers for. It also shows you how to read the rest of the book.
:plate ch01-plate.svg | A mill manager's office, with a window over the factory floor

> This chapter needs no earlier knowledge.

*You will need:* nothing. This is the first chapter, and it assumes no earlier knowledge of the subject.

> A family wedding shows that willing helpers are not enough.

Think of a family wedding. Someone must choose the date and the guest list. Someone must hire the hall, buy the food and collect the money. Many relatives are willing to help, and each one works hard. Yet on the morning of the wedding, nobody can say who decides what happens next, or who answers if the food is not enough. Willing people alone do not make the day succeed. Something more is needed.

> A bookshop meets the same puzzle every day, and the answer has a name.

Now picture a small bookshop with seven employees. Every day the same questions return. Which books should we order? Who serves the customers, and who counts the cash? What happens when a school asks for a large order by Friday? If nobody has the task of answering such questions, the employees work hard but not together. The shop loses time, money and customers. If someone has that task, the same seven people achieve far more. The work that answers these questions has a name: management. This chapter builds the idea slowly, one step at a time.

> The book has a fixed way of teaching, and you can learn it now.

You will find the same signs in every chapter. A new word appears in bold, and its meaning follows at once. A short note in the side column repeats that meaning. At the end of each section, a paragraph beginning *Before moving on.* repeats the main points. Short questions marked *Pause* let you test yourself before you continue. Cases about a bookshop called Meghna and Sons are labelled *Case file, illustrative.*, because the shop is an illustration and not a real organisation. Where you see the note *Go slowly here*, read each sentence twice.

* * *

## 1.1 The Idea of Management

@! Go slowly here.

> A household already contains the idea we need.

We begin with something every reader knows: a household. A family has a limited income, a few members who can work, a home and some wishes. They want food on the table, school fees paid and the rent settled. Someone must decide how to spend the money. Someone must decide who does which task. Someone must also check, at the end of the month, whether the plan worked. When nobody does these things, bills are missed and tasks are repeated. When someone does them with care, the same income lasts longer.

@ Management | The work of planning, organising, leading and controlling people and resources to reach an organisation's goals.

> Management is the name for this careful deciding, arranging, guiding and checking.

The same work takes place in a business, a school or a hospital, and there it has a special name. **Management** is the work of planning, organising, leading and controlling people and resources to reach an organisation's goals. In a bookshop, management includes choosing which books to order and checking that the day's takings are correct.^1

^1: People also use the word management for the managers as a group. This book uses *management* only for the work, and *manager* for the person.

@ Management | Word in use. In daily life, to manage can mean to cope, as in managing on a small income. In this book, management means the four-part work defined above.

> The everyday verb to manage is narrower than the word management in this book.

You may know the verb *to manage* from daily speech, as in "she manages on a small income". That meaning is about coping. The subject meaning is wider, because it covers the whole work of directing an organisation toward its goals.

> Four verbs in the definition need a plain-word preview.

The definition uses four verbs that you may not yet know as subject words. Here they are in plain words. *Planning* means deciding in advance what to do. *Organising* means arranging people and tasks. *Leading* means guiding and encouraging people. *Controlling* means checking results and correcting any difference from the plan. Chapter 3, 'The Functions of Management and How Management Is Judged', teaches all four. The definition also uses the words organisation and resources. The next two paragraphs explain them.

:pause 1.p1 | Name the four kinds of work in the definition of management. For each one, give an example from a family household.

@ Organisation | A group of people working together in a planned way to reach goals they could not reach alone.

> A group of people with a plan is an organisation.

First, the word organisation. A roadside seller of mangoes works alone and needs no group. A bookshop with seven employees is different, because the work is too large for one person. We call such a group an **organisation**. An organisation is a group of people working together in a planned way to reach goals they could not reach alone. A school, a hospital, a bank and a village cricket club are all organisations. People also say institution or enterprise. This book uses one word, organisation, for all of them.

@ Resource | Anything an organisation uses to reach its goals, such as people, money, materials and information.

> Resources are the things an organisation works with.

To reach its goals, an organisation needs things to work with. A **resource** is anything an organisation uses to reach its goals, such as people, money, materials and information. A bookshop's resources include its books, its cash, its shelves, its staff and its list of school customers. People are a resource too, though a special one, because only people can decide and act.

@ Resource | Word in use. In daily life, a resource often means a natural source of wealth, such as water or coal. In management, a resource is anything the organisation uses, including people and money.

> Not every resource can be touched.

Some resources can be touched, such as books and shelves. Others cannot. The list of school customers is information, and the skill of the staff belongs to the people resource. A manager must think about all of them, because each one helps the organisation to reach its goals.

@ Manager | A person who is responsible for the work of other people and for the results of their work.

> A manager gets results through the work of other people.

Now we reach the last part of the definition: managers reach goals through people. Think of a shop owner who sells books alone. The owner does the work with her own hands. Once a second person joins the shop, a new job appears. Someone must see that both people do their work and that the shop's results are good. A *result* is what the work produces, such as books sold or customers served. The person who has this job is a **manager**. A manager is a person who is responsible for the work of other people and for the results of their work. The word *responsible* has a precise meaning, which Section 1.4 explains. For now, read it as answerable. The person who directs the sales assistants and answers for the shop's sales is a manager.

> Results through people is the idea that separates management from doing the work oneself.

This idea stands at the centre of the whole book. A manager's own hands rarely make the product or serve the customer. The manager's work is to see that other people do it well, together, and toward the goals. A good sales assistant who becomes a manager must therefore learn a new skill: succeeding through the effort of others. Many students find this change difficult to picture, because the work no longer looks like work. It becomes deciding, arranging, guiding and checking. Yet it is real work, and the organisation depends on it.

:pause 1.p2 | A taxi owner employs two drivers and tells each one which area to cover. Is the owner a manager? Give a reason from the definition.

> The recap repeats the four ideas of this section.

*Before moving on.* Management is the work of planning, organising, leading and controlling people and resources to reach an organisation's goals. An organisation is a group with a plan. Resources are what it works with. A manager gets results through other people. *You should now be able to say* that management is the work of directing people and resources toward an organisation's goals.

* * *

## 1.2 Nature of Management

> Do a bookshop and a hospital share one kind of management?

Is the management of a bookshop a different kind of work from the management of a hospital, a bank or a school? The question is practical. If the work were different each time, a book like this one would have little to teach. The answer is that the *nature* of management, meaning its main features, is shared. Four features appear in every organisation. We take them one at a time.

> Management is found everywhere, and it never finishes.

The first feature is that management is universal and continuing. *Universal* means found everywhere. A family shop, a government office, a factory in Chattogram and a hospital in Edinburgh all need someone to decide, arrange, guide and check. The details differ, and we return to that point below, but the work is of the same kind. *Continuing* means never finished. A manager does not plan once and stop. Customers change, prices change and employees change, so the manager returns again and again to the same four kinds of work, for as long as the organisation lives. Think of a household cook: the meal is eaten, and tomorrow the cook plans again. A bookshop is the same. The books ordered on Monday are sold by Friday, and on Saturday the order must be placed again.

> Management exists because people work together.

The second feature is that management is a group activity. A person who works entirely alone has nobody to direct. A group is different. Tasks must be shared, effort must be combined, and disagreements must be settled. Management is the work that does all three. In the bookshop, the sales assistants, the cashier and the stock clerk each perform a part. Management is what joins the parts into one shop. Without it, there is a collection of individuals and not an organisation.

> Management always aims at goals.

The third feature is that management is goal-directed. It does not exist for its own sake. A manager always works toward the goals of the organisation, such as a sales target for the year. A manager who is busy but moves toward no goal is not performing management.

> The table sets the four features side by side.

The table below shows the four features together. Read each row from left to right: the feature, its meaning, and an example from a bookshop.

:table Four features of management
| Feature | Meaning | Bookshop example |
| Universal | Found in every organisation | The owner decides which books to order |
| Continuing | Never finished | Each new day brings new orders to place |
| Group activity | Needs people working together | Assistants, cashier and clerk each perform a part |
| Goal-directed | Aims at goals | The shop aims to sell more books than last year |

> The four features look different from the employee's side and the customer's side.

The four features also look different from different viewpoints. An employee notices the group activity most, because the employee's own task is only one part of the shop's work, and someone must say how the parts fit. A customer rarely sees management at all. The customer sees only the result: the right book on the shelf, a short wait at the till, and a correct bill. When these happen day after day, the continuing work of management is the reason. The owner sees all four features at once, because the owner answers for the whole shop and for every goal it has set.

> Every feature has a limit, and the limits prevent mistakes.

Each feature has a limit. Universal does not mean identical: a hospital manager and a bookshop manager use the same four kinds of work, but the details differ, because patients are not customers. Continuing does not mean that the work is the same every day. Group activity raises a harder question. Many students find it confusing, because a one-person business seems to have no group. Such an owner leads nobody, but still decides what to buy, arranges the stall and checks the day's takings. These are management on a very small scale.

> The recap repeats the four features.

*Before moving on.* Management is universal, continuing, a group activity and goal-directed. It is found in every organisation, it never finishes, it joins the efforts of many people, and it aims at goals. *You should now be able to say* that the nature of management means these four features.

* * *

## 1.3 Purpose and Importance

> Two shops, the same books and the same street can have very different futures.

Imagine two bookshops on one street. They buy from the same suppliers and charge the same prices. After a year, one shop is busy and the other must close. The books did not make the difference. The difference lay in how each shop used its resources: its people, its money, its stock and its time. This section asks two questions. What is management for, and why does it matter?

> A small household budget shows what limited resources force a manager to decide.

First, a bridge from daily life. Suppose a family has Tk 20,000 for one month. Rent takes Tk 8,000 and food takes Tk 9,000. Together these use Tk 17,000, and Tk 3,000 remains. The remaining money cannot pay for school books, transport and savings all at once. Someone must choose, and the choice has a result for everyone in the family. An organisation faces the same situation on a larger scale, with more people and more choices.

> The purpose of management is to reach goals by using resources well.

The purpose of management is to help the organisation reach its goals by using its resources well. Using resources well means that the organisation does not waste the time of its people, its money or its materials. A shop that orders books nobody buys wastes money. A shop where two employees perform the same task while a customer waits wastes time. Management tries to prevent both.

> The figure shows how managers turn two inputs into results.

The next figure gives a picture of this purpose. Read it from left to right. The box on the left holds the resources. The dashed arrow below it carries the goals. Both arrows enter the middle box, where managers decide, arrange, guide and check. The thick arrow on the right leaves the middle box and reaches the results. If the results match the goals, the purpose has been met.

:fig Managers turn resources and goals into results | ch01-fig01.svg

> Four conditions explain why every organisation needs management.

Why does every organisation need management? Four conditions explain it. First, resources are limited, so someone must decide how to use them. Second, people have different wishes, so someone must bring their efforts toward common goals. Third, conditions change, because customers, prices and rules are not fixed, so someone must watch and adjust. Fourth, many tasks depend on one another, so someone must see that they fit together. Without management, each of these four problems remains unsolved.

> Good management benefits owners, employees, customers and society.

Importance means how much something matters. Management matters to four groups. For the owner, good management protects the money invested and helps the organisation succeed. For employees, it gives clear tasks, fair treatment and steadier work. For customers, it means goods and service of the promised quality, delivered when promised. For society, successful organisations provide jobs and useful goods. Poor management reverses each of these benefits.

> The same good management looks different to the manager, the owner and the employee.

Each person in the bookshop sees the benefit in a different place. The owner sees it in the year's sales and in the care of the stock. The manager sees it in a working day that runs without delay. The employee sees it in knowing, each morning, which task is his or hers. The customer sees it in the book found quickly. All four are looking at the same management from four positions. When one of these views turns bad, the others usually follow, because the work is joined together.

> The recap repeats purpose, need and importance.

*Before moving on.* The purpose of management is to reach goals by using resources well. Organisations need it because resources are limited, people differ, conditions change and tasks depend on one another. It matters to owners, employees, customers and society. *You should now be able to say* why an organisation without management would waste its resources.

* * *

## 1.4 A Manager's Responsibility

@ Responsibility | A duty to carry out a task and to answer for how well it is done.

> A manager's duty has two parts: to act and to answer.

Who answers when a shop's sales fall? The question leads to the last idea of the chapter. A manager does more than direct work. A manager also carries a duty. **Responsibility** is a duty to carry out a task and to answer for how well it is done. A cashier who is responsible for the till must count the cash correctly and explain any difference.

> A manager answers for results, and not only for effort.

A manager answers for results. It is not enough to say that the employees worked hard. If the sales target is missed, the manager must explain why, and say what will change. The manager's responsibility covers the work of other people, as the definition of a manager says.

> A manager answers to three groups, and each expects something different.

A manager answers to owners, employees and customers. The table below shows what each group expects. Read each row as: the group, then what the manager answers for.

:table What a manager answers for
| To whom | What the manager answers for |
| Owners | Results, and the care of the owners' money and goods |
| Employees | Clear tasks, fair treatment and pay on time |
| Customers | Goods and service as promised |

> From the manager's own side, responsibility can feel heavy, and it needs support.

Responsibility looks different from the manager's own chair. The manager cannot say that a mistake belongs to the assistant who made it, because the manager answers for the assistant's work. Many people find this unfair at first. It becomes reasonable when you remember the definition: a manager is a person who gets results through other people, and the results belong to the person who directs the work.

> Responsibility is different from authority, which later chapters explain.

Responsibility is not the same as authority. Authority means the right to give orders and make decisions. Chapter 14, 'Authority, Delegation and Coordination', teaches it. A manager may be given a duty without receiving the right to act. That gap causes trouble, and the later chapter explains how to avoid it.

> The recap repeats responsibility and its three audiences.

*Before moving on.* Responsibility is a duty to perform a task and to answer for it. A manager answers for results to owners, employees and customers.

* * *

## Worked Case: Meghna and Sons

> The worked case applies the definitions to a documented shop.

This worked case applies the ideas of the chapter to one documented organisation. It does not model a written answer. It shows one way of reasoning, step by step. *Situation.* Read the case file below first.

> The case file records the shop's people, resources and sales target.

:case Case file, illustrative. Meghna and Sons is a family-run bookshop in Dhanmondi, Dhaka, founded on 4 April 1996 by Nurul Meghna, the owner-manager. Position on 1 January 2026: seven staff are Rafiq Meghna, store manager; Tariq Meghna, accounts and online orders; three sales assistants; one cashier; and one stock clerk. Resources: stock Tk 3,500,000; fittings Tk 600,000; seven staff. The sales target for 2026 is Tk 15,840,000, which is 10% above the 2025 sales of Tk 14,400,000.

> The question asks us to identify the organisation, the resources, the manager and the goal.

*Question.* Which parts of the case file are the organisation, the resources, the manager and the goal? How was the target reached?

> The reasoning goes through each definition in turn.

*Reasoning.* We use the definitions one at a time.

> Step one: the organisation is the group with a planned way of working.

Step 1. The organisation is Meghna and Sons: the owner-manager and seven staff, working together in a planned way. One person could not sell this volume of books alone.

> Step two: the resources are the three items the file lists.

Step 2. The resources are the stock, the fittings and the seven staff. The stock and fittings are materials, and the staff are people.

> Step three: the definition of a manager decides who counts, and a title alone does not.

Step 3. A manager is a person who is responsible for the work of other people and for the results of their work. Nurul fits this definition, because she is the owner-manager of a shop with seven staff. Rafiq holds the title of store manager. The case file does not say which employees report to him, so we cannot apply the definition to him without more facts. A title is a clue, and the definition is the test.

> Step four: the goal is the sales target, and its arithmetic can be checked.

Step 4. The goal is the 2026 sales target. We check how it was found. Ten per cent of Tk 14,400,000 is Tk 14,400,000 × 10 ÷ 100 = Tk 1,440,000. Adding this to the 2025 sales gives Tk 14,400,000 + Tk 1,440,000 = Tk 15,840,000. The figure matches the case file.

> Step five: the table of Section 1.4 shows who the manager answers to in this shop.

Step 5. Use the table of Section 1.4. Nurul is both the owner and the manager, so she answers to herself as owner for the results and to the employees for fair treatment. She also answers to customers for goods and service as promised. A family shop therefore joins two roles in one person, which is common in small organisations.

> The conclusion joins the four parts into one picture.

*Conclusion.* At Meghna and Sons, management is the work of directing the seven staff, the stock and the fittings toward a sales target of Tk 15,840,000. The owner-manager is the clear manager under the definition.

> Three common slips are worth naming before the check.

*Common slips.* Readers often name the title as the test of a manager, forget that people are a resource, or confuse the sales target with the 2025 sales. The title is only a clue, the staff are a resource, and the target is the 2025 sales plus ten per cent.

> The check confirms that the target is a sensible increase.

*Check.* A tenth of Tk 14,400,000 is Tk 1,440,000, because dividing by ten moves the digits one place. The target is the 2025 sales plus that amount, so it is ten per cent higher. The answer is sensible.

* * *

## Summary

> The summary gathers the chapter into five sentences.

Management is the work of planning, organising, leading and controlling people and resources to reach an organisation's goals. An organisation is a group working together in a planned way. Resources are everything it uses. A manager gets results through other people and is responsible for their work. Management is universal, continuing, a group activity and goal-directed. Its purpose is to reach goals by using resources well. A manager answers to owners, employees and customers, and this duty is different from authority, which is the right to give orders.

## Think It Through

> Four short cases take you one step at a time from the case file to new settings.

Each case below moves a little further from the shop in the case file. Use only the definitions of this chapter.

:q 1.t1 | Use the case file. Name one manager at Meghna and Sons, and list the resources the case file records.
:q 1.t2 | Suppose Nurul is away for one week and Rafiq directs the sales assistants. For that week, who answers for the assistants' work, and why?
:q 1.t3 | Why does a one-person stall still need management, although it has no employees?
:q 1.t4 | A village cricket club has members, a small fund, a ground and a wish to win its league. Name the organisation, two resources, and the person who would be the manager.

## Where People Go Wrong

> Five common misunderstandings are stated and corrected.

*Wrong:* Management means giving orders. *Correct:* Giving orders is one small part of leading. Management also includes deciding what to do, arranging the work and checking the results.

> A second misunderstanding limits management to large businesses.

*Wrong:* Only large businesses need management. *Correct:* Management is universal. A family shop, a stall and a village club all have resources and goals, so they all need it.

> A third misunderstanding trusts the job title.

*Wrong:* Anyone whose job title includes the word manager is a manager. *Correct:* The test is the definition. A manager is responsible for the work of other people and for the results of their work. A title is only a clue.

> A fourth misunderstanding confuses a duty with a right.

*Wrong:* Responsibility and authority are the same thing. *Correct:* Responsibility is a duty to perform a task and to answer for it. Authority is the right to give orders and make decisions.

> A fifth misunderstanding confuses effort with results.

*Wrong:* A manager who works hard has done the job. *Correct:* A manager answers for results. Hard work that does not move the organisation toward its goals does not meet the manager's responsibility.

## In History

> Robert Owen managed a mill and its people together, and the case still teaches.

Robert Owen (1771–1858) was a Welsh-born manufacturer. On 1 January 1800 he became manager and part-owner of the New Lanark cotton mills in Scotland, beside the River Clyde near the town of Lanark. David Dale had founded the mills in the 1780s.

> Owen managed people as well as output.

Owen did not manage only machines and output. He managed the people who worked there. He limited working hours and raised the standards of housing and cleanliness in the village. He opened a village store and a fund for the sick. He also established schools, including an infant school in 1816. When the mills stopped for four months, he continued to pay wages. His mills became famous, and visitors from many countries came to see how they were run.

> His partners disliked the cost, yet the business continued to succeed.

Owen's reforms cost money, and some of his partners disagreed with the spending. Yet the mills continued to succeed as a business. His story shows a manager who answered for output and for people at once, and who also had to answer to the owners. It also shows that responsibility has more than one direction. A manager's duty reaches upward to owners, sideways to the work, and downward to the employees.

## Review Questions

> Three questions return to the main ideas of the chapter.

:q 1.1 | Name four resources that a hospital uses, and say which kind of resource each one is.
:q 1.2 | Explain the difference between responsibility and authority.
:q 1.3 | State in one or two sentences why an organisation needs management.
