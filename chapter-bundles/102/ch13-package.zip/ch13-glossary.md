:glossary 13
Span of management | The number of employees who report directly to one manager. Only direct reports count. A store manager with three sales assistants, a cashier and a stock clerk has a span of five. The best span depends on skill, nearness and the kind of work.
Departmentalization | The grouping of jobs into departments according to a common basis, such as function, product, customer or territory. A department is a group of jobs under one manager. A shop may group by function into sales, stock and accounts.
Tall structure | A structure with many levels and small spans of management. Close supervision is possible, but messages pass through many levels and the many managers raise the cost of wages.
Flat structure | A structure with few levels and wide spans of management. Messages travel quickly and employees have more freedom, but each manager may be overloaded when the span is too wide.
Division of labour | The dividing of a large job into smaller tasks done by different people. Each worker becomes skilled in a narrow task, but the divided tasks must be joined again, which creates the need for coordination.
