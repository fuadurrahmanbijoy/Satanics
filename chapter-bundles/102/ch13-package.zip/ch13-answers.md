:answers 13
:a 13.p1 | The tasks are similar (both routine, in one room) and the employees are near the manager. Either of these, or the small number of other duties, suggests a wider span.
:a 13.p2 | Territory, because each branch is a place with its own manager.
:a 13.t1 | Too wide: one owner cannot follow 12 people and answer all their questions. Acceptable: all 12 do the same counter work in one place, so the tasks are similar and near, and the rules may be clear.
:a 13.t2 | Taller, because a new level has been added. The owner's span falls from 12 to 2 and each manager has 6. A benefit is closer supervision; a cost is the added wages and slower messages through the extra level.
:a 13.t3 | Territory. Grouping by product would give each product its own department, and each department would work in all three cities, so the managers would be responsible for a product everywhere and not for a place.
:a 13.t4 | One reasonable answer: a span of about 3 to 5 for the senior doctor, since the clinic is small and all work in one place (size and nearness), and a grouping by function (doctors, nurses, reception) because the clinic is small and its work is routine. Other reasoned answers are acceptable.
:a 13.1 | His span is 4, because only the 4 report to him directly. The people below him number 4 + (4 × 3) = 16.
:a 13.2 | The accounts work takes his time, so he has less time to lead. A smaller span lets him give each employee enough attention.
:a 13.3 | Function (sales, stock, accounts); product (textbooks, storybooks, stationery); customer (walk-in, schools, online); territory (a branch in each city).
:a 13.4 | A tall structure has many levels and small spans; a flat structure has few levels and wide spans. A cost of tall: slow messages and high cost of many managers. A cost of flat: managers may be overloaded.
