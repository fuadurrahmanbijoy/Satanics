:chapter XIII | Structure: Span, Departments and Forces
:mood How many people can one manager lead, and how should the work be grouped?
:desc Every structure answers two questions: how many people report to each manager, and how the jobs are gathered into groups. This chapter explains both choices, and then shows the forces that push managers toward one design or another.
:plate ch13-plate.svg | A customs department where desks stand in tiers beneath a chief clerk

> Two ideas from Chapter 12 support this chapter.

You will need two ideas from the previous chapter. The first is organizing, taught in Chapter 12, 'Organizing and Types of Organization', section 12.1 'What Organizing Is'.^1 The second is the formal structure, taught in Chapter 12, 'Organizing and Types of Organization', section 12.3 'Formal and Informal Organization'.^2 Read those sections again if either idea feels uncertain.

^1: Recall: organizing, Chapter 12, 'Organizing and Types of Organization', section 12.1 'What Organizing Is'.
^2: Recall: formal organization, Chapter 12, 'Organizing and Types of Organization', section 12.3 'Formal and Informal Organization'.

> A shopkeeper can watch three assistants, but no one can watch three thousand soldiers.

Think of a shopkeeper who has three assistants. She sees every sale, hears every conversation and corrects a mistake within a minute. Now think of a general who has three thousand soldiers. He cannot see them all, and he cannot speak to each one in a single day. Somewhere between three and three thousand there lies a point where one person can no longer lead everyone directly. Where is that point, and what should the leader do when the point has been passed?

> The puzzle has two parts: how many people to lead directly, and how to group the rest.

The puzzle has a second part. Suppose a Victorian customs department, with desks in tiers and a chief clerk above them, grows from twenty clerks to two hundred. The chief clerk must now decide how many officers will report to him, and how the clerks will be grouped beneath those officers. Some departments group clerks by the kind of task. Others group them by the ships they handle, or by the port where they work. Each choice changes how fast the work moves and how well the clerks understand their duties.

> The chapter answers both parts and then names the forces that shape the answer.

In this chapter we answer both parts of the puzzle. We begin with the number of people a manager leads directly. Then we study four ways of grouping jobs. Finally we examine the forces that push a manager toward one design or another, and we study the old idea that the work itself should be divided into small tasks. Throughout, we shall use the small Dhaka bookshop Meghna and Sons, whose records give us numbers to work with.

* * *

## 13.1 Span of Management

> A teacher with a class shows that the number of people led changes how well they are led.

Consider a teacher who gives private lessons to two students. She knows each student's weak points and can reply to every question at once. When the same teacher faces a class of sixty, she can no longer follow each student. Her skill has not changed. The number of people she leads has changed, and that number alters the quality of her leadership. Managers meet the same fact in every organisation.

@ Span of management | The number of employees who report directly to one manager.

> The span of management is the number of employees reporting directly to one manager.

Management gives this number a name. The **span of management** means the number of employees who report directly to one manager. The word *directly* matters. A manager with five employees and fifty more below them has a span of five, not fifty-five. A store manager who has three sales assistants, a cashier and a stock clerk reporting to him has a span of five.

@ Span | Word in use. In daily life, the length of time or distance between two points, as in the span of a bridge. In management, the number of employees reporting directly to one manager.

> The case file records the spans at Meghna and Sons in 2026.

:case Case file, illustrative. Spans recorded at Meghna and Sons for 2026: Nurul Meghna, the owner-manager, has 2 direct reports; Rafiq Meghna, the store manager, has 5. The staff list suggests that Nurul's two are Rafiq and Tariq Meghna, and that Rafiq's five are the 3 sales assistants, the 1 cashier and the 1 stock clerk, but the record gives the counts only.

> The two spans in the shop differ, and the difference has a reason.

The shop has two different spans: 2 and 5. The owner has a small span, and the store manager has a larger one. Neither number is wrong. The question that matters is whether each manager can lead the people reporting to him well. To answer it, we need to know what makes a span suitable.

> Several factors decide how wide a span can be without harm.

There is no single correct span for all managers. The number depends on factors, and a manager can reason about each one. First, the skill of the employees. Employees who are trained and experienced need little guidance, so one manager can lead many. Second, the similarity of the tasks. If all the employees do the same kind of work, one manager can supervise them together. Third, the clarity of plans and rules. When everyone knows the standards, fewer questions come to the manager.

> More factors: distance, the manager's other duties, and how often things change.

Three more factors complete the list. Fourth, nearness: employees who work in one room are easier to lead than employees in different towns. Fifth, the manager's other duties. A manager who must also sell, buy and keep accounts has little time left for leading, so his span should be small. Sixth, the speed of change. Work that changes every week creates many questions, and a manager needs time to answer them. In general, the wider the span, the more the first three factors must be favourable.

> An exception: a wide span can work when employees are skilled, and a narrow one can still fail.

These factors have exceptions. A manager with a very wide span may succeed if the employees are highly skilled and the rules are clear. A manager with a narrow span may still fail if he supervises too closely and gives employees no room to think. The factors are guides to judgement and not a formula.

:pause 13.p1 | A store manager leads one cashier and one stock clerk, and both work in the same room on routine tasks. Name two factors from the list that suggest this manager could lead more people.

@ Tall structure | A structure with many levels and small spans of management.

> A tall structure has many levels and small spans.

Spans in the whole organisation add together to give its shape. A **tall structure** means a structure with many levels and small spans of management. Imagine a company in which each manager has only two employees below. To cover a hundred employees, the company needs many levels of managers, one above another, and the structure grows tall.

@ Flat structure | A structure with few levels and wide spans of management.

> A flat structure has few levels and wide spans.

The opposite design is the **flat structure**. A flat structure means a structure with few levels and wide spans of management. If each manager leads twelve employees, the same hundred employees need far fewer levels, and the structure is low and wide. The figure shows the idea with two small trees. To read it, begin at the top box, which holds the highest manager, and count the lines that leave each box. The number of lines leaving a box is its span, and the number of rows is the number of levels.

:fig Wide and narrow spans shown as two trees | ch13-fig01.svg

> Each design has benefits and costs, and neither is best in every case.

Each design has benefits and costs. A tall structure allows close supervision and gives employees many steps to climb, but messages must pass through many levels, so decisions are slow, and the many managers add to the cost of wages. A flat structure sends messages quickly and gives employees more freedom, but each manager is overloaded if the span is too wide. A manager who has too wide a span may miss mistakes. A manager who has too narrow a span may watch too closely and discourage initiative.

> The recap fixes span, the factors, and tall and flat designs.

*Before moving on.* The span of management is the number of employees who report directly to one manager. The suitable span depends on factors such as skill, similarity of tasks, clarity of plans, nearness and the manager's other duties. A tall structure has many levels and small spans. A flat structure has few levels and wide spans.

* * *

## 13.2 Departmentalization

> Once a manager has many employees, the next question is how to gather them into groups.

A bookshop with three employees needs no groups. Everyone knows everyone, and the owner speaks to all of them daily. When the shop grows to seven employees, the owner must decide how to divide them. One idea is to put the people who buy and shelve books together, and the people who serve customers together. That is a division by the kind of work. Another idea is to place together everyone who deals with schools. That is a division by customer. The choice affects how the shop works every day.

@ Departmentalization | Grouping jobs into departments according to a common basis, such as function or customer.

> Departmentalization is the grouping of jobs into departments on a common basis.

Management has a name for this choice. **Departmentalization** means grouping jobs into departments according to a common basis, such as function or customer. A department is a group of jobs placed under one manager. The basis is the feature that the jobs in one group share. Four bases are common: function, product, customer and territory. We take each in turn.

@ Department | Word in use. In daily life, a section of a large shop or a branch of government, such as a department of education. In management, any group of jobs placed under one manager, whatever name the organisation gives it.

> Grouping by function puts together jobs that need the same skill.

*By function.* A function is a main kind of work that an organisation must perform, such as selling, stock handling or accounts. When jobs are grouped by function, all the people who perform the same kind of work belong to one department. The case file shows the shop's present design.

> The case file records the grouping now used at Meghna and Sons.

:case Case file, illustrative. The grouping used now at Meghna and Sons is by function: sales, stock and accounts.

> Grouping by function builds skill and avoids repeated effort, but can separate departments from one another.

Grouping by function has advantages. People who share a skill learn from one another, and the shop needs only one stock team and one accounts team. It also has a weakness. The functions can drift apart: the sales team may promise a delivery date that the stock team cannot meet, because neither group sees the whole customer. Function suits an organisation with a small range of products and customers.

> Grouping by product puts together every job needed for one kind of good.

*By product.* When jobs are grouped by product, each kind of good or service has its own department with all the skills it needs. A large bookshop might have one department for textbooks, one for storybooks and one for stationery. The head of each department can then be judged by the results of one product. The weakness is repetition: each department may need its own buyer and its own record keeper, which raises the cost.

> Grouping by customer puts together every job needed to serve one kind of buyer.

*By customer.* When jobs are grouped by customer, each type of buyer has its own department. The shop's records show three types of customers, and the sales of 2025 can be set against them.

> The case file records the alternative grouping by customer type, with the sales of 2025.

:case Case file, illustrative. The alternative grouping at Meghna and Sons is by customer type, using the 2025 sales: walk-in customers Tk 9,000,000; schools Tk 3,600,000; online Tk 1,800,000.

> A customer grouping lets each department learn what its buyers need, but it repeats skills.

A customer grouping lets each department study the needs of its own buyers. A school department could learn when schools place their orders and what discounts they expect. Walk-in customers and online customers would also have their own teams. The cost is repetition, since each team may need its own stock handling and its own accounts, and a small shop may not have enough people to supply every team.

> Grouping by territory puts together every job in one place.

*By territory.* Territory means a geographical area, such as a district or a town. When jobs are grouped by territory, each area has its own department. A chain of bookshops with branches in several cities might give each city its own manager. Territory grouping suits an organisation that serves places far apart, because local managers can respond to local needs. The risk is that branches begin to follow different rules.

:pause 13.p2 | A bookshop with two branches, one in Dhaka and one in Chattogram, gives each branch its own manager. Which basis of grouping is this?

> The table compares the four bases by what they group and where they work well.

The table below compares the four bases. Each row names a basis and says what it puts together, one strength and one weakness. Read across a row to see one basis, and down a column to compare the four.

:table Four bases of departmentalization
| Basis | Puts together | Strength | Weakness |
| Function | Jobs needing the same skill | Builds skill, saves effort | Departments may drift apart |
| Product | Jobs for one good | Focus on each product | Repeated skills, higher cost |
| Customer | Jobs for one kind of buyer | Knows the buyer well | Repeated skills, needs more people |
| Territory | Jobs in one place | Responds to local needs | Branches may differ in rules |

> Most organisations mix the bases, and the right mix depends on the size and the work.

Few organisations use only one basis. A shop may group by function at the top and by customer inside the sales department. A large company may group by territory, and inside each territory by product. The test is the same in every case: does the grouping help the organisation reach its goals, with a reasonable cost? A grouping that was right for a shop with five employees may fail for a shop with fifty.

> The recap fixes departmentalization and the four bases.

*Before moving on.* Departmentalization is grouping jobs into departments on a common basis. The four common bases are function, product, customer and territory. Each has strengths and weaknesses, and most organisations mix them.

* * *

## 13.3 Forces Behind Structure

> Managers do not choose a structure freely; several forces push them toward one design.

A manager who has studied spans and departments may expect a single best design to exist. It does not. Two organisations of similar size can use different structures and both succeed. The reason is that managers work under forces, and the forces differ from place to place. We now name the main forces, beginning with two old ideas about what a structure should be.

> The bureaucratic model asks for fixed rules, clear levels and impersonal treatment.

The first idea is the bureaucratic model. Max Weber, a German sociologist who lived from 1864 to 1920, described an organisation built on written rules, fixed duties, a clear chain of command from top to bottom, and promotion by ability.^3 Its aim was fairness and reliability: the same rule applies to everyone, and the work continues when a person leaves. Its weakness is stiffness. An organisation that follows rules without exception may respond slowly to new situations.

^3: Weber described this model in writings that were published after his death. The word *bureaucracy* has a neutral meaning in management, although in daily speech it is often used as a complaint about slow offices.

> The behavioural model asks for a structure that fits the needs and habits of people.

The second idea is the behavioural model. Writers of this school noticed that employees are not machines. People work better when they feel valued, when they have some say in decisions, and when the groups they belong to are respected. A structure built on this idea gives employees wider tasks, more freedom and more contact with managers. This model is linked to the informal organization that we studied in the previous chapter. Its weakness is that freedom without enough guidance can lead to confusion.

> Neither model is correct in all cases; the best choice depends on the situation.

Neither model is correct in every case. A customs office that must treat every importer by the same rule leans toward the bureaucratic model. A group of designers who need freedom to try new ideas leans toward the behavioural one. The wise manager asks which model suits the work and the people at hand. That question leads to the forces that decide the answer.

> Situational factors such as size, the kind of work, and the world outside affect the best structure.

These forces are called situational factors, which means features of an organisation's own circumstances. Four are important. The first is size. A shop of seven employees can work with a flat structure and few rules, but a company of seven thousand needs levels and written procedures. The second is the kind of work. Routine work, which repeats every day, suits firm rules. Work that changes often, such as design, needs more freedom.

> The other factors are the world outside and the people themselves.

The third factor is the world outside the organisation. If customers, rivals and laws change slowly, a fixed structure can last for years. If they change quickly, a structure must be able to change with them. The fourth factor is the people. Employees who are skilled and keen to take responsibility can work with a wide span and few rules. Employees who are new or less trained need more guidance and closer supervision.

@ Division of labour | Dividing a large job into smaller tasks done by different people.

> Division of labour is the oldest force: splitting a large job into smaller tasks.

Behind every structure lies an older idea. **Division of labour** means dividing a large job into smaller tasks done by different people. The Scottish thinker Adam Smith described it in 1776, in his book *The Wealth of Nations*, by the example of a pin factory.^4 He observed that when pin making is divided into separate operations, each done by a different worker, the workers together produce far more pins than the same people working alone. Division of labour is the reason structures exist at all: once a job is divided, someone must group the tasks and link the people.

^4: Adam Smith (1723 to 1790) was a Scottish thinker and an early writer on economics. The pin factory is the best-known illustration in his book.

> Division of labour raises output, but it creates the need for coordination and can bore workers.

Division of labour has benefits and limits. Each worker becomes skilled in a narrow task, time is saved because no one changes from one task to another, and training is short. The limits are real. Workers who repeat a single small task all day may become bored, and a chain of many small tasks needs someone to join the results. That joining is called coordination, and the next part of this book teaches it.^5

^5: Coordination is taught in Chapter 14, 'Authority, Delegation and Coordination'. Here it is needed only in its everyday meaning: making separate parts work together.

> The more finely the work is divided, the more coordination is needed.

The link between the two ideas is simple to state. The more finely a job is divided, the more coordination is needed to bring the pieces together. A bookshop in which one person does everything needs no coordination at all. A bookshop with ten duties spread over seven people needs a clear arrangement of who tells whom what. Structure is the means by which an organisation carries out both the division and the coordination.

> The recap fixes the two models, the situational factors, and division of labour.

*Before moving on.* The bureaucratic model values rules and clear levels. The behavioural model values the needs of people. Situational factors such as size, the kind of work, the world outside and the people decide which suits best. Division of labour means splitting a large job into smaller tasks, and it creates the need for coordination.

* * *

## Worked Case: Spans and Grouping at Meghna and Sons

> The worked case applies the chapter's ideas to the shop's records.

This section applies the ideas of the chapter to the shop's records. It does not give a model answer. It shows one way of reasoning, step by step, so that you can follow each decision and then repeat it on another case.

> The situation gives the spans, the present grouping and the alternative.

*Situation.* In 2026 Nurul Meghna has 2 direct reports and Rafiq Meghna has 5. The shop groups its jobs by function: sales, stock and accounts. The alternative is to group by customer type, using the 2025 sales: walk-in Tk 9,000,000; schools Tk 3,600,000; online Tk 1,800,000.

> The question asks whether the spans are reasonable and whether the shop should change its grouping.

*Question.* Are the two spans reasonable for a shop of this size? Would a grouping by customer type be a better choice than the present grouping by function?

> Reasoning begins with the spans and the factors that affect them.

*Reasoning.* First, the spans. Rafiq's span of 5 is the larger. The factors from section 13.1 help us judge it. His employees work in one shop, so nearness is favourable. Their tasks, which are selling, the counter and stock handling, differ somewhat but are routine. The record gives no sign of difficulty. Nurul's span of 2 is small, but the owner has other duties, such as dealing with the world outside the shop, so a small span is reasonable. Both spans seem suitable.

> Next, the sales figures show how large each customer department would be.

Second, the grouping. A customer grouping would create three departments. We first find how large each customer type is, by dividing each customer's sales by the total of Tk 14,400,000. Walk-in sales are Tk 9,000,000, which is 62.5% of the total. School sales are Tk 3,600,000, which is 25%. Online sales are Tk 1,800,000, which is 12.5%. A walk-in department would be the main part of the shop. An online department would serve only one-eighth of the sales, yet it would still need its own skills in stock handling and accounts.

> The weakness of customer grouping is repeated skills, which a small shop can ill afford.

With only 7 employees, three customer departments would leave very few people in each. Each would still need stock handling and accounts, so the work would be repeated, and the cost per sale would rise. The present grouping by function avoids repetition: one stock group and one accounts group serve all three kinds of customer. Its weakness, as section 13.2 explained, is that sales and stock may drift apart, and the shop's small size makes that risk low.

> The conclusion states what the records support.

*Conclusion.* The two spans appear suitable, and the present grouping by function is reasonable for a shop of this size. A customer grouping becomes more attractive if school or online sales grow so that a customer department could keep several people busy.

> The check tests the arithmetic and counts the reports.

*Check.* We test the numbers. The three sales figures add to Tk 9,000,000 + Tk 3,600,000 + Tk 1,800,000 = Tk 14,400,000, which equals the total sales of 2025. The three shares add to 62.5% + 25% + 12.5% = 100%. The spans add to 2 + 5 = 7, which equals the 7 employees on the staff list, so every employee reports to exactly one manager in our reading of the record.

* * *

## Summary

> The summary restates the chapter in a few sentences.

The span of management is the number of employees who report directly to one manager, and the suitable span depends on factors such as skill, similarity of tasks, clarity of plans, nearness and the manager's other duties. Many levels with small spans make a tall structure; few levels with wide spans make a flat structure. Departmentalization groups jobs by function, product, customer or territory. Managers choose among designs under situational factors, and division of labour creates the need for structure and coordination.

## Think It Through

> Four situations test the chapter, from familiar to combined.

Each question below changes the situation a little more than the one before. Answer them in order.

:q 13.t1 | A bookshop owner has 12 employees who all serve customers at the counter. She asks them all to report to her. Give one reason this span may be too wide and one reason it may be acceptable.
:q 13.t2 | The shop places a new manager between the owner and the 12 employees, and each of two managers leads 6. Has the structure become taller or flatter? Name one benefit and one cost.
:q 13.t3 | A company runs three shops, one in each of three cities, and gives each city its own manager. Name the basis of grouping. Then say what would change if the company grouped by product instead.
:q 13.t4 | A small clinic has two doctors, three nurses and one receptionist. Suggest a span for the senior doctor and a basis of grouping, and give your reasons using at least two situational factors.

## Where People Go Wrong

> Mistake one: counting all the people below a manager as the span.

Some students count every person below a manager as that manager's span. The span includes only those who report directly to the manager. A manager with five employees, each of whom leads others, has a span of five.

> Mistake two: believing that a flat structure is always better.

Some students believe that a flat structure is always better because it is faster. A flat structure can overload its managers. The correction depends on skill and on the work: skilled employees with clear rules can use a wide span, but untrained employees cannot.

> Mistake three: believing that one basis of grouping is correct.

Some students believe that one basis of departmentalization is correct for all organisations. Function, product, customer and territory each suit different circumstances, and most organisations use a mixture.

> Mistake four: forgetting that division of labour needs coordination.

Some students praise division of labour without noticing its cost. Every division of a job creates a need to join the parts again, and a poor structure can lose the benefit of dividing the work.

## In History

> Alfred Sloan reorganised General Motors into divisions in the 1920s.

General Motors, the American car maker, was formed in 1908 and grew by joining together several car companies. By 1920 it had many makes, but its structure was poorly organised, and some of its cars competed with one another. Ford's Model T was then the leading car in the United States. In 1923 Alfred P. Sloan became president of General Motors. He had joined the company as a director and vice-president in 1918.

> Sloan grouped the company into divisions, each for a car brand, under central control.

Sloan arranged the company in divisions, one for each car brand: Chevrolet, Pontiac, Oldsmobile, Buick and Cadillac. The brands were planned in a graded range of prices, from the lowest to the highest. Each division ran its own affairs, while a small central office set policy and managed finance and planning. Reports on sales and results allowed the central office to see when a division fell behind its plan. Sloan described his work later in his book *My Years with General Motors*, published in 1963.

> The case shows grouping by product combined with central control.

The case shows ideas from this chapter at work. The divisions are a grouping by product, because each brand has its own department with the jobs it needs. The central office shows that grouping by product does not remove the need for coordination. Writers still debate how far central control should reach, and the debate has no final answer. The design became a pattern for many large companies in later years.

## Review Questions

:q 13.1 | A manager has 4 employees who report to him directly, and each of them leads 3 others. State his span and the total number of people below him.
:q 13.2 | Explain why a store manager who must also keep accounts should have a smaller span than one who has no other duties.
:q 13.3 | Name the four bases of departmentalization and match each to an example from a bookshop.
:q 13.4 | Explain, in your own words, the difference between a tall structure and a flat structure, and give one cost of each.
