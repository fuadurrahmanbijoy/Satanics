:chapter V | The Environment of Organisations
:mood Can any organisation live apart from the world around it?
:desc Every organisation stands inside a larger world of customers, rivals, laws and machines. This chapter divides that world into its parts, shows how managers study it, and explains the ways in which they respond to it.
:plate ch05-plate.svg | A harbour where ships, customs sheds and a watchful clerk meet the weather

> Two earlier ideas support this chapter.

You will need two ideas from earlier chapters. The first is the management process, taught in Chapter 3, 'The Functions of Management and How Management Is Judged', section 3.1 'The Management Process'.^1 The second is the organisation, taught in Chapter 1, 'What Management Is', section 1.1 'The Idea of Management'.^2 Read those sections again if either idea feels uncertain.

^1: Recall: management process, Chapter 3, 'The Functions of Management and How Management Is Judged', section 3.1 'The Management Process'.
^2: Recall: organisation, Chapter 1, 'What Management Is', section 1.1 'The Idea of Management'.

> A clerk checks the wind before he opens his books.

Picture a busy harbour in the middle of the nineteenth century. At the head of the quay stands a shipping office, and on its roof a weather vane turns. Each morning a clerk climbs to the window and studies the vane before he opens the ledgers. The ledgers tell him what the office owns and owes. The vane tells him something the ledgers cannot: whether the ships will arrive on time.

> The office controls its books, but not the forces that decide its fortune.

The clerk's habit hides a puzzle. The office has careful books, a sound building and skilled workers. Yet its fortune depends on matters it does not control. The wind decides when the cargo arrives. Officers at the customs shed decide how long goods wait and what tax they pay. Merchants decide whether to send their goods through this harbour or another. Over some decades, iron steamships began to replace sailing ships. A firm that had mastered sail could lose its trade without making one error in its own books.

@ Environment | Word in use. In daily life, the natural world of air, land and water. In management, everything inside and around an organisation that affects how it works.

> The question of the chapter: what else must managers examine?

Here is the question for this chapter. If an organisation can be managed perfectly inside its own walls and still fail, what else must its managers examine? The answer is the world around the organisation, which managers call its environment. We will name its parts, learn to sort its forces, and see how managers watch it and respond to it. Later we will meet a real company, Nokia, whose managers faced this problem on a very large scale. We will also read the records of a small Dhaka bookshop, Meghna and Sons, which met the same problem on a small scale.

* * *

## 5.1 Inside and Outside the Organisation

> The shop door divides what an owner can change from what an owner cannot.

Think of the door of a shop. Inside, the owner can move the shelves, change who works at the counter and decide the opening hours. Outside, the owner cannot move the road, cannot change the weather and cannot order a customer to buy. This ordinary picture gives us the first distinction of the chapter. Some conditions a manager can change directly. Other conditions a manager cannot change directly, and must learn to meet in other ways.

@ Internal environment | Conditions inside an organisation, such as its people, structure and culture, which managers can change directly.

> The internal environment is everything inside the door that managers can change directly.

The conditions inside the door form the **internal environment**. The internal environment means the people, the structure and the culture inside an organisation, which managers can change directly. Structure means the way work and authority are divided among people. Culture means the shared habits and beliefs of a group. In a bookshop, the internal environment includes the employees, the division of work between counter and stockroom, and the usual way of serving a customer.

> The case file records an internal change at Meghna and Sons.

:case Case file, illustrative. Meghna and Sons is a family-run bookshop in Dhanmondi, Dhaka, founded on 4 April 1996 by Nurul Meghna, the owner-manager. In 2025 it had 7 employees: Rafiq Meghna, the store manager; Tariq Meghna, who handled accounts and online orders; 3 sales assistants; 1 cashier; and 1 stock clerk. During 2025, 2 of the 7 employees left.

> An employee leaving is an internal change, because managers can act on it directly.

The departure of 2 employees belongs to the internal environment. The owner and the store manager can respond by hiring, by training, or by dividing the work again. Notice the word *directly*. Managers did not cause the departures, but they can act on the result with their own authority. That power to act directly is what marks a condition as internal.

@ External environment | All outside forces, such as customers, rivals, laws and technology, that affect an organisation.

> The external environment is every outside force that affects the organisation.

The forces outside the door form the **external environment**. The external environment means all outside forces, such as customers, rivals, laws and technology, that affect an organisation. A manager cannot give these forces an order. A manager can, however, study them and prepare. A customer who changes her tastes, a rival who lowers a price and a government that issues a new rule all belong here. Each of them reaches the organisation from beyond the door.

:box IN SHORT
Internal environment: a manager can change it directly. External environment: a manager can study it, prepare for it, and sometimes influence it, but cannot command it.

:pause 5.p1 | A new bookshop opens two streets away from Meghna and Sons. Is this change internal or external? Give one reason.

> The line between inside and outside is a boundary, and it follows control, not distance.

The line between the two environments is called the boundary. It is not a wall, because goods, money, information and people cross it every day. It also follows control, not distance. A supplier in the next street is outside the boundary, because the owner cannot direct that supplier. A branch in another town is inside the boundary if the same organisation owns it and directs it.

> The recap fixes the two environments and the boundary between them.

*Before moving on.* The internal environment is what managers can change directly. The external environment is what they can only study, prepare for or influence. The boundary between them follows control, not distance.

* * *

## 5.2 Components of the External Environment

> The outside forces are too many to study as one heap, so managers sort them.

Suppose a manager writes down every outside force that touches a bookshop in one year. The list would include tastes, prices, laws, machines, rivals, weather and world events. A list that long is hard to use. Managers therefore sort outside forces into groups, and watch each group in turn. Writers divide the groups in different ways. This book uses five, and the groups are a convenience for thinking, not a law of nature.

@ Task environment | The outside groups that deal directly with an organisation, such as customers and suppliers.

> The task environment holds the outside groups that deal directly with the organisation.

Before we meet the five groups, one more distinction helps. Some outside forces are people and bodies that deal directly with the organisation. They form the **task environment**. The task environment means the outside groups that deal directly with an organisation, such as customers and suppliers. For a bookshop, the schools that order books, the publishers that sell them and the rival shops that compete for the same buyers are all part of it.

> The figure shows rings of forces around the organisation.

Other forces reach the organisation more slowly, through the whole society: the state of the economy, the customs of the people, the laws, the machines and the world beyond the country. The figure shows both kinds. To read it, begin at the centre, where the organisation stands. The next ring holds the task environment. The outer ring holds the five groups of wider forces, each named on its own segment. The nearer a force stands to the centre, the more directly it deals with the organisation.

:fig External environment layers around the organisation | ch05-fig01.svg

> The economic environment is the state of money, prices, incomes and trade.

The first group is the economic environment: the state of money, prices, incomes and trade around the organisation. When families have less to spend, they buy fewer books. When rivals lower their prices, customers compare. Bank interest rates, the cost of paper and the general level of employment all belong here. A manager watches the economic environment to learn what customers can afford and what the organisation must pay.

> The social and cultural environment is the tastes, beliefs and habits of the people served.

The second group is the social and cultural environment: the customs, beliefs, tastes and education of the people the organisation serves. A society that values schooling buys many school books. A society in which more people read on screens buys fewer printed ones. These forces change slowly, and they differ from one community to another, so a manager must study the people actually served and not assume that all customers think alike.

> The political and legal environment is the rules and actions of public bodies.

The third group is the political and legal environment: the rules and actions of governments, courts and public bodies. Taxes, shop licences, rules on imported goods and decisions about what schools teach all belong here. These rules differ from country to country, so this book names the country whenever it names a rule.^3 A decision by an education authority, for example, can change which books every school in a country must buy.

^3: A tax on imported books may exist in one country and not in another. A manager must always check the rules of the country where the organisation operates.

> The technological environment is the methods and machines available to the organisation and its rivals.

The fourth group is the technological environment: the methods and machines available to the organisation and its rivals. The steamship changed the harbour. The internet changed the bookshop. The same technology can bring a threat and an opportunity together. A website lets a distant rival reach the shop's customers, and it also lets the shop itself reach customers who never enter the door.

> The global environment is the part of the outside world beyond the country's borders.

The fifth group is the global environment: forces that come from beyond the borders of the country. A shop that buys foreign books feels the price of foreign money. A shop that sells only local books still feels world prices for paper, and it can still meet rivals that operate online from other countries. No organisation is wholly sheltered. Some meet the global environment daily, and others meet it only through prices and rivals.

> The table sorts the five groups by what each covers.

The table below places the five groups side by side. Each row names a group, says in plain words what it covers, and gives an example for a bookshop. Read across a row to see one group, and down a column to compare the groups.

:table The five groups of wider forces
| Group | What it covers | Example for a bookshop |
| Economic | Money, prices, incomes, trade | A fall in family spending on books |
| Social and cultural | Tastes, beliefs, habits, education | A shift from printed books to screens |
| Political and legal | Rules and actions of public bodies | A new tax or a change in school books |
| Technological | Methods and machines | Online selling and phone payment |
| Global | Forces from beyond the country | The price of foreign money |

> The groups overlap, so one event can touch several of them.

One caution applies to the table. The groups overlap. A rival's online price cut is an economic force, because it changes prices. It is also a technological force, because online selling made it possible. It also belongs to the task environment, because the rival competes for the same buyers. A manager does not need to decide which single box is correct. The sorting is useful when it makes the manager notice every way in which the event reaches the organisation.

> The case file records the outside changes at Meghna and Sons.

:case Case file, illustrative. Outside changes recorded at Meghna and Sons: online price cuts of about 15% on textbooks since March 2025; textbook sales of Tk 4,300,000 in 2025 against Tk 5,100,000 in 2024; and a curriculum change from January 2026.

> Each outside change reaches the shop through a different group.

Each recorded change reaches the shop through a different route. The online price cuts come from rivals and from technology. The fall in textbook sales shows how those forces reached the shop's own results. The curriculum change is a decision of public authority, and it falls within the political and legal group. In the Worked Case at the end of the chapter we shall sort these changes step by step.

> The recap fixes the five groups and the task environment.

*Before moving on.* The task environment is the set of outside groups that deal directly with the organisation. The wider forces fall into five groups: economic, social and cultural, political and legal, technological, and global. One event may belong to several groups at once.

* * *

## 5.3 Managing the Environment

> Knowing the outside world is useful only if managers act on what they learn.

A manager who knows that a rival has cut prices has learned something useful. The next question is what to do about it. Managers have three broad ways of meeting the external environment: they can watch it, they can fit the organisation to it, and they can try to change it. We take them one at a time, and then we join them into a single plan of response.

@ Environmental scanning | Regularly collecting and studying information about outside changes that could affect the organisation.

> Scanning is the regular watching of outside change, like the clerk and his weather vane.

The harbour clerk's morning habit has a name in management. **Environmental scanning** means regularly collecting and studying information about outside changes that could affect the organisation. A shop owner who reads rivals' online prices every week is performing it. So is a store manager who asks the sales assistants what customers requested and could not find. The word *regularly* matters. A single look is a glance; a habit of looking is scanning.

> Scanning cannot predict the future, but it reduces surprise.

Scanning has limits. It cannot predict the future, because many outside changes have no warning. It also produces more information than anyone can use, so a manager must decide which signals matter. Its value lies in reducing surprise. An organisation that watches the outside world meets a change early, when many responses remain possible. An organisation that does not watch meets it late, when few remain. Scanning is also part of planning, one of the functions in the management process.

> Adapting means changing the organisation to fit an outside force.

The second way is adapting: changing something inside the organisation so that it fits an outside force. A shop that sees buyers moving online may add an online order service. A shop that sees a new school curriculum may change the books it keeps on its shelves. Adapting works because the internal environment is the part that managers can change directly. Its weakness is that the organisation always follows the outside force and never leads it.

> Influencing means acting on the outside force itself, within the limits of law and honesty.

The third way is influencing: acting on the outside force itself, so that it changes in the organisation's favour. A group of shops may join a trade association and put its case to a public body. A shop may advertise to change what customers prefer. Influence has strict limits. A small organisation seldom has the power to change a law or a market. All influence must also stay within the law and within honest dealing, because an organisation that cheats to change its environment damages itself.

> A strategic response is a chosen combination of watching, adapting and influencing.

Managers rarely use one way alone. They choose a combination, and we call that choice a strategic response. A strategic response means the broad choice a manager makes about how the organisation will meet an outside force.^4 The choice depends on two questions. How strong is the force? How much power does the organisation have to change it, or to change itself? A strong force and a weak organisation usually call for adapting. A weak force may call only for watching.

^4: A strategy is a broad plan for reaching a goal. Plans are taught later in Chapter 7, 'Planning: Meaning, Nature and Steps', section 7.1 'What Planning Is'. Here, the phrase *strategic response* needs only the plain meaning given in the text.

> The case file records how Meghna and Sons responded on 3 March 2026.

:case Case file, illustrative. Response of 3 March 2026: Meghna and Sons issued a price-match list covering 200 titles. Price-matching means selling a listed title at the price a rival charges for it. The record shows the earlier sequence: online price cuts of about 15% on textbooks since March 2025; textbook sales of Tk 4,300,000 in 2025 against Tk 5,100,000 in 2024.

> The price-match list is a case of adapting, because the shop changed its own prices.

The price-match list is a case of adapting. The shop did not try to change the rivals' prices, and it did not try to change the law. It changed something it controls directly, which is its own price list. It also limited the change to 200 titles, which is a choice about where the pressure was strongest. From the viewpoint of the owner, the list protects sales. From the viewpoint of a customer, it removes one reason to buy elsewhere. From the viewpoint of the store manager, it adds work, because each price on the list must be checked against the rivals' prices.

> Adapting has a limit: matching a rival's price can reduce the shop's profit on each copy.

Adapting has a cost, and the cost deserves attention. When a shop matches a lower price, it earns less on each copy sold. The shop must therefore ask whether the extra copies sold will make up for the lower profit on each. That question is one of effectiveness and productivity, the two measures of management taught earlier. A response that wins customers but loses money has not solved the problem.

> The recap fixes the three ways of meeting the environment.

*Before moving on.* Scanning means watching the outside world on a regular basis. Adapting means changing the organisation to fit an outside force. Influencing means acting on the outside force itself. A strategic response is the chosen combination of these, matched to the strength of the force and the power of the organisation.

* * *

## Worked Case: Sorting the Outside Changes of 2025 and 2026

> The worked case applies the chapter's ideas to the records of Meghna and Sons.

This section applies the ideas of the chapter to the records of Meghna and Sons. It does not give a model answer. It shows one way of reasoning, step by step, so that you can follow each decision and then repeat it on a new situation.

> The situation lists every change in the record.

*Situation.* The shop's records for 2025 and 2026 list four changes. First, online price cuts of about 15% on textbooks since March 2025. Second, textbook sales of Tk 4,300,000 in 2025 against Tk 5,100,000 in 2024. Third, a curriculum change from January 2026. Fourth, the departure of 2 of the 7 employees in 2025. A fifth record is a response: the price-match list for 200 titles, issued on 3 March 2026.

> The question asks for three sortings of each change.

*Question.* For each change, decide whether it is internal or external. For each external change, name the group or groups to which it belongs. Then decide whether the response of 3 March 2026 is adapting or influencing.

> Reasoning begins with the boundary test: can the manager change it directly?

*Reasoning.* Begin with the boundary test from section 5.1: can the managers change this condition directly? The departure of 2 employees fails the test as a cause, but passes it as a result, because the owner can hire and train. It is internal. The price cuts do not pass the test. The owner cannot command a rival's price list, so they are external. The curriculum change is external for the same reason. The fall in textbook sales is a result recorded in the shop's own books, but its cause lies partly outside the door, so we treat it as the effect of external forces.

> The table records the sorting of each change.

Now we sort each external change into groups, using the five groups and the task environment. The table below shows the result. Read each row from left to right: the change, the inside or outside decision, and the groups that fit.

:table Sorting the recorded changes
| Change | Inside or outside | Groups that fit |
| Online price cuts of about 15% | Outside | Economic, technological, task environment |
| Curriculum change from January 2026 | Outside | Political and legal; task environment (schools) |
| Fall in textbook sales | Result in the shop's books | Effect of the forces above |
| Departure of 2 of 7 employees | Inside | Internal environment |

> The response is adapting, because it changes only what the shop controls.

The price-match list changes the shop's own prices. The owner controls that directly, so the response is adapting. No part of the record shows an attempt to change the rivals or the law, so nothing here is influencing.

> The conclusion states the sorting in plain sentences.

*Conclusion.* Three of the four recorded changes are external or result from external forces, and one is internal. The shop met the price cuts by adapting. The record does not show scanning as a regular habit, so the next question for the managers is how they will learn of the next change early.

> The check tests the arithmetic and guards against a false conclusion.

*Check.* We test the numbers. The fall in textbook sales is Tk 5,100,000 minus Tk 4,300,000, which equals Tk 800,000. As a share of the 2024 figure, Tk 800,000 divided by Tk 5,100,000 equals about 0.157, or 15.7%. That is close to the 15% price cut, but it does not prove that the price cuts caused the fall, because other forces may also have acted. The curriculum change began in January 2026, after the 2025 fall, so it cannot explain that fall. A careful manager keeps these facts apart.

* * *

## Summary

> The summary restates the chapter in five sentences.

The internal environment is what managers can change directly. The external environment is what they can only study, prepare for or influence. The boundary follows control, not distance. Outside forces fall into five groups: economic, social and cultural, political and legal, technological, and global. The groups of forces that deal directly with the organisation form the task environment. Managers meet the environment by scanning, by adapting and by influencing, and they combine these ways in a strategic response.

## Think It Through

> Four situations test the chapter, from familiar to combined.

Each question below changes the situation a little more than the one before. Answer them in order.

:q 5.t1 | A school near a bookshop moves its book list to a new publisher. Is this change internal or external for the shop? Name the group that fits best.
:q 5.t2 | Suppose the shop's own stock clerk, and not the school, proposed the new list. Does your sorting change? Explain using the boundary.
:q 5.t3 | A government raises the tax on imported books. Name the group, and say whether the change is inside or outside a bookshop's boundary. Give one response that is adapting and one that is influencing.
:q 5.t4 | A small clinic finds that 2 of its 5 nurses have left, a new clinic has opened across the road, and a new rule requires extra records. Sort the three changes. Then explain why watching them is part of planning in the management process.

## Where People Go Wrong

> Mistake one: believing that the environment is only what lies outside.

Some students believe that the environment means only what lies outside the organisation. This is incomplete. The internal environment is also part of the environment of a manager's work. The word *external* tells us which part lies beyond the boundary, and the word *internal* tells us which part lies within it.

> Mistake two: believing that managers can only react.

Some students believe that managers can only react to outside forces. In fact they can adapt, and in some cases they can influence. The correction has a limit, however. A small organisation can rarely influence a large force, and all influence must remain lawful and honest.

> Mistake three: placing each force in only one group.

Some students try to place each outside force in exactly one group. An online price cut is economic, technological and part of the task environment at once. The groups are tools for noticing, not boxes with rigid walls.

> Mistake four: believing that scanning predicts the future.

Some students believe that scanning predicts the future. It does not. It collects information about changes that have begun, so that managers meet them early. The value of scanning is a smaller surprise, not certainty.

## In History

> Nokia, a leader in mobile phones, sold its phone business in 2013 after a shift in its market.

Nokia is a company from Finland. For many years it was the largest maker of mobile phones in the world by number sold. In 2007 the American company Apple released the iPhone, a phone that worked as a small computer with a touch screen. Phones that used Google's Android software soon followed. Nokia chose Microsoft's Windows Phone software for its phones, and its first Windows Phone devices reached customers in late 2011.

> The sale was announced on 3 September 2013 and approved by shareholders on 19 November 2013.

On 3 September 2013, Nokia announced that it would sell its devices and services business to Microsoft, the American software company. The total price was €5.44 billion. Of that sum, €3.79 billion paid for the business and €1.65 billion paid for a licence to use Nokia's patents. About 32,000 Nokia employees were to move to Microsoft. On 19 November 2013, Nokia's shareholders approved the sale by a very large majority of the votes cast.

> Writers still debate the causes, but the case shows the environment at work.

Writers still debate why the change happened. Some stress the company's software and the speed of its decisions. Others stress the force of the new competitors. We do not need to settle that debate here. The case shows three ideas from this chapter. A technological change altered what customers wanted. Rivals in the task environment moved quickly. A strategic response that comes late may leave few choices. Nokia remained in business after the sale, with its network equipment business and its patents.

## Review Questions

:q 5.1 | Sort these forces as internal or external: a rival's price cut; a new store manager; a change in school book rules; the shop's own opening hours.
:q 5.2 | In your own words, state the difference between the internal environment and the external environment. Explain how the boundary decides which is which.
:q 5.3 | Name the five groups of wider forces. Give one example of each for a bookshop.
:q 5.4 | Explain the difference between scanning, adapting and influencing. Say which one the price-match list of 3 March 2026 is.
