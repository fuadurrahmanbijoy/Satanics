:chapter XII | Organizing and Types of Organization
:mood Who does what, and who answers to whom?
:desc A goal cannot be reached by good intentions alone; someone must decide who does which task. This chapter explains organizing, the steps by which managers divide and link work, and the difference between the official structure and the friendships that grow beside it.
:plate ch12-plate.svg | A railway office where a great wall chart shows every department of the company

> Two earlier ideas support this chapter.

You will need two ideas from earlier chapters. The first is the management process, taught in Chapter 3, 'The Functions of Management and How Management Is Judged', section 3.1 'The Management Process'.^1 The second is the organisation, taught in Chapter 1, 'What Management Is', section 1.1 'The Idea of Management'.^2 Read those sections again if either idea feels uncertain.

^1: Recall: management process, Chapter 3, 'The Functions of Management and How Management Is Judged', section 3.1 'The Management Process'.
^2: Recall: organisation, Chapter 1, 'What Management Is', section 1.1 'The Idea of Management'.

> A railway with no division of duties would stop at its first emergency.

Imagine a railway company in the middle of the nineteenth century. Its track runs for hundreds of miles, and every day trains leave and arrive at stations far from the head office. On a winter morning a telegraph message reaches the head office: a bridge near a distant town has been damaged, and a passenger train is due to cross it in two hours. Several people in the office read the message. Each of them knows that something must be done. Each of them believes that another person will do it.

> The puzzle is that everyone sees the danger and no one is told to act.

This is the puzzle of the chapter. The company has money, engines, track and willing workers, yet it may fail on this morning, because no one has been told that the message is his or her responsibility. Good intentions do not move a train. What the company lacks is an arrangement: a known answer to the question *who does what, and who answers to whom?* An organisation that cannot answer that question for every task will meet the same danger again and again, however skilled its people may be.

> The chapter will name the arrangement, show how it is made, and meet its unofficial twin.

In this chapter we study that arrangement. First we name it and say why it exists. Then we follow the steps by which a manager builds it. Finally we meet two forms that it takes: the one managers draw on paper, and the one that people form among themselves without any instruction. We shall use the records of a small Dhaka bookshop to practise, and a famous railway chart of 1855 to see where the idea first took a clear shape.

* * *

## 12.1 What Organizing Is

> A household shows that many tasks need a plan of who does what.

Think first of a household that is preparing a wedding meal. There are dishes to buy, to cook and to serve, guests to welcome, and a bill to pay. If every relative does whatever seems useful at the moment, some tasks are done twice and others not at all. A sensible family leader says: you buy, you cook, you serve, you welcome. The meal succeeds because the work was divided and each person knew the share that was his or hers. Management uses the same idea on a larger scale.

@ Organizing | Arranging tasks, people and resources into a working structure so that goals can be reached.

> Organizing is the function that arranges work, people and resources into a structure.

The function that does this has a name. **Organizing** means arranging tasks, people and resources into a working structure so that goals can be reached. A resource is anything an organisation uses to do its work, such as money, rooms, machines and time. When a bookshop owner decides who will buy books, who will serve customers and who will keep accounts, the owner is organizing. Organizing is one of the functions in the management process, and it follows planning, because the manager must know what is to be done before arranging who will do it.

@ Organizational structure | The pattern of jobs, groups and reporting lines that divides and links the work.

> The result of organizing is an organizational structure.

Organizing is an activity, and it leaves a result behind. We call the result the **organizational structure**, which means the pattern of jobs, groups and reporting lines that divides and links the work. A reporting line is the path that shows which person answers to which other person. In a bookshop the structure answers questions such as these: Who orders books? Who may refuse a refund? To whom does the cashier bring a problem? The structure exists whether or not anyone has drawn it.

@ Structure | Word in use. In daily life, a building or other object that has been put together. In management, the pattern of jobs and reporting lines inside an organisation.

> The purpose of organizing is to turn a goal into jobs that people can perform.

Why do organisations organize at all? The first purpose is to turn a large goal into jobs of a size that one person can perform. No one can sell the books, count the stock and keep the accounts at the same moment. The second purpose is to avoid waste. When each task has an owner, it is neither forgotten nor done twice. The third purpose is to link the parts, so that the work of the buyer reaches the seller in good order. These three purposes serve the aim of the whole management process, which is to reach goals with productivity and effectiveness.

> From each viewpoint, organizing gives something different.

The same arrangement looks different from each viewpoint. The owner sees a way to reach the shop's goals without doing every task personally. The manager sees a tool for checking whether any task has been left without an owner. The employee sees a fixed answer to the question *what is my job, and to whom do I turn?* The customer, who never sees the structure, feels its results when the right person answers a question without delay.

> Organizing has a nature: it is continuous, it serves goals, and it follows people and work.

Organizing also has a nature that is worth knowing, because it prevents three errors. First, organizing is continuous. A structure that suited a shop with three employees may fail when the shop has seven, so managers return to it whenever the work changes. Second, organizing serves goals. A structure is judged by whether it helps the organisation reach its goals, and not by whether it looks neat on paper. Third, organizing deals with people as well as tasks. A perfect plan of duties can fail if the people who must perform it do not understand or accept it.

> Exceptions: a structure can help in one setting and harm in another.

There are limits to what organizing can do. A structure cannot repair a poor plan, because it only arranges the work that the plan has set. Too much structure can also slow an organisation: if every small question must travel through several reporting lines, customers wait and employees lose interest. A good structure is therefore the lightest one that still makes every task and every reporting line clear.

:box IN SHORT
Organizing is the function that arranges tasks, people and resources. Its result is the organizational structure. Its purpose is to make every task owned, every owner known and every part linked to the others.

> The recap fixes the function, its result and its purpose.

*Before moving on.* Organizing is the function of arranging tasks, people and resources into a working structure. The structure is the pattern of jobs, groups and reporting lines. Its purpose is to give every task an owner and to link the parts. It is continuous, it serves goals, and it must be judged by its results.

* * *

## 12.2 The Organizing Process

> Building a structure can be learned as four ordered steps.

A manager who must organize a shop does not need a special gift. The work can be done in four ordered steps: identify the tasks, group the tasks, assign the duties, and set the relationships. We shall follow each step with the same example, a small bookshop, so that you can see how one step leads to the next. Many students find this process confusing at first because the steps seem to blend together. They become clear when each step is asked a single question.

> Step one asks: what work must be done?

*Step one: identify the tasks.* The question of this step is *what work must be done?* The manager lists every task that the shop must perform to reach its goals, from the largest to the smallest. The list should come from the plan and not from the names of the people who are available, because a list built around people will hide the tasks that nobody has yet considered. At this step the manager does not ask who will do each task. Only the work is listed.

> The case file records the ten duties of Meghna and Sons in 2026.

:case Case file, illustrative. Duties recorded at Meghna and Sons for 2026, ten in number: buying, receiving, shelving, selling, cashier, accounts, online orders, returns, school accounts and marketing. The ten duties are assigned to 7 people.

> Ten duties and seven people show that some people must hold more than one duty.

The record gives a useful fact: there are ten duties and seven people. Ten divided among seven cannot give one duty to each person, so at least some people hold more than one duty. This is normal in a small organisation. It also shows why the next two steps matter, because the manager must decide which duties belong together in one person's hands.

> Step two asks: which tasks belong together?

*Step two: group the tasks.* The question of this step is *which tasks belong together?* Tasks belong together when they need the same skill, use the same place, or depend closely on one another. Receiving books, shelving books and handling returns all involve the stockroom and the physical books, so a manager may place them in one group. Selling and the cashier's work both happen at the counter, so they may form another group. A group of tasks is the first step from a list to a pattern.

> There is no single correct grouping, so the manager must judge the shop's own situation.

Another manager might group the same ten duties in a different way. Online orders and school accounts both deal with customers who never walk into the shop, and a manager could place them together. The best grouping depends on the people available and the work to be done. This is a place where judgement is needed, and the guide is the purpose of organizing: whichever grouping makes tasks owned, linked and free of waste serves the shop best.

> Step three asks: who will do each group of tasks?

*Step three: assign the duties.* The question of this step is *who will do each group of tasks?* The manager now turns to people. A duty is a task that a named person is expected to perform. The manager matches each group to the person with the skill and the time to perform it. In the base record of the shop, for example, Tariq Meghna already handles accounts and online orders. That assignment shows how a manager keeps related tasks together in one person's hands.

> Assigning a duty is incomplete unless the person also has the means and the authority to perform it.

Assigning a duty is not complete until the person has what is needed to perform it. A cashier who must handle returns needs a rule that says how much money may be refunded without asking anyone. The right to take such decisions is called authority, which was taught earlier as the right to command or to decide. A duty without authority leaves the person unable to act, and authority without a duty leaves the organisation without an owner for the task.

> Step four asks: who answers to whom, and who works with whom?

*Step four: set the relationships.* The question of this step is *who answers to whom, and who works with whom?* The manager decides the reporting lines. In the bookshop, the sales assistants may report to the store manager, and the store manager may report to the owner. The manager also decides how groups share information, for example how the stock clerk tells the sellers that a new delivery has arrived. Without this step, the groups would work well alone and badly together.

@ Organization chart | A diagram showing the jobs in an organisation and who reports to whom.

> The organization chart is a drawing of the result of the four steps.

When the four steps are complete, the manager can draw the result. An **organization chart** is a diagram showing the jobs in an organisation and who reports to whom. Each job is shown in a box, and lines join the boxes to show the reporting lines. The figure below shows a small example. To read it, begin at the top box, which holds the highest authority. Follow a line downward from a box to meet the jobs that report to it. A line always joins two boxes and means *reports to*, read from the lower box to the upper box.

:fig An organization chart with lines of authority | ch12-fig01.svg

@ Chart | Word in use. In daily life, a table or picture that shows numbers, such as a chart of rainfall. In management, a diagram of jobs and reporting lines.

> A chart shows the official lines only, and it can become out of date.

An organization chart has two limits. It shows only the official lines and nothing of the friendships and habits that also guide behaviour; we shall meet those in the next section. It can also become out of date, because a chart drawn in January may not describe the shop after two people leave in March. A chart is a record of a decision, and the manager must update the record when the decision changes.

> Common slips in the process: skipping a step, or building the chart around people.

Students often make two slips in this process. The first is to skip step one and begin with the people, which makes the list of tasks fit the people instead of the goals. The second is to draw the chart first and decide the duties later, which produces boxes with no real work in them. Keeping the order of the steps prevents both slips.

:pause 12.p1 | A shop has three sales assistants and one cashier. Name the step in which the manager decides that all four report to the store manager.

> The recap fixes the four steps and the chart.

*Before moving on.* The four steps are to identify the tasks, group the tasks, assign the duties and set the relationships. Assigning a duty means giving the person the means and the authority to perform it. The organization chart is the drawing that records the result.

* * *

## 12.3 Formal and Informal Organization

> A shop has an official pattern, and a second pattern that nobody drew.

Walk into a bookshop at noon and watch for a moment. The official pattern is easy to find: the cashier stands at the counter, the stock clerk carries boxes, and the store manager walks between them. Now watch where people stand during a quiet hour. Some of them gather in small groups, talk about books and families, and pass along advice that no one has ordered them to give. A second pattern has formed beside the first. Both patterns shape how the shop works, and a manager who sees only the first will often be surprised by the second.

@ Formal organization | The official structure of jobs, rules and lines of authority that management sets up.

> The formal organization is the official structure that management sets up.

The first pattern is the **formal organization**. It means the official structure of jobs, rules and lines of authority that management sets up. It is deliberate, which means that managers choose it on purpose. It is usually written down, in job descriptions, rules and the organization chart. Everything we studied in section 12.2 produces a formal organization, because the four steps are decisions that management takes and records.

> The formal organization gives order, stability and clear authority, but it can be slow.

The formal organization has real strengths. It gives each employee a known job and a known person to ask. It lasts when individuals come and go, because the jobs remain even when the people change. It supports the control of work, since someone is answerable for each task. Its weakness is that it cannot describe everything people do. Official rules cannot foresee each small situation, and an organisation that relies only on its rules can become slow and stiff.

:pause 12.p2 | A shop's job description says that the stock clerk reports to the store manager. Is this part of the formal or the informal organization? Give one reason.

@ Informal organization | The network of friendships and social groups that forms among employees on its own.

> The informal organization is the network of friendships that forms without management's instruction.

The second pattern is the **informal organization**. It means the network of friendships and social groups that forms among employees on its own. No manager designs it, no document records it, and it has no official leader. It appears wherever people work together over time. Employees who share a bus route, a hometown or an interest in poetry will talk to one another more than the chart would predict, and a group of friends is the usual result.

> The case file records an informal group at Meghna and Sons.

:case Case file, illustrative. In 2026, 3 sales assistants at Meghna and Sons form a lunch group and exchange book tips informally. The record places the group beside the formal structure and does not show it on the organization chart.

> The lunch group is informal, because no manager created it and it appears on no chart.

The lunch group is part of the informal organization. No manager created it. No chart records it. Yet it does useful work: when one sales assistant learns which new title a school teacher has asked about, the others hear it at lunch. The knowledge reaches the counter faster than any written notice would. This example shows an important point. The informal organization is neither good nor bad in itself. Its effect depends on what the group does and on how it relates to the goals of the shop.

> People join informal groups to meet needs that the official structure does not meet.

Why do people join informal groups? The reasons are ordinary ones. Employees want company, because work fills much of the day and people dislike spending it alone. They want help, because a colleague can often explain a task faster than a manual. They want information, because the official channels are slow or incomplete. They want to feel that they belong and that their opinion counts. Each of these is a need that the formal structure rarely meets, and the informal group meets it. We shall study such needs in detail in the chapter on motivation.

> Informal groups can help or harm, so managers must neither ignore nor attack them.

The effects of informal groups can be good or bad. A helpful group shares knowledge, supports new employees and builds loyalty. A harmful group can spread false rumours, resist a reasonable change, or protect a colleague who has done poor work. A manager who tries to forbid all informal groups will fail, because friendships grow wherever people meet, and the attempt will anger employees. A wiser manager learns which groups exist, listens to them, and uses their strengths for the goals of the organisation.

> The two organizations are not rivals; they work together inside one organisation.

The two patterns are therefore not rivals. They exist side by side inside one organisation, and each fills a gap in the other. The table below sets them side by side. Each row names a feature, and the two columns say how the feature appears in each kind. Read across a row to compare the two on one feature.

:table Formal and informal organization compared
| Feature | Formal organization | Informal organization |
| Origin | Set up by management | Grows among employees on its own |
| Record | Written: rules, job descriptions, chart | Unwritten: habits, friendships |
| Authority | Comes from the position held | Comes from the respect of the group |
| Main strength | Order and stability | Speed and goodwill |
| Main risk | Slowness and stiffness | Rumour and resistance |

> Making an organization effective means designing the formal structure while working with the informal one.

How can managers make an organisation effective, then? They begin with a sound formal structure: every task has an owner, every reporting line is clear, and the chart is kept up to date. They then treat the informal organization as a fact of the shop and not as an enemy. Managers share honest information, so that rumour has less room. They ask informal groups for ideas, because those groups often know where the work is going wrong. They also watch for harm, and they speak plainly when a group acts against the shop's goals.

> The recap fixes the two kinds and the way they work together.

*Before moving on.* The formal organization is the official structure that management sets up. The informal organization is the network of friendships that forms on its own. People join informal groups to meet needs the formal structure does not meet. Managers make an organisation effective by designing the formal structure well and by working with the informal groups.

* * *

## Worked Case: Organizing the Duties of Meghna and Sons

> The worked case applies the four steps to the shop's ten duties.

This section applies the process of section 12.2 and the distinction of section 12.3 to the shop's records. It is not a model answer. It shows one way of reasoning, so that you can follow each decision and then repeat it on a new case.

> The situation gives the duties, the people and the lunch group.

*Situation.* The shop's record for 2026 lists ten duties: buying, receiving, shelving, selling, cashier, accounts, online orders, returns, school accounts and marketing. They are assigned to 7 people. The base record names the people: Rafiq Meghna, the store manager; Tariq Meghna, who handles accounts and online orders; 3 sales assistants; 1 cashier; and 1 stock clerk. A lunch group of 3 sales assistants exchanges book tips informally.

> The question asks for a grouping, an owner for each group, and the place of the lunch group.

*Question.* Group the ten duties into a small number of groups. Decide how many duties fall to each person on average. Then say where the lunch group belongs in the structure.

> The reasoning applies steps two to four in order.

*Reasoning.* Step one is already done, because the record lists the ten tasks. For step two, we look for tasks that share a skill or a place. Buying, receiving, shelving and returns all concern the physical books, so they form a stock group of 4 duties. Selling and the cashier's work both happen at the counter, so they form a counter group of 2 duties. Accounts, online orders, school accounts and marketing all deal with records or with customers who are not at the counter, so they form a records-and-outside-customers group of 4 duties. The grouping is one reasonable choice, and the file does not say which choice the shop made.

> For step three, the base record already gives one assignment, and the other assignments are not recorded.

For step three, the base record states that Tariq Meghna handles accounts and online orders, and both duties sit in the third group. That agrees with our grouping, which is a useful sign. The file does not record who holds the other duties, so we do not invent assignments. We can, however, work out how heavy the load is. Ten duties among seven people give an average of 10 divided by 7, which is about 1.4 duties per person. For step four, the store manager would take the reporting of the stock group and the counter group, and the owner would receive reports from the store manager and from Tariq Meghna.

> The lunch group is informal, so it stays off the chart but not out of the manager's view.

The lunch group of 3 sales assistants is informal. It has no place on the organization chart, because no manager created it and it carries no authority. The store manager should still know of it, because the group already carries useful knowledge about which books customers ask for.

> The conclusion states the structure and the status of the lunch group in plain sentences.

*Conclusion.* The shop's ten duties fall into three groups of 4, 2 and 4 duties. The load is about 1.4 duties per person on average, so some people hold more than one duty. The lunch group belongs to the informal organization, and managers should use it, not suppress it.

> The check tests the counting and guards against a hidden gap.

*Check.* We test the counting. The groups give 4 plus 2 plus 4, which equals 10, so no duty is lost or counted twice. The load check: 7 people times 1 duty each gives only 7 duties, so 10 − 7 = 3 duties must be additional ones. This confirms that at least some people hold two duties. The shop should also confirm each person's duties in writing, because a task that is not assigned is the first step toward the puzzle that opened this chapter.

* * *

## Summary

> The summary restates the chapter in a few sentences.

Organizing is the function that arranges tasks, people and resources into a working structure. Its result is the organizational structure, the pattern of jobs, groups and reporting lines. The process has four steps: identify the tasks, group the tasks, assign the duties and set the relationships. The organization chart records the result. Beside the formal organization, which management sets up, an informal organization of friendships forms on its own. Effective managers design the formal structure well and work with the informal groups.

## Think It Through

> Four situations test the chapter, from familiar to combined.

Each question below changes the situation a little more than the one before. Answer them in order.

:q 12.t1 | A bookshop has these tasks: ordering books, serving customers, counting cash. Group them into two groups and give a reason for your grouping.
:q 12.t2 | Suppose the same shop adds a task of delivering books to schools. Where would you place it, and how does your answer show that grouping needs judgement?
:q 12.t3 | A small clinic has a doctor, two nurses and a receptionist. Three employees eat lunch together every day and share news about patients' appointments. Is this group part of the formal or the informal organization? Explain whether the manager should be pleased or concerned.
:q 12.t4 | A shop doubles its number of employees and keeps the same chart. Name two problems that may appear, using the ideas of structure and the formal and informal organization.

## Where People Go Wrong

> Mistake one: believing that the chart is the organisation.

Some students believe that the organization chart is the organisation. The chart is only a drawing of the formal structure at one moment. It leaves out the friendships and habits that also guide behaviour, and it may be out of date.

> Mistake two: believing that informal groups are always harmful.

Some students believe that informal groups are always harmful. In the lunch group of the case file, the informal group carried useful knowledge. The correction has a limit: informal groups can also spread rumour or resist change, so a manager must judge each group by its effects.

> Mistake three: believing that organizing is only drawing boxes.

Some students believe that organizing is only drawing boxes and lines. The drawing comes at the end. The real work lies in identifying tasks, grouping them, assigning duties with the means to perform them, and setting relationships.

> Mistake four: confusing the structure with its effects.

Some students confuse a structure with its results. A structure that looks neat can still fail if people do not understand it or if it does not serve the goals of the organisation. A structure is judged by its results.

## In History

> Daniel McCallum drew an early organisation chart for the Erie Railroad in 1855.

In 1855 the New York and Erie Railroad was one of the longest railways in the United States. Its general superintendent, Daniel McCallum, faced the problem of the opening puzzle on a large scale: a company spread over many miles, in which messages travelled quickly by telegraph but responsibility for acting on them was unclear. McCallum worked with a civil engineer, George Holt Henshaw, to prepare a diagram of the company's plan of organization. It is dated by the returns of September 1855.

> The chart showed divisions, duties and the number of employees in each department.

The diagram showed the division of duties and the number and class of employees in each department. It was drawn in the form of a tree, in which the highest authorities stood at the roots and the departments and staff spread out as branches. Divisional superintendents were responsible for the daily work of the lines under them, and regular reports travelled upward to the central office. Historians commonly regard the diagram as one of the first modern organization charts. McCallum also set down general principles of management, and he later worked on military railways during the American Civil War.

> The case shows that a drawn structure can make responsibility known across a large organisation.

The case shows an idea from this chapter at work. A structure turns a large undertaking into duties with known owners and known reporting lines. The tree shape also shows why the chart is useful: it lets any person trace the line from a task to the authority above it. The diagram does not describe the friendships among the railway's workers, which formed informally as in every workplace.

## Review Questions

:q 12.1 | Separate these into formal or informal: the job description of a cashier; a lunch group of friends; the reporting line from stock clerk to store manager; a habit of sharing book tips at noon.
:q 12.2 | State the four steps of the organizing process in order, and say which question each step answers.
:q 12.3 | In your own words, give the difference between the formal organization and the informal organization. Give one strength of each.
:q 12.4 | Explain why people join informal groups, and say how a manager can work with such groups.
