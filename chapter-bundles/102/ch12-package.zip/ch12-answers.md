:answers 12
:a 12.p1 | Step four, set the relationships, because it decides who answers to whom.
:a 12.p2 | Formal. The job description and the reporting line were set up by management and are written down.
:a 12.t1 | One grouping: stock tasks (ordering books) and counter tasks (serving customers, counting cash). The reason is that the counter tasks happen at the same place and use the same dealing with customers and money.
:a 12.t2 | It could join the group with ordering books if the delivery depends on stock, or it could join a group of tasks for customers away from the counter. Either answer is reasonable, which shows that grouping needs judgement guided by the purpose of organizing.
:a 12.t3 | Informal, because no manager set it up. The manager should be pleased that staff share useful information, and concerned only if private patient details are passed on carelessly or if rumour spreads.
:a 12.t4 | The chart may be out of date, with tasks that nobody owns and reporting lines that are too long. The informal organization may also grow in new groups that spread rumour, because the formal structure no longer links the larger staff.
:a 12.1 | Formal: the cashier's job description and the reporting line from stock clerk to store manager. Informal: the lunch group and the habit of sharing book tips at noon.
:a 12.2 | Identify the tasks (what work must be done?); group the tasks (which tasks belong together?); assign the duties (who will do each group of tasks?); set the relationships (who answers to whom, and who works with whom?).
:a 12.3 | The formal organization is the official structure of jobs, rules and lines of authority that management sets up. The informal organization is the network of friendships that forms on its own. The formal one gives order and stability; the informal one gives speed and goodwill.
:a 12.4 | People join to meet needs such as company, help, information and belonging. A manager can learn which groups exist, listen to them, share honest information and use their strengths, while watching for harm.
