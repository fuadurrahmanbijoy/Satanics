:glossary 08
Standing plan | A plan made once and used again and again for situations that repeat. It saves thought and gives fair, equal treatment. Example: a shop's returns policy, applied to every customer who asks to exchange a book.
Single-use plan | A plan made for one occasion or project and not used again. It has a start and an end. Example: the plan for a 28-day book fair stall, which will not be repeated in the same form.
Policy | A general guide for decisions, setting limits within which choices are made. It guides but leaves room for judgement. Example: "We exchange books within 7 days", where the employee decides about a damaged book on the last day.
Procedure | A fixed series of steps to be followed for a repeated task. It says how to do the work, in a fixed order. Example: ask for the receipt, check the date, check the book, give the new book, record the exchange.
Budget | A plan that states expected income and spending in money terms for a period. It turns plans into figures. Example: a book fair budget with planned spending of Tk 240,000 and expected sales of Tk 900,000.
