:chapter VIII | Kinds of Plans and Making Planning Work
:mood Must a manager think everything out again each morning?
:desc This chapter sorts plans into kinds: those used again and again, and those used once. It shows how plans differ by length of time and by level, and it explains what makes planning work in practice. The examples come from a bookshop's returns, a book fair and a yearly budget.
:plate ch08-plate.svg | A staff officer's table with maps and pins on the eve of a landing

:box YOU WILL NEED
This chapter builds on two earlier ideas. The first is what planning is and why it is done, in Chapter 7 'Planning: Meaning, Nature and Steps', section 7.1 'What Planning Is'. The second is the list of activities that every manager performs, in Chapter 3 'The Functions of Management and How Management Is Judged', section 3.1 'The Management Process'.

> A shop must answer the same customer question many times and a rare question once.

Picture the counter of a bookshop on a busy Saturday. A customer asks to return a book. Ten minutes later, another customer asks the same thing. By the end of the day, six customers have asked. Must the manager think the problem through six times, and perhaps give six different answers? That would waste time, and it would be unfair, because one customer might be helped and another refused for the same reason.

> A rare event, such as a book fair, needs its own careful thought.

Now picture a different day. The shop is invited to run a stall at a book fair that lasts four weeks and will not be repeated. No earlier answer exists for this event, because it has never happened before. The manager must think it through once, with great care, and then the thinking will be finished. Is it sensible to treat the two days in the same way? Surely not.

> The answer is to use different kinds of plan for repeated and one-time situations.

The puzzle shows that plans are not all alike. Some are made once and used many times, so that the manager can save thought for harder problems. Others are made once for one occasion and then set aside. In Chapter 7 we learned how to make a plan by following five steps. This chapter asks a new question: what kinds of plan exist, and how can a manager make planning work in daily life? We begin with the main division.

* * *

## 8.1 Kinds of Plan

> Plans divide into those used repeatedly and those used once.

How can we sort the many plans that a shop makes? A useful first step is to ask whether the plan will be used again. If it will, it belongs to one group. If it will not, it belongs to the other. Almost every plan fits one group or the other, and the sorting question is easy to ask.^1

^1: The meaning of a plan and the steps of planning are set out in Chapter 7 'Planning: Meaning, Nature and Steps', section 7.1 'What Planning Is'.

### Standing Plans

> A standing plan is made once and used again for situations that repeat.

@ Standing plan | A plan made once and used again and again for situations that repeat.

The first group is the **standing plan**. A standing plan is a plan made once and used again and again for situations that repeat. For example, a shop that decides how to answer returned books once, and then applies the same answer to every customer, uses a standing plan. The word "standing" tells us that the plan remains in place, like a post that stays upright from day to day.

> Standing plans save thought, give fair treatment and let employees decide alone.

Standing plans give three benefits. They save time, because the manager does not decide the same question again. They give fair treatment, because every customer meets the same answer. They let employees act without waiting for the manager, because the answer is already written. The cost is that a standing plan can grow old: if conditions change and the plan does not, it may lead people to the wrong action.

### Single-Use Plans

> A single-use plan is made for one occasion and then set aside.

@ Single-use plan | A plan made for one occasion or project and not used again.

The second group is the **single-use plan**. A single-use plan is a plan made for one occasion or project and not used again. A book fair that happens once, a move to a new building and the opening of a branch are all examples. Once the occasion is over, the plan has no further use, although the manager may learn from it when making the next one.

> Single-use plans fit rare events, while standing plans fit repeated ones.

The two groups answer different needs. Think of the owner's viewpoint. The owner wants the repeated questions answered cheaply and the rare event answered carefully. The employee's viewpoint is different: the employee wants to know quickly what to do about a returned book, and has little need to know about a book fair that will not return. A well-run shop therefore keeps a small collection of standing plans for daily work, and writes a new single-use plan for each large event.

:pause 8.p1 | A shop plans a one-day sale to clear old stock. Is its plan a standing plan or a single-use plan? What would change your answer?

### Policy, Procedure and Rule

> Three kinds of standing plan differ in how much freedom they leave.

Standing plans come in three common forms. They differ in one respect: how much freedom each leaves to the person who follows it. A policy leaves the most freedom, a procedure leaves less, and a rule leaves none. The table below sets them side by side. Read it row by row: the left column names the form, the middle column says what it does, and the right column gives a shop example.

:table Three forms of standing plan
| Form | What it does | Shop example |
| Policy | Gives a general guide and sets limits for choices | Returns are accepted only within a set time |
| Procedure | Lists the steps in order for a repeated task | Check the receipt, check the book, record the exchange |
| Rule | Requires one action in one situation, with no choice | No exchange without a receipt |

> A policy is a general guide that sets limits within which choices are made.

@ Policy | A general guide for decisions, setting limits within which choices are made.

A **policy** is a general guide for decisions, setting limits within which choices are made. For example, a shop that decides "we exchange books within a fixed number of days" has set a policy. Within that limit the employee can decide: a customer who returns a damaged book on the last day may be helped, while one who returns an old book may be refused. A policy gives direction and leaves judgement.

> A procedure is a fixed series of steps for a repeated task.

@ Procedure | A fixed series of steps to be followed for a repeated task.

A **procedure** is a fixed series of steps to be followed for a repeated task. Where a policy says what is allowed, a procedure says how to carry it out. For example, the exchange procedure may say: ask for the receipt, check the date, check that the book is undamaged, give the new book, and write the exchange in the record. The steps are always the same, and the order always matters.

> A rule requires one action and leaves no choice, unlike a policy.

@ Rule | Word in use. In daily life, a general way that something is usually done, as in "as a rule, I wake early." In planning, a single required action for one situation, with no choice.

A rule is the narrowest standing plan. It says that in one situation one action must be taken, and the person who follows it has no choice. For example, "no exchange without a receipt" is a rule. The three forms work together: a policy sets the limits, a procedure gives the steps, and a rule fixes the points where no choice is allowed.

> The shop's returns policy is a standing plan for a repeated situation.

:case Case file, illustrative. Plans 2026, standing: returns policy, an exchange within 7 days with a receipt.

> The returns policy shows how one standing plan holds both a policy and a rule.

Read the record carefully. "Exchange within 7 days" sets a limit, and so it is a policy. "With a receipt" is a condition that allows no choice, and so it behaves as a rule. The record does not list the steps, and a procedure for them could be added. The case shows that real plans often mix the three forms in one sentence, and the reader's task is to see each part.

### Programmes and Projects

> A programme is a set of linked single-use plans, and a project is one part of it.

@ Programme | Word in use. In daily life, a television or radio show, or a printed list of events. In planning, a set of linked plans, usually single-use, that together reach a larger objective.

Single-use plans also come in two sizes. A programme is a larger set of linked plans that together reach a large objective, and a project is one defined piece of work within it. For example, a shop that plans a year of school visits may treat the whole year as a programme and each visit as a project. Each project has a start, an end and a person in charge.

> The book fair stall is a single-use plan with a start date and an end date.

:case Case file, illustrative. Plans 2026, single-use: a 28-day book fair stall in February 2026.

> The fair is a project because it begins, ends and is not repeated.

The book fair stall is a project, because it has a start, an end and a fixed length of 28 days, and it will not be repeated in the same form. It is a single-use plan. Notice how this differs from the returns policy, which has no end date and applies every day.

### Budgets

> A budget states expected income and spending in money terms for a period.

@ Budget | A plan that states expected income and spending in money terms for a period.

One more kind of plan is used by almost every organisation. A **budget** is a plan that states expected income and spending in money terms for a period. For example, a family might write that it expects to receive a fixed income this month and plans to spend part of it on food. A budget turns the plans of the shop into figures, so that the manager can see whether the shop can afford them.

> Budgets can be standing or single-use, depending on the period they cover.

A budget may cover a short event or a whole year. The yearly budget is renewed every year, so it is repeated in form, although the figures change. A budget for one event is used once. This shows that the two main groups are guides and not walls: a plan may have features of both.

> The case file gives the book fair's budget and the yearly sales budget.

:case Case file, illustrative. Plans 2026, book fair budget: spending Tk 240,000 and expected sales Tk 900,000. Yearly budget: sales Tk 15,840,000.

> Comparing expected sales with budgeted spending shows whether the event is worth planning.

Read the record. The book fair has two figures: Tk 240,000 of planned spending and Tk 900,000 of expected sales. The expected sales are larger than the spending, so the event seems worth planning, although the cost of the books themselves must still be counted. Notice that the budget does not guarantee the sales. It states what the manager expects and plans for.

> Section 8.1 in four lines.

*Before moving on.* A standing plan is used again; a single-use plan is used once. Policy, procedure and rule are standing plans, from the most free to the least free. A programme holds linked projects, and a budget states income and spending in money.

* * *

## 8.2 Time Span and Level

> Plans can be sorted by how far ahead they look.

A second way to sort plans is by time. How far into the future does the plan reach? A long-range plan looks several years ahead, often three to five years, or more. A short-range plan looks ahead for a year or less. The shop's plan to open a second branch in five years is long-range. Its plan for next week's staff timetable is short-range. The two are linked, because the short-range plans are the steps that lead toward the long-range plan.

> Plans can also be sorted by level: strategic plans set direction, operational plans do the daily work.

A third way to sort plans is by level. A strategic plan sets the main direction of the whole organisation, such as which customers to serve and which new business to enter. An operational plan states how one part of the organisation will carry out its daily work, such as how many people stand at the counter. Strategic plans are usually made by the owner or top managers and look far ahead. Operational plans are made by lower managers and employees and look a short way ahead. The planning steps of Chapter 7 apply at every level.

> The grid places the main plans by repeat use and by time span.

The figure arranges the plans of this chapter in a grid. Read it as follows: the two columns show whether a plan is used again or used once, and the two rows show whether it looks far ahead or only a short way. Find a plan by choosing its column and its row. The placing is a guide and not a law, because a policy may last for a few months and a project may last for years.

:fig Plans arranged by time span and by repeat use | ch08-fig01.svg

> Short-range plans are the steps that lead toward long-range plans.

Why does the shop need both? A long-range plan alone is too distant to guide the week, and a short-range plan alone has no direction. Suppose the owner wants to open a second branch in five years. That aim is long-range. To reach it, the shop needs a yearly budget, a plan for saving money, and a plan for training a manager for the new branch. These are short-range plans, each a step on the road. A manager checks that every short-range plan points the same way as the long-range one.

> Strategic and operational plans fit together like a frame and its pictures.

The same fitting is needed between levels. The owner's strategic plan says which customers the shop wishes to serve, for example schools and walk-in readers. The store manager then writes operational plans for stock, staff and opening hours that serve those customers. An employee who knows the strategic plan can make better daily choices, because the employee knows the purpose behind the work. Where levels do not fit, effort is wasted.

> Section 8.2 in three lines.

*Before moving on.* Long-range plans look several years ahead and short-range plans a year or less. Strategic plans set direction and operational plans organise daily work. The grid helps to sort plans, but its boundaries are not fixed.

* * *

## 8.3 Making Planning Effective

> A plan that is well made can still fail if the organisation does not support it.

Knowing the kinds of plan is the first half of the lesson. The second half is making them work. Chapter 7 showed that plans fail for many reasons. Four habits help a manager to prevent failure, and each one is explained here with a shop example.

### Support from the Top

> A plan needs the visible support of the owner or senior managers.

The first habit is support from the top. If the owner makes a plan but is seen to ignore it, employees will ignore it too. Support means that senior managers approve the plan, give it money and time, and follow it themselves. In a family shop, this means the owner follows the returns policy in the same way as an assistant must. If the owner makes an exception for a friend, the policy loses its force.

> Without support, a plan competes with daily work and loses.

Consider the viewpoints. The owner supports a plan by following it. The store manager supports it by giving employees time to learn it. The employee supports it by using it and by reporting what does not work. When one of these three withdraws support, the plan weakens, because people watch what their leaders do and not only what they say.

### Clear Objectives

> A plan is useful only if its objective is exact and shared.

The second habit is clear objectives. An objective is the result that has been chosen as the target. If the objective is vague, such as "have a good book fair", then each person decides privately what good means, and the efforts pull in different directions. An exact objective states the result and the date: for example, to reach the expected sales of the fair by the end of its 28 days.

> Exact objectives let a manager check results against the plan.

An exact objective also makes later checking possible. If the stall's expected sales are known in advance, the manager can compare the actual sales with them after the first week, and again after the fourth. Without an exact objective there is nothing to compare. The control of results is taught in Chapter 18.

### Communication and Flexibility

> Employees must know the plan, and the plan must be able to bend.

The third habit joins two ideas that seem opposite. Communication means that everyone affected by the plan knows it: what it says, why it exists and who does what. A standing plan that is kept in the owner's head cannot guide the assistants. The manager should put it in writing, explain it, and answer questions.

> Flexibility keeps a plan useful when conditions change.

Flexibility means that the plan can be changed when conditions change. A plan that cannot bend becomes a trap. Suppose the returns policy allows exchange within seven days, and a large school order arrives with a longer delay between delivery and use. The manager may then allow a longer period for such orders, and should record the change for everyone. Flexibility does not mean having no plan; it means reviewing the plan on a regular day and changing it with care.

### Overcoming the Limits of Planning

> Planning has limits, and a manager can reduce them but not remove them.

The fourth habit is to accept that planning has limits and to reduce them. The future cannot be known, so every plan rests on assumptions that may prove wrong. Planning takes time and money, and a plan that is too detailed may cost more than it saves. Plans can also lead managers to follow them after they stop fitting the facts.

> Three actions reduce the limits: review often, plan in proportion and keep a margin.

Three actions help. First, review plans on a fixed date, for example at the start of each season, and ask whether the planning premises still hold. Second, plan in proportion: give more detail where an error costs much, such as a large order, and less detail where the cost is small. Third, keep a margin, which means a small reserve of money or time to meet surprises. A shop that plans for a large order with no reserve is one price change away from trouble.

> A manager should test a plan against the four habits before using it.

A short test helps a manager to decide whether a plan is ready. Ask four questions. Do the senior managers support it? Is the objective exact, with a date? Do all the affected employees know it? Is there a fixed day to review it and change it? If any answer is no, the plan has a weak point, and it is cheaper to repair the weak point before the plan starts than after it fails.

:pause 8.p2 | The shop's owner makes a new plan for the book fair but tells nobody except the store manager. Which of the four habits is weak, and what should the owner do?

> Section 8.3 in four lines.

*Before moving on.* Planning works when the top supports it, objectives are exact and shared, employees know the plan, and the plan can change. The limits of planning are reduced by regular review, proportion and a margin.

* * *

## Worked Case: Sorting the Shop's Plans for 2026

> This worked case sorts the shop's plans and tests their figures.

This worked case follows the standard order for a descriptive chapter: Situation, Question, Reasoning, Conclusion and Check. It applies the ideas of the chapter to the shop's own record, and it is a study of the idea and not a model answer.

> The situation lists the three plans in the 2026 case file.

*Situation.* The shop has three plans for 2026. The first is a returns policy: exchange within 7 days with a receipt. The second is a 28-day book fair stall in February 2026, with a budget of Tk 240,000 and expected sales of Tk 900,000. The third is a yearly budget with sales of Tk 15,840,000.

> The question asks for the kind of each plan and what the figures show.

*Question.* Which plans are standing and which are single-use, and what do the figures show about the book fair?

> The reasoning sorts the plans first, then compares the figures.

*Reasoning.* First, sort the plans by repeat use. The returns policy applies every day and has no end date, so it is a standing plan. The book fair stall has a start and an end and will not be repeated, so it is a single-use plan. The yearly budget is renewed each year in form, so it behaves as a standing plan, although its figures change. Second, compare the figures of the fair. The expected sales exceed the planned spending by Tk 900,000 − Tk 240,000 = Tk 660,000. Third, find the share of the year. The expected sales of the fair are Tk 900,000 out of Tk 15,840,000, which is 900,000 ÷ 15,840,000 = 0.0568, or about 5.7%.

> The conclusion states the kind of each plan and the size of the fair.

*Conclusion.* The returns policy and the yearly budget are standing plans; the book fair stall is a single-use plan. The fair is expected to bring in about 5.7% of the year's sales, and the expected sales exceed the planned spending by Tk 660,000 before the cost of the books is counted.

> The check multiplies back to the starting figure.

*Check.* If 5.7% of Tk 15,840,000 is calculated, 15,840,000 × 5.7 ÷ 100 is about Tk 902,880, which is close to Tk 900,000. The small difference arises because 5.7% is a rounded figure, so the answer is sensible.

* * *

## Summary

> The chapter in a few lines.

Plans are sorted by repeat use into standing plans and single-use plans. Standing plans include policy, procedure and rule, and single-use plans include programmes and projects. A budget states income and spending in money terms. Plans are also sorted by time into long-range and short-range, and by level into strategic and operational. Planning works when the top supports it, objectives are exact, people know the plan, and the plan can change.

## Think It Through

> Four questions that change the situation step by step.

The questions begin with the shop and move to new settings.

:q 8.t1 | The shop's returns policy allows exchange within 7 days with a receipt. A customer returns a book on day 8 with a receipt. Which part of the standing plan decides the case, and what could the manager do within the policy?

:q 8.t2 | Suppose the book fair had expected sales of Tk 600,000 and the same budget of Tk 240,000. By how much would the expected sales exceed the spending, and what would you advise?

:q 8.t3 | A school canteen serves lunch every day and also plans a once-a-year sports day. Give one standing plan and one single-use plan for the canteen.

:q 8.t4 | Explain when a standing plan should be changed. Give two signs that a policy has grown old.

## Where People Go Wrong

> A policy, a procedure and a rule are not the same.

Some students use the three words as if they meant one thing. They differ in freedom: a policy guides and leaves judgement, a procedure fixes the steps, and a rule leaves no choice. Reading the sentence for how much choice it leaves usually shows which form it is.

> A single-use plan is not a weak or unimportant plan.

Some students think that a plan used once matters less. A single-use plan, such as a landing on a coast, may be the most important plan an organisation ever makes. It is called single-use because it is used once, not because it is small.

> A standing plan does not last for ever.

Some students believe that once a standing plan is made, it stays. Conditions change, and the plan must be reviewed. A plan that is never reviewed becomes a habit that no longer fits the facts.

> A budget does not guarantee the sales it expects.

Some students read the expected sales in a budget as a promise. They are an estimate, based on premises. The actual figures may differ, and the manager must compare them with the budget as the period goes on.

## In History

> The Allied landings in Normandy were planned as a single operation on a very large scale.

On 6 June 1944, during the Second World War, Allied forces landed on the coast of Normandy in northern France. The operation was called Operation Overlord, and it began with the largest landing from the sea in history. The landing was not repeated. It was a single-use plan on a very large scale.

> Planning began more than a year before the landing.

Planning began in 1943, when a joint British and American staff under Lieutenant-General Frederick Morgan was told to prepare a plan for an invasion in 1944. In late 1943, General Dwight D. Eisenhower was named Supreme Commander. The first target date was in the spring of 1944, and it was later moved to June, and the final day was set by the commanders after studying conditions.

> The plan shows how a single-use plan joins many standing and single-use parts.

The operation also needed a second plan, a campaign of deception called Operation Bodyguard, meant to hide where and when the landing would be. Both plans were prepared together. The history shows what this chapter has taught: a very large single-use plan needs exact objectives, support from the top, communication among many groups, and the ability to change.

## Review Questions

> Five questions that review the chapter.

:q 8.1 | Sort these plans into standing and single-use: a returns policy, a book fair stall, a yearly budget, the opening of a new branch.

:q 8.2 | Define policy, procedure and budget, and give one shop example of each.

:q 8.3 | What is the difference between a long-range plan and a short-range plan, and between a strategic plan and an operational plan?

:q 8.4 | Explain why support from the top matters to a plan.

:q 8.5 | State two ways in which a manager can reduce the limits of planning.

