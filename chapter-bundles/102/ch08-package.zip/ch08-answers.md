:answers 08
:a 8.p1 | A one-day sale to clear old stock is a single-use plan, because it is made for one occasion. If the shop held the same sale every year with the same steps, it would become a standing plan.
:a 8.p2 | Communication is weak, because the employees who carry out the plan do not know it. The owner should explain the plan to everyone affected, in writing, and answer their questions.
:a 8.t1 | The limit "within 7 days" decides the case, because day 8 is outside it. That part is a policy, so the manager has room for judgement, for example to help if the book was damaged. The manager should record the exception.
:a 8.t2 | The expected sales would exceed the spending by 600,000 − 240,000 = Tk 360,000. The event still seems worth planning, but the margin is smaller, and the cost of the books must be counted before the manager decides.
:a 8.t3 | Standing plan: a procedure for serving lunch each day, or a policy on prices. Single-use plan: the plan for the annual sports day, with its own date and budget.
:a 8.t4 | Change a standing plan when conditions change or it fails to fit the facts. Two signs of an old policy: employees often ask for exceptions, and customers or employees complain about the same point.
:a 8.1 | Standing: returns policy and yearly budget (renewed in form each year). Single-use: book fair stall and the opening of a new branch.
:a 8.2 | A policy is a general guide that sets limits for choices (exchange within a set number of days). A procedure is a fixed series of steps for a repeated task (check receipt, check book, record exchange). A budget states expected income and spending in money for a period (the book fair budget of Tk 240,000).
:a 8.3 | A long-range plan looks several years ahead and a short-range plan a year or less. A strategic plan sets the main direction of the organisation; an operational plan states how one part does its daily work.
:a 8.4 | If senior managers ignore a plan, employees ignore it too. Support gives the plan money, time and example, so people follow it.
:a 8.5 | Review plans on a fixed date and check the premises; plan in proportion, with more detail where an error costs much; keep a margin of money or time.
