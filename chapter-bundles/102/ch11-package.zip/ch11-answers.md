:answers 11
:a 11.p1 | 0.8 × 500 = 400 and 0.2 × (−1,000) = −200, so the expected value is 400 − 200 = Tk 200.
:a 11.t1 | Worth it: an important, unclear decision that affects many people, or one that needs the support of employees to be carried out. Not worth it: an urgent or simple choice, or one where a single person holds both the knowledge and the authority.
:a 11.t2 | 0.4 × 900,000 = 360,000 and 0.6 × (−300,000) = −180,000, so the expected value is Tk 180,000. This is still above Tk 0, so opening still beats waiting on expected value.
:a 11.t3 | 900,000p − 300,000(1 − p) = 0 gives 1,200,000p = 300,000, so p = 0.25. Check: 0.25 × 900,000 = 225,000 and 0.75 × 300,000 = 225,000, which cancel.
:a 11.1 | The event happens one time in four. The probability that it does not happen is 1 − 0.25 = 0.75.
:a 11.2 | 0.7 × 50,000 = 35,000 and 0.3 × (−80,000) = −24,000, so the expected value is Tk 11,000.
:a 11.3 | 0.2 × 100,000 = 20,000; 0.5 × 40,000 = 20,000; 0.3 × (−60,000) = −18,000. The sum is Tk 22,000, and the probabilities add up to 1.
:a 11.4 | X: 0.6 × 200,000 = 120,000 and 0.4 × (−100,000) = −40,000, so Tk 80,000. Y is Tk 70,000. X is higher by Tk 10,000, but it can lose Tk 100,000, so a manager would also ask whether the firm can bear that loss.
:a 11.5 | A square shows a decision point and a circle shows a chance event. We draw the tree from left to right and calculate from right to left, which is called folding back.
:a 11.6 | It stores and analyses data quickly, and it answers what-if questions. One limit: wrong data give wrong answers, and the system supports the manager but does not decide.
:a 11.7 | Advantages: more information and ideas, and stronger support from those affected. Disadvantages: it is slower and uses the time of several employees; it can also let one member dominate or blur responsibility.
:a 11.8 | Any three of: time, cost, importance, the manager's values and attitude to risk, and authority.
:a 11.9 | A tree works when the possible results and their probabilities are known, which describes risk. Under certainty each choice has one known result, so the manager compares the results directly and needs no probabilities.
