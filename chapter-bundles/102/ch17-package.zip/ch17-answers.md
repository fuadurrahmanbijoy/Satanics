:answers 17
:a 17.p1 | Point 5: the manager presents the problem, asks the employees for suggestions, and then makes the decision. The manager keeps the final decision, but only after hearing the group.
:a 17.t1 | Both parts are possible. She is a leader, because colleagues seek her advice and follow it willingly, which is influence without a position. She is not a manager unless she also holds a position of authority.
:a 17.t2 | In the emergency, a point near 1: time is short and danger is high, so the manager decides and announces. For a monthly meeting on the duty roster, a point near 5 or 6, because nurses know their own needs and time allows discussion.
:a 17.1 | Leadership is the process of influencing people to work willingly toward group goals. Its three parts are the leader, the followers and the situation.
:a 17.2 | Any two of: a manager holds a position, a leader holds influence; followers must obey a manager but choose to follow a leader; a leader needs no title. One person can be both when a manager also influences people to follow willingly.
:a 17.3 | Legitimate (position), reward, coercive (punishment), expert and referent power. Referent power comes from liking and admiration: an assistant whom colleagues respect and copy can influence them with no reward to offer.
:a 17.4 | (a) Autocratic: danger and short time. (b) Participative or free-rein: skilled people with knowledge the leader lacks. (c) Free-rein: experienced people with clear goals need little direction.
:a 17.5 | The trait approach looks for personal qualities of leaders; the situational approach says the right way to lead depends on leader, followers and situation. The continuum supports the situational approach, because no point on it is best everywhere.
