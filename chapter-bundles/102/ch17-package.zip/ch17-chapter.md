:chapter XVII | Leadership
:mood Why do some people attract followers, and others only obedience?
:desc This chapter explains what leadership is, how a leader differs from a manager, and where a leader's power comes from. It compares the main approaches and styles of leadership and follows one bookshop through a change in its layout.
:plate ch17-plate.svg | A ship's captain at the wheel in heavy seas, with the crew behind him

:box YOU WILL NEED
Chapter 16, 'Motivation', section 16.1 'What Motivation Is'; and Chapter 14, 'Authority, Delegation and Coordination', section 14.1 'Authority and Power'. Chapter 16 explains why people choose to act and keep acting. Chapter 14 explains authority, which comes with a position, and power, which is a wider idea. This chapter uses both ideas to explain why people follow one person and not another.

> Two managers hold the same title and the same authority, yet their employees behave very differently.
Imagine two shops. Each has a store manager with the same title, the same pay and the same authority. In the first shop, employees do what the manager says, at the time he says it, and nothing more. When he leaves the room, the work slows. In the second shop, employees report problems before the manager asks, and they stay late before a busy week without being told. The title is the same, and the authority is the same. Something else differs. What is it?

> Two tempting answers, talent and kindness, are each partly wrong.
One tempting answer is that the second manager was born with a gift. Another is that the second manager is a kinder person. Both answers contain a little truth, and both fail as a full explanation. People have studied this question for more than a hundred years, and their answers have changed several times. This chapter follows those changes, so that you can judge each answer for yourself.

> A captain in a storm shows that authority puts a person in charge, while something more keeps the crew steady.
Picture a ship in a storm. The captain at the wheel holds authority from the shipowner. In the storm, however, the crew do not obey because a contract says so. They obey because they trust him: he knows the sea, he stays calm, and he cares whether they live. His authority put him at the wheel. Something else holds the crew together. That something has a name, *leadership*, which section 17.1 defines.

> The chapter moves from the meaning of leadership, to the approaches, to the styles and modern ideas.
Section 17.1 defines leadership, separates it from management, and shows where a leader's power comes from. Section 17.2 describes two approaches that explain why some people lead well, and a famous continuum of leader behaviour. Section 17.3 describes the styles of leadership and three modern ideas. Along the way, we follow a bookshop in Dhaka through a change that two of its managers handled in two different ways. Many students find this subject confusing, because the word *leader* is used loosely in daily talk. We shall use it with one meaning only.

* * *

## Leader and Manager

> A group of friends planning a trip shows leadership appearing without any title.
Begin with a small, familiar case. A group of six friends plans a weekend trip. Nobody is the owner, nobody is the boss, and nobody has a title. Within an hour, one friend has proposed the dates, listened to objections, settled an argument and persuaded the group to share the costs. The others follow her plan, and they do so willingly. She holds no authority at all. What she holds is influence, and the group's decision to accept it.

> Recall: motivation, Chapter 16, 'Motivation', section 16.1 'What Motivation Is'.
> Leadership is the process of influencing people to work willingly toward group goals.
@ Lead | Word in use. In daily life, "lead" can mean to be in front, as in a race, and "lead" is also a metal. In management, to lead is to influence people so that they follow willingly.
@ Leadership | The process of influencing people to work willingly toward group goals.
This is the idea we call **leadership**. Leadership means the process of influencing people to work willingly toward group goals. Take the friend who planned the trip: she influenced the others, they worked willingly, and the goal belonged to the whole group. Each part of the definition matters. *Influencing* means that the leader changes what other people choose to do. *Willingly* means that people act from their own motivation, and not from fear alone. *Group goals* means that the aim is shared, and is not only the leader's private wish.

> Leadership involves three things together: the leader, the followers and the situation.
Leadership is a process, and a process has parts. The first part is the leader, the person who influences. The second is the followers, the people who are influenced; without followers there is no leadership, because influence needs someone to receive it. The third part is the situation: the task, the time available, and the dangers and chances around the group. The friend who plans a weekend trip faces a calm situation, so her gentle style works. The captain in a storm faces a dangerous one, and he needs a different way of influencing. Leadership changes when any of the three parts changes.

> Leadership has limits: it does not depend on a title, and it is not always used for good ends.
Two exceptions help to avoid mistakes. First, leadership does not depend on a title. An experienced sales assistant whom colleagues ask for advice may lead more than the store manager does. Second, the definition says nothing about whether the goals are good. A leader may influence people toward a harmful aim, and the process is still leadership. Leadership is therefore a description of what happens, and it is not a compliment. When we want to ask whether leadership is good, we look at its goals and its methods.

> A manager holds a position, and a leader holds influence; one person can be both, or only one.
Now we separate two words that students often confuse. A manager is a person who holds a position in an organisation and carries the authority that comes with it. A leader is a person who influences others, whether or not that person holds a position. Some managers lead well. Some managers do not lead at all, and their employees obey the rules and no more. Some leaders are not managers: the friend on the trip, or the respected assistant at the counter. The best managers do both, because a manager who can also lead gets more from the same people. The table below sets the two ideas side by side. Read each row from left to right: the first column names a feature, and the other two columns say how it appears for a manager and for a leader.

:table A manager and a leader compared
| Feature | Manager | Leader |
| Source of influence | Position and authority | Personal influence, with or without a position |
| Why people follow | The position requires it | They choose to follow |
| Main concern | Using resources well to meet plans | Moving people toward group goals |
| Needs a title | Yes | No |

> A leader's power can come from five sources, and one of them, liking and admiration, is called referent power.
Why do people accept a leader's influence? The answer lies in power, the ability to influence the actions of others, which Chapter 14 separates from authority. In 1959 two American social psychologists, John French and Bertram Raven, listed five sources of power.^1 The first is *legitimate* power, which comes from a position. The second is reward power: the leader can give something people value, such as a bonus or a better shift. The third is coercive power: the leader can punish, for example by a warning. The fourth is expert power: people follow because the leader knows more. The fifth is referent power, which the next paragraph defines.

^1: French and Raven published their list in 1959. The names they gave to the five sources are still used in books on management.

> Referent power rests on liking and admiration, and it often lasts longer than power from rewards or punishment.
@ Referent power | Power that comes from other people's liking and admiration for a leader.
**Referent power** means power that comes from other people's liking and admiration for a leader. For example, a sales assistant whom colleagues respect and wish to resemble can influence them without any reward to offer. The first four sources can be taken away: a position can end, a bonus can be cancelled. Referent power belongs to the relationship, and it survives such changes. Even so, it has limits. A leader who relies on liking alone may avoid hard decisions to stay popular. Coercive power gets obedience, but it rarely gets commitment, because people who obey from fear do the minimum.

> People follow a leader who helps them meet their needs, which links leadership to motivation.
Leadership connects to motivation, which Chapter 16 explains. People follow willingly when they believe that the leader helps them to meet their needs. A leader who sees which need matters most to each person, whether pay, security, belonging or a chance to grow, can influence that person more easily. The need hierarchy is one way to think about this question. A leader who ignores people's needs may still hold authority, but the motivation of the group will be weak.

> The owner, the manager, the employee and the customer each see leadership from a different position.
Each person sees leadership from a different position. The owner sees a way to turn a small number of managers into a strong team. The manager sees a skill that makes delegation safer, because people who follow willingly can be trusted with more work. The employee sees whether the person in charge understands and respects the work. The customer sees the result: a shop whose employees are led well shows it at the counter, in service that is steady and willing.

> Before moving on: leadership is influence toward group goals, it differs from management, and it rests on several kinds of power.
*Before moving on.* Leadership is the process of influencing people to work willingly toward group goals. It involves a leader, followers and a situation. A manager holds a position; a leader holds influence; one person may be both. Leader power has five sources: position, reward, punishment, expert knowledge and referent power, which is liking and admiration.

* * *

## Approaches to Leadership

> People once believed that leaders are born with special qualities, and this belief started the study of leadership.
In the early twentieth century, many writers held a simple belief: leaders are born, and one can recognise them by their qualities. Under this view, history is the story of great individuals, each with a rare set of gifts. The idea was attractive, and it led to a large amount of research. Researchers made lists of qualities, such as height, intelligence, confidence, energy and honesty, and they measured these in people who had become leaders. This is the trait approach. In it, the aim is to find the personal qualities that make a leader.

> The trait approach failed to find one list of qualities that works everywhere.
In 1948 the American psychologist Ralph Stogdill reviewed many such studies. He found that no list of qualities predicted leadership in every situation. A person who led well in a school club did not always lead well in a business. Some qualities, such as drive and honesty, appeared often, but none was enough alone. The trait approach still gives us something: it reminds us that a leader's character matters. Its weakness is that it ignores the situation, and a captain who commands well in a storm may command badly in a boardroom.

> The situational approach says that effective leadership depends on the leader, the followers and the situation together.
Researchers then asked a different question. Instead of asking "What qualities make a leader?", they asked "What should a leader do in this situation?" The situational approach holds that no single way of leading is best, and that the right way depends on the leader, the followers and the situation. A new employee who needs guidance, for example, may need a leader who gives clear directions. A skilled employee of many years may work best with a leader who gives freedom. The situational approach says that a good leader reads the situation and changes behaviour to fit it.

> Recall: authority and power, Chapter 14, 'Authority, Delegation and Coordination', section 14.1 'Authority and Power'.
> In 1958 Tannenbaum and Schmidt described seven patterns of leader behaviour along one line.
In 1958 two American writers, Robert Tannenbaum and Warren Schmidt, published an article in the *Harvard Business Review* called "How to Choose a Leadership Pattern". They described a continuum, which is a line along which a quantity changes in small steps. At one end, the manager uses a great deal of authority and the employees have little freedom. At the other end, the manager uses little authority and the employees have a great deal of freedom. Between the ends they described seven patterns. In the first, the manager decides and announces the decision. In the second, the manager decides and then tries to persuade the group. In the third, the manager presents a decision and invites questions. In the fourth, the manager presents a tentative decision that the group may change. In the fifth, the manager presents the problem, asks for suggestions and then decides. In the sixth, the manager sets limits and asks the group to decide. In the seventh, the group acts within limits set by the manager.

> To read the figure, follow the line from left to right: the manager's authority falls and the employees' freedom rises.
Figure 17.1 shows the continuum. To read it, begin at point 1 on the left and move along the line to point 7 on the right. The upper wedge shows the authority that the manager uses; it is widest at point 1 and narrows to the right. The lower wedge shows the freedom of the employees; it is narrowest at point 1 and widens to the right. A point on the line is one pattern of behaviour. Points 1, 4 and 7 carry short labels, and the paragraph above names the others.

:fig The Tannenbaum and Schmidt leadership continuum | ch17-fig01.svg

:pause 17.p1 | Look at the continuum. At which point does the manager keep the final decision but ask the employees for suggestions first? Name the point and say why.

> The continuum offers no best point; the right point depends on forces in the manager, the employees and the situation.
Tannenbaum and Schmidt did not say that one point is best. They said that the right pattern depends on three forces. The first is the forces in the manager: his values, his confidence in the employees and his comfort with uncertainty. The second is the forces in the employees: how much they wish for freedom, how well they know the work and how ready they are to take responsibility. The third is the forces in the situation: the type of organisation, the time available and the nature of the problem. When time is short, as in an emergency, a pattern near point 1 is often wise. When employees are skilled and time is available, a pattern nearer point 6 may bring better decisions and more commitment.

> Before moving on: the trait approach seeks the qualities of leaders, and the situational approach says the right way to lead depends on circumstances.
*Before moving on.* The trait approach searched for the personal qualities of leaders and found no list that works in every situation. The situational approach holds that effective leadership depends on the leader, the followers and the situation. Tannenbaum and Schmidt, in 1958, described a continuum of seven patterns, from the manager who decides and announces to the group that acts within limits. No point on the line is best in every case.

* * *

## Styles and Modern Ideas

> Two managers in one shop handled one change in two ways within a single week.
:case Case file, illustrative. Meghna and Sons, the family-run bookshop in Dhanmondi, Dhaka, changed the layout of its shop on 3 March 2026. Nurul Meghna, the owner-manager, decided on the change and told the staff. Rafiq Meghna, the store manager, asked the 3 sales assistants for their views first and then decided. Both ways of handling a decision were used within one week.

> Why did one change bring two ways of deciding? The answer is that leaders have usual ways of behaving, called styles.
Why would two members of one family, in one shop, handle a similar change in two ways? One answer is that each person has a usual way of making decisions and treating followers. A leader's usual way has a name: the leadership style. The case file records two decisions and does not tell us why each manager chose as he did, so we cannot judge which choice was better. We can, however, describe what each choice was.

> Recall: leadership, section 17.1 'Leader and Manager'.
> A leadership style is a leader's usual way of making decisions and treating followers.
@ Style | Word in use. In daily life, a fashion or manner, such as a style of dress. In management, a leader's usual pattern of behaviour toward followers.
@ Leadership style | The usual way a leader makes decisions and treats followers.
A **leadership style** means the usual way a leader makes decisions and treats followers. For example, a leader who nearly always decides alone and then informs the group has a different style from a leader who nearly always asks first. The word *usual* is important. A style is a habit and not a rule, and a skilled leader can step away from the habit when the situation calls for it.

> Lewin and his colleagues described three classic styles in 1939: autocratic, participative and free-rein.
In 1939 the German-born psychologist Kurt Lewin and two colleagues studied groups of boys in the United States, led by adults who behaved in three different ways.^2 Later writers named three styles from this work. An autocratic leader decides alone and tells the group what to do. A participative leader asks for views, discusses the problem, and decides with the group, or after listening to it. A free-rein leader gives the group almost complete freedom and steps in rarely. On the continuum of section 17.2, the autocratic style lies near point 1, the participative style lies near the middle, and the free-rein style lies near point 7.

^2: Lewin and his colleagues, Ronald Lippitt and Ralph White, reported their experiments with boys' clubs in 1939. The names of the three styles come from later textbooks, and they describe the results in simple form.

> Each style fits some situations and fails in others, as the table shows.
Each style has a time and a place. The autocratic style fits an emergency, a very new group, or a task where one wrong move is costly; its risk is that people stop offering ideas. The participative style fits a problem where employees know things the leader does not, and where commitment matters; its risk is that decisions take longer. The free-rein style fits a group of skilled and motivated people; its risk is that the group drifts, if people lack skill or goals are not clear. The table sets the three side by side. Read each row from left to right: the first column names the style, the second says who decides, and the third and fourth give a fitting case and the main risk.

:table Three classic leadership styles
| Style | Who decides | Fits when | Main risk |
| Autocratic | The leader alone | Time is short or danger is high | Ideas stop coming |
| Participative | The leader with the group | Employees know the work well | Slow decisions |
| Free-rein | The group | People are skilled and motivated | Drift without direction |

> The case file shows both ends of the range of behaviour in one shop: deciding and telling, and asking and then deciding.
Look again at the layout change. Nurul decided and told the staff, which is the autocratic style, and the first point of the continuum. Rafiq asked the sales assistants first and then decided, which is the participative style and lies near the fifth point of the continuum. Both are patterns that a leader can choose. A good leader knows the range, and chooses the pattern that fits the people and the problem.

> Emotional intelligence is the ability to understand and manage feelings, one's own and other people's.
@ Emotional intelligence | The ability to notice, understand and manage one's own and other people's feelings.
**Emotional intelligence** means the ability to notice, understand and manage one's own and other people's feelings. For example, a manager who notices that a tired employee is losing patience, and who responds calmly, shows emotional intelligence. Two psychologists, Peter Salovey and John Mayer, introduced the term in 1990, and the writer Daniel Goleman made it widely known in 1995. Its parts include knowing one's own feelings, controlling them under pressure, understanding other people, and handling relationships with care. The idea has limits. It does not replace knowledge of the work, and researchers still debate how well it can be measured.

> Transformational leadership inspires followers to look beyond self-interest and to change themselves and the organisation.
@ Transformational leadership | Leading by inspiring followers to look beyond self-interest and to change themselves and the organisation.
**Transformational leadership** means leading by inspiring followers to look beyond self-interest and to change themselves and the organisation. The political scientist James MacGregor Burns drew the idea in 1978 from his study of political leaders. He contrasted it with a leader who trades, giving pay or praise in return for work done. The trading leader gets the agreed work. The transformational leader hopes for more: followers who accept a larger purpose and who grow in skill and confidence. For example, an owner who explains to the whole shop why good service matters to the neighbourhood, and who asks each person to help build that reputation, is leading in this way. The risk is that an inspiring leader may be followed without question, even when the aim is mistaken.

> Coaching leadership develops people by guidance, questions and feedback, and it links leading with delegation.
Coaching leadership is a style in which the leader develops people. The leader asks questions, gives feedback and sets tasks that stretch the employee a little. For example, a store manager might delegate the weekly order to a sales assistant, then review the result with the assistant and discuss what could improve. Delegation, which Chapter 14 explains, makes coaching possible, because people learn by doing real work. Coaching takes time, and it suits a person who wishes to learn. It fits poorly where the task is urgent and no time remains for teaching.

> Before moving on: a style is a leader's usual way; the best leaders can change style, and modern ideas add feelings, inspiration and development.
*Before moving on.* A leadership style is a leader's usual way of making decisions and treating followers. The three classic styles are autocratic, participative and free-rein, and each fits some situations. Emotional intelligence is the ability to notice, understand and manage feelings. Transformational leadership inspires followers to look beyond self-interest. Coaching leadership develops people through guidance and feedback.

* * *

## Worked Case: Matching Style to Situation

> The worked case tests the choices in the case file against the three forces of the continuum.
Case file, illustrative. We now apply section 17.2 and section 17.3 to the layout change. We take it in the order *Situation, Question, Reasoning, Conclusion, Check*, so that each step is announced and explained.

> The situation restates the facts of the case file and nothing more.
*Situation.* On 3 March 2026 the bookshop changed its layout. Nurul decided and told the staff. Rafiq asked the 3 sales assistants first and then decided. Both styles were used within one week. The file does not say what the change was, why each manager chose as he did, or what the results were.

> The question asks how to judge each choice with the three forces, using only what the file supports.
*Question.* Using the three forces of Tannenbaum and Schmidt, under what conditions would each choice be wise?

> The reasoning applies the forces in the manager, the employees and the situation to each choice.
*Reasoning.* First, name each choice. Nurul used point 1 of the continuum: decide and announce. Rafiq used point 5: ask for suggestions and then decide. Second, apply the three forces. For point 1, the situation should favour speed or a clear single view; the employees should accept direction; the manager should be confident in his own judgement. For point 5, the employees should know something the manager does not, such as how customers move through the shop; the time should allow a short discussion; and the manager should be willing to hear views he may not follow. Third, notice what the file cannot tell us. We do not know whether Nurul's change was urgent, or whether the assistants knew more about the shelves than Rafiq did. A judgement on either choice would therefore be a guess.

> The conclusion and the check show what can and cannot be said from the file.
*Conclusion.* Both choices are acceptable patterns, and each is wise under some conditions. The file shows that the shop's leaders used two points of the continuum within one week. It does not show which was better. *Check.* A good test of the reasoning is that it names the missing facts: the purpose of the change and its results. A conclusion that picked a winner would claim more than the file supports. The next step for a manager is the one the continuum suggests: ask what the three forces say about this decision, and then choose the point.

* * *

## Summary

> The summary states the chapter in a few lines.
Leadership is the process of influencing people to work willingly toward group goals. A leader differs from a manager: a manager holds a position, and a leader holds influence. A leader's power can come from position, reward, punishment, expert knowledge and referent power. The trait approach looked for the qualities of leaders. The situational approach says that the right way to lead depends on the leader, the followers and the situation. Tannenbaum and Schmidt described seven patterns on a continuum. Autocratic, participative and free-rein are the classic styles. Emotional intelligence, transformational leadership and coaching leadership are modern ideas.

## Think It Through

> The problem asks you to apply the chapter to two situations.
A hospital ward has twelve nurses and one ward manager. The ward manager has authority from the hospital, but several nurses go to a senior nurse, who holds no position of authority, whenever they need advice or support. Use the ideas of this chapter to answer both questions.

:q 17.t1 | Is the senior nurse a leader, a manager, or both? Explain your answer using the definitions of leadership and management in section 17.1.
:q 17.t2 | A fire alarm sounds in the ward. Which point of the continuum should the ward manager use, and why? Then say which point suits a monthly meeting on improving the duty roster.

## Where People Go Wrong

> Six common misunderstandings about leadership are stated and corrected here.
The first misunderstanding is that leaders are born and cannot be made. Correction: some qualities help, but studies found no list that works everywhere, and people can learn many leadership skills. The second is that a leader and a manager are the same. Correction: a manager holds a position; a leader holds influence; the two overlap but are not equal.

> Further misunderstandings concern the best style, the meaning of power, and the nature of a leader's goals.
The third misunderstanding is that one style is always best. Correction: each style fits some situations and fails in others. The fourth is that the participative style is always better because it is kinder. Correction: in an emergency, or with a very new group, slow discussion may cause harm. The fifth is that power is only the ability to punish. Correction: power has five sources, and referent power often lasts longest. The sixth is that leadership is always good. Correction: the definition describes influence toward group goals and says nothing about whether the goals are good.

## In History

> Shackleton led the Endurance expedition from 1914 to 1916 and brought all 28 men home.
Ernest Shackleton was a British explorer. On 8 August 1914, he sailed from Plymouth, in England, in the ship *Endurance*, with a crew of 28 men. His aim was to cross the continent of Antarctica. In January 1915 the ship became trapped in the ice of the Weddell Sea. The ice crushed her, and the men abandoned the ship on 27 October 1915. She sank in November 1915.

> After the loss of the ship, Shackleton's choices kept his men together through months on the ice and in open boats.
The men then lived for months on the ice, and in April 1916 they reached Elephant Island, an uninhabited island, in three small boats. On 24 April 1916, Shackleton and five others sailed one boat, the *James Caird*, about 800 miles to South Georgia to find help. He then crossed the mountains of that island on foot with two companions, reached a whaling station, and after three failed attempts by other ships, rescued the 22 men left on Elephant Island on 30 August 1916, with a Chilean tug, the *Yelcho*. All 28 men survived.

> Writers on leadership use the case, though later retelling should be read with care.
Writers on management often use this case. Shackleton is often described as a leader who put his crew's welfare before personal glory. We should treat such accounts with some care: much of what is said about his methods comes from later retelling, and a famous story invites a simple lesson. Still, the facts of the rescue are well recorded, and they show a leader whose choices kept a group together under extreme danger.

## Review Questions

> The review questions test each main idea of the chapter.
:q 17.1 | Define leadership in your own words, and name its three parts.
:q 17.2 | Give two differences between a manager and a leader, and explain how one person can be both.
:q 17.3 | Name the five sources of a leader's power, and explain referent power with an example of your own.
:q 17.4 | Match each situation to the style that fits best, and give one reason: (a) a flood warning reaches a warehouse; (b) a team of skilled designers needs to choose a new logo; (c) a group of experienced accountants works on a long project with clear goals.
:q 17.5 | Explain the difference between the trait approach and the situational approach, and say which one the Tannenbaum and Schmidt continuum supports.

:read Robert Tannenbaum and Warren H. Schmidt, How to Choose a Leadership Pattern, 1958
:read James MacGregor Burns, Leadership, 1978
