:chapter XVIII | Controlling
:mood How does a manager know that the plan is working?
:desc A plan is only a promise until its results are checked. This chapter explains how managers set standards, measure results, compare them with the plan and correct the difference, and it shows the three moments at which control can act.

:plate ch18-plate.svg | An engine-room with gauges, a governor and an engineer reading them

> This chapter builds on two earlier sections about planning and objectives.

*You will need:* Chapter 7 'Planning: Meaning, Nature and Steps', section 7.1 'What Planning Is'; and Chapter 9 'Objectives and Management by Objectives', section 9.1 'Objectives'.

> A plan was made, a year passed, and the result was a surprise.

Imagine a shopkeeper who plans carefully in January. She decides how much stock to buy, how much to sell, and how much profit to earn. Twelve months later she counts the stock, and she finds that goods worth far more than expected have disappeared. The plan was sensible. The shopkeeper worked hard. Yet nothing in the year warned her, and now the loss cannot be recovered. She asks herself a painful question: when could I have known?

> The question has an answer: she could have known early, if she had checked.

The answer is: much earlier. If she had counted a part of the stock each week, the first small shortage would have appeared in the first month. She could have found the cause, such as a door left open or a mistake in recording sales, and she could have acted while the loss was still small. The plan did not fail. The checking failed, because there was none.

> Engineers solved this problem for machines long before managers solved it for people.

Engineers met the same problem with steam engines. In a Victorian engine-room, a steam engine that runs too fast may damage itself, and one that runs too slowly cannot do its work. So engineers fitted a device called a governor. The governor senses the speed and adjusts the flow of steam, so that the engine returns to its right speed without anyone touching it. A gauge shows the engineer how the engine is doing. The pattern is: a level to aim for, a reading, a comparison, and an adjustment.

> A business needs the same pattern, and this chapter explains it.

A business needs the same pattern. This chapter shows how managers apply it to stock, money, time and people. It also shows that the pattern has three moments: before work, during work and after work. Last, it explains why even a good system fails when people resist it or when no one truly checks. This is the final function of management, and it closes the cycle that began with planning.

* * *

## What Controlling Is

### Controlling

> Plans stay useful only when results are compared with them.

Think about driving a car. You choose a destination (the plan). During the drive you watch the road, the speed and the fuel. If the car drifts toward the edge, you turn the wheel. You do not wait until you arrive to find out that you left the road. This everyday habit of watching and adjusting is exactly what managers do with an organisation.

@ Controlling | Checking results against plans and taking action to correct any difference.
@ Control | Word in use. In daily life, to control a person or a thing often means to have power over it. In management, control means checking results and correcting differences.
> Controlling is checking results against plans and correcting differences.

This function is called **controlling**. Controlling means checking results against plans and taking action to correct any difference. A shop manager who compares weekly sales with the sales target, and who changes the display when sales are low, is controlling. Notice that controlling has two halves: the check, and the action. A check without action is only an observation, and action without a check is guessing.

> Controlling is the last function in the management process, and it connects back to the first.

In Chapter 3 you met the functions of management. Controlling comes last, but it does not end the work. What the check finds goes back into the next plan. For this reason people speak of a cycle: plan, organise, lead, control, and then plan again.

> Different people see control from different sides.

Viewpoints differ. The owner sees control as protection of money and name. The manager sees it as a way to learn early where help is needed. The employee may see it as distrust, unless the purpose is explained and the checks are fair. The customer meets control as reliable quality, such as the right book on the shelf at the right price. A good manager keeps all four views in mind when designing a check.

> Before moving on: controlling is checking results against plans and correcting differences.

*Before moving on.* Controlling means checking results against plans and taking action to correct any difference. It has two halves, the check and the action. It is the last function of management, and its findings feed the next plan.

### Nature and Principles

> Control has certain features that hold in every organisation.

Five features describe the nature of control. It is *continuous*, because results change every week, and one check at year end is not enough. It is *forward-looking*, because its purpose is to improve future results, not to blame the past. It is *universal*, because every manager at every level controls something, from the owner who watches profit to the cashier who counts the till. It is *tied to plans*, because without a plan there is nothing to check against. And it is *connected to people*, because people carry out the checks and people are checked.

> Good control follows a few simple principles.

Five principles guide the work. First, control should follow the plan, so that it checks what matters to the plan. Second, it should watch key points. A manager cannot watch everything, so the manager watches the key result areas, the few areas where results decide success. Third, it should act quickly, because a late correction is costly. Fourth, it should be economical: its cost must stay below the loss it prevents. Fifth, it should be flexible, so that it still works when the plan changes.

> A check costs money, so its cost must be compared with the loss it prevents.

The economical principle deserves an example. Suppose a stall loses about Tk 500 a year to small errors. A system that costs Tk 2,000 a year to prevent this is poor value, since it spends four times what it saves. Controlling every item with equal care is therefore wasteful. Wise managers spend most effort where the possible loss is largest.

> Before moving on: control is continuous, forward-looking and universal, and it follows a few clear principles.

*Before moving on.* Control is continuous, forward-looking, universal, tied to plans, and connected to people. It should follow the plan, watch key points, act quickly, cost less than the loss it prevents, and remain flexible.

### The Link with Planning

> Planning and controlling depend on each other.

> Recall: planning, Chapter 7, section 7.1 'What Planning Is'; objectives, Chapter 9, section 9.1 'Objectives'.
> Plans give control something to measure, and control tells planners if the plan works.

Planning and controlling are like two sides of a coin. Planning sets the objectives and chooses the course of action. Controlling checks whether the objectives are being reached. Without plans, control has nothing to measure against, so it cannot begin. Without control, planning is only hope, because no one learns whether the plan worked. Control also supplies facts for the next plan: a premise that proved wrong in this year can be corrected in the next.

> Before moving on: planning and control are a pair, and each makes the other useful.

*Before moving on.* Plans give controlling its measures, and controlling shows whether the plan works. The findings return to planners, who adjust objectives and premises for the next period.

* * *

## The Control Process

### Setting Standards

> The control process has four steps, and the first is to decide what counts as good.

How does a teacher know whether a student passed? The teacher first decides the pass level, and then compares the work with it. Control follows the same order. Before work begins, the manager decides what level of result is acceptable. Only then can results be judged.

@ Standard | A level of performance set in advance as the measure of what is acceptable.
@ Standard | Word in use. In daily life, standard may mean ordinary or average, as in a standard model. In control, a standard is a level that has been chosen in advance as the measure.
> A standard is a level of performance chosen in advance.

Such a level is called a **standard**. A standard is a level of performance set in advance as the measure of what is acceptable. A stall owner may set a standard that no more than 2 in every 100 loaves are wasted. Standards come from objectives and plans, and they are often stated in four ways: in quantity (units sold), in quality (errors allowed), in time (hours to finish), and in cost (taka spent).

> A standard must be measurable and fair, or it cannot guide anyone.

A good standard is measurable, so that everyone can tell whether it was met. It is also fair, so that employees believe it can be reached. A standard that nobody can meet teaches people to ignore it. The key result areas tell the manager where standards matter most.

> The case file's standard is a small percentage of the stock value.
:case Case file, illustrative. The control record of Meghna and Sons sets a stock loss standard of 1% of stock value. Stock at cost is Tk 3,500,000, so the standard allows a loss of Tk 35,000.

### Measuring Performance

> The second step is to find out what actually happened.

A standard is useful only if real results are measured. A manager must decide what to measure, how often, and by whom. Results may be counted, weighed, timed or reported. Good measurement is accurate and timely: a figure that arrives six months late can no longer change the result.

> The case file measures loss over the year and also counts a sample every week.
:case Case file, illustrative. In 2025 the actual stock loss of Meghna and Sons was Tk 56,000. The record also shows a weekly count of 200 titles.

> A weekly sample gives an early signal at low cost.

The weekly count of 200 titles is a sample: a small part of the stock, counted often. It would be costly to count every title every week, but a sample gives an early signal. This is the economical principle at work.

### Comparing

> The third step compares the actual result with the standard.

Comparing means placing the actual result beside the standard and finding the difference. This difference is called the *deviation*. A deviation is the amount by which the actual result differs from the standard. We calculate it in one way, so that signs never confuse us: actual minus standard.

> A worked example with small numbers makes the method easy to follow.

*Given.* A stall holds stock worth Tk 100,000. The standard loss is 2% of stock value. The actual loss is Tk 3,000. *Find.* The deviation. *Formula.* In words: deviation equals actual result minus standard. In symbols: D = A − S, where D is the deviation, A is the actual result and S is the standard. *Steps.* The standard in taka is 2% of 100,000 = 0.02 × 100,000 = Tk 2,000. Then D = 3,000 − 2,000 = Tk 1,000. *Answer.* The loss is Tk 1,000 above the standard. *Check.* Tk 1,000 is 1% of Tk 100,000, and the actual rate 3% equals the standard 2% plus 1%.

> A second example uses the real figures of the case file.

*Given.* Stock Tk 3,500,000; standard loss 1%; actual loss Tk 56,000. *Find.* The standard in taka, the actual loss rate, and the deviation. *Steps.* Standard: 0.01 × 3,500,000 = Tk 35,000. Actual rate: 56,000 ÷ 3,500,000 = 0.016, which is 1.6%. Deviation: 56,000 − 35,000 = Tk 21,000. In rates: 1.6% − 1.0% = 0.6 percentage points. *Answer.* The loss is Tk 21,000 above the standard, which is 1.6% against 1%. *Check.* 0.6% of 3,500,000 = 0.006 × 3,500,000 = Tk 21,000, which agrees.

> Three slips are common when comparing.

Three slips are common. The first is to subtract the wrong way and so reverse the meaning of the sign. The second is to confuse a percentage with a percentage point: from 1% to 1.6% is a rise of 0.6 percentage points, but it is also a rise of 60 per cent of the standard rate. The third is to compare figures for different periods, such as a week's loss with a year's standard.

### Correcting

> The fourth step is to act on the difference.

A deviation calls for a question: why? The manager looks for the cause before choosing the action. Possible actions are to improve performance (stop the cause), to change the plan, or to revise the standard if it was unrealistic. If the deviation is small and temporary, the manager may do nothing, and this too is a decision.

> The tags are the correction chosen for the stock loss.
:case Case file, illustrative. As the correction, Meghna and Sons fitted security tags at Tk 30,000 in 2026.

> A correction has a cost, so it must be weighed against its benefit.

A correction also has a cost, so it must be weighed against the benefit. Suppose, as an illustration, that the tags remove the whole excess loss of Tk 21,000 a year. Then Tk 30,000 ÷ Tk 21,000 is about 1.4, so the tags repay their cost in a little under a year and a half. If they remove only half the excess, the repayment takes about three years. The cost and the benefit must both be judged.

> The figure shows the four steps as a loop that returns to planning.

The figure shows the process as a loop. To read it, start at the box *Set standard* and follow the arrows: measure, compare, correct. The dashed arrow shows that what is learned returns to the first box and to planning.

:fig The control process as a loop | ch18-fig01.svg

:pause 18.p1 | A cafe sets a standard of 5 spoiled cups in a week. In week 6 it has 9. What is the deviation, and what should the manager do first?

:box IN SHORT
The four steps are: set a standard, measure performance, compare to find the deviation (actual minus standard), and correct. The findings return to planning.

> Before moving on: the control process sets a standard, measures, compares and corrects, and the findings return to planning.

*Before moving on.* The control process has four steps: set a standard, measure performance, compare it with the standard to find the deviation, and correct. The deviation is actual minus standard. A correction must be weighed against its cost.

* * *

## Types of Control

### Three Moments of Control

> Control can act before, during or after the work.

Picture a cook. Before cooking, the cook checks that the rice is clean and the oil is fresh. While cooking, the cook tastes the food and lowers the flame if it burns. After cooking, the cook judges the finished dish and remembers to use less salt next time. The cook has controlled at three different moments. Managers do the same, and each moment has a name.

@ Feedforward control | Control that acts before work begins, to prevent problems.
> Feedforward control acts before the work begins, to prevent problems.

The first is **feedforward control**. Feedforward control acts before work begins, to prevent problems. It checks the inputs: people, materials, money and plans. Training new employees before they serve customers is an example, and so is checking that an order is within budget before it is placed. Its strength is that a problem prevented costs nothing to repair. Its weakness is that it needs good forecasts, and a forecast can be wrong.

@ Concurrent control | Control that acts while the work is being done.
> Concurrent control acts while the work is going on.

The second is **concurrent control**. Concurrent control acts while the work is being done. It checks the process as it happens, and it corrects at once. A supervisor who watches a cashier in the first week and gives help on the spot is using it. A security tag that sounds an alarm as a book leaves the shop is another example, since it acts during the event. Its strength is speed. Its weakness is cost, because someone or something must watch all the time.

@ Feedback control | Control that acts after the work is done, using the results to correct later work.
> Feedback control acts after the work is done and uses the results to improve later work.

The third is **feedback control**. Feedback control acts after the work is done, using the results to correct later work. The year-end stock count of the case file is of this kind, and so is a review of last month's sales. It is the easiest control to apply, because results are plain to see. But it has a clear limit: it cannot undo what has already happened. A loss found at year end stays lost, and only future losses can be reduced.

> The table compares the three types on the moment, the target and the limit.

The table below compares the three types. Read each row across: the first cell names the type, and the other cells say when it acts, what it checks and what limits it.

:table Three types of control
| Type | When it acts | What it checks | Main limit |
| Feedforward | Before work | Inputs and plans | Depends on forecasts |
| Concurrent | During work | The process | Costs constant attention |
| Feedback | After work | Results | Too late to undo the past |

> The choice among the types depends on the cost of a mistake and the time available.

How should a manager choose? When a mistake is costly or cannot be undone, such as a safety fault, prefer feedforward and concurrent control. When mistakes are small and cheap to repair, feedback control may be enough. The exception is that no type works alone: feedforward needs feedback to test whether its forecasts were right.

> Most organisations use all three, because each covers a weakness of the others.

A sensible organisation uses all three. Feedforward prevents the easy mistakes. Concurrent control catches the problems that slip through. Feedback shows what neither noticed and improves the next period. The case file shows a mixture: the year-end count is feedback, the tags act during the event, and the weekly count of a sample gives feedback often enough to behave almost like a live check.

:pause 18.p2 | A manager reads last month's complaints and changes the rota. Is this feedforward, concurrent or feedback control? Give one reason.

### Monitoring

> Monitoring is regular watching of progress, and it supports all three types.

Monitoring means watching progress regularly through reports, visits and counts, so that deviations appear early. It is not a fourth type of control but a habit that supports all three. A weekly report on sales, or a short daily meeting at the shop door, are forms of monitoring.

> Before moving on: control acts before work (feedforward), during work (concurrent) or after work (feedback), and monitoring supports all three.

*Before moving on.* Feedforward control acts before work begins, to prevent problems. Concurrent control acts while the work is being done. Feedback control acts after the work is done, using the results to correct later work. Organisations use all three, with monitoring to keep watch.

* * *

## Making Control Effective

### Requirements of Effective Control

> Effective control meets a short list of requirements.

For control to help, it must be timely, so that the information arrives while action is still useful. It must be accurate, because wrong figures lead to wrong actions. It must be understood by the people who are checked, and it must be economical, costing less than it saves. It should also focus on key points, and it should suit the plan and the people it serves.

### Barriers to Control

> People and costs can stop control from working.

Several barriers stand in the way. Employees may resist, because they fear blame or feel distrusted. Some results are hard to measure, such as the quality of service or the spirit of a team. Measuring everything is costly and can slow the work. And too much control can harm: when every step is checked, employees may stop thinking for themselves and wait for orders.

### Power and Control

> Control gives power to those who check, and that power needs its own limits.

A person who checks the work of others holds power: the power to praise, to blame and to correct. Power is a separate term, studied elsewhere in this book. The danger is that one person controls too much alone. If the same person does the work and also checks it, no one else can see a mistake or a deceit. For this reason good organisations separate the doing from the checking.

> Timing matters because information loses value as it ages.

Timing deserves a closer look. A shop that learns of a shortage in the first week can search the till records, ask the staff and check the door while memories are fresh. A shop that learns in the twelfth month can do none of these. The same figure has very different value on different days, and so the speed of reporting is part of the design of control.

> Before moving on: effective control is timely, accurate, understood, economical and focused, and it must guard against resistance and misuse.

*Before moving on.* Effective control is timely, accurate, understood and economical, and it focuses on key points. Barriers include resistance, hard-to-measure results, cost and excess. Where one person both acts and checks, power is unchecked, and control fails.

* * *

## Worked Case: Classifying the Controls at Meghna and Sons

> The worked case applies the three types to the control record.

*Situation.* Case file, illustrative. The control record of Meghna and Sons shows: a stock loss standard of 1% (Tk 35,000 of Tk 3,500,000); an actual 2025 loss of Tk 56,000, which is 1.6%; security tags at Tk 30,000 fitted in 2026; and a weekly count of 200 titles. *Question.* Place each action as feedforward, concurrent or feedback control, and say what is still missing.

> Each action is placed by asking when it acts.

*Reasoning.* The standard of 1%, set in advance, guides decisions before the year begins, and in that sense it belongs with feedforward control. The year-end figure of Tk 56,000 is a result found after the work, so it is feedback. The tags act at the moment an item leaves the shop, so they are concurrent. The weekly count of 200 titles comes after each week's trading, so it is feedback, but it is frequent and so gives early signals.

> Rates give a fair comparison between the standard and the result.

Notice that the record states both taka amounts and rates. The rate (1.6% against 1%) compares loss with the value of stock, so the result can be judged fairly in a year when stock is larger or smaller. The taka amount (Tk 21,000 above the standard) shows how much money is at stake.

> The conclusion shows a balanced system with one gap.

*Conclusion.* The record has all three moments, but its feedforward element is thin: it has a standard and no preventive step, such as training staff in stock handling before they work. A shop that adds one would stop some losses before they begin. *Check.* The deviation was Tk 56,000 − Tk 35,000 = Tk 21,000, and each classification follows from when the action acts.

* * *

## Summary

> The summary gathers the main ideas.

Controlling is checking results against plans and taking action to correct any difference. The control process has four steps: set a standard, measure performance, compare it with the standard, and correct. A standard is a level of performance set in advance as the measure of what is acceptable. Feedforward control acts before work, concurrent control acts during work, and feedback control acts after work. Effective control is timely, accurate, understood and economical, and it needs checks on those who check.

## Think It Through

:q 18.t1 | Meghna and Sons lost Tk 56,000 against a standard of Tk 35,000. Find the deviation. If the tags remove Tk 15,000 of the yearly loss, how many years do they take to repay their Tk 30,000 cost?

:q 18.t2 | A shop owner asks every employee to write down each action in a daily log, and checks the log every evening. Describe how this control could go too far, and one change that keeps the benefit.

:q 18.t3 | A stall owner serves, keeps the cash and also checks the cash at the end of the day. What risk does this create, and how can it be reduced?

## Where People Go Wrong

> A common error is to think that controlling means finding fault.

Some students believe that control exists to blame people. Its purpose is to keep results close to plans, and to learn for the next period.

> Another error is to think that every deviation needs a strong response.

Some students believe that any difference from the standard must be corrected at once. A small, temporary deviation may need only watching. A manager who reacts to every small change wastes effort and may unsettle the employees.

> Another error is to think that a check alone is enough.

Some students believe that measuring is the whole of control. Without action to correct a deviation, a check changes nothing.

> A third error is to think that feedback control is the best because it is accurate.

Some students believe that feedback control is enough because its figures are exact. It arrives after the loss, and it cannot undo it. Feedforward and concurrent control act earlier.

> A last error is to think that more control is always better.

Some students believe that checking everything is wise. Control costs money and can discourage employees. The aim is control that costs less than the loss it prevents.

## In History

> Barings Bank, in 1995, shows how weak control can destroy a strong organisation.

Barings was Britain's oldest merchant bank, founded in 1762. In 1992 it sent a young trader, Nick Leeson, to run its futures trading in Singapore. He also oversaw the records of his own trades, so the person who traded was also the person who reported the trades. When a discrepancy in the accounts was raised in January 1995, it was Leeson who gave the explanation, and for a time it was accepted.

> The losses grew in secret until the bank collapsed on 26 February 1995.

By February 1995 the hidden losses amounted to about £827 million, more than the bank's capital. Barings went into administration on 26 February 1995, and the Dutch group ING bought it on 6 March for one pound, taking on its debts. Leeson was sentenced in Singapore in December 1995 to six and a half years in prison. A Bank of England inquiry reported in July 1995 and found failings by management and weak control. The lesson for this chapter is plain: where doing and checking sit in one pair of hands, no standard, report or comparison can protect the organisation.

## Review Questions

:q 18.1 | Define controlling and explain its two halves.

:q 18.2 | Name the four steps of the control process in order, and say what each does.

:q 18.3 | Define standard, and give a standard in quantity, in time and in cost for a bookshop.

:q 18.4 | A stall has stock worth Tk 200,000 and a standard loss of 1.5%. The actual loss is Tk 4,200. Find the standard in taka and the deviation.

:q 18.5 | Place each action as feedforward, concurrent or feedback control: training a new cashier before the first day; watching a new cashier at the till; reviewing last month's sales figures; an alarm on a door.

:q 18.6 | Give one strength and one limit of each of the three types of control.

:q 18.7 | State three requirements of effective control and two barriers to control.

:q 18.8 | Why does Chapter 7 planning need controlling, and why does controlling need Chapter 9 objectives?

:read Henri Fayol, Administration industrielle et générale, 1916
:read Board of Banking Supervision, Report into the Circumstances of the Collapse of Barings, 1995
