:answers 18
:a 18.p1 | Deviation = actual − standard = 9 − 5 = 4 spoiled cups above the standard. The manager should first find the cause (for example a machine fault or a new employee) before choosing the correction.
:a 18.p2 | Feedback control. It uses last month's results, after the work is done, to correct later work.
:a 18.t1 | Deviation = 56,000 − 35,000 = Tk 21,000 above the standard. Repayment = 30,000 ÷ 15,000 = 2 years.
:a 18.t2 | It could go too far by taking much of the employees' time and showing distrust, so they may write the log to please the owner and stop using their own judgement. A change that keeps the benefit: log only the key items, such as cash and stock, and check by sample.
:a 18.t3 | The same person does and checks the work, so an error or a theft can pass unseen. The risk falls if another person counts the cash, or if the owner checks the count.
:a 18.1 | Controlling is checking results against plans and taking action to correct any difference. Its halves are the check and the action; a check without action changes nothing.
:a 18.2 | Set a standard (decide the acceptable level); measure performance (find the actual result); compare (find the deviation, actual minus standard); correct (act on the cause).
:a 18.3 | A standard is a level of performance set in advance as the measure of what is acceptable. Examples: sell at least 120 books a day (quantity); serve each customer within 5 minutes (time); keep the stock loss to Tk 35,000 a year (cost).
:a 18.4 | Standard = 0.015 × 200,000 = Tk 3,000. Deviation = 4,200 − 3,000 = Tk 1,200 above the standard.
:a 18.5 | Training before the first day: feedforward. Watching at the till: concurrent. Reviewing last month's sales: feedback. An alarm on a door: concurrent.
:a 18.6 | Feedforward: prevents problems, but depends on forecasts. Concurrent: corrects at once, but costs constant attention. Feedback: easy to apply since results are known, but too late to undo the past.
:a 18.7 | Any three of: timely, accurate, understood, economical, focused on key points. Barriers, any two of: resistance, results hard to measure, cost, too much control.
:a 18.8 | Planning needs controlling to learn whether the plan works. Controlling needs objectives to supply the standards against which results are compared.
