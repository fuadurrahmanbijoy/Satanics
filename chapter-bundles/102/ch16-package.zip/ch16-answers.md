:answers 16
:a 16.p1 | Answers vary. A good answer names a goal, such as a skill, a result or the respect of others, that kept the person working without orders.
:a 16.p2 | Esteem. The job is steady and safe, so levels 1 and 2 are met, but the clerk feels unnoticed and wants respect for the work.
:a 16.t1 | Possible answers: the first assistant may feel a need for esteem and belonging (known by regular customers), while the second may feel mainly a need for income and safety, which the pay already meets. The same pay meets one need and leaves the other untouched.
:a 16.t2 | Theory X: it assumes employees must be watched. A result could be distrust, or careless work that matches the low expectation. A Theory Y change: share the till targets with staff and give them responsibility for checking their own sales.
:a 16.t3 | Their lower needs are already met, so extra pay may remove no complaint and add little push. Incentives that touch esteem and growth, such as training, a senior title or responsibility for a project, may work better.
:a 16.1 | Motivation is the inner push that makes a person choose to act and keep acting toward a goal, such as an assistant who tidies shelves each day to be trusted. A need is a lack a person feels and wants to fill, such as the wish for more income.
:a 16.2 | Motivation is inside the person; an incentive is a reward offered from outside. An incentive fails when it does not meet a need the person feels, or when the goal seems out of reach.
:a 16.3 | Physiological, safety, social, esteem, self-actualisation. The order matters because the need pushing now is the one an incentive must meet.
:a 16.4 | Salary: physiological (and safety). Safety shoes: safety. Team outing: social. Title of senior sales assistant: esteem. Designing the window display: self-actualisation (and esteem).
:a 16.5 | Need (wish for income), drive (tension), action (working carefully toward the target), goal (the bonus), need met and tension falls. The loop may restart with a new need.
:a 16.6 | Hygiene factors are the conditions around the job (pay, rules, supervision, security); they prevent unhappiness. Motivators are in the work itself (achievement, recognition, responsibility, advancement); they build effort.
:a 16.7 | Theory X: people dislike work and must be directed and watched. Theory Y: people can enjoy work and seek responsibility. Theory X can suit a dangerous task or a new employee.
:a 16.8 | The record shows that 2 of 7 left but not why. Without knowing which needs are unmet, an incentive may touch the wrong level and be wasted.
