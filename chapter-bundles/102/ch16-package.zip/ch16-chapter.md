:chapter XVI | Motivation
:mood Why does one person work with care, and another only with the clock?
:desc Two employees receive the same pay and the same tasks, yet one gives far more effort. This chapter explains the inner pushes behind work, compares the best-known need theories, and shows how a manager's assumptions shape the way people are led.
:plate ch16-plate.svg | A pit-head at pay time: miners, the lamp-room and the pay window

> This chapter builds on two earlier sections.

*You will need:* Chapter 15 'Human Factors, Groups and Creativity', section 15.1 'Human Factors in Management'; and Chapter 3 'The Functions of Management and How Management Is Judged', section 3.1 'The Management Process'.

> Two employees with the same pay behave very differently.

Imagine a shop with two sales assistants. They were hired on the same day. They receive the same pay, work the same hours, and sell the same kinds of goods. Yet one of them arrives early, learns the names of regular customers, and tidies shelves without being asked. The other watches the clock, serves each customer correctly, and leaves at the minute the day ends. Neither person breaks a rule. Both are paid fairly. Why is the work so different?

> Pay alone cannot explain the difference, so something else must be at work.

The first answer that comes to mind is pay, but pay is equal here, so pay cannot be the whole explanation. A second answer is skill, yet both assistants are equally skilled. A third answer is character: one is hardworking, the other lazy. That answer is attractive, because it is short. But it explains nothing, and it gives the owner no action to take. Moreover, the "lazy" assistant may behave very differently at a cricket match or a family wedding, where the same person works hard for hours without pay.

> A person who works hard in one place and not in another has a reason that can be studied.

This fact is the key. The same person can be eager in one setting and careless in another. The difference lies in what that setting offers: what the person wants, what the person hopes to gain, and what the person believes is possible. Managers cannot see these inner matters, but they can study them, and they can arrange work so that the right wants are met. Whole theories have been built on this idea, and this chapter introduces the best-known ones.

* * *

## What Motivation Is

### Motivation

@! Go slowly here.

> Before a word is defined, an everyday case shows the idea.

Start with an everyday case. A student has an examination in ten days. One student studies for two hours every evening. Another student, with the same books and the same teacher, leaves the books closed until the last night. The first student has a reason that is strong enough to start the work and to keep it going each evening. The second student has a weaker reason, or none. Both students are able to study. What differs is the push.

@ Motivation | The inner push that makes a person choose to act and keep acting toward a goal.
> Motivation is the inner push that starts and sustains a person's action toward a goal.

That push has a name. **Motivation** means the inner push that makes a person choose to act and keep acting toward a goal. The goal may be a pass in the examination, a higher income, or the respect of friends. The word *keep* matters. A short burst of effort that stops after one day is weak motivation. Strong motivation continues when work becomes tiring or dull.

> Motivation lives inside a person, so a manager sees only its results.

Three points follow. First, motivation is inside the person. A manager cannot look at an employee and measure it. A manager can only observe what the employee does: the effort, the care, the time. Second, motivation is not the same as ability. A highly skilled employee may have little motivation, and a less skilled employee may have a great deal. Third, motivation is not force. A person who works only from fear of punishment is obeying, and that is not the same as being pushed from within.

:pause 16.p1 | Think of a task you did for hours without anyone telling you to. What was the goal that kept you going?

> Before moving on: motivation is an inner push toward a goal, and it is different from skill or force.

*Before moving on.* Motivation means the inner push that makes a person choose to act and keep acting toward a goal. It is inside the person, so managers see only the behaviour it produces. It differs from ability, which is what a person can do, and from force, which is what a person is made to do.

### Need

> A push begins with a lack, which we call a need.

Where does the push come from? Consider hunger. At midday, after a morning without food, you feel a discomfort, and you walk to the kitchen. The discomfort is a lack. Something is missing, and you want to fill it. The same pattern holds for other lacks, such as the lack of company when you are alone, or the lack of respect when others ignore your work.

@ Need | A lack that a person feels and wants to fill.
@ Need | Word in use. In daily life, to need something may mean that one must have it, as in "I need a pen". In this chapter, a need is the lack itself, felt by the person.
> A need is a lack that a person feels and wants to fill.

This lack is called a **need**. A need is a lack that a person feels and wants to fill. A person who feels the need for income takes a job. A person who feels the need for friendship joins a club. Because needs differ from person to person, the same offer can move one employee and leave another untouched.

@ Drive | Word in use. In daily life, to steer a vehicle, or a strong push toward a task. In the study of motivation, the inner tension that a need creates, which pushes a person to act.
> A need creates a tension, called a drive, that pushes the person to act.

A need leads to a tension inside the person. Writers on motivation often call this tension a drive, and we use the word in that sense only. The tension is uncomfortable, so the person acts to remove it. The next section shows how need, drive, action and goal join in one loop. For now, remember only that a need comes first.

> Before moving on: a need is a felt lack, and it creates the tension that starts action.

*Before moving on.* A need is a lack that a person feels and wants to fill. It creates a tension, called a drive, and the tension pushes the person to act. Needs differ between people, so one offer will not move everyone in the same way.

### Why Managers Must Understand It

> Managers get results through people, so people's motivation affects every result.

Why should a manager study something that cannot be seen? The answer lies in the work of leading. In Chapter 3, leading was one part of the management process: it means guiding people so that they work toward the goals of the organisation. A manager who leads without understanding motivation is like a driver who does not know what the engine needs.

> Recall: leading, Chapter 3, section 3.1 'The Management Process'.
> Motivation affects productivity and effectiveness, and it affects who stays.

Motivation affects at least three results. It affects productivity, because motivated employees usually produce more from the same time. It affects effectiveness, because motivated employees are more likely to work on the right tasks, and not merely on any task. And it affects who stays. Employees whose needs are not met often look for work elsewhere, and replacing them costs time and money.

> The staff record shows that people left but not why.
:case Case file, illustrative. In the 2025 staff record of Meghna and Sons, 2 of 7 employees left. Total wages in 2025 were Tk 2,940,000, an average of Tk 420,000 a year per employee. The record states the numbers and does not state the reasons.

@ Incentive | A reward offered to encourage a person to act in a wanted way.
> An incentive is a reward offered to encourage wanted behaviour.

Managers often respond to motivation with an incentive. An **incentive** means a reward offered to encourage a person to act in a wanted way. A bonus for meeting a sales target is an incentive. So is a day off for perfect attendance, or praise before the whole team. Notice that an incentive is outside the person, while motivation is inside. The incentive is offered, and it works only if it touches a need the person actually feels.

> The bonus in the 2026 plan is an incentive.
:case Case file, illustrative. The 2026 plan of Meghna and Sons offers a bonus of one month's pay if the sales target is met.

> Before moving on: managers need motivation because it affects output, results and staff retention, and an incentive works only if it meets a need.

*Before moving on.* Managers get results through people, so motivation affects productivity, effectiveness and the number of employees who stay. An incentive is a reward offered to encourage a person to act in a wanted way. It works only when it meets a need that the person feels.

### Assumptions About Motivation

> Every motivation theory starts from some assumptions about people.

Every manager holds beliefs about what moves people, whether or not the manager has thought about them. These beliefs guide daily choices. The theories in this chapter make the beliefs explicit, so that we can examine them. Four assumptions run through most of the theories.

> The first two assumptions say that behaviour has causes and that people differ.

The first assumption is that behaviour has causes. People do not act for no reason, even when the reason is hidden. The second is that people differ. An owner may be moved by the wish to leave a legacy, a sales assistant by the wish to support a family, a customer by price. A manager must therefore look at each person, and not only at the group.

> The last two assumptions say that managers shape conditions and that motives change.

The third assumption is that managers cannot place motivation inside another person. They can only arrange the conditions in which a person's own motives are likely to work. The fourth is that motives change. An employee who first seeks a secure income may later seek responsibility. A manager who studied the person last year may need to study again.

> Before moving on: the theories assume that behaviour has causes, that people differ, that managers shape conditions and that motives change.

*Before moving on.* Behaviour has causes. People differ. Managers shape conditions and do not insert motivation. Motives change over time. You should now be able to say: *motivation is an inner push from a felt need, and a manager can only arrange conditions in which that push is likely to appear.*

* * *

## Need Theories

> Need theories explain motivation by asking which needs a person feels.

> Recall: human factors, Chapter 15, section 15.1 'Human Factors in Management'.
> If motivation grows from needs, a good theory should list the needs and show how they act.

In Chapter 15 you studied the human side of management. Now we ask a sharper question about that human side. If motivation grows from needs, which needs are there, and in what order do they matter? Three well-known answers follow. The first, and the most famous, is the work of Abraham Maslow. The second shows how any need leads to action. The third, by Frederick Herzberg, divides the features of a job into two groups.

### Maslow's Need Hierarchy

@! Go slowly here.

> An everyday case begins the idea: a hungry person cares little about anything else.

Begin with a person who has eaten nothing for two days. Offer this person a place on a respected committee. Will the person care? Probably not. Hunger fills the mind, and the offer seems unimportant. Now offer a meal. The person eats, and the hunger fades. An hour later the same person starts to wonder about shelter for the night. Later again, about friends. The needs do not arrive all at once. They arrive in an order.

> Maslow noticed this order and wrote it down in 1943.

This order was noticed by Abraham Maslow, an American psychologist, who set out his theory in a paper of 1943, *A Theory of Human Motivation*, in the journal *Psychological Review*. He asked what people want, and he found that wants fall into groups that rank one above another. A hungry person looks for food first. Only when food is secure does the next group of wants become strong.

@ Need hierarchy | Maslow's idea that human needs rank in five levels, and a higher need matters only after the lower ones are met.
> The need hierarchy ranks five levels of need, from lowest to highest.

This idea is called the **need hierarchy**. The need hierarchy is Maslow's idea that human needs rank in five levels, and a higher need matters only after the lower ones are met. The word *hierarchy* means a ranking from lower to higher. Picture a stair: you stand on the first step before you climb to the second. The five levels are listed below, from the lowest to the highest.

> The table gives the five levels, the need at each level, and a shop example.

To read the table, take one row at a time. The first cell gives the level, the second says what the person lacks at that level, and the third gives an example from the workplace.

:table Maslow's five levels of need
| Level | The need | Example at work |
| 1 Physiological | Food, water, shelter, rest | Wages large enough to buy food and pay rent |
| 2 Safety | Security and freedom from danger | A steady job; a safe building; a fair notice period |
| 3 Social | Belonging, friendship, acceptance | Being part of a friendly team |
| 4 Esteem | Respect from others and self-respect | Praise, a title, trust with responsibility |
| 5 Self-actualisation | Becoming all that one can be | Learning new skills; using one's abilities fully |

> Self-actualisation means growing toward one's own full ability.

The last level needs a plain explanation. *Self-actualisation* means becoming everything that one is able to become.^1 A musician who must make music, a teacher who wants every pupil to learn, and a trader who builds a business larger than anyone expected are examples. This level is never fully reached, because there is always more to learn. Maslow thought that it matters to a person only after the four lower levels are mostly met.

^1: Maslow wrote *self-actualization* with a z. This book uses British spelling.

> The figure shows the five levels as steps of a stair.

The figure shows the same levels as a stair. To read it, begin at the bottom step, which is the lowest need. Each step rises above the one before it, and the label on each step names the need. Moving upward means moving toward needs that matter more once the lower steps are secure.

:fig Maslow's five needs as a stair | ch16-fig01.svg

> Maslow's key claim is that a need that is met stops pushing, and a new need takes its place.

Now the central claim, which many students misread. Maslow did not say that a person has only one need at a time. He said that an unmet lower need pushes most strongly, and that a need which is met stops pushing. When it stops pushing, the next need above it comes forward. The consequence for a manager is direct. An incentive works only when it touches the need that is pushing at that moment. A praise card means little to an employee who cannot pay the rent. A larger salary may mean less to an employee who already earns enough and wants respect.

> The cashier's training offer is a second kind of incentive.
:case Case file, illustrative. In the 2026 plan of Meghna and Sons, the cashier is offered training for a supervisor post.

> The cashier's training touches esteem and growth, which sit high on the stair.

Where does this offer sit on the stair? Training for a supervisor post offers a title and responsibility, which belong to esteem, and a chance to learn, which belongs to self-actualisation. Compare it with the bonus of one month's pay: that incentive speaks mainly to the lower levels, because income buys food, shelter and security. A shop owner who wants to keep a particular employee might offer either, but the theory tells the owner to ask which need is pushing that person now.

> The hierarchy has limits, and Maslow himself did not claim a rigid order.

Now the exceptions. The order is not the same for everyone. Some people place respect above friendship, and some pursue a creative goal while poor. Needs also overlap, so a person may be partly secure and partly hungry for respect at the same time. Later researchers have found that the five levels do not always appear in the same order in every culture. Maslow himself said that the order is not fixed for every person. So the hierarchy is a useful guide to questions, not a rule that predicts one person's behaviour.

:pause 16.p2 | A stock clerk has a steady job and a safe warehouse, and says the work feels pointless because nobody notices it. Which level of need is probably unmet?

:box IN SHORT
The need hierarchy ranks needs in five levels: physiological, safety, social, esteem and self-actualisation. An unmet lower need pushes hardest. When it is met, the next level comes forward.

> Before moving on: the need hierarchy ranks five levels of need and treats a met need as no longer pushing.

*Before moving on.* The need hierarchy is Maslow's idea that human needs rank in five levels, and a higher need matters only after the lower ones are met. An incentive works when it touches the need now pushing. The order is a guide and not a law: it differs between people and cultures.

> You should now be able to say what the five levels are and why an incentive may fail.

You should now be able to say: *needs rank in five levels, and an incentive works only when it meets the level that is pushing the person now.*

### The Needs-Goal Model

@! Go slowly here.

> A simple loop shows how a need becomes action and then returns.

Maslow told us which needs exist. A second idea, which we may call the needs-goal model, shows how any single need turns into action. Return to hunger. First comes the lack: the stomach is empty. Then comes tension, which is uncomfortable. The tension moves the person to act, so the person walks to the kitchen. The person reaches the goal, which is a meal. The tension falls, and the need is met. Some hours later the lack returns, and the loop starts again.

> The needs-goal model has five parts that form a loop.

The loop has five parts. A need creates a drive, which is the tension described earlier. The drive leads to action, and the action leads to a goal. When the person reaches the goal, the need is met and the drive falls. The figure shows the loop. To read it, follow the arrows from the need, around the loop, and back to the start. The words on each arrow tell you what moves the person from one part to the next.

:fig The needs-goal model as a loop | ch16-fig02.svg

> At work, the same loop describes how an incentive leads to effort.

Now place the loop in a workplace. An employee feels a need for more income. The tension leads to action: the employee works carefully to help the shop meet its sales target. The goal is the bonus of one month's pay. When the bonus is paid, the need is partly met, and a new need may come forward. If the goal is never reached, the loop breaks. The employee may try another action, lower the goal, or become frustrated and leave.

> Before moving on: a need leads to a drive, to action and to a goal, and meeting the goal ends the tension.

*Before moving on.* In the needs-goal model, a need creates a drive, the drive leads to action, and action leads to a goal. Reaching the goal meets the need and ends the tension. The loop breaks when the goal seems out of reach or the reward does not meet the need.

> You should now be able to describe how an unmet need becomes action.

You should now be able to say: *a felt need creates tension, tension leads to action toward a goal, and reaching the goal ends the tension.*

### The Two-Factor View

> Herzberg found that some job features prevent complaints but do not create enthusiasm.

Think about a classroom. Poor light and noise will make students unhappy. Good light and quiet, however, will not by themselves make them eager to learn. Removing the bad condition does not supply the push. Frederick Herzberg, an American psychologist, noticed a similar pattern at work. In a study with Bernard Mausner and Barbara Snyderman, published in 1959 as *The Motivation to Work*, he found that two different sets of job features were linked to feelings about work.

> The first set, hygiene factors, prevents unhappiness; the second set, motivators, builds enthusiasm.

The first set deals with the conditions around the job: pay, working conditions, company rules, supervision and job security. Herzberg called these hygiene factors. When they are poor, people are unhappy. When they are good, people stop complaining, but they are not necessarily eager. The second set deals with the work itself: achievement, recognition, interesting tasks, responsibility and the chance to advance. He called these motivators. When they are present, people are more likely to give effort willingly.

> Hygiene factors roughly match the lower steps of Maslow's stair, and motivators the upper steps.

This view links to Maslow's stair. Hygiene factors resemble the lower levels, since pay and security serve physical needs and safety. Motivators resemble the upper levels, since recognition and growth serve esteem and self-actualisation. The match is rough, not exact. Both views agree on one lesson for managers: fixing the conditions around a job removes complaints, but it does not by itself create commitment.

> Critics say that the split is not sharp and that pay motivates some people.

The exceptions deserve attention. Later studies found that the split between the two sets is less sharp than Herzberg described, and that pay can motivate some people, especially when income is short. The sensible reading is to treat the two factors as a prompt for two questions. Are the conditions around the job fair? Is the work itself worth doing?

> Before moving on: Herzberg separated job features that prevent unhappiness from those that build effort.

*Before moving on.* The two-factor view says that conditions around the job, such as pay and rules, prevent unhappiness, while the work itself, such as achievement and responsibility, builds effort. The split is rough, but it reminds managers to ask both questions.

* * *

## Theory X and Theory Y

### Theory X

> Managers act on beliefs about people, and these beliefs have names.

Suppose two shop managers each find an employee arriving late. The first manager says that employees avoid work unless watched, and installs a clock-in system. The second manager says that the employee probably has a reason, and asks. Each manager acts on a belief about people. Douglas McGregor, an American management scholar, gave these beliefs names in his book *The Human Side of Enterprise* (1960).

@ Theory X | A set of assumptions that people dislike work and must be directed and watched.
> Theory X assumes that people dislike work and must be directed and watched.

**Theory X** is a set of assumptions that people dislike work and must be directed and watched. Under these assumptions, the average person avoids responsibility, wants security above all, and works hard only when pressed by rules, checks and the fear of punishment. A manager who holds these assumptions tends to give detailed orders, supervise closely, and use punishment and reward as the main tools.

> Theory X leads to close control, which can be right when tasks are dangerous or the workers are new.

The exception to note is that close control is sometimes the right choice. A new employee learning a dangerous task needs clear directions and checking. The weakness appears when a manager applies Theory X to everyone, always. Capable people then feel distrusted, and some live down to the low expectation.

### Theory Y

@ Theory Y | A set of assumptions that people can enjoy work and seek responsibility.
> Theory Y assumes that people can enjoy work and seek responsibility.

**Theory Y** is a set of assumptions that people can enjoy work and seek responsibility. Under these assumptions, effort at work is as natural as rest or play, and people direct themselves toward goals they accept. A manager who holds these assumptions shares goals, delegates tasks, and offers growth, as in the training offered to the cashier.

### Using the Theories

> Both theories are assumptions held by managers, not facts about people.

Use the two theories with care. They describe what a manager assumes, and not what people are. A manager who assumes Theory X and watches closely may receive the careless work that was expected, and so seem to be proved right. McGregor drew on Maslow's ideas: Theory X fits people whose lower needs press hardest, and Theory Y fits people whose higher needs are active.

> Before moving on: Theory X and Theory Y are two sets of assumptions, and the best approach depends on the person and the task.

*Before moving on.* Theory X assumes that people dislike work and must be directed and watched. Theory Y assumes that people can enjoy work and seek responsibility. Both are assumptions held by managers, and a good manager matches the approach to the person and the task.

* * *

## Worked Case: Reading the 2026 Staff Plan

> The worked case applies the theories to the facts of Meghna and Sons.

*Situation.* Case file, illustrative. In 2025, 2 of 7 employees left Meghna and Sons. The 2026 plan has two measures: a bonus of one month's pay if the sales target is met, and training for the cashier for a supervisor post. *Question.* Which needs does each measure touch, which theory of management does each suggest, and what should the owner-manager do next?

> The reasoning places each measure on the stair and then asks what is assumed.

*Reasoning.* The bonus is an incentive in money. Money buys food, shelter and security, so it touches the physiological and safety levels. In Herzberg's terms, pay is a hygiene factor, so it can reduce complaints but may not build lasting enthusiasm. The training offer gives responsibility and a chance to learn, so it touches esteem and self-actualisation. In Herzberg's terms, it is a motivator. As for assumptions, a reward tied to a target says little about whether the owner trusts people. The training offer assumes that the cashier can take on responsibility, which fits Theory Y.

> The conclusion warns that the measures help only if they match the needs that employees really feel.

*Conclusion.* The two measures reach different levels of need, and a plan that uses both is wider than a plan that uses only one. But the record does not say why two employees left, so the owner-manager cannot yet know which need was unmet. The next step is to ask the remaining employees what they want from their work, and not to assume. *Check.* Each statement uses only the case facts and the theories of this chapter. The needs-goal loop supports the conclusion: if the target seems impossible, the bonus will not start the loop.

* * *

## Summary

> The summary gathers the main ideas.

Motivation is the inner push that makes a person choose to act and keep acting toward a goal. It begins with a need, a lack that a person feels and wants to fill. An incentive is a reward that works only when it meets a need. Maslow's need hierarchy ranks needs in five levels. The needs-goal model shows a loop from need to drive, action and goal. Herzberg separated job features that prevent unhappiness from those that build effort. Theory X and Theory Y are two sets of assumptions that managers hold about people.

## Think It Through

:q 16.t1 | In the opening puzzle, two assistants have equal pay and skill, yet one works harder. Using the need hierarchy, suggest two different needs that might explain the difference.

:q 16.t2 | The owner of a small shop installs a camera over the till and checks every sale each evening. Which theory does this suggest? Describe one result that could follow and one change that would suit Theory Y.

:q 16.t3 | Meghna and Sons offered a bonus of one month's pay. Suppose instead that employees in a new setting, a hospital pharmacy, already earn comfortable salaries. Which kind of incentive might work better, and why?

## Where People Go Wrong

> A common error is to think that money always motivates.

Some students believe that more pay always raises motivation. Pay is powerful when income is the need that pushes. When it is not, extra pay may only remove a complaint.

> Another error is to treat the five levels as a rigid ladder.

Some students believe that a person must finish one level completely before the next appears. Needs overlap, and the order differs between people. The hierarchy is a guide to questions.

> A third error is to treat Theory X as wrong and Theory Y as right in every case.

Some students believe that Theory X is always bad. It describes assumptions, and close direction is suitable where the task is dangerous or the person is new. The error lies in applying one set of assumptions to everyone.

> A last error is to confuse motivation with an incentive.

Some students believe that a bonus and motivation are the same thing. The bonus is outside the person and is offered. Motivation is inside the person. The bonus works only if it meets a need.

## In History

> Maslow's paper of 1943 gave managers a way to ask what people want.

In 1943 Abraham Maslow, then at Brooklyn College in New York, published *A Theory of Human Motivation* in the journal *Psychological Review*. The paper appeared in volume 50, issue 4, on pages 370 to 396. It arranged human needs in groups that rank one above another, and it said that when the strongest need is met, the next higher need comes forward. Maslow wrote in words, and the stair picture used in this chapter is a later way of showing his idea.

> The idea spread from psychology into management, where it is still debated.

Managers later borrowed the idea, and Douglas McGregor used it in 1960 to explain his two sets of assumptions. Research has not confirmed the exact order of the five levels, and Maslow's paper itself says the order is not fixed for every person. Yet the central question, what does this person want now, remains one of the most useful questions in the book.

## Review Questions

:q 16.1 | Define motivation and need in your own words, and give one example of each from a shop.

:q 16.2 | Explain the difference between motivation and an incentive. Why can an incentive fail?

:q 16.3 | List Maslow's five levels from lowest to highest, and say why the order matters to a manager.

:q 16.4 | Place each incentive on Maslow's levels: a monthly salary, safety shoes for the stock clerk, a team outing, the title of senior sales assistant, a chance to design the window display.

:q 16.5 | Describe the five parts of the needs-goal model, using an employee who wants a bonus.

:q 16.6 | Explain how hygiene factors differ from motivators, and give two examples of each.

:q 16.7 | State the assumptions of Theory X and of Theory Y. Describe one situation where Theory X suits better.

:q 16.8 | Meghna and Sons lost 2 of 7 employees in 2025. Why should the owner-manager ask employees before choosing an incentive?

:read Abraham H. Maslow, A Theory of Human Motivation, 1943
:read Frederick Herzberg, Bernard Mausner and Barbara Snyderman, The Motivation to Work, 1959
:read Douglas McGregor, The Human Side of Enterprise, 1960
