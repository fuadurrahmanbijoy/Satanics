:answers 10
:a 10.p1 | She returns to step 3, develop the alternatives, or to step 2 and the criteria. She could add an alternative such as leaving 20 minutes earlier, or a rickshaw, and test it against the same two criteria.
:a 10.p2 | The price is certain, because the list is fixed for a year and the result is known. The number of customers is uncertainty, because nobody can say the result or estimate its chance. If past records of similar books existed, it would be risk.
:a 10.t1 | Supplier A's price is certainty. Supplier B's delivery times are uncertainty, since no records exist to estimate a chance. Step 1 and step 2 come first, but the manager learns what to find out at step 4, evaluating, where the missing delivery facts stop the test.
:a 10.t2 | The criteria stay the same, but the figures in them change: the expected sales fall, so criterion A (sales per taka spent) and criterion B (sales less rent) fall for Mirpur. Rent and fitting costs do not change. The owner should re-evaluate the options with the corrected figure and compare again.
:a 10.1 | Decision making is choosing one course of action from several, in order to solve a problem or use an opportunity. Example: a shop owner chooses one of two sites for a second shop.
:a 10.2 | A problem is a gap between what is and what should be, and an opportunity is a chance to do better than before. An opportunity is easier to miss, because nobody complains about a chance that was lost.
:a 10.3 | The steps are: name the problem or opportunity; set the criteria; develop the alternatives; evaluate them; choose; implement and follow up. Criteria come first so that they cannot be bent to favour the option already liked.
:a 10.4 | A decision criterion is a standard used to judge which alternative is best. Two examples are the price per copy and the days a supplier takes to deliver.
:a 10.5 | (a) Certainty: the lease fixes the amount. (b) Risk: past records allow the chance to be estimated at 4 in 10. (c) Uncertainty: no records exist, so neither the results nor their chances can be estimated.
:a 10.6 | It is risk, because the chance can be estimated from records. The estimated chance of a late order is 3 out of 12, which is 1/4.
:a 10.7 | She must go back to step 2 and rank the criteria, because no alternative now passes both tests. She must decide whether cost or arrival time counts more.
