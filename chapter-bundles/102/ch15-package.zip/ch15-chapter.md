:chapter XV | Human Factors, Groups and Creativity
:mood If two people have the same tools, why does the work differ?
:desc Machines behave the same way each day, but people do not. This chapter explains the human factors that shape work, shows how groups and teams form and set their own rules, and ends with the ways in which new ideas are born and put to use.
:plate ch15-plate.svg | A workshop where craftsmen at one bench share a tool and a lamp

> Two ideas from earlier chapters support this chapter.

You will need two ideas from earlier chapters. The first is the informal organization, taught in Chapter 12, 'Organizing and Types of Organization', section 12.3 'Formal and Informal Organization'.^1 The second is leading, one of the functions in the management process, taught in Chapter 3, 'The Functions of Management and How Management Is Judged', section 3.1 'The Management Process'.^2 Read those sections again if either idea feels uncertain.

^1: Recall: informal organization, Chapter 12, 'Organizing and Types of Organization', section 12.3 'Formal and Informal Organization'.
^2: Recall: leading, Chapter 3, 'The Functions of Management and How Management Is Judged', section 3.1 'The Management Process'.

> A workshop shows two craftsmen with equal tools who still work in different ways.

Picture a workshop of the nineteenth century. Two craftsmen stand at one long bench. They share a single lamp and pass one heavy tool between them. Both were trained by the same master, and both are paid the same wage. Yet by the end of each day, one has finished six pieces with great care, and the other has finished four, with more mistakes. The master, who watches them, does not blame the bench or the lamp. He knows that the difference lies in the two people.

> The puzzle is that equal tools and equal pay do not give equal work.

This is the puzzle of the chapter. A manager can buy the same machine for every worker and arrange the same lamp for every bench, but the results will still differ, because people differ. A machine does not feel proud or tired. It does not ask what its neighbour is paid, and it does not form friendships. People do all of these things, and each of them changes the work. A manager who ignores this fact will find that careful plans fail without any visible cause.

> The chapter studies the human side of work, from the single person to the group to the new idea.

In this chapter we study the human side of work in three steps. First we examine the traits and feelings that every person brings to a job. Then we study how people join into groups, and how those groups set rules that no one has written. Finally we look at the way new ideas arise and are put to use. We shall test each idea against the records of the small Dhaka bookshop Meghna and Sons.

* * *

## 15.1 Human Factors in Management

> A shop where two assistants react differently to the same instruction shows that people differ.

Suppose a store manager tells two sales assistants to place a new pile of books near the door. The first assistant finishes the task at once and asks whether anything else is needed. The second assistant does the task slowly and complains that the pile will block the customers. The instruction was the same, the books were the same, and the door was the same. The manager is left with the question that this section answers: what is it about people that makes the same instruction produce different results?

@ Human factors | The traits, feelings and relationships of people that affect how they work.

> Human factors are the traits, feelings and relationships that affect how people work.

Management gives a name to the answer. **Human factors** means the traits, feelings and relationships of people that affect how they work. A trait is a lasting feature of a person, such as patience or shyness. A feeling is a state of mind at a given time, such as worry or pride. A relationship is a link between two people, such as friendship or rivalry. When the first assistant works quickly because she likes the store manager, a relationship is shaping the work.

> Human factors act at three levels: the person, the group and the organisation.

The figure below shows that human factors act at three levels. To read it, begin at the centre, which holds the single person. The middle ring holds the groups to which the person belongs, and the outer ring holds the organisation as a whole. A force at an outer ring reaches the person through the rings between. A change in pay or rules, for example, belongs to the organisation, but it is felt first in the groups and then by each person.

:fig Individual, group and organisation factors as nested rings | ch15-fig01.svg

> Individual factors come first, because every group is made of single persons.

The innermost ring contains the individual factors, and these are the subject of the rest of this section. The group factors are studied in section 15.2. Organisation factors, such as pay, rules and working conditions, are treated in later chapters on motivation and leadership. We begin with the person because every group is made of persons, and a manager who understands one person at a time is better prepared to understand a group.

> Individual differences are the ways in which people vary in ability, attitude and background.

The first individual factor is the set of individual differences, which means the ways in which people vary from one another. People differ in ability: one can add a column of numbers quickly, and another can calm an angry customer. They differ in attitude, which is a person's settled way of judging something as good or bad. They differ in needs, in experience and in background. No two employees are alike, and a rule that suits one employee may confuse another.

> Individual differences have limits: they explain much, but they must not be used to label people.

Individual differences have a limit that managers must respect. They help to explain why people act differently, but they must not be used to label a person unfairly. A manager who decides, after one slow morning, that an employee is lazy has drawn a conclusion from too little evidence. The correction is to observe over time, to ask the employee, and to look for causes outside the person, such as unclear instructions or a broken tool.

> Perception is the way a person selects and understands what he or she sees and hears.

The second individual factor is perception. Perception means the way a person selects, arranges and understands what he or she sees and hears. Two people can look at the same event and report different things, because each notices some parts and ignores others. The first assistant saw a pile of books as a simple task. The second assistant saw a pile that might block customers. Each assistant described what was real to him or her.

> Perception is shaped by experience, mood and expectation, and it can mislead.

Perception depends on a person's experience, mood and expectations. A customer who was treated badly in another shop may read a polite remark as false. An employee who expects to be criticised may hear criticism in a neutral question. Perception can also mislead a manager. A first impression, such as a person's clothes or manner of speaking, can colour every later judgement. The remedy is to compare impressions with facts, such as records of work done.^3

^3: Many students find perception difficult to separate from opinion. A useful test is to ask: what did I observe, and what did I add from my own mind? Only the first is fact.

:pause 15.p1 | An employee arrives late twice in one week. The manager decides the employee does not care about the job. Name one piece of observed fact and one piece that the manager may have added from his own mind.

> From four viewpoints, human factors matter to everyone in the shop.

Human factors look different from each viewpoint. The owner sees them as a source of both cost and strength: good relationships keep employees, and poor ones send them away. The manager sees them as the main material of leading. The employee sees them as the feeling of being treated fairly and understood. The customer meets them in every conversation, because the mood of an employee reaches the buyer in a few seconds.

:box IN SHORT
Human factors are the traits, feelings and relationships that affect how people work. They act on three levels: the person, the group and the organisation. Individual differences and perception explain why one instruction can produce different results.

> The recap fixes human factors, individual differences and perception.

*Before moving on.* Human factors are the traits, feelings and relationships of people that affect how they work. They act at the levels of the person, the group and the organisation. Individual differences show how people vary, and perception shows how each person understands the same event in a different way.

* * *

## 15.2 Groups and Teams

> People in a workshop quickly form small circles, and those circles shape the work.

Return to the workshop of the opening. After a few weeks, the two craftsmen at the bench find that they eat their midday meal together and compare their tools. A third craftsman joins them, then a fourth. Soon the four share advice, pass along rumours and help one another when the master is away. No one planned this circle. It formed because people who work near each other tend to join together. This is a group, and it is the second level of human factors.

> A group is two or more people who interact, depend on each other and see themselves as members.

A group is two or more people who interact with each other, depend on each other in some way, and see themselves as belonging together. Passengers who wait at a bus stop are not a group, because they do not interact or depend on one another. The four craftsmen are a group. They talk, they rely on each other, and each of them knows that he belongs. The informal organization, studied in the previous chapter, is made of such groups.

> People form groups for security, belonging, status, help with tasks and shared interests.

Why do people form groups? Several reasons are common. A group offers security, since a person in a group feels less alone when something goes wrong. It satisfies the wish to belong, which most people feel. It can give status, since membership of a respected group raises a person's standing. It gives help with the task, because members share knowledge and skill. Finally, people with a shared interest, such as a love of books, tend to join together. A manager who understands these reasons will not treat every group as a threat.

@ Team | Word in use. In daily life, the players on one side in a sport. In management, a small group of people with joined skills who work toward a common goal.

@ Team | A small group of people with joined skills, working toward a common goal for which they are all accountable.

> A team is a small group with joined skills, a common goal and shared accountability.

Not every group is a team. A **team** means a small group of people with joined skills, working toward a common goal for which they are all accountable. To be accountable is to be answerable for the result. Three features separate a team from an ordinary group. The members have different skills that fit together. They share one goal. They are answerable together for whether the goal is reached. A stock clerk, a buyer and a cashier who work together to prepare a school order form a team. The four craftsmen eating lunch are a group but not a team.

> A table compares a crowd, a group and a team.

The table below sets three kinds of gatherings side by side. Each row names a feature, and the columns show how the feature appears in a crowd, a group and a team. Read across a row to compare the three on one feature.

:table Crowd, group and team compared
| Feature | Crowd | Group | Team |
| Interaction | None or little | Regular | Close and planned |
| Goal | None shared | Often personal | One common goal |
| Accountability | None | Each for self | All for the result |
| Example | Passengers at a bus stop | Colleagues at lunch | Staff preparing a school order |

> Groups develop rules that nobody writes, and these rules are called norms.

Every group, whether it is a team or not, develops rules of behaviour. The rules are rarely written, yet members know them well. A newcomer to the workshop learns, without being told, that one does not leave a mess on the common bench and that one does not criticise a colleague in front of the master. Such rules have a name in management.

@ Norm | Word in use. In daily life, what is normal or average. In management, an unwritten rule of behaviour that a group expects its members to follow.

@ Group norm | An unwritten rule that members of a group follow and expect others to follow.

> A group norm is an unwritten rule that members follow and expect others to follow.

A **group norm** means an unwritten rule that members of a group follow and expect others to follow. A norm may say how fast to work, how to speak to customers, or when to take a break. A norm is shown by what happens to someone who breaks it. The group may laugh, give a look, or leave the person out of conversation. Norms hold a group together, and they are an important part of the informal organization.

> Norms can help the organisation or work against it.

Norms can serve the organisation or oppose it. A norm that says *we help new employees learn the shelves* serves the shop. A norm that says *no one should work faster than the slowest member* works against it, because it limits what the group produces. Managers cannot abolish norms, but they can influence them. They can reward helpful norms, discuss harmful norms openly, and set an example in their own behaviour.

:pause 15.p2 | The three sales assistants of a shop have an unwritten rule that no one sells a book to a customer who is already talking with another assistant. Is this a group norm? Say whether it helps or harms the shop.

> The recap fixes group, team and norm.

*Before moving on.* A group is two or more people who interact, depend on each other and feel that they belong. A team is a small group with joined skills, a common goal and shared accountability. A group norm is an unwritten rule that members follow and expect others to follow. Norms may help the organisation or work against it.

* * *

## 15.3 Creativity and Innovation

> Most organisations are full of ideas, yet few ideas ever reach the customer.

Walk through any shop and ask the employees for ideas. Within an hour you will hear a dozen: a new way to arrange the shelves, a quicker way to check returns, a chair for readers near the window. Now ask a different question: how many of these ideas will ever be tried? In most shops the answer is very few. Between having an idea and using it there lies a gap, and the gap has a cost. This section explains both sides of it.

@ Creativity | The ability to produce new and useful ideas.

> Creativity is the ability to produce ideas that are both new and useful.

The first side is **creativity**. Creativity means the ability to produce new and useful ideas. Both words in the definition matter. An idea that is new but of no use, such as selling books by weight, is only a curiosity. An idea that is useful but not new is only a copy. A sales assistant who thinks of a quiet corner where customers can try a book before buying has produced an idea that is new to the shop and useful to its buyers.

> Creativity comes from knowledge, curiosity and freedom, and not only from special talent.

Creativity is not a gift of artists alone. Every person can produce ideas, and the ideas grow from three sources. The first is knowledge: a person who knows the work well sees where it can be improved. The second is curiosity, the wish to ask *why is it done this way?* The third is freedom, which means room to try and to be wrong. A person who is afraid of being laughed at will keep ideas private. For this reason, creativity depends on the conditions that a manager creates.

@ Innovation | Turning a new idea into a new product, service or method that is put to use.

> Innovation is turning a new idea into something that is put to use.

The second side is **innovation**. Innovation means turning a new idea into a new product, service or method that is put to use. A method is a way of doing a task. Creativity is the seed, and innovation is the crop that grows from it. A suggestion on paper is creativity. A reading corner that stands in the shop and is used by customers is innovation. The step from one to the other needs money, time, a decision and the effort of several people.

> Many creative ideas are not adopted, and a wise organisation chooses among them.

Not every idea should be adopted. Some ideas cost more than they can earn. Some ideas fit poorly with the shop's goals. Some ideas need skills that the shop does not have. An organisation that adopts every suggestion would waste its money, and an organisation that adopts none would stop learning. The aim is to choose well, to test promising ideas on a small scale, and to explain the reasons for refusal to the people who offered them.

> Encouraging ideas needs listening, time, safety to fail, and a way to turn ideas into action.

How can managers encourage ideas? Four practices help. First, listen: ask employees for suggestions and give each one a real hearing. Second, give time and freedom, because employees who are always hurried have no room to think. Third, make failure safe: if a tried idea does not work, treat it as a lesson and not as a fault. Fourth, provide a path from idea to action, such as a simple way to submit suggestions and a promise of an answer.

> Some habits of managers stop ideas before they start.

Some habits stop ideas. Quick ridicule teaches employees to keep silent. The remark *we tried that before* closes a discussion without examining whether conditions have changed. Silence in reply to a suggestion tells the employee that the effort was wasted. A manager who wishes for ideas must watch his own words as carefully as he watches the stock.

> The case file records the suggestions made at Meghna and Sons in 2026.

:case Case file, illustrative. Suggestions recorded at Meghna and Sons for January to June 2026: 14 suggestions were made, and 3 were adopted. A reading corner was built in April 2026 at a cost of Tk 45,000. Weekend sales rose from Tk 180,000 to Tk 207,000 a month, a rise of 15%.

> The record shows the gap between ideas and use, and one idea that crossed it.

The record shows the gap described above. Fourteen suggestions are creativity at work. Three adopted suggestions mark the step into innovation. The reading corner is an idea put into use, and the weekend sales figure records what followed. We now apply these figures in the worked case below.

> The recap fixes creativity, innovation and the encouraging of ideas.

*Before moving on.* Creativity is the ability to produce new and useful ideas. Innovation is turning a new idea into something that is put to use. Managers encourage ideas by listening, by giving time and freedom, by making failure safe, and by providing a path from idea to action.

* * *

## Worked Case: Suggestions and the Reading Corner

> The worked case applies the chapter's ideas to the shop's record.

This section applies the ideas of the chapter to the shop's record. It does not give a model answer. It shows one way of reasoning, step by step, so that you can follow each decision and then repeat it on another case.

> The situation lists the suggestions, the reading corner and the sales.

*Situation.* In January to June 2026, Meghna and Sons recorded 14 suggestions from its staff, and 3 were adopted. A reading corner was built in April 2026 at a cost of Tk 45,000. Weekend sales rose from Tk 180,000 to Tk 207,000 a month.

> The question asks what the figures show about creativity and innovation, and what they cannot show.

*Question.* Which of the figures show creativity and which show innovation? What share of suggestions was adopted? What can be said about the reading corner and the rise in weekend sales?

> Reasoning begins by separating ideas from ideas put to use.

*Reasoning.* First we separate the two ideas. The 14 suggestions measure creativity, because each is an idea offered by a person. The 3 adopted suggestions measure innovation, because they were put to use. The share adopted is 3 divided by 14, which is about 0.214, or 21%. So about one suggestion in five became part of the shop's work. This is not a poor result. It shows that the shop listens and also chooses.

> The reading corner shows an idea put into use, but its link to the sales rise needs care.

Second, the reading corner. The record shows that it was built in April 2026 at Tk 45,000, so it is an idea put into use. The record does not say whether it came from one of the 3 adopted suggestions, and we shall not assume so. The weekend sales rose by Tk 207,000 − Tk 180,000 = Tk 27,000 a month. As a share of the earlier figure this is 27,000 divided by 180,000 = 0.15, or 15%, which agrees with the record. The corner may have helped, but weekend sales can rise for other reasons, such as a change in the weather or in the school year.

> A rough comparison of cost and extra sales helps the owner, but sales are not profit.

Third, a rough comparison. If the rise of Tk 27,000 a month continued, then in about 45,000 divided by 27,000 = 1.7 months the extra sales would equal the cost of the corner. This is only an illustration, because sales are not profit: the shop must still pay for the books it sells. The owner would need the profit on those extra sales to judge whether the corner paid for itself.

> The conclusion states what the figures show and what they leave open.

*Conclusion.* The record shows a shop that collects ideas and adopts one in about five. It shows one idea, the reading corner, put into use, followed by a rise of 15% in weekend sales. It does not prove that the corner caused the whole rise.

> The check tests the arithmetic.

*Check.* We test the numbers. 3 divided by 14 is about 0.214, so 21% is correct. Tk 180,000 plus 15% of Tk 180,000 is Tk 180,000 + Tk 27,000 = Tk 207,000, which matches the record. The cost of Tk 45,000 is greater than one month of extra sales but less than two months, which agrees with our figure of 1.7 months.

* * *

## Summary

> The summary restates the chapter in a few sentences.

Human factors are the traits, feelings and relationships of people that affect how they work, and they act at the levels of the person, the group and the organisation. Individual differences and perception explain why the same instruction can have different results. People form groups for security, belonging, status, help and shared interests. A team is a small group with joined skills, a common goal and shared accountability, and every group develops group norms. Creativity produces new and useful ideas; innovation puts them to use; and managers encourage both by listening and by making failure safe.

## Think It Through

> Four situations test the chapter, from familiar to combined.

Each question below changes the situation a little more than the one before. Answer them in order.

:q 15.t1 | A new employee in a shop smiles at every customer. A second new employee rarely smiles but answers every question correctly. Explain, using individual differences, why a manager should not decide at once which is the better employee.
:q 15.t2 | The three sales assistants have an unwritten rule that they eat lunch at the same time every day. A manager asks them to eat at different times so that the counter is always covered. Name the norm, and explain one way the manager could win their agreement.
:q 15.t3 | Employees stop giving suggestions after a manager repeatedly answers *we tried that before*. Name the habit, explain its effect on creativity and innovation, and suggest one change.
:q 15.t4 | A clinic wants to find ways to reduce waiting time. It asks a nurse, a receptionist and a doctor to work together and report on the result. Is this group a team? Name the three features and say which of them the clinic must make clear for the group to be accountable.

## Where People Go Wrong

> Mistake one: treating employees as if they were machines.

Some managers treat employees as if they were machines that respond in the same way to the same instruction. People differ in ability, attitude and background, and a method that works for one employee may fail for another.

> Mistake two: believing that a group and a team are the same.

Some students believe that a group and a team are the same thing. A team is a small group with joined skills, a common goal and shared accountability. A group of friends at lunch may have none of these.

> Mistake three: believing that norms are always harmful or always helpful.

Some students believe that norms are always a problem for managers. A norm that helps new employees learn the work is useful. The correction is to judge each norm by its effect on the goals of the organisation.

> Mistake four: confusing creativity with innovation.

Some students use the words *creativity* and *innovation* as if they meant the same. Creativity is producing the idea. Innovation is putting the idea into use. An organisation can be rich in creativity and poor in innovation.

## In History

> Post-it notes grew from a weak adhesive found at 3M in 1968 and were launched in 1980.

The American company 3M, based in Minnesota, makes many products from adhesives to abrasives. In 1968, a scientist named Spencer Silver was working at 3M's headquarters in Maplewood, Minnesota, on a strong adhesive. He produced the opposite: a weak adhesive that held lightly and could be pulled off and stuck again. He believed that it was unusual and useful, but for several years he could not find a use for it.

> Art Fry linked the weak adhesive to a bookmark problem, and the company tested the product and sold it in 1980.

Another 3M employee, Art Fry, sang in a church choir. His paper bookmarks kept falling out of his hymnbook. Fry remembered Silver's adhesive, and he saw that it could make a bookmark that stayed in place without damaging the page. He then saw that it would work better as a note. Sources date his idea to the early 1970s. Market tests in several cities gave mixed results, and 3M nearly stopped the product, but in 1980 Post-it notes were made available to customers in the United States.

> The case shows creativity first, then the long step to innovation.

The case shows both ideas of this chapter. Silver's adhesive was a creative result, new but without a known use. Fry's idea joined it to a need, and the work of testing, making and selling turned it into an innovation. The company allowed its scientists to share ideas with each other, and this freedom helped the idea to travel from one person to another.

## Review Questions

:q 15.1 | In your own words, state what is meant by human factors, and name the three levels at which they act.
:q 15.2 | Tell a group from a team. Give one example of a group that is not a team, and one example of a team.
:q 15.3 | Name two ways in which a manager can stop creative ideas, and two ways of encouraging them.
:q 15.4 | Explain the difference between creativity and innovation, using the reading corner at Meghna and Sons or another example.
