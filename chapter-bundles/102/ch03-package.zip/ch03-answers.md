:answers 03
:a 3.p1 | Week 1: 600 ÷ 3 = 200 books per employee. Week 2: 800 ÷ 5 = 160. Productivity fell, although the total rose.
:a 3.p2 | It is effective, because every planned parcel was delivered. It is not efficient, because it used twice the budget.
:a 3.t1 | The firm reached its goal of 300 parcels, so it was effective. The vans used twice the distance needed, so input was wasted and it was not efficient. Better planning of routes would help most.
:a 3.t2 | 45,100 ÷ 8 = 5,637.5, so about 5,638 copies per employee. This is lower than the 5,857 of 2025, because input grew while output stayed at the forecast level.
:a 3.1 | Planning, organising, leading, controlling. Examples: set the sales target; assign jobs to the 7 employees; encourage the sales assistants; compare actual sales with the target.
:a 3.2 | Before: 1,800 ÷ 4 = 450 loaves per baker. After: 2,100 ÷ 4 = 525. Change: 75 ÷ 450 = 0.1667, a rise of about 16.7%.
:a 3.3 | Productivity is a ratio. If input grows faster than output, the ratio falls. Example: 600 books with 3 employees is 200 each; 800 books with 5 employees is 160 each.
:a 3.4 | Effectiveness is how far goals are reached, whatever the cost. Efficiency is how little input a result needs. A firm that does a wrong job very cheaply is efficient but not effective.
:a 3.5 | Long training, a body of knowledge, and a code of conduct enforced by an association. For a small shop, no licence or governing body is required, so the enforced code and association are missing.
:a 3.6 | A law of physics holds every time. A principle is drawn from experience and must be adapted, because it may suit one organisation and fit another badly.
