:answers 09
:a 9.p1 | For example, sales and customer service. In sales, a shop that does not sell cannot survive; in customer service, poor service loses customers.
:a 9.p2 | A cycle suits MBO because results from one period teach what objectives to agree for the next. A straight line would end after one year and waste what was learned.
:a 9.t1 | Sample: (1) key result area: results; measure: share of pupils passing the year-end tests; target 85%; period: the next school year. (2) key result area: staff development; measure: hours of training per teacher; target 14 hours; period: the next school year.
:a 9.t2 | Two ways: objectives imposed by the head teacher, so teachers feel no ownership (fix: agree each objective in a meeting); results judged that a teacher cannot control (fix: agree objectives only for results the teacher can influence, and review them during the year).
:a 9.1 | An objective is a specific result that an organisation or person intends to reach within a stated time. An activity is something done, such as holding a sale; an objective is what is reached, such as selling 2,000 copies.
:a 9.2 | Sample: "Sales to schools of Tk 4,000,000 in 2026"; "Stock turnover of at least 3.2 times in 2026"; "12 hours of customer-service training per employee in 2026". Each names a measure, a target and a period.
:a 9.3 | Average stock = cost of sales ÷ turnover = 9,800,000 ÷ 3.2 = Tk 3,062,500. Check: 3,062,500 × 3.2 = 9,800,000.
:a 9.4 | (1) Organisation states objectives; (2) manager and employee agree individual objectives; (3) employee acts with self-control; (4) progress is reviewed; (5) performance appraisal; (6) results guide the next period. Performance appraisal is stage five.
:a 9.5 | Benefits, any two of: clarity, commitment, coordination, fair appraisal, development of people. Weaknesses, any two of: paperwork, bias towards what is easy to count, short-term focus, rigid objectives, pressure when used badly.
