:chapter IX | Objectives and Management by Objectives
:mood Where are we going, and how will we know when we have arrived?
:desc This chapter explains what an objective is, how to write one that can be measured, and how managers and employees can agree objectives together. It follows one bookshop through the objectives set for 2026 and ends with the system that Peter Drucker described in 1954.
:plate ch09-plate.svg | A traveller at a crossroads, studying a signpost before choosing a road

:box YOU WILL NEED
Chapter 7, 'Planning: Meaning, Nature and Steps', section 7.1 'What Planning Is'; and Chapter 8, 'Kinds of Plans and Making Planning Work', section 8.1 'Kinds of Plan'. Chapter 7 explains what a plan is and why managers make plans. Chapter 8 describes the kinds of plan, such as standing plans and single-use plans. This chapter starts where those two end: every plan needs a place to reach.

> Two students make two promises, and only one of the promises can be checked.
Imagine two students at the start of a school year. The first says, "I want to do well this year." The second says, "I will score at least 70 out of 100 in every subject in the final tests, and I will study for two hours on each weekday evening." One year passes. Can the first student say whether she kept her promise? She cannot. The word "well" has no edge, so any result can be called well or badly, depending on her mood. The second student can answer in one minute, by reading her results and her study record.

> A shop has the same problem as the first student: a wish with no edge cannot be steered towards or checked.
Now put a shop in place of the student. The owner says, "We must improve the business." The stock clerk hears this and decides to tidy the storeroom. The cashier decides to serve customers faster. The store manager decides to buy more stock. Each person works hard, and each person chooses a different road. A year later, nobody can say whether the business improved, because nobody said what improvement would look like.

> A plan is a road, and a road is useful only after someone names the place it leads to.
In Chapter 7 you studied the plan, which is a chosen way to reach a result. A plan is a road. A road helps only when someone has named the town at its end. Picture a traveller at a crossroads with four roads and a signpost whose arms carry no names. The traveller has energy and a good map, and still cannot choose. An organisation can be in the same position: busy every day, yet unable to say what the work is for.

> This chapter answers one question in three steps and then shows the system that joins them.
The question for this chapter is therefore: how does a wish become a result that a whole organisation can steer by and check? The destination has a formal name, *objective*, which section 9.1 defines. Section 9.1 also shows which parts of an organisation's work deserve an objective. Section 9.2 shows how to write one so that anyone can tell afterwards whether it was reached. Section 9.3 describes a system, called management by objectives, in which managers and employees agree objectives together. Along the way we follow a bookshop in Dhaka through the objectives it agreed for 2026. Many students find the word *objective* confusing, because it also has an everyday meaning. We deal with that at once, so that it does not trouble you later.

* * *

## Objectives

> A traveller needs a named destination before any road makes sense.
Return to the traveller at the crossroads. Suppose each arm of the signpost now carries a name and a distance: "Market town, 12 kilometres." The traveller can choose a road, can measure progress along it, and can tell on arrival that the journey is over. An organisation needs the same signpost for its work. Without one, each person guesses the direction, and the guesses differ.

> Recall: planning, Chapter 7, 'Planning: Meaning, Nature and Steps', section 7.1 'What Planning Is'.
> An objective is a specific, dated result that an organisation intends to reach.
@ Objective | Word in use. In daily life, "objective" can describe a fair opinion that does not depend on feelings, and it is also the lens of a microscope. In management, it is a noun: a result to be reached.
@ Objective | A specific result an organisation or person intends to reach within a stated time.
An **objective** means a specific result that an organisation or a person intends to reach within a stated time. For example, "sell 500 copies of one school textbook before 30 June" is an objective, because it names a result, a number and a date. In everyday talk people say goal or aim. In this book, objective is the formal word, and goal appears only in plain talk. An organisation usually holds several objectives at once, and together they decide which plan it chooses from the alternatives open to it.

> Objectives give direction, join effort, motivate and supply a measure for later checks.
Why does an organisation need objectives? There are four reasons. Objectives give direction, because every person knows the destination. They join effort, because the cashier and the stock clerk steer towards the same place. They motivate, because people work harder towards a result they can see and reach. They supply a measure: when the year ends, the result can be set beside the objective. Chapter 18, 'Controlling', teaches how that comparison is used.

> Objectives have five features: a result, a time, a measure, a network and a possible conflict.
@ Objective | Word in use. See the note above: in management, a result to be reached.
Objectives share several features, and each feature helps you test whether a statement deserves the name. First, an objective names a result, not an activity. "Hold a sale" is an activity. "Sell 2,000 copies in the sale" is a result. Second, an objective states a time. A result with no date can always be postponed. Third, an objective carries a measure where one is possible; section 9.2 returns to this. Fourth, objectives form a network. The organisation's objectives lead to objectives for each department, and these lead to objectives for individual employees. Fifth, objectives can conflict. A shop that cuts its stock to save money may find that it cannot also promise every customer that every title is on the shelf. The manager balances the objectives and does not pretend that the conflict is absent.

> The same objective looks different to the owner, the manager, the employee and the customer.
Each person sees an objective from a different position. The owner sees a result that must be paid for and protected. The manager sees a task to be shared among people. The employee sees a measure of what is expected, and so of what counts as a good year. The customer rarely sees the objective itself, yet feels its effect, for example in better service at the counter.

> Key result areas are the few parts of the work where results decide success.
@ Key result area | A part of the organisation's work where results are vital to success.
An organisation does many things, and it cannot give an objective to every action. Where should it place its effort? The answer is the **key result area**, which means a part of the organisation's work where results are vital to success. For a bookshop, sales are one key result area, because a shop that does not sell cannot survive. Stock is another, because too little stock loses sales and too much stock ties up money. Customer service, returns and profit are further examples. The list stays short on purpose. If an organisation names twelve areas as vital, none of them is vital. The list also changes with time: a new shop may treat winning customers as the vital area, while an old shop may treat cost control as vital.

> The five 2026 objectives in the case file fall in five key result areas.
:case Case file, illustrative. Meghna and Sons, a family-run bookshop in Dhanmondi, Dhaka, founded on 4 April 1996 by Nurul Meghna, agreed five objectives for 2026. They are: sales of Tk 15,840,000; profit of Tk 900,000; returns below 2% of sales; 14 hours of customer-service training per employee; and stock turnover raised from 2.8 to 3.2 times.^1 Nurul Meghna and Rafiq Meghna, the store manager, agreed them on 5 January 2026. Each objective lies in one key result area: sales, profit, returns, customer service and stock.

^1: Tk is the symbol for the taka, the currency of Bangladesh. Large amounts are written with commas in groups of three digits.

> Before moving on: objectives are results with a time, and key result areas say where to place them.
*Before moving on.* An objective is a specific result to be reached within a stated time. It differs from an activity, which is only something done. Objectives give direction, join effort, motivate and supply a measure. A key result area is a part of the work where results decide success, and the five objectives in the case file lie in five such areas.

:pause 9.p1 | Name two key result areas for a small school, and say why a result in each area decides whether the school succeeds.

* * *

## Setting Objectives

> Take a vague wish and sharpen it, one step at a time, until anyone can check it.
Start with a wish that many organisations write: "Improve customer service." Can anyone check this statement in December? No one can. Now sharpen it in four moves. First, choose the key result area: customer service. Second, choose a measure for that area: the number of hours of training each employee receives. Third, add the number: 14 hours. Fourth, add the period: the year 2026. The sharpened statement reads: "14 hours of customer-service training per employee in 2026." It is one of the five objectives in the case file, and a person can check it by counting hours.

> Good objective-setting follows six steps, from the key result area to agreement with the person responsible.
The example contains the whole technique, which has six steps. Step one: choose the key result area. Step two: state the result you want, in words that name a result and not an activity. Step three: attach a measure, which is the unit used to count progress, such as taka, hours or percentage. Step four: fix the number and the date. Step five: test the objective. Can it be reached with the people, money and time available, and does it ask for more than last year, so that effort is needed? Step six: agree the objective with the person who must deliver it. An objective that the responsible person has never discussed is only an instruction.

> A target is the number in an objective, and the measure tells you what the number counts.
@ Target | Word in use. In daily life, a mark that you aim at, such as the centre of a board. In management, the number or level written into an objective, such as 3.2 times for stock turnover.
The words measure, number and target need care. The measure is the unit, such as taka of sales. The target is the number set for that unit, such as Tk 15,840,000. Together they make an aim that can be measured. The table below shows four vague wishes beside the measurable objectives from the case file. Read each row from left to right: the first column gives a wish, the second gives the objective that sharpens it, and the third names the measure.

:table Four vague wishes sharpened into the objectives in the case file
| Vague wish | Measurable objective | Measure |
| Sell more | Sales of Tk 15,840,000 in 2026 | Taka of sales |
| Keep returns low | Returns below 2% of sales | Share of sales |
| Train the staff | 14 hours of customer-service training per employee | Hours per employee |
| Hold less stock | Stock turnover from 2.8 to 3.2 times | Times per year |

> The sales and profit targets are set above the 2025 results, which makes them stretch targets.
:case Case file, illustrative. In 2025 Meghna and Sons recorded sales of Tk 14,400,000 and profit of Tk 750,000. The 2026 objectives are sales of Tk 15,840,000 and profit of Tk 900,000. The sales objective is Tk 1,440,000 above the 2025 result, an increase of 10%.^2 The profit objective is Tk 150,000 above the 2025 result, an increase of 20%.

^2: A percentage means a part in every 100. An increase of 10% on Tk 14,400,000 is 14,400,000 × 10 ÷ 100 = Tk 1,440,000, and Tk 14,400,000 + Tk 1,440,000 = Tk 15,840,000.

> A measurable aim has limits: some results resist counting, and a number can mislead.
Two exceptions deserve attention. First, not every result can be counted directly. The quality of advice from a sales assistant is hard to put in a number, so organisations often count something close to it, such as hours of training. The count is a substitute and should be treated with care. Second, a number can mislead. A manager who chases a sales target may reduce prices until profit disappears. This is why an organisation sets several objectives together, so that each one guards against the harm that another might cause.

> Objectives link level to level, from the owner to the manager to each employee.
Objectives also link levels. The owner's sales objective becomes an objective for the store manager, who divides it among customer groups and among employees. For illustration only, and not as part of the case file, suppose sales to walk-in customers, schools and online buyers each rise by 10% above their 2025 values of Tk 9,000,000, Tk 3,600,000 and Tk 1,800,000. The three new values are Tk 9,900,000, Tk 3,960,000 and Tk 1,980,000, and they add to Tk 15,840,000. Each person who owns one part can see how it supports the whole.

> Before moving on: a good objective names a result, a measure, a number and a date, and the person responsible agrees it.
*Before moving on.* To set an objective, choose the key result area, state a result, attach a measure, fix a number and a date, test whether it can be reached, and agree it with the person responsible. The measure is the unit; the target is the number. Be careful with results that resist counting, and set several objectives together so that one does not damage another.

* * *

## Management by Objectives

> Two shops can hold the same objectives on paper and still behave very differently.
Imagine two shops with identical objectives. In the first, the owner writes a number on a sheet for each employee and hands the sheet over. In the second, the owner meets each employee, discusses the number, changes it where the employee shows a good reason, and both people agree it. Which shop will reach its objectives with more commitment? Most people answer the second, and that answer is the seed of this section.

> Peter Drucker gave the idea its name in 1954, in a book about the practice of management.
In 1954 Peter Drucker, a writer on management born in Vienna and working in the United States, published *The Practice of Management*. In it he described a way of managing in which objectives are agreed between the manager and each employee, and in which each employee then judges his or her own progress. Drucker used the phrase "management by objectives and self-control".^3 Later writers shortened it to MBO. Section 'In History' near the end of this chapter tells more of his story.

^3: Self-control here means that employees check their own results against the agreed objectives, and do not wait for a manager to tell them how they are doing. It does not mean control by the self in the sense of controlling one's temper.

> Management by objectives is a system: agree objectives together, work towards them, then judge the results against them.
@ Management by objectives | A system in which managers and employees agree objectives together, then judge performance against them.
**Management by objectives** means a system in which managers and employees agree objectives together, then judge performance against them. For example, the owner and the store manager meet in January, agree the store manager's objectives for the year, and meet again in December to compare the results with those objectives. The word *together* matters. Objectives that one person imposes on another do not make a system of management by objectives. They make a system of orders with numbers attached.

:box IN SHORT
Management by objectives is a cycle. Agree objectives together, work towards them with freedom to choose the means, review progress during the year, appraise the results at the end, and use what is learned to agree the objectives for the next year.

> The case file shows the first stage of the cycle: two people agreeing objectives.
:case Case file, illustrative. On 5 January 2026, Nurul Meghna and Rafiq Meghna agreed the objectives for the year: sales of Tk 15,840,000; profit of Tk 900,000; returns below 2% of sales; 14 hours of customer-service training per employee; and stock turnover raised from 2.8 to 3.2 times. The file records the agreement between these two people. It does not record later stages of the cycle.

### The Process of MBO

> The process has six stages, and the last stage leads back to the first.
The process of management by objectives has six stages. In stage one, the organisation states its own objectives for the period. In stage two, each manager and employee agree the objectives for his or her own work, so that these support the organisation's objectives. In stage three, each person plans the means and acts. During this stage the employee has freedom to choose how to work, and checks his or her own progress; this is the self-control that Drucker named. In stage four, manager and employee review progress during the period, and they change an objective if conditions have changed. In stage five, performance appraisal takes place at the end of the period. In stage six, the results guide the objectives for the next period, and the cycle begins again.

> Recall: kinds of plan, Chapter 8, 'Kinds of Plans and Making Planning Work', section 8.1 'Kinds of Plan'.
> In stage three, each person chooses plans and means that fit the agreed objective.
In stage three a person chooses the means. The kinds of plan from Chapter 8 are tools here. A standing plan, such as a policy on how to handle a customer's complaint, repeats from year to year. A single-use plan, such as a project to fit security tags in one month, serves one objective once. Every plan rests on planning premises, which are the assumptions about the future that the plan accepts. An objective of Tk 15,840,000 in sales assumes that demand from schools and walk-in customers will stay about as strong as before. If that assumption fails, the review in stage four is the moment to say so.

> Performance appraisal is the stage where results are compared with the agreed objectives.
@ Performance appraisal | A review of how well an employee has done against agreed standards.
A **performance appraisal** means a review of how well an employee has done against agreed standards. In management by objectives, the standard is the objective agreed at the start, so the appraisal asks one question: what was the result, compared with the number we agreed?^4 For example, an employee who agreed to receive 14 hours of training and received 10 can be told the gap and asked why it arose. The appraisal is also a time to plan help, such as more training.

^4: A standard is a level of performance fixed in advance as the measure of what is acceptable. Chapter 18, 'Controlling', teaches it in full. Here it means only the agreed objective.

> To read the ring, start at the top and follow the arrows clockwise; the last arrow returns to the start.
Figure 9.1 shows the six stages as a ring. To read it, begin at the box at the top and follow the arrows in the direction of the clock. Each box is one stage. Each arrow shows which stage comes next. After the last box, an arrow returns to the first box, which shows that the process is a cycle and does not end after one year.

:fig The MBO cycle as a ring | ch09-fig01.svg

:pause 9.p2 | The last arrow of the ring returns to the first stage. Explain why a cycle suits management by objectives better than a straight line.

### The Benefits of MBO

> MBO brings clarity, commitment, coordination, a fair basis for appraisal and a way to develop people.
Management by objectives offers five benefits. It brings clarity, because each person knows what the organisation expects. It brings commitment, because people who help to set an objective feel responsible for it. It improves coordination, because each person's objectives support the objectives above. It gives a fair basis for appraisal, because the judgement uses a number agreed in advance and not a general impression. It helps to develop people, because the review shows where an employee needs training. Each person gains in a different way. The owner gains control without checking every action. The manager gains a sound way to share work. The employee gains knowledge of what counts as a good year. The customer gains from a shop whose people all work towards the same result.

### The Weaknesses of MBO

> MBO has weaknesses: heavy paperwork, a bias towards what is easy to count, short-term focus and rigid objectives.
No system is free of faults, and management by objectives has several. It takes time, because meetings and records are needed for every employee. It favours results that are easy to count, so quality may suffer, as you saw in section 9.2. It can push attention towards the short term, since a year is the usual period. It can make objectives rigid: an employee may keep following an objective after conditions have made it useless. It can be unfair when an employee is judged on a result that depends on events outside his or her control. It can fail when top managers do not support it, or when they use the cycle to place pressure on people. A system that works only on paper has the weaknesses of MBO and none of its benefits.

> The table sets each benefit against the weakness that most often accompanies it.
The table below sets four benefits beside the risk that goes with each. Read each row from left to right: the first column gives a benefit, and the second column gives the way that benefit is lost when the system is poorly used.

:table Four benefits of MBO and the matching risk
| Benefit | Matching risk |
| Clarity of expectations | Objectives chosen because they are easy to count |
| Commitment from agreement | Objectives imposed, so agreement is only on paper |
| Fair basis for appraisal | Results judged that the employee cannot control |
| Coordination across levels | Heavy paperwork that takes time from the work |

> Before moving on: MBO is a cycle of agreed objectives, self-control, review and appraisal, with real benefits and real risks.
*Before moving on.* Management by objectives is a system in which managers and employees agree objectives together and judge performance against them. Its six stages are: state the organisation's objectives, agree individual objectives, act with self-control, review progress, appraise performance, and begin the cycle again. Its benefits are clarity, commitment, coordination, fair appraisal and development. Its weaknesses are paperwork, a bias towards what is easy to count, a short-term focus, rigid objectives and pressure when it is used badly.

* * *

## Worked Case: Making the Stock Objective Measurable

> The worked case tests the stock objective in the case file from wish to number.
Case file, illustrative. We now apply the ideas of this chapter to one objective. We take it in the order *Situation, Question, Reasoning, Conclusion, Check*, so that each step is announced and explained.

> The situation states the objective and the figures that give it meaning.
*Situation.* The case file records the wish that Meghna and Sons should hold stock more efficiently. The objective agreed on 5 January 2026 is stock turnover raised from 2.8 to 3.2 times. Here stock means the books that the shop holds for sale. Stock turnover means the number of times in a year that the shop sells its average stock, found by dividing cost of sales by average stock. Cost of sales is Tk 9,800,000, and average stock is Tk 3,500,000.

> The question asks whether the objective can be measured and what stock it implies.
*Question.* Is the objective measurable? And if cost of sales stays at Tk 9,800,000, how much average stock does the shop need to reach 3.2 times?

> The 2025 figures show where the shop starts, and the formula shows what the number means.
*Reasoning.* First we confirm the starting point. The formula in words is: stock turnover equals cost of sales divided by average stock. With the numbers: 9,800,000 ÷ 3,500,000 = 2.8. So 2.8 is the 2025 starting point, and the objective is measurable, because it names a measure (times per year), a target (3.2) and a period (2026). Next we find the stock that gives 3.2. Rearrange the formula: average stock equals cost of sales divided by turnover. Then 9,800,000 ÷ 3.2 = 3,062,500. The shop therefore needs average stock of Tk 3,062,500. The reduction is 3,500,000 − 3,062,500 = Tk 437,500.

> The conclusion and the check show that the objective is measurable and that its arithmetic holds.
*Conclusion.* The objective is measurable. If cost of sales stays at Tk 9,800,000, reaching 3.2 times means holding average stock of Tk 3,062,500, which is Tk 437,500 less than in 2025. *Check.* Multiply back: 3,062,500 × 3.2 = 9,800,000, which equals cost of sales. The arithmetic holds. One more test uses the idea of conflict from section 9.1: a smaller stock may lead to titles being out of stock, which could reduce sales. This is why the sales objective and the stock objective must be read together.

* * *

## Summary

> The summary states the chapter in a few lines.
An objective is a specific result to be reached within a stated time. Key result areas show where objectives matter most. To set an objective, name a result, a measure, a target and a date, and agree it with the person responsible. Management by objectives is a system in which managers and employees agree objectives together and judge performance against them, and its cycle runs from agreement to action, review and appraisal, and back to agreement. The system has real benefits and real risks.

## Think It Through

> The problem asks you to apply the chapter to a school.
A school with 600 pupils and 30 teachers wants to adopt management by objectives. Its head teacher says only: "We want to be a better school." Use the ideas of this chapter to answer both questions below.

:q 9.t1 | Write two measurable objectives for the school. For each, name the key result area, the measure, the target and the period.
:q 9.t2 | Describe two ways in which management by objectives could fail in the school, and say what the head teacher could do to prevent each.

## Where People Go Wrong

> Six common misunderstandings about objectives are stated and corrected here.
The first misunderstanding is that an activity is an objective. "Hold a book fair" says what is done and not what is reached. Correction: name the result, such as the number of copies sold. The second is that a vague word is enough. "Better" and "improve" have no edge. Correction: add a measure, a target and a date.

> Further misunderstandings concern the number of objectives, the way they are set and their permanence.
The third misunderstanding is that more objectives are better. Twenty objectives divide attention, and the key results are lost among them. Correction: choose the few that decide success. The fourth is that management by objectives means a manager hands out numbers. Correction: the system depends on agreement, and an imposed number is only an order. The fifth is that objectives never change. Correction: review them during the period, and change one when conditions have changed. The sixth is that a measured result is always the whole truth. Correction: a number can hide poor quality, so read objectives together and add judgement.

## In History

> Drucker published management by objectives in 1954, and many organisations adopted it afterwards.
Peter Drucker was born in Vienna on 19 November 1909 and died on 11 November 2005. He moved to the United States, worked as a writer and adviser on management, and published *The Practice of Management* in 1954. The book treated management as a practice that can be studied and taught. In it he described management by objectives and self-control, and he proposed that a business set objectives in a small number of key areas. His list had eight, among them market standing, innovation and profitability.

> Drucker drew on practice he had seen, and the idea spread widely and was later criticised.
Drucker did not claim to have invented every part of the idea. He drew on practices that he had observed in large organisations. What he added was a clear statement that the objectives of the organisation should be turned into objectives for each manager, and that each manager should use them to guide and to judge his or her own work. In the following years, many firms and public bodies adopted the system. Later experience showed its faults too: paperwork, a bias towards what is easy to count, and misuse as a tool of pressure. These faults are in section 9.3. Drucker's central point remains useful: people work better when they know the result expected and have helped to define it.

## Review Questions

> The review questions test each main idea of the chapter.
:q 9.1 | Define objective in your own words, and say how an objective differs from an activity.
:q 9.2 | Rewrite each wish as a measurable objective, adding a measure, a target and a period: "Sell more books to schools", "Keep stock low", "Make staff more helpful". Use figures of your own.
:q 9.3 | In the case file, stock turnover is cost of sales divided by average stock. If cost of sales is Tk 9,800,000, find the average stock that gives a turnover of 3.2 times.
:q 9.4 | List the six stages of the MBO process in order, and name the stage in which performance appraisal takes place.
:q 9.5 | Give two benefits and two weaknesses of management by objectives.

:read Peter F. Drucker, The Practice of Management, 1954
