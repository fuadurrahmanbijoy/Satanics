:glossary 09
Objective | A specific result that an organisation or person intends to reach within a stated time. It names a result, a measure, a number and a date. Example: selling 500 copies of one textbook before 30 June.
Key result area | A part of the organisation's work where results are vital to success. A bookshop might name sales, stock, customer service, returns and profit as its key result areas, and set objectives in each.
Management by objectives | A system in which managers and employees agree objectives together, then judge performance against them. Its cycle runs from agreeing objectives, to acting with self-control, to review and appraisal, and back to agreement. Peter Drucker described it in 1954.
Performance appraisal | A review of how well an employee has done against agreed standards. In management by objectives, the standard is the objective agreed at the start. Example: an employee who agreed 14 training hours and received 10 is told the gap.
