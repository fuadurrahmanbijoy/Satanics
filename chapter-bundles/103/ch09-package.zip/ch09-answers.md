:answers 09
:a 9.p1 | A credit of Tk 300: credit Tk 800 less debit Tk 500. This balance is the net income.
:a 9.t1 | Tk 788,000 + Tk 900,000 = Tk 1,688,000. The figure mixes two years, so the 2027 income statement would overstate revenue by Tk 788,000.
:a 9.t2 | The balance sheet needs ending capital. Ending capital comes from the statement of owner's equity (starting capital plus net income minus drawings), so that statement must come first.
:a 9.1 | Income statement: what did the business earn? Statement of owner's equity: how did capital change? Balance sheet: what does the business own and owe on one date? The first two headings end *For the year ended …*; the balance sheet heading ends *At …*.
:a 9.2 | Net income is Tk 12,000 − Tk 7,000 = Tk 5,000. Ending capital is Tk 10,000 + Tk 5,000 − Tk 1,000 = Tk 14,000. Assets are Tk 6,000 + Tk 2,000 + Tk 9,000 = Tk 17,000; liabilities Tk 3,000 plus capital Tk 14,000 also give Tk 17,000.
:a 9.3 | Step 1: debit Revenue 12,000, credit Income Summary 12,000. Step 2: debit Income Summary 7,000, credit Expenses 7,000. Step 3: debit Income Summary 5,000, credit Owner's Capital 5,000. Step 4: debit Owner's Capital 1,000, credit Drawings 1,000.
:a 9.4 | Temporary: Revenue, Wages Expense, Drawings. Permanent: Prepaid Insurance, Wages Payable, Owner's Capital.
:a 9.5 | 1 January 2027: debit Wages Payable 6,000, credit Wages Expense 6,000. 4 January 2027: debit Wages Expense 8,000, credit Cash 8,000. Wages expense of 2027 is Tk 8,000 − Tk 6,000 = Tk 2,000.
:a 9.6 | The net loss is Tk 11,000 − Tk 9,000 = Tk 2,000, so Income Summary has a debit balance. Step 3: debit Owner's Capital 2,000, credit Income Summary 2,000. Capital falls by Tk 2,000.
