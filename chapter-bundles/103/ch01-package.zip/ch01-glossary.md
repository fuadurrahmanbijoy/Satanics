:glossary 01
Service business | A business that earns money by doing work for customers rather than by selling goods. The customer pays for the work performed, such as a repaired book, a haircut or a lesson, and takes home no goods that the business bought or made.
Merchandising business | A business that buys finished goods and sells them again at a higher price. It does not change the goods. A bookshop that buys books from publishers and sells the same books to readers is an example.
Manufacturing business | A business that makes goods from materials and then sells them. It holds materials, goods half finished and goods ready to sell. A bakery that turns flour and fuel into bread is an example.
Company | A business that the law treats as a person separate from its owners. Its ownership is divided into equal parts called shares, so it can have many owners. It can own goods and owe money in its own name.
Shareholder | A person who owns one or more shares of a company. A person who holds one tenth of the shares owns one tenth of the company. More shares give a larger part of the ownership.
