:answers 01
:a 1.p1 | It is a merchandising business, because it buys finished goods (rice) and sells them again without changing them.
:a 1.p2 | One quarter, because 25 is one quarter of 100.
:a 1.t1 | Its customers pay for work, so it holds no goods bought for resale. It still records fees, wages, rent and any money owed, and the materials it uses are a cost of the work.
:a 1.t2 | The salon combines a service business (hair work) with a merchandising business (shampoo bought and resold). If shampoo is a small part of its income, the service kind brings in most of its money.
:a 1.t3 | Not in the sense of this chapter, because the club does not supply goods or services to earn a profit. It still needs records of the fees it collects and the money it spends.
:a 1.t4 | It combines manufacturing (bread baked from materials) and merchandising (tea bought and resold). Ownership has the shape of a partnership, with three owners. Any one of the three friends, a lender or the tax authority would need its records.
:a 1.1 | The tailor is a service business, the grocer is a merchandising business, and the furniture workshop is a manufacturing business.
:a 1.2 | Examples: the owner (whether the bakery earns a profit), a lender (whether a loan can be repaid), the tax authority (how much tax is due), and an employee (whether wages will be paid).
:a 1.3 | 410,000 shares × Tk 10 = Tk 4,100,000. One tenth of 410,000 is 41,000 shares.
:a 1.4 | A shareholder is a person who owns one or more shares of a company. A merchandising business buys finished goods and resells them, while a manufacturing business makes goods from materials and then sells them.
:a 1.5 | It is a service business, because it repairs and binds books for schools. Separate records let the owner see the result of each business alone and judge each one fairly.
