:glossary 06
Trial balance | A list of all ledger account balances, with debits and credits totalled, to test that they are equal. It is taken at one date. If the two totals agree, the test is passed; if they differ, a slip must be found.
Unadjusted trial balance | A trial balance taken before the period-end adjustments have been recorded. The January list of Meghna Binding Service is unadjusted, because no adjustment has yet been made to the accounts.
Transposition error | A mistake in which two digits of a number are written in the wrong order, such as 53 for 35. Posted on one side only, it makes the trial balance totals differ by a multiple of 9, here 18.
Suspense account | A temporary account that holds a difference until its cause is found. It takes the side that makes the two column totals agree, and it must be cleared by a correcting entry before reports are prepared.
