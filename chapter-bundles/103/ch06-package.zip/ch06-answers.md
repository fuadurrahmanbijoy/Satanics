:answers 06
:a 6.p1 | Every entry has equal debits and credits, and posting copies both sides, so the ledger holds equal totals of debits and credits. Balancing removes the same amount from both totals, so the debit balances still equal the credit balances.
:a 6.t1 | Two examples: the 15 January rent entry left out entirely, which leaves Cash at Tk 305,000 and Rent at nil but both totals at Tk 660,000; and wages debited to Rent instead of Wages, which leaves the totals equal but Rent wrongly at Tk 95,000 and Wages at nil.
:a 6.1 | Debits: 50,000 + 30,000 = Tk 80,000. Credits: Tk 80,000. The totals are equal.
:a 6.2 | Debits: 187,450 + 96,300 + 150,000 + 42,000 + 78,500 = Tk 554,250. Credits: 64,250 + 400,000 + 90,000 = Tk 554,250. The trial balance is balanced.
:a 6.3 | Difference = 465,500 − 458,900 = Tk 6,600, with credits larger. 6,600 ÷ 9 is not a whole number, so a transposition is unlikely. Half is Tk 3,300, which suggests a debit balance of Tk 3,300 listed in the Credit column.
:a 6.4 | The debits fall short by Tk 7,200, so a suspense account with a debit balance of Tk 7,200 is added in the Debit column.
:a 6.5 | Difference = 81,000 − 18,000 = Tk 63,000, with debits larger (63,000 ÷ 9 = 7,000). The credits are short, so the suspense balance of Tk 63,000 goes on the credit side. Correcting entry: debit Suspense 63,000, credit Rent 63,000. Narration: Corrected rent posted as 81,000 instead of 18,000, and cleared the suspense account.
