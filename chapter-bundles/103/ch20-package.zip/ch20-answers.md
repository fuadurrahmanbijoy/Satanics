:answers 20
:a 20.p1 | Freight in (Tk 40,000) is a product cost, because it is part of bringing goods to the shop. Rent (Tk 180,000) is a period cost, because it belongs to the time the building is used.
:a 20.p2 | Cash, an asset, falls by Tk 5,000, and accounts payable, a liability, falls by Tk 5,000. Both sides fall by the same amount, so the balance sheet still balances.
:a 20.t1 | Two changes: every report would cover 1 July to 30 June, and the quarters would end on 30 September, 31 December, 31 March and 30 June, so the quarter ended 30 September 2026 would become a first quarter. Moving from a December year-end also needs a bridging period of six months, 1 January to 30 June. The accounts, the debit and credit rules and the split between product costs and period costs stay the same.
:a 20.t2 | A year ending when trade is quiet, such as soon after the term-start rush, is a good choice. Inventory is low and easy to count then, and the whole busy season falls inside one year.
:a 20.1 | Product costs: books bought and freight in. Period costs: shop rent, wages of the shop assistants and delivery to a customer (freight out).
:a 20.2 | Gross profit is Tk 600,000 − Tk 380,000 = Tk 220,000. Profit is Tk 220,000 − Tk 150,000 = Tk 70,000.
:a 20.3 | The order is: journal, posting to the ledger, trial balance, adjusting entries, adjusted trial balance, the three statements, closing entries, post-closing trial balance. The adjusting entries and the closing entries change account balances.
:a 20.4 | An account payable is an amount the business owes, and it appears among the liabilities. An account receivable is an amount owed to the business, and it appears among the assets.
:a 20.5 | The second quarter runs from 1 July to 30 September. The second quarter is an interim period; the year is the fiscal year, and the cycle is a set of steps and not a period of time.
