:glossary 20
Fiscal year | Any twelve-month period a business chooses for its yearly reports. It may start in any month, and the calendar year is one choice among many. Meghna and Sons uses 1 January to 31 December, while the Bangladesh government uses 1 July to 30 June.
Interim period | A reporting period shorter than a year. A quarter of three months is the usual example, and months and half-years are others. Interim reports use the same methods as yearly reports but depend more on estimates.
Product cost | A cost of buying or making goods held for sale. It waits in inventory until the goods are sold and then moves to cost of goods sold. The price paid for books and freight in are examples.
Period cost | A cost charged to the period in which it is incurred, because it belongs to time and not to particular goods. It reaches the income statement at once. Rent and wages are examples.
