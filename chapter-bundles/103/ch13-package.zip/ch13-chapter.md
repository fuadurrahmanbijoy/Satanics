:chapter XIII | Inventory: Meaning and Measurement
:mood A shelf that is empty and a store room that is full: which mistake costs more?
:desc This chapter explains the goods a business holds for sale and the materials it holds to make them. You learn the three kinds of inventory in a factory, why a business holds inventory at all, and what it costs to hold too little or too much. You then learn the two systems for recording inventory, how a physical count works, and how to reduce the value of goods that will sell for less than they cost.
:plate ch13-plate.svg | A warehouse in the age of hoists, crates and handwritten lists

> A small puzzle: two bad mornings in a bookshop, one with too few goods and one with too many.

Imagine two bad mornings in a bookshop. On the first morning a student walks in and asks for a particular textbook. The shelf is empty. The student shrugs and walks to another shop, and the sale is lost for ever. On the second morning the owner opens the store room at the back and finds a thousand copies of a book that nobody has asked for in a year. The money that paid for those copies is not in the bank. It is locked in paper and dust.

> The puzzle is to find a sensible amount between none and too many, and then to record it honestly.

Both mornings are mistakes, and they pull in opposite directions. If the owner buys more to avoid the first morning, the second morning comes closer. If the owner buys less to avoid the second, the first comes closer. How much should a business hold? And once it holds something, how should it count the goods and say what they are worth? Accountants answer the second question with care, because the figure appears twice: in the income statement, through cost of goods sold, and in the balance sheet, as an asset. A mistake in the count is a mistake in the profit.

> The running case gives a first number: the goods held by the bookshop at the end of 2025.

:case Case file, illustrative. On 31 December 2025 Meghna and Sons held goods for sale with a total cost of Tk 3,500,000. The year's net sales were Tk 14,400,000 and its cost of goods sold was Tk 9,800,000. Two groups within the Tk 3,500,000 need special attention: 800 titles that have not sold for 18 months, and 120 copies of an old edition.

:box YOU WILL NEED
This chapter uses cost of goods sold from Chapter 10 'Accounts of a Merchandising Company', section 10.1 'Sales, Purchases and Returns'. It also uses the idea of current assets from Chapter 10 'Accounts of a Merchandising Company', section 10.3 'Classified Balance Sheet'. The arithmetic is multiplication, percentages and subtraction; Appendix A1 'Maths You Will Use' holds a short reference.

* * *

## 13.1 What Inventory Is

> A shop and a household both keep a supply of things for later use, and the business version has a name.

Begin at home. Most families keep a supply of rice, oil and soap in the kitchen. They do not eat the rice the moment they buy it. They keep it until it is needed, and when it runs low they buy more. A shopkeeper behaves in the same way, with one difference: the shopkeeper keeps the goods in order to sell them, not to use them.

> Inventory is the accounting name for goods held for sale and for materials held to make them.
> Recall: current assets, Chapter 10, section 10.3 'Classified Balance Sheet'.
@ Inventory | Goods held for sale, or materials held to make goods for sale, in the ordinary course of business.

In accounting this supply has a name: **inventory**. Inventory means goods held for sale, or materials held to make goods for sale, in the ordinary course of business. For example, the books on the shelves of Meghna and Sons are inventory, because the shop intends to sell them to customers. Inventory is an asset, because the business owns it and expects to receive money from it. It is a current asset, because the business expects to sell it within a short time, usually within one year.

> Two different words in common use cause confusion, so one of them is set aside.
@ Stock | Word in use. In daily life, a supply of goods kept for later. In this book, stock means shares in a company; goods are called inventory.

Many students find the word "stock" confusing, because shopkeepers use it for goods and investors use it for shares in a company. Both uses are correct in their own settings. To avoid mixing them, this book uses inventory for goods and stock only for company shares. One phrase keeps the older word for tradition, and we meet it in section 13.3.

> Inventory moves from the balance sheet to the income statement at the moment of sale.

Inventory has a life in two steps. While the goods wait on the shelf, their cost is an asset on the balance sheet. When a customer buys them, the cost leaves the balance sheet and becomes the expense called cost of goods sold, which Chapter 10, section 10.1 'Sales, Purchases and Returns' explains. The sale itself is revenue. So the same Tk 100 of cost appears in two places in two different times: first as an asset, then as an expense. Gross profit is the revenue from the sale less this cost. If the cost is wrong, the profit is wrong.

> Not everything in a shop is inventory, because the test is the purpose for which the item is held.

What does not count? The test is the purpose. A cupboard in the shop is owned and useful, but the owner does not intend to sell it. It is equipment, not inventory. A box of carrier bags for customers is a supply used in the business, not a good held for sale. Books that belong to a publisher and are only stored in the shop do not count either, because the shop does not own them. Inventory is owned goods held for sale, or owned materials held to make goods for sale.

> A merchandising shop holds one kind of inventory; a factory holds three.

A shop such as a bookshop buys goods already finished and sells them in the same condition. It therefore holds one kind of inventory: finished goods bought for resale. A business that makes things holds three kinds, because making takes time and the product passes through stages. Imagine a book-binding workshop, such as the separate workshop Meghna Binding Service. It buys paper, board, thread and glue. It folds, sews and covers books over several days. It then holds finished volumes until a customer collects them. At any moment the workshop has materials waiting, books half-made, and books complete.

> The first stage is the materials waiting at the start of the chain.
@ Raw materials | Materials a manufacturer holds to turn into products.

The first kind is **raw materials**. Raw materials are materials a manufacturer holds to turn into products. For example, the reels of paper and the sheets of board in the workshop are raw materials. They have not yet been changed in any way.

> The second stage is the unfinished products in the middle of the chain.
@ Work in process | Goods in a factory that have been started but are not yet finished.

The second kind is **work in process**. Work in process means goods in a factory that have been started but are not yet finished. For example, a pile of printed sheets that are sewn but have no cover is work in process. Its cost includes the materials and the labour used so far.

> The third stage is the completed products waiting for a customer.
@ Finished goods | Completed products held for sale.

The third kind is **finished goods**. Finished goods are completed products held for sale. For example, a bound and trimmed volume on the collection shelf is a finished good. A bookshop's inventory consists wholly of finished goods, bought ready-made from a publisher.

> The figure shows the chain from materials to customer, and how each stage differs in hatching.

The figure below shows the chain. Read it from left to right. Each box is one kind of inventory, and the arrows show the order in which goods move. The first box is lightly shaded because its goods are untouched. The middle box has cross-hatching because work is in progress. The last box is dense, because its goods are complete. A customer stands at the far end.

:fig Three kinds of inventory in a factory chain | ch13-fig01.svg

> From four viewpoints the kinds matter in different ways.

The kinds matter to different people. The owner wants to know how much money is tied up in each stage. The manager of the workshop watches the middle stage, because goods that stay long in the middle are a sign of delay. The employee who handles the materials needs a count of what is waiting. A lender looking at the balance sheet sees the total and asks how quickly it turns into cash. Finished goods are closest to cash, and raw materials are furthest from it.

> Before moving on, we collect the ideas of this section.

*Before moving on.* Inventory is owned goods held for sale, or owned materials held to make goods for sale. It is a current asset until the sale, when its cost becomes cost of goods sold. A shop holds finished goods only. A factory holds raw materials, work in process and finished goods. You should now be able to say, for any item in a business, whether it is inventory and, if so, which kind.

## 13.2 Why Hold Inventory

> A business could try to hold nothing at all, and the reasons it does not form a framework.

Why does a business not hold nothing? It would save storage, it would never have unsold goods, and it would never have a loss from old books. The answer is that customers do not wait, and suppliers do not deliver at the moment of need. Section 13.1 asked what inventory is. This section asks why a business accepts the burden of holding it. There are four main reasons.

> Four reasons explain why every trading business holds some inventory.

The first reason is the customer. A customer who finds the shelf empty usually goes elsewhere, so goods must be ready when the customer arrives. The second reason is delay in supply. A publisher may need two weeks to deliver, so the shop needs enough goods to last until the delivery comes. The third reason is price. Buying a large quantity at one time often earns a lower price per item, and fewer deliveries mean lower transport costs. The fourth reason is demand that changes with the season. A bookshop sells many more textbooks in the weeks before classes start, so it must prepare before that time. A factory has a fifth reason: the stages of making need materials and part-made goods to keep the workers busy.

> Holding too little costs sales, goodwill and sometimes the customer for ever.

Suppose the owner decides to hold very little. The first cost is the lost sale: the revenue and the gross profit on it are gone. The second cost is harder to see. A student who cannot find a textbook this term may never return next term. The third cost is the emergency purchase, for example paying extra to receive goods quickly. These costs do not appear on any ledger account, because the sale that never happened leaves no record. They are real all the same, and that is why a shortage is easy to overlook.

> Holding too much costs money in many small amounts that grow large together.
@ Cost | Word in use. In daily life, the price you pay for something. In accounting, the amount given up to acquire or hold an item; a holding cost is a different amount, spent to keep goods.

Now suppose the owner decides to hold a great deal. The goods must be stored, insured and guarded. Paper can spoil in damp air. Fashions change, and a book may fall out of demand. Above all, the money spent on the goods could have been used elsewhere, for example to pay a debt or to buy goods that sell faster. The total of these burdens is called the holding cost, and it is usually stated as a percentage of the goods' cost for one year.

> The running case gives a holding cost for a group of titles that did not sell.

:case Case file, illustrative. On 31 December 2025, 800 titles had a total cost of Tk 380,000 and had not sold for 18 months. Meghna and Sons estimated its holding cost at 10% a year. The holding cost for one year is therefore Tk 380,000 × 10% = Tk 38,000. That is Tk 38,000 spent every year to keep goods that did not sell.

> A table sets the two mistakes side by side so that their different natures can be compared.

The table below compares the two mistakes. Introduce each row as a question: what is lost, and who sees it? Read across a row to compare the two cases.

:table The cost of too little and the cost of too much
| Question | Too little inventory | Too much inventory |
| --- | --- | --- |
| What is lost? | Sales and customers | Money tied up and goods that age |
| Is it recorded in the books? | No; the sale leaves no entry | Yes; storage and insurance appear as expenses |
| Who notices first? | The customer | The owner, when cash runs short |
| Typical remedy | Reorder sooner | Reduce purchases; sell at a lower price |

> The right amount lies between the two mistakes and depends on the business.

The right amount cannot be set by a rule that fits every business. A grocer who sells fresh fish needs very little, because fish spoils in a day. A bookseller who sells textbooks needs more, because titles keep their value for a year or longer. There is also an exception to the idea that more is safer: if demand collapses suddenly, a large stock of goods becomes a large loss. We meet a famous case in the closing pack.

> Before moving on, we collect the ideas of this section.

*Before moving on.* A business holds inventory because customers do not wait, suppliers need time, bulk buying saves money and demand follows the season. Holding too little costs sales. Holding too much costs storage, insurance, spoilage and the use of money. You should now be able to say one cost of each mistake and why the first is harder to see.

## 13.3 Recording Inventory

> To record inventory a business must answer two questions: how many, and what are they worth.

A business must know two things about its inventory: the quantity it holds and the value of that quantity. The value of each item is its cost, which Chapter 14 explains in detail. This section teaches how the quantity is found and recorded, and how an item whose value has fallen is treated. There are two systems for recording, and we begin with the more modern one.

> The perpetual system keeps a running record that changes after every purchase and every sale.
@ Perpetual inventory system | A system that updates the inventory account after every purchase and sale.

The first system is the **perpetual inventory system**. A perpetual inventory system is a system that updates the inventory account after every purchase and sale. For example, when the shop buys five books at Tk 100 each, the Inventory account rises by Tk 500 at once. When it sells eight books, the account falls by their cost, and the cost of goods sold rises by the same amount. At any moment the account shows what the shop should be holding. The word *perpetual* means "going on without end".

> The periodic system leaves the account unchanged all year and finds the figure by counting at the end.
@ Periodic inventory system | A system that finds inventory only by a physical count at period end.

The second system is the **periodic inventory system**. A periodic inventory system is a system that finds inventory only by a physical count at period end. For example, a small stall records every purchase in a Purchases account and every sale in a Sales account, but does not touch Inventory until the last day of the year. The stall then counts what remains, values it at cost, and calculates the cost of goods sold by subtraction. The word *periodic* means "at regular periods".

> A small example shows that both systems reach the same cost of goods sold.

Take small, clean numbers so that the method is the only thing to learn. *Given.* A shop begins the year with 10 books at Tk 100 each. It buys 5 more at Tk 100. It sells 8. All books cost Tk 100, so no question arises about which book is sold. *Find.* The cost of goods sold, and the inventory at the end, under each system.

> Under the perpetual system, every movement is recorded as it happens.

*Perpetual.* Start with 10 × 100 = Tk 1,000. The purchase adds 5 × 100 = Tk 500, so the account shows Tk 1,500. The sale of 8 books reduces it by 8 × 100 = Tk 800, so the account shows Tk 700. The cost of goods sold, recorded at each sale, is Tk 800.

> Under the periodic system, the answer comes from a formula applied after a count.

*Periodic.* The year's records show the opening inventory of Tk 1,000 and purchases of Tk 500. A count at year end finds 7 books, which are valued at 7 × 100 = Tk 700. The cost of goods sold is the opening inventory plus purchases less the closing inventory: 1,000 + 500 − 700 = Tk 800. *Answer.* Both systems give cost of goods sold of Tk 800 and closing inventory of Tk 700. *Check.* 10 + 5 − 8 = 7 books, and 7 × 100 = 700. The two systems agree, as they should.

:pause 13.p1 | A shop with a periodic system loses 3 books to theft during the year. Will the loss show as a separate item in its records, or will it be hidden? Give a reason.

> The two systems differ in what they reveal during the year, and a table makes the difference plain.

If both systems give the same answer, why choose between them? The difference is in what they show along the way. Read each row of the table below as a question about the system.

:table Perpetual and periodic systems compared
| Question | Perpetual | Periodic |
| --- | --- | --- |
| When is Inventory updated? | After every purchase and sale | Once, at period end |
| Can the owner see the quantity at any time? | Yes, from the records | No, only after a count |
| Is a loss from theft visible? | Yes, as a difference from the count | No; it hides inside cost of goods sold |
| Work needed during the year | More | Less |

> A count is needed under both systems, because records can differ from what is on the shelf.

Neither system removes the need to count. In the periodic system the count is the only source of the closing figure. In the perpetual system the count is a check on the records. The traditional name for this count is the *stock count*, the one place where this book keeps the older word. We also call it a physical count. A team walks through the shelves and the store room and writes down each item and its quantity, ideally with a second person who checks the first. Goods that belong to others are left out. Goods that have been sold but not yet collected are also left out, because they no longer belong to the business.

> After a count, any difference between the records and the shelves must be explained and corrected.

Under the perpetual system, suppose the records say 700 and the count finds 660. The difference of 40 may come from theft, damage, a mistake in recording, or a sale not entered. The business investigates first. If no cause is found, it reduces the Inventory account to the counted figure and charges the loss as an expense. The count is the final authority, because goods that cannot be found cannot be sold.

> Cost is not the only measure, because some goods will sell for less than they cost.
@ Net realisable value | The expected selling price of an item less the cost of selling it.

The last idea in this chapter is about value. A business usually reports inventory at its cost. But suppose an item can no longer be sold for as much as it cost. A business should not report an asset at more than the money it can bring in. The money it can bring in is the **net realisable value**. Net realisable value is the expected selling price of an item less the cost of selling it. For example, a textbook that cost Tk 100 may now sell for only Tk 150 after a discount, and selling it costs Tk 20 in packing and delivery. Its net realisable value is 150 − 20 = Tk 130.

> The rule: report the lower of cost and net realisable value, item by item.

The rule is plain. For each item or group of the same item, compare the cost with the net realisable value. If cost is lower, report cost. If net realisable value is lower, report that figure and treat the difference as a loss in the period when the value fell. In the example above, cost Tk 100 is lower than Tk 130, so the book stays at Tk 100. If the discount were bigger and the net realisable value fell to Tk 70, the book would be reported at Tk 70, and a loss of Tk 30 would be recorded. We never raise an item above its cost because its value rises. Standards on this point differ between countries, so a business must follow the standards of the place where it reports.

> Before moving on, we collect the ideas of this section.

*Before moving on.* A perpetual system updates Inventory after every purchase and sale. A periodic system finds it only by a count at period end. Both give the same cost of goods sold when the records are right. Inventory is reported at the lower of cost and net realisable value. You should now be able to say what each system shows during the year and how to test whether an item must be written down.

## Worked Example: Excess Titles and an Old Edition

> The two groups from the case file are examined in full, with every line of arithmetic shown.

:case Case file, illustrative. Given for 31 December 2025: inventory at cost Tk 3,500,000. Excess inventory: 800 titles at cost Tk 380,000, unsold for 18 months, holding cost 10% a year. Old edition: 120 copies, cost Tk 300 each, net realisable value Tk 180 each.

> The task has two parts: the cost of holding the titles and the write-down of the old edition.

*Find.* (a) the share of inventory in the excess titles, and the yearly holding cost; (b) the write-down for the old edition, and the value at which it is reported.

> Part (a) uses a percentage of a number, which is the same step twice.

*Part (a), steps.* The excess titles are 380,000 ÷ 3,500,000 = 0.1086, which is about 10.9% of the inventory. The holding cost is the cost times the rate: 380,000 × 10% = 380,000 × 0.10 = Tk 38,000 a year. *Answer.* About 11% of the inventory is excess, and keeping it costs Tk 38,000 a year. *Check.* 38,000 is one tenth of 380,000, which matches a rate of 10%.

> Part (b) compares cost with net realisable value, copy by copy, and multiplies by the number of copies.

*Part (b), steps.* The cost per copy is Tk 300 and the net realisable value is Tk 180. Since 180 is lower than 300, the copies are written down. The write-down per copy is 300 − 180 = Tk 120. For 120 copies it is 120 × 120 = Tk 14,400. The old edition was carried at 120 × 300 = Tk 36,000, and is now reported at 120 × 180 = Tk 21,600. *Answer.* The write-down is Tk 14,400. *Check.* 36,000 − 21,600 = 14,400, which agrees.

> The write-down is recorded as a loss and reduces the Inventory account by the same amount.

The entry follows from the answer. Debit an expense account, here called Inventory Write-down Expense, with Tk 14,400, and credit Inventory with Tk 14,400. The income statement bears the loss in 2025, the year in which the value fell, and the balance sheet shows the lower figure.

> The common slips are in the units and in the direction of the comparison.

Three slips are common. The first is to multiply by the wrong number of copies. The second is to use the selling price in place of net realisable value, forgetting to subtract the cost of selling. The third is to write up an item whose value has risen. A write-down is permitted; a write-up above cost is not.

## Summary

> The chapter's ideas in a few lines.

Inventory is owned goods held for sale, or owned materials held to make them. A shop holds finished goods; a factory holds raw materials, work in process and finished goods. Holding too little costs sales, and holding too much costs money and risk. A perpetual system updates Inventory at every purchase and sale; a periodic system finds it by a count at period end. Inventory is reported at the lower of cost and net realisable value.

## Think It Through

:q 13.t1 | The 800 unsold titles of Meghna and Sons cost Tk 380,000 and the holding cost is 10% a year. If they stay unsold for a further 12 months, what extra cost will the shop bear, and what other loss might it face?
:q 13.t2 | A bookseller says: "I never hold more than one week of goods, so I never lose money on inventory." Name two costs that this policy might create.

## Where People Go Wrong

> Belief: any item the business owns and holds is inventory.

The test is purpose. Equipment and office supplies are owned, but they are not held for sale, so they are not inventory.

> Belief: the periodic system is wrong because it does not update the account.

Both systems are correct. They give the same cost of goods sold when the records are right. They differ in what they show during the year.

> Belief: net realisable value is the selling price.

Net realisable value is the selling price less the cost of selling. Forgetting to subtract that cost raises the value wrongly.

> Belief: when the market value of an item rises, the item should be written up.

Inventory is not reported above its cost. A fall below cost is recognised; a rise above cost is not.

> Belief: a count that differs from the records means the count is wrong.

The count is the final authority on quantity. A difference must be investigated, but if no cause is found the records are corrected to the count.

## In History

> A famous modern case shows how holding too much can become a very large loss.

In April 2001 the American networking company Cisco Systems, based in San Jose, California, announced a large reduction in its inventory value. Demand for its products had fallen sharply, while it had ordered materials for much higher sales. In its third quarter of fiscal 2001 the company recorded an excess inventory charge of about USD 2.25 billion, and most of it related to materials it no longer expected to use.

> The case teaches that a count and a rule on value matter most when demand changes quickly.

The lesson fits this chapter. Goods that cannot be sold at cost must be reported at a lower value, and the loss falls in the period when the fall is recognised. Cisco's write-down was large in size, but the same rule applies to the 120 old copies of Meghna and Sons.

## Review Questions

:q 13.1 | Classify each item as raw materials, work in process, finished goods, or not inventory: (a) reels of paper in a binding workshop; (b) sewn sheets with no cover; (c) a stapler on the owner's desk; (d) bound volumes ready for collection; (e) a supplier's books stored in the shop but still owned by the supplier.
:q 13.2 | A shop holds 200 copies of a guide book. Each cost Tk 450. Each can now be sold for Tk 500, and the cost of selling is Tk 90 a copy. Find the net realisable value per copy, and the write-down, if any, for all 200 copies.
:q 13.3 | A shop begins the year with inventory of Tk 40,000 at cost and buys goods for Tk 65,000. A count at year end shows goods with a cost of Tk 30,000. Find the cost of goods sold under a periodic system.
:q 13.4 | A perpetual record shows 500 units of a book. A count finds 470. Cost is Tk 60 a unit. Find the cost of the difference and say what the shop should do first.
:q 13.5 | An owner holds goods with a total cost of Tk 600,000 and a holding cost of 12% a year. Find the yearly holding cost. In the next year, 150 units that cost Tk 80 each have a net realisable value of Tk 55. Find the write-down, and state the new reported value of those units.

:read Horngren, Harrison and Oliver, Accounting, 2012
