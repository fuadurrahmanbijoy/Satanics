:answers 13
:a 13.p1 | It will be hidden. A periodic system calculates cost of goods sold by subtraction, so the cost of the 3 stolen books is included in cost of goods sold with no separate sign.
:a 13.t1 | The extra holding cost is 380,000 × 10% = Tk 38,000. The shop may also face a write-down if the titles can only be sold for less than their cost.
:a 13.t2 | Two possible costs: lost sales when demand rises or a delivery is late, and the loss of customers who do not return. More frequent orders may also raise transport costs and remove bulk-buying discounts.
:a 13.1 | (a) raw materials; (b) work in process; (c) not inventory, because it is not held for sale; (d) finished goods; (e) not inventory, because the shop does not own it.
:a 13.2 | Net realisable value = 500 − 90 = Tk 410 a copy. Cost is Tk 450, so each copy is written down by 450 − 410 = Tk 40. For 200 copies the write-down is Tk 8,000.
:a 13.3 | Cost of goods sold = 40,000 + 65,000 − 30,000 = Tk 75,000.
:a 13.4 | The difference is 500 − 470 = 30 units, and 30 × 60 = Tk 1,800. The shop should first investigate the cause. If none is found, it reduces Inventory to the counted figure and charges Tk 1,800 as a loss.
:a 13.5 | Holding cost is 600,000 × 12% = Tk 72,000 a year. The write-down per unit is 80 − 55 = Tk 25, so for 150 units it is Tk 3,750. The units are reported at 150 × 55 = Tk 8,250.
