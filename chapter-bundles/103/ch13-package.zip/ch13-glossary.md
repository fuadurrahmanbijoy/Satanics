:glossary 13
Inventory | Goods held for sale, or materials held to make goods for sale, in the ordinary course of business. The business must own them. It is a current asset until sale, when its cost becomes cost of goods sold. Books on a bookshop's shelves are inventory.
Raw materials | Materials a manufacturer holds to turn into products. They have not yet been changed by the factory's work. In a binding workshop, reels of paper, board, thread and glue are raw materials.
Work in process | Goods in a factory that have been started but are not yet finished. Their cost includes the materials and labour used so far. Sewn sheets that have no cover yet are work in process.
Finished goods | Completed products held for sale. They are closest to being turned into cash. Bound volumes ready for collection are finished goods, and a bookshop's inventory consists wholly of them.
Perpetual inventory system | A system that updates the inventory account after every purchase and sale, so that the account always shows what the business should hold. A count is still needed, as a check on the records.
Periodic inventory system | A system that finds inventory only by a physical count at period end. During the year only purchases are recorded, and cost of goods sold is found by subtraction: opening inventory plus purchases less closing inventory.
Net realisable value | The expected selling price of an item less the cost of selling it. If it is lower than cost, the item is reported at net realisable value. An item that sells for Tk 150 with Tk 20 of selling cost has a value of Tk 130.
