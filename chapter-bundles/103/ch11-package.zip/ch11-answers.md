:answers 11
:a 11.p1 | The subsidiary ledger holds the balance of one named customer. The accounts receivable control account holds the total owed by all customers together.
:a 11.t1 | Five credit sales make five entries and ten postings, so a special journal saves very little. The answer changes when credit sales become many, for example dozens each month, or when more than one clerk must write at the same time.
:a 11.t2 | Every sale is posted twice to the control account, so it is too high by the total of the lines. The customer accounts are correct, so the two totals disagree by exactly the amount posted twice, and the test reveals the slip.
:a 11.t3 | The agreement test reveals it. The control account, posted from the wrong total, is Tk 1,800 lower than the sum of the customer accounts, since Tk 54,200 - Tk 52,400 = Tk 1,800.
:a 11.1 | Lines of Tk 100, Tk 200 and Tk 300 give a total of Tk 600. Debit the accounts receivable account Tk 600 and credit Sales Tk 600, each posted once.
:a 11.2 | Total: Tk 42,500 + Tk 18,750 + Tk 31,200 = Tk 92,450. Closing balance: Tk 150,000 + Tk 92,450 = Tk 242,450. Both Greenfield School lines go to one customer account.
:a 11.3 | They do not agree. The control account should be Tk 310,000 + Tk 126,400 = Tk 436,400. The customer accounts total Tk 426,400. The difference is Tk 10,000, which suggests a posting is missing or wrong.
:a 11.4 | Total: Tk 36,000 + Tk 54,500 + Tk 29,500 = Tk 120,000. Debit Purchases Tk 120,000 and credit the accounts payable control account Tk 120,000. Closing balance: Tk 200,000 + Tk 120,000 = Tk 320,000.
