:answers 17
:a 17.p1 | No. The money is for a later year, so it belongs to the period that it pays for. It is received early and is shown as a liability, fees paid in advance, until that period begins.
:a 17.t1 | Cash can rise because of money not charged against the year, such as a loan or the sale of an asset, or because the club bought no lasting assets. A deficit arises when expenditure on the accrual basis, including amounts owed but unpaid, exceeds income that belongs to the year, such as when many fees are still owed.
:a 17.t2 | Profit = 46,000 − 50,000 + 9,000 − 0 = Tk 5,000. The equity fell by Tk 4,000 only because she withdrew Tk 9,000, so the business was profitable.
:a 17.1 | Receipts: 6,000 + 40,000 + 3,000 = Tk 49,000. Payments: 15,000 + 12,000 + 8,000 = Tk 35,000. Closing cash = 49,000 − 35,000 = Tk 14,000.
:a 17.2 | Subscriptions = 40,000 − 2,000 − 1,500 + 3,500 = Tk 40,000. Wages = 12,000 + 1,000 = Tk 13,000. Income = 40,000 + 3,000 = 43,000. Expenditure = rent 15,000 + wages 13,000 = 28,000. Surplus = Tk 15,000. The cupboard is an asset, not an expense.
:a 17.3 | Opening owner's equity = 60,000 − 15,000 = 45,000. Closing = 72,000 − 18,000 = 54,000. Profit = 54,000 − 45,000 + 20,000 − 8,000 = Tk 21,000.
:a 17.4 | In the receipts and payments account the Tk 30,000 is a payment. In the income and expenditure account it does not appear as expenditure, because it is a lasting asset. In the balance sheet it appears as an asset at its cost.
