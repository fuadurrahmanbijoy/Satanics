:answers 12
:a 12.p1 | A difference of Tk 1,000 means an item is missing, wrongly placed or wrongly added. Tick the items again and check the arithmetic; make no entry until the two adjusted balances agree.
:a 12.t1 | Entries are needed for the service charge (Tk 1,500), the dishonoured cheque (Tk 8,000), the interest (Tk 2,500) and the school payment (Tk 40,000), because the bank recorded them first. No entry is needed for the deposit in transit or the two cheques, because the business recorded them first and the bank will catch up.
:a 12.t2 | The business should contact the payee to learn why the cheque has not been presented, because rules on old cheques differ between banks and countries. Until it clears, the cheque stays on the reconciliation as an outstanding cheque and is subtracted on the bank side each month.
:a 12.1 | Bank side: 3,400 + 700 − 300 = 3,800. Book side: 3,000 + 900 − 100 = 3,800. The adjusted balance is Tk 3,800 on both sides.
:a 12.2 | Bank side: 91,250 + 12,000 + 6,500 − 9,800 − 4,150 = 95,800. Book side: 95,050 + 5,000 − 750 − 3,500 = 95,800. The adjusted balance is Tk 95,800.
:a 12.3 | The cash book is higher by Tk 1,750 before adjusting. Bank side: 18,400 + 5,000 − 3,200 − 1,100 = 19,100. Book side: 20,150 − 250 − 800 = 19,100. The adjusted balance is Tk 19,100.
:a 12.4 | Bank side: 47,000 + 4,000 − 9,000 = 42,000. Book side: 40,000 + 3,000 + 500 − 1,500 = 42,000. Entries: debit Bank, credit Account Receivable Tk 3,000; debit Bank, credit Interest Revenue Tk 500; debit Bank Charges, credit Bank Tk 1,500. Bank on the balance sheet is Tk 42,000.
