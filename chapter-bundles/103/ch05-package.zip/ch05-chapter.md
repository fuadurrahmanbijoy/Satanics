:chapter V | The Journal and the Ledger
:mood If every event is written down once, how can any fact be found again?
:desc Every transaction leaves a paper trail: a source document, a journal entry and a ledger account. This chapter follows that trail step by step, names the steps of the accounting cycle, and works through the seven January 2026 transactions of Meghna Binding Service.
:plate ch05-plate.svg | A bookkeeper copying entries from a day-book into a large ledger

:box YOU WILL NEED
Chapter 4 'Accounts, Debits and Credits', section 4.2 'Six Types of Account'; Chapter 4 'Accounts, Debits and Credits', section 4.3 'Debit and Credit'; Appendix A1 'Maths You Will Use'.

> A drawer of loose slips holds every fact but answers no question quickly.

Imagine a shopkeeper who writes every payment and every receipt on a loose slip of paper and drops the slip into a drawer. After a month the drawer holds hundreds of slips. A question arrives: how much did the shop spend on rent? The shopkeeper must read every slip to find the answer. A second question follows: what happened on the tenth of the month? Again every slip must be read. The slips contain all the facts, yet they cannot answer either question without a long search.

> Two books, one arranged by date and one by account, answer both questions.

The puzzle is how to arrange the facts so that both kinds of question can be answered at once. Accountants found the answer long ago: write each event twice, in two different books. The first book lists events in the order in which they happened. The second collects the same events under the name of the thing they affect, such as Cash or Rent. This chapter explains both books, the path that leads from the first to the second, and the repeating series of steps to which they belong.

* * *

## 5.1 The Accounting Cycle

> A baker's daily routine is a cycle, and accounting has a cycle too.

Think of a baker's working day. The baker buys flour, mixes dough, bakes loaves, sells them, counts the money and cleans the ovens. Tomorrow the baker performs the same steps in the same order. A routine that repeats in this way is a cycle. Accounting has a routine of this kind. In each period a business performs the same ordered steps to turn its events into reports, and then it begins again.

> The accounting cycle is the series of steps repeated each period.

@ Accounting cycle | The series of steps repeated each period, from recording transactions to preparing closing records.

The name for this routine is the **accounting cycle**. The accounting cycle is the series of steps repeated each period, from recording transactions to preparing closing records. A period is the stretch of time covered by one set of reports, such as a month or a year. When one cycle ends, the next begins with the first transaction of the new period. Meghna Binding Service, the book-binding workshop that began on 1 January 2026 with its own separate set of books, runs one cycle for each period it chooses to report.

> This book divides the cycle into eight steps, and three belong to this chapter.

The eight steps appear in the table that follows. Read each row from left to right: the number of the step, what happens in it, and where this book teaches it. Steps 1 to 3 are the subject of this chapter. The later steps are previewed here in one line each and taught in full later. A trial balance, for example, is a list of the balances of all the accounts, used to test that the records agree; Chapter 6 teaches it. Some books group the steps differently, but the order never changes.

:table The eight steps of the accounting cycle
| Step | What happens | Where taught |
| 1 | Collect and check source documents | This chapter |
| 2 | Record each transaction in the journal | This chapter |
| 3 | Post the journal to the ledger | This chapter |
| 4 | List the ledger balances in a trial balance | Chapter 6, 'The Trial Balance' |
| 5 | Adjust the accounts for changes not yet recorded | Chapter 7, 'Adjusting the Accounts' |
| 6 | Collect the figures on a worksheet | Chapter 8, 'The Worksheet' |
| 7 | Prepare the financial statements | Chapter 9, 'Financial Statements and Closing Entries' |
| 8 | Prepare the closing records | Chapter 9, 'Financial Statements and Closing Entries' |

> A source document is the first proof that a transaction happened.

@ Source document | Paper or electronic proof of a transaction, such as an invoice, receipt or cheque stub.

Every cycle begins with proof. A **source document** is paper or electronic proof of a transaction, such as an invoice, receipt or cheque stub. When the workshop buys books on credit from a publisher, the publisher's invoice is the source document. When the workshop pays rent, the landlord's receipt is the source document. Records begin from the document and never from memory, because a document can be shown to a bank, a tax authority or an auditor, who is a person that checks records for accuracy.

> Not every event has outside paper, and the bookkeeper must still act with care.

The idea has limits. Some events have no paper from an outsider: the owner's own investment may be proved only by a bank slip or a signed note. Other entries, which Chapter 7 describes, rest on a calculation made inside the business. A careful bookkeeper therefore asks one question of each source document before recording it: does this prove that an event happened, and does it show the date and the amount? If it does not, the entry waits.

> The figure that follows shows the path of one transaction through the first three steps.

The next figure shows the path that one transaction takes. Read it from left to right. The three boxes are the source document, the journal and the ledger. The arrow between the first two is labelled "recorded", and the arrow between the last two is labelled "posted". Below each box is a short note saying how that record is arranged. The example in the bottom row follows the publisher's invoice of 3 January.

:fig The path from source document to journal to ledger | ch05-fig01.svg

> The ring shows all eight steps and the return to the beginning.

The second figure draws the whole cycle as a ring. Begin at the box marked 1 at the top and follow the arrows clockwise. Each box is one step. After step 8 the ring returns to step 1, which is why it is drawn as a circle and not as a line. The boxes with heavy outlines are the three steps taught in this chapter.

:fig The accounting cycle as a ring of steps | ch05-fig02.svg

> A short review of the cycle and of source documents.

*Before moving on.* The accounting cycle is the series of steps repeated each period. Steps 1 to 3 move a transaction from a source document to the journal and then to the ledger. A source document is the proof on which the whole record rests.

* * *

## 5.2 The Journal

> One transaction on 1 January shows what the first book must hold.

On 1 January 2026, Nurul invests Tk 500,000 in cash in the workshop. What must be written down? Two accounts are touched. The account Cash rises, because the workshop now holds more cash. The account Owner's Equity rises, because the owner's share in the workshop has risen by the same amount. Both facts belong to one event, so both must be written together in one place.

> Recall: debit and credit, Chapter 4, section 4.3; account types, Chapter 4, section 4.2.

> The table reminds the reader which side increases each type of account.

A reminder from Chapter 4 helps here. Each type of account increases on one side and decreases on the other. The table that follows lists the five types met in this chapter. Read a row from left to right: the type, the side on which it increases, and an example from the case. A decrease is always entered on the opposite side.

:table Which side increases each type of account
| Type of account | Increases with | Example in the case |
| Asset | Debit | Cash |
| Liability | Credit | Publisher Payable |
| Owner's equity | Credit | Owner's Equity |
| Revenue | Credit | Service Revenue |
| Expense | Debit | Rent |

> A word with two meanings appears in the name of the first book.

> The journal is the book of first entry, kept in date order.

@ Book | Word in use. In daily life, a set of printed pages that you read. In accounting, a record in which transactions are written, such as the journal or the ledger.

@ Journal | The book of first entry, in which transactions are recorded in date order with debits and credits.

The first book is called the journal. The **journal** is the book of first entry, in which transactions are recorded in date order with debits and credits. It is called the book of first entry because every transaction is written there before it is written anywhere else. The record of one transaction in the journal is a journal entry. A journal may be a bound volume, a ledger-style sheet or a computer file; the rules are the same.^1

^1: Some businesses keep several journals, one for each frequent kind of transaction. Chapter 11, 'Special Journals', teaches them. This chapter uses the single general journal.

> A journal entry has five columns and a fixed order of lines.

A journal entry follows a fixed pattern. The columns are Date, Particulars, Folio, Debit and Credit. The date goes on the first line. The account to be debited is written first, with its amount in the Debit column. The account to be credited is written on the next line, indented a little to the right, with its amount in the Credit column. The Folio column stays empty until the entry is posted, a step that section 5.3 explains. The table that follows shows the entry for 1 January.

:table The journal entry for 1 January 2026
| Date | Particulars | Folio | Debit (Tk) | Credit (Tk) |
| 1 January 2026 | Cash |  | 500,000 |  |
|  |   Owner's Equity |  |  | 500,000 |
|  | Narration: Owner invested cash to begin the workshop. |  |  |  |

> A narration records the reason for the entry in one line.

@ Narration | A short note under a journal entry explaining the transaction.

The last line of the entry is a narration. A **narration** is a short note under a journal entry explaining the transaction. For example, "Owner invested cash to begin the workshop" tells a later reader why Cash was debited. A good narration names the event, not the accounts, and fits on one or two lines. It matters most to the reader who was not present: an auditor, a new bookkeeper or the owner a year later.

:pause 5.p1 | A workshop pays Tk 10,000 in cash for electricity. Which account is debited, which is credited, and what narration would you write?

> Every entry must balance: total debits equal total credits.

Every journal entry obeys one rule: the total of the debit amounts equals the total of the credit amounts. In the entry above, Tk 500,000 is debited and Tk 500,000 is credited. If the totals differ, the entry is wrong, and the error must be found before anything is posted. This rule is the safeguard that makes the records dependable.

> A compound entry has more than one debit or more than one credit.

@ Compound entry | A journal entry that has more than one debit or more than one credit.

Most entries touch two accounts, but some touch three or more. A **compound entry** is a journal entry that has more than one debit or more than one credit. Take a different workshop, not part of the case, that buys a binding press for Tk 30,000. It pays Tk 10,000 in cash and owes Tk 20,000 to the dealer. The press is debited for Tk 30,000. Cash is credited for Tk 10,000 and the dealer's payable account is credited for Tk 20,000. The debit total, Tk 30,000, equals the credit total, Tk 30,000, even though three accounts appear.

:table A compound entry for a different workshop
| Date | Particulars | Folio | Debit (Tk) | Credit (Tk) |
| 5 March 2026 | Equipment |  | 30,000 |  |
|  |   Cash |  |  | 10,000 |
|  |   Equipment Dealer Payable |  |  | 20,000 |
|  | Narration: Bought a binding press, part paid in cash, balance owed. |  |  |  |

> A short review of the journal.

*Before moving on.* The journal is the book of first entry. Each entry has a date, a debit line, a credit line, and a narration. Debits equal credits in every entry. A compound entry has more than one debit or more than one credit, and it still balances.

* * *

## 5.3 The Ledger and Posting

> The second book gathers every entry that touches one account.

Return to the shopkeeper's question: how much was spent on rent? The journal lists events by date, so the rent payments lie scattered among all the other entries. A second book is needed, in which all the rent entries sit together on one page. Another page holds all the Cash entries, another all the Owner's Equity entries, and so on. Each page is one account.

> The ledger holds every account, and posting fills it.

@ Ledger | The book containing all of a business's accounts, where the effects of journal entries are collected.

@ Posting | Copying the debits and credits from the journal to the right accounts in the ledger.

The **ledger** is the book containing all of a business's accounts, where the effects of journal entries are collected. The ledger of the workshop will hold eight accounts: Cash, Shelving, Inventory, Publisher Payable, Owner's Equity, Service Revenue, Rent and Wages. The act of filling it is called posting. **Posting** is copying the debits and credits from the journal to the right accounts in the ledger. Posting changes no amount and invents no entry; it only moves what the journal already holds.

> Posting follows four short steps for every journal entry.

The method has four steps, and the same four serve every entry. First, find the account that was debited and enter on its debit side the date, the name of the other account, the journal page, and the amount. Second, find the account that was credited and enter on its credit side the date, the name of the other account, the journal page and the amount. Third, repeat for any further lines of the entry. Fourth, write the ledger page of each account in the Folio column of the journal. The tables that follow show the postings of the 1 January entry, with the journal on page 1 and the accounts on pages L1 and L5.

:table The 1 January posting in the Cash account (ledger page L1)
| Date | Particulars | Folio | Debit (Tk) | Credit (Tk) |
| 1 January 2026 | Owner's Equity | J1 | 500,000 |  |

:table The 1 January posting in the Owner's Equity account (ledger page L5)
| Date | Particulars | Folio | Debit (Tk) | Credit (Tk) |
| 1 January 2026 | Cash | J1 |  | 500,000 |

> The folio columns link each journal line to its ledger account and back.

@ Folio | Word in use. In daily life, a page number or a large sheet of paper. In accounting, a reference number linking a journal line to a ledger page, or the reverse.

Folio references are small numbers that link the two books. In the ledger, "J1" says that the amount came from journal page 1. In the journal, "L1" written beside Cash says that the amount was posted to ledger page L1. With these links a reader can start from any figure in either book and find the other half of the record in seconds. A folio entry in the journal also shows that the line has been posted, which prevents posting the same line twice.^2

^2: Accounting software posts automatically, but the logic is the same: each journal line reaches the account it names, once.

> After posting, an account is balanced to show how much it now holds.

Posting leaves each account with many amounts on its two sides. To learn how much the account holds, we find its balance. Balancing an account means totalling both sides and finding the difference. Many students find this step confusing, because the arithmetic is easy but the layout is not. The method is as follows. Total the debit side. Total the credit side. Subtract the smaller total from the larger. The result is the balance, and it belongs to the side with the larger total.

> The formula for a balance is the larger total less the smaller total.

*Formula.* In words: the balance equals the larger side total minus the smaller side total. In symbols: B = L − S, where B is the balance, L is the larger total and S is the smaller total. For a tiny example with made-up figures, suppose an account has debits of Tk 200 and Tk 100, and a credit of Tk 120. Then L = 300 on the debit side and S = 120, so B = 300 − 120 = Tk 180, a debit balance. *Check.* Add the balance to the smaller side: 120 + 180 = 300, which equals the larger total, so the two sides now agree.

> A short review of the ledger, posting and balancing.

*Before moving on.* The ledger collects the journal's entries under the name of each account. Posting copies each debit and each credit to its account and records the folio. A balance is the larger side total less the smaller, placed on the larger side.

* * *

## Worked Example: The January Transactions

> The case file lists seven transactions to be journalised, posted and balanced.

:case Case file, illustrative. Given: Meghna Binding Service, a separate set of books, January 2026. 1 January: owner invests cash Tk 500,000. 2 January: buys shelving for cash Tk 120,000. 3 January: buys book inventory on credit from a publisher Tk 200,000. 10 January: earns Tk 40,000 cash for binding work. 15 January: pays rent Tk 60,000. 20 January: pays Tk 80,000 to the publisher. 31 January: pays wages Tk 35,000.

> The task is three jobs: journalise, post, and balance Cash.

*Find.* The journal entry for each transaction, with narrations; the postings to the ledger accounts Cash, Shelving, Inventory, Publisher Payable, Owner's Equity, Service Revenue, Rent and Wages; and the balance of Cash.

> The method reuses the debit rules and the balance formula.

*Formula.* For each transaction: debit the account that gains (assets, expenses) or loses (liabilities, owner's equity, revenue) value, credit the other, and make the totals equal. For the Cash balance: B = L − S, where L is the larger side total and S the smaller.

> Steps 1 and 2 journalise the first four transactions.

*Steps.* Step 1: journalise. The first table covers 1 to 10 January.

:table Journal entries for 1 to 10 January 2026
| Date | Particulars | Folio | Debit (Tk) | Credit (Tk) |
| 1 January 2026 | Cash | L1 | 500,000 |  |
|  | Owner's Equity | L5 |  | 500,000 |
|  | Narration: Owner invested cash to begin the workshop. |  |  |  |
| 2 January 2026 | Shelving | L2 | 120,000 |  |
|  | Cash | L1 |  | 120,000 |
|  | Narration: Bought shelving for cash. |  |  |  |
| 3 January 2026 | Inventory | L3 | 200,000 |  |
|  | Publisher Payable | L4 |  | 200,000 |
|  | Narration: Bought book inventory on credit from a publisher. |  |  |  |
| 10 January 2026 | Cash | L1 | 40,000 |  |
|  | Service Revenue | L6 |  | 40,000 |
|  | Narration: Received cash for binding work. |  |  |  |

> The second table covers the last three transactions.

The second table covers 15 to 31 January. In every entry the debit total equals the credit total.

:table Journal entries for 15 to 31 January 2026
| Date | Particulars | Folio | Debit (Tk) | Credit (Tk) |
| 15 January 2026 | Rent | L7 | 60,000 |  |
|  | Cash | L1 |  | 60,000 |
|  | Narration: Paid the month's rent. |  |  |  |
| 20 January 2026 | Publisher Payable | L4 | 80,000 |  |
|  | Cash | L1 |  | 80,000 |
|  | Narration: Paid part of the amount owed to the publisher. |  |  |  |
| 31 January 2026 | Wages | L8 | 35,000 |  |
|  | Cash | L1 |  | 35,000 |
|  | Narration: Paid wages for January. |  |  |  |

> Step 3 posts every line, and the Cash account shows six postings.

Step 2: post. Each of the fourteen lines above is copied to its account. The Cash account receives six postings, and the table that follows shows them with the totals of each side.

:table The Cash account after posting (ledger page L1)
| Date | Particulars | Folio | Debit (Tk) | Credit (Tk) |
| 1 January 2026 | Owner's Equity | J1 | 500,000 |  |
| 2 January 2026 | Shelving | J1 |  | 120,000 |
| 10 January 2026 | Service Revenue | J1 | 40,000 |  |
| 15 January 2026 | Rent | J1 |  | 60,000 |
| 20 January 2026 | Publisher Payable | J1 |  | 80,000 |
| 31 January 2026 | Wages | J1 |  | 35,000 |
| Totals |  |  | 540,000 | 295,000 |

> Step 4 balances Cash line by line, then the other accounts.

Step 3: balance Cash. Debit total: 500,000 + 40,000 = Tk 540,000. Credit total: 120,000 + 60,000 + 80,000 + 35,000 = Tk 295,000. The larger total is the debit side, so B = 540,000 − 295,000 = Tk 245,000, a debit balance. The other accounts are balanced in the same way, and the table that follows lists every balance.

:table The balance of every ledger account at 31 January 2026
| Account | Debit total (Tk) | Credit total (Tk) | Balance (Tk) |
| Cash | 540,000 | 295,000 | 245,000 debit |
| Shelving | 120,000 |  | 120,000 debit |
| Inventory | 200,000 |  | 200,000 debit |
| Publisher Payable | 80,000 | 200,000 | 120,000 credit |
| Owner's Equity |  | 500,000 | 500,000 credit |
| Service Revenue |  | 40,000 | 40,000 credit |
| Rent | 60,000 |  | 60,000 debit |
| Wages | 35,000 |  | 35,000 debit |

> The answer and the check agree with the case file.

*Answer.* The Cash account closes with a debit balance of Tk 245,000, and the other balances are those of the table above. *Check.* The debit balances total 245,000 + 120,000 + 200,000 + 60,000 + 35,000 = Tk 660,000. The credit balances total 120,000 + 500,000 + 40,000 = Tk 660,000. The two totals are equal, which is what correct journalising and posting must produce. Chapter 6 shows how this test is used.

> Common slips arise from the side, the folio and the date.

Common slips are easy to name. A student may post a debit to the credit side of the account, which reverses the amount. A student may forget to enter the folio, so the line seems unposted and is posted twice. A student may total the wrong side or subtract in the wrong order and obtain a negative balance, a sure sign of a slip. Check the side, the folio and the subtraction, in that order.

* * *

## Summary

> The chapter's main ideas in a few lines.

A transaction starts with a source document, is recorded in the journal in date order with debits and credits, and is then posted to the ledger, which holds one account for each kind of item. These are steps 1 to 3 of the eight-step accounting cycle, which repeats each period. A narration explains each entry, and a compound entry has more than one debit or credit. A ledger account is balanced by subtracting the smaller side total from the larger.

## Think It Through

:q 5.t1 | A clerk posts the 20 January entry to the Cash account but forgets to post it to Publisher Payable. What balance will Publisher Payable then show, and by how much will the credit balances exceed the debit balances?

## Where People Go Wrong

> The journal and the ledger arrange the same facts in different orders.

Many students think the journal and the ledger hold different information. They hold the same transactions. The journal arranges them by date; the ledger arranges them by account.

> Posting copies a line; it does not create or change one.

Another error is to alter an amount while posting. Posting only copies. If an amount looks wrong, the correction belongs in the journal, with its own entry and narration.

> A debit goes to the debit side of its own account, not to the other account's side.

A third slip is to place a debit on the credit side of the account because the other account's name was written there. The Particulars column names the other account; the amount goes on the side of the account whose page you are on.

> A balance is a difference, not a total.

A fourth confusion treats the balance as the sum of both sides. It is the difference between them, placed on the larger side.

## In History

> A medieval merchant's surviving books show that recorded transactions endure.

Francesco Datini was a merchant of Prato, a town near Florence in Tuscany, Italy. He was born around 1335 and died on 16 August 1410. He traded in cloth and many other goods, and kept offices in several countries. After his death, his papers stayed in his house in Prato. In 1870, workers altering the house found them stored in sacks in a disused stairwell.

> The Datini archive shows how long a well-kept record can last.

The find included some 150,000 letters and more than 500 account books and ledgers. Historians still use them to study how merchants of the fourteenth century recorded debts, payments and goods. The survival of so many books, six centuries later, shows the aim of this chapter: a transaction written once in an orderly book can be found again by someone who never met the writer.

## Review Questions

:q 5.1 | A workshop owner invests Tk 100,000 in cash. A week later the workshop pays Tk 20,000 in cash for shelving. Journalise both transactions, with narrations.
:q 5.2 | Post the two entries of question 5.1 to the Cash account and balance it.
:q 5.3 | A Cash account has debits of Tk 125,500 and Tk 48,250 and credits of Tk 30,750 and Tk 61,400. Find its balance and say on which side it falls.
:q 5.4 | On 1 February 2026 the Cash account of Meghna Binding Service starts with the balance of Tk 245,000 brought down. During February it receives Tk 52,000 and pays out Tk 118,500. Find the balance at 28 February 2026.
:q 5.5 | A different workshop buys a press for Tk 30,000, paying Tk 10,000 in cash and owing the rest to the dealer. Journalise the compound entry, post it to the three accounts, and state the balance of each.

:read Origo, Iris, The Merchant of Prato: Francesco di Marco Datini, 1957
