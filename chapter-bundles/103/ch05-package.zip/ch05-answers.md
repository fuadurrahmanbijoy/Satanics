:answers 05
:a 5.p1 | Debit Electricity (an expense) Tk 10,000 and credit Cash Tk 10,000. Narration: Paid electricity bill in cash.
:a 5.t1 | Publisher Payable would show a credit balance of Tk 200,000 instead of Tk 120,000. The credit balances would then total Tk 740,000 against debit balances of Tk 660,000, so credits would exceed debits by Tk 80,000.
:a 5.1 | Debit Cash 100,000, credit Owner's Equity 100,000 (narration: Owner invested cash). Then debit Shelving 20,000, credit Cash 20,000 (narration: Bought shelving for cash).
:a 5.2 | Cash debit side: 100,000. Cash credit side: 20,000. Balance = 100,000 − 20,000 = Tk 80,000 debit.
:a 5.3 | Debit total = 125,500 + 48,250 = 173,750. Credit total = 30,750 + 61,400 = 92,150. Balance = 173,750 − 92,150 = Tk 81,600, on the debit side.
:a 5.4 | Debit side: 245,000 + 52,000 = 297,000. Credit side: 118,500. Balance = 297,000 − 118,500 = Tk 178,500 debit.
:a 5.5 | Debit Equipment 30,000; credit Cash 10,000; credit Equipment Dealer Payable 20,000. Debits 30,000 equal credits 30,000. Balances: Equipment Tk 30,000 debit; Cash Tk 10,000 credit on these entries alone; Equipment Dealer Payable Tk 20,000 credit.
