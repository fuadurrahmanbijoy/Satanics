:chapter III | The Accounting Equation
:mood Why must what a business holds always match the claims on it?
:desc This chapter teaches assets, liabilities and owner's equity, the three building blocks of every business record. It shows why they always balance, adds revenue, expenses and drawings, and tests the idea on seven January events in a small binding workshop.
:plate ch03-plate.svg | A grocer's balance scale with weights on both pans, and a ledger beside it

:box YOU WILL NEED
Chapter 2, 'What Accounting Is', section 2.1 'The Idea of Accounting', for the meaning of accounting and bookkeeping; Chapter 2, section 2.3 'Rules and Concepts', for historical cost; and Appendix A1, 'Maths You Will Use', for moving a term across an equals sign.

> A market stall holds Tk 100,000 of value, and someone must have a claim on all of it.

Picture a market stall on a busy street in Dhaka. Its owner, Rahim, counts what the stall holds: a folding table, a rack of umbrellas for sale, and cash in a tin. A careful friend values everything together at Tk 100,000. "Whose is all this?" the friend asks. Rahim answers: "Mostly mine. But my uncle lent me Tk 30,000 to buy the umbrellas, and he expects it back."

> The uncle's claim and Rahim's claim together equal the whole value of the stall.

Now the friend has an answer. The uncle has a claim of Tk 30,000. The rest, Tk 70,000, belongs to Rahim. Add the two claims and the total is Tk 100,000 again. Try to find one taka of value in the stall that nobody has a claim on. You cannot. Every taka entered the stall in one of two ways: someone lent it, or Rahim put it in or earned it.

> This chapter explains why what a business holds always equals the claims on it.

This small discovery is the subject of the whole chapter. A business holds things of value. The people who lent money, and the owner, hold claims on those things. The two totals must agree, in every business, in every country, on every day. Is that a law of nature, or only a habit of bookkeepers? By the end of the chapter you will see that it is a rule of arithmetic with a plain reason, and you will watch seven events in a small workshop obey it, one after another.

* * *

## Assets, Liabilities and Equity

> Records begin with events that change a business's money, and these events have a name.

@ Transaction | An event that has a money effect on a business and must be recorded.

Bookkeeping, as Chapter 2 explained, means writing down what happens to the money of a business.^1 But which events deserve a place in the records? A business meets many events in a day: a telephone call, a promise, a visit from a customer. Only some of them change its money. A **transaction** is an event that has a money effect on a business and must be recorded. Buying shelving for Tk 120,000 is a transaction. A customer who says she may buy a book next month has not yet created one.

^1: Recall: accounting and bookkeeping, Chapter 2, 'What Accounting Is', section 2.1 'The Idea of Accounting'.

> We follow one small workshop through this chapter, and its figures never change.

:case Case file, illustrative. Meghna Binding Service is a book-binding workshop that repairs and binds books for schools. It began on 1 January 2026 and keeps a separate set of books from the bookshop Meghna and Sons of Dhanmondi, Dhaka. This chapter uses the workshop's records for January 2026. Amounts are in taka (Tk), with international digit grouping.^2

^2: In Bangladesh you may also see lakh and crore. Tk 500,000 is five lakh. This book writes every amount with commas after each three digits.

> Start from your own belongings; a business owns things of the same kind.

@! Go slowly here.
@ Asset | Word in use. In daily life, a useful quality or a helpful person, as in "she is an asset to the team". In accounting, an item of value that a business owns.
@ Asset | Something of value that a business owns or controls, such as cash, goods held for sale or equipment.

Begin with your own life. You may own a bicycle, a mobile telephone and Tk 2,000 in cash. Each has value to you, and you control each one. A business owns things of the same kind. An **asset** is something of value that a business owns or controls, such as cash, goods held for sale or equipment. The shelving that the workshop buys on 2 January 2026 is an asset, and so is the cash in its drawer. Goods held for sale have a name of their own, inventory, which Chapter 13, 'Inventory: Meaning and Measurement', section 13.1 'What Inventory Is' teaches in full. We use that word from here onward.

> Money owed to others is the second building block.

@ Liability | An amount a business owes to others, such as a loan or an unpaid supplier bill.

Now suppose you borrow Tk 1,500 from a friend to buy a second-hand textbook. The book is yours, but you owe your friend. A business owes money in the same way. A **liability** is an amount a business owes to others, such as a loan or an unpaid supplier bill. On 3 January 2026 the workshop buys books from a publisher for Tk 200,000 and promises to pay later. Until it pays, it has a liability. The amount owed to one supplier is called an account payable; Chapter 4, 'Accounts, Debits and Credits', section 4.1 'The Account' explains that name more fully. Some books say creditor for the same idea. This book says account payable.

> The owner's share is what remains after the debts are taken away.

@! Go slowly here.
@ Capital | Word in use. In daily life, a city where a government sits, or any money used to start something. In accounting, it often means the owner's money in the business; this book says owner's equity.
@ Owner's equity | The owner's claim on the business: what is left of the assets after the liabilities are paid.

Return to the bicycle. Suppose it is worth Tk 12,000, and Tk 4,000 of its price is still owed to your uncle. How much of the bicycle is really yours? Tk 12,000 minus Tk 4,000 leaves Tk 8,000. A business works in the same way. **Owner's equity** is the owner's claim on the business: what is left of the assets after the liabilities are paid. Other books call it capital, net worth or proprietorship. This book uses only owner's equity, so that one idea always has one name. At 31 January 2026 the workshop holds assets of Tk 565,000 and owes Tk 120,000, so its owner's equity is Tk 445,000.

> Both sides of a business must agree, and this agreement has a name.

@ Accounting equation | The rule that assets always equal liabilities plus owner's equity.

Go back to Rahim's stall. It holds Tk 100,000. His uncle's claim is Tk 30,000 and his own is Tk 70,000. In words: what the business holds equals what it owes plus what the owner can claim. The **accounting equation** is the rule that assets always equal liabilities plus owner's equity. In symbols, A = L + E, where A stands for assets, L for liabilities and E for owner's equity. For the stall, 100,000 = 30,000 + 70,000. The equation is true because each asset was paid for by someone: a lender, who gains a liability claim, or the owner, who gains an equity claim. No third source exists.

:fig An equation as a balanced scale: assets on one pan, liabilities and owner's equity on the other | ch03-fig01.svg

> Read the scale as an equals sign: the two pans carry the same total.

The picture shows the idea a second time. Read it from left to right. The left pan carries the assets. The right pan carries two blocks: the liabilities and the owner's equity. The beam is level because the totals are equal. If a block is added to one pan, a block of the same weight must be added to the other, or the scale tips.

> The equation can be rearranged to find any one of its three parts from the other two.

Often you know two parts and need the third. Rearranging the equation gives E = A − L, and also L = A − E (Appendix A1, section A1.3 'Rearranging an Equation', shows the move). Here is the first calculation, set out in the order used throughout this book.

> Worked example: owner's equity from assets and liabilities, with small numbers.

*Given.* A business has assets of Tk 50,000 and liabilities of Tk 20,000.
*Find.* The owner's equity.
*Formula.* In words: owner's equity equals assets minus liabilities. In symbols: E = A − L.
*Steps.* E = 50,000 − 20,000 = 30,000.
*Answer.* The owner's equity is Tk 30,000.
*Check.* Liabilities plus equity should equal assets: 20,000 + 30,000 = 50,000. It does.

> The equation measures recorded amounts, and equity can fall below zero.

Two limits are worth knowing. First, the equation uses the prices written in the records. Chapter 2, section 2.3 'Rules and Concepts', taught historical cost: an asset is recorded at the price paid.^3 Shelving bought for Tk 120,000 stays at Tk 120,000, even if a dealer would offer a different price today. Second, if liabilities exceed assets, then E = A − L gives a negative number. The owner then has no claim left, and the business owes more than it holds. This is a warning sign, not an error in the equation.

^3: Recall: historical cost, Chapter 2, 'What Accounting Is', section 2.3 'Rules and Concepts'.

> Each person reads the same equation with a different question in mind.

Different people read the equation differently. A lender looks at A and L and asks whether the assets are large enough to repay the loan. The owner looks at E and asks how large the personal claim has become. A supplier looks at the account payable and asks whether the business can pay it.

:pause 3.p1 | A workshop has assets of Tk 80,000 and liabilities of Tk 25,000. What is its owner's equity, and how do you check the result?

> Four ideas have been built so far, and each rests on the one before.

*Before moving on.* A transaction is a money event that must be recorded. Assets are what the business owns, liabilities are what it owes, and owner's equity is the owner's claim after debts. The three always obey A = L + E. You should now be able to say why the two sides of the equation can never differ.

## Revenue, Expenses and Drawings

> The owner's claim changes after the first day, and three new ideas explain how.

On the first day the owner's claim is the money put in. Then the business starts to work. How can the owner's claim grow beyond what the owner invested? Think of a household. Your wealth rises when you receive a salary, falls when you pay the rent, and falls again when you give money to a relative. Business owners see the same three movements, and each has a name.

> Revenue is what a business earns by selling or by doing work.

@ Revenue | Money earned or becoming due from selling goods or doing services.

A business earns by selling goods or doing work. **Revenue** is money earned or becoming due from selling goods or doing services. On 10 January 2026 the workshop binds books for a school and receives Tk 40,000 in cash. That is revenue of Tk 40,000. Notice the words "or becoming due". A customer may take the work today and pay next month. The revenue is earned when the work is done, not when the cash arrives. Chapter 7, 'Adjusting the Accounts', section 7.1 'Why Adjust' returns to this timing.

> An expense is a cost used up while earning revenue.

@ Expense | A cost used up in earning revenue, such as rent or wages.

Earning revenue costs something. An **expense** is a cost used up in earning revenue, such as rent or wages. On 15 January 2026 the workshop pays rent of Tk 60,000, and on 31 January it pays wages of Tk 35,000. Both are used up already: the rented room has served its month, and the worker has done the work. Two payments are not expenses, and many students confuse them. Buying shelving only changes one asset into another, and paying a supplier only reduces a liability.

> Drawings are the owner's own withdrawals, and they are not a cost of earning.

@ Drawings | Money or goods the owner withdraws from the business for personal use.

The owner may also withdraw money. **Drawings** means money or goods the owner withdraws from the business for personal use. If Rahim takes Tk 500 from the tin to buy his family's dinner, that is drawings. It reduces the assets and the owner's claim, yet it did not help to earn any revenue, so it is not an expense. The workshop has no drawings in January 2026.

> The owner's claim at any date is money put in, plus revenue, minus expenses and drawings.

The four movements can now be joined. The owner's equity at any date equals the money the owner has put in (with any equity carried from earlier periods), plus revenue, minus expenses, minus drawings. In symbols, E = I + R − X − D, where I is the owner's investment, R is revenue, X is expenses and D is drawings. Put this into the equation and the expanded form appears: A = L + (I + R − X − D). It tells you where the owner's claim came from and where it went.

> Worked example: a messier stall with all four movements and a liability.

*Given.* Karim's umbrella stall has an owner's investment of Tk 30,000, revenue of Tk 18,000, expenses of Tk 11,500, drawings of Tk 4,000 and liabilities of Tk 9,500.
*Find.* The owner's equity and the total assets.
*Formula.* Owner's equity equals investment plus revenue minus expenses minus drawings: E = I + R − X − D. Then A = L + E.
*Steps.* E = 30,000 + 18,000 − 11,500 − 4,000 = 32,500. A = 9,500 + 32,500 = 42,000.
*Answer.* Owner's equity is Tk 32,500 and total assets are Tk 42,000.
*Check.* Change the order: 30,000 − 4,000 = 26,000; 26,000 + 18,000 = 44,000; 44,000 − 11,500 = 32,500. The result is the same.

> The workshop's January figures give the same owner's equity by a second route.

:case Case file, illustrative. Meghna Binding Service, January 2026: owner's investment Tk 500,000; revenue Tk 40,000; expenses Tk 60,000 (rent) plus Tk 35,000 (wages) = Tk 95,000; drawings none. Owner's equity = 500,000 + 40,000 − 95,000 − 0 = Tk 445,000. This agrees with assets Tk 565,000 minus liabilities Tk 120,000.

> Four common slips: wrong sign, drawings as expense, mixed units, revenue as cash.

Four slips appear again and again. Students subtract revenue and add expenses, which reverses the signs. They record drawings as an expense, which hides the owner's withdrawals. They mix units, for example thousands of taka with whole taka. And they treat revenue as cash received, although a customer may not have paid yet. Before any answer, ask which way each item moves the owner's claim.

:pause 3.p2 | The owner invested Tk 40,000. Revenue was Tk 15,000, expenses Tk 9,000 and drawings Tk 2,000. What is the owner's equity?

> Three new items and one longer formula have been added to the equation.

*Before moving on.* Revenue raises owner's equity, expenses lower it, and drawings lower it without being an expense. The expanded form is E = I + R − X − D. You should now be able to say which of the four movements raises the owner's claim and which three lower it.

## Transactions and the Equation

> Every transaction has matching effects, so the equation stays balanced.

How can a business record hundreds of events and still keep both sides equal? The answer lies in how a transaction behaves. Each transaction changes the items of the equation, but always in matching ways: when one side changes, the other side changes by the same amount, or the change happens inside one side only.

> Three questions analyse any transaction in the same order.

@! Go slowly here.

Take any transaction and ask three questions in order. First, which items change, and by how much? Second, is each item an asset, a liability, owner's equity, revenue, an expense or drawings? Third, after the change, does A = L + E still hold? If the third answer is no, an effect is missing or a sign is wrong. Begin with the smallest case. On 1 January 2026 the owner puts Tk 500,000 into the workshop. The asset cash rises by Tk 500,000, and owner's equity rises by Tk 500,000. Both sides are Tk 500,000. The equation holds.

> Five patterns cover all seven events of the month.

The table below groups the effects into five patterns. Read a row from left to right: the first cell names the pattern, the second states what happens to the two sides, and the third gives an example from the workshop.

:table The five patterns of change in the equation
| Pattern | Effect on the equation | Example from January 2026 |
| One asset rises, another falls | Total assets unchanged | Shelving bought for cash |
| Asset rises, liability rises | Both sides rise equally | Inventory bought on credit |
| Asset rises, owner's equity rises | Both sides rise equally | Owner invests; binding fee earned |
| Asset falls, owner's equity falls | Both sides fall equally | Rent paid; wages paid |
| Asset falls, liability falls | Both sides fall equally | Publisher paid |

> Every row has two effects, which is the seed of a larger system.

Notice that every row contains at least two effects. No transaction changes only one item and leaves the rest alone. This fact is the seed of double entry, which Chapter 4, 'Accounts, Debits and Credits', section 4.3 'Debit and Credit' builds into a full method of recording. For now, keep the simpler tool: test A = L + E after every transaction. A transaction that changes only the asset side, such as the shelving purchase, still balances, because one asset rises exactly as another falls.

> Three questions, five patterns and one test close this section.

*Before moving on.* Analyse any transaction with three questions: what changes, what kind of item it is, and whether A = L + E still holds. Five patterns cover the January events. You should now be able to say why no transaction can leave the equation unbalanced.

## Worked Example: Seven Transactions of January

> The seven events of the month are the data, and the task is to find the final position.

:case Case file, illustrative. *Given.* Meghna Binding Service, January 2026: 1 January, the owner invests cash of Tk 500,000; 2 January, buys shelving for cash, Tk 120,000; 3 January, buys books (inventory) on credit from a publisher, Tk 200,000; 10 January, earns Tk 40,000 in cash for binding work; 15 January, pays rent, Tk 60,000; 20 January, pays the publisher Tk 80,000; 31 January, pays wages, Tk 35,000.

> Find, formula and steps: classify each event, then total the effects.

*Find.* Total assets, liabilities and owner's equity at 31 January 2026, and a check that they balance.
*Formula.* A = L + E. Each row of the table below shows the effect of one event on A, L and E, in taka.
*Steps.* The table lists each event with its effect. Assets rise or fall by the cash and other items affected, and equity changes only when revenue or an expense arises or the owner invests.

:table Effects of the seven events on the equation (Tk)
| Date | Event | Assets | Liabilities | Owner's equity |
| 1 Jan | Owner invests cash | +500,000 | 0 | +500,000 |
| 2 Jan | Shelving bought for cash | +120,000 and −120,000 | 0 | 0 |
| 3 Jan | Inventory bought on credit | +200,000 | +200,000 | 0 |
| 10 Jan | Binding fee earned (revenue) | +40,000 | 0 | +40,000 |
| 15 Jan | Rent paid (expense) | −60,000 | 0 | −60,000 |
| 20 Jan | Publisher paid | −80,000 | −80,000 | 0 |
| 31 Jan | Wages paid (expense) | −35,000 | 0 | −35,000 |
| Total | | 565,000 | 120,000 | 445,000 |

:fig Totals of assets, liabilities and owner's equity after each of the seven events, in taka | ch03-fig02.svg

> Read the figure by rows, each showing the three totals after one event.

To read the second figure, take one row at a time. The three number columns show the totals of assets, liabilities and owner's equity after that event. Look at the row for 3 January: assets rise to 700,000, and liabilities to 200,000, with owner's equity still at 500,000. In every row, the first number equals the sum of the other two.

> The answer is stated in a sentence, and two independent checks confirm it.

*Answer.* At 31 January 2026 the workshop has assets of Tk 565,000, liabilities of Tk 120,000 and owner's equity of Tk 445,000. The assets are cash Tk 245,000, shelving Tk 120,000 and inventory Tk 200,000.
*Check.* Liabilities plus equity: 120,000 + 445,000 = 565,000, which equals the assets. The cash can be tested alone: 500,000 − 120,000 + 40,000 − 60,000 − 80,000 − 35,000 = 245,000. The expanded form agrees: 500,000 + 40,000 − 95,000 = 445,000.

> Three slips are common in a worked list like this one.

Students often match a rent payment to the liability column, when it should lower owner's equity. They also forget that the shelving appears twice, once rising and once falling. And they sometimes change owner's equity when the publisher is paid. Test each row against the three questions before totalling.

> A long list is solved one row at a time and then totalled.

*Before moving on.* A long list of events is solved one row at a time, then totalled. Two checks, A = L + E and the expanded form, give confidence. You should now be able to analyse a new set of events in the same way.

* * *

## Summary

> The chapter in a few lines: three items, one equation, and what moves it.

Assets are what a business owns, liabilities are what it owes, and owner's equity is the owner's claim after debts. The accounting equation, A = L + E, holds for every business at every date. Revenue raises owner's equity, expenses lower it, and drawings lower it without being an expense, giving E = I + R − X − D. Every transaction has matching effects, so the equation stays balanced. At 31 January 2026, Meghna Binding Service has assets of Tk 565,000, liabilities of Tk 120,000 and owner's equity of Tk 445,000.

## Think It Through

:q 3.t1 | A transaction changes only the asset side of the equation. Give one example from this chapter and explain why both sides stay equal.
:q 3.t2 | A student says that paying the publisher Tk 80,000 on 20 January 2026 was an expense. Decide whether she is right, and explain what changed.

## Where People Go Wrong

> Owner's equity is a claim, and it is not the same as the owner's cash.

Many readers think owner's equity is the cash the owner has in the business. It is not. Owner's equity is a claim, not an item. At 31 January 2026 the workshop's owner's equity is Tk 445,000, but its cash is only Tk 245,000. The claim covers the shelving and the inventory too, after the liability is removed.

> Paying a debt lowers a liability, and it does not create an expense.

Another common belief is that every payment is an expense. Paying the publisher Tk 80,000 lowered cash and the account payable by the same amount. Owner's equity stayed at Tk 480,000. Only costs used up in earning revenue, such as rent and wages, are expenses.

> A balanced equation does not prove that every figure is correct.

A third belief is that if A = L + E balances, every figure must be right. This does not follow. Suppose the rent of Tk 60,000 were recorded as Tk 6,000. Cash and equity would both fall by Tk 6,000, and the equation would still balance, yet the records would be wrong. Chapter 6, 'The Trial Balance', shows how such mistakes are sought.

## In History

> A bank of the fifteenth century needed the same two lists that the equation joins.

In 1397 Giovanni di Bicci de' Medici (1360–1429), a banker of Florence in Italy, founded the Medici Bank. It grew into one of the most powerful banking houses of the fifteenth century, with branches in cities such as Rome, Venice, Geneva, Lyon, Bruges and London. Each branch was a separate company with its own name, owner's equity, managers and account books, under a head office in Florence.

> Surviving ledgers let a modern historian reconstruct what the branches held and owed.

A branch of such a bank held coins, loans owed to it and goods, and it owed deposits and shares of profit to its partners. These are the two lists that the accounting equation says must match. A set of confidential ledgers, discovered in 1950, allowed the historian Raymond de Roover to reconstruct how the bank was organised and run. The bank collapsed in 1494, when the Medici were expelled from Florence. Its books remain a reminder that every business, old or new, must show what it holds and who has a claim on it.

## Review Questions

:q 3.1 | Classify each item as an asset, a liability or owner's equity: (a) cash in the drawer, Tk 30,000; (b) a bill of Tk 12,000 owed to a paper supplier; (c) a binding press owned by the workshop; (d) a bank loan of Tk 90,000; (e) the owner's claim after all debts are paid.
:q 3.2 | A business has assets of Tk 240,000 and owner's equity of Tk 150,000. Find the liabilities.
:q 3.3 | At the start of a year a workshop's owner's equity was Tk 300,000. During the year the owner invested no more money. Revenue was Tk 410,000, expenses Tk 365,000 and drawings Tk 50,000. Find the owner's equity at the end of the year.
:q 3.4 | A workshop reports, in thousands of taka, assets of 1,250 and liabilities of 480. State its owner's equity in taka.
:q 3.5 | On 1 March a workshop starts with Tk 200,000 in cash from the owner. It then (a) buys equipment on credit for Tk 90,000; (b) earns Tk 30,000 in cash; (c) pays wages of Tk 18,000; (d) the owner withdraws Tk 10,000; (e) pays Tk 40,000 of the equipment debt. Find assets, liabilities and owner's equity after the fifth event, and check that they balance.

:read Raymond de Roover, The Rise and Decline of the Medici Bank, 1397–1494, 1963
