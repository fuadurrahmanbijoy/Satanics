:glossary 03
Transaction | An event that changes the money position of a business and must be recorded. Buying shelving for cash is a transaction; a customer saying she may buy next month is not, because no money has yet changed.
Asset | Something of value that a business owns or controls, such as cash, goods held for sale or equipment. For example, the shelving bought by a workshop is an asset, and so is the cash in its drawer.
Liability | An amount that a business owes to others, such as a bank loan or an unpaid supplier bill. For example, Tk 200,000 owed to a publisher for books is a liability until it is paid.
Owner's equity | The owner's claim on the business: what is left of the assets after all liabilities are paid. For example, assets of Tk 565,000 less liabilities of Tk 120,000 leave owner's equity of Tk 445,000.
Accounting equation | The rule that assets always equal liabilities plus owner's equity, written A = L + E. It holds because every asset was provided either by a lender or by the owner.
Revenue | Money earned, or becoming due, from selling goods or doing services. For example, a binding fee of Tk 40,000 earned by a workshop is revenue, whether the customer pays now or later.
Expense | A cost used up in earning revenue, such as rent or wages. For example, rent paid for a month in which a workshop has used the room is an expense; buying shelving is not.
Drawings | Money or goods that the owner withdraws from the business for personal use. Drawings lower the owner's equity, but they are not an expense, because they do not help to earn revenue.
