:answers 03
:a 3.p1 | Owner's equity = 80,000 − 25,000 = Tk 55,000. Check: liabilities plus equity, 25,000 + 55,000 = 80,000, which equals the assets.
:a 3.p2 | Owner's equity = 40,000 + 15,000 − 9,000 − 2,000 = Tk 44,000.
:a 3.t1 | Buying shelving for cash: one asset (shelving) rises by Tk 120,000 and another (cash) falls by Tk 120,000. Total assets are unchanged, so liabilities and owner's equity need no change and the equation stays equal.
:a 3.t2 | She is not right. Paying the publisher lowered cash by Tk 80,000 and lowered the account payable by Tk 80,000. Owner's equity did not change, so no expense arose.
:a 3.1 | (a) asset; (b) liability; (c) asset; (d) liability; (e) owner's equity.
:a 3.2 | Liabilities = 240,000 − 150,000 = Tk 90,000. Check: 90,000 + 150,000 = 240,000.
:a 3.3 | Owner's equity at the end = 300,000 + 410,000 − 365,000 − 50,000 = Tk 295,000.
:a 3.4 | Equity = 1,250 − 480 = 770 thousand, which is Tk 770,000.
:a 3.5 | Assets Tk 252,000 (cash 162,000 and equipment 90,000); liabilities Tk 50,000 (90,000 − 40,000); owner's equity Tk 202,000 (200,000 + 30,000 − 18,000 − 10,000). Check: 50,000 + 202,000 = 252,000.
