:answers 18
:a 18.p1 | Interest for a year is 200,000 × 5% = Tk 10,000. For six months, 10,000 × 6 ÷ 12 = Tk 5,000.
:a 18.t1 | His share of the remainder does not change, because the ratio stays 5:3:2 and he still receives two parts in ten. His interest rises by 400,000 × 6% = Tk 24,000 a year, so his total grows through the first layer only.
:a 18.t2 | Outsiders such as suppliers and banks are paid first, from all the cash available. If the cash cannot cover the debts, nothing is left for the partners, whose capital is used up by the loss.
:a 18.1 | Four parts in all. The first partner receives (3 ÷ 4) × 80,000 = Tk 60,000 and the second receives (1 ÷ 4) × 80,000 = Tk 20,000. Check: 60,000 + 20,000 = 80,000.
:a 18.2 | Interest: Mira 450,000 × 8% = 36,000; Naveed 300,000 × 8% = 24,000; total 60,000. Remainder 211,000 − 60,000 = 151,000. Shares: Mira (3 ÷ 5) × 151,000 = 90,600; Naveed (2 ÷ 5) × 151,000 = 60,400. Totals: Mira Tk 126,600 and Naveed Tk 84,400, which add to 211,000.
:a 18.3 | Time is 9 ÷ 12 = 0.75 year. Interest: Mira 450,000 × 8% × 0.75 = 27,000; Naveed 300,000 × 8% × 0.75 = 18,000; total 45,000. Remainder 180,000 − 45,000 = 135,000. Shares: Mira 81,000; Naveed 54,000. Totals: Mira Tk 108,000 and Naveed Tk 72,000, which add to 180,000.
:a 18.4 | Debit Bank Tk 300,000 and credit Priya, Capital Tk 300,000, dated 1 April 2028, with a narration that the amount was paid in by the new partner on admission. Debits equal credits.
:a 18.5 | Loss = 850,000 − 700,000 = Tk 150,000. Shares: P (2 ÷ 3) × 150,000 = Tk 100,000; Q (1 ÷ 3) × 150,000 = Tk 50,000. Payments: P 400,000 − 100,000 = Tk 300,000; Q 200,000 − 50,000 = Tk 150,000. Check: cash after debts is 700,000 − 250,000 = 450,000, which equals 300,000 + 150,000.
