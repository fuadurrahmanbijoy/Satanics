:answers 10
:a 10.p1 | Tk 500 + Tk 2,000 − Tk 700 = Tk 1,800.
:a 10.p2 | Tk 22,500, the first instalment, because it falls due within one year. The other Tk 67,500 is non-current.
:a 10.t1 | The two mistakes are equal and opposite on the same side, so total debits still equal total credits. Example: Wages debited Tk 300 too much and Rent debited Tk 300 too little.
:a 10.t2 | Cost of goods sold is Tk 2,000 too large, gross profit is Tk 2,000 too small, and inventory is missing from current assets, so the balance sheet understates assets.
:a 10.1 | Tk 5,000 − Tk 300 − Tk 100 = Tk 4,600.
:a 10.2 | Net sales Tk 78,000. Cost of goods sold = 12,000 + 50,000 − 1,000 − 14,000 = Tk 47,000. Gross profit Tk 31,000. Operating expenses 6,000 + 7,000 = Tk 13,000. Profit Tk 18,000.
:a 10.3 | Current assets Tk 22,000 (3,000 + 4,000 + 14,000 + 1,000); equipment Tk 20,000; total assets Tk 42,000. Current liabilities Tk 7,000 (5,000 + 2,000); long-term loan Tk 10,000; owner's equity Tk 25,000; total Tk 42,000.
:a 10.4 | (a) omission; (b) principle; (c) commission; (d) compensating error.
:a 10.5 | (b) Debit Vehicles Tk 40,000; credit Repairs Expense Tk 40,000. (c) Debit Electricity Expense Tk 700; credit Telephone Expense Tk 700.
:a 10.6 | Inventory: current asset. Shop fittings: non-current asset. Accounts payable: current liability. Loan due in four years: non-current liability. Loan due in six months: current liability.
