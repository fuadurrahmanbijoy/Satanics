:answers 15
:a 15.p1 | The van price of Tk 900,000 and the painting of Tk 12,000, which is needed before use, belong in the cost. The road licence of Tk 20,000 is a cost of using the van during the first year, so it is an expense, not part of the cost.
:a 15.t1 | Profit for 2026 would be Tk 15,000 too low, and the machine on the balance sheet would be Tk 15,000 too low at Tk 315,000 instead of Tk 330,000.
:a 15.t2 | Capitalising a repair removes it from expenses, so profit rises and the asset grows. This is dishonest because the repair does not create a lasting asset, so the profit and the balance sheet both give a false picture, even if the entry is not noticed at first.
:a 15.1 | Acquisition cost = 450,000 − 20,000 + 8,000 + 12,000 + 4,000 = Tk 454,000. The training of Tk 6,000 is an expense.
:a 15.2 | (a) revenue; (b) capital; (c) capital; (d) revenue; (e) capital, because it is done before first use.
:a 15.3 | Profit is Tk 12,000 too high and the plant asset is Tk 12,000 too high on the balance sheet.
:a 15.4 | Acquisition cost = 600,000 + 30,000 + 18,000 = Tk 648,000. Revenue expenditure for the year = 22,000 + 9,000 = Tk 31,000.
