:glossary 07
Accounting period | The span of time, such as a month, a quarter or a year, for which a business measures and reports its results. For example, Meghna Binding Service reports for the calendar year 2026.
Accrual basis of accounting | A method that records revenue when it is earned and an expense when it is incurred, whether or not cash has moved. For example, wages earned in December belong to December even if paid in January.
Matching principle | The rule that expenses are recorded in the same period as the revenue they helped to earn. For example, insurance for October to December is placed beside the revenue of those months.
Prepaid expense | A cost paid in advance that is an asset until it is used up, after which it becomes an expense. For example, a year of insurance paid on 1 October is mostly still an asset on 31 December.
Unearned revenue | Money received before the work is done, held as a liability until the work is performed. For example, a school pays Tk 24,000 in advance; the part not yet worked remains a liability.
Accrued expense | A cost that has already been used up but not yet paid, shown as a liability. For example, wages earned by workers in the last days of December but paid in January.
Accrued revenue | Revenue that has already been earned but not yet received or billed, shown as an asset. For example, binding work finished in December for which the invoice is sent in January.
Adjusting entry | A journal entry made on the last day of a period to bring an account to its correct balance for that period. For example, debiting Insurance Expense and crediting Prepaid Insurance for the part used.
