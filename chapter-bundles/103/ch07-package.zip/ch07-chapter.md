:chapter VII | Adjusting the Accounts
:mood If money moves on one day and the benefit arrives on another, which day counts?
:desc Records made as money moves do not always show what a period really earned and used. This chapter explains why accounts need adjustment at period end, teaches the two families of adjustment, deferrals and accruals, and shows how each is entered, using the year-end records of a small binding workshop.
:plate ch07-plate.svg | A clerk at year-end with a wall calendar, an open ledger and a pile of unpaid bills

:box YOU WILL NEED
Chapter 6, 'The Trial Balance', section 6.1 'Preparing a Trial Balance'; Chapter 4, 'Accounts, Debits and Credits', section 4.3 'Debit and Credit'; and Appendix A1, 'Maths You Will Use', for percentages and simple division.

> Paying for a year of use on one day raises the question of how much belongs to each month.

Imagine that you pay Tk 12,000 on 1 October for a bus pass that lasts twelve months. By 31 December you have used it for three months. A friend asks: "How much did the pass cost you this year?" Your wallet says Tk 12,000, because that is the amount that left it. Your journeys say Tk 3,000, because that is the amount you have used. Both answers are honest. They answer two different questions.

> A business meets the same puzzle, and its records must choose one answer.

Now give the puzzle to a business. On 1 October 2026 the book-binding workshop Meghna Binding Service pays Tk 36,000 for twelve months of insurance. On 31 December 2026 its records still show the whole Tk 36,000 as paid. In the same records nothing appears for the wages of the last days of December, which the workers have earned but not yet received. The first item makes the year look dearer than it was. The second makes it look cheaper. A lender who read such records would form a wrong picture in both directions.

> The records are true as a diary of events, but incomplete as a measure of the period.

The records are not false. Each payment did happen, and each was written down correctly on its day. They are incomplete as a measure of one period of time. Closing that gap is the work of this chapter: a small set of corrections, made once at the end of each period, each needing only a few lines of arithmetic. Many students find this chapter difficult at first, because a ledger that balances looks finished. It is not finished, and you will soon see why.

* * *

## Why Adjust

> Reports cover a fixed span of time, which must be named before anything can be measured.

@! Go slowly here.
@ Period | Word in use. In daily life, a lesson at school or the full stop at the end of a sentence. In accounting, a span of time such as a month or a year.
@ Accounting period | The span of time, such as a month or year, for which results are measured and reported.

A school reports on your work term by term, not once for your whole life. A business reports in the same way. An **accounting period** is the span of time, such as a month or year, for which results are measured and reported. Meghna Binding Service uses the calendar year 2026, from 1 January to 31 December. Some businesses also report every month or every quarter. The shorter the period, the more often the records need correction, because more items fall across the edge of the period.^1

^1: Reporting periods of different lengths are taught in Chapter 20, 'The Whole Cycle and Reporting Periods', section 20.1 'Fiscal Year and Interim Periods'.

> Revenue and expenses belong to the period of the activity, not the period of the cash.

@! Go slowly here.
@ Accrual | Word in use. In daily life, a gradual build-up, such as interest growing in a savings account. In accounting, an amount earned or used up that cash has not yet settled.
@ Accrual basis of accounting | Recording revenue when earned and expenses when incurred, whether or not cash has moved.

There are two ways to decide which period an item belongs to. The first follows the cash: record an item when money moves. The second follows the activity: record an item when the work is done or the benefit is received. The second way is the **accrual basis of accounting**: recording revenue when earned and expenses when incurred, whether or not cash has moved. An expense is incurred when the cost is used up, not when it is paid. A worker who labours on 28 December 2026 has earned wages in December, even if the pay arrives on 5 January 2027. On the accrual basis those wages belong to 2026. From here onward this book uses the accrual basis.

> Costs are placed beside the revenue they helped to earn.

@ Matching principle | The rule that expenses are recorded in the same period as the revenue they helped to earn.

Think about fairness. If the workshop earns fees all year, the report for the year should carry the cost of the room, the labour and the insurance that made those fees possible. The **matching principle** is the rule that expenses are recorded in the same period as the revenue they helped to earn. Insurance for the months from October to December belongs beside the revenue of those months. Insurance for the following nine months belongs beside the revenue of 2027. The accrual basis says when to count an item; matching says where to place its cost.

:pause 7.p1 | A workshop pays Tk 24,000 on 1 November for twelve months of rent. How much of this cost belongs to a year ending on 31 December, and which principle decides it?

> At period end some items are wrongly timed and others are missing.

@! Go slowly here.

The ordinary entries of the year, taught in Chapter 5, are made when something happens: cash is paid, a bill arrives, a customer is billed. Two problems follow. Some items are recorded too early or too late for the period: a payment may cover many months, and a fee may arrive before the work. Other items are never recorded, because no event pushed anyone to write them: wages that are earned but unpaid, and work that is done but not yet billed. So at the end of each period the accounts must be checked and corrected. The corrections fall into two families. In a deferral, cash moves first and the effect is put off to later. In an accrual, the effect comes first and the cash moves later. Chapter 8, 'The Worksheet', and Chapter 9, 'Financial Statements and Closing Entries', use the corrected figures.

> The year-end figures of the workshop show what needs correction.

The table below is a trial balance.^2 It was taken on 31 December 2026 before any correction. Read each row as an account name and its balance. The debit total and the credit total both equal Tk 1,240,000.

^2: Recall: trial balance, Chapter 6, 'The Trial Balance', section 6.1 'Preparing a Trial Balance'.

:table Unadjusted trial balance, Meghna Binding Service, 31 December 2026 (Tk)
| Account | Debit | Credit |
| Cash | 150,000 | |
| Accounts Receivable | 90,000 | |
| Supplies | 48,000 | |
| Prepaid Insurance | 36,000 | |
| Equipment | 360,000 | |
| Drawings | 80,000 | |
| Wages | 330,000 | |
| Rent | 120,000 | |
| Utilities | 26,000 | |
| Accounts Payable | | 60,000 |
| Unearned Revenue | | 24,000 |
| Capital | | 400,000 |
| Service Revenue | | 756,000 |
| Total | 1,240,000 | 1,240,000 |

> The uncorrected figures give a profit that is too high by Tk 96,000.

:case Case file, illustrative. Meghna Binding Service, 31 December 2026. Before correction, revenue is Tk 756,000 and the expenses are wages Tk 330,000, rent Tk 120,000 and utilities Tk 26,000, a total of Tk 476,000. The profit, meaning revenue minus expenses, appears to be Tk 280,000. After the six corrections of this chapter, revenue is Tk 788,000 and expenses are Tk 604,000, so profit is Tk 184,000. Chapter 8, 'The Worksheet', section 8.3 'Worked Worksheet', calls this amount net income.

> Different readers of the records are harmed in different ways by a wrong profit.

Each reader of the records would be misled by the first figure. The owner might withdraw money in the belief that Tk 280,000 was earned. A lender might judge the business safer than it is. A tax authority would assess tax on the wrong amount. An employee might read the high profit as a reason to expect higher pay. Correct timing protects all of these people.

> The accrual basis is the basis used here, though other bases exist.

The accrual basis is not the only method in use. Some very small businesses, in some countries, keep records on the cash basis and may be allowed to report tax that way. Rules differ from country to country, and this book describes the accrual basis because it is the basis behind the statements studied here. Even on the accrual basis, judgement is needed: a very small amount may be left uncorrected if leaving it would mislead nobody.

> The section's four ideas are the period, the accrual basis, matching, and the need to correct.

*Before moving on.* An accounting period is the span of time being reported. The accrual basis places revenue and expenses in the period of the activity, and matching places each cost beside the revenue it helped to earn. Because ordinary entries follow cash and events, corrections are needed at period end. You should now be able to say why a ledger that balances can still give the wrong profit.

## Deferrals

> In a deferral, cash moves first and the effect arrives in later periods.

Return to the bus pass. The money left your wallet on 1 October, but the benefit arrives month by month. An accountant calls the correction for such a case a deferral, because part of the effect is put off to later periods. This section covers three deferrals of the workshop and one related correction for equipment. Each follows one pattern: find how much of the cash has already been used up, move that part into an expense or into revenue, and leave the rest where it is.

> A cost paid in advance is an asset until it is used up.

@! Go slowly here.
@ Prepaid expense | A cost paid in advance that is an asset until it is used up.

On 1 October 2026 the workshop pays Tk 36,000 for twelve months of insurance. On that day nothing has been used up, and the whole payment is an asset: a right to be protected for a year. A **prepaid expense** is a cost paid in advance that is an asset until it is used up. Insurance, rent and subscriptions are common examples. Each day, a small part is used up and becomes an expense. At the end of the period, the entry moves the used part from the asset to an expense account.

:fig Insurance paid on 1 October 2026 for twelve months: the part used by 31 December and the part still to come | ch07-fig01.svg

> The bar shows twelve months of cover, split at 31 December.

To read the figure, follow the bar from left to right. Each box is one month. The hatched boxes, October to December 2026, are used up in the period. The dashed boxes, January to September 2027, are still ahead. The vertical line marks the end of the period. Each box stands for Tk 3,000.

> Worked example: the insurance adjustment, step by step.

*Given.* Insurance of Tk 36,000 paid on 1 October 2026 for twelve months; the period ends on 31 December 2026.
*Find.* The insurance expense for 2026 and the prepaid expense that remains.
*Formula.* In words: monthly cost equals the amount paid divided by the months covered; expense equals monthly cost times months used; remainder equals amount paid minus expense. In symbols: m = P ÷ n; X = m × k; R = P − X, where P is the amount paid, n the months covered and k the months used.
*Steps.* m = 36,000 ÷ 12 = 3,000. The months used are October, November and December, so k = 3. X = 3,000 × 3 = 9,000. R = 36,000 − 9,000 = 27,000. Entry: debit Insurance Expense 9,000; credit Prepaid Insurance 9,000.
*Answer.* The insurance expense for 2026 is Tk 9,000, and Tk 27,000 remains as a prepaid expense.
*Check.* 9,000 + 27,000 = 36,000. Also, 27,000 ÷ 3,000 = 9, the nine months still ahead.

> Supplies are counted at the end, and the difference is the amount used.

Some assets are used up without a clear daily rate. The workshop buys paper, thread and glue during the year, and records the cost in an asset account called Supplies. These are items bought to be used in the work, not goods held for sale. Nobody records each sheet used. So at year end the staff count what remains, and the difference between what was bought and what remains is the amount used. This is a prepaid cost, too, but the count, not a monthly rate, fixes the amount.

> Worked example: supplies used during 2026.

*Given.* The Supplies account shows Tk 48,000 before adjustment; a count on 31 December 2026 values the supplies on hand at Tk 15,000.
*Find.* The supplies used during 2026.
*Formula.* In words: supplies used equal the supplies account balance minus supplies on hand.
*Steps.* 48,000 − 15,000 = 33,000. Entry: debit Supplies Expense 33,000; credit Supplies 33,000.
*Answer.* Supplies used in 2026 are Tk 33,000, and the Supplies account is left at Tk 15,000.
*Check.* 33,000 + 15,000 = 48,000, the original balance.

> Money received in advance is a debt of work until the work is done.

@ Unearned revenue | Money received before work is done, held as a liability until the work is performed.

Now turn the idea around. Suppose a school pays a magazine publisher for a year of issues in advance. The publisher has the money, but it still owes twelve issues. The money is not yet earned. For the workshop, **unearned revenue** is money received before work is done, held as a liability until the work is performed. On 1 October 2026 a school pays Tk 24,000 in advance for binding work; the trial balance shows this as a liability of Tk 24,000. The work is done evenly at Tk 4,000 a month from 1 October. By 31 December three months of the work are complete, so part of the liability has become revenue.

> Worked example: the part of the advance that has been earned.

*Given.* Unearned Revenue of Tk 24,000; work worth Tk 4,000 a month, started on 1 October 2026; period ends on 31 December 2026.
*Find.* The revenue earned in 2026 and the liability that remains.
*Formula.* In words: revenue earned equals monthly work times months done; liability remaining equals the advance minus revenue earned.
*Steps.* 4,000 × 3 = 12,000. 24,000 − 12,000 = 12,000. Entry: debit Unearned Revenue 12,000; credit Service Revenue 12,000.
*Answer.* Tk 12,000 is earned in 2026, and Tk 12,000 stays as unearned revenue.
*Check.* The whole advance covers 24,000 ÷ 4,000 = 6 months, and 3 months are done, so half remains.

> Equipment is paid for once but serves for years, so its cost is spread.

Equipment follows the same spirit. The workshop paid Tk 360,000 for equipment that will serve for about five years. It would be unfair to charge the whole cost to the first year. The method that spreads the cost is called depreciation, taught in Chapter 16, 'Depreciation', section 16.1 'Why Depreciate'. For now, use the simplest rule: divide the cost, less any amount expected at the end, by the years of service. The charge is recorded by debiting Depreciation Expense and crediting an account called Accumulated Depreciation, explained in Chapter 16, section 16.4 'Recording and Disposal'.

> Worked example: one year of depreciation on the equipment.

*Given.* Equipment cost Tk 360,000; life 5 years; no residual value, which means nothing is expected to be received at the end.
*Find.* The depreciation for 2026.
*Formula.* In words: yearly charge equals cost divided by years of life. In symbols: D = C ÷ N.
*Steps.* D = 360,000 ÷ 5 = 72,000. Entry: debit Depreciation Expense 72,000; credit Accumulated Depreciation 72,000.
*Answer.* The depreciation for 2026 is Tk 72,000.
*Check.* 72,000 × 5 = 360,000, the whole cost after five years.

> Four corrections have been made; the pattern is to find the used part and move it.

*Before moving on.* A prepaid expense is an asset until used, and the used part moves to an expense. Supplies are counted, and the difference is the amount used. Unearned revenue is a liability until the work is done, and the earned part moves to revenue. Depreciation spreads the cost of equipment over its life. You should now be able to say why cash may leave on one day while the cost belongs to several periods.

## Accruals

> In an accrual the effect comes first and the cash moves later.

You use your telephone in December. The bill arrives in January, and you pay it in January. Yet the calls were made in December, and a fair record of December would include them. An accrual is the opposite of a deferral: the activity has happened, but the cash has not yet moved, and nothing has yet been written down. Two accruals concern the workshop, one for a cost and one for revenue.

> A cost already used up but not yet paid is recorded as a debt.

@! Go slowly here.
@ Accrued expense | A cost already used up but not yet paid, shown as a liability.

The workshop pays its workers on the fifth day of each month. On 31 December 2026 the workers have worked for several days since their last pay, and Tk 14,000 is owed to them. Nothing has been written down, because no money has moved. An **accrued expense** is a cost already used up but not yet paid, shown as a liability. The workers' labour has been used in earning December's revenue, so the matching principle puts its cost in December. The liability is real: the workshop owes the workers Tk 14,000.

> Worked example: wages owed at the end of the year.

*Given.* The Wages account shows Tk 330,000 before adjustment; wages of Tk 14,000 have been earned by workers but not paid.
*Find.* The wages expense for 2026 and the liability at 31 December.
*Formula.* In words: wages expense equals wages recorded plus wages owed.
*Steps.* 330,000 + 14,000 = 344,000. Entry: debit Wages 14,000; credit Wages Payable 14,000.
*Answer.* The wages expense for 2026 is Tk 344,000, and the workshop owes Tk 14,000 in Wages Payable.
*Check.* The new liability, Tk 14,000, equals the increase in the expense, so the equation still balances.

> Revenue already earned but not yet billed is recorded as an asset.

@ Accrued revenue | Revenue already earned but not yet received or billed, shown as an asset.

Now consider the other side. A freelance designer finishes a job in the last week of December, but sends the invoice in January. The work is done, so the revenue belongs to December. In the workshop's case, binding work worth Tk 20,000 was finished for a school before 31 December, and the invoice has not yet been prepared. **Accrued revenue** is revenue already earned but not yet received or billed, shown as an asset. The asset is the right to be paid. An amount owed to the business by a customer is called an account receivable; some books say debtor. This book says account receivable.

> Worked example: work done but not yet billed.

*Given.* Binding work worth Tk 20,000 is complete on 31 December 2026 but not billed. Service Revenue stands at Tk 756,000 before this item and before the item for unearned revenue.
*Find.* The entry for the unbilled work and its effect on Accounts Receivable.
*Formula.* In words: revenue earned equals the value of work done; the customer's debt is added to Accounts Receivable.
*Steps.* Entry: debit Accounts Receivable 20,000; credit Service Revenue 20,000. Accounts Receivable becomes 90,000 + 20,000 = 110,000.
*Answer.* Revenue rises by Tk 20,000, and Accounts Receivable becomes Tk 110,000.
*Check.* Assets rise by 20,000 and owner's equity rises by 20,000 through revenue, so the equation balances.

:pause 7.p2 | At year end a workshop owes its workers Tk 6,500 and has finished work worth Tk 11,000 that it has not yet billed. State the two amounts, and say which is an asset and which is a liability.

> Both accruals record an effect before any cash moves.

*Before moving on.* An accrued expense is a cost used up but unpaid, and it creates a liability. Accrued revenue is revenue earned but unbilled, and it creates an asset. In both, the cash moves later. You should now be able to say how an accrual differs from a deferral.

## Recording Adjusting Entries

> One picture holds the four kinds of correction, arranged by what moved first.

Before listing the entries, hold the whole plan in one picture. The figure arranges the corrections in a square. The columns show whether cash moved before the effect (a deferral) or after it (an accrual). The rows show whether the item is on the cost side or the revenue side.

:fig The four kinds of adjustment, arranged by when cash moves and by cost or revenue | ch07-fig02.svg

> An adjusting entry corrects one account for the period and changes no cash.

@ Adjusting entry | A journal entry made at period end to bring an account to its correct balance for the period.

Each correction is written as a journal entry, as in Chapter 5. An **adjusting entry** is a journal entry made at period end to bring an account to its correct balance for the period. It is dated on the last day of the period, here 31 December 2026, and carries a short narration. Three habits apply to every adjusting entry. It is made after the unadjusted trial balance. It changes at least one revenue or expense account and at least one asset or liability account. And it does not involve Cash, because the adjustment is about timing, and the cash has already moved or will move later.^3

^3: Recall: debit and credit, Chapter 4, 'Accounts, Debits and Credits', section 4.3 'Debit and Credit'.

> The six corrections of the workshop, each with its two accounts and its reason.

The table lists the six adjustments for Meghna Binding Service. Read each row from left to right: the reference letter, the account debited, the account credited, the amount in taka, and the narration that explains the entry.

:table Adjusting entries of Meghna Binding Service, 31 December 2026 (Tk)
| Ref | Debit | Credit | Amount | Narration |
| (a) | Supplies Expense | Supplies | 33,000 | Supplies used in 2026 |
| (b) | Insurance Expense | Prepaid Insurance | 9,000 | Insurance expired, 1 October to 31 December |
| (c) | Depreciation Expense | Accumulated Depreciation | 72,000 | One year of depreciation on equipment |
| (d) | Unearned Revenue | Service Revenue | 12,000 | Advance fees earned in 2026 |
| (e) | Wages | Wages Payable | 14,000 | Wages earned but unpaid |
| (f) | Accounts Receivable | Service Revenue | 20,000 | Work done but not billed |

> Common slips: forgetting that part of the original amount remains, and mixing up accounts.

Several slips occur in this work. Students record the whole payment as an expense, forgetting that part of it remains an asset or a liability. They adjust for the full year when only part of the year has passed. They debit Cash by habit, although no cash moves. And they reverse the two accounts, for example by crediting Wages when the wages are owed. A quick test helps: after each entry, ask whether the asset or liability account now shows a sensible figure.

> Six entries, one date and no cash complete the section.

*Before moving on.* An adjusting entry is dated on the last day of the period, carries a narration and involves no cash. The workshop's six entries cover supplies, insurance, depreciation, advance fees, wages owed and unbilled work. You should now be able to write any of the six from its data.

## Worked Example: From Unadjusted to Adjusted Balances

> The unadjusted balances and the six adjustments are the data, and the task is to find the new balances.

:case Case file, illustrative. *Given.* The unadjusted trial balance of Meghna Binding Service at 31 December 2026 (see the table in the first section), totalling Tk 1,240,000 on each side, and the six adjustments: (a) supplies on hand Tk 15,000, so supplies expense Tk 33,000; (b) insurance for 12 months paid on 1 October 2026, Tk 3,000 a month, expired Tk 9,000; (c) equipment depreciation Tk 72,000 (5 years, no residual value); (d) unearned revenue earned Tk 12,000 (Tk 4,000 a month from 1 October); (e) wages owed Tk 14,000; (f) revenue earned but not billed Tk 20,000.

> Find, formula and steps: apply each entry to its two accounts, and total the effect on profit.

*Find.* The adjusted balance of every account that changes, the profit after adjustment, and a check that debits equal credits.
*Formula.* Adjusted balance equals unadjusted balance plus or minus the adjustment. Profit equals revenue minus expenses.
*Steps.* Apply each of the six entries to its two accounts, as in the next table. An asset or expense rises on a debit and falls on a credit; a liability or revenue rises on a credit and falls on a debit.

:table Balances of the accounts changed by the six adjustments (Tk)
| Account | Side | Before | Change | After |
| Accounts Receivable | Debit | 90,000 | +20,000 | 110,000 |
| Supplies | Debit | 48,000 | −33,000 | 15,000 |
| Prepaid Insurance | Debit | 36,000 | −9,000 | 27,000 |
| Accumulated Depreciation | Credit | 0 | +72,000 | 72,000 |
| Wages Payable | Credit | 0 | +14,000 | 14,000 |
| Unearned Revenue | Credit | 24,000 | −12,000 | 12,000 |
| Service Revenue | Credit | 756,000 | +32,000 | 788,000 |
| Wages | Debit | 330,000 | +14,000 | 344,000 |
| Supplies Expense | Debit | 0 | +33,000 | 33,000 |
| Insurance Expense | Debit | 0 | +9,000 | 9,000 |
| Depreciation Expense | Debit | 0 | +72,000 | 72,000 |

> The expenses and revenue after adjustment give the true profit of the year.

Service Revenue rises by 12,000 + 20,000 = 32,000, from 756,000 to 788,000. The expenses are wages 344,000, rent 120,000, utilities 26,000, supplies expense 33,000, insurance expense 9,000 and depreciation expense 72,000, which total 604,000. The profit is therefore 788,000 − 604,000 = 184,000.

> The answer and the two checks show that the books still balance.

*Answer.* After the six adjustments the profit for 2026 is Tk 184,000, not the Tk 280,000 that the unadjusted figures suggested. Tk 96,000 of the apparent profit had not really been earned.
*Check.* The unchanged accounts are Cash 150,000, Equipment 360,000, Drawings 80,000, Rent 120,000 and Utilities 26,000 on the debit side, and Accounts Payable 60,000 and Capital 400,000 on the credit side. The debit side totals 1,346,000 and the credit side totals 1,346,000. Also, expenses rise by 128,000 and revenue by 32,000, so profit falls by 96,000: 280,000 − 96,000 = 184,000.

> Three slips are common when the table is built.

Students often forget one side of an entry, so the totals differ by one amount. They carry a figure to the wrong side, such as treating Accumulated Depreciation as a debit. And they replace the old balance instead of changing it, for example writing 33,000 for Supplies instead of 48,000 less 33,000. Compare each total with the check before moving on.

> The worked case joins the earlier ideas into one routine.

*Before moving on.* The worked case applies all six adjustments to the unadjusted balances and shows that profit falls from Tk 280,000 to Tk 184,000. You should now be able to carry a trial balance through its adjustments and test the result.

* * *

## Summary

> The chapter in a few lines: periods, the accrual basis, matching and six corrections.

Results are measured for an accounting period. The accrual basis places revenue and expenses in the period of the activity, and the matching principle sets each cost beside the revenue it helped to earn. Because ordinary entries follow cash, the accounts need adjustment at period end. A prepaid expense is an asset that is used up, unearned revenue is a liability that is earned, an accrued expense is a cost owed, and accrued revenue is revenue owed to the business. Each correction is an adjusting entry dated on the last day of the period.

## Think It Through

:q 7.t1 | Suppose Meghna Binding Service made none of the six adjustments. State the profit that its records would show for 2026, and say who might be misled and how.
:q 7.t2 | Explain why an adjusting entry does not involve Cash, using the insurance example.

## Where People Go Wrong

> Adjusting entries do not correct mistakes; they update the records for the passing of time.

Many readers believe that an adjusting entry corrects a mistake. It does not. The original entries were right on the day they were made. Adjusting entries bring the accounts up to date for time that has passed or work that has been done.

> A prepaid cost is an asset when paid, not an expense.

Another belief is that a cost is an expense on the day it is paid. When the workshop pays Tk 36,000 for a year of insurance, nothing is used up on that day, so the payment is an asset. Only the part used up becomes an expense.

> Money received in advance is not yet revenue.

A third belief is that money received is always revenue. The advance of Tk 24,000 from a school was a liability on the day it arrived, because the work was still owed. Only the work done, Tk 12,000, became revenue by 31 December. Revenue follows the work, not the cash.

> Depreciation does not set money aside.

A fourth belief is that depreciation puts cash aside for replacing equipment. It does not. It spreads a cost already paid across the years of use, and no cash moves when it is recorded.

## In History

> A company that failed in 2001 shows what can happen when reports hide the true position.

Enron Corporation was an energy company based in Houston, Texas, in the United States. It filed for bankruptcy on 2 December 2001. Investigations showed that its reports had kept large debts out of sight, partly by moving them into separate arrangements. Its collapse cost investors and employees heavily.

> A new United States law followed in 2002.

In 2002 the United States passed the Sarbanes-Oxley Act, which tightened the rules on company reporting and auditing. It applies to companies in the United States; other countries have their own laws. The story shows why correct and complete accounts matter: a report that leaves out what a business owes gives its readers a false picture.

## Review Questions

:q 7.1 | On 1 March a workshop pays Tk 6,000 for six months of insurance. Find the insurance expense and the prepaid expense at 30 June of the same year.
:q 7.2 | The Supplies account shows Tk 52,500 before adjustment. A count on the last day of the year shows supplies on hand of Tk 18,200. Find the supplies expense and write the adjusting entry.
:q 7.3 | On 1 November a workshop receives Tk 18,000 for a school's binding work, to be done evenly over six months. Find the revenue earned and the unearned revenue at 31 December.
:q 7.4 | Equipment cost Tk 240,000, has a life of 8 years and no residual value. At year end wages of Tk 9,000 are owed, and work worth Tk 15,000 has been done but not billed. Write the three adjusting entries and state the effect on profit.

:read W. A. Paton and A. C. Littleton, An Introduction to Corporate Accounting Standards, 1940
:read Bethany McLean and Peter Elkind, The Smartest Guys in the Room, 2003
