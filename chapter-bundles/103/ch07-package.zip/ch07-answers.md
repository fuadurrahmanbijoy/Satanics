:answers 07
:a 7.p1 | Monthly rent = 24,000 ÷ 12 = Tk 2,000. November and December are two months, so Tk 4,000 belongs to the year. The matching principle (with the accrual basis) decides it: the cost is placed in the period in which it is used.
:a 7.p2 | The Tk 6,500 owed to workers is an accrued expense, a liability. The Tk 11,000 of unbilled work is accrued revenue, an asset.
:a 7.t1 | The records would show a profit of Tk 280,000 instead of Tk 184,000, which is Tk 96,000 too high. The owner might withdraw too much, and a lender or tax authority would judge the business on a wrong figure. Assets would also be overstated and liabilities understated.
:a 7.t2 | The Tk 36,000 was paid in cash on 1 October. The adjustment on 31 December only moves the used part, Tk 9,000, from the asset Prepaid Insurance to the expense Insurance Expense. No money moves on that date.
:a 7.1 | 6,000 ÷ 6 = Tk 1,000 a month. March to June is 4 months, so the expense is Tk 4,000 and the prepaid expense is 6,000 − 4,000 = Tk 2,000.
:a 7.2 | Supplies expense = 52,500 − 18,200 = Tk 34,300. Entry: debit Supplies Expense 34,300; credit Supplies 34,300.
:a 7.3 | 18,000 ÷ 6 = Tk 3,000 a month. November and December are 2 months, so revenue earned is Tk 6,000 and unearned revenue is 18,000 − 6,000 = Tk 12,000.
:a 7.4 | Depreciation = 240,000 ÷ 8 = Tk 30,000: debit Depreciation Expense, credit Accumulated Depreciation. Wages: debit Wages 9,000, credit Wages Payable 9,000. Unbilled work: debit Accounts Receivable 15,000, credit Service Revenue 15,000. Expenses rise by 39,000 and revenue by 15,000, so profit falls by Tk 24,000.
