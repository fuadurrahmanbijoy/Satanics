:answers 16
:a 16.p1 | (Tk 120,000 − Tk 20,000) ÷ 4 = Tk 25,000 a year.
:a 16.p2 | Year 1: 25% × Tk 80,000 = Tk 20,000, leaving Tk 60,000. Year 2: 25% × Tk 60,000 = Tk 15,000, leaving Tk 45,000.
:a 16.t1 | The yearly charge falls from Tk 60,000 to (Tk 330,000 − Tk 30,000) ÷ 8 = Tk 37,500, so each year's profit rises by Tk 22,500. The total charged over the whole life is unchanged at Tk 300,000, because only the timing changes.
:a 16.t2 | Depreciation is an allocation of cost, not a transfer of cash. The cash was paid on the day of purchase, and the yearly entry moves no cash. Saving for a new machine is a separate decision about cash.
:a 16.1 | Charge: (Tk 50,000 − Tk 10,000) ÷ 4 = Tk 10,000 a year. After two years the accumulated depreciation is Tk 20,000, so the book value is Tk 30,000.
:a 16.2 | Straight-line: (Tk 275,000 − Tk 25,000) ÷ 8 = Tk 31,250 a year; for 3 months, Tk 31,250 × 3 ÷ 12 = Tk 7,812.50. Units-of-production: Tk 250,000 ÷ 400,000 = Tk 0.625 a unit; 36,000 × Tk 0.625 = Tk 22,500.
:a 16.3 | Year 1: Tk 30,000, remaining Tk 120,000. Year 2: Tk 24,000, remaining Tk 96,000. Year 3: Tk 19,200, remaining Tk 76,800. Gain = Tk 80,000 − Tk 76,800 = Tk 3,200.
:a 16.4 | Yearly charge: (Tk 240,000 − Tk 40,000) ÷ 5 = Tk 40,000. Entry for 2026: debit depreciation expense Tk 40,000, credit accumulated depreciation Tk 40,000. After three years the accumulated depreciation is Tk 120,000 and the book value is Tk 120,000, so the sale gives a loss of Tk 20,000. Sale entry: debit cash Tk 100,000, debit accumulated depreciation Tk 120,000, debit loss on sale Tk 20,000; credit press at cost Tk 240,000.
