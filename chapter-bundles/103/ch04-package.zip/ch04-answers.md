:answers 04
:a 4.p1 | Debit. Rent is an expense, and expenses increase by debit, so its balance usually falls on the debit side.
:a 4.p2 | Shelving is an asset that increases, so it is debited. Cash is an asset that decreases, so it is credited.
:a 4.t1 | Cash is an asset, and assets stand on the left of the equation A + D + E = L + C + R. Increases of left-side items are recorded on the left, which is the debit side.
:a 4.t2 | Debit Drawings and credit Cash, both for Tk 10,000. Drawings is its own type because the owner's personal use is not a cost of earning revenue, so it is not an expense.
:a 4.1 | Debit Cash 2,000 and credit Owner's Capital 2,000; debit Shelf 500 and credit Cash 500; debit Cash 300 and credit Sales Revenue 300. Cash: debits 2,300 less credits 500 gives a debit balance of Tk 1,800.
:a 4.2 | Debit Inventory (paper) 18,000, credit Accounts Payable 18,000; debit Accounts Payable 7,500, credit Cash 7,500; debit Cash 26,400, credit Service Revenue 26,400; debit Wages 9,200, credit Cash 9,200; debit Drawings 4,000, credit Cash 4,000. Cash: 50,000 + 26,400 − 7,500 − 9,200 − 4,000 = 55,700 debit. Accounts Payable: 18,000 − 7,500 = 10,500 credit.
:a 4.3 | Borrowing: debit Cash 100,000, credit Bank Loan 100,000. Repaying: debit Bank Loan 40,000, credit Cash 40,000. Bank Loan has a credit balance of Tk 60,000.
:a 4.4 | An asset normally has a debit balance, so a credit balance means more cash was recorded as paid out than received, through an error or an overdraft. Check each entry against its source document.
:a 4.5 | Inventory: asset, debit, debit. Accounts Payable: liability, credit, credit. Drawings: drawings, debit, debit. Service Revenue: revenue, credit, credit. Wages: expense, debit, debit.
