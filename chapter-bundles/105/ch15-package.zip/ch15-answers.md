:answers 15
:a 15.p1 | 40 + 15 = 55 days.
:a 15.p2 | 70 − 30 = 40 days. For 40 days the business must use its own money.
:a 15.t1 | Each item rises by one fifth, so the net investment is Tk 1,010,959 × 1.2 = about Tk 1,213,151. The extra money needed is about Tk 202,192. More sales means more inventory and more money owed by customers, and the amount owed to suppliers rises less than the total.
:a 15.1 | Operating cycle: 60 + 25 = 85 days. Cash conversion cycle: 85 − 35 = 50 days.
:a 15.2 | Inventory: 7,300,000 × 60 ÷ 365 = Tk 1,200,000. Receivables: 10,950,000 × 25 ÷ 365 = Tk 750,000. Payables: 7,300,000 × 35 ÷ 365 = Tk 700,000. Net investment: 1,200,000 + 750,000 − 700,000 = Tk 1,250,000.
:a 15.3 | The parts are mail float, processing float and clearing float. The days lost are 3 + 2 + 2 = 7 days.
:a 15.4 | Customers then pay in fewer days, so the receivable days fall. The operating cycle and the cash conversion cycle fall by the same number of days, and less of the business's own money is tied up.
