:glossary 15
Working capital | The money a business has tied up in short-term assets such as stock and money owed by customers. It is the money that moves daily from cash to goods to customers' promises and back to cash. A stall's rice, cash and customer debts are an example.
Current asset | An asset expected to turn into cash within about a year. Cash, inventory and accounts receivable are examples. A delivery cart used for many years is not a current asset.
Current liability | An amount owed that must be paid within about a year. A bill owed to a supplier and due next week is an example. A loan repayable over five years is not.
Inventory | Goods held for sale or for use in making goods. A bookshop's books, a tailor's cloth and a baker's flour are examples. Shopkeepers often call it stock.
Accounts receivable | Money owed to a business by customers who bought on credit. A school that took books in March and will pay in April creates accounts receivable for the bookshop.
Accounts payable | Money a business owes to suppliers for goods bought on credit. One business's accounts payable is its supplier's accounts receivable.
Net working capital | Current assets minus current liabilities. If the stall holds Tk 11,200 in current assets and owes Tk 10,000, its net working capital is Tk 1,200. A negative result warns that short-term debts exceed short-term assets.
Operating cycle | The days from buying stock to collecting cash from the customer. It equals the inventory days plus the receivable days. For Meghna and Sons Limited, 75 + 20 = 95 days.
Cash conversion cycle | The operating cycle minus the days a business takes to pay its suppliers. It equals inventory days plus receivable days minus payable days. For Meghna and Sons Limited, 75 + 20 − 45 = 50 days.
Float | Money that has been paid by one person but cannot yet be used by the receiver. It has three parts: mail float, processing float and clearing float. A cheque with 2, 1 and 3 days of these parts has 6 days of float.
