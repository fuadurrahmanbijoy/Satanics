:answers 01
:a 1.p1 | No. The tailor has accepted an order, but no money has moved today. The cash flow into the business will come next week, when the customer pays.
:a 1.p2 | The Tk 300,000 of savings is equity, and the Tk 100,000 loan is debt. The bank must be repaid on agreed dates; the owner shares any profit or loss.
:a 1.t1 | Ticket sales of Tk 40,000 are a cash flow into the business today. The film hire of Tk 25,000 is owed next month, so it is not a cash flow today. The Tk 10,000 loan instalment is a cash flow out today.
:a 1.t2 | The net cash flow today is Tk 40,000 less Tk 10,000, which is Tk 30,000 in. The film hire of Tk 25,000 is a liability; it will become a cash flow out next month, when it is paid.
:a 1.1 | For her, finance is finding money and deciding how to use it. She might find Tk 800 by asking her cousin, and decide to spend it on onions to sell.
:a 1.2 | Recording the money received is accounting, because it records what has happened. Deciding whether to borrow for the machine is finance, because it looks forward and asks where to find money and how to use it.
:a 1.3 | The two sources are the owner's savings, which are equity, and the loan, which is debt. Two uses might be ovens and other equipment, and ingredients to bake with, or money kept at the bank.
:a 1.4 | The sale is counted in June, when the goods are taken. The money moves only on 28 July, so the cash flow into the business falls in July.
:a 1.5 | Cash flow in is Tk 3,000, and cash flow out is Tk 2,000. The net movement is Tk 3,000 less Tk 2,000, which is Tk 1,000 in.
:a 1.6 | The Tk 800 is a source of funds, and it is debt, because it must be repaid. Afterwards she owes her cousin Tk 800, which is a liability, plus any extra charge they agree.
:a 1.7 | A source might be the school fund; a use might be buying ingredients for the canteen. The canteen's daily sales bring cash flow into it.
:a 1.8 | The sources are the owners' savings, which are equity, and the bank loan, which is debt. Two assets might be medical equipment and a cash and bank balance. Finance is one business function beside the clinic's other work; it finds funds and judges the money side of the other functions' decisions.
