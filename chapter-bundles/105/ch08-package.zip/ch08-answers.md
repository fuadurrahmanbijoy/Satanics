:answers 08
:a 8.p1 | Project A: 60,000 ÷ 30,000 = 2 years. Project B: 3 years (3 × 20,000 = 60,000). Payback misses the cash after the payback point: A returns only its cost, while B returns Tk 120,000 in all.
:a 8.p2 | Present values: 12,000 ÷ 1.10 = 10,909 and 12,000 ÷ 1.21 = 9,917, total 20,826. NPV = 20,826 − 20,000 = Tk 826. It is positive, so accept.
:a 8.t1 | Payback: X = 2.00 years; Y = 3 + 50,000 ÷ 400,000 = 3.13 years. NPV at 10%: X = 272,727 + 165,289 + 75,131 + 68,301 − 500,000 = Tk 81,449; Y = 90,909 + 123,967 + 150,263 + 273,205 − 500,000 = Tk 138,344. Payback prefers X, net present value prefers Y. Choose Y, because it adds Tk 56,895 more value and net present value uses all the cash and its timing.
:a 8.t2 | Net present value is the present value of the inflows minus the initial investment. At the internal rate of return the discounted inflows are exactly equal to the initial investment, so the difference is zero.
:a 8.1 | After 2 years the inflows total 270,000; unrecovered 130,000. Year 3 inflow is 180,000: 130,000 ÷ 180,000 = 0.72. Payback period = 2.72 years.
:a 8.2 | Present values: 109,091 + 123,967 + 135,237 + 136,603 = about 504,897. NPV = about Tk 104,897. It is positive, so accept.
:a 8.3 | Payback: accept if no longer than the limit set by managers. Net present value: accept if zero or more. Internal rate of return: accept if at least the required return. Profitability index: accept if at least 1.
:a 8.4 | NPV at 20% = +4,784; at 25% = −33,920. IRR = 20 + 5 × 4,784 ÷ (4,784 + 33,920) = 20 + 0.62 = about 20.6%.
:a 8.5 | M: index 330,000 ÷ 300,000 = 1.10; NPV = Tk 30,000. N: index 540,000 ÷ 500,000 = 1.08; NPV = Tk 40,000. M ranks first by index; N ranks first by net present value.
:a 8.6 | Payback period: the time to recover the initial investment. Net present value: the worth today of the inflows minus the initial investment, in taka. Internal rate of return: the discount rate at which net present value is zero. Profitability index: present value of inflows per taka of initial investment.
:a 8.7 | Net present value should decide, because it uses all the cash flows, respects their timing and states the gain in taka. Payback ignores later cash and timing, so it serves only as a second look at how long the money is tied up.
