:answers 12
:a 12.p1 | Degree of financial leverage = 50,000 ÷ (50,000 − 10,000) = 50,000 ÷ 40,000 = 1.25.
:a 12.t1 | A high degree of operating leverage already makes EBIT swing widely when sales change. Borrowing adds a second lever, and the two multiply, so earnings per share would swing even more. Owners who dislike a wide swing may borrow little to keep total risk lower.
:a 12.1 | Profit before tax = 150,000 − 30,000 = 120,000. Tax = 30,000. Profit after tax = 90,000. Less preferred dividend 18,000 = 72,000. Earnings per share = 72,000 ÷ 10,000 = Tk 7.20.
:a 12.2 | Preferred dividend before tax = 18,000 ÷ 0.75 = 24,000. Degree of financial leverage = 150,000 ÷ (150,000 − 30,000 − 24,000) = 150,000 ÷ 96,000 = 1.56.
:a 12.3 | Degree of total leverage = 2.50 × 1.60 = 4.00.
:a 12.4 | Earnings per share rises by about 4.00 × 10% = 40%. From Tk 5.00 it becomes about Tk 5.00 × 1.40 = Tk 7.00.
:a 12.5 | Plan X: at EBIT 100,000, (100,000 − 40,000) ÷ 4,000 = Tk 15.00; at 60,000, 20,000 ÷ 4,000 = Tk 5.00, a fall of 66.7%. Plan Y: at 100,000, 100,000 ÷ 8,000 = Tk 12.50; at 60,000, 60,000 ÷ 8,000 = Tk 7.50, a fall of 40%. Plan X is riskier, because its earnings per share swings more for the same fall in EBIT.
