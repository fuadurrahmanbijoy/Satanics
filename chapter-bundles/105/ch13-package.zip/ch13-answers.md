:answers 13
:a 13.p1 | 8% × 500 = Tk 40 each year.
:a 13.p2 | The investor receives 50 + 1,000 = Tk 1,050 in one year. Value = 1,050 ÷ 1.10 = Tk 954.55.
:a 13.t1 | More than the coupon rate. At 10% the value is Tk 962.09, above Tk 940. At 11% it is Tk 926.08, below Tk 940. The required return lies between 10% and 11% (about 10.6%), above 9%.
:a 13.t2 | A discount bond, because Tk 940 is below par. If the required return fell to 9%, the price would become Tk 1,000.00, equal to par.
:a 13.1 | C = Tk 80, a = 3.169865, f = 0.683013. Coupons: 80 × 3.169865 = 253.589. Par value: 1,000 × 0.683013 = 683.013. Value = Tk 936.60.
:a 13.2 | Discount bond: the required return is above the coupon rate, so the fixed coupon is less attractive and the price falls below par. Par bond: the two rates are equal, so the price equals par. Premium bond: the required return is below the coupon rate, so the coupon is more attractive and the price rises above par.
:a 13.3 | Coupon Tk 30, 4 periods, 4% per half-year: a = 3.629895, f = 0.854804. Coupons: 30 × 3.629895 = 108.897. Par value: 1,000 × 0.854804 = 854.804. Value = Tk 963.70.
:a 13.4 | At 10% the value is Tk 962.09; at 11% it is Tk 926.08. The fraction is (962.09 − 950) ÷ (962.09 − 926.08) = 12.09 ÷ 36.01 = 0.336. The yield to maturity is about 10.3%.
:a 13.5 | The coupons and the par value are fixed. A higher required return means each future payment is discounted more heavily, so its present value is smaller and the total falls.
