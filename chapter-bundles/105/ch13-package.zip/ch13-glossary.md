:glossary 13
Bond | A loan sold to investors, repaid at a set date with fixed interest along the way. The business that borrows is the issuer. For example, a business may divide a loan of Tk 5,000,000 into 5,000 bonds of Tk 1,000 each.
Par value | The amount printed on a bond that is repaid at maturity. It is also called face value. A bond with a par value of Tk 1,000 repays Tk 1,000 to the investor on the date of maturity.
Coupon interest | The fixed interest a bond pays each period, set as a percentage of par value. The percentage is the coupon rate. A par value of Tk 1,000 and a coupon rate of 9% give coupon interest of Tk 90 a year.
Maturity | The date on which a bond is repaid. A bond with five years to maturity pays its par value, with its last coupon interest, at the end of year 5.
Valuation | The work of finding what an asset is worth from the cash it is expected to bring. It needs the expected cash and the required return of the investor.
Intrinsic value | The worth of an asset worked out from the present value of its expected cash flows. An asset that pays Tk 1,100 in one year has an intrinsic value of Tk 1,000 at a required return of 10%.
Discount bond | A bond that sells for less than its par value. This happens when the required return is above the coupon rate. The case bond at 12% sells for Tk 891.86.
Premium bond | A bond that sells for more than its par value. This happens when the required return is below the coupon rate. The case bond at 7% sells for Tk 1,082.00.
Yield to maturity | The yearly return an investor earns by buying a bond at its price and holding it to maturity. It is the rate that makes the present value of all payments equal the price. The case bond at Tk 920 has a yield to maturity of about 11.2%.
