:answers 16
:a 16.p1 | Cost = 0.01 ÷ 0.99 × 365 ÷ 20 = 0.010101 × 18.25 = 0.1843, or 18.43% a year.
:a 16.t1 | Fund the permanent Tk 300,000 long term: 300,000 × 0.10 = Tk 30,000. Fund the seasonal Tk 150,000 short term: 150,000 × 0.13 × 4 ÷ 12 = Tk 6,500. Total Tk 36,500. All long term: 450,000 × 0.10 = Tk 45,000. Interest saved: Tk 8,500.
:a 16.1 | Cost = 0.02 ÷ 0.98 × 365 ÷ 20 = 0.020408 × 18.25 = 37.24% a year.
:a 16.2 | Cost = 0.03 ÷ 0.97 × 365 ÷ 35 = 0.030928 × 10.4286 = 32.25% a year.
:a 16.3 | Discount = Tk 4,000, so the payment on day 10 is Tk 196,000. Interest for 30 days = 196,000 × 0.13 × 30 ÷ 365 = Tk 2,094, which is less than Tk 4,000. Giving up the discount costs 24.83%, above 13%. Borrow and take the discount, gaining about Tk 1,906.
:a 16.4 | 3/10, net 30: 0.03 ÷ 0.97 × 365 ÷ 20 = 56.44%. 1/10, net 60: 0.01 ÷ 0.99 × 365 ÷ 50 = 7.37%. The first is more costly to give up, by about 49.07 percentage points.
:a 16.5 | Short: up to one year, for example trade credit or a bank overdraft. Intermediate: one to five years, for example a loan for a van repaid in instalments. Long: more than five years, for example equity from the owners or a bond.
:a 16.6 | Fund the permanent need, the stock held all year, with long-term money. Fund the extra December stock with short-term money, such as an overdraft, and repay it in January when the stock is sold.
:a 16.7 | Permanent working capital is the minimum the shop needs all year, such as basic stock and money in the till. Seasonal working capital is the extra stock and money needed only before the school term opens.
:a 16.8 | An overdraft charges interest only on the amount used and only for the days used, while a short loan charges interest on the whole amount for the whole period. A business whose need rises and falls may prefer the overdraft.
