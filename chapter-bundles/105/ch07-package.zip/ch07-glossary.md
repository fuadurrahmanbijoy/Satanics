:glossary 07
Capital budgeting | The process of planning, evaluating and choosing long-term investments, such as a machine that will work for five years. It covers finding proposals, estimating their cash flows, choosing among them and later reviewing the results.
Capital expenditure | Spending on assets that will serve the business for many years. A machine, a delivery van and a new shop floor are examples; a month of electricity is not, because it is used up at once.
Independent projects | Projects where accepting one has no effect on whether another is accepted. A print-on-demand machine and a new set of shelves are independent: a business may accept both, either or neither.
Mutually exclusive projects | Projects where accepting one means rejecting the others. A machine and a branch fit-out that cannot be run together are an example, as are two scanners when only one will be bought.
Relevant cash flow | Cash flow that changes only because a project is accepted. It must be cash, lie in the future and differ with the decision. A sunk cost, such as a survey already paid, is not relevant.
Initial investment | Cash spent at the start to get a project going. It includes the price of the asset, delivery, installation and any working capital needed. It is paid at time zero, before year one begins.
Depreciation | The part of an asset cost charged as an expense in each year of its use. With the straight-line method, the yearly charge is cost less resale value, divided by years. No cash leaves in those years.
EBIT | Earnings before interest and tax: the profit from operations before paying lenders or the tax office. It equals revenue less cash costs less depreciation. The book uses EBIT in place of the term operating profit.
Operating cash flow | Cash a project produces each year from running it, after tax. It equals EBIT, less tax on EBIT, plus depreciation, since depreciation reduced EBIT but no cash was paid.
Terminal cash flow | Cash received at the end of a project life, such as the resale value of equipment. It also includes working capital that returns, and is reduced by tax on any gain from the sale.
