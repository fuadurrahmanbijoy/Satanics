:answers 02
:a 2.p1 | The decision to buy the oven for Tk 200,000 is the investment decision. Paying Tk 80,000 from owners' funds and borrowing Tk 120,000 is the financing decision.
:a 2.p2 | The dividend is Tk 25,000, the part of the profit paid out. The retained earnings are Tk 90,000 less Tk 25,000, which is Tk 65,000.
:a 2.t1 | The new oven is an investment decision. The payout to the owners is a dividend decision. Repaying the loan changes how the business is funded, so it is a financing decision.
:a 2.t2 | Repaying the loan reduces debt, so lenders supply less of the funds. A dividend takes money out to the owners, so the business keeps less profit as owners' funds. Repaying the loan leaves the Tk 150,000 of profit used inside the business; a dividend sends it out.
:a 2.1 | Planning: decide in advance what money the shop will need, such as stock for the new term. Raising: find that money from the family or a bank. Control: compare spending with the plan and act on any difference.
:a 2.2 | Buying the scanner is the investment decision; choosing a bank loan to pay for it is the financing decision. The dividend decision, how much profit to pay out and how much to keep, has not yet been made.
:a 2.3 | Planning decides in advance that Tk 30,000 will be needed for cloth and arranges it. Control compares the actual bill with Tk 30,000 afterwards, finds any difference, and acts on it.
:a 2.4 | Profit is not cash. If cash is short, suppliers may refuse deliveries, wages may be late and chances to buy cheaply may pass, even though the shop earns a profit.
:a 2.5 | Buying the fridge is an investment decision. Repaying the loan changes how the household is funded, so it is a financing decision.
:a 2.6 | The freezer is an investment decision, and paying herself is a dividend decision. The dividend is Tk 50,000, and the retained earnings are Tk 40,000. Using kept profit to pay for the freezer is also part of the financing decision.
:a 2.7 | The three decisions are investment (the machine), financing (the loan) and dividend (the payout). The more profit is paid out, the less is retained to pay for the machine, so the more the manufacturer may need to borrow.
:a 2.8 | Tailor A is more efficient, because A uses Tk 70 for each Tk 100 of sales against Tk 80. Efficiency looks at the cost per unit of sales; profitability compares profit with the money invested or the sales made.
