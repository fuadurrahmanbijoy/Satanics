:glossary 02
Financial manager | The person who plans, raises and controls the money of a business, whatever the job title. In a small shop one brother may hold the duty; in a large business a team may. The manager answers to owners, lenders and employees.
Financial planning | Deciding in advance how much money a business will need and when. A tailor who knows she must pay Tk 38,000 for cloth and rent in the first week of March can arrange the money before the day arrives.
Financial control | Checking that money is spent and recorded as planned, and acting when it is not. If cloth planned at Tk 30,000 costs Tk 36,000, control finds the Tk 6,000 difference, asks why, and changes something.
Investment decision | Choosing which long-lasting assets or projects a business should buy. It asks what to buy, and it commits money for a long time. A bakery choosing between a new oven and a delivery van makes one.
Financing decision | Choosing how to raise the money for purchases, from owners or lenders. It asks how to pay, not what to buy. An oven may be paid for from owners' funds, a bank loan, or both.
Dividend decision | Choosing how much profit to pay out to owners and how much to keep in the business. A payout rewards owners now; keeping profit leaves more to fund growth later without asking a lender.
Dividend | A share of profit paid out to the owners of a business. If a shop earns Tk 90,000 and pays Tk 30,000 to its owners, the dividend is Tk 30,000. A family may call its payout a withdrawal.
Retained earnings | Profit kept in the business instead of being paid out to owners. If the shop earns Tk 90,000 and pays out Tk 30,000, retained earnings are Tk 60,000. They belong to the owners and may already be spent on assets.
Operating efficiency | How little money and effort a business uses to produce each unit of sales. A tailor who spends Tk 70 for every Tk 100 of sales is more efficient than one who spends Tk 80 for the same Tk 100.
Liquidity | How easily a business can pay its bills on time from cash it has or can quickly raise. Books on shelves are not liquid until sold, while a bank balance is. Weak liquidity can delay wages and stop deliveries.
Profitability | How much profit a business earns compared with the money invested or the sales made. A profit of Tk 20,000 on Tk 200,000 invested is 10% of the money invested; compare ratios, not amounts.
