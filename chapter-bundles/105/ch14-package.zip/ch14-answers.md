:answers 14
:a 14.p1 | Value = 10 ÷ (0.15 − 0.05) = 10 ÷ 0.10 = Tk 100.00.
:a 14.t1 | The bond suits her better. It pays fixed interest by contract, and a lender is paid before owners if the business ends. Common stock pays dividends the directors may cut, and its holder has only a residual claim, paid last, so the risk of loss is higher.
:a 14.1 | P = 9 ÷ 0.12 = Tk 75.00.
:a 14.2 | D₁ = 3.50 × 1.05 = 3.675. Then r − g = 0.11 − 0.05 = 0.06, so P₀ = 3.675 ÷ 0.06 = Tk 61.25.
:a 14.3 | If g equals r, the bottom of the fraction is zero and no value exists. If g is above r, the value is negative, which has no meaning. A business also cannot raise dividends faster than the required return for ever.
:a 14.4 | Any three: a bond holder lends and a stockholder owns; bond interest is fixed while dividends are decided by the directors; a bond gives no vote while common stock does; a lender is paid before owners; the stockholder carries more risk.
:a 14.5 | At 12%: 6 ÷ 0.12 = Tk 50.00. At 15%: 6 ÷ 0.15 = Tk 40.00. The value falls by Tk 10.00, because a higher required return lowers the present value.
:a 14.6 | A: D₁ = 4.16, so P₀ = 4.16 ÷ 0.08 = Tk 52.00. B: D₁ = 4.28, so P₀ = 4.28 ÷ 0.05 = Tk 85.60. The gap of Tk 33.60 arises because higher growth shrinks r − g from 0.08 to 0.05.
:a 14.7 | Bond: 80 × 2.48685 + 1,000 × 0.75131 = 198.95 + 751.31 = Tk 950.26. Stock: D₁ = 2.00 × 1.05 = 2.10, so P₀ = 2.10 ÷ 0.05 = Tk 42.00; ten shares are Tk 420.00. Total = Tk 1,370.26.
