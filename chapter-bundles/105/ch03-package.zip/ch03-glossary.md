:glossary 03
Profit maximisation | The aim of earning the largest profit possible in a period, usually one year. A shop that always picks the plan with the largest profit for the year follows this aim, even if the plan harms later years.
Market value | The price at which something could be sold today in a market. A used bicycle that a buyer would pay Tk 6,000 for today has a market value of Tk 6,000.
Wealth maximisation | The aim of making the market value of the owners' stake as large as possible over time. It takes account of when profits arrive and how certain they are, because buyers pay for both.
Stakeholder | Any person or group affected by a business, such as workers, customers, lenders and owners. A bookshop's stakeholders include its staff, the schools that buy from it and the bank that lent it money.
Principal | A person who hires another person to act for them. The owners of a bookshop are principals when they hire someone to run a branch for them.
Agent | A person who acts for a principal and takes decisions in the principal's name. A hired branch manager is an agent of the owners.
Agency conflict | A clash between what a principal wants and what an agent chooses to do. A manager paid on sales may choose discounts that raise sales, while the owners want profit.
Agency cost | The loss in value, plus the cost of prevention, that comes from an agency conflict. If a bad choice costs the owners Tk 105,000 and checking the records costs more, both amounts count.
