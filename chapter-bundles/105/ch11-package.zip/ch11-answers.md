:answers 11
:a 11.p1 | 5,000 ÷ 25 = 200 units.
:a 11.p2 | DOL = 60,000 ÷ 20,000 = 3.00. A fall of 10% in sales lowers EBIT by 3.00 × 10% = 30%.
:a 11.t1 | Before: CM = 90 − 50 = Tk 40, so break-even is 240,000 ÷ 40 = 6,000 packs. After: CM = 90 − 30 = Tk 60, so break-even is 480,000 ÷ 60 = 8,000 packs.
:a 11.t2 | Before: contribution 9,000 × 40 = Tk 360,000, EBIT Tk 120,000, DOL 3.00. After: contribution 9,000 × 60 = Tk 540,000, EBIT 540,000 − 480,000 = Tk 60,000, DOL 540,000 ÷ 60,000 = 9.00. The new machine carries more business risk, because its break-even point and its leverage are both higher.
:a 11.1 | A fixed operating cost stays the same whatever the units sold, such as shop rent. A variable operating cost grows with each unit, such as the price paid for each book bought for resale.
:a 11.2 | CM = 150 − 95 = Tk 55. Break-even = 330,000 ÷ 55 = 6,000 units.
:a 11.3 | At 5,000 units: 5,000 × 55 − 330,000 = −Tk 55,000, a loss. At 6,000 units: EBIT is 0. At 7,000 units: 385,000 − 330,000 = Tk 55,000.
:a 11.4 | Contribution = 8,000 × 55 = Tk 440,000. EBIT = 440,000 − 330,000 = Tk 110,000. DOL = 440,000 ÷ 110,000 = 4.00.
:a 11.5 | Near break-even EBIT is small compared with contribution, so the quotient is large. For the printing unit it is 4.00 at 8,000 packs and 3.00 at 9,000 packs. At break-even EBIT is zero and the value cannot be found.
