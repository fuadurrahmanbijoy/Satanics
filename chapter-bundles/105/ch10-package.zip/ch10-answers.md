:answers 10
:a 10.p1 | About 10%. A beta of 2 means the investment moves about twice as far as the market, so 2 × 5% = 10%.
:a 10.p2 | Market risk premium = 10% − 6% = 4%. Required return = 6% + 0.5 × 4% = 8%.
:a 10.t1 | Premium = 14% − 8% = 6%. Required return = 8% + 1.0 × 6% = 14%. The expected return of 13% is below 14%, so the line lies below the security market line. Reject it.
:a 10.1 | Market risk premium = 13% − 7% = 6%. Required return = 7% + 1.2 × 6% = 7% + 7.2% = 14.2%.
:a 10.2 | Firm-specific risk hits one business only, so losses at some businesses are offset by gains at others when many are held. Market risk hits all businesses at once, so holding more of them cannot remove it.
:a 10.3 | The line starts at 6% at beta 0 and rises 4 points for each whole step of beta, reaching 10% at beta 1 and 14% at beta 2. At beta 0.5 the required return is 8%; at beta 1.5 it is 12%.
:a 10.4 | Weak form: studying past price charts does not help. Semi-strong form: reading a public report after it appears does not help. Strong form: using secret information known only to managers does not help.
:a 10.5 | No. An expected return below the line is less than the required return for that much market risk, so the investment does not pay enough for the risk. The investor should reject it, or accept only if its expected return rises to the line.
