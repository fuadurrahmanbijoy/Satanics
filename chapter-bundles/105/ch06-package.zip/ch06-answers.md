:answers 06
:a 6.p1 | Tk 3,000 ÷ 1.10 + Tk 2,000 ÷ 1.21 + Tk 1,000 ÷ 1.331 = Tk 2,727.27 + Tk 1,652.89 + Tk 751.31 = about Tk 5,131.48. It is worth more, because the larger receipts come sooner.
:a 6.t1 | Plan X: Tk 81,818.18 + Tk 49,586.78 + Tk 22,539.44 = Tk 153,944.40. Plan Y: Tk 27,272.73 + Tk 49,586.78 + Tk 67,618.33 = Tk 144,477.84. Plan Y costs less in present value, because its larger payments fall later.
:a 6.t2 | Money has a time value, so a taka received sooner is worth more than a taka received later. The same total, paid in a different order, gives a different present value.
:a 6.1 | Tk 18,181.82 + Tk 28,925.62 + Tk 37,565.74 = Tk 84,673.18.
:a 6.2 | Tk 20,000 × 1.21 + Tk 35,000 × 1.10 + Tk 50,000 = Tk 24,200 + Tk 38,500 + Tk 50,000 = Tk 112,700.
:a 6.3 | Annuity part: Tk 15,000 for 5 years, Tk 15,000 × 3.790787 = Tk 56,861.80. Odd part: Tk 25,000 extra in year 5, Tk 25,000 × 0.620921 = Tk 15,523.03. Present value = Tk 72,384.83.
:a 6.4 | At 9%: rising Tk 86,416.60, falling Tk 90,774.03. At 15%: rising Tk 76,732.14, falling Tk 83,093.61. The falling stream is worth more at both rates, and the gap is larger at 15%.
:a 6.5 | In an annuity all payments are equal, in a mixed stream they differ. The annuity factor assumes equal payments, so it fits only a level part of a stream; the rest must be discounted as single sums.
