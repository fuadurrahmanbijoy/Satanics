:glossary 06
Mixed stream | A series of payments or receipts that differ in size from one period to the next. Receipts of Tk 1,000, Tk 2,000 and Tk 3,000 at the ends of three years form a mixed stream. An annuity is the special case in which all sizes are equal.
Discounted cash flow | A way of valuing a series of future cash flows by turning each one into a present value and adding the results. For example, Tk 1,000 in year 1 and Tk 2,000 in year 2 at 10% are valued as Tk 909.09 plus Tk 1,652.89.
