:answers 04
:a 4.p1 | Year 1: Tk 11,000. Year 2: Tk 12,100. Year 3: Tk 12,100 × 1.10 = Tk 13,310. Check: Tk 10,000 × 1.331 = Tk 13,310.
:a 4.p2 | Year by year: Tk 13,310 ÷ 1.10 = Tk 12,100, then ÷ 1.10 = Tk 11,000, then ÷ 1.10 = Tk 10,000. The present value is Tk 10,000.
:a 4.t1 | PV = Tk 130,000 ÷ 1.07 to the power of 5 = Tk 130,000 ÷ 1.402552 = about Tk 92,688. This is above Tk 90,000, so waiting is better. Check: Tk 90,000 × 1.402552 = about Tk 126,230, which is below Tk 130,000.
:a 4.t2 | Factor = 21,277.79 ÷ 15,000 = 1.418519. In the 6% column of the future value table this factor is in the row for 6 years, so n = 6 years.
:a 4.1 | Factor = 1.09 to the power of 6 = 1.677100. FV = Tk 15,000 × 1.677100 = Tk 25,156.50.
:a 4.2 | Factor = 1 ÷ 1.11 to the power of 4 = 1 ÷ 1.518070 = 0.658731. PV = Tk 80,000 × 0.658731 = Tk 52,698.48.
:a 4.3 | Simple: Tk 25,000 × (1 + 0.06 × 8) = Tk 37,000. Compound: Tk 25,000 × 1.06 to the power of 8 = Tk 25,000 × 1.593848 = Tk 39,846.20. Compound interest is Tk 2,846.20 higher.
:a 4.4 | Rate per quarter = 12% ÷ 4 = 3%. Effective annual rate = 1.03 to the power of 4 − 1 = 1.125509 − 1 = 12.55%.
:a 4.5 | Opportunity cost of idle cash is the interest it could have earned. Example: Tk 50,000 kept in a drawer for a year loses the Tk 4,000 that a bank paying 8% would have given.
