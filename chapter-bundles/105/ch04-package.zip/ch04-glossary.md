:glossary 04
Time value of money | The idea that money received sooner is worth more than the same amount received later, because money in hand can be put to work. Tk 100,000 today is worth more than Tk 100,000 in a year.
Interest | The price paid for using money for a period, received by the lender. If a bank pays Tk 8,000 for the use of Tk 100,000 for a year, the Tk 8,000 is interest.
Interest rate | The interest for one period, shown as a percentage of the amount lent or borrowed. Tk 8,000 earned on Tk 100,000 in a year is an interest rate of 8% a year.
Opportunity cost | The value of the best choice given up when you pick another. Cash kept idle in a drawer has an opportunity cost equal to the interest a bank would have paid on it.
Simple interest | Interest worked out on the original amount only, so the same amount is added each period. Tk 10,000 at 10% earns Tk 1,000 every year.
Compound interest | Interest worked out on the original amount plus interest already earned, so interest earns interest. Tk 10,000 at 10% earns Tk 1,000 in year 1 and Tk 1,100 in year 2.
Single sum | One payment or receipt made at one point in time. A deposit of Tk 10,000 made today is a single sum, unlike payments that repeat each year.
Future value | What an amount today will grow to after a stated time at a stated rate, found by FV = S × (1 + i) to the power of n. Tk 10,000 at 10% for two years has a future value of Tk 12,100.
Present value | What an amount to be received later is worth today at a stated rate. At 10%, Tk 12,100 due in two years has a present value of Tk 10,000.
Discounting | Finding a present value by working backwards from a future amount at a rate, dividing by (1 + i) once for each year. Tk 12,100 becomes Tk 11,000 and then Tk 10,000.
Discount rate | The rate used to turn a future amount into a present value. It is the same number as the interest rate when the money could earn that rate, used for working backwards.
Compounding period | The time between one addition of interest and the next. A bank that adds interest every six months has a compounding period of six months.
Effective annual rate | The single yearly rate that gives the same growth as compounding within the year. A rate of 12% compounded half-yearly has an effective annual rate of 12.36%.
