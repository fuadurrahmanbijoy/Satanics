:answers 17
:a 17.p1 | No. A debenture has no particular asset pledged. Here the building is pledged, so this is a loan secured by collateral, a mortgage.
:a 17.p2 | Debt: 200,000 ÷ 1,000,000 = 20%. Common equity: 800,000 ÷ 1,000,000 = 80%.
:a 17.t1 | A machine and a shop fit-out last for years and pay for themselves slowly. A short-term loan would fall due long before they have earned the money, so the business would have to sell them or borrow again. Long-term funds stay for as long as the assets take to pay for themselves.
:a 17.1 | Any three. Collateral: the lender can take an asset if the loan is not repaid, which lowers its risk. A covenant, such as a minimum level of owners' equity: it protects the cushion behind the loan. A limit on new borrowing or on profit paid out: it stops money leaving the business. A schedule of instalments: it returns the money along the way.
:a 17.2 | A public issue offers shares to the general public. It reaches many buyers and can raise large sums, but it brings fees, disclosure and new owners. A rights issue offers new shares only to existing shareholders in proportion to their holdings. It is cheaper and keeps control with the old owners, but it raises only what they are willing to pay.
:a 17.3 | Any four. Commercial banks: term loans. Bangladesh Development Bank Limited: long-term loans to industrial projects. Investment Corporation of Bangladesh: money invested in shares and securities. IDCOL: long-term loans for infrastructure and renewable energy. Dhaka Stock Exchange and Chittagong Stock Exchange: places where shares are issued and traded.
:a 17.4 | 11% × (1 − 0.25) = 11% × 0.75 = 8.25%.
:a 17.5 | 0.25 × 7.5% = 1.875%. 0.05 × 12% = 0.60%. 0.70 × 14% = 9.80%. Sum: 12.275%, or about 12.28%.
