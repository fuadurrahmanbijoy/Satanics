:glossary 05
Annuity | A series of equal payments made at equal time intervals for a set number of periods. Three deposits of Tk 1,000, one at the end of each of three years, form an annuity, as do monthly loan instalments over two years.
Ordinary annuity | An annuity whose payments fall at the end of each period. Loan instalments and bank interest are usually of this kind. When no kind is stated, an annuity is taken to be ordinary.
Annuity due | An annuity whose payments fall at the start of each period. Rent paid in advance is an example. Each payment comes one period earlier, so the annuity due is worth 1 + i times an ordinary annuity.
Perpetuity | An annuity that never ends, such as a fund paying a scholarship of Tk 50,000 every year for ever. Its present value is the payment divided by the interest rate.
Factor table | A printed table of ready-made multipliers for given rates and numbers of periods. A reader finds the row for the number of periods, reads the column needed, and multiplies the factor by the payment.
Sinking fund | Money put aside in equal deposits to reach a target sum by a set date. The deposit equals the target divided by the future value factor. A business may use one to replace a vehicle.
Amortisation | Repaying a loan by equal payments that cover the interest and part of the amount borrowed. The instalment equals the loan divided by the present value factor, and the loan falls to zero at the last payment.
