:answers 05
:a 5.p1 | Factor = (1.10⁴ − 1) ÷ 0.10 = (1.4641 − 1) ÷ 0.10 = 4.641. Future value = Tk 1,000 × 4.641 = Tk 4,641.
:a 5.p2 | Tk 3,310 × 1.10 = Tk 3,641, or Tk 1,331 + Tk 1,210 + Tk 1,100 = Tk 3,641.
:a 5.t1 | Present value of the plan = Tk 90,000 × 3.790787 = about Tk 341,171. This is less than Tk 400,000, so the payment plan costs less today. The delay in paying is worth something at 10%.
:a 5.t2 | Each payment of an annuity due is made one period earlier, so it earns one more period of interest, or is discounted one period less. Every payment is therefore worth 1 + i times as much.
:a 5.1 | Factor = (1.09⁶ − 1) ÷ 0.09 = 7.523335. Ordinary: Tk 12,000 × 7.523335 = about Tk 90,280. Due: Tk 90,280 × 1.09 = about Tk 98,405.
:a 5.2 | Factor = (1 − 1.10⁻⁵) ÷ 0.10 = 3.790787. Present value = Tk 45,000 × 3.790787 = about Tk 170,585.
:a 5.3 | Factor = (1.07⁴ − 1) ÷ 0.07 = 4.439943. Deposit = Tk 300,000 ÷ 4.439943 = about Tk 67,568.
:a 5.4 | Factor = (1 − 1.12⁻³) ÷ 0.12 = 2.401831. Payment = Tk 250,000 ÷ 2.401831 = about Tk 104,087.
:a 5.5 | An ordinary annuity pays at the end of each period and an annuity due at the start. The annuity due has the higher future value, because each payment earns one more period of interest.
:a 5.6 | Present value = Tk 20,000 ÷ 0.05 = Tk 400,000. A fund of Tk 400,000 earns 5% × Tk 400,000 = Tk 20,000 a year, so paying out only the interest leaves the fund whole.
