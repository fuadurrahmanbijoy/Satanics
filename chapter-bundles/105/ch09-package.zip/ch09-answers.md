:answers 09
:a 9.p1 | No. The probabilities add up to 0.2 + 0.5 + 0.4 = 1.1, and a probability distribution must add up to exactly one.
:a 9.p2 | Deviations below the expected value are negative and those above are positive, so they would cancel to zero. Squaring makes every deviation positive, so the spread shows.
:a 9.t1 | Coefficient of variation: Project X = 10,000 ÷ 50,000 = 0.20; Project Y = 24,000 ÷ 80,000 = 0.30. Project Y carries more risk for each unit of return.
:a 9.1 | Return = 5,600 + (82,000 − 80,000) = Tk 7,600. Rate of return = 7,600 ÷ 80,000 = 0.095, or 9.5%.
:a 9.2 | Business risk comes from the trade: sales, costs and trade conditions, for example a rise in the price of paper. Financial risk comes from borrowing: interest of Tk 60,000 a year on a loan of Tk 600,000 at 10% must be paid in poor years too, so what is left for the owners varies more.
:a 9.3 | Expected value = 0.25 × 6 + 0.50 × 10 + 0.25 × 14 = 1.5 + 5.0 + 3.5 = 10%. Deviations −4, 0, +4; squares 16, 0, 16; weighted 4 + 0 + 4 = 8; standard deviation = √8 = 2.83%.
:a 9.4 | Asset M: 3 ÷ 10 = 0.30. Asset N: 9 ÷ 18 = 0.50. Asset N carries more risk for each unit of return, although its expected return is higher.
