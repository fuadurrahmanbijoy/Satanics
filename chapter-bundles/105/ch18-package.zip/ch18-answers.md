:answers 18
:a 18.p1 | 60,000 × (1 − 0.25) = Tk 45,000. The payment saves Tk 15,000 of tax.
:a 18.t1 | Lease P: 60,000 × 0.75 = Tk 45,000 a year; 45,000 × 2.600527 = Tk 117,024. Lease Q: 45,000 × 0.75 = Tk 33,750 in years 1 and 2, worth 33,750 × 1.795566 = Tk 60,600; year 3 hire 70,000 × 0.75 = Tk 52,500, worth 52,500 × 0.804961 = Tk 42,260; total about Tk 102,861. Lease Q is cheaper by about Tk 14,163.
:a 18.t2 | The minibus hired for one week is an operating lease. The six-year oven lease that cannot be cancelled is a financial lease. The press sold and leased back is a sale and leaseback.
:a 18.1 | The owner is the lessor and the puller is the lessee. A lease is a contract in which the owner of an asset lets another party use it in return for regular payments.
:a 18.2 | An operating lease is short or cancellable and the lessor keeps most risks, for example a scanner hired by the month. A financial lease is long and cannot be cancelled, and the lessee in effect carries the cost and risk of owning, for example a six-year oven lease.
:a 18.3 | 80,000 × (1 − 0.25) = Tk 60,000. The payment lowers taxable profit by Tk 80,000, which saves Tk 20,000 of tax.
:a 18.4 | First, find the after-tax cash outflow of leasing each year. Second, find the after-tax cash outflow of buying each year. Third, convert each outflow to a present value at the after-tax cost of debt and add. Fourth, compare the totals and choose the lower.
:a 18.5 | Discount rate = 8% × 0.75 = 6%. Lease: 100,000 × 0.75 = 75,000 a year; 75,000 × 2.673017 = about Tk 200,476. Buy: 70,000 ÷ 1.06 + 72,000 ÷ 1.1236 + 74,000 ÷ 1.191016 = about Tk 192,249. Buying costs about Tk 8,227 less, so buy.
