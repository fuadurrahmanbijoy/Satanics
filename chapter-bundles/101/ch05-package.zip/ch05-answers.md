:answers 05
:a 5.p1 | External. A competitor's price cut happens outside the business, and the business cannot control it directly. It is an economic force.
:a 5.t1 | The competitor is part of the external environment, in the economic group, because it concerns competition and price.
:a 5.t2 | Examples: the skill and number of staff, the stock the shop holds and how it is recorded, the money available, and the shop's culture of service.
:a 5.t3 | Adapt: change the stock, improve service or reduce costs. Influence: build goodwill with customers or join other shops in a trade association. Either answer should stay within the law.
:a 5.1 | Internal: (a), (c), (e), (h), (j). External: (b), (d), (f), (g), (i).
:a 5.2 | The textbook price cut and the curriculum change would matter less. The internal facts, 7 staff and stock listed on paper cards, would still matter for the remaining books.
:a 5.3 | The rise in flour prices is external, in the economic group. Hiring a new baker is internal, because the bakery decides it.
:a 5.4 | Internal: the owner, the managers, the employees. External: customers, suppliers, lenders, competitors or the government. Any five such stakeholders, correctly placed, are acceptable.
:a 5.5 | A fall in sales caused by an external change can reduce income until the business cannot continue, and lost customers weaken goodwill. A site with more footfall or a stronger local market may lower the risk, though no site removes it.
