:chapter V | The Business Environment
:mood Why can sales fall when nothing inside the shop has changed?
:desc A business does not stand alone. Forces inside it and forces around it shape what it can do, and some of those forces change without warning. This chapter names the forces, sorts them into two groups, and shows how a business can respond. We follow the bookshop's 2025 records and the story of a famous camera company.
:plate ch05-plate.svg | A harbour-master's window: ships, cranes and a market square beyond

:box YOU WILL NEED
From Chapter 3, 'Objectives of Business and What Makes It Succeed', section 3.1 'The Purpose of a Business', you need the idea that a business has objectives. From Chapter 4, 'Choosing Where a Business Stands', section 4.1 'Why Location Matters', you need the idea that a site has features that help or hurt a business. Nothing else is assumed.

> A business can lose sales while nothing inside it changes.

Suppose the owner of a shop keeps the same shelves, the same seven staff and the same opening hours for two years. Nothing in the shop is worse than before. Yet in one year, sales of the shop's main product fall by a large sum. The owner asks a hard question: if nothing inside the shop changed, where did the cause come from?

> The shop's textbook sales show such a fall in 2025.

:case Case file, illustrative. Meghna and Sons recorded textbook sales of Tk 4,300,000 in 2025, against Tk 5,100,000 in 2024. Overall sales in 2025 were Tk 14,400,000. The record also notes that online sellers cut textbook prices by about 15% from March 2025, and that a school curriculum change was announced for January 2026.

> The answer lies in the surroundings of the business, which this chapter names.

The record points to events outside the shop: a price cut by other sellers and a decision about school books. Neither event happened in the shop, yet both can change what the shop sells. Every business lives among such events. This chapter gives names to the forces inside and outside a business, and shows how an owner can respond when they change.

* * *

## Inside the Business

> A household has some things under its control and others that are not.

Begin with your own household. You decide how the family spends its money in a month, who cooks, and which rooms are used. You do not decide the price of rice in the market, the weather, or whether the electricity fails. Some forces you control, and others reach you from outside. A business is in the same position.

> The word environment names all the forces and conditions that affect a business.
@ Environment | All the forces and conditions, inside and outside a business, that affect how it operates.
@ Environment | Word in use. In daily life, environment often means nature: air, water, forests and weather. In this subject, environment means all the forces and conditions, natural or not, that affect how a business operates.

The word for all these forces together is **environment**. The environment of a business is all the forces and conditions, inside and outside the business, that affect how it operates. In daily life people use the word for nature. Here it is wider: it includes staff, prices, laws and machines as well as weather. We sort it into two groups. The first group lies within the business.

> The internal environment is the group of forces inside the business that it can control.
@ Internal environment | Forces within the business that it can control, such as its staff, resources and rules.

The first group is the **internal environment**. The internal environment means forces within the business that it can control, such as its staff, resources and rules. The owner can change the shop's opening hours, train staff, or alter how stock is recorded. The word *internal* means inside. Control is the key idea: the owner may use it or may choose not to, but the power to decide belongs to the business.

> Owners, managers and employees are the people inside, and each sees the business differently.

Three groups of people stand inside every business. Owners provide the money, carry the risk and set the objectives.^1 Managers organise the work and make daily decisions. Employees do the work, and they give the business its skill and energy. Each group has its own interests: the owner looks for profit, the manager for smooth operation, the employee for fair pay and safe work. These interests often agree, but they can also conflict.

^1: Recall: objectives, Chapter 3, 'Objectives of Business and What Makes It Succeed', section 3.1 'The Purpose of a Business'.

> A stakeholder is anyone affected by the business or able to affect it.
@ Stakeholder | Any person or group affected by a business or able to affect it, such as staff or customers.

Such people are called **stakeholders**. A stakeholder is any person or group affected by a business or able to affect it, such as staff or customers. Owners, managers and employees are the internal stakeholders. Later in this chapter we meet stakeholders outside the business. A stake is an interest in the outcome: a person with a stake gains or loses when the business does well or badly.

> Resources and culture complete the internal picture: what the business holds and how it behaves.
@ Culture | Word in use. In daily life, culture often means the arts, customs and way of life of a whole society. In a business, culture means the shared habits and beliefs of the people who work there.

Two more internal forces matter. Resources are what the business holds: money, stock, equipment, skills, and systems for keeping records. Culture is the set of habits and beliefs that people in the business share, such as how they treat customers and how willing they are to try new methods. Resources can be counted; culture must be observed over time.

> One internal change looks different to each person who stands inside the business.

Consider one internal change: the shop replaces its paper cards with a computer list of stock. The owner sees a cost and a possible gain in sales. The manager sees time spent on moving the records and on checking them. An employee sees a new task to learn, and perhaps a quicker way to find a title. A customer, who stands outside, sees only whether the book can be found sooner. One change, four viewpoints: this is why a manager must ask who is affected before deciding.

> Rules written by the business are internal; laws made by the state are external.

A business also has rules of its own: a rule on how staff greet customers, or a rule on when a customer may return a book. These rules are part of the internal environment, because the business wrote them and can change them. Laws are different. A law is a rule made by the state, and the business must obey it whether it likes the law or not. Many students confuse the two, because both are called rules. The test is simple: who can change it? If the business can, it is internal.

> At the shop, the internal facts in 2025 were seven staff and stock listed on paper cards.

:case Case file, illustrative. The internal record of Meghna and Sons for 2025 lists 7 staff and stock listed on paper cards. Both facts belong to the internal environment, because the shop can change them.

> A culture of care or of carelessness shows in small daily habits.

Culture shows in small daily habits. In a shop where staff greet each customer and note what customers ask for, the owner learns quickly what readers want. In a shop where staff ignore such questions, the owner learns late. Culture cannot be bought like a shelf. It grows from what owners and managers do every day, and from what they praise or ignore. This is why culture can be a strength that rivals cannot copy, or a weakness that is hard to remove.

> Internal control is partial, and internal forces create strengths and weaknesses.

Control is not complete. A manager can train staff but cannot make every employee equally skilled. An owner can buy a computer only if money allows. Internal forces also create strengths and weaknesses. A trained, willing team is a strength. Stock listed on paper cards may be a weakness, because finding a title can take longer and errors may be more likely.

> Section 5.1 ends with a recap.

*Before moving on.* The environment is all the forces and conditions that affect a business. The internal environment is the part the business can control: owners, managers, employees, resources and culture. A stakeholder is any person or group affected by a business or able to affect it.

## Outside the Business

> The owner cannot choose competitors' prices or the law, yet both matter.

Return to the puzzle of the bookshop. The price cut by online sellers and the curriculum change came from outside the shop. The owner did not choose them and cannot order them to stop. Forces of this kind form the second group.

> The external environment is the group of forces outside the business that it cannot control directly.
@ External environment | Forces outside the business, such as customers, laws and prices, that it cannot control directly.

The second group is the **external environment**. The external environment means forces outside the business, such as customers, laws and prices, that it cannot control directly. The word *directly* matters. The shop cannot command customers or change a law, although it can influence some forces, as section 5.3 shows. External stakeholders include customers, suppliers, lenders, competitors and the government. Features of the area around the shop, such as its neighbours and roads, also belong here.^2

^2: Recall: plant location, footfall and industrial estate, Chapter 4, 'Choosing Where a Business Stands', section 4.1 'Why Location Matters'. Site factors belong to the external environment.

:pause 5.p1 | Is a competitor's price cut part of the internal or the external environment? Give one reason.

> External stakeholders each want something different from the business.

External stakeholders each want something different. Customers want goods of good quality at a fair price. Suppliers want orders and prompt payment. Lenders want their money back with interest. Competitors want the same customers. The government wants taxes paid and laws obeyed. Because their wants differ, a decision that pleases one group can displease another: a lower price pleases customers but may trouble a supplier who is asked to charge less.

> Sorting forces helps an owner decide what can be changed and what must be met.

Why sort at all? The sort tells the owner what to do about each force. An internal fact can be changed. An external force can only be met: by adapting, by influencing within limits, or by scanning for early warning. An owner who mixes the two groups wastes effort, for example by trying to change a competitor's price instead of changing the shop's own stock list.

> The many external forces are easier to hold in mind when sorted into four groups.

The external environment holds many forces, so we sort them into four groups. The table below names each group, says what it contains, and gives a bookshop example. Read each row from left to right. The groups overlap at the edges, as the exceptions below explain.

:table Four groups of external force
| Group | What it contains | Bookshop example |
| Economic | Prices, incomes, competition, interest rates | Online sellers cut textbook prices |
| Social and cultural | Habits, beliefs, tastes, population | Visits to the book fair each February |
| Political and legal | Government decisions, laws, taxes | A school curriculum change |
| Technological | New machines, methods and tools | Online selling websites |

> Economic forces concern money: incomes, prices and competition.

Economic forces concern money and trade. They include what customers earn and are willing to spend, the prices competitors charge, and the cost of borrowing. When incomes rise, customers can buy more books. When a competitor lowers its prices, customers may move to it. In the case file, the price cut of about 15% by online sellers is an economic force. A shop with unchanged prices now looks dearer by comparison, although it changed nothing.

> Social and cultural forces are the habits, beliefs and tastes of the people around.

Social and cultural forces are the habits, beliefs and tastes of the people around the business. They include what people read, how families value education, which festivals bring gifts, and how the population changes. Each February, Dhaka holds the Amar Ekushey Book Fair, where many readers buy books. A bookshop feels such a habit, because buying may move to the fair for a month. Tastes also change slowly, which makes these forces hard to notice.

> Political and legal forces are the decisions of governments and the rules that follow.

Political and legal forces are the decisions of governments and the laws that follow. They include taxes, rules on trading, and decisions about education. Laws differ from country to country, so a business must learn the rules of the place where it works. A curriculum is the list of subjects and books a school teaches. The curriculum change announced for January 2026 is a decision about education of this kind: it may change which books students need, and so what the shop should stock.

> Technological forces are new machines, methods and tools that change how business is done.

Technological forces are new machines, methods and tools that change how goods are made, sold and delivered. Online selling is the main example for a bookshop: a customer can compare prices on a phone and order without leaving home. Technology can also help the business, since a shop can use it to record stock or to reach customers. A technological force can therefore be a threat or an opportunity, depending on how the business responds.

> Each external force can bring a threat or an opportunity, depending on the business.

A force is not good or bad in itself. A price cut by online sellers is a threat to a shop that sells only textbooks. The same cut is an opportunity to a school that now buys its books more cheaply. A new curriculum is a threat to a shop with old stock, and an opportunity to a shop that is ready with the new books. The question for the owner is always the same: what does this force mean for this business, in this year?

> Customers are both external stakeholders and the source of the business's income.

Customers deserve special notice among the external stakeholders. They are outside the business, so the owner cannot control them. Yet without them the business has no income. A business that watches its customers closely learns early about changes in tastes, prices and needs. In this sense customers are the most important window through which a business sees its external environment.

> The groups overlap, and the forces change at different speeds.

The groups overlap. The online price cut is economic, because it concerns price, and technological, because online selling made it possible. Sorting is a tool for thinking, not a law: when a force fits two groups, name both. The forces also change at different speeds. Laws change in announced steps, tastes change slowly, and technology can change fast.

> Section 5.2 ends with a recap.

*Before moving on.* The external environment is the group of forces outside the business that it cannot control directly. We sort these forces into economic, social and cultural, political and legal, and technological groups. The groups overlap, so name every group that fits.

## Interaction with the Environment

> A business and its environment act on each other in both directions.

The internal and external groups are not separate worlds. They act on each other, and this two-way action is called interaction. Forces from outside reach the business: a price cut lowers sales. Forces from inside shape the response: stock on paper cards makes it harder to see which titles still sell. The business also acts outwards, since its prices and service shape how customers feel. The figure below shows the business at the centre with the internal forces close around it and the external forces beyond. Read it from the centre outward; the arrows run both ways.

:fig A business at the centre with internal and external forces around it | ch05-fig01.svg

> A business can adapt to change by altering what it does.

The first response is adapting. Adapting means changing what the business does so that it fits new conditions. The shop could change its stock to match the new curriculum, offer advice that an online seller cannot give, or reduce its costs. Which choice suits depends on the internal environment: only changes that the shop can afford, and that its staff can perform, are real options. A customer sees the result as a shop that still offers what is needed.

> A business can sometimes influence outside forces, but only within limits.

The second response is influencing the environment. A business can sometimes shape the forces around it. It can build goodwill by serving customers well, so that they stay when prices tempt them away. Several shops can also join a trade association to speak with one voice to officials. The limits are real. A small shop cannot reverse an online price cut or change a law alone, and any influence must stay within the law.

> Scanning means watching the outside forces regularly, so that change brings early warning.

The third response is scanning for change. Scanning means watching all four groups of external force on a regular basis: reading the news, noting competitors' prices, and asking customers what they need. Scanning gives time. The curriculum change was announced for January 2026, so a shop that scans has months to adjust its stock before the change arrives. A shop that does not scan learns of it when customers ask for books it does not hold.

> A table compares the three responses and their limits.

The three responses can be compared side by side. The table below names each response, says what it means, gives a shop example, and states its main limit. Read each row from left to right.

:table Three responses to a changing environment
| Response | What it means | Shop example | Main limit |
| Adapting | Changing what the business does | Stocking the new curriculum books | Needs money and time |
| Influencing | Shaping the forces around it | Building goodwill with local schools | A small business has little power |
| Scanning | Watching for change early | Noting competitors' prices each month | Gives warning, not a cure |

> Owners, employees and customers experience a response differently.

Each response looks different from each viewpoint. The owner weighs cost against the risk of losing sales. The employees may need training and may worry about their jobs. The customers notice only the result: whether the shop still has the books they need at a fair price. A response succeeds when all three viewpoints can accept it.

> The environment can help or block a business's objectives, including survival and goodwill.

The environment also connects to the objectives of Chapter 3. A fall in sales can threaten survival, which is the first aim of most businesses. A loss of customers can damage goodwill, the trust that brings customers back. A change in the environment may block an objective, but it can also open a chance, such as a new group of customers who want a service the shop can supply.

> Adapting has costs, and doing nothing is also a choice.

Adapting is not free: new stock needs money and new methods need training. Yet doing nothing is also a choice, and it can threaten the survival of the business. The honest question for an owner is which cost is smaller. The change itself is not always clear in advance, either, so some mistakes cannot be avoided. Good scanning reduces them but does not remove them.

:box IN SHORT
The environment has two parts. The internal environment is what the business can control. The external environment is what it cannot control directly. Stakeholders stand in both parts.

> Section 5.3 ends with a recap.

*Before moving on.* A business and its environment act on each other. A business can adapt to change, try to influence the forces around it within limits, and scan regularly for early warning. Each response has a cost, and doing nothing is also a choice.

## A Worked Case: Sorting the Shop's Forces

> The worked case sorts the shop's recorded facts and measures the fall in textbook sales.

:case Case file, illustrative. The 2025 record of Meghna and Sons shows textbook sales of Tk 4,300,000, against Tk 5,100,000 in 2024. Overall sales were Tk 14,400,000. Online sellers cut textbook prices by about 15% from March 2025. A school curriculum change was announced for January 2026. Internally, the shop has 7 staff and stock listed on paper cards.

> The question asks for a sort into internal and external, and for the size of the fall.

*Question.* Sort the four recorded facts into the internal and external environment, name the group of each external force, and measure the fall in textbook sales and the share textbooks form of overall sales.

> Reasoning step one sorts the four facts.

*Reasoning, part one.* The price cut is outside the shop and cannot be controlled directly, so it is external; it is economic, and technological too, because online selling made it possible. The curriculum change is also external, in the political and legal group. The 7 staff and the paper cards are inside the shop and can be changed, so both are internal.

> Reasoning step two measures the fall and the share.

*Reasoning, part two.* The fall is Tk 5,100,000 − Tk 4,300,000 = Tk 800,000. As a share of 2024 textbook sales, Tk 800,000 ÷ Tk 5,100,000 = 0.157, or about 15.7%. Textbooks formed Tk 4,300,000 ÷ Tk 14,400,000 = 0.299 of overall 2025 sales, or about 29.9%.

> Reasoning step three lists the responses open to the shop.

*Reasoning, part three.* The shop can adapt, because the curriculum change gives notice: it can study the new list of books and adjust its stock before January 2026. It can influence within limits, by building goodwill with nearby schools. It can scan, by noting competitors' prices each month. The internal facts shape these options, since stock on paper cards makes it harder to see which titles sell, and seven staff set a limit on what can be done at once.

> The conclusion states the sort and the size, and the check tests the arithmetic.

*Conclusion.* Two external forces and two internal facts appear in the record. Textbook sales fell by Tk 800,000, about 15.7%, and they remain about 29.9% of overall sales, so the forces matter. The record shows the events and the fall; it does not prove that the price cut caused all of the fall. *Check.* Tk 5,100,000 − Tk 800,000 = Tk 4,300,000, and 0.299 × Tk 14,400,000 is about Tk 4,300,000.

* * *

## Summary

> The environment has an inside and an outside, and a business can respond to both.

The environment is all the forces and conditions that affect how a business operates. The internal environment holds what the business can control: owners, managers, employees, resources and culture. The external environment holds forces it cannot control directly: economic, social and cultural, political and legal, and technological. A stakeholder is anyone affected by the business or able to affect it. A business can adapt, influence within limits, and scan for change.

## Think It Through

> A new competitor opens near a bookshop, and the owner must decide how to respond.

A new bookshop opens two streets from a small shop. It sells the same kinds of book and advertises lower prices. The owner of the small shop has the same staff and the same stock as before.

:q 5.t1 | Which part of the environment is the new competitor, and in which of the four groups does the competitor belong?
:q 5.t2 | Name two internal forces that will decide how well the small shop can respond.
:q 5.t3 | Describe one way the owner could adapt and one way the owner could try to influence the situation.

## Where People Go Wrong

> External forces cannot be controlled, but they can be answered.

*A business can ignore external forces because it cannot control them.* The business cannot control them directly, but it can adapt, influence within limits, and scan for early warning. Ignoring them is a choice with a cost.

> Internal does not mean fully controlled or free of problems.

*Everything internal is under complete control.* Control is partial: money, skills and time limit what the owner can change, and internal forces can be weaknesses.

> A stakeholder is not only the owner.

*A stakeholder is the owner.* A stakeholder is anyone affected by the business or able to affect it, including staff, customers, suppliers and the government.

> Environment in this subject is wider than nature.

*Environment means nature.* In daily life it often does, but here it means all the forces and conditions, inside and outside the business, that affect how it operates.

## In History

> Kodak invented the digital camera in 1975 yet failed to adapt in time and sought bankruptcy protection in 2012.

George Eastman founded the Kodak company in Rochester, New York, in the United States, and in 1888 it introduced a simple camera for ordinary people. For more than a century, photographic film was Kodak's main business. In 1975 a Kodak engineer, Steven Sasson, built the first digital camera. Digital photography later grew, and smartphones took much of the market. Many observers judge that Kodak's habits and resources, built around film, slowed its response. On 19 January 2012 the company filed for bankruptcy protection under Chapter 11 of United States law, which lets a company reorganise while it still operates. The external force was technological, and the internal culture shaped the response.

## Review Questions

:q 5.1 | Sort each into internal or external: (a) the skill of the shop's staff; (b) a new tax on imported books; (c) the layout of the shelves; (d) a competitor's price cut; (e) the owner's decision to open on Fridays; (f) a rise in customers' incomes; (g) a new payment application; (h) the shop's habit of greeting every customer; (i) rain flooding the road outside; (j) the cash held in the shop's drawer.
:q 5.2 | Suppose Meghna and Sons stopped selling textbooks. Which forces in the case file would then matter less, and which internal facts would still matter?
:q 5.3 | A small bakery faces a rise in flour prices and hires a new baker. Sort these two events into internal and external, and name the group of the external one.
:q 5.4 | Name five stakeholders of the shop, and say whether each is internal or external.
:q 5.5 | Explain how a change in the external environment could threaten the survival of a business and its goodwill, and say how a different site from Chapter 4 might change the risk.

:read R. Edward Freeman, Strategic Management: A Stakeholder Approach, 1984
:read Michael E. Porter, Competitive Strategy, 1980
