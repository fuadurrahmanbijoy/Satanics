:glossary 05
Environment | All the forces and conditions, inside and outside a business, that affect how it operates. It includes staff, prices, laws and machines as well as weather. The shop's environment includes its seven staff and an online seller's price cut.
Internal environment | Forces within the business that it can control, such as its staff, resources and rules. The owner can change opening hours or how stock is recorded, so these belong to the internal environment.
External environment | Forces outside the business, such as customers, laws and prices, that it cannot control directly. Examples are a competitor's price cut and a school curriculum change. The business can adapt to them or influence them within limits.
Stakeholder | Any person or group affected by a business or able to affect it, such as staff or customers. Owners, managers and employees are internal stakeholders; customers, suppliers, lenders and the government are external stakeholders.
