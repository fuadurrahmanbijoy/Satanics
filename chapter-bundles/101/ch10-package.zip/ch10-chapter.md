:chapter X | The Cooperative Society
:mood What if the customers owned the shop?
:desc Most businesses are owned by people who hope to earn a profit from other people's needs. A cooperative society turns this around: the people who have the need own the business, each with one vote. This chapter explains the idea, its four common kinds and the way a cooperative is formed, managed and shared out.
:plate ch10-plate.svg | A village store of the 1840s, owned by the members who queue at its counter

> Two earlier ideas are needed before this chapter.

*You will need* two earlier ideas. The first is the list of ownership forms: see Chapter 7, 'Forms of Business Ownership and the Sole Proprietorship', section 7.1 'Choosing an Ownership Form'. The second is the company, which this chapter uses as a contrast: see Chapter 9, 'The Joint Stock Company', section 9.1 'What a Company Is'.

> Poor buyers in a small town pay too much for poor goods.

Imagine a town where the only shop belongs to one trader. The trader buys flour in small quantities, so he pays a high price. He sells it at a higher price still, and he mixes sand into the sack to add weight. The townspeople are poor, and the nearest other shop is a day's walk away. They have no choice but to buy from him. Each family knows it is being cheated, and each family is too weak to change anything alone.

> The people discover that together they could do what none can do alone.

Then one evening some of them meet and make a calculation. If thirty families each gave a small sum, they could buy a whole sack of flour at once, at a lower price, and sell it to themselves at fair weight. No outside owner would take a profit from them. Whatever remained after the costs could return to the families. The idea is simple to state and difficult to carry out: who would own the shop, who would decide, and who would share the gain? This chapter shows how a group of people answers these questions on equal terms, and it ends with a real shop opened by working people in England in 1844.

## The Cooperative Idea

> Neighbours who lend tools to one another already practise the idea in a small way.

Before we study the business form, think of a daily example. Several neighbours need a ladder, but none uses it more than twice a year. They buy one ladder together and keep it in a shared place. Each neighbour pays a fair part and each may use it. No one makes a profit from the others. The arrangement works because every person has the same need and every person has the same claim. A cooperative society is a larger and more formal version of such an arrangement.

> A cooperative society is owned by its members, who join to meet a common need.
@ Cooperative society | A business owned and run by members who join to meet a common need, each with one vote.
@ Society | Word in use. In daily life, all the people of a country or a community. In business, a form of business owned by its members, as in cooperative society.
@ Member | Word in use. In daily life, a person who belongs to a club or group. In a cooperative, an owner of the business who has paid for a share and holds one vote.

A **cooperative society** is a business owned and run by members who join to meet a common need, each with one vote. A *member* is one of these owners. For example, thirty families who own a flour shop together, and who also buy their flour from it, form a cooperative society. The word *society* has a special meaning here: it names a business form and does not mean the people of a country. A cooperative differs from the forms of the earlier chapters in its purpose. It exists to serve its members, and it does not exist to enrich outside owners.^1

^1: Recall: the ownership forms, Chapter 7, section 7.1 'Choosing an Ownership Form'. A cooperative belongs to the private sector, because individuals own it and government does not.

> A sole owner and a company both seek profit for their owners.

The contrast with other forms is useful. A sole proprietorship has one owner, who keeps all the profit. A company has shareholders, who own it in proportion to the number of shares they hold, and whose main aim is a return on their money.^2 In each of these forms the owner and the customer are usually different people. In a cooperative they are often the same people. The member who buys flour from the cooperative is also an owner of the cooperative, and so a good price for the member is the aim of the business and not a cost to it.

^2: Recall: the company as a contrast, Chapter 9, section 9.1 'What a Company Is'. Shares in a company carry votes in proportion to the number held.

> Rules called principles guide how cooperatives are run.
@ Cooperative principle | A basic rule of cooperatives, such as open membership, one vote per member and fair sharing of surplus.

A **cooperative principle** is a basic rule of cooperatives, such as open membership, one vote per member and fair sharing of what remains after costs. A later section names that remainder and explains it: see section 10.3 'How a Cooperative Operates'. The first principle is open membership, which means that anyone with the need may join, whatever the person's wealth, religion or position. The second is control by members, which means that members decide, not outsiders. The third is fair sharing of the gain. The fourth is education: a society teaches its members how to run it. These rules came from a real shop, whose story ends this chapter.

:pause 10.p1 | Name two cooperative principles and say what each one protects.

> Self-help is the spirit behind the idea, and it asks for effort from every member.

The idea rests on self-help. Members do not wait for a rich owner or for government to solve their problem; they solve it themselves, and they accept that the solution needs effort from each person. A member must pay for a share, attend meetings, buy from the society where possible and accept the decisions of the majority. A cooperative whose members expect others to do the work will weaken. This is why education is a principle: people must learn how to run a business before they can own one together.

> Each member has one vote, whatever the number of shares held.

The most distinctive principle is *one member one vote*. It means that every member has exactly one vote, however much money the member put in. In a company, a person who holds many shares holds many votes. In a cooperative, a person who holds ten shares and a person who holds one share each have one vote. The reason is fairness: a cooperative is a union of people, not of money. A wealthy member cannot buy control from poorer members.

> One member one vote protects the weak but does not remove all difficulty.

The rule has limits that a careful reader should notice. A cooperative needs money, and members usually pay for shares to provide it. The number of shares a member may hold is often limited, so that no person gains great power. The vote protects small members from large ones, but it does not ensure that members attend meetings or decide wisely. A cooperative with many members who never vote may be run by a few active people. Equal votes are a protection, not a guarantee of good management.

> Before moving on: this section gave three ideas.

*Before moving on.* A cooperative society is a business owned and run by members who join to meet a common need, each with one vote. Cooperative principles are the basic rules that guide it: open membership, control by members, fair sharing of the gain and education. One member one vote means every member has one vote whatever the number of shares held.

## Kinds of Cooperative

> Cooperatives differ by the need that brings the members together.

Members join a cooperative because of a need, and the need decides the kind of cooperative. Four kinds are common in most countries. A fifth set of kinds exists for housing, farming and other needs, but the four below show the main ideas. For each kind we ask the same question: what do the members have in common, and what does the cooperative do for them?

> A consumer cooperative is a shop owned by the people who buy from it.

The first kind is the *consumer cooperative*, a shop or service owned by the people who buy from it. The thirty families in the opening puzzle formed one. The members aim to buy goods of honest quality at fair prices. Many such shops, like the Rochdale shop, share their gain by returning part of it to members in proportion to what each bought. The consumer cooperative is the form most familiar to ordinary people, and it is often the first one that a community forms.

> A producer cooperative is owned by the people who make the goods.

The second kind is the *producer cooperative*, owned by people who make goods or provide work together. A group of weavers may buy looms together and work in a shared workshop. A group of fishing families may own boats together. The members are both owners and workers, so they share the decisions and the income. This kind gives skilled people a way to work for themselves without large capital. Its limit is that the members must agree on how work and pay are shared, and disagreements can be difficult to settle.

> A marketing cooperative sells the products of its members together.
@ Marketing cooperative | A cooperative that sells its members' products together to obtain better prices.

A **marketing cooperative** is a cooperative that sells its members' products together to obtain better prices. For example, a hundred small farmers who each grow a little jute may sell separately and accept the price a trader offers. If they sell together, they offer a large amount, they can wait for a better price, and they can bargain with many buyers. The cooperative collects the product, grades it, stores it and sells it. Each member receives a payment in proportion to the amount delivered. Farm marketing is the commonest use of this kind.

> A credit cooperative lends money to its members from their own savings.

The fourth kind is the *credit cooperative*, which is a society where members save together and lend to one another. Each member deposits small savings. The society lends from the pool to members who need money for a shop, a field or a school fee, and it charges a modest rate. Because the members know one another, the society can judge who is likely to repay. Poor people who cannot obtain a loan from a bank often find a credit cooperative their only source of fair credit.

> Four kinds can be compared by who the members are and what they gain.

A table can show the four kinds side by side. Read each row as one kind: the first column names it, the second names who the members are, and the third states what they gain.

:table Four kinds of cooperative, their members and their gain
| Kind | Members are | What members gain |
| Consumer cooperative | People who buy goods | Fair prices and honest quality |
| Producer cooperative | People who make goods | Shared work, shared income |
| Marketing cooperative | People who grow or make goods for sale | Better prices for their products |
| Credit cooperative | People who save and borrow | Fair loans from shared savings |

> The kinds can be combined, and many cooperatives serve more than one need.

The kinds are not rigid. A village society may sell seeds to its farmers, market their crops and lend them money for the next season. In such a case it serves the farmers as consumers, as marketers and as borrowers. The law of each country may require each society to state its purpose when it registers, and a society that wishes to change its purpose may need new permission. The name of the kind tells the reader what the members chiefly need, and nothing more than that.

> Before moving on: this section gave four kinds of cooperative.

*Before moving on.* A consumer cooperative is owned by those who buy; a producer cooperative by those who make; a credit cooperative by those who save and borrow. A marketing cooperative sells its members' products together to obtain better prices. The need that unites the members decides the kind, and one society may serve more than one need.

## How a Cooperative Operates

> Formation is easier than for a company but follows steps set by law.

Imagine that twenty bookshop owners agree to buy paper together. How do they begin? A cooperative is formed by people who share a need, who agree on a purpose and on rules, and who pay for the first shares. Most countries then require registration with a government office. In Bangladesh the law is the Cooperative Societies Act, and societies are registered with a government registrar of cooperatives.^3 Registration gives the society legal standing: it may own property, sign contracts and sue, as a person may.

^3: The Cooperative Societies Act of 2001 is the law in Bangladesh, with later amendments. Rules on the number of members, the share capital and the permitted purposes differ by country and change over time, so check the current law before relying on any figure.

> Members of a registered society usually have limited liability.

Registration also decides the liability of the members. In most countries, including Bangladesh, a registered cooperative gives its members limited liability, which means that a member can lose no more than the money paid for shares. This is different from a sole proprietorship, where liability is unlimited. A member who owns ten shares of Tk 1,000 may lose at most Tk 10,000 if the society fails. The law of each country must be checked, because a few types of society have a different rule.

> The members govern through a general meeting and a committee they elect.

How does a society with many members make decisions? It cannot ask every member about every matter. Instead, all members meet at least once a year in a *general meeting*, where each has one vote. The meeting approves the accounts, decides large questions and elects a *management committee*, a small group of members who direct the society between meetings. The committee appoints a manager and staff to do the daily work. The sketch below shows how authority moves in a ring: the members form the meeting, the meeting elects the committee, and the committee answers to the members.

> The sketch is a ring with three parts, and each arrow shows one act of authority.

To read the sketch, start with the box for the members at the lower left. An arrow runs from the members to the box for the general meeting at the top, because the members attend the meeting and vote. A second arrow runs from the meeting to the box for the committee at the lower right, because the meeting elects the committee. A third arrow runs back from the committee to the members, because the committee serves them and reports to them. Authority therefore returns to where it began.

:fig The ring of authority: members, general meeting and committee | ch10-fig01.svg

> The committee manages, and members check its work.

The committee has duties as well as powers. It keeps the accounts, admits new members, makes sure the society obeys the law and its own rules, and reports to the members at the meeting. Members may remove a committee that fails them. This arrangement gives the members real control, though it depends on their taking part. A society whose members never attend meetings may become one that a few committee members control, and the original idea of equal ownership is weakened.

> What remains after costs is the surplus, and a cooperative shares it among members.
@ Surplus | In a cooperative, what remains after costs, shared among members instead of paid to outside owners.

The business must also pay its way. The money received from sales, less the cost of goods, wages, rent and other expenses, leaves an amount at the end of the year. In a cooperative this amount is called the **surplus**, which is what remains after costs, shared among members instead of paid to outside owners. Many writers use the word *surplus* and not *profit* because the aim of the society is not to make money from the members. A surplus arises when the society charges members a little more than its costs, or sells their goods for a little more than it paid.

> The surplus is divided by rule, and part of it is kept for the society.

The members decide at the general meeting what to do with the surplus. Four uses are common. Part is kept in a reserve to meet future losses and to grow the society. Part is paid as a *dividend*, which means a payment shared out among members, in many cooperatives in proportion to the amount each member bought or sold through the society. A limited interest may be paid on shares. Part may be spent on education or on the community. A company pays its profit in proportion to shares; a cooperative pays its surplus in proportion to use.

> A member has duties to the society as well as rights from it.

Rights and duties go together in a cooperative. A member has the right to vote, to be told how the society is doing, to receive a fair share of the surplus and to stand for election to the committee. A member also has duties: to pay for the shares agreed, to obey the rules, to deal with the society in good faith, and to treat other members fairly. A person who takes the benefits but neglects the duties harms every other member, because the society belongs to all of them together.

> A cooperative has real merits and real limits.

What are the merits and limits of the form? Its merits are fairness, since each member has one vote; protection for weak buyers and sellers; limited liability; and a purpose that serves members. Its limits are that it may raise less money than a company, because members are often poor and the number of shares each may hold is restricted; that decisions may be slow when many members must agree; that managers may lack skill or the incentive to work hard; and that members may lose interest. The form suits people with a shared need, and it suits less well a business that needs very large sums.

> Cooperatives help farmers sell their crops for a fair price.

One field deserves a final note. Small farmers face a weak position when selling crops. Each farmer has only a little to sell and needs money quickly, so the trader sets the price. A marketing cooperative lets farmers collect, store and sell together, and often gives them a place to borrow before the harvest. In several countries, including Bangladesh, governments encourage this use of cooperatives. The result depends on honest management and on members who deliver their crops to the society and not to the trader outside.

> Before moving on: this section gave the working of a cooperative.

*Before moving on.* A cooperative is formed by people with a shared need, registered under the law of the country, and usually gives its members limited liability. The members govern through a general meeting and an elected committee. The surplus is shared by rule among reserve, dividend, interest on shares and the community. The form has fairness and protection as merits and limited money and slow decisions as limits.

* * *

## A Worked Case: A Buying Cooperative for Dhaka Bookshops

> A worked case applies the ideas to a recorded proposal and is not a model answer.

A worked case applies an idea to a situation. It has five parts: the situation, the question, the reasoning, the conclusion and a check. We apply the ideas of this chapter to one case file.

> The situation is a proposal for twenty-two bookshops to buy together.
:case Case file, illustrative. Proposal, 2026. Twenty-two independent bookshops in Dhaka propose to form a buying cooperative. Meghna and Sons would hold 10 shares of Tk 1,000 each, a total of Tk 10,000. The shop's paper and stationery purchases are Tk 2,400,000 a year. The expected bulk discount is 12 per cent, which is Tk 288,000 a year.

> The table lists the figures of the proposal in order.

The table below lists the figures of the proposal. Read each row as one item, with its amount in taka.

:table Figures in the proposal for Meghna and Sons
| Item | Amount (Tk) |
| Cost of 10 shares at Tk 1,000 each | 10,000 |
| Paper and stationery purchases a year | 2,400,000 |
| Expected discount, 12 per cent | 288,000 |

> The question asks what the proposal offers the shop, and what the shop must give.

*Question.* What does Meghna and Sons gain from the proposal, what does it risk, and what control does it hold?

> Reasoning begins by checking the discount, then compares it with the money put in.

*Reasoning.* First we check the discount. Multiply the yearly purchases by the rate: 2,400,000 × 0.12 = Tk 288,000. This agrees with the record. After the discount, the shop would pay 2,400,000 − 288,000 = Tk 2,112,000. Second, we compare the gain with the money put in. The shares cost 10 × 1,000 = Tk 10,000, so 288,000 ÷ 10,000 = 28.8. The expected yearly discount is nearly 29 times the cost of the shares. Third, we compare it with the profit of Tk 750,000 for 2025: 288,000 ÷ 750,000 = 0.384, which is 38 per cent when rounded to a whole number.

> The risk and the control of the shop come from the form, not from the figures.

Fourth, we turn to risk and control. If the cooperative is registered with limited liability, the most the shop can lose on the shares is Tk 10,000, since a member's loss is limited to the money paid for shares. This is very much smaller than the possible gain. On control, the shop would hold one vote among twenty-two members, as each member has one vote, though it holds 10 shares. The shop could not outvote the other shops, and it could not be outvoted by shops that hold more shares.

> The conclusion weighs the gain, the risk and the limits of the record.

*Conclusion.* On the figures given, the proposal offers a large expected gain for a small sum at risk, and the shop keeps an equal voice. The record states that the discount is expected, not certain. It does not state who would manage the cooperative, how the surplus would be shared or whether the shop would be required to buy all its paper through it. These facts should be known before the shop joins.

> The check repeats the arithmetic from the other direction.

*Check.* Divide the discount by the purchases: 288,000 ÷ 2,400,000 = 0.12, which is the rate in the record. Add the discount to the new payment: 288,000 + 2,112,000 = 2,400,000, which equals the original purchases. The result is sensible, because a 12 per cent saving on a large yearly purchase gives a large yearly sum.

* * *

## Summary

> The summary lists the main ideas of the chapter.

A cooperative society is a business owned and run by members who join to meet a common need, each with one vote. Cooperative principles guide it: open membership, control by members, fair sharing of the surplus and education. Four common kinds are consumer, producer, marketing and credit cooperatives. A society is registered by law, usually gives limited liability, and is governed by a general meeting and a committee. Its merits are fairness and protection for members, and its limits are small money and slow decisions.

## Think It Through

> The questions below change the situation step by step.

Questions 10.t1 and 10.t2 use the case file in the worked section. Questions 10.t3 and 10.t4 change the setting.

:q 10.t1 | Suppose the discount were 9 per cent and not 12 per cent on purchases of Tk 2,400,000. Find the discount in taka, and how many times it exceeds the Tk 10,000 paid for shares.

:q 10.t2 | The shop decides to hold 25 shares of Tk 1,000 and not 10. What is the most it can lose on shares, and how many votes does it have? Explain.

:q 10.t3 | Sixty jute farmers each sell about 400 kg to a trader who offers a low price. Describe how a marketing cooperative could help them, and name one thing that could go wrong.

:q 10.t4 | A cooperative of bakers wishes to borrow a large sum to buy a factory. Which features of the form help, and which limit the plan? What other form might the bakers consider?

## Where People Go Wrong

> Four common mistakes about the cooperative society, each with its correction.

*Mistake.* A cooperative never makes a surplus. *Correction.* A cooperative must cover its costs and usually earns a surplus, which it shares by rule among members instead of paying it to outside owners.

> Votes in a cooperative do not follow money.

*Mistake.* A member with more shares has more votes. *Correction.* Each member has one vote, whatever the number of shares held. This is the main difference from a company.

> Government does not own a cooperative.

*Mistake.* A cooperative is a government business. *Correction.* A cooperative is owned by its members. Government may register it, inspect it or help it, but government is not its owner.

> A cooperative can fail even though it is fair.

*Mistake.* Because every member has an equal voice, a cooperative cannot fail. *Correction.* A cooperative can fail through poor management, shortage of money or members who take no part. Equal votes protect fairness and do not ensure skill.

## In History

> Working people of Rochdale opened a shop in 1844 on rules that became the principles.

In 1844 the town of Rochdale, in Lancashire in England, was full of weavers and other workers made poor by changes in the cloth trade. A group of 28 working people, about half of them weavers, formed the Rochdale Society of Equitable Pioneers. They collected small sums, over a period of months, to rent the ground floor of a warehouse at 31 Toad Lane. On 21 December 1844 they opened a store selling basic goods such as butter, sugar, flour, oatmeal and candles.

> The pioneers wrote rules that gave every member a voice and a share of the gain.

The Pioneers drew up rules that differed from earlier shops. Any customer could become a member and an owner. Each member had one vote. Goods were sold at honest quality for cash, and the gain was returned to members as a dividend in proportion to their purchases. By the end of the first year they had about eighty members. The International Co-operative Alliance, a world body of cooperatives, later adopted principles based on these rules, in 1937 and again in 1995. The case shows that people with little money, by agreeing fair rules, can own a business together.

## Review Questions

> The questions below ask the reader to apply the chapter.

:q 10.1 | Explain cooperative society in your own words and give one example.

:q 10.2 | Compare a cooperative with a company on four points: purpose, voting, return to owners and liability.

:q 10.3 | State three cooperative principles and explain what each protects.

:q 10.4 | Describe the four kinds of cooperative and name one need that each meets.

:q 10.5 | Explain how the members, the general meeting and the committee relate to one another.

:q 10.6 | Explain what a surplus is and describe two ways in which a cooperative may use it.
