:answers 06
:a 6.p1 | For: the business depends on society and affects it, and responsible conduct builds goodwill. Against: the duty of a business is profit within the law, and spending the owners' money on social aims is not the manager's choice.
:a 6.t1 | 38 − 30 = 8 days late. 8 ÷ 30 = 0.27 of the agreed time (about 27 per cent).
:a 6.t2 | 150,000 ÷ 750,000 = 0.20, or 20 per cent of the profit. No. A gift alone does not show responsibility, because honest dealing, prompt payment and safe goods matter more than gifts.
:a 6.t3 | The supplier must wait for money it has earned and may have to borrow to pay its own staff, which harms its survival. It may raise the matter, ask for firm payment dates or seek other customers. The customer should pay on the agreed date or agree new terms in advance.
:a 6.t4 | Affected: people downstream (the community), consumers of the river's water and fish, and later generations. Duties involved: care with waste and sustainability. A responsible firm would treat its waste even though the law is weak and accept the extra cost.
:a 6.1 | Social responsibility is a business's duty to act in ways that benefit society as well as its owners. Example: a factory that treats its waste water before returning it to a river.
:a 6.2 | Prompt payment: suppliers. Honest accounts: owners and lenders. A safe workplace: employees. Truthful labels: consumers. Care with waste water: the community.
:a 6.3 | For: the business depends on society and affects it; responsible conduct builds goodwill and survival. Against: profit within the law is the owners' aim; a manager should not spend the owners' money on social aims; governments, not businesses, care for society.
:a 6.4 | The customer buys; the consumer uses. A father who buys milk is the customer, and the child who drinks it is the consumer.
:a 6.5 | Sustainability is running a business so that it meets today's needs without harming later generations' ability to meet theirs. Example: a paper maker that cuts trees without replanting.
:a 6.6 | The supplier delivered first and must wait for money it has earned, so late payment is borrowing without permission; it also damages trust, even where the law is silent.
