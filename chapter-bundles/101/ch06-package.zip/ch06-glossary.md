:glossary 06
Social responsibility | A business's duty to act in ways that benefit society as well as its owners. The duty includes honest dealing, safe goods and care with waste. Example: a factory that treats its waste water before returning it to a river.
Sustainability | Running a business so that it meets today's needs without harming the ability of later generations to meet theirs. Example: a paper maker that plants a tree for each tree it cuts can continue for many years, but one that does not replant may exhaust its supply.
Consumer | A person who uses goods or services, whether or not that person also paid for them. The customer is the person who buys. Example: a father who buys milk is the customer; the child who drinks it is the consumer.
Investor | A person who puts money into a business expecting to receive a return, such as a share of profit or interest. Example: a person who buys a share in a company, or a bank that lends money to a shop.
