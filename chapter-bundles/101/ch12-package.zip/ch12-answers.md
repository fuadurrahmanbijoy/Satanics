:answers 12
:a 12.p1 | No. If Salim's cost of one shirt were also 2 kilograms of rice, both neighbours would pay the same price in rice for a shirt. Neither would have a comparative advantage, so trade would bring no gain.
:a 12.t1 | The tariff is 20 per cent of Tk 10,000, which is Tk 2,000. The new price is Tk 10,000 plus Tk 2,000, which is Tk 12,000.
:a 12.t2 | Before the tariff, the imported bicycle at Tk 10,000 is cheaper than the local one at Tk 11,500. After it, the local bicycle at Tk 11,500 is cheaper than the imported one at Tk 12,000. The government gains tax and the local maker gains sales. The customer loses, because the lowest price rises from Tk 10,000 to Tk 11,500.
:a 12.1 | (a) visible; (b) invisible; (c) visible; (d) invisible; (e) invisible. Goods are visible trade, and services such as hotel stays, freight and bank fees are invisible trade.
:a 12.2 | Balance = 6,000 minus 18,000 = minus 12,000, a deficit of USD 12,000. In taka, 12,000 times 120 = Tk 1,440,000.
:a 12.3 | Balance = 60,000 minus 25,000 = plus 35,000, a surplus of USD 35,000. In taka, 35,000 times 120 = Tk 4,200,000.
:a 12.4 | Price before the tariff: 500 times 120 = Tk 60,000. Tariff: 10 per cent of Tk 60,000 = Tk 6,000. Total: Tk 66,000.
:a 12.5 | An hour of the doctor's time treating patients is worth more than an hour of typing, so she loses less by hiring the assistant. In the same way, two countries each gain by making the goods that cost them least in other goods and trading, even if one country is better at making everything.
