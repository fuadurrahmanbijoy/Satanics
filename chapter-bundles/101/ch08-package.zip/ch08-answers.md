:answers 08
:a 8.p1 | Yes. Under mutual agency each partner is the agent of all the others, so a contract signed in the ordinary course of the business binds every partner, including a partner who did not sign.
:a 8.t1 | Yes. Anwar acted in the ordinary course of the business, and the supplier did not know of the limit. The limit in the deed protects the partners against each other, not against an outsider who did not know of it.
:a 8.t2 | Anwar broke the deed and his duty to act for the common benefit. They may claim that he must bear the loss that his order causes, and they may agree a firmer rule for large orders.
:a 8.t3 | They may tell their regular suppliers of the limit in writing, so that an informed supplier cannot hold them to a larger order. They may also require a second partner to approve every large order.
:a 8.1 | 3 + 2 = 5 parts, and Tk 60,000 ÷ 5 = Tk 12,000 for one part. The first friend receives 3 × Tk 12,000 = Tk 36,000 and the second receives 2 × Tk 12,000 = Tk 24,000. Check: Tk 36,000 + Tk 24,000 = Tk 60,000.
:a 8.2 | They would share equally, Tk 30,000 each. The rule is that partners share profit equally when the deed is silent, whatever capital each has supplied.
:a 8.3 | 4 + 3 + 3 = 10 parts, and Tk 420,000 ÷ 10 = Tk 42,000 for one part. Nurul receives Tk 168,000, Rafiq receives Tk 126,000 and Tariq receives Tk 126,000. Check: the three shares add to Tk 420,000.
:a 8.4 | She would be a sleeping partner. Her liability would be unlimited, because the Partnership Act 1932 of Bangladesh makes no provision for limited partners. Mutual agency still binds her, because the acts of the baker bind all the partners.
