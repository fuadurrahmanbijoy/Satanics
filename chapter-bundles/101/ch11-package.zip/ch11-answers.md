:answers 11
:a 11.p1 | A public corporation. It is a separate body set up by law, with its own managers and accounts. A departmental undertaking is run as part of a government department.
:a 11.t1 | For keeping: the village routes serve people whom a private owner might not serve, and the service is essential. Government can accept a loss for a public aim. For selling: the loss is paid by taxpayers, and a private owner may manage staff and costs more closely.
:a 11.t2 | Government may pay a grant for the village routes only and let the company set fares freely on the busy routes, or it may reduce staff on routes where the work does not need them.
:a 11.t3 | A public corporation, because it has its own board and accounts and does not need ministry permission for each decision. A government company also has freedom, but a departmental undertaking has the least.
:a 11.1 | (a) A sole proprietorship. (b) A state enterprise, as a departmental undertaking or a public corporation. (c) A company, because it can raise large capital from many shareholders. (d) A cooperative society, because the farmers serve their own needs together.
:a 11.2 | The first arrangement is a departmental undertaking. The second is a public corporation.
:a 11.3 | The price difference is Tk 92 − Tk 85 = Tk 7 a bottle. The yearly saving is 2,000 × Tk 7 = Tk 14,000. Check: 2,000 × Tk 85 = Tk 170,000 and 2,000 × Tk 92 = Tk 184,000, a difference of Tk 14,000.
:a 11.4 | A state enterprise, probably a public corporation, suits it. Water is essential, needs large capital and serves everyone at a price that families can pay. One risk is loss from low prices or political orders, which taxpayers would then cover.
