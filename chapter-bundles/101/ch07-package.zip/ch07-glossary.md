:glossary 07
Private sector | The part of an economy owned and run by individuals and private firms rather than by government. A family bakery, a tailor and a privately owned bank belong to it.
Public sector | The part of an economy owned and run by government. A national railway or a government hospital belongs to it. Many countries have both a private sector and a public sector.
Sole proprietorship | A business owned and run by one person, who keeps all profit and bears all losses. The owner may employ staff, but the staff own no part of it. Example: a family bookshop with one founder-owner.
Unlimited liability | A duty on the owner to pay the business's debts from personal wealth if the business cannot pay them. There is no upper limit. Example: a business owes Tk 500,000 and holds Tk 200,000, so the owner must find Tk 300,000.
Trade licence | Official permission from a local authority to carry on a stated trade in a stated place. Example: a bookseller in Dhaka holds a licence naming the trade, books, and the address of the shop, and must renew it each year.
