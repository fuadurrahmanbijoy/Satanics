:answers 07
:a 7.p1 | Tk 300,000. The debt of Tk 800,000 less the Tk 500,000 held by the business leaves Tk 300,000 for the owner to pay from personal wealth.
:a 7.t1 | New total debts: Tk 1,150,000. New ratio: 1,150,000 ÷ 4,100,000 = 0.28 (to two decimal places), assuming capital stays at Tk 4,100,000.
:a 7.t2 | The owner alone bears the loss of Tk 750,000. Unlimited liability adds that if the loss left debts the business could not pay, he would have to pay them from personal wealth.
:a 7.t3 | He must repay the Tk 2,000,000 from personal wealth if the farm cannot, which may mean selling land or savings. Before borrowing he could have borrowed less, saved a reserve, bought insurance for the crop, or chosen a form with limited liability.
:a 7.t4 | Helpful: full control, quick decisions, all profit. Limiting: unlimited liability across five shops, her own time, and the money one person can raise. She might consider other owners or another form, taught in later chapters.
:a 7.1 | Sole proprietorship, partnership, company and cooperative society are in the private sector. State enterprise is in the public sector.
:a 7.2 | Full control, so decisions are quick; all profit, so effort is rewarded; easy and cheap to begin; few legal steps; close contact with customers.
:a 7.3 | Unlimited liability means the owner must pay the business's debts from personal wealth if the business cannot, with no upper limit. Example: a business owes Tk 500,000 but holds Tk 200,000, so the owner finds Tk 300,000.
:a 7.4 | A barber's shop needs little money and personal attention, which one owner can provide. A power station needs very large sums and many skills, which one person cannot provide.
:a 7.5 | A trade licence is official permission from a local authority to carry on a stated trade in a stated place. A shop trading without a current licence may be fined or closed.
:a 7.6 | Mixed money hides the true result of the business, so the owner cannot tell whether it earns a profit.
