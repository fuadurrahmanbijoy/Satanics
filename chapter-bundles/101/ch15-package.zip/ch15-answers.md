:answers 15
:a 15.p1 | Tk 10 is the face value and Tk 15 is the premium. The sale is in the primary market, because the company sells new shares and keeps the money.
:a 15.p2 | The company receives Tk 1,000 in the primary sale of 100 shares. When Rina sells her 10 shares, Rina receives the Tk 120 and the company receives nothing.
:a 15.p3 | The Securities and Exchange Commission, the regulator, investigates the broker. The stock exchange runs the market where the trade took place.
:a 15.t1 | Reasons to list: shares become easy to trade, and the company can raise money from the public. Reason not to list: the company must publish information and follow the exchange's rules.
:a 15.t2 | Tk 20,000 ÷ Tk 400,000 = 5 per cent of profit. The owner should also weigh the information, contacts and voice with the government that membership gives.
:a 15.1 | Regulate: the Securities and Exchange Commission. Trade: the Dhaka Stock Exchange and a stock broker. Promote: the Export Promotion Bureau. Serve: FBCCI.
:a 15.2 | Total: 50,000 × Tk 30 = Tk 1,500,000. Face value part: 50,000 × Tk 10 = Tk 500,000. Premium part: 50,000 × Tk 20 = Tk 1,000,000. It is a sale in the primary market.
:a 15.3 | It is the secondary market. The selling owner receives 1,000 × Tk 35 = Tk 35,000, and the company receives nothing.
:a 15.4 | An export processing zone, where buildings, power and port links are ready and some taxes and duties are reduced; or the Export Promotion Bureau, which gives information on foreign markets and help with fairs.
:a 15.5 | The Securities and Exchange Commission approves the offer; the exchange lists and trades the new shares; stock brokers handle sales for investors; the export processing zone authority gives the site and its benefits.
