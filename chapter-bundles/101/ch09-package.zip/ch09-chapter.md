:chapter IX | The Joint Stock Company
:mood Can a business live on after its owners are gone?
:desc A company is a business that the law treats as a person of its own, owned by shareholders who risk only the money they invest. This chapter explains what a company is, how private and public companies differ, and how a company is formed. It ends by asking when the company is the right form, using the running case of Meghna and Sons.
:plate ch09-plate.svg | A stock exchange floor in the Victorian age, with brokers in top hats

> You will need: Chapter 8 'The Partnership', section 8.4 'Partnership Compared with Sole Proprietorship', and section 8.3 'Rights, Duties and Dissolution'.
> A partnership suffers when a partner leaves, and each partner risks all personal wealth.

Think of a bookshop run by three partners. One partner is tired and wishes to leave, and she asks for her money back. The other two must find that money quickly, or the shop must close. Meanwhile, a supplier who never met her can demand payment from her house and her savings, although she no longer works in the shop. A partnership solves many problems, but it leaves two untouched: it is hurt when its members change, and its members risk everything they own.

> Four questions about a business that outlives its owners.

Now ask four stranger questions. Could a business continue to exist after all its owners have died? Could it own a building, sign a contract and be taken to court in its own name, as a person can? Could an owner leave by selling a part of the business to someone else, without disturbing the business at all? And could an owner lose only the money contributed, and never one taka more? Most students answer no to the first question. Every answer is yes, and the form of business that gives all four is called the company.

> The chapter moves from meaning, to kinds, to formation, to judgement.

This chapter explains how that is possible. We begin with what a company is and why the law allows it. We then separate the two kinds of company, private and public, and follow the steps that bring one into existence. We end by asking whether the company is the best form, because it is not always the best. Many students find the idea of a business that is a person difficult at first, since we usually think of a person as someone who can walk and speak. The chapter builds the idea in small steps, and each section ends with a short recap.

* * *

## What a Company Is

> Equal parts let many people fairly pool money.

Imagine ten neighbours who wish to build a rice mill. The mill costs more than any one neighbour can pay, so each contributes money: one gives a large amount, another a small amount. The mill is built and begins to earn a profit. Now the neighbours face a question of fairness. How should the profit be divided, and what happens when one neighbour wishes to leave? A fair method is to divide the total money of the mill into equal parts, and to give each neighbour as many parts as the money that neighbour contributed.

> A company is a business whose money is divided into equal parts.
@ Stock | Word in use. In daily life, the goods a shop holds for sale, such as the books on a shelf. In the name "joint stock company", an old word for the money of the business, divided into parts.
@ Joint stock company | A business whose capital is divided into equal parts, owned by many people, and treated by law as a person.

The mill of the neighbours shows the idea behind a **joint stock company**, which means a business whose money is divided into equal parts, owned by many people, and treated by the law as a person of its own. For example, a bakery owned by two hundred people, each holding some of its equal parts, is a company. People also say corporation. This book uses the one word company.^1 Note the word stock: in a shop it means goods for sale, but in this name it is an old word for the money of the business.

^1: In the United States and some other countries, the word corporation is more common than company for this form of business.

> The law gives a company a personality of its own, apart from its owners.

The most important idea in this chapter is that the law treats the company as a person of its own, called a separate legal person. This is a legal fact, not a physical one: the company has no body, but the law gives it rights and duties, as it does to a human being. The company is therefore different from the people who own it, and different from the people who work in it. Think again of the bookshop in the opening. If it were a company, the shop would be one person, the three owners would be three other persons, and the law would keep the four apart.

> Separateness lets the company own, contract, sue and continue.

Four results follow from this separateness. The company can own property in its own name, so the building belongs to the company and not to any owner. It can make contracts and borrow money in its own name. It can sue others and be sued in a court. And it continues to exist when an owner dies, leaves or sells, because a person made by law has no age and no natural death. A company ends only when the law, or its owners by a formal process, bring it to an end.

:pause 9.p1 | In the opening, the leaving partner could demand her money and the shop could be forced to close. In a company, what happens to the business when an owner leaves?

> Recall: why partnerships struggle with change, Chapter 8, 'The Partnership', section 8.3 'Rights, Duties and Dissolution'.
> A partnership is not a person apart from its partners; a company is.

Compare this with the partnership of Chapter 8. A partnership has no existence apart from its partners, so a change in the partners can end it or force it to change. A company has no such weakness, because its owners are not its body. An owner of a company holds a claim on it, not the company itself. The owner can sell that claim to another person, and the business continues exactly as before, with the same building, the same contracts and the same staff.

> Recall: partner liability for debts, Chapter 8, 'The Partnership', section 8.4 'Partnership Compared with Sole Proprietorship'.
> Limited liability caps an owner's loss at the money contributed.
@ Limited liability | A rule that owners of a company lose, at most, the money they paid for their parts, never their personal wealth.

The second great idea follows from the first. Because the company is a separate person, the debts of the company are the debts of the company, and not of its owners. **Limited liability** means a rule that owners of a company lose, at most, the money they paid for their parts of it, and never their personal wealth. Suppose a company fails and owes a supplier more than it has. The supplier cannot take the owners' houses; the owners lose what they paid, and nothing more. In a partnership, by contrast, each partner may be asked to pay the debts from personal wealth.

> Limited liability has limits: guarantees, fraud and unpaid amounts.

The rule has exceptions, and a careful reader should know them. A bank often lends to a small company only if the owners sign a personal guarantee, which is a written promise to repay if the company cannot. An owner who signs it has chosen to accept that debt personally. The law may also remove protection from owners who use the company to commit fraud. And an owner who has not yet paid for the parts that were promised must still pay that amount. The rule protects honest owners from the ordinary risk of business; it does not protect them from their own promises or from wrongdoing.

> A share is one equal part of a company.
@ Share | One equal part of a company's capital, giving its holder a claim on profit and a voice in decisions.
@ Share | Word in use. In daily life, a portion of something divided among people, such as a share of food. In a company, a measured part of the capital, with a claim on profit.

The equal parts of the mill have a name. A **share** is one equal part of a company's capital, which gives its holder a claim on profit and a voice in decisions. A person who holds shares is a shareholder. Suppose a company divides its capital into 1,000 shares of Tk 100 each, so the capital is Tk 100,000. A person who holds 100 of those shares owns one tenth of the company and receives one tenth of any profit that the company decides to distribute. Shareholders usually vote on major decisions, and each share normally carries one vote.

> The case file divides capital into shares of Tk 10.

:case Case file, illustrative. On 15 September 2026, a proposal was made to convert Meghna and Sons into Meghna and Sons Limited. The authorised capital would be Tk 10,000,000, divided into 1,000,000 shares of Tk 10 each. The proposal would issue 410,000 shares to the partners in return for their existing capital: 250,000 to Nurul, 100,000 to Rafiq and 60,000 to Tariq, a total value of Tk 4,100,000.

> Authorised capital is a ceiling; only part of it is issued.

The case file uses two phrases that need a plain meaning. Authorised capital is the largest amount of capital that the founding documents allow the company to raise through shares. To issue shares means to create them and give them to holders in return for money or property. In the case file the ceiling is 1,000,000 shares, but only 410,000 would be issued at first, so 590,000 remain available for later. Section 9.3 'Forming a Company' returns to the founding documents.

:box IN SHORT
A company is a separate legal person, with capital divided into shares, and with owners whose loss is limited to the money they paid.

> Before moving on: the four ideas of the section in one place.

*Before moving on.* A company is a business whose capital is divided into equal parts, called shares. The law treats it as a separate legal person, so it owns property, makes contracts and continues when owners change. Limited liability protects owners from the debts of the company, with a few exceptions, such as personal guarantees and fraud.

* * *

## Private and Public Companies

> Companies differ in who may buy their shares.

Not every company wishes to sell shares to strangers. A family of bakers may want limited liability and a business that continues, yet wish to keep control among a few trusted people. A large railway or bank, by contrast, may need so much money that it must ask thousands of people to contribute. The law therefore provides two kinds of company, and the difference between them is about who may buy the shares.

> A private company keeps its shares among a few chosen owners.
@ Private limited company | A company that restricts transfer of its shares and cannot invite the public to buy them.

A **private limited company** means a company that restricts the transfer of its shares and cannot invite the public to buy them. To restrict transfer means that an owner may not sell shares to an outsider without following the company's rules, which usually require the agreement of the others. For example, three partners who convert their business into a company, and who agree that no one may sell shares to an outsider without the others' consent, have formed a private limited company.

> A public company may ask the public to buy its shares.
@ Public limited company | A company that may invite the public to buy its shares, which are often traded on a stock exchange.

A **public limited company** means a company that may invite the public to buy its shares, and whose shares are often traded on a stock exchange. A stock exchange is a market in which shares are bought and sold under rules, through licensed dealers called brokers. A person who owns shares in a public company can usually sell them to another person on the exchange, on any working day, without asking the company for permission.

> Limited in a name warns the reader about the owners' protection.
@ Limited | Word in use. In daily life, restricted or small, as in "limited time". In a company's name, it means that the owners' loss is limited to the money they paid.

Both kinds of company carry the word limited in their names. The word has an everyday meaning of small or restricted, but here it has a legal meaning: it tells every customer, supplier and lender that the owners are protected by limited liability, and that only the company's own wealth stands behind its debts. In Bangladesh, the name of a private company ends with Private Limited, and the name of a public company ends with Limited.

> The companies differ in five features, shown in a table.

The two kinds differ in several features. The table that follows compares them. Read each row from left to right: the first column names a feature, and the next two columns say what is true of a private company and of a public company. The numbers follow the law of Bangladesh, where the Companies Act 1994 sets the rules; other countries use different numbers.^2

^2: Rules differ by country. The numbers in the table follow the law of Bangladesh at the time of writing. A reader who needs exact rules should read the current Act.

:table Private and public limited companies compared (Bangladesh)
| Feature | Private limited company | Public limited company |
| Number of members | At least 2, at most 50 | At least 7, no upper limit |
| Transfer of shares | Restricted by its rules | Free, in general |
| Invitation to the public | Not allowed | Allowed, by prospectus |
| Stock exchange | Shares not traded | Shares may be traded |
| Name ends with | Private Limited | Limited |

> The figure shows few owners against many, and a closed ring against an open one.

The figure that follows draws the same difference as two circles. Each small circle inside a larger circle stands for one owner. In the private company the owners are few, and a dashed ring around them marks that outsiders may not buy. In the public company the owners are many, and arrows from outside show that the public may buy shares.

:fig A private company and a public company, drawn as two ownership circles | ch09-fig02.svg

> A private company gains control and privacy; a public company gains money and easy exit.

Each kind has merits and demerits. The private company keeps control among a few trusted owners, has fewer rules, and need not offer its affairs to public view. Its demerit is that it can raise money only from a small circle of people. The public company can raise large sums from thousands of people, and its owners can leave by selling shares to others. Its demerits are heavier rules, more public information about its affairs, and the risk that the original owners lose control as shares pass to many hands.

> Owners, employees and customers see the two kinds differently.

The viewpoint of each person changes the judgement. An owner of a private company values control, and an owner of a public company values the ease of selling. An employee may find a large public company secure but distant, and a small private company personal but fragile. A customer rarely notices the difference, but a lender will read the kind of company before deciding how much to trust it.

> Before moving on: private against public, in one paragraph.

*Before moving on.* A private limited company restricts the transfer of its shares and cannot invite the public to buy them. A public limited company may invite the public, and its shares are often traded on a stock exchange. Both carry limited in their names. The public kind gains money and an easy exit for owners, but it accepts more rules and a greater risk of losing control.

* * *

## Forming a Company

> A company needs steps and documents, unlike a partnership.

Suppose the three partners of Meghna and Sons decide to form a company. They cannot do it by agreement among themselves alone, as partners can form a partnership by a deed. The law requires a sequence of steps and documents, and each step has a purpose. The figure that follows shows the sequence as a flow of five boxes. Read it from the first box to the last; a box with a dashed outline applies only to a public company.

:fig Five steps from idea to commencement of business | ch09-fig01.svg

> Promoters are the people who start the work of forming the company.

The first step belongs to the promoters, the people who conceive the idea and begin the work of forming the company. They choose the name, find the first money, prepare the documents and pay the early costs. In the case file, the three partners would act as promoters. Promoters are not owners of the company by that fact alone; they become owners only when they take shares.

> The memorandum states what the company is, in outline.
@ Memorandum of association | The founding document stating a company's name, objects, registered office, liability and share capital.

The second step is to write two founding documents. The **memorandum of association** is the founding document that states a company's name, objects, registered office, liability and share capital. The objects are the purposes for which the company exists, and the registered office is its official address. The liability clause says that the owners' liability is limited. The share capital clause states the authorised capital, which in the case file is Tk 10,000,000.

> The articles state how the company is run inside.
@ Articles of association | The document setting the company's internal rules, such as duties of directors and meetings.

The **articles of association** are the document that sets the company's internal rules, such as the duties of directors and the holding of meetings. Directors are the persons chosen to direct the affairs of the company. A private company uses its articles to restrict the transfer of shares. The memorandum is therefore about the company's outer relations with the world, and the articles are about its inner life.

> Registration gives the company its legal existence.

The third step is registration. The promoters send both documents, with fees, to a public official called the Registrar, who in Bangladesh is the Registrar of Joint Stock Companies and Firms. If the documents satisfy the law, the Registrar issues a certificate of incorporation, which is a document that proves the company exists. From the date of that certificate the company is a separate legal person. A private company may now begin business.

> A prospectus invites the public to buy shares or debentures.
@ Prospectus | A published invitation to the public to buy shares or debentures, describing the company and the risks.

A public company that wishes to raise money from the public takes a fourth step. A **prospectus** means a published invitation to the public to buy shares or debentures, which describes the company and its risks. A debenture is a loan to the company, recorded in a certificate. A prospectus usually states the name and objects of the company, its directors, the number and price of the shares offered, the use of the money, the risks, and how to apply.^3

^3: In Bangladesh, public offers of shares are also regulated by the Bangladesh Securities and Exchange Commission, which examines the offer before it reaches the public.

> The certificate of commencement lets a public company begin business.

The fifth step applies to the public company only. After the public has subscribed for shares, the company applies for a certificate of commencement, a document that allows a public company to begin business once the Registrar is satisfied that the legal conditions are met. These conditions include that a minimum number of shares has been taken by the public. Only then may the company begin its business and use the money raised.

> Before moving on: the five steps in one paragraph.

*Before moving on.* Promoters conceive the company and prepare the memorandum and the articles. The Registrar registers the company and issues a certificate of incorporation. A public company then issues a prospectus, collects the money for shares, and obtains a certificate of commencement. A private company may begin business after registration.

* * *

## Is the Company the Best Form?

> Each form of business has a price as well as a benefit.

The company offers limited liability, a continuing life, large amounts of money and shares that can be sold. These are real advantages, but each has a price. Registration needs fees and documents. A company must keep proper accounts, file reports with the Registrar, and obey rules about meetings. A public company must also publish more information. A small shop owner who needs none of the four advantages may reasonably remain a sole proprietor or a partner, and that choice is not a failure of ambition.

> Directors manage the company on behalf of the owners.

A company with hundreds of shareholders cannot be managed by all of them together. The shareholders therefore choose directors, who direct the affairs of the company and appoint managers for daily work. This is management by directors. The shareholders keep the right to vote on major matters and to choose or remove directors at meetings, usually held once each year.

> Owners and controllers may be different people with different aims.

In a large company the owners, who are the shareholders, are not the same people as the controllers, who are the directors and managers. This is the separation of ownership and control. It brings skill, because experts may manage, but it brings a risk: controllers may serve their own interests instead of the owners'. Meetings, published accounts and independent checks of the accounts reduce this risk. In a small family company the same persons are owners and controllers, and the separation is slight.

> Before moving on: the company's price and the separation.

*Before moving on.* The company is not the best form for every business, because its advantages carry costs in money, effort and public information. Directors manage on behalf of the shareholders, so ownership and control may be separate, and rules of meeting and accounting exist to protect the owners.

* * *

## Worked Case: Dividing the Capital of Meghna and Sons Limited

> The worked case follows the order Situation, Question, Reasoning, Conclusion, Check.

This section applies the ideas of the chapter to the running case. We follow five parts in order: the situation, the question, the reasoning, the conclusion and a check. The aim is to see how the ideas work on real figures; it is not a model answer to any question.

> The situation restates the case file in full.

:case Case file, illustrative. *Situation.* The proposal of 15 September 2026 would convert Meghna and Sons into Meghna and Sons Limited, with authorised capital of Tk 10,000,000 in 1,000,000 shares of Tk 10. It would issue 410,000 shares to the partners for their existing capital: Nurul 250,000, Rafiq 100,000 and Tariq 60,000 shares, a total value of Tk 4,100,000.

> The question asks what each partner would hold, and what it means.

*Question.* What is each partner's holding worth, what fraction of the issued shares does each hold, and what does this mean for control and for risk?

> Reasoning step one: the value of each holding is shares times Tk 10.

*Reasoning.* We begin with value. Each share has a value of Tk 10, so we multiply the number of shares by Tk 10. Nurul: 250,000 × Tk 10 = Tk 2,500,000. Rafiq: 100,000 × Tk 10 = Tk 1,000,000. Tariq: 60,000 × Tk 10 = Tk 600,000. The three values together are Tk 2,500,000 + Tk 1,000,000 + Tk 600,000 = Tk 4,100,000, which agrees with the case file.

> Reasoning step two: each fraction is the holding divided by 410,000.

Next we find each fraction of the issued shares, 410,000 in all. Nurul: 250,000 ÷ 410,000 is about 61.0 per cent. Rafiq: 100,000 ÷ 410,000 is about 24.4 per cent. Tariq: 60,000 ÷ 410,000 is about 14.6 per cent. The three fractions add to 100 per cent. The issued shares are 410,000 of the 1,000,000 authorised, which is 41 per cent, and 590,000 shares, with a value of Tk 5,900,000, remain unissued.

> Reasoning step three: the fractions show control, and limited liability shows risk.

Now we read the figures. Nurul holds more than half of the issued shares, so if each share carries one vote, Nurul alone could carry an ordinary vote at a meeting; Rafiq and Tariq together hold about 39.0 per cent. As for risk, each partner would lose at most the money paid for the shares, and not personal wealth, if the company failed. The case file does not say which kind of company is intended. Three owners with no plan to invite the public fit a private limited company.

> Conclusion and check: the figures agree, and the form fits.

*Conclusion.* The partners would hold shares worth Tk 2,500,000, Tk 1,000,000 and Tk 600,000, with about 61.0, 24.4 and 14.6 per cent of the issued shares. Their loss would be limited, and the company would continue if one of them left. *Check.* 410,000 + 590,000 = 1,000,000 shares, and Tk 4,100,000 + Tk 5,900,000 = Tk 10,000,000, which is the authorised capital. The check passes.

* * *

## Summary

> Summary of the chapter in a few lines.

A company is a business whose capital is divided into shares and which the law treats as a separate legal person. This gives it a continuing life, the power to own and contract, and limited liability for its owners. A private limited company restricts the transfer of its shares and cannot invite the public; a public limited company may invite the public, and its shares may be traded on a stock exchange. A company is formed by promoters, who prepare a memorandum and articles of association, register the company, and, for a public company, issue a prospectus and obtain a certificate of commencement. The company is not always the best form, because it costs money and effort, and because ownership and control may separate.

## Think It Through

:q 9.t1 | Two sisters run a bakery as a partnership with six staff. They want to borrow money from a bank and to expand to a second shop. List one reason for and one reason against converting the bakery into a company, using limited liability in both.
:q 9.t2 | Should the bakery become a private limited company or a public limited company? Give your reasoning in four sentences.

## Where People Go Wrong

> Limited liability does not mean the company never pays its debts.

Many students believe that limited liability means a company does not have to pay its debts. This is wrong. The company must pay its debts from its own wealth. Limited liability only means that the owners are not forced to pay them from their personal wealth, apart from the exceptions in this chapter.

> A shareholder owns shares, not the company's property.

Another common error is to say that a shareholder owns the shop, the stock and the building. The company owns these, because the company is a separate legal person. The shareholder owns shares, which are claims on profit and votes in decisions.

> A company can be small, and a private company is not owned by the state.

A third error is to think that every company is large, or that a public company is owned by the government. A company may have two owners and a single shop. A public limited company is public because it may invite the public to buy shares, and not because the state owns it.

## In History

> The Dutch East India Company shows why shares for many investors were invented.

In 1602 merchants of the Dutch Republic formed the Vereenigde Oostindische Compagnie, known in English as the Dutch East India Company, and in short as the VOC. Voyages to Asia were costly and dangerous, and a single lost ship could ruin one merchant. The founding charter allowed the residents of the Republic to buy shares, with no fixed upper or lower amount, and the first public sale of shares took place in August 1602. Many investors therefore held small parts of the risk, and the company is often described as the first whose shares were openly traded and held by many investors.

> Selling shares in Amsterdam let investors leave without ending the company.

Investors in the VOC could leave the company without waiting for the ships to return. They sold their shares to others in Amsterdam, where buyers and sellers soon gathered to trade, and in 1611 a building for this trade was opened in the city. The voyages and the company continued while the owners of the shares changed. This is the same idea that this chapter described: a business that continues, with parts that owners can sell.

## Review Questions

:q 9.1 | State two ways in which a company differs from a partnership, and explain each in one sentence.
:q 9.2 | Company A has five owners, who may sell shares only with the agreement of the others. Company B invites the public to buy its shares, and its shares are traded on a stock exchange. Compare the two companies in three features.
:q 9.3 | A new public company prepares to invite the public to buy shares. List five things that its prospectus should tell the public.
:q 9.4 | A family partnership of five members wishes to bring in many small investors from the neighbourhood. Name the kind of company that suits it, and list the documents and steps it needs, in order.
:q 9.5 | Explain the separation of ownership and control, and give one way in which it may be reduced.

:read Joseph de la Vega, Confusion of Confusions, 1688
:read Paul Frentrop, A History of Corporate Governance, 1602-2002, 2003
