:answers 09
:a 9.p1 | The business continues unchanged. The owner sells or gives up the shares, and the company, as a separate legal person, keeps its building, contracts and staff.
:a 9.t1 | For: limited liability protects the sisters' homes if the bank loan cannot be repaid. Against: a bank may still ask them for personal guarantees, so the protection may be weaker than it seems.
:a 9.t2 | A private limited company suits two owners who want control and no public offer. It limits their loss and keeps control with them. A public company would add costs and rules. They could change later if they need much more money.
:a 9.1 | A company is a separate legal person, so it continues when owners change, but a partnership has no existence apart from its partners. A company limits owners' loss to the money they paid; each partner may have to pay debts from personal wealth.
:a 9.2 | Company A is private: few owners, restricted transfer of shares, no invitation to the public. Company B is public: many owners, free transfer of shares, an open invitation to the public, and trading on a stock exchange.
:a 9.3 | Any five of: the name and objects, the directors, the number and price of the shares offered, the use of the money, the risks, how to apply.
:a 9.4 | A public limited company. Steps in order: promoters form the plan; write the memorandum and articles; register and obtain the certificate of incorporation; issue the prospectus and collect share money; obtain the certificate of commencement.
:a 9.5 | Owners (shareholders) and controllers (directors and managers) may be different people with different aims. Meetings, published accounts and independent checks of the accounts reduce the risk.
