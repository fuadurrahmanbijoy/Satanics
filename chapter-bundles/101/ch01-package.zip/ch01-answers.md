:answers 01
:a 1.p1 | The café. The definition asks for goods or services provided to others in exchange for money, and the café is paid by strangers; the neighbour provides lunch only to her own family and receives no money.
:a 1.p2 | An aid to trade, because it carries goods for shops and does not buy, sell or make them. As an aid to trade it belongs to commerce.
:a 1.t1 | Before: the tailor makes shirts, which is manufacturing industry, and sells them, which is trade. After: the tailor also buys ready-made shirts and sells them in a second shop, so trade grows. The factory that supplies the shirts is manufacturing industry, and transport, banking and insurance may be needed as aids to trade.
:a 1.t2 | Yes. The definition says aiming to earn a profit, not always earning one. A bakery that sells bread to customers for money and aimed at profit is a business, although this year it has a loss.
:a 1.1 | Trade, which is part of commerce. The aids to trade used were banking (the bank), transport (the courier) and insurance.
:a 1.2 | (a) Industry, extractive. (b) Trade. (c) An aid to trade (transport). (d) Industry, manufacturing. (e) An aid to trade (banking). Items (b), (c) and (e) belong to commerce, because commerce is trade together with its aids.
:a 1.3 | It would enter manufacturing industry, because printing notebooks makes finished goods. It would still be in trade as well, because it would continue to buy and sell books and stationery.
:a 1.4 | Example answer: a mobile phone is a good, and repairing the phone is a service. A good is a physical thing the customer owns afterwards; a service is work done for the customer, and no physical thing remains to own.
:a 1.5 | Likely aids: transport, to bring vegetables from farm to market (removes distance); banking, to hold the stall's money (removes risky handling of money); insurance, if the stall insures its stock (removes risk of loss). Advertising and warehousing may also apply.
:a 1.6 | Income = 50 × Tk 25 = Tk 1,250. Costs = 50 × Tk 20 + Tk 100 = Tk 1,000 + Tk 100 = Tk 1,100. Profit = Tk 1,250 − Tk 1,100 = Tk 150.
:a 1.7 | Growing cotton: extractive industry. Spinning, weaving and sewing: manufacturing industry. Selling the shirt in a shop: trade. Aids to trade could be transport (carrying shirts), banking (payments), insurance (stock) or advertising.
:a 1.8 | Any four of: exchange for money, regular dealing, aim of profit, risk, satisfying customers' needs. Risk is a characteristic because profit is not certain, and a business can make a loss.
