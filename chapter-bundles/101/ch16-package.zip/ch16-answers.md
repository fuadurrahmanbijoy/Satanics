:answers 16
:a 16.p1 | A cartel. The sellers agree on a price but each keeps their own stall, so they stay independent; nothing is bought or merged.
:a 16.t1 | Vertical. The mill and the bakery stand at different stages of one product, flour and bread, so joining them is vertical, toward the source.
:a 16.t2 | Opportunity: a secure supply of flour. Threat to the baker: being tied to her own mill when another is cheaper. Threat to the other bakers: the mill may refuse them flour or raise the price.
:a 16.1 | Horizontal. Both bakeries stand at the same stage, making and selling bread, so they were competitors.
:a 16.2 | Vertical, moving toward the source. Opportunity: a secure supply of paper. Threat: being tied to its own mill even when another is cheaper.
:a 16.3 | A cartel. Each owner stays independent and no mill is bought, while in a merger one company absorbs another and only one remains.
:a 16.4 | A takeover. The buyer controls the main decisions of the second company, which continues to exist; a buyer that holds shares in several companies in this way acts as a holding company.
:a 16.5 | Lower cost appears in the Tk 360,000 yearly rent saving. The payment of the price of Tk 1,800,000, and whether the customers and staff of Padma Stationers would stay, need more facts.
