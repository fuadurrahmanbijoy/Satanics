:chapter XIII | Export and Import Procedure
:mood Who trusts whom, when two strangers trade across a border?
:desc Trade between countries needs more than goods and money. It needs a chain of steps and papers that protect a seller and a customer who have never met. This chapter follows an export from order to payment, an import from registration to release at the border, and the papers that travel with the goods. It ends with the barriers that block exporters and the ways Bangladesh promotes exports.
:plate ch13-plate.svg | A customs house clerk stamping papers beside crates on a dockside

> You will need: Chapter 12 'Foreign Trade', section 12.2 'Measuring Foreign Trade', and section 12.3 'Regulating Trade'.
> Trade measures and the rules of trade from Chapter 12 are the background of this chapter.

A bookseller in Dhaka receives a letter from a stranger in Kolkata. The stranger wishes to buy 150 books in Bangla and asks for a price. The two people have never met, they live in different countries, and each must act first. The bookseller fears sending the books and then waiting for money that never arrives. The stranger fears sending the money and then waiting for books that never arrive. If each waits for the other, no trade takes place.

> Strangers in two countries need a way to share the risk.

Who should go first? Neither person should have to trust the other, and that is the puzzle of this chapter. The answer is a fixed procedure, built over many centuries, in which banks, shipping lines and government offices stand between the two strangers and each confirm one small fact. A bank confirms that money will be paid. A shipping line confirms that goods were loaded. A customs office confirms that the law was obeyed. The procedure has many steps and many papers, and many students find the number of papers confusing at first. We therefore take the steps one at a time, and we use one running case to show how they fit together.

> The chapter follows export, then import, then the papers, then barriers.

We begin with the export side, where the bookseller sells. We then turn to the import side, where a business buys from abroad. We study the papers that move with the goods, and we end with the barriers that block exporters and the ways Bangladesh helps them. The terms Foreign trade, Export and Import come from Chapter 12 and we use them without defining them again.

* * *

## Export Procedure

> Export procedure is a chain of steps that spreads the risk between two strangers.

Export procedure means the steps that a seller follows to send goods to a customer in another country and to receive payment. In this book the person who buys is called the customer; other books use the words buyer or client for the same person. The chain has four main parts: the order and contract, the letter of credit, shipping and clearing, and payment. The figure that follows shows the chain as a flow of six boxes. Read it from the top box to the bottom box; each arrow means that the next step may begin only when the previous step is complete.

:fig Six steps of an export, from order to payment | ch13-fig01.svg

> The order and contract fix the terms before any money or goods move.

The first part is the export order and contract. An *export order* is a customer's request to buy goods, and it becomes a contract when the seller accepts it. A contract is a promise that the law will enforce. The contract should state the goods, the quantity, the price, the currency, the date of delivery, who pays the cost of transport and insurance, and the method of payment. A missing term causes disputes later. For example, if the contract names a price but not the currency, the two sides may argue whether the price is in taka or in dollars.

> Recall: how trade is counted, Chapter 12, 'Foreign Trade', section 12.2 'Measuring Foreign Trade'.
> An exporter must be registered, and the goods must be allowed to leave.

Before the contract is signed, the seller must be allowed to export. In Bangladesh an exporter is expected to hold a trade licence and to be registered with the government office that controls exports and imports.^1 The law also bans or limits the export of certain goods. A business therefore checks, before it accepts an order, that its goods are allowed to leave the country. The check costs little, and a refusal at the port costs a great deal.

^1: In Bangladesh the registration is an export registration certificate, issued under the control of the Chief Controller of Imports and Exports. Names, fees and rules change over time, so a reader who needs the current rule should ask the issuing office.

> A letter of credit is a bank's promise to pay when stated papers are shown.
@ Letter of credit | A bank's written promise to pay an exporter on the customer's behalf once stated documents are presented.
@ Document | Word in use. In daily life, any written or printed paper. In trade, a paper with a fixed form, such as an invoice, that proves a fact about a shipment.

The second part solves the puzzle of the opening. A **letter of credit** means a bank's written promise to pay an exporter on the customer's behalf once stated documents are presented. The customer asks its own bank to issue the letter; the bank lists the papers that the exporter must show, and agrees to pay when those papers arrive. For example, the Kolkata customer asks a bank in Kolkata to promise payment to the Dhaka bookseller. The bookseller no longer needs to trust a stranger, because the bookseller trusts a bank.

> The bank pays against papers, and the papers must match the credit exactly.

The rule of the letter of credit is strict: the bank pays only if the papers match the letter in every stated detail. The bank examines papers and not goods. A bank clerk in Dhaka cannot open the crates to count the books. This is the exception that surprises many students. A paper with a wrong date, a misspelt name or a quantity that differs from the letter gives the bank a reason to refuse payment, even when the goods are perfect. Exporters therefore read the letter carefully before they begin to pack.

:pause 13.p1 | The bookseller holds a letter of credit but has not yet shipped the books. What risk has the letter removed, and what risk remains?

> Shipping and clearing move the goods out of the country with the right papers.

The third part is shipping and clearing. The exporter packs the goods, marks the packages, and arranges transport with a shipping line, an airline or a road carrier. The carrier gives a receipt for the goods, which is a paper called a bill of lading; Section 13.3 'Documents of Foreign Trade' teaches it in full. The exporter also prepares the seller's bill for the shipment, called an invoice, which the same section teaches. Many exporters hire a clearing and forwarding agent, a business whose work is to deal with the port, the carrier and the customs office on the exporter's behalf.

> Goods leave only after the border office has examined them.

Before the goods leave, an official at the border examines them and checks the papers. The official wishes to know that the goods are the goods described, that any tax is paid and that no rule is broken. This official checking of goods at a border is taught as customs clearance in Section 13.2 'Import Procedure', where it is more complex. The exporter may also insure the shipment, so that an insurer pays for a loss at sea.

> Payment comes last, when the bank accepts the papers.

The fourth part is payment. After shipment the exporter gathers the papers that the letter lists and takes them to its own bank within the time that the letter allows. The bank compares each paper with the letter. If every detail matches, the bank sends the papers to the customer's bank and receives payment, which it then passes to the exporter. If one detail fails, the bank may refuse, and the exporter must correct the paper before the time expires. A refusal is a delay, and a delay of a few days can cost a sale.

> The risk is shared among banks, carriers and officials.

Consider the situation from each viewpoint. The exporter wants payment with little risk of refusal. The customer wants to be sure that goods of the right kind arrive. The banks want to earn a fee and to avoid paying for a faulty set of papers. The procedure gives each person a fair share of safety, and the cost is time and paperwork.

> Before moving on: the export chain in one paragraph.

*Before moving on.* An export begins with an order and a contract, and the exporter must hold the right registration. A letter of credit then gives the exporter a bank's promise to pay when stated papers are shown. The goods are packed, shipped and cleared at the border. The exporter shows the papers to the bank, and the bank pays only if they match the letter exactly.

* * *

## Import Procedure

> Import procedure is the mirror of export, followed by the business that buys.

Import procedure is the set of steps that a business follows to buy goods from a supplier in another country and to receive them. It mirrors the export procedure, because every export from one country is an import into another. The steps change because the person who buys now carries the legal duties of the receiving country. Suppose the Dhaka bookseller now buys printing paper from a supplier abroad. The bookseller is now the importer, and the supplier is now the exporter.

> An importer must be registered and, for some goods, hold a licence.

The first part is import registration and licence. A government office keeps a record of businesses that are allowed to import, and a business registers with it before it buys abroad. Some goods, such as certain chemicals or foods, need a further licence or permission, because the state wishes to control them. A business that ignores this step may find its goods held at the port. The rules differ from country to country, and in Bangladesh they have been changed several times, so a business should confirm the present rule before it places an order.^2

^2: In Bangladesh the importer's registration is an import registration certificate, and the rules on licences and on restricted goods are published by the government and revised from time to time.

> An indent is a written order sent to the foreign supplier.

The second part is the indent and the letter of credit. An *indent* is a written order, sent to a foreign supplier, that lists the goods, the quantity, the price and the terms. It is the importer's side of the export order of Section 13.1. The importer then applies to its own bank to issue a letter of credit in favour of the supplier. The bank examines the importer's finances, and often requires the importer to deposit part of the amount, because the bank takes a risk when it promises to pay.

> Recall: the letter of credit, section 13.1 'Export Procedure'.
> The import letter of credit is the same promise seen from the customer's side.

Nothing in the letter of credit has changed; only the point of view has changed. The Kolkata customer of Section 13.1 was the importer, and the Dhaka bookseller was the exporter. In this section the Dhaka bookseller applies to a Dhaka bank, and the supplier abroad is paid by the bank when the papers match. A careful importer reads the list of papers in the letter before it is sent, because the supplier must be able to supply every paper on the list.

> Customs clearance is the official check and payment of duty at the border.
@ Customs clearance | The official checking of goods at a border and payment of any duty before they are released.
@ Clearance | Word in use. In daily life, the removal of objects from a space, or permission to proceed. In trade, the official checking and release of goods at a border.

The third part is **customs clearance**, which means the official checking of goods at a border and the payment of any duty before they are released. Duty is a tax charged on goods when they cross a border. For example, when the printing paper reaches the port, the importer cannot take it away until the customs office has checked it and the importer has paid the duty that is due. In Bangladesh the National Board of Revenue controls customs.^3

^3: Customs are administered in Bangladesh under the National Board of Revenue. The procedures, the forms and the rates of duty change from time to time.

> Recall: tariffs and regulation, Chapter 12, 'Foreign Trade', section 12.3 'Regulating Trade'.
> The importer presents a customs form and papers, and the officer checks and values the goods.

The steps of clearance follow a fixed order. The ship arrives and the carrier gives notice. The importer, or a clearing and forwarding agent, presents to the customs office a form that lists the goods and their value, called a *bill of entry*, together with the invoice, the bill of lading and the packing list. A customs officer checks the papers, may open the packages to examine the goods, and decides the amount of duty under the tariff of Chapter 12. The importer pays, and the customs office releases the goods. The importer then collects them from the port and moves them to the shop.

> Clearance fails when papers, value or goods do not agree.

Clearance can fail, and a careful importer knows the common causes. The papers may disagree with each other, such as an invoice that states 150 packages when the packing list states 148. The declared value may seem too low, and the officer may then reassess the duty. The goods may be of a kind that needs a licence that the importer does not hold. Delay at the port is costly, because the shipping line and the port charge for every day that goods remain.

> Before moving on: the import chain in one paragraph.

*Before moving on.* An importer first registers and, where the goods require it, obtains a licence. The importer sends an indent to the supplier and asks its bank for a letter of credit. When the goods arrive, customs clearance checks them and collects duty before they are released. Delay or disagreement among the papers raises costs.

* * *

## Documents of Foreign Trade

> A shipment travels with a small set of papers, each proving one fact.

A shipment of goods across a border is accompanied by papers, and each paper proves one fact to one person. A customs officer reads some of them, a bank reads others, and the customer reads all of them. The figure that follows shows the main papers as four sheets. Read each sheet from top to bottom: the name is under the sheet, and the short line below the name says what the paper proves.

:fig The main papers that travel with a shipment | ch13-fig02.svg

> The commercial invoice is the seller's bill for the shipment.
@ Commercial invoice | The seller's bill listing goods, quantity, price and terms for a shipment.

The first paper is the **commercial invoice**, which means the seller's bill listing the goods, the quantity, the price and the terms for a shipment. It is prepared by the exporter. For example, the invoice for the books of the running case lists 150 titles, the price of each, the total and the currency. The customs officer uses it to value the goods, and the bank uses it to check the letter of credit. An invoice that disagrees with the letter is a common reason for refusal.

> The bill of lading is the carrier's receipt, contract record and title.
@ Bill of lading | A document from a shipping line that receipts goods, states their carriage terms and shows who may claim them.

The second paper is the **bill of lading**, which means a document from a shipping line that receipts the goods, states their terms of carriage and shows who may claim them. It does three jobs. It is a receipt: the line confirms that it received the goods in a stated condition. It records the terms of the contract of carriage between the exporter and the line. And it is a document of title: the person who holds the proper original copy may claim the goods at the destination. This last job explains why banks treat the bill of lading with great care.

> A bill of lading is the key to the goods, and it also proves loading.

Imagine that the goods are locked in a warehouse at the destination port, and the bill of lading is the key. The customer cannot collect the goods without it, and the bank will not release the payment without it. The date written on the bill also proves the date of loading, which the letter of credit often fixes. A bill of lading marked as received in poor condition is called unclean, and a bank usually refuses it. The exporter should therefore check that the packing is sound before the carrier signs.

> A charter party is a contract that hires a ship, not a space on one.
@ Charter party | A contract by which a shipowner hires a whole ship or part of it to a merchant.

The third paper applies when goods fill a whole ship, or a large part of one. A **charter party** means a contract by which a shipowner hires a whole ship, or part of it, to a merchant. Two kinds are common: a voyage charter hires the ship for one journey, and a time charter hires it for a period. A small exporter of books sends packages with a shipping line that carries the goods of many customers, and so needs a bill of lading but not a charter party. A bulk trader of grain or oil may hire a ship under a charter party.

> A packing list tells what is in each package.

The fourth paper is the packing list. It describes each package: the number of packages, what each holds, and the weight and size. The customs officer uses it to check the contents against the invoice, and the customer uses it to check the goods on arrival. Many shipments also carry an insurance certificate, which proves cover against loss, and a certificate of origin, which names the country where the goods were made. The letter of credit states which of these papers it needs.

> The table compares four papers by who prepares them and what they prove.

The table that follows compares the four papers. Read each row from left to right: the first column names the paper, the second says who prepares it, and the third says the fact it proves.

:table Four papers of a shipment compared
| Paper | Prepared by | What it proves |
| Commercial invoice | The exporter | What was sold, at what price and terms |
| Packing list | The exporter | What each package holds |
| Bill of lading | The shipping line | That goods were received, on what terms, and who may claim them |
| Charter party | The shipowner and the merchant | That a ship, or part of one, was hired |

:box IN SHORT
The invoice proves the sale, the packing list proves the contents, the bill of lading proves the loading and gives the right to claim, and the charter party proves the hire of a ship.

> Before moving on: the four papers in one paragraph.

*Before moving on.* A commercial invoice is the seller's bill for a shipment. A bill of lading receipts the goods and shows who may claim them. A charter party hires a ship for a merchant who fills a whole ship. A packing list shows what each package holds. A bank pays only when the papers agree with the letter of credit and with one another.

* * *

## Barriers and Promotion

> Barriers raise the cost or block the sale; promotion lowers the cost.

An exporter meets barriers that make a sale hard or costly. A tax on imports, called a tariff in Chapter 12, raises the price in the customer's country. A quota limits the quantity that may enter. A standard of quality or safety may exclude goods that fail it. Long paperwork, slow ports and scarce shipping space cause delays. A small exporter may also lack the money to produce the goods before payment arrives, and a change in the price of a foreign currency may reduce its earnings.

> Promotion strategies reduce the barriers through help, finance and information.

A country that wishes to raise its exports can reduce these barriers. The state may register exporters and offer help with finance, so that an exporter can pay for materials before the customer pays. It may establish zones with simpler rules for factories that produce for export. It may arrange trade fairs, where exporters meet customers from abroad, and it may train exporters in quality and in the papers of Sections 13.1 and 13.3.^4

^4: The kinds of help offered by Bangladesh, such as export credit, special zones and cash support, change with government policy. Readers who need present details should consult the Export Promotion Bureau and Bangladesh Bank.

> Export bodies give information, finance and a shared voice.

Several bodies carry this work. In Bangladesh the Export Promotion Bureau, a government body, supports exporters by collecting information and organising fairs. Bangladesh Bank, the central bank, controls foreign currency and the rules for the banks that open letters of credit. Trade associations, such as the Bangladesh Garment Manufacturers and Exporters Association, speak for their members to the government and help them to share knowledge. Chambers of commerce perform a similar task for businesses in general.

> Before moving on: barriers and promotion in one paragraph.

*Before moving on.* Tariffs, quotas, standards, delay and lack of finance are barriers to exports. A country can lower them through registration, finance, special zones and trade fairs. Government bodies, the central bank and trade associations each perform part of this work.

* * *

## Worked Case: The Export File of Meghna and Sons

> The worked case follows Situation, Question, Reasoning, Conclusion, Check.

This section applies the chapter to the running case. We follow five parts in order: the situation, the question, the reasoning, the conclusion and a check. The aim is to see how the steps fit together on real dates and figures.

> The situation is the export file, stated in full.

:case Case file, illustrative. *Situation.* An export file of Meghna and Sons records the sale of 150 Bangla titles for USD 2,500 (Tk 300,000). The order came from a Kolkata bookseller on 2 November 2026. The letter of credit was opened on 5 November 2026. The goods were packed on 12 November, shipped on 14 November, and the documents were taken to the bank on 15 November. Payment was received on 28 November 2026.

> The question asks for the steps, the waiting times and the price per title.

*Question.* Which step of Section 13.1 does each date mark? How many days passed between the steps? What price per title does the file give, and what exchange rate do its figures imply?

> Reasoning step one: match each date to its step.

*Reasoning.* We begin by matching dates to steps. The order of 2 November is the export order and contract. The opening of the letter of credit on 5 November is the second step, and it came before any packing. The packing on 12 November and the shipment on 14 November belong to shipping and clearing. The presentation of documents on 15 November and the receipt of payment on 28 November belong to payment.

> Reasoning step two: count the days between the dates.

Next we count the days between each pair of dates. From 2 to 5 November is 3 days. From 5 to 12 November is 7 days. From 12 to 14 November is 2 days. From 14 to 15 November is 1 day. From 15 to 28 November is 13 days. The total is 3 + 7 + 2 + 1 + 13 = 26 days, from the order to the payment.

> Reasoning step three: price per title and the implied exchange rate.

Now we turn to the price. The file gives Tk 300,000 for 150 titles, so the price per title is Tk 300,000 ÷ 150 = Tk 2,000. The file also gives USD 2,500 for the same sale, so the figures imply an exchange rate of Tk 300,000 ÷ USD 2,500 = Tk 120 for each dollar. The file does not state a rate, so this is a value that follows from its two amounts.

> Conclusion and check: steps, days and figures agree.

*Conclusion.* The dates follow the order of the chain: order, letter of credit, packing, shipment, documents, payment. The books were not packed until the letter of credit was in the bookseller's hands, which is the protection that the letter exists to give. The longest wait, 13 days, came after the documents reached the bank. *Check.* The five waiting times add to 26, which equals the number of days from 2 to 28 November. Also, 150 × Tk 2,000 = Tk 300,000, and Tk 120 × 2,500 = Tk 300,000. Both checks pass.

* * *

## Summary

> Summary of the chapter in a few lines.

An export begins with an order and a contract and is protected by a letter of credit, which is a bank's promise to pay when stated papers are shown. The goods are then packed, shipped and cleared, and the exporter shows the papers to the bank for payment. An import is the mirror: the importer registers, sends an indent, obtains a letter of credit and passes customs clearance. A commercial invoice, a bill of lading, a packing list and, for a whole ship, a charter party are the main papers. Barriers such as tariffs and delay can be reduced through finance, special zones and export bodies.

## Think It Through

:q 13.t1 | A bank refuses the documents of an exporter because the quantity on the invoice differs from the quantity in the letter of credit. The goods are already at sea. List the steps the exporter should take, and say who bears the delay.
:q 13.t2 | A customer asks the exporter to ship before the letter of credit is opened and promises to pay later. Give one reason to accept and two reasons to refuse.

## Where People Go Wrong

> A bank checks papers, not the quality of the goods.

Many students believe that the bank checks that the goods are good. It does not. The bank compares the papers with the letter of credit, and it pays if they agree, even when the goods are poor. A customer who fears poor goods should ask for a paper of inspection in the letter.

> A bill of lading is more than a receipt.

A second error is to treat the bill of lading as only a receipt. It is also a record of the contract of carriage and a document of title. A person who holds the proper original may claim the goods. This is why banks keep it until payment.

> Import and export are one trade seen from two sides.

A third error is to think that import procedure and export procedure are two different systems. The letter of credit, the invoice and the bill of lading are the same papers. Only the person who uses them, and the country whose law applies, differ.

## In History

> Early garment exports from Bangladesh show the procedure at work.

In 1978 the garment industry of Bangladesh was very small. Sources record that only a handful of factories made garments for export, and that a first shipment of shirts went to a business in Paris in that year. Accounts differ on which firm sent it, and some name Reaz Garments, while others give the credit to Desh Garments. Desh Garments, led by Noorul Quader, formed a joint venture with the Daewoo Corporation of South Korea in the same year and became the first factory in Bangladesh built wholly to export garments.

> The procedure of this chapter turned a few shipments into an industry.

For a new exporter in 1978, every step of this chapter was new: the registration, the letter of credit, the packing, the bill of lading and the clearance at the port. A first shipment proved that the chain worked for goods made in Bangladesh. Workers from Bangladesh went to South Korea to learn the work, and many later founded their own factories. Within a few decades garments became the largest export of the country.

## Review Questions

:q 13.1 | Put these steps of an export in order: shipping the goods, receiving the letter of credit, accepting the order, receiving payment, presenting the documents to the bank. Give a reason for the position of the letter of credit.
:q 13.2 | The Kolkata customer wishes to pay by bank transfer after delivery instead of a letter of credit. State one gain and one risk for the exporter.
:q 13.3 | A business in Bangladesh wishes to import paper from a supplier in another country. List the steps that the business must follow from registration to the release of the goods.
:q 13.4 | A grain trader wishes to move a full cargo by sea. Name the paper that hires the ship and the paper that receipts the goods, and say what each proves.
:q 13.5 | An exporter faces a tariff, a standard of quality and a lack of finance. Say which body or measure of Section 13.4 could help with each barrier.

:read International Chamber of Commerce, Uniform Customs and Practice for Documentary Credits, 2007
