:answers 13
:a 13.p1 | The letter removes the risk of not being paid by a stranger, because a bank promises payment. The risk that remains is that the papers may not match the letter, so the bank may refuse.
:a 13.t1 | The exporter asks the customer to amend the letter or corrects the invoice, then presents the papers again before the time limit ends. The exporter bears the delay and its costs, because the error was in the exporter's paper.
:a 13.t2 | Reason to accept: the customer may be reliable and the sale may be large. Reasons to refuse: the exporter then has no bank promise of payment, and the customer may fail to pay.
:a 13.1 | Accepting the order; receiving the letter of credit; shipping the goods; presenting the documents to the bank; receiving payment. The letter comes before shipping so that payment is promised before the goods leave.
:a 13.2 | Gain: less cost and paperwork. Risk: the exporter has no bank promise and must trust the customer to pay after the goods have been delivered.
:a 13.3 | Register as an importer and obtain any licence; send an indent to the supplier; ask the bank for a letter of credit; receive the goods and the papers; complete customs clearance and pay duty; collect the goods.
:a 13.4 | A charter party hires the ship; it proves that the ship was hired. A bill of lading receipts the goods; it proves loading, states the terms of carriage and shows who may claim the goods.
:a 13.5 | Tariff: government talks and information from the Export Promotion Bureau. Standard of quality: training in quality for exporters. Lack of finance: export finance through banks and Bangladesh Bank.
