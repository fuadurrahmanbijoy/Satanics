:glossary 02
Factor of production | A resource used to make goods or provide services. Economists name four: land, labour, capital and enterprise. A tea stall uses all four: a spot, the seller's work, a kettle, and the decision to open.
Land | All natural resources a business uses, including ground, water, minerals and forests. Nature provides land; people do not make it. Its reward is rent, such as the rent of a shop space.
Labour | The physical and mental work people give to a business, paid for with wages. A shop assistant who lifts boxes and advises customers gives both kinds of work. Wages are the reward of labour.
Division of labour | Splitting a job into small tasks so that each worker repeats one task and becomes faster. Two workers, one folding and one gluing paper bags, make more bags than two workers who each do both tasks.
Capital | Man-made goods and money used to produce other goods, such as machines, tools and stock. A kettle, a shop's shelves and the books held for sale are capital. Interest is the reward of capital.
Enterprise | The act of organising the other factors and accepting the risk of loss in the hope of profit. Profit is its reward, and unlike rent, wages and interest it is not agreed in advance.
