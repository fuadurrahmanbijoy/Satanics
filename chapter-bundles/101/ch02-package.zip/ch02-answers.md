:answers 02
:a 2.p1 | The kettle is capital, because people made it. The river water and the corner of pavement are land, because nature supplied them.
:a 2.p2 | Profit is not agreed in advance. It depends on how the year goes, so the person who receives it may gain a lot, a little, or make a loss.
:a 2.t1 | The machine is capital, and the three workers are labour. Buying the machine brings a cost of purchase or interest; the workers bring wages.
:a 2.t2 | The owner carries the risk, because profit is what remains after the payments agreed in advance. The owner supplies enterprise.
:a 2.t3 | The owner supplies labour for the work of operating the machine, and enterprise for organising the workshop and accepting the risk.
:a 2.1 | The landlord supplies land and earns rent. The shop assistant supplies labour and earns wages. The lender supplies capital and earns interest. The owner supplies enterprise and earns profit.
:a 2.2 | Labour is work paid with wages, which are agreed in advance, so a member of staff is paid even in a poor year. Nurul Meghna supplies enterprise: organising the shop and accepting the risk, with a profit of Tk 750,000 that was not agreed in advance.
:a 2.3 | Shop A relies mostly on the owner's labour, a little capital in the cart, and a rented spot as land. Shop B relies heavily on capital in shelves, scanners and stock, and on many staff as labour, with more land in its larger space. Both need an owner supplying enterprise.
:a 2.4 | The field is land and earns rent. The two helpers are labour and earn wages. The tractor is capital and earns interest. The farmer's decisions and risk are enterprise and earn profit.
:a 2.5 | Land: the rented shop space or stall. Labour: an assistant who sells the cloth. Capital: the stock of cloth or the shelves. Enterprise: the trader's organising of the business and acceptance of risk.
:a 2.6 | Division of labour splits a job into small tasks so that each worker repeats one. In the bag example, folding and gluing by two workers gave close to 60 bags in an hour instead of 40. One cost is that repeating one task can become dull.
