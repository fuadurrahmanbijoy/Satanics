:glossary 03
Objective | A clear aim that a business tries to reach within a stated time. A good objective has an amount and a time. "Raise profit from Tk 750,000 to Tk 900,000 during 2026" is an objective; "do better" is only a wish.
Economic objective | An aim that can be measured in money, such as profit, sales or market share. Market share is the part of all sales in one area that a single business wins. If a shop receives Tk 200,000 of Tk 1,000,000 spent on books in a town, its share is 20%.
Survival | A business's ability to keep operating by covering its costs year after year. A business that earns less than its costs spends the money it started with and must close when that money is gone. Profit is the sign of survival.
Goodwill | The good name a business earns with customers, which brings them back and is worth money. It takes years to earn and can be lost at once. A buyer of a business may pay more for a shop whose customers return.
