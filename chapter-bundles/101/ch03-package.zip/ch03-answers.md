:answers 03
:a 3.p1 | The stall loses Tk 2,250 − Tk 2,000 = Tk 250 each month. The savings last Tk 1,000 ÷ Tk 250 = 4 months.
:a 3.p2 | Example: answer a customer's question honestly and find the right book. The customer returns and tells others, and a buyer of the business would later pay more for a shop whose customers return.
:a 3.t1 | A social aim conflicts with profit when it costs money that would otherwise be kept as profit, as when books are given away. The shop can reduce the conflict by limiting the gift to a fixed number, choosing gifts that also build goodwill, and keeping survival first.
:a 3.t2 | The baker needs enough money (sound finance) to buy ingredients and pay helpers before new customers pay, and a plan for how many customers can be served well. Growth that is too fast can leave bills unpaid, which threatens survival, and poor service can damage goodwill.
:a 3.1 | Economic: raise profit to Tk 900,000 (measured in money), and supply 12 schools' libraries (a growth aim, measured through sales). Human: train 7 staff for 14 hours each, because the staff gain. Social: give 200 books a year to a school library, because people outside the business gain.
:a 3.2 | Example: "Raise the shop's sales by 10% during 2026." It has an amount (10%) and a time (during 2026).
:a 3.3 | R = P ÷ C × 100 = 300 ÷ 2,000 × 100 = 0.15 × 100 = 15%. Check: 15% of Tk 2,000 is Tk 300.
:a 3.4 | Any three, each with a reason. Examples: a product customers want (fresh flowers of good quality from a reliable supplier); planning and foresight (order more stock before busy times, since flowers do not keep); goodwill (customers return if the flowers last); sound finance (do not buy more than can be sold, and pay the supplier on time).
:a 3.5 | Raise sales by 10%: economic. Pay a monthly bonus: human. Give leftover cloth to a girls' school: social. Open a second counter: economic (growth).
:a 3.6 | Every other aim needs the business to exist. A business that cannot cover its costs year after year stops, so it can pay no wages, serve no customers and give no gifts.
:a 3.7 | Borrowed money must be repaid with interest, and new branches cost money before they earn, so the café may be unable to pay its bills (sound finance). Fast growth may also spread attention thin, so service falls and goodwill suffers.
:a 3.8 | Goodwill is earned by honest dealing and good service over years. It is lost by one act of dishonesty or poor treatment. It is worth money because customers return, and a buyer of the business would pay more for a business whose customers return.
