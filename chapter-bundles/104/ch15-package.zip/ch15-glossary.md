:glossary 15
Rent | The payment to the owner of land for its use, in everyday talk and in economics. In this book the word is kept for land. Example: Tk 60,000 a month paid for a shop site.
Economic rent | The payment to any factor above the least needed to keep it in use. For land as a whole the least needed is nothing, so the whole payment is economic rent. Example: a singer paid Tk 100,000 who would sing for Tk 40,000 earns Tk 60,000.
Quasi-rent | A temporary surplus earned by a man-made asset while its supply is fixed in the short run. It disappears when new assets are built. Example: printing presses when demand for books suddenly rises.
Wage | The payment to labour for its work over a period. It may be stated by the hour, the day or the month. Example: Tk 35,000 a month for a shop assistant.
Nominal wage | A wage measured in money, without allowing for changes in prices. It is the figure on the pay slip. Example: Tk 35,000 a month.
Real wage | A wage measured by the goods and services it can buy. It equals the nominal wage divided by the price index over 100. Example: 35,000 ÷ 1.12 = Tk 31,250.
Marginal revenue product | The extra revenue a firm gains from employing one more unit of labour. A firm hires while it is at least equal to the wage. Example: an assistant who adds Tk 40,000 a month.
