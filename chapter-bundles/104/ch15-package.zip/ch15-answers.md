:answers 15
:a 15.p1 | The 60-bag land pays no rent. The 70-bag land pays 70 - 60 = 10 bags, and the 90-bag land pays 90 - 60 = 30 bags.
:a 15.t1 | Demand: a surgeon's work brings in or saves a great deal, so the marginal revenue product is high. Supply: few people can qualify because training is long and costly. High demand and small supply give a high wage.
:a 15.t2 | The farm's yield net of transport falls less, or its sale price rises, so its advantage over the marginal land grows and its rent rises. Demand for its use rises while its supply is fixed.
:a 15.1 | Rent is the payment to the owner of land for its use. Nobody can make more land, so the total supply does not respond to payment.
:a 15.2 | Economic rent = 80,000 - 50,000 = Tk 30,000.
:a 15.3 | Marginal land: 0. The 100 kg grade: 100 - 80 = 20 kg. The 120 kg grade: 120 - 80 = 40 kg.
:a 15.4 | 120 ÷ 100 = 1.2, and 24,000 ÷ 1.2 = Tk 20,000.
:a 15.5 | The real wage falls. Money rises by 5% but prices rise by 8%, so purchasing power is lower.
:a 15.6 | Hire two. The first two add 45,000 and 34,000, above the wage of 30,000. The third adds 29,000, which is below it.
:a 15.7 | Rent is the lasting payment to the owner of land, whose supply is fixed. Quasi-rent is a temporary surplus of a man-made asset while its supply is fixed in the short run, and it disappears as new assets are built.
