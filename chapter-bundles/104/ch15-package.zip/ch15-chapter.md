:chapter XV | Rent and Wages
:mood Why is one field paid for, and one worker paid more than another?
:desc This chapter explains why land earns a payment that no one needs to be tempted to give, how the payment to labour is measured in money and in goods, and how demand and supply set a wage and explain why wages differ.
:plate ch15-plate.svg | A hiring fair, with workers waiting beside the farm carts

:box YOU WILL NEED
Chapter 14, 'Monopoly and Imperfect Competition', section 14.1 'Monopoly', for monopoly; Chapter 9, 'Elasticity of Supply and Market Equilibrium', section 9.3 'Changes in Equilibrium', for changes in equilibrium; Chapter 11, 'Costs of Production', section 11.1 'Explicit and Implicit Costs', for explicit and implicit costs; and Appendix A1, 'Maths You Will Use', for percentages and index numbers.

> A hiring fair brings together owners of land and sellers of labour.

On a market day in an old English county, farmers drive their carts into the square and workers stand beside them, waiting to be hired for the year. A farmer with two fields looks over the crowd. Everyone at the fair knows that the farmer will pay the labourers, for they have to be tempted to work. Few ask a stranger question: why does the farmer's field earn a payment at all? Nobody had to be tempted to make the field.

> Two puzzles stand beside each other: the payment to land and the payment to workers.

A second puzzle sits close to the first. In the crowd, a ploughman asks for less than a skilled stonemason, and the stonemason asks for less than a surgeon would in the town. They are all people. Why do their payments differ so widely? And what stops a farmer from offering half the going rate, or a worker from demanding double?

> The chapter answers both puzzles by looking at demand and supply.

The answers come from the tools you already have. Section 15.1 studies rent, the payment to land, and shows that a whole class of payments share its character. Section 15.2 turns to wages and distinguishes the wage in money from the wage in goods. Section 15.3 uses demand and supply to explain how wages are set and why they differ.

* * *

## 15.1 Rent

### Rent and economic rent

> Everyday speech uses the word rent for many payments.

@ Rent | Word in use. In daily life, any payment for the use of a house, a room, a car or a machine. In economics, the payment for the use of land.

@ Rent | The payment to the owner of land for its use, in everyday talk and in economics.

> Rent is the payment to the owner of land for its use.

Begin with a familiar payment. A family pays a landlord each month to live in a flat. A farmer pays an owner each year to plough a field. In both cases a person pays for the use of land that belongs to someone else. This payment is **rent**, which means the payment to the owner of land for its use, in everyday talk and in economics. A tenant who pays Tk 60,000 a month for a shop site is paying rent. In everyday speech the word is also used for cars and machines, so this book keeps it for land unless it says otherwise.

> The supply of land as a whole is fixed, which makes its payment unusual.

Land has a feature that most goods lack. Nobody can make more of it. The whole supply of land in a country is fixed, whatever the payment. In words you know from Chapter 9, the elasticity of supply of land as a whole is zero. Because supply cannot respond, the payment to land is set by demand alone: when many people want land, its payment rises, and when few want it, the payment falls. The landowner does not have to be tempted to supply it.

@ Economic rent | The payment to any factor above the least needed to keep it in use.

> Economic rent is the part of a payment above the least needed to keep a factor in use.

This observation leads to a wider idea. **Economic rent** means the payment to any factor above the least needed to keep it in use. A factor is any resource used in production, such as land, labour or a machine. Suppose a famous singer is paid Tk 100,000 for an evening and would have agreed to sing for Tk 40,000. The least needed is Tk 40,000, and the economic rent is Tk 60,000. For land as a whole the least needed is nothing, since it exists whatever is paid, so the whole payment is economic rent.

> Recall: explicit and implicit costs, Chapter 11, section 11.1 'Explicit and Implicit Costs'.

For one plot, the position differs. A plot of farmland has another use, and its owner could sell it for building. The least needed to keep it in farming is what that other use would pay, which Chapter 11 would call an implicit cost. Only the part above that is economic rent. This is a common source of confusion, and it is why economists speak of economic rent for any factor and not only land.

> The owner, the tenant and the buyer of the goods each see rent differently.

Viewpoints differ. For the owner, rent is income from a fixed asset that needs no extra effort to supply. For the tenant, rent is a payment that must be covered by the sales of the shop or the crop. For the buyer of the goods, rent is not a reason for a high price, since the site's advantage creates the rent and not the other way round. A tenant who pays a high rent for an excellent site is paying for its advantage, and could not make the same profit from a poor site at a low rent.

> Before moving on: rent is a payment for land; economic rent is a surplus above the least needed.

*Before moving on.* Rent is the payment to the owner of land for its use. Land as a whole is fixed in supply, so its whole payment is economic rent. Economic rent is the part of any payment above the least needed to keep a factor in use.

### Ricardian theory of rent

> Differences in the quality of land explain why some plots pay more.

Why does one plot pay more rent than another? The English economist David Ricardo gave the classic answer in 1817. His theory rests on a simple picture: land differs in quality, and the best land is used first.

> Rent arises because better land produces more at the same cost.

Imagine a district with three grades of land. A farmer using one acre of Grade A land harvests 3,000 kg of rice. On Grade B the same work and seed yield 2,500 kg, and on Grade C they yield 2,000 kg. Suppose that Grade C is the poorest land still worth farming, so it pays no rent: it is the marginal land. A farmer will not pay more for Grade B than the extra 500 kg it gives over Grade C, because Grade C is available for nothing. For the same reason Grade A will rent for the extra 1,000 kg. Rent equals the difference in yield between a plot and the marginal land.

> The figure shows rent as the part of the yield above the marginal land's yield.

To read the first figure, look at the stacked bars. Each bar is one grade of land, and its height is the yield of one acre. The lower, hatched part of each bar is the yield of the marginal land, which every grade produces. The dotted part above it is the extra yield, and that is the rent. Grade C has no dotted part, because it is the marginal land and pays no rent.

:fig Differential rent as stacked grades of land | ch15-fig01.svg

> Ricardo's theory applies to shop sites as well as farms.

Ricardo's theory applies to shop sites as well as to farms, and the next record shows it.

> The record gives two profits and the rent they imply.

:case Case file, illustrative. Meghna and Sons trades at a site in Dhanmondi, Dhaka. The shop's profit before rent at Dhanmondi is Tk 1,470,000 a year. At the marginal site, which pays no rent, the profit before rent would be Tk 750,000. The difference is Tk 720,000, which equals the rent paid: Tk 60,000 × 12 = Tk 720,000.

> The case file confirms that rent equals the gain of the better site over the marginal one.

The record shows the theory at work. A tenant would not pay more than Tk 720,000 a year for the Dhanmondi site, because the marginal site yields Tk 750,000 for no rent. The rent also cannot fall far below Tk 720,000, because other shopkeepers would bid for such a profitable site. Competition between users therefore pushes the rent to the difference. Note that rent does not cause the price of the goods sold at the site. It is the result of the site's advantage.

:pause 15.p1 | Three grades of land yield 90, 70 and 60 bags an acre, and the 60-bag land is the marginal land. Find the rent of each grade, in bags.

> Before moving on: Ricardian rent is the gain of a better plot over the marginal plot.

*Before moving on.* In Ricardo's theory, land of different quality earns differential rent, equal to the difference between its yield and that of the marginal land. The marginal land pays no rent. The same reasoning applies to shop sites.

### Quasi-rent

> Man-made assets can earn a surplus for a short time.

Land is a gift of nature. Is there a similar surplus for things people make? Yes, but it does not last. The English economist Alfred Marshall, in his *Principles of Economics* (1890), gave it a name.

@ Quasi-rent | A temporary surplus earned by a man-made asset while its supply is fixed in the short run.

> Quasi-rent is a short-run surplus earned by a man-made asset.

**Quasi-rent** means a temporary surplus earned by a man-made asset while its supply is fixed in the short run. Suppose the demand for printed books rises. The number of printing presses cannot rise overnight, so those that exist earn more than the least needed to keep them running, namely their variable costs. The surplus above variable cost is what pays the fixed cost and leaves a gain. In the long run, new presses are built, supply rises and the surplus is competed away. That is why it is called quasi, meaning 'as if' rent: it behaves like rent for a short time only.

> Before moving on: rent is lasting, quasi-rent is temporary.

*Before moving on.* Rent belongs to land, whose supply is fixed for good. Quasi-rent belongs to man-made assets, whose supply is fixed only in the short run, and it disappears when new assets are built.

* * *

## 15.2 Wages

### The wage

> The word wage is used loosely in daily life.

@ Wage | Word in use. In daily life, the weekly pay of a manual worker, as distinct from a salary. In economics, any payment to labour, whatever its name.

@ Wage | The payment to labour for its work over a period.

> A wage is the payment to labour for its work over a period.

Labour is the work of people, and it is paid. A **wage** means the payment to labour for its work over a period. It may be stated by the hour, the day or the month. A shop assistant paid Tk 35,000 a month earns a wage, and so does a surgeon paid Tk 400,000 a month. In daily speech a salary and a wage are different; in economics the two are the same kind of payment.

### Nominal wage and real wage

> A wage in money can hide what the worker can actually buy.

A wage is first stated in money, but money is only useful for what it buys. If the prices of goods double, the same money buys half as much. Economists therefore separate the money amount from its purchasing power.

@ Nominal wage | A wage measured in money, without allowing for changes in prices.

> A nominal wage is the money amount, unadjusted for prices.

The **nominal wage** is a wage measured in money, without allowing for changes in prices. Tk 35,000 a month is a nominal wage. It is the figure on the pay slip.

@ Real wage | A wage measured by the goods and services it can buy.

> A real wage measures the goods and services the wage buys.

The **real wage** is a wage measured by the goods and services it can buy. To find it, divide the nominal wage by a price index, which is a number showing the level of prices compared with a base year set at 100. In words: real wage = nominal wage ÷ (price index ÷ 100). In symbols, real wage = W ÷ (P ÷ 100), where W stands for the nominal wage and P for the price index.

> The next record sets out the figures.

:case Case file, illustrative. A shop assistant at Meghna and Sons earns a nominal wage of Tk 35,000 a month. The price index rises from 100 to 112. The real wage is 35,000 ÷ 1.12 = Tk 31,250.

> The steps follow the usual order, from the given figures to a check.

*Given:* a nominal wage of Tk 35,000 a month, and a price index that rises from 100 to 112. *Find:* the real wage, in the prices of the base year. *Formula:* real wage = nominal wage ÷ (price index ÷ 100). *Steps.* The index divided by 100 is 112 ÷ 100 = 1.12. Then 35,000 ÷ 1.12 = 31,250. *Answer:* the real wage is Tk 31,250 a month, in base-year prices. *Check:* prices have risen 12%, so the wage should buy less than Tk 35,000 did before, and Tk 31,250 is lower.

> The nominal wage can rise while the real wage falls.

The result carries a lesson. Suppose the assistant is given a rise of 10%, to Tk 38,500, while the price index rises to 112. The real wage is 38,500 ÷ 1.12 = Tk 34,375 in base-year prices, which is below the first figure of Tk 35,000 in the same prices. The assistant has more money and less purchasing power. A common slip is to judge a wage by the nominal figure alone.

> A viewpoint check shows why the real wage matters to each side.

The employee cares about the real wage, because bills are paid in goods. The employer cares about the nominal wage, because the payroll is paid in money, but a careful employer also watches the real wage, since workers who see their purchasing power fall may leave or bargain for more. A rise in the nominal wage that only matches rising prices leaves the worker no better off, and economists call confusion over this point a mistake of treating money as if it were purchasing power.

> Before moving on: the nominal wage is in money and the real wage is in goods.

*Before moving on.* A wage is the payment to labour for its work over a period. The nominal wage is the money amount. The real wage divides it by the price level, so it shows what the wage buys.

* * *

## 15.3 How Wages Are Set

### What a worker adds

> A firm hires a worker only if the worker brings in more than the worker costs.

Return to the shop. The owner is thinking of hiring one more assistant at a wage of Tk 35,000 a month. A sensible owner asks one question: how much more money will the shop receive because of this assistant? If the answer is more than Tk 35,000, hiring pays. If it is less, hiring loses money.

@ Marginal revenue product | The extra revenue a firm gains from employing one more unit of labour.

> Marginal revenue product is the extra revenue from one more unit of labour.

The measure has a name. **Marginal revenue product** means the extra revenue a firm gains from employing one more unit of labour. It combines two things: the extra output the worker produces, and the extra revenue that each unit of output brings, which is the marginal revenue you met earlier. In words: marginal revenue product = extra output from the worker × marginal revenue per unit. For a worker who produces 20 more books a week, where each extra book brings Tk 500, the marginal revenue product is Tk 10,000 a week.

> The hiring rule compares the marginal revenue product with the wage.

The rule for the owner follows. Hire one more worker while the marginal revenue product is at least as large as the wage, and stop when it falls below the wage. The extra output from each added worker eventually shrinks, since the workers share the same shop, shelves and counter, and so the marginal revenue product falls as the firm hires more.

> The record gives the revenue that two extra assistants would add.

:case Case file, illustrative. At Meghna and Sons, the first extra assistant adds Tk 40,000 a month of revenue, and the second adds Tk 30,000. The wage is Tk 35,000 a month.

> The case file shows the rule in use: hire the first assistant but not the second.

Apply the rule. The first assistant brings in Tk 40,000 and costs Tk 35,000, so the shop gains Tk 5,000 a month. The second brings in Tk 30,000 and costs Tk 35,000, so the shop would lose Tk 5,000 a month. The owner hires one extra assistant and stops. Since the figures fall as more are hired, the marginal revenue product schedule works as the firm's demand for labour: it shows how many workers the firm will hire at each wage.

### Demand and supply of labour

> A labour market has a demand side and a supply side, like any other market.

The wage for a whole occupation is set where the demand for labour meets the supply of labour. Demand comes from all the firms that hire; it slopes downward because the marginal revenue product falls as more workers are hired. Supply comes from workers; it slopes upward because a higher wage draws more people into the work, as it draws people from other jobs, from study and from leisure. As in other markets, the equilibrium wage is the wage at which the quantity of labour demanded equals the quantity supplied.

> To read the second figure, find the wage and the number of workers where the lines meet.

To read the second figure, look at the axes. The vertical axis shows the wage, and the horizontal axis shows the number of workers. The solid line, sloping down, is the demand for labour. The dashed line, sloping up, is the supply of labour. Where they cross, the wage and the number employed are set. At a higher wage, more workers want jobs than firms will fill; at a lower wage, firms want more workers than offer.

:fig Wage set by the demand for and supply of labour | ch15-fig02.svg

> Recall: changes in equilibrium, Chapter 9, section 9.3 'Changes in Equilibrium'.

Changes follow the pattern of Chapter 9. If firms become more productive or the price of their goods rises, the marginal revenue product rises and demand for labour moves to the right, so the wage and the number employed both rise. If more people enter the occupation, supply moves to the right and the wage falls. A wage fixed by law above the equilibrium wage leaves more workers seeking jobs than firms will fill, though it raises the pay of those who keep their work.

### Why wages differ

> Wages differ because the demand and supply differ between occupations.

The same tools explain why wages differ. A surgeon earns more than an assistant for reasons on both sides of the market. On the demand side, a surgeon's work brings in or saves a very large amount, so the marginal revenue product is high. On the supply side, few people can qualify, since the training is long, costly and demanding, so the supply is small. A high demand meeting a small supply gives a high wage.

> Other causes work through the same two sides.

> Recall: monopoly, Chapter 14, section 14.1 'Monopoly'.

Other causes follow the same logic. Dangerous or unpleasant jobs pay more, because few people accept them at an ordinary wage. Workers with scarce skills are in short supply. Trade unions raise wages by limiting supply or by bargaining. A firm that is the only large employer in a town, a position like the monopoly of Chapter 14, may pay less than a competitive market would, because workers have nowhere else to go. Differences in wages are therefore not random; each can be traced to demand, supply or both.

> A minimum wage fixed above the equilibrium wage helps those hired and may leave others without work.

Wages are sometimes fixed by law. A minimum wage set above the equilibrium wage raises the pay of workers who keep their jobs, but at that higher wage firms demand fewer workers than seek work. Whether jobs are lost, and how many, depends on how strongly firms respond to the higher wage; the wider the gap between the legal wage and the equilibrium wage, the larger the likely loss. Governments weigh this against the gain to the workers who are paid more.

> Before moving on: wages follow the marginal revenue product and the supply of workers.

*Before moving on.* A firm hires while the marginal revenue product is at least the wage. The wage for an occupation is set where demand for labour meets supply. Wages differ because demand and supply differ across occupations.

* * *

## Worked Examples: Four Rungs

> Four examples, from clean numbers to a combined problem.

Each example below follows the order Given, Find, Formula, Steps, Answer, Check.

> Rung 1: a real wage with clean numbers.

*Given:* a nominal wage of Tk 20,000 a month, and a price index that rises from 100 to 125. *Find:* the real wage. *Formula:* real wage = nominal wage ÷ (price index ÷ 100). *Steps.* 125 ÷ 100 = 1.25, and 20,000 ÷ 1.25 = 16,000. *Answer:* Tk 16,000 a month in base-year prices. *Check:* prices rose by a quarter, so the wage should buy only four-fifths as much: 20,000 × 0.8 = 16,000.

> Rung 2: differential rent with three sites and less tidy numbers.

*Given:* three shop sites have profits before rent of Tk 1,470,000, Tk 1,100,000 and Tk 750,000 a year, and the last is the marginal site. *Find:* the rent that each site can bear. *Formula:* rent = profit before rent at the site - profit before rent at the marginal site. *Steps.* First site: 1,470,000 - 750,000 = 720,000. Second site: 1,100,000 - 750,000 = 350,000. Marginal site: 0. *Answer:* Tk 720,000, Tk 350,000 and nothing. *Check:* the better the site, the higher the rent, and the first figure agrees with the Dhanmondi record.

> Rung 3: the period changes from a year to a month.

*Given:* an annual nominal wage of Tk 420,000, and a price index that rises from 100 to 112. *Find:* the real wage per month. *Steps.* The monthly nominal wage is 420,000 ÷ 12 = 35,000. The real monthly wage is 35,000 ÷ 1.12 = 31,250. *Answer:* Tk 31,250 a month. *Check:* the annual real wage is 420,000 ÷ 1.12 = 375,000, and 375,000 ÷ 12 = 31,250, the same. The slip to avoid is to divide by 12 at one stage and forget it at another.

> Rung 4: hiring and economic rent in one problem.

*Given:* a firm pays Tk 35,000 a month. Successive extra workers add Tk 52,000, Tk 41,000, Tk 36,000 and Tk 30,000 a month of revenue. The third worker would have accepted Tk 28,000 a month. *Find:* how many to hire, the gain, and the third worker's economic rent. *Steps.* Compare each marginal revenue product with 35,000: the first three exceed it, the fourth (30,000) does not, so hire three. The revenue added is 52,000 + 41,000 + 36,000 = 129,000, and the wages are 3 × 35,000 = 105,000, a gain of 24,000. The economic rent of the third worker is 35,000 - 28,000 = 7,000. *Answer:* hire three, gain Tk 24,000 a month, and the third worker's economic rent is Tk 7,000. *Check:* the last worker hired adds 36,000, slightly above the wage of 35,000, as the rule requires.

* * *

## Summary

> The chapter's main results in a few lines.

Rent is the payment to the owner of land for its use. Land as a whole is fixed in supply, so its whole payment is economic rent, which is any payment above the least needed to keep a factor in use. Ricardo's theory makes rent the difference between a plot's yield and that of the marginal land. Quasi-rent is a temporary surplus earned by a man-made asset in the short run. A wage is the payment to labour, the nominal wage is in money and the real wage is in goods. A firm hires while the marginal revenue product is at least the wage, and wages are set by demand and supply.

## Think It Through

:q 15.t1 | Explain why surgeons earn more than shop assistants, using both the demand side and the supply side of the labour market.
:q 15.t2 | A new road makes a distant farm easier to reach. What do you expect to happen to the rent of that farm, and why?

## Where People Go Wrong

> Four common misunderstandings, each corrected.

Many students think that rent raises the price of the goods grown on the land. In Ricardo's theory it is the other way: the marginal land fixes the cost, and rent is the surplus of better land. They often judge a wage by its nominal figure alone, when the real wage shows what the wage buys. They think that economic rent belongs only to land, when any factor can earn it. The fourth error is to expect a firm to hire until the marginal revenue product is zero; it stops when the marginal revenue product falls below the wage.

## In History

> In 1817 Ricardo explained rent as the gain of better land over the poorest land in use.

David Ricardo (1772 to 1823) was an English businessman and economist. In 1817 he published *On the Principles of Political Economy and Taxation*, which set out the theory of rent that this chapter describes. At the time, England had high food prices and a fierce argument about the corn laws, which taxed imported grain. Ricardo argued that rent followed from the price of food, and that the poorest land in use paid none.

> In 2013 Bangladesh raised the garment minimum wage after protests and a factory disaster.

Wages can also be set by law. In April 2013 the Rana Plaza building, which housed garment factories near Dhaka, collapsed, and more than a thousand people died. After this disaster and a wave of strikes, a government wage board raised the monthly minimum wage for entry-level garment workers from Tk 3,000 to Tk 5,300, effective from December 2013. The minimum wage was revised again in later years. The case shows a wage fixed above the level that the market had set, as discussed in section 15.3.

## Review Questions

:q 15.1 | Define rent, and explain why the supply of land as a whole is said to be fixed.
:q 15.2 | A singer is paid Tk 80,000 for an evening and would have accepted Tk 50,000. Find the economic rent.
:q 15.3 | Three grades of land yield 120, 100 and 80 kg an acre, and the 80 kg land is the marginal land. Find the differential rent of each grade.
:q 15.4 | A nominal wage of Tk 24,000 a month meets a price index that rises from 100 to 120. Find the real wage.
:q 15.5 | A nominal wage rises by 5% while prices rise by 8%. Does the real wage rise or fall?
:q 15.6 | A firm pays Tk 30,000 a month. Successive workers add Tk 45,000, Tk 34,000, Tk 29,000 of revenue. How many should it hire?
:q 15.7 | Distinguish rent from quasi-rent in one sentence each.

:read David Ricardo, On the Principles of Political Economy and Taxation, 1817
