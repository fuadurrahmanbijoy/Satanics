:answers 05
:a 5.p1 | %ΔP = 4 ÷ 10 × 100 = +40%; %ΔQ = -10 ÷ 25 × 100 = -40%; E = 40 ÷ 40 = 1, so demand is unit elastic.
:a 5.t1 | Quantity demanded falls by about 0.3 × 10% = 3%. Demand is inelastic, so total revenue rises, because the 10% higher price outweighs the 3% fall in quantity.
:a 5.t2 | With time, consumers find substitutes and change habits, so demand becomes more elastic. A large rise may also lose customers who watch the price closely, so the gain in revenue may not last.
:a 5.1 | It is the percentage change in quantity demanded divided by the percentage change in price. Percentages remove units and starting levels, so goods of different size can be compared.
:a 5.2 | The base is the average of the old and new values, which is the same whichever is called old. The percentage and so the elasticity do not depend on the direction.
:a 5.3 | %ΔQ = -20 ÷ 50 × 100 = -40%; %ΔP = 10 ÷ 25 × 100 = +40%; E = 1. Demand is unit elastic.
:a 5.4 | Quantity rises from 40 to 50: %ΔQ = 10 ÷ 45 = 22.22%; price falls from 40 to 30: %ΔP = 10 ÷ 35 = 28.57%; E = 0.78, inelastic. Total revenue falls from Tk 1,600 to Tk 1,500, as the test predicts.
:a 5.5 | Income elasticity = 10% ÷ 20% = 0.5.
:a 5.6 | Cross elasticity = -3% ÷ 5% = -0.6. The negative sign shows that tea and sugar are used together.
:a 5.7 | A brand of tea has many close substitutes, namely other brands, so a consumer can switch when its price rises. Tea in general has fewer substitutes.
