:chapter V | Elasticity of Demand
:mood How hard does a change in price push the consumer?
:desc This chapter teaches you to measure how strongly consumers respond to a change in price, in their own income and in the price of a rival good, and to use the result to judge whether a lower price brings a firm more money.
:plate ch05-plate.svg | A pharmacist's scales weigh a small weight against a large one

:box YOU WILL NEED
Chapter 4, 'Demand and the Demand Curve', section 4.1 'Quantity Demanded and the Law of Demand', for demand and its curve; Chapter 4, section 4.2 'Movement and Shift', for the difference between a movement along a curve and a shift; and Appendix A1, 'Maths You Will Use', for percentages and fractions.

> Two goods lose a fifth of their price, yet they sell very differently.

Picture a street in Dhanmondi, Dhaka, on a Friday evening. One stall sells packets of salt. Beside it, a shop sells fashionable shoes. On the same day, both owners cut their prices by one-fifth. The salt seller waits all evening for a rush of customers, but it does not come. Families buy the same few packets they always buy, because a household cannot use more salt merely because salt is cheaper. The shoe seller finds a queue at the door by seven o'clock.

> The law of demand gives the direction of the change but not its size.

The law of demand, which you met in Chapter 4, says that a lower price raises the quantity demanded. It holds in both shops. Yet it says nothing about how much the quantity demanded rises. Salt rose by a trifle; shoes rose by a great deal. For an owner who must decide whether to cut a price, the direction is not enough. The owner needs a number that tells how strongly consumers respond.

> A price cut brings more customers but less money from each one.

There is a second puzzle behind the first. A lower price attracts more customers, but each customer pays less. Whether the shop finishes the day with more money received or with less depends on which effect is larger, and that depends on the same strength of response. This chapter builds the number. Section 5.1 defines and calculates it. Section 5.2 teaches you to read it. Section 5.3 explains what makes it large or small. Section 5.4 extends the idea to income and to the price of a rival good.

* * *

## 5.1 Price Elasticity of Demand

### Why we need percentages

@! Go slowly here.

> Money amounts and unit counts hide the real size of a change.

Begin with a household question. Suppose your monthly rent rises by Tk 500, and in the same month the price of a pen rises by Tk 5. Both rises look small, yet they are very different. Tk 500 added to a rent of Tk 20,000 is a rise of one-fortieth. Tk 5 added to a pen that costs Tk 10 is a rise of one-half. Only the change measured against the starting level shows how large the change is. For this reason economists measure changes in percentages.

@ Response | Word in use. In daily life, an answer or a reply. In economics, the change in quantity demanded that follows a change in price or in another cause.

> Quantity needs the same treatment: ten more units mean different things to different shops.

Quantity has the same difficulty. Ten extra notebooks in a week is a large rise for a shop that sells thirty and a tiny rise for a shop that sells three thousand. A measure of response must therefore compare a percentage change in quantity with a percentage change in price. Such a measure has no units. It can be compared across goods, shops and countries.

@ Elastic | Word in use. In daily life, able to stretch and then return, like a rubber band. In economics, the quantity demanded stretches a long way when the price changes.

@ Price elasticity of demand | The percentage change in quantity demanded divided by the percentage change in price.

> Price elasticity of demand is the percentage change in quantity demanded divided by the percentage change in price.

This measure has a name. **Price elasticity of demand** means the percentage change in quantity demanded divided by the percentage change in price. Suppose a price rises by 10% and the quantity demanded falls by 20%. The price elasticity of demand is 20 divided by 10, which is 2. The name comes from a picture: a rubber band is elastic when a small pull stretches it far, and quantity demanded is elastic when a small change in price stretches it far.^1

^1: By the law of demand, price and quantity demanded move in opposite directions, so the raw ratio is negative: -20 divided by +10 gives -2. Economists usually drop the minus sign and report the size of the number, ignoring its sign. This book does the same, and the sign is always understood to be there.

> Before moving on: the measure compares two percentages and has no units.

*Before moving on.* Changes in money and in units cannot be compared, so we use percentages. Price elasticity of demand divides the percentage change in quantity demanded by the percentage change in price. A result of 2 means quantity changes twice as fast as price.

### Finding a percentage change

> A percentage change is the change divided by a base value, times 100.

You need one tool before you can calculate. In words, the percentage change equals the change in the value, divided by the value you compare it with, multiplied by 100. In symbols, percentage change = (new value - old value) ÷ old value × 100. This ordinary method works well for small changes. It has one weakness, which many students find confusing, because the answer depends on the direction of travel.

> The ordinary method gives different answers going up and going down.

Test it with the price of a notebook. A price rising from Tk 40 to Tk 50 rises by Tk 10, and 10 divided by 40 is 25%. A price falling from Tk 50 to Tk 40 falls by the same Tk 10, but 10 divided by 50 is 20%. One gap between the same two prices has produced two percentages. If we used this method, the elasticity between Tk 40 and Tk 50 would depend on which price we chose as the start, and two people measuring the same demand schedule could report different numbers.

> The midpoint method divides each change by the average of the old and new values.

The remedy is the midpoint method, which divides the change by the midpoint, the average of the old and new values. In words: percentage change = change ÷ average of the old and new values × 100. In symbols, with old value A and new value B, percentage change = (B - A) ÷ ((A + B) ÷ 2) × 100. The average is the same whichever value you call old, so the answer is the same in both directions. Between Tk 40 and Tk 50 the average is Tk 45, the change is Tk 10, and 10 ÷ 45 gives 22.22% whether the price rises or falls.^2

^2: Some books divide by the starting value and accept a small difference. The midpoint method is used here because it gives one answer for each pair of points. If another book uses the starting value, expect slightly different results when the changes are large.

> Before moving on: use the average of old and new values as the base.

*Before moving on.* The ordinary percentage change depends on the starting point. The midpoint method removes that problem by dividing the change by the average of the old and new values. Every elasticity in this chapter uses it.

### The formula and a first example

> The whole formula uses two midpoint percentages and one division.

@! Go slowly here.

Now the whole formula can be stated. In words: price elasticity of demand = percentage change in quantity demanded ÷ percentage change in price, each found by the midpoint method. In symbols, E = %ΔQ ÷ %ΔP. Here E stands for price elasticity of demand, %ΔQ for the percentage change in quantity demanded and %ΔP for the percentage change in price. The Greek capital letter Δ (delta) means 'change in'.

:box IN SHORT
Price elasticity of demand measures how strongly quantity demanded responds to price. Find each percentage change by the midpoint method, divide the quantity figure by the price figure, and report the size of the result.

> The first example uses the smallest clean numbers, so only the method is new.

Our first example uses clean numbers, so that the method is the only new thing. It is an everyday setting, not the running case. *Given:* a tea stall raises its price per cup from Tk 9 to Tk 11, and the quantity demanded falls from 24 cups to 16 cups an hour. *Find:* the price elasticity of demand. *Formula:* E = %ΔQ ÷ %ΔP, with midpoint percentages.

> Each line of arithmetic is shown, with its reason.

*Steps.* First, the quantity. The change is 16 - 24 = -8 cups. The average is (24 + 16) ÷ 2 = 20 cups. So %ΔQ = -8 ÷ 20 × 100 = -40%. Second, the price. The change is 11 - 9 = Tk 2. The average is (9 + 11) ÷ 2 = Tk 10. So %ΔP = 2 ÷ 10 × 100 = +20%. Third, divide: E = -40 ÷ +20 = -2, and the size is 2. *Answer:* the price elasticity of demand is 2, so quantity demanded changes twice as fast as price. *Check:* a 20% rise in price led to a 40% fall in quantity, and 40 is larger than 20, so a result above 1 is sensible.

:pause 5.p1 | A good's price rises from Tk 8 to Tk 12, and the quantity demanded falls from 30 to 20. Find %ΔP, %ΔQ and E.

> You should now be able to turn a price change and a quantity change into one number.

*You should now be able to say* how a change in price and a change in quantity become one number: find each percentage change from the average of its old and new values, then divide quantity by price.

### A realistic example: the notebook

> The notebook schedule gives a realistic example with less tidy numbers.

> Recall: demand schedule, Chapter 4, section 4.1 'Quantity Demanded and the Law of Demand'.

:case Case file, illustrative. Meghna and Sons, a bookshop in Dhanmondi, Dhaka, records a demand schedule for its popular 200-page notebook by the rule quantity = 80 - price, with price in taka. The price falls from Tk 50 to Tk 40, and the quantity demanded rises from 30 to 40. By the midpoint method, the percentage change in quantity is 10 / 35 = 28.57%, and the percentage change in price is 10 / 45 = 22.22%. The price elasticity of demand is 1.29.

> The averages 35 and 45 come from the quantities and the prices.

Follow the arithmetic slowly. The two quantities are 30 and 40, so their average is 35, and the change of 10 gives 10 ÷ 35 = 28.57%. The two prices are 50 and 40, so their average is 45, and the change of 10 gives 10 ÷ 45 = 22.22%. Dividing, 28.57 ÷ 22.22 = 1.29. *Check:* quantity moved by a larger percentage than price, so the result must lie above 1, and it does.

> Five slips account for most wrong answers.

Common slips are few. Students divide price by quantity instead of quantity by price. They divide by the starting value in one place and by the average in another. They mix a figure in taka with a figure in units. They forget the units of time, comparing a weekly figure with a monthly one. And they report a negative sign in one answer and drop it in the next. Decide on the order and the sign rule before you begin.

> Before moving on: the notebook example gives 1.29.

*Before moving on.* The notebook's price elasticity of demand between Tk 50 and Tk 40 is 1.29. Always divide quantity by price, use midpoints for both, and keep the time period the same.

* * *

## 5.2 Reading the Result

> A single number is useful only if you know what it says.

A number such as 1.29 is useful only when you know what it says. The dividing line is 1, because 1 is the case where the two percentages are equal. Three cases follow, each with a name.

@ Elastic demand | Demand for which the percentage change in quantity is larger than the percentage change in price.

> Elastic demand has a result above 1: consumers respond strongly.

When the result is above 1, demand is **elastic demand**. It means demand for which the percentage change in quantity is larger than the percentage change in price. The notebook, at 1.29, is an example. The tea stall at 2 is another. The curve for such a good is flat, as the first figure below shows.

@ Inelastic demand | Demand for which the percentage change in quantity is smaller than the percentage change in price.

> Inelastic demand has a result below 1: consumers respond weakly.

When the result is below 1, demand is **inelastic demand**. It means demand for which the percentage change in quantity is smaller than the percentage change in price. Salt in our opening puzzle is a likely example: a price cut of one-fifth brings only a trifling rise in the quantity demanded. The curve for such a good is steep.

@ Unit elastic demand | Demand for which the percentage change in quantity equals the percentage change in price.

> Unit elastic demand has a result of exactly 1: the two percentages are equal.

When the result equals 1, demand is **unit elastic demand**. It means demand for which the percentage change in quantity equals the percentage change in price. Your pause question, with a result of 1, is an example. It is the dividing line between the other two cases.

> The axes show price and quantity demanded; each point is one pair.

To read the figure below, notice what the axes show. The vertical axis shows price, and the horizontal axis shows quantity demanded. Each point on a curve is one price with the quantity demanded at that price. Starting from the same point, a price fall of the same size moves the flat curve a long way to the right and the steep curve only a short way.

:fig Two demand curves through the same point: a flat curve for elastic demand and a steep curve for inelastic demand | ch05-fig01.svg

> Slope and elasticity are different things, as a straight line shows.

A warning follows. Elasticity is not the same as the slope of the curve. Along one straight demand curve, the slope never changes, yet the elasticity does. On the notebook schedule, the fall from Tk 60 to Tk 50 gives 2.2, the fall from Tk 50 to Tk 40 gives 1.29, and the fall from Tk 40 to Tk 30 gives 0.78. A single good can be elastic at high prices and inelastic at low prices.

> The three cases are compared in one table.

The table below compares the three cases. Read each row from left to right: the first column names the case, the second gives the size of the result, the third says which percentage is larger, and the fourth anticipates the test described next.

:table The three cases of price elasticity of demand
| Case | Size of result | Larger percentage | Effect of a price cut on money received |
| Elastic demand | Above 1 | Quantity | Rises |
| Unit elastic demand | Equal to 1 | Neither | Unchanged |
| Inelastic demand | Below 1 | Price | Falls |

@ Total revenue | Price multiplied by quantity sold.

> Total revenue is price times quantity, the money a firm receives from sales.

Why does the result matter to a firm? Because of **total revenue**, which means price multiplied by quantity sold. If a stall sells 10 cups at Tk 5, its total revenue is Tk 50. A price cut lowers the price paid for every unit but raises the number of units sold. Which effect wins depends on the elasticity.

> The total revenue test links the size of the result to the change in revenue.

The total revenue test says: if demand is elastic, a fall in price raises total revenue; if demand is unit elastic, total revenue does not change; if demand is inelastic, a fall in price lowers total revenue. A rise in price gives the opposite results. The notebook confirms the first rule, as the next record shows.

> The notebook's total revenue rises when its price falls.

:case Case file, illustrative. When the notebook's price falls from Tk 50 to Tk 40, total revenue rises from Tk 1,500 (Tk 50 × 30) to Tk 1,600 (Tk 40 × 40). The price elasticity of demand over this fall is 1.29, so demand is elastic.

> Along one schedule, revenue rises and then falls as the price keeps falling.

To read the next figure, look at the table on its left and the graph on its right. In the table, each row gives a price, the quantity demanded from the rule quantity = 80 - price, and total revenue. In the graph, the horizontal axis shows price, the vertical axis shows total revenue, and each point is one row of the table. Total revenue climbs as the price falls from Tk 60 to Tk 40, and then drops. The peak lies where demand changes from elastic to inelastic.

:fig The total revenue test: a table of prices, quantities and total revenue beside a graph of total revenue against price | ch05-fig02.svg

> Before moving on: the result is read against 1, and the revenue test follows from it.

*Before moving on.* A result above 1 is elastic demand, equal to 1 is unit elastic demand, and below 1 is inelastic demand. Total revenue is price times quantity. When demand is elastic a price cut raises it, and when demand is inelastic a price cut lowers it. The same good may be elastic in one price range and inelastic in another.

* * *

## 5.3 Factors Behind Elasticity

> Three questions help predict whether demand is elastic or inelastic.

Why is salt inelastic and a pair of shoes elastic? Three features of a good explain most cases. None of them gives a number; each tells you which side of 1 to expect.

> Many close substitutes make demand elastic.

The first feature is the availability of substitutes, which are other goods that can be used for the same purpose. A consumer who finds the price of one brand of tea too high can buy another brand, so demand for one brand is elastic. Demand for tea in general has fewer substitutes, so it is less elastic. The more narrowly a good is described, the more substitutes it has.

> Necessities tend to be inelastic and luxuries elastic.

The second feature is the difference between a necessity, which a household buys whatever the price, and a luxury, which it can easily do without. Salt, rice and basic medicines are necessities. Fashionable shoes and restaurant meals are luxuries. A word of caution: the same good can be a necessity for one household and a luxury for another, so this is a tendency, not a rule.

> Time and the share of income also matter.

The third feature has two parts. Time: consumers need time to find substitutes and change habits, so demand is usually less elastic soon after a price change than long after. Share of income: a good that takes a large part of a household's income, such as rent, makes consumers watch its price closely, while a pen takes so little that its price rarely matters. Both parts shift the result toward elastic as time passes or the share rises.

> Before moving on: substitutes, necessity and luxury, time and share of income.

*Before moving on.* Demand tends to be more elastic when close substitutes exist, when the good is a luxury, when consumers have time to adjust, and when the good takes a large share of income. Each is a guide to which side of 1 to expect.

* * *

## 5.4 Income and Cross Elasticity

> The same idea can measure responses to causes other than the good's own price.

The method is not limited to the good's own price. Quantity demanded also responds to consumers' income and to the price of other goods. Each response has its own measure, found in the same way.

> Recall: movement and shift, Chapter 4, section 4.2 'Movement and Shift'.

@ Income elasticity | The percentage change in quantity demanded divided by the percentage change in consumers' income.

> Income elasticity compares the response of quantity to a change in income.

**Income elasticity** means the percentage change in quantity demanded divided by the percentage change in consumers' income. A change in income shifts the demand curve rather than moving along it, which is why this measure is separate from the price measure. The sign matters here and is kept. A positive result means that more income raises the quantity demanded; a negative result means that it lowers it.

> A 10% rise in income lifts fiction by 15%.

:case Case file, illustrative. A rise of 10% in income lifts the quantity of fiction demanded by 15%. Income elasticity = 15% ÷ 10% = 1.5.

@ Cross elasticity | The percentage change in quantity demanded of one good divided by the percentage change in the price of another.

> Cross elasticity links the quantity of one good to the price of another.

**Cross elasticity** means the percentage change in quantity demanded of one good divided by the percentage change in the price of another. A positive result means the goods are substitutes, since a dearer rival sends consumers to the good. A negative result means the goods are used together, so a dearer partner reduces the use of both.

> A 10% dearer rival notebook lifts the shop's notebook by 4%.

:case Case file, illustrative. A rise of 10% in the price of a rival notebook raises the quantity demanded of the shop's notebook by 4%. Cross elasticity = 4% ÷ 10% = 0.4.

> Before moving on: income elasticity and cross elasticity use the same ratio.

*Before moving on.* Each measure divides a percentage change in quantity demanded by a percentage change in its cause. Income elasticity uses consumers' income; cross elasticity uses the price of another good. Their signs carry meaning.

* * *

## Worked Examples: Changing the Setting

> Two further examples change the period, the sign and the setting.

The first two examples are above: the tea stall and the notebook. The next two reshape the problem. Both follow the same order: Given, Find, Formula, Steps, Answer, Check.

> Rung 3: the periods differ, so one figure must be converted before dividing.

*Given:* a rice seller raises the price from Tk 80 to Tk 100 a kilogram. At Tk 80, households buy 30 kg a week; at Tk 100, they buy 100 kg a month. Take a month as four weeks. *Find:* the price elasticity of demand. *Formula:* E = %ΔQ ÷ %ΔP, with midpoint percentages. The two quantities are in different periods, and this is the slip to avoid.

> The steps convert first, then calculate.

*Steps.* Convert 100 kg a month to 100 ÷ 4 = 25 kg a week. Quantity: change = 25 - 30 = -5; average = 27.5; %ΔQ = -5 ÷ 27.5 × 100 = -18.18%. Price: change = +20; average = 90; %ΔP = 20 ÷ 90 × 100 = +22.22%. Divide: 18.18 ÷ 22.22 = 0.82. *Answer:* E = 0.82, so demand is inelastic. *Check:* total revenue per week is Tk 80 × 30 = Tk 2,400 before and Tk 100 × 25 = Tk 2,500 after. A price rise with inelastic demand raises revenue, and it did.

> Rung 4: a bus fare combines schedule reading, elasticity and the revenue test.

*Given:* a bus company's schedule shows 800 passengers a day at a fare of Tk 10, and 700 at a fare of Tk 12. The company asks whether raising the fare from Tk 10 to Tk 12 will increase its total revenue. *Find:* E and the change in total revenue. *Steps.* Quantity: change = -100; average = 750; %ΔQ = -13.33%. Price: change = +2; average = 11; %ΔP = +18.18%. E = 13.33 ÷ 18.18 = 0.73. Revenue: Tk 10 × 800 = Tk 8,000 before, Tk 12 × 700 = Tk 8,400 after. *Answer:* demand is inelastic and revenue rises by Tk 400. *Check:* the elasticity test and the direct multiplication agree, so the working is sound.

* * *

## Summary

> The chapter's main results in a few lines.

Price elasticity of demand is the percentage change in quantity demanded divided by the percentage change in price, found with midpoints. Above 1 is elastic demand, equal to 1 is unit elastic demand, below 1 is inelastic demand. The total revenue test links the result to the effect of a price change on money received. Substitutes, necessity, time and share of income guide prediction. Income elasticity and cross elasticity apply the same ratio.

## Think It Through

:q 5.t1 | A pharmacy sells a medicine with no substitute, and its price elasticity of demand is 0.3. The owner raises the price by 10%. Estimate the change in quantity demanded and say what happens to total revenue.
:q 5.t2 | Explain why a firm whose demand is inelastic might still hesitate to raise its price a great deal. Think of time and substitutes.

## Where People Go Wrong

> Four common misunderstandings, each corrected.

Many students believe that a steep curve and an inelastic good are the same thing, and that a flat curve always means elastic. Slope depends on the units on the axes; elasticity compares percentages. Along a straight line the slope is constant while elasticity changes from point to point. Students also believe that a negative result means demand is inelastic. The sign shows only that price and quantity move in opposite directions; the size alone tells you which case you have. A third error is to call a good elastic or inelastic everywhere; the result belongs to a price range, a period and a group of consumers. The last error is to use the total revenue test for a change in income. The test applies to the good's own price only.

## In History

> In 1973 oil prices rose fourfold, yet demand fell slowly.

In October 1973 the Yom Kippur War, which began on 6 October between Israel and Egypt and Syria, led Arab members of the Organization of the Petroleum Exporting Countries to announce cuts in production and an embargo on oil shipments to the United States and some other countries. The embargo lasted until March 1974. During this time the price of crude oil rose from about US$3 a barrel to nearly US$12, roughly four times.

> Consumers could not change quickly, so demand fell only slowly.

The rich countries did not respond with a matching fall in the quantity demanded. In the short run, households and firms could not change their cars, heating systems and machines, and there were few substitutes for petrol and heating oil. Demand was therefore strongly inelastic. In the years that followed, consumers bought smaller cars, firms improved their equipment, and new oil fields opened. Demand became more elastic as time passed, as section 5.3 would lead you to expect.

## Review Questions

:q 5.1 | Define price elasticity of demand in your own words, and say why percentages are used.
:q 5.2 | Why does the midpoint method give the same answer when a price rises as when it falls?
:q 5.3 | A price rises from Tk 20 to Tk 30 and the quantity demanded falls from 60 to 40. Calculate E and say whether demand is elastic, inelastic or unit elastic.
:q 5.4 | Using the notebook schedule, calculate E for the fall from Tk 40 to Tk 30, and apply the total revenue test.
:q 5.5 | A rise of 20% in income raises the quantity of mangoes demanded by 10%. Calculate income elasticity.
:q 5.6 | A rise of 5% in the price of tea lowers the quantity of sugar demanded by 3%. Calculate cross elasticity and say what the sign shows.
:q 5.7 | Give one reason why demand for a brand of tea is more elastic than demand for tea in general.

:read Alfred Marshall, Principles of Economics, 1890
