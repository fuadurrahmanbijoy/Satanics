:glossary 10
Production function | A rule showing the largest output that can be made from each combination of inputs. It records what is technically possible with the best known methods. Example: 1 oven and 2 helpers can make at most 100 loaves a day.
Short run | A period so short that at least one input, such as a machine, cannot be changed. It is not a fixed number of days; it is whatever period leaves an input fixed. Example: a baker can hire helpers but cannot install a new oven.
Long run | A period long enough for all inputs to be changed. Its length differs between firms. Example: given years, a baker can build a new bakery and buy more ovens.
Total product | The whole quantity of output produced with a given amount of inputs. Example: the binding workshop with 4 workers has a total product of 44.
Marginal product | The extra output from adding one more unit of an input, others held fixed. It equals the change in total product divided by the change in the input. Example: the fourth worker adds 44 - 36 = 8.
Average product | Total product divided by the number of units of the input used. It shows the output per unit. Example: 44 ÷ 4 = 11 with 4 workers.
Law of diminishing returns | Adding more of one input to fixed amounts of others will, after a point, add less and less to output. It belongs to the short run and does not say that total output falls. Example: each worker beyond the second in the workshop.
Returns to scale | The change in output when all inputs are increased in the same proportion. It may be increasing, constant or decreasing. Example: doubling workers and machines raised output from 24 to 60.
