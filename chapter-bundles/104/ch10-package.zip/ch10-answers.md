:answers 10
:a 10.p1 | Marginal product of the third helper = 18 - 12 = 6 loaves. Average product with 3 helpers = 18 ÷ 3 = 6 loaves.
:a 10.p2 | The 8 means the fourth worker adds 8 to total product (44 - 36). Average product with 4 workers is 44 ÷ 4 = 11.
:a 10.p3 | With some inputs fixed, extra units of one input eventually add less and less to output. The fixed input is the machine.
:a 10.t1 | The machine is already used to its limit and the bench is crowded, so the extra worker has no machine time to use. The cause is the fixed input, not the skill of the worker.
:a 10.t2 | Each extra worker adds less output for the same wage, so more worker-days, and more pay, are needed for each extra unit of output.
:a 10.1 | A production function is a rule showing the largest output that can be made from each combination of inputs. It records the best method known, not what a careless firm might produce.
:a 10.2 | In the short run at least one input is fixed; in the long run all inputs can be changed. A machine or an oven is a fixed input.
:a 10.3 | Marginal product: 30, 40, 30, 20. Average product: 30, 35, 33.33, 30.
:a 10.4 | The third worker's marginal product is 12, equal to the average of 12 for 2 workers, so the average does not change.
:a 10.5 | Output rises by less than the inputs (2.4 against 3): decreasing returns to scale.
:a 10.6 | Output rises by more than the inputs (2.6 against 2): increasing returns to scale.
:a 10.7 | The law changes one input and holds others fixed, and it belongs to the short run; returns to scale changes all inputs together, and it belongs to the long run. The law concerns the extra output; returns to scale compares proportional changes.
