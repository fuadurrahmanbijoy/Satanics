:chapter IV | Demand and the Demand Curve
:mood Why does a crowd gather round a stall when the price tablet changes?
:desc This chapter builds the central diagram of the book. It explains what buyers are willing and able to buy at each price, why a lower price brings a larger quantity, how to draw the demand curve, and what moves or shifts it. It ends with related goods and a few unusual cases.
:plate ch04-plate.svg | A Victorian fishmonger's stall, with price tablets and a crowd of buyers

> Two earlier ideas and one appendix help with this chapter.

*You will need* two ideas from earlier chapters: the fall of satisfaction with each extra unit, from Chapter 3 'Utility and Diminishing Marginal Utility', section 3.2 'The Law of Diminishing Marginal Utility'; and the habit of holding other conditions fixed, from Chapter 1 'What Economics Is', section 1.4 'Economic Laws'. Appendix A1 'Maths You Will Use' helps with reading a graph and with rearranging an equation.

> A fishmonger changes a price tablet, and the crowd responds.

Picture a fishmonger's stall in a Victorian market town, early on a Saturday morning. Along the front of the stall stand small tablets, each marking the price of one kind of fish. A crowd of buyers moves slowly past. At nine o'clock the fishmonger lowers the tablet for the herring. Within minutes the crowd thickens, baskets fill, and the tray empties faster than before. At noon the tablet is raised again, and the crowd moves on to the cheaper trays.

> The crowd does not obey the fishmonger's orders, yet it behaves in a regular way.

Nobody ordered the buyers to do this. Each acted for private reasons, and each had a different purse and a different taste. Yet the crowd as a whole behaved in a way that the fishmonger could predict: a lower price brought more buyers, and a higher price sent them away. How can millions of separate choices form a pattern that is so regular? And can we describe the pattern exactly, so that any firm could use it?

> The chapter gives that pattern a name, a table and a picture.

In this chapter we build the answer in small steps. We name what buyers do, record it in a table, and draw it as a curve. Then we ask what makes the curve move, and we meet some goods that behave in unusual ways. Many students find the central diagram hard at first, because two different changes both seem to alter the same picture. We therefore go slowly, and we separate the two changes with care.

* * *

## 4.1 Quantity Demanded and the Law of Demand

> Begin with a question: how many notebooks would you buy at each price?

@! Go slowly here.

Begin with a question from your own life. A plain 200-page notebook costs Tk 60. How many would you buy this week? Now suppose the price falls to Tk 20. Would you buy the same number? Most people answer that they would buy more at the lower price, and fewer at the higher price. The number of units that buyers choose to buy at one particular price in a period is called the quantity demanded. It is a single number, tied to a single price.

@ Demand | The quantities of a good that buyers are willing and able to buy at each price in a period.

> Demand is the whole set of prices and quantities, not one number.

Economists use the word **demand** for something larger. Demand means the quantities of a good that buyers are willing and able to buy at each price in a period. Notice the two conditions, willing and able. A wish without money is not demand, and money without a wish is not demand either. For the notebook, demand is the full list: so many at Tk 60, so many at Tk 50, so many at Tk 40, and so on. One entry in the list is a quantity demanded. The whole list is demand.

@ Demand | Word in use. In daily life, demand means a strong request or order, as in a demand for payment. In economics, demand is the whole list of quantities buyers will buy at each price.

> In this book, demand alone always means the whole list.

The everyday word needs care here. In daily speech people say that "demand rose" when they mean that more was bought. This book keeps two words apart. Quantity demanded means one quantity at one price. Demand alone means the whole list of prices and quantities, which the next pages record in a table and then draw as a line.

@ Demand schedule | A table showing the quantity demanded at each price.

> A demand schedule is a table of prices and the quantities demanded at them.

The simplest way to record demand is a table. A **demand schedule** is a table showing the quantity demanded at each price. We now use the case of the shop. The next paragraph is a record, and its figures are fixed.

> The case file records the weekly demand for the shop's notebook.

:case Case file, illustrative. Meghna and Sons records the weekly demand for its 200-page notebook. At a price of Tk 60 the quantity demanded is 20 notebooks; at Tk 50, 30; at Tk 40, 40; at Tk 30, 50; at Tk 20, 60. The quantity demanded equals 80 minus the price in taka.

> The same record is laid out as a table.

:table Weekly demand schedule for the 200-page notebook
| Price (Tk) | Quantity demanded (notebooks a week) |
| 60 | 20 |
| 50 | 30 |
| 40 | 40 |
| 30 | 50 |
| 20 | 60 |

> Each row pairs one price with one quantity demanded.

To read a row, take the line for Tk 40. It says that at a price of Tk 40, buyers choose to buy 40 notebooks a week. Read down the table and notice the pattern: as the price falls by Tk 10 each time, the quantity demanded rises by 10 each time. The rule in the case file, quantity equals 80 minus the price, gives the same numbers: 80 minus 40 is 40.

@! Go slowly here.
@ Law of demand | When the price of a good rises, the quantity demanded falls, if other conditions stay the same.

> The pattern in the table is the law of demand.

The pattern has a name. The **law of demand** says that when the price of a good rises, the quantity demanded falls, if other conditions stay the same. The final clause matters. Income, tastes and the prices of other goods must stay fixed, or we cannot tell whether a change in the quantity bought came from the price.^1 The law also works in the other direction: when the price falls, the quantity demanded rises.

^1: Recall: ceteris paribus, which means other things remaining equal, Chapter 1, 'What Economics Is', section 1.4 'Economic Laws'.

> Two reasons explain why a lower price brings a larger quantity demanded.

Why should buyers behave in this way? Two reasons are enough for now. The first links to the last chapter.^2 Each extra notebook gives a buyer less satisfaction than the one before, so a buyer will take a further notebook only if its price is lower. The second reason is that a lower price brings in new buyers who could not afford the good before, and it tempts existing buyers to find new uses. A cheap notebook may become a diary, a ledger and a gift.

^2: Recall: diminishing utility, Chapter 3, 'Utility and Diminishing Marginal Utility', section 3.2 'The Law of Diminishing Marginal Utility'.

:pause 4.p1 | At a price of Tk 50 the quantity demanded is 30 notebooks. Without drawing anything, say what the quantity demanded is at Tk 30, and state in one sentence the law of demand that your answer shows.

@ Demand curve | A line on a graph showing the quantity demanded at each price.

> A demand curve draws the table as a line on a graph.

A table is exact, but a picture shows the pattern at a glance. A **demand curve** is a line on a graph showing the quantity demanded at each price. To read the graph, notice its two axes, which are lines at right angles.^3 The vertical axis shows the price in taka. The horizontal axis shows the quantity demanded in notebooks a week. A point on the graph means: at this price, buyers choose this quantity.

^3: See Appendix A1 'Maths You Will Use', section A1.5 'Reading a Graph', for axes, points and slope.

:fig The demand curve for the notebook, with a movement along it from Tk 50 to Tk 40 | ch04-fig01.svg

> The line slopes downward, because a lower price goes with a larger quantity.

Read the line from the top left to the bottom right. At the top, the price is high and the quantity is small. At the bottom, the price is low and the quantity is large. We call it a curve although in this case it is a straight line, because the word covers lines of every shape. The downward slope is the law of demand drawn as a picture: lower price, larger quantity demanded. In the picture, the short bold part between the points for Tk 50 and Tk 40 will be used in the next section.

> The section closes with the four ideas in a few lines.

*Before moving on.* Quantity demanded is one number at one price. Demand is the whole list of prices and quantities, which the demand schedule records and the demand curve draws. The law of demand says that, other conditions staying the same, a lower price brings a larger quantity demanded. You should now be able to say why the curve slopes downward.

## 4.2 Movement and Shift

> Two different changes can alter the picture, and they must be kept apart.

The fishmonger faced two different events. At nine o'clock his own price fell, and more fish sold. Suppose that on another Saturday a rival stall across the street cut its price, and fewer buyers came to him even though his tablet had not changed. Both events changed how much fish he sold. Are they the same kind of change? They are not, and the difference is the key to this chapter.

@! Go slowly here.

> A change in the price of the good moves us along one curve.

First, the price of the good itself changes. The notebook falls from Tk 50 to Tk 40. Buyers respond by buying more, and the quantity demanded rises from 30 to 40 notebooks a week. On the graph, the point moves along the same line, from the point for Tk 50 to the point for Tk 40. We call this a movement along the curve. The curve itself does not change position, because the whole list of prices and quantities is the same list as before.

> Five other conditions decide where the whole curve lies.

Second, something other than the price changes. The curve was drawn with other conditions held fixed, and these conditions are called the determinants of demand. When one of them changes, buyers want different quantities at every price, and the curve must be redrawn in a new position. The table below lists the usual determinants, with an example for the notebook. We introduce the table in words first: each row names one determinant, and the middle column gives a notebook example.

:table The determinants of demand, with a notebook example
| Determinant | Example for the notebook | Effect on demand |
| Buyers' incomes | Families have more money to spend | Rises |
| Prices of related goods | A rival notebook becomes cheaper | Falls |
| Tastes | Schools ask pupils to keep notebooks | Rises |
| Number of buyers | A new college opens nearby | Rises |
| Expectations | Buyers expect a price rise next month | Rises now |

> Read each row as a change of condition and the resulting change of demand.

To read a row, take the second line: when a rival notebook becomes cheaper, some buyers leave, and demand for our notebook falls. The word *falls* here means that fewer notebooks are wanted at every price, not only at one price.

@! Go slowly here.

> A change in a determinant shifts the whole curve.

When a determinant changes, the whole curve moves to a new position. We call this a shift of the curve, which some books call a change in demand. This book uses the word shift. The case file gives a precise example.

> The case file records a shift caused by a rival's price.

:case Case file, illustrative. The price of a rival notebook falls by Tk 10. Weekly demand for the shop's notebook moves down by 5 at every price. At Tk 60 the quantity demanded becomes 15; at Tk 50, 25; at Tk 40, 35; at Tk 30, 45; at Tk 20, 55.

> The new curve lies to the left of the old curve.

The new quantities are 5 smaller than the old ones in every row, so the curve moves to the left. A move to the left means a smaller quantity at every price. A move to the right means a larger quantity at every price. The picture shows the old curve and the new curve, and the arrow shows the direction.

:fig The demand curve after a shift to the left, caused by a cheaper rival notebook | ch04-fig02.svg

> Both curves slope downward, and the gap between them is 5 notebooks.

Read the picture along a horizontal line at Tk 40. The old curve meets this line at 40 notebooks. The new curve meets it at 35. The horizontal gap between the two curves is the same at every price: 5 notebooks. Prices on the vertical axis did not change, so the shift is not a movement along either curve.

:pause 4.p2 | Meghna and Sons raises the price of the notebook from Tk 40 to Tk 50. Is this a movement along the curve or a shift? Give one reason.

> A short test separates the two changes.

*Before moving on.* Ask one question: what changed? If the price of the good itself changed, there is a movement along the curve. If a determinant changed, there is a shift of the whole curve. You should now be able to say, for any change, which of the two it is.

## 4.3 Related and Unusual Goods

> Some changes in demand come from the price of another good.

A shift can come from a change in the price of another good, and the effect depends on how the two goods are related. The rival notebook in the case file is the first kind of relation. A shopper who finds the rival cheaper may switch to it, and our notebook loses buyers. The second kind of relation works the other way. We look at both kinds now, then at income, and then at four unusual cases.

@ Substitute goods | Goods that can replace each other, so a price rise for one raises demand for the other.

> Substitute goods can replace each other.

Two notebooks of the same size and quality are **substitute goods**. Substitute goods are goods that can replace each other, so a price rise for one raises demand for the other. If the rival notebook becomes dearer, some buyers move to ours, and demand for ours shifts to the right. The case file showed the reverse: a price fall for the rival shifted our demand to the left. Tea and coffee, or buses and trains, are other pairs.

@ Complementary goods | Goods used together, so a price rise for one lowers demand for the other.

> Complementary goods are used together.

Some goods are not rivals but partners. **Complementary goods** are goods used together, so a price rise for one lowers demand for the other. A pen and a notebook are complementary goods. If pens become dearer, fewer people write, and fewer notebooks are wanted at every price. Tea and sugar, and a lamp and its oil, are other pairs. Substitutes move in opposite directions, and complements move in the same direction, as the table below summarises in words first.

:table How a price rise for one good changes demand for another
| Relation | Example pair | Price of first good | Demand for second good |
| Substitute goods | Our notebook and a rival notebook | Rises | Rises |
| Complementary goods | Pen and notebook | Rises | Falls |

> Read each row as a price change for the first good and its effect on the second.

To read the second row, take the pair of pen and notebook. When the price of the pen rises, demand for the notebook falls. Be careful with direction: the effect on the second good is a shift of its curve, not a movement along it.

@ Normal good | A good for which demand rises when buyers' incomes rise.

> A normal good is bought more when incomes rise.

Income is another determinant. A **normal good** is a good for which demand rises when buyers' incomes rise. Notebooks are a normal good, because families with more money buy more of them. Most goods behave in this way. A few goods behave in the opposite way, and demand for them falls as incomes rise, because buyers move to better goods; we do not name them here.

@ Normal | Word in use. In daily life, normal means usual or ordinary. In economics, a normal good is one whose demand rises with income.

> The economic word normal has a narrow meaning.

The word needs care. A normal good is not a usual good, nor an average one. It is any good whose demand rises when buyers' incomes rise. A luxury can be a normal good, and so can a basic good.

@ Giffen good | A rare, very basic good for which quantity demanded rises when its price rises.

> A Giffen good breaks the law of demand, but it is rare.

The law of demand has a famous exception. A **Giffen good** is a rare, very basic good for which quantity demanded rises when its price rises. Alfred Marshall, an English economist, wrote in 1890 that Sir Robert Giffen, a Victorian statistician, had noticed such behaviour among very poor households that spent most of their money on bread. When bread became dearer, the argument runs, they could no longer afford meat, and so they bought more bread. Whether this really happened is debated, and clear modern cases are few.

:fig A Giffen-type curve slopes upward, in contrast with the usual curve | ch04-fig03.svg

> The Giffen-type curve slopes upward, against the usual downward slope.

The picture contrasts the usual curve, which slopes downward, with a Giffen-type curve, which slopes upward. On the upward line, a higher price goes with a larger quantity demanded. The numbers on this picture are not real data; it shows only the shape. Note one fact that keeps the law of demand valuable: the Giffen good is a rare, special case, and the law holds for almost every good that you will meet.

@ Snob effect | A fall in demand for a good because many other people now buy it.

> The snob effect reduces demand when many others buy.

Two further cases depend on what other buyers do. The **snob effect** is a fall in demand for a good because many other people now buy it. A buyer who values owning something rare may leave a good once it becomes common. A scarf that a few people wore as a mark of taste loses its appeal when every street shows it.

@ Bandwagon effect | A rise in demand for a good because many other people buy it.

> The bandwagon effect raises demand when many others buy.

The **bandwagon effect** is the opposite: a rise in demand for a good because many other people buy it. A mobile phone that all of a buyer's friends use becomes more attractive to that buyer, because it is easier to share messages and games. Both effects shift the curve, since they come from other buyers' choices and not from the good's own price.

> The section closes with the pairs and the exceptions.

*Before moving on.* Substitute goods replace each other, and complementary goods are used together. A normal good is bought more as incomes rise. A Giffen good is a rare exception to the law of demand, and the snob and bandwagon effects show that the choices of other buyers can shift demand. You should now be able to name one pair of each kind.

## Worked Case: Using the Notebook Demand Schedule

> Two links let us calculate any quantity or price from the demand rule.

The case file gives a rule: the quantity demanded equals 80 minus the price in taka. In symbols, Q = 80 − P, where Q is the quantity demanded in notebooks a week and P is the price in taka. Rearranged, P = 80 − Q.^4

^4: Appendix A1 'Maths You Will Use', section A1.3 'Rearranging an Equation', shows how to move a term across the equals sign.

> The first example is a clean calculation of a quantity.

**Example 1.** *Given:* Q = 80 − P. *Find:* the quantity demanded when the price is Tk 45. *Formula:* quantity demanded equals 80 minus the price. *Steps:* Q = 80 − 45 = 35 notebooks a week. *Answer:* at Tk 45, buyers choose 35 notebooks a week. *Check:* 35 lies between 30 (at Tk 50) and 40 (at Tk 40) in the table, as it should for a price between Tk 50 and Tk 40.

> The second example finds a price and then follows a shift.

**Example 2.** *Given:* the old rule Q = 80 − P, and the new rule after the rival's price fall, Q = 75 − P. *Find:* the price at which buyers choose 25 notebooks under each rule, and the change in the quantity demanded at Tk 40. *Formula:* P = 80 − Q for the old rule, and P = 75 − Q for the new rule. *Steps:* old rule, P = 80 − 25 = Tk 55; new rule, P = 75 − 25 = Tk 50; at Tk 40 the old quantity is 80 − 40 = 40 and the new quantity is 75 − 40 = 35, a change of 40 − 35 = 5. *Answer:* 25 notebooks are chosen at Tk 55 before the shift and at Tk 50 after it, and at Tk 40 the quantity demanded is 5 notebooks lower. *Check:* the shift is 5 at every price, as the case file states.

> Classification of a change as a movement or a shift is a matter of asking what changed.

**Worked classification.** *Situation:* three events occur in one month. The shop lowers its notebook price from Tk 50 to Tk 40. A rival lowers its price by Tk 10. A new college opens nearby. *Question:* which events are movements and which are shifts? *Reasoning:* in the first event, the price of the good itself changed. In the second, the price of a related good changed. In the third, the number of buyers changed. *Conclusion:* the first is a movement along the curve; the second and third are shifts. *Check:* only the first event changes the price on the vertical axis for our own notebook.

> Four common slips spoil these answers.

*Common slips.* Students often call a price change a shift. They mix the sides of the formula, using Q = 80 − P when they need P = 80 − Q. They forget units, and they treat a fall in demand as a fall in the quantity demanded at only one price.

## Summary

> The chapter's main ideas in a few lines.

Demand is the set of quantities buyers are willing and able to buy at each price, and a quantity demanded is one entry in that set. The law of demand says that, other conditions staying the same, a lower price brings a larger quantity demanded, so the demand curve slopes downward. A change in the price of the good is a movement along the curve. A change in a determinant is a shift of the curve. Substitute and complementary goods, normal goods, and the Giffen, snob and bandwagon cases show how demand depends on other goods, incomes and other buyers.

## Think It Through

> Two problems that apply the chapter to new settings.

:q 4.t1 | A jeweller finds that a certain luxury ring sells more when the price rises. Give two reasons why a buyer might behave in this way, and say whether the case breaks the law of demand.

:q 4.t2 | A bus fare rises, and at the same time the price of petrol falls. For bus travel, say which change is a movement along the curve and which is a shift, and give the direction of the shift.

## Where People Go Wrong

> A shift is often confused with a movement.

*Error 1: "A fall in the price of the good shifts its curve."* This is wrong. A fall in the price of the good moves the point along the same curve. Only a change in a determinant shifts the curve.

> Demand is not the same as quantity demanded.

*Error 2: "Demand and quantity demanded mean the same."* This is wrong. Quantity demanded is one number at one price. Demand alone is the whole list of prices and quantities.

> The law needs other things to stay equal.

*Error 3: "Sales rose after the price rose, so the law of demand fails."* This may be wrong. Incomes, tastes or the price of a rival may also have changed, and these shift the curve. The law speaks only of the effect of the good's own price when other conditions stay the same.

> Wanting is not the same as demanding.

*Error 4: "A buyer who wishes for a good demands it."* This is wrong. Demand needs both the will and the ability to pay.

## In History

> A French mathematician drew the first demand curve.

In 1838, the French mathematician Antoine Augustin Cournot, who lived from 1801 to 1877, published *Recherches sur les principes mathématiques de la théorie des richesses*, which is known in English as *Researches into the Mathematical Principles of the Theory of Wealth*. In its fourth chapter, titled in English "Of the law of demand", Cournot wrote demand as a function of price: the quantity sold depends on the price. He treated it as a fact of experience that the function falls as the price rises, and he drew it as a curve with price and quantity as its two axes.

> The work was ignored for years, but its method became standard.

Cournot's book received hardly any response when it appeared, and the reading public of the 1830s had little interest in economics written with algebra and diagrams. Later economists, among them Léon Walras of Lausanne, drew on his ideas. Today every textbook, including this one, draws the demand curve in the way that Cournot first did.

## Review Questions

> Seven questions that check the chapter's ideas.

:q 4.1 | Plot the demand schedule of the notebook from the case file on a graph, with price on the vertical axis. Say what the slope of the line shows.

:q 4.2 | After the rival's price fall, the quantities demanded at Tk 60, 50, 40, 30 and 20 are 15, 25, 35, 45 and 55. Plot the new curve on the same graph as the old one. Then draw a third curve that shows a rise in demand of 10 at every price, and give its quantity at Tk 40.

:q 4.3 | Classify each change as a movement along the curve or a shift of the curve: (a) the notebook price falls from Tk 60 to Tk 50; (b) pens become cheaper; (c) incomes of students fall; (d) the shop lowers the notebook price from Tk 40 to Tk 30.

:q 4.4 | Using Q = 80 − P, find the quantity demanded at Tk 35 and the price at which the quantity demanded is 55.

:q 4.5 | Name a pair of substitute goods and a pair of complementary goods. For each pair, say how a price rise for the first good changes demand for the second.

:q 4.6 | Define a Giffen good, and say why it is not the usual case.

:q 4.7 | A new college opens near the shop, and the price of the notebook is unchanged. Say what happens to demand, and explain which determinant has changed.

:read Antoine Augustin Cournot, Researches into the Mathematical Principles of the Theory of Wealth, 1838
:read Alfred Marshall, Principles of Economics, 1890
