:answers 04
:a 4.p1 | 50 notebooks. A lower price (Tk 30 against Tk 50) brings a larger quantity demanded, which is the law of demand.
:a 4.p2 | A movement along the curve, because the price of the good itself changed, and the quantity demanded falls from 40 to 30.
:a 4.t1 | Buyers may take a high price as a sign of quality or rank, or may expect the price to rise further. Their tastes or expectations then change with the price, so other conditions are not equal. A ring is not a very basic good, so it is not a Giffen good.
:a 4.t2 | The fare rise is a movement along the bus demand curve, with a smaller quantity demanded. Cheaper petrol makes car travel cheaper, and cars are a substitute for buses, so demand for bus travel shifts to the left.
:a 4.1 | The points are (20, Tk 60), (30, Tk 50), (40, Tk 40), (50, Tk 30), (60, Tk 20), with quantity on the horizontal axis. The line slopes downward: each Tk 10 fall in price adds 10 notebooks, so a lower price goes with a larger quantity demanded.
:a 4.2 | The new curve lies 5 notebooks to the left of the old one at every price. A rise of 10 on the old curve gives Q = 90 − P, so the quantity at Tk 40 is 50 (40 + 10).
:a 4.3 | (a) movement; (b) shift, to the right, since pens and notebooks are used together; (c) shift, to the left; (d) movement.
:a 4.4 | At Tk 35, Q = 80 − 35 = 45 notebooks. For Q = 55, P = 80 − 55 = Tk 25.
:a 4.5 | Substitute goods: tea and coffee; a price rise for tea raises demand for coffee. Complementary goods: pens and notebooks; a price rise for pens lowers demand for notebooks.
:a 4.6 | A Giffen good is a rare, very basic good for which quantity demanded rises when its price rises. It is not the usual case because for almost every good a higher price lowers the quantity demanded.
:a 4.7 | Demand rises, so the curve shifts to the right. The number of buyers has changed, and that is a determinant of demand.
