:answers 01
:a 1.p1 | (a) Positive: the shop's staff records can confirm the number 7. (b) Normative: whether the shop ought to employ an eighth person depends on values and judgement, and facts alone cannot settle it.
:a 1.t1 | The claim ignores that another condition changed in the same month, since free notebooks reduce the need to buy. Ceteris paribus requires all other things to stay the same, and here they did not. We cannot tell how much of the fall came from the price.
:a 1.t2 | Economic laws describe how people usually behave, so they state tendencies and not certainties. Exactness is not the test of usefulness; a usual pattern can still guide a seller or a government. Used with ceteris paribus, such a law separates one cause from many.
:a 1.1 | (a) Positive: staff records can test it. (b) Normative: it says what ought to be. (c) Positive: the accounts can confirm the figure. (d) Normative: should signals a value judgement.
:a 1.2 | (a) Micro: one firm. (b) Macro: the general price level. (c) Micro: one consumer. (d) Macro: a total for the whole economy.
:a 1.3 | Her wants cost Tk 60 + Tk 60 + Tk 30 = Tk 150, but she has only Tk 100. Wants exceed means by Tk 50, so she must choose and give up something.
:a 1.4 | Consumption, production, exchange and distribution. Examples: a reader takes a book home (consumption); a printer makes the book (production); the shop buys it from the printer (exchange); the shop's income pays staff and owner (distribution).
:a 1.5 | Ceteris paribus means all other things stay the same. An economic law states a usual tendency of people, while a law of nature, such as the fall of a stone, describes things that do not choose and holds exactly.
