:answers 09
:a 9.p1 | Buyers want 80 − 40 = 40 notebooks, and firms offer 40 notebooks. The two quantities are equal.
:a 9.p2 | Both rise. The shift creates excess demand at the old price, the price climbs, and firms offer more along the supply curve.
:a 9.t1 | At Tk 30, buyers want 50 notebooks and firms offer 30, so excess demand is 20. Buyers who obtain a notebook gain a lower price; the 20 who cannot buy, and the firms who cannot charge more, lose.
:a 9.t2 | She describes time. This month supply is inelastic because the crop cannot grow faster; next year it is more elastic because she can plant more.
:a 9.1 | ΔQ = 20, average Q = 100, so 0.2. ΔP = 10, average P = 25, so 0.4. Elasticity = 0.2 ÷ 0.4 = 0.5. Supply is inelastic.
:a 9.2 | ΔQ = 100, average Q = 450, so 0.222. ΔP = 30, average P = 115, so 0.261. Elasticity = 0.222 ÷ 0.261 = about 0.85.
:a 9.3 | ΔQ = 60, average Q = 300, so 0.2. ΔP = 10, average P = 55, so 0.182. Elasticity = 0.2 ÷ 0.182 = 1.1. Supply is elastic.
:a 9.4 | Before: 60 − price = 2 × price, so price = 20 and quantity = 40. After: 90 − price = 2 × price, so price = 30 and quantity = 60.
:a 9.5 | 90 − price = 2 × price − 30, so 120 = 3 × price, price = 40, quantity = 50. Compared with the demand shift only (price 30, quantity 60), the price is higher and the quantity is lower.
