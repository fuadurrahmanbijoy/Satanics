:glossary 09
Elasticity of supply | The percentage change in quantity supplied divided by the percentage change in price. It tells us how strongly firms respond to a price change. If a 10% rise in price raises quantity supplied by 5%, the elasticity of supply is 0.5.
Competitive market | A market with many buyers and sellers, none of whom can set the price. Each one must accept the price that the whole market produces. A street of tea stalls selling the same tea is a small example.
Equilibrium price | The price at which the quantity buyers want equals the quantity sellers offer. At this price neither side has a reason to change its plans, so the price stays still. In the notebook market it is Tk 40.
Excess demand | A situation in which buyers want more than sellers offer at a price. Some buyers cannot obtain the good, so they offer more money and push the price up. In the notebook market at Tk 30, buyers want 50 and firms offer 30.
Excess supply | A situation in which sellers offer more than buyers want at a price. Some goods stay unsold, so sellers cut the price and push it down. In the notebook market at Tk 50, firms offer 50 and buyers want 30.
