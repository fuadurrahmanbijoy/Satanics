:answers 07
:a 7.p1 | No. Q has the same notebooks as P but 2 more pens, so Q is better. Two combinations on one curve must please equally.
:a 7.p2 | As she gives up pens, those that remain become more precious to her, and as notebooks pile up each extra one is worth less. So she parts with fewer pens for each extra notebook.
:a 7.t1 | The old combination now costs 6 × Tk 40 + 8 × Tk 10 = Tk 240 + Tk 80 = Tk 320, which is less than Tk 400, so she can still buy it and has Tk 80 left. She can therefore reach a higher curve, so she is better off. The exact new best point depends on her curves.
:a 7.t2 | Suppose two curves cross at X. Take A on one curve to the right of X, and B on the other curve directly above A, with the same notebooks and more pens. B is better than A. But A and B each please equally with X, so they would be equal. The two statements clash, so the curves cannot cross.
:a 7.1 | Tk 200 ÷ Tk 40 = 5 notebooks, or Tk 200 ÷ Tk 20 = 10 pens. Two others: 2 notebooks and 6 pens (80 + 120 = 200); 3 notebooks and 4 pens (120 + 80 = 200).
:a 7.2 | Pens given up: 8 − 5 = 3. Notebooks gained: 8 − 6 = 2. Rate = 3 ÷ 2 = 1.5 pens per notebook. It is smaller than 3, because she now holds fewer pens and more notebooks, so she gives up fewer pens for each notebook.
:a 7.3 | Notebooks: 450 ÷ 50 = 9. Pens: 450 ÷ 30 = 15. Steepness: 50 ÷ 30 = 1.67 pens per notebook. Check: 9 × 50 = Tk 450.
:a 7.4 | Notebooks: 400 ÷ 50 = 8, down from 10. Pens: 400 ÷ 20 = 20, unchanged. The line turns inwards around the pen point and becomes steeper: 50 ÷ 20 = 2.5 pens per notebook.
:a 7.5 | No. The price ratio is 2, but her rate is 4: she would give up 4 pens for one more notebook while the market asks only 2. She gains by buying more notebooks and fewer pens, moving towards 6 notebooks and 8 pens.
:a 7.6 | 2 pens × Tk 20 = Tk 40. This equals the price of Tk 40, so her consumers' surplus on that last notebook is Tk 40 − Tk 40 = 0.
