:chapter XVI | Interest and Profit
:mood Why is money paid to wait, and who deserves what is left at the end?
:desc Lenders are paid for letting others use their money, and owners are paid, sometimes, for taking chances. This chapter explains what sets the rate of interest, separates two meanings of profit, and shows why profit arises at all.
:plate ch16-plate.svg | A bank manager and a farmer across a desk, with a bond and an inkwell between them

:box YOU WILL NEED
Chapter 15, 'Rent and Wages', section 15.1, 'Rent'; Chapter 11, 'Costs of Production', section 11.1, 'Explicit and Implicit Costs'; Chapter 13, 'Market Structure and Perfect Competition', section 13.3, 'Equilibrium of Firm and Industry'; and Appendix A1, 'Maths You Will Use'.

> A neighbour with spare money must decide whether to lend it for nothing.

In spring, a farmer needs Tk 100,000 to buy seed and tools. His neighbour has exactly that sum saved. She has three choices. She can keep the money in a box, give it to him for nothing, or hand it over and ask for more money back after the harvest. Most neighbours choose the third. Why do they ask for more, and how much more is fair?

> A second puzzle asks whether the money left after repayment is truly a gain.

A second puzzle follows the farmer to the autumn. He sells the harvest, repays the loan with the extra amount, and has Tk 20,000 left. Is that Tk 20,000 a gain? Not necessarily. If he could have earned more by working for another farmer, the Tk 20,000 may be less than he gave up. Both puzzles ask the same thing: what is a fair payment for money, and what is a fair reward for running a business?

> This chapter studies the price of money and the reward of the owner.

We study two payments in this chapter. The first is the payment for the use of money, which is called interest. The second is the reward of the person who runs the firm and takes the chances, which is called profit. We use the shop of Meghna and Sons and a famous lender of Bangladesh as our examples.

* * *

## Interest

> A friendly loan shows why a lender wants more back than was lent.
@! Go slowly here.

Begin with a loan between friends. You lend a friend Tk 1,000 today, and he promises to repay in one year. During that year you cannot spend the money. You also run a small risk that he will not repay. Most lenders will not accept Tk 1,000 back, because they would be worse off than if they had kept the money. They ask for a little more, perhaps Tk 1,100. The extra Tk 100 is the lender's reward for waiting and for taking the risk.

> Interest is the price paid for the use of money over time.
@ Interest | Word in use. In daily life, interest often means curiosity or attention, as in an interest in music. In economics, it means a payment for the use of money.
@ Interest | The payment a borrower makes to a lender for the use of money over time.

The extra Tk 100 has a name. **Interest** is the payment a borrower makes to a lender for the use of money over time. The payment is stated as a rate, which is the interest for one year divided by the sum borrowed, written as a per cent. In the friend's loan, Tk 100 on Tk 1,000 is a rate of 10 per cent a year. Interest is like the rent of land, which is a payment for the use of something owned by another person.^1

^1: Rent as a payment for the use of land is taught in Chapter 15, 'Rent and Wages', section 15.1 'Rent'. Interest is the matching payment for the use of money.

> The bank's loan to the shop is an example of interest in the case file.

:case Case file, illustrative. Meghna and Sons holds a bank loan of Tk 600,000. The rate of interest is 11 per cent a year. Interest for one year is therefore Tk 66,000. The loan is an explicit cost of the shop, because the money is paid to an outsider, the bank.

> The rate of interest is set where the wishes of savers and borrowers meet.
@ Loanable funds | The money that savers offer and borrowers demand at each interest rate.

Why is the rate 11 per cent and not 5 or 20? One answer treats money as a good that is bought and sold. **Loanable funds** are the money that savers offer and borrowers demand at each interest rate. Savers are people and firms with money they do not need now. Borrowers are people and firms that want money to spend now. The loanable funds theory says that the rate of interest is the price at which the funds offered equal the funds demanded.

> Borrowers want more at a low rate, and savers offer more at a high rate.

The first figure below shows the idea. To read it, look at the horizontal axis, which measures loanable funds in taka, and the vertical axis, which measures the rate of interest in per cent a year. The falling line shows that borrowers want more funds when the rate is low, because borrowing is cheap. The rising line shows that savers offer more funds when the rate is high, because waiting is better rewarded. The lines cross at one rate. At that rate, the funds that borrowers demand equal the funds that savers offer.

:fig Demand for and supply of loanable funds, and the rate of interest where they meet | ch16-fig01.svg

> If savers offer more, the rate falls, and if borrowers want more, the rate rises.

The theory predicts how the rate moves. If people begin to save more, the rising line moves to the right, and the rate falls. If firms want to borrow more to build factories, the falling line moves to the right, and the rate rises. Many students find it odd that a rate can be a price. The oddity disappears when you remember that the thing being bought is the use of money for a year.

> A second theory says that people hold money because holding it is useful.
@ Liquidity preference | The wish of people to hold money in cash form rather than lend it.

A second theory looks at the other side of the choice. **Liquidity preference** is the wish of people to hold money in cash form rather than lend it. Cash can be spent at once, which is useful. John Maynard Keynes, a British economist, argued in 1936 that people hold cash to pay for daily purchases, to be ready for emergencies, and to wait for better chances to buy assets. A lender who gives up cash loses these benefits. Interest is the reward that persuades people to part with cash.

> Both theories explain interest, and neither is complete.

Both theories have limits. The loanable funds theory stresses savers and borrowers. The liquidity preference theory stresses the supply of money and the wish to hold it. A country's central bank, such as Bangladesh Bank, also influences rates through its policy. In practice, economists use both theories together.

> Different loans carry different rates, because they differ in risk, length and cost.

Rates differ from loan to loan, even on the same day. A loan to a small trader with no property carries more risk than a loan to a large firm, so the lender asks a higher rate. A loan for ten years ties up money longer than a loan for ten weeks. A very small loan costs almost as much to administer as a large one, which raises its rate. In some countries, including Bangladesh, Islamic banks avoid a fixed rate of interest and share the results of the venture with the borrower instead.

> Interest looks different to the lender, the borrower and the owner of a firm.

The viewpoint changes the meaning. To the lender, interest is income for waiting. To a household that borrows, interest is a cost of buying now instead of later. To the manager of a firm, interest on a loan is an explicit cost, and the manager compares it with the extra output that the borrowed money can buy. A loan is worth taking only when the money earns more than the interest it costs.

> The section closes with a recap and a first test.

*Before moving on.* Interest is the payment for the use of money, stated as a yearly rate. The loanable funds theory sets the rate where savers' offers equal borrowers' demands. The liquidity preference theory says interest rewards people for giving up cash. Rates differ with risk, length and size. You should now be able to say why a lender asks for more than was lent.

:pause 16.p1 | A bank lends Tk 200,000 for one year at 9 per cent a year. How much interest does the borrower pay, and how much does the borrower repay in total?

* * *

## Profit

> A harvest sale shows that the money left over can be counted in two ways.
@! Go slowly here.

Return to the farmer. He sells his harvest for Tk 300,000. This money received from sales is called revenue. He pays Tk 250,000 for seed, labour, fuel and the interest on his loan. He has Tk 50,000 left. A bookkeeper would call that his gain. But the farmer also worked for months on his own land, and his capital was tied up in the farm. The Tk 50,000 does not yet say whether the year was worth his effort. We need two measures, not one.

> The accountant's measure subtracts only the costs that were paid in money.
@ Profit | Word in use. In daily life, profit means any gain or money left in the till. In economics, it has two exact meanings, which differ by the owner's implicit costs.
@ Accounting profit | Revenue minus explicit costs only.

The accountant's measure is the simpler one. **Accounting profit** is revenue minus explicit costs only. An explicit cost is a cost that involves a payment of money to outsiders, such as wages, rent and interest.^2 The farmer's accounting profit is Tk 300,000 minus Tk 250,000, which is Tk 50,000. This is the profit that appears in a firm's accounts and on which taxes are usually based. Rules for tax differ by country, so a student should always name the country whose rules apply.

^2: Explicit and implicit costs are taught in Chapter 11, 'Costs of Production', section 11.1 'Explicit and Implicit Costs'.

> The economist's measure also subtracts what the owner's own resources could have earned.
@ Economic profit | Revenue minus all costs, explicit and implicit, including normal profit.

The economist's measure goes further. **Economic profit** is revenue minus all costs, explicit and implicit, including normal profit. An implicit cost is the value of resources the owner supplies, such as the owner's time and money. If the farmer could have earned Tk 60,000 as a hired worker, that sum is an implicit cost. His economic profit is Tk 50,000 minus Tk 60,000, which is a loss of Tk 10,000. The same year looks like a success in the accounts and a poor choice in the economist's reckoning.

> Normal profit is the least profit that keeps an owner in the business.

The words *normal profit* need a reminder. Normal profit is the least profit a firm must earn to stay in business, covering the owner's implicit costs.^3 When we subtract all implicit costs, we subtract normal profit. What remains is economic profit, which may be above, equal to, or below zero. Economic profit above zero is called supernormal profit, because it is more than normal. The table below sets out the three cases.

^3: Normal profit is taught in Chapter 13, 'Market Structure and Perfect Competition', section 13.3 'Equilibrium of Firm and Industry'.

:table The three results of economic profit
| Economic profit | What it means | Likely result |
| Above zero | Supernormal profit: more than the owner could earn elsewhere | New firms are attracted |
| Equal to zero | Normal profit only: the owner earns exactly what is needed | The owner stays |
| Below zero | Less than the owner could earn elsewhere | The owner may leave |

> Each row of the table pairs one result with its likely consequence.

Read the table one row at a time. In the first row, the owner earns more than the best alternative, so other people want to enter the same line of business. In the second row, the owner is neither tempted nor driven away. In the third row, the owner would do better to use time and money elsewhere, although some owners stay for reasons that money does not measure.

> Economic profit guides decisions to enter, stay in or leave a line of business.

The measure matters because owners compare their own results with the best alternative. When economic profit is above zero in an industry, other people notice and open similar firms. When it is below zero for long, owners move their time and money to other uses. Accounting profit cannot give this guidance, because it leaves out the alternatives. A limit: implicit costs are estimates, so economic profit is an estimate too.

> The shop's records contain all the figures needed for both measures.

:case Case file, illustrative. For 2025, Meghna and Sons recorded accounting profit of Tk 750,000. The case file counts two implicit costs: Tk 600,000 for the owner's time, and Tk 287,000 for the interest forgone on capital employed of Tk 4,100,000 at 7 per cent. Together, the implicit costs are Tk 887,000. Economic profit is therefore 750,000 minus 887,000, which is −Tk 137,000.

> The shop has a positive accounting profit and a negative economic profit.

The shop shows the difference between the two measures. The accounts report a gain of Tk 750,000, and any lender or tax office would see a firm with a positive profit. Yet the owner's own resources could have earned Tk 887,000 elsewhere. From the owner's viewpoint, the shop earns Tk 137,000 less than the best alternative. The employee and the customer see nothing of this. Only the owner pays the implicit costs.

:pause 16.p2 | A firm has revenue of Tk 900,000 and explicit costs of Tk 700,000. Its owner's time and capital could earn Tk 150,000 elsewhere. Find the accounting profit and the economic profit.

> The section ends with a recap.

*Before moving on.* Accounting profit subtracts explicit costs only. Economic profit subtracts explicit and implicit costs, so it also subtracts normal profit. Economic profit above zero is supernormal profit. You should now be able to say why a firm can have a positive accounting profit and a negative economic profit.

* * *

## Why Profit Occurs

> If profit can be negative, we must ask why it exists at all.

Interest has a clear reason: lenders wait. Profit is harder to explain, because it is what remains after every cost, including the owner's, has been paid. Why should anything remain? Economists give four answers. Each one fits some cases and fails in others, so we study them as four views and not as one rule.

> Profit rewards the owner for taking on the chance of loss.
@ Risk bearing | The act of taking on the chance of loss in business, which profit rewards.

The first view is the oldest. **Risk bearing** is the act of taking on the chance of loss in business, which profit rewards. A firm that makes goods before knowing whether anyone will buy them may lose its money. Frank Knight, an American economist, argued in 1921 that some chances cannot be known in advance or insured, and that profit is the reward for facing them. Limit: the view explains why a risky venture should earn more on average, not why every owner who takes a risk is paid.

> A second view treats profit as a payment for the owner's own contribution.

The second view is called the marginal productivity view. It treats the owner, who organises the land, labour and capital, as one more input. The owner's pay is the extra output that the owner's organising adds, as with any other input. Limit: the contribution of one owner is hard to measure, so the view is hard to test.

> A third view says that new methods create profit until rivals copy them.

The third view comes from Joseph Schumpeter, an Austrian economist who wrote in 1911. He argued that profit is the reward of innovation, which means introducing a new good or a new method. The innovator's costs are lower, or the good is new, so economic profit appears. Rivals then copy the idea, and the profit shrinks to zero. Limit: many firms earn profit without any new idea.

> A fourth view says that power over price can protect profit.

The fourth view is monopoly. A firm that is protected from rivals, because entry is difficult, can keep its price above its costs for a long time. Its supernormal profit lasts, because no new firm can enter to share it. Limit: this explains profit that is protected, but not profit in markets with many rivals.

:table Four views of why profit occurs
| View | Source of profit | Main limit |
| Risk bearing | Reward for facing chance of loss | Does not pay every risk-taker |
| Marginal productivity | Pay for the owner's own contribution | Hard to measure for one owner |
| Innovation | New methods and goods, until copied | Many profits need no new idea |
| Monopoly | Protection from rivals | Does not explain profit among many rivals |

> The table pairs each view with the case it explains best and the case it misses.

To read a row, take the view in the first column and ask what source it names in the second. Then check the third column for its weakness. No row is complete alone. A careful economist uses all four views, and asks which fits the firm being studied.

> Supernormal profit tends to attract rivals unless something blocks them.

Two of the views end in the same place. Supernormal profit signals that an activity pays more than its alternatives, and it invites new firms to enter. As they enter, the extra supply lowers the price, and the supernormal profit shrinks. Only protection from rivals, such as a new idea that others cannot copy or a market that new firms cannot enter, can keep it for long. This is why innovation and monopoly are linked with lasting profit.

> The four views disagree only because they describe different firms.

The views are better understood as answers to different questions. A farmer who plants before the rains faces risk. A manager of a large firm supplies organising skill. A new software firm relies on innovation. A single seller of a protected good relies on monopoly. A student who meets a profit in any case should ask which source applies.

> The section closes with a recap.

*Before moving on.* Profit has four main explanations: risk bearing, the owner's own contribution, innovation and monopoly power. Each fits some firms and fails for others. You should now be able to name the four views and give one limit of each.

* * *

## Worked Example: Interest and Economic Profit of the Shop

> Two examples apply the ideas, one small and clean and one realistic.

We work two examples in the same order each time: Given, Find, Formula, Steps, Answer and Check. The first finds the interest on the shop's bank loan. The second finds the shop's economic profit.

> The first example finds a year's interest on the bank loan.

*Given.* The shop owes Tk 600,000 to its bank. The rate of interest is 11 per cent a year, and the loan runs for one year. *Find.* The interest for the year. *Formula.* In words, interest equals the sum borrowed multiplied by the rate. In symbols, I = S × r, where I is the interest, S is the sum borrowed and r is the rate written as a decimal.

> Each line of arithmetic is shown, with its unit, so the method is the only new thing.

*Steps.* Write 11 per cent as 11 ÷ 100 = 0.11. Then I = 600,000 × 0.11 = Tk 66,000. *Answer.* The shop pays Tk 66,000 in interest for the year. *Check.* One per cent of 600,000 is Tk 6,000. Eleven per cent is eleven times that, which is 11 × 6,000 = Tk 66,000. The two routes agree.

> The second example finds the economic profit of the shop for 2025.

*Given.* Sales were Tk 14,400,000, and accounting profit was Tk 750,000. The owner's time is valued at Tk 600,000. Capital employed was Tk 4,100,000, and it could have earned 7 per cent a year elsewhere. *Find.* The economic profit. *Formula.* Forgone interest = rate × capital employed. Economic profit = accounting profit − total implicit costs. This is the same as revenue minus all costs, because accounting profit is revenue minus explicit costs.

> Every step is written out, so nothing depends on guesswork.

*Steps.* Write 7 per cent as 0.07. Forgone interest = 0.07 × 4,100,000 = Tk 287,000. Total implicit costs = 600,000 + 287,000 = Tk 887,000. Economic profit = 750,000 − 887,000 = −Tk 137,000.

> The shop is below normal profit by Tk 137,000.

*Answer.* The economic profit is −Tk 137,000. The shop earns Tk 137,000 less than its owner's time and capital could earn elsewhere. *Check.* The implicit costs of Tk 887,000 exceed the accounting profit of Tk 750,000, so the answer must be negative. Adding back: −137,000 + 887,000 = 750,000, the figure in the accounts. A negative result does not force the owner to close the shop. It tells her the price of staying.

> Four common slips spoil these calculations.

Common slips are easy to name. First, using 11 instead of 0.11, which gives an answer one hundred times too large. Second, mixing periods, such as a yearly rate with a loan held for three months. Third, forgetting implicit costs, which gives accounting profit and not economic profit. Fourth, a wrong sign, such as subtracting the smaller number from the larger. Write the unit beside every number, and check the sign by asking whether the implicit costs exceed the accounting profit.

* * *

## Summary

> The chapter's main points fit in a few lines.

Interest is the payment for the use of money, stated as a yearly rate. The loanable funds theory sets it where savers' offers equal borrowers' demands, and the liquidity preference theory says it rewards people for giving up cash. Accounting profit subtracts explicit costs only. Economic profit subtracts all costs, including normal profit. Profit is explained by risk bearing, the owner's contribution, innovation and monopoly power.

* * *

## Think It Through

:q 16.t1 | Two ventures have the same expected sales and costs, but one is far more risky. Using the risk bearing view, explain why the risky venture should be expected to earn more on average.

:q 16.t2 | A bank charges 8 per cent a year to a large firm and 18 per cent a year to a small trader. Give two reasons for the difference.

* * *

## Where People Go Wrong

> Profit in the accounts is not the same as economic profit.

*Mistake: "A profit of Tk 750,000 means the shop is doing well."* That is accounting profit. After the owner's implicit costs of Tk 887,000, the shop's economic profit is −Tk 137,000.

> Interest is a price, not a punishment.

*Mistake: "Interest is only an unfair charge on borrowers."* Interest pays the lender for waiting and for risk, and it rations scarce funds among borrowers who want them. Whether a particular rate is fair is a separate question.

> Normal profit is a cost, not a gain.

*Mistake: "Normal profit is a form of profit left for the owner."* Normal profit is part of costs, because it covers the owner's implicit costs. Only economic profit above zero is a surplus above all costs.

> Each view of profit fits some firms only.

*Mistake: "Profit has one cause."* Risk, the owner's contribution, innovation and monopoly power each explain some profits and fail for others.

* * *

## In History

> A village experiment showed that very poor borrowers could repay small loans.

In 1976, Muhammad Yunus, a Bangladeshi economist then teaching at Chittagong University, began to lend small sums to poor villagers in Jobra, a village near the university. Banks at that time refused to lend to people who owned no property. Yunus found that the borrowers repaid, and he went on to found the Grameen Bank in 1983.

> The bank charged interest, and it showed that risk and cost are not the only forces that fix its level.

The Grameen Bank grew into a large lender to poor households in Bangladesh, and in 2006 Yunus and the bank shared the Nobel Peace Prize. The story links to this chapter in two ways. Loans to people without property carry more risk and cost more to administer, which usually raises the rate. Yet repayment turned out better than lenders had expected, so the chance of loss was smaller than they feared.

* * *

## Review Questions

> The questions move from one loan to the full measure of economic profit.

:q 16.1 | A loan of Tk 50,000 is made at 10 per cent a year for one year. Find the interest and the total repayment.

:q 16.2 | A loan of Tk 450,000 is made at 9.5 per cent a year for one year. Find the interest.

:q 16.3 | A loan of Tk 600,000 at 11 per cent a year is held for three months. Interest is charged on the sum borrowed only and is not added to it. Find the interest.

:q 16.4 | An owner's accounting profit is Tk 420,000. Her time is worth Tk 300,000 a year elsewhere, and her capital of Tk 2,000,000 could earn 6 per cent a year. Find the economic profit and say which of the three results in the table it is.

:q 16.5 | A firm has an accounting profit of Tk 380,000 and implicit costs of Tk 450,000. Find the economic profit and say what it tells the owner.

:q 16.6 | A trader has sales of Tk 2,000,000 and explicit costs of Tk 1,700,000. Her time is worth Tk 200,000 a year elsewhere, and her capital of Tk 1,000,000 could earn 8 per cent. Find her accounting profit and economic profit, and name the result.

:q 16.7 | Name the four views of why profit occurs, and give one limit of each.

:read Frank H. Knight, Risk, Uncertainty and Profit, 1921
:read Joseph A. Schumpeter, The Theory of Economic Development, 1911
:read Muhammad Yunus, Banker to the Poor, 1999
