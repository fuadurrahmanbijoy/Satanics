:answers 16
:a 16.p1 | Interest = 200,000 × 0.09 = Tk 18,000. Total repayment = 200,000 + 18,000 = Tk 218,000.
:a 16.p2 | Accounting profit = 900,000 − 700,000 = Tk 200,000. Economic profit = 200,000 − 150,000 = Tk 50,000, which is supernormal profit.
:a 16.t1 | The risky venture may end in loss, and owners will not accept that chance unless the average reward is larger. If it earned no more, few people would take the risk. Profit is the reward for facing the chance of loss.
:a 16.t2 | The small trader is a riskier borrower, because the chance of non-repayment is higher. A small loan also costs almost as much to administer as a large one, so the cost per taka lent is higher.
:a 16.1 | Interest = 50,000 × 0.10 = Tk 5,000. Total repayment = 50,000 + 5,000 = Tk 55,000.
:a 16.2 | 9.5 per cent is 0.095. Interest = 450,000 × 0.095 = Tk 42,750.
:a 16.3 | Interest for a year is 600,000 × 0.11 = Tk 66,000. Three months is 3 ÷ 12 of a year, so interest = 66,000 × 3 ÷ 12 = Tk 16,500.
:a 16.4 | Forgone interest = 0.06 × 2,000,000 = Tk 120,000. Implicit costs = 300,000 + 120,000 = Tk 420,000. Economic profit = 420,000 − 420,000 = Tk 0. This is normal profit only.
:a 16.5 | Economic profit = 380,000 − 450,000 = −Tk 70,000. The owner could earn Tk 70,000 more elsewhere, so the result is below normal profit.
:a 16.6 | Accounting profit = 2,000,000 − 1,700,000 = Tk 300,000. Forgone interest = 0.08 × 1,000,000 = Tk 80,000. Implicit costs = 200,000 + 80,000 = Tk 280,000. Economic profit = 300,000 − 280,000 = Tk 20,000, which is supernormal profit.
:a 16.7 | Risk bearing, limit: it does not pay every risk-taker. Marginal productivity, limit: one owner's contribution is hard to measure. Innovation, limit: many profits need no new idea. Monopoly, limit: it does not explain profit among many rivals.
