:answers 14
:a 14.p1 | To sell 30 units she must cut the price on all units. She loses Tk 10 on each of the first 20 units (Tk 200) and gains 10 new units at Tk 50 (Tk 500). The net gain is Tk 300, or Tk 30 a unit, which is below Tk 50.
:a 14.p2 | Each firm fears that rivals would copy a price cut but not a price rise, so a change brings it little gain either way. It leaves the price alone.
:a 14.t1 | No. One large firm may serve everyone at a lower cost for each unit than many small firms, and a market of differentiated goods gives variety that identical goods cannot. Price is only one measure of how well a market serves consumers.
:a 14.t2 | At 50 units marginal revenue is −10, so the extra units lower revenue while adding cost. Output of 40 units gives revenue Tk 1,600 against Tk 1,500 at 50, and cost falls from Tk 1,900 to Tk 1,560, so profit rises from −Tk 400 to Tk 40.
:a 14.1 | (1,600 − 1,500) ÷ (40 − 30) = 100 ÷ 10 = Tk 10 per unit.
:a 14.2 | Marginal revenue per unit: 50, 30, 10, −10. Take the first two steps (50 over 20, 30 over 22); stop at the third (10 under 25). Output 20 units, price 60 − 20 = Tk 40. Total cost = 100 + 200 + 220 = Tk 520. Profit = 800 − 520 = Tk 280.
:a 14.3 | Tk 300 for the whole step of 10 units is Tk 300 ÷ 10 = Tk 30 per unit, so the figures agree. Compare the per-unit figure, Tk 30, with the marginal cost of Tk 20 per unit; marginal revenue is higher, so the step is worth taking.
:a 14.4 | At 40 units the price is Tk 40 and the marginal cost is Tk 24, so output rises; at 50 units the price is Tk 30 and the marginal cost is Tk 34, so it stops. Competitive output is 40 units at Tk 40, against 30 units at Tk 50 for the monopoly: ten more units at Tk 10 less.
:a 14.5 | (a) Monopolistic competition. (b) Oligopoly. (c) Monopoly.
:a 14.6 | Marginal revenue = (900 − 800) ÷ 10 = Tk 10 per cup. This is below the marginal cost of Tk 12, so the stall should not sell the extra 10 cups. Yes, Tk 10 is below the price of Tk 18.
