:answers 02
:a 2.p1 | The best alternative given up, which is the Tk 300 earned. Sleeping late is a lesser alternative and is not added.
:a 2.t1 | The cost is the Tk 120 that could have been earned, the best alternative. For a student with no job offer, or with a different alternative such as a tutoring fee, the cost would differ.
:a 2.t2 | The maximum is 1,000 books or 500 parcels. 600 books needs 30 hours and 300 parcels needs 30 hours, so 60 hours are needed; it is still not attainable.
:a 2.1 | A want is something a person would like to have, whatever the price. One want may be met, but others appear in its place, so the whole list is without limit.
:a 2.2 | Scarcity is the condition that resources are limited while wants are unlimited, so choices must be made. A rich person has limited time; a poor person has limited money.
:a 2.3 | The Tk 400 from working, as the best alternative. Resting is a lesser alternative and is not counted.
:a 2.4 | One pair of trousers costs 8 ÷ 4 = 2 shirts. One shirt costs 4 ÷ 8 = 0.5 pair of trousers.
:a 2.5 | Shelving gives 30 × 20 = 600 books; packing gives 10 × 10 = 100 parcels. All 40 hours are used, and at 600 books the curve allows 100 parcels, so the point lies on the curve.
:a 2.6 | First step: 10 buses lost for 5 cars, 2 per car. Second step: 20 buses lost for 5 cars, 4 per car. The opportunity cost rises.
:a 2.7 | Resources differ in their suitability, so moving them costs more and more. More resources, or better methods, would shift the curve outward.
