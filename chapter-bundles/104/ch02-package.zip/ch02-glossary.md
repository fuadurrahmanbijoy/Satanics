:glossary 02
Want | Something a person would like to have, however little or much the person can pay for it. A want may be a good, a service or a condition. Example: a bicycle, a haircut or a free afternoon.
Scarcity | The condition that resources are limited while wants are unlimited, so choices must be made. It applies to rich and poor alike, and it is the reason economics exists. Example: a family cannot buy everything on its list.
Opportunity cost | The value of the best alternative given up when a choice is made. Only the best alternative counts, not all alternatives added. Example: Rafiq's extra parcel gives up 2 books.
Trade-off | Giving up some of one thing in order to have more of another. It is the exchange itself, while opportunity cost measures what is given up. Example: planting more jute and less rice.
Production possibility curve | A line showing the largest combinations of two goods that can be produced with all resources used fully. Points inside waste resources; points outside cannot be reached. Example: Rafiq's 800 books or 400 parcels.
