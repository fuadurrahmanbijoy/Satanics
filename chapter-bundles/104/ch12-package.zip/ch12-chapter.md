:chapter XII | The Least-Cost Combination of Inputs
:mood How can a firm tell which mix of workers and machines is the cheapest way to make the same output?
:desc This chapter shows how a firm chooses among the many ways of making the same output. You will learn to draw and read two lines, one for output and one for total cost, and to find the mix of inputs that costs least.
:plate ch12-plate.svg | A water wheel drives rows of looms in a Victorian mill

:box YOU WILL NEED
Chapter 10 'Production Function and Returns', section 10.1 'Inputs and Output'; Chapter 11 'Costs of Production', section 11.1 'Explicit and Implicit Costs'; Chapter 7 'Indifference Curve Analysis', section 7.2 'Marginal Rate of Substitution'; Appendix A1 'Maths You Will Use'.

> A workshop owner must bind 100 books every day and can use workers, machines or both.

Imagine the owner of a binding workshop who must bind 100 books every day. The books can be bound by hand, by machine, or by some of each. With hand work only, the workshop needs many workers and no machine. With machines only, it needs many machines and few workers. Between these two extremes lie many other ways to reach the same 100 books.

> Each way has its own daily bill, so the owner needs a method to find the smallest.

Each way has its own bill at the end of the day. Workers must be paid, and machines must be rented. More machines mean fewer workers, so one bill rises as the other falls. The owner is left with a question that has a definite answer: which way gives the same 100 books for the smallest total?

> Trying every way is slow and explains nothing; two lines give a better method.

A beginner might try every way, one after another. That works when there are few ways, but it does not explain why one way wins. A better method uses two pictures. One line shows every way of making the output. Another line shows every way of spending a given sum. Where the two lines meet in the right manner, the cheapest mix is found. Many students find this idea new, but the thinking is familiar from the consumer's choice in Chapter 7, now applied to a firm. We start with the first line.

* * *

## Choosing Inputs

> Recall: production function, Chapter 10, section 10.1 'Inputs and Output'.
> A firm makes output from inputs, and a mix of inputs means the amounts used together.

@ Input | Word in use. In daily life, a contribution of ideas or advice, as in your input to a meeting. In economics, a thing a firm uses to make output, such as labour, a machine or a raw material.
@ Mix | Word in use. In daily life, to blend things together. In economics, the amounts of different inputs that a firm uses together, as in a mix of workers and machines.

A firm makes its output by using inputs. Chapter 10 showed that a production function links the inputs to the output. In this chapter we study two inputs: workers and machines. Other inputs, such as paper and glue, are held fixed. Four workers with four machines is one mix. Five workers with three machines is another mix.

> Workers and machines can replace each other within limits, so many mixes give one output.

Workers and machines can replace each other, within limits. A machine can do the work of several people, and a skilled worker can do what a poor machine cannot. So the same output can come from different mixes. The production function tells us the output for each mix. Here we ask the reverse question: for a chosen output, which mixes reach it? The answer is a line.

@ Isoquant | A line showing all combinations of two inputs that produce the same output.

> An isoquant joins all mixes that give the same output.

The line has a name. An **isoquant** is a line showing all combinations of two inputs that produce the same output. The word *iso* means equal, and *quant* comes from quantity, so isoquant means equal quantity of output. If five mixes each give 100 books a day, all five lie on one isoquant.

> Case file: five mixes of workers and machines give 100 books a day.

:case Case file, illustrative. For an output of 100 books bound a day, the wage is Tk 600 per worker per day and the machine rent is Tk 400 per machine per day. Five combinations give this output, written as (workers, machines): (2, 10), (3, 6), (4, 4), (5, 3) and (6, 2). Joined together, they form one isoquant.

> Isoquants slope downward, curve toward the origin, and never cross.

An isoquant has three properties. First, it slopes downward: to keep output the same, more workers mean fewer machines. Second, it curves toward the corner where the two axes meet, because each added worker replaces fewer machines than the one before. Third, two isoquants never cross, and an isoquant farther from the corner shows a larger output. These properties match those of an indifference curve and an indifference map, with one difference. Satisfaction cannot be counted, but output can be counted in books.

> A firm decides how much to spend and can divide the sum between workers and machines.

Now consider the owner's money. Suppose the owner decides to spend Tk 4,000 a day on inputs. With that sum the owner can hire many workers and rent few machines, or the reverse. Every division of Tk 4,000 between the two inputs lies on one line.

@ Isocost line | A line showing all combinations of two inputs that cost the same total amount.

> An isocost line joins all mixes that have the same total cost.

An **isocost line** is a line showing all combinations of two inputs that cost the same total amount. Here *cost* is the firm's expense. The formula in words is: total cost equals the wage times the number of workers, plus the machine rent times the number of machines. In symbols, C = w x L + r x M, where C is the total cost, w is the wage per worker, L is the number of workers, r is the rent per machine and M is the number of machines.

> The Tk 4,000 line meets the axes at 6.67 workers and 10 machines.

Take the case prices. If all of Tk 4,000 buys workers, the firm hires 4,000 / 600 = 6.67 workers a day, which is an average over several days. If all of it buys machines, the firm rents 4,000 / 400 = 10 machines. These are the two ends of the line. The mix (4, 4) lies on it, because 600 x 4 + 400 x 4 = 2,400 + 1,600 = Tk 4,000. A higher total cost gives a line farther from the corner.

> The slope of an isocost line is the price ratio: one worker costs as much as 1.5 machines.

The slope of the line depends only on the two prices. One worker costs Tk 600 and one machine costs Tk 400, so a worker costs as much as 600 / 400 = 1.5 machines. Along the line, each extra worker must be paid for by renting 1.5 fewer machines. If the wage rises, the line becomes steeper. If the machine rent rises, it becomes flatter.

:pause 12.p1 | An isocost line is drawn for a total of Tk 4,800, with a wage of Tk 600 and a machine rent of Tk 400. How many workers could be hired if no machine is rented?

@ Marginal rate of technical substitution | The amount of one input a firm can give up when it adds one unit of another, keeping output the same.

> Recall: marginal rate of substitution, Chapter 7, section 7.2 'Marginal Rate of Substitution'.
> The marginal rate of technical substitution is the slope of the isoquant.

Chapter 7 gave the consumer's marginal rate of substitution, which keeps satisfaction the same. The firm has a twin, and it keeps output the same. The **marginal rate of technical substitution** is the amount of one input a firm can give up when it adds one unit of another, keeping output the same. We write it as MRTS. Here it is the number of machines a firm can save when it adds one worker.

> The case isoquant gives MRTS values of 4, 2, 1 and 1.

The table gives the MRTS between each pair of neighbouring mixes on the case isoquant. Its columns show the move, the machines saved, the workers added and the MRTS, which is the machines saved divided by the workers added.

:table MRTS between neighbouring mixes on the isoquant for 100 books
| Move | Machines saved | Workers added | MRTS |
| (2, 10) to (3, 6) | 4 | 1 | 4 |
| (3, 6) to (4, 4) | 2 | 1 | 2 |
| (4, 4) to (5, 3) | 1 | 1 | 1 |
| (5, 3) to (6, 2) | 1 | 1 | 1 |

> The MRTS falls as workers replace machines, because each added worker is worth less.

Read the first row: adding one worker saves four machines, so the MRTS is 4. The values fall as we move down the table. This is called a diminishing MRTS. It happens because the more workers there are, the less each extra worker adds, while the fewer machines remain, the more each remaining machine matters. The falling MRTS is the reason the isoquant curves toward the corner.

> The MRTS also equals the marginal product of a worker divided by that of a machine.

There is a second way to write the MRTS. The marginal product of an input is the extra output from one more unit of it, a quantity met in Chapter 10, 'Production Function and Returns'. A worker replaces machines in proportion to what each adds, so MRTS = marginal product of a worker / marginal product of a machine. A worker who adds twice as much output as a machine replaces two machines.

> Recap: inputs, the isoquant, the isocost line and the MRTS.

*Before moving on.* An isoquant joins the mixes of two inputs that give the same output. An isocost line joins the mixes that have the same total cost, and its slope is the price ratio. The MRTS is the number of machines saved by adding one worker, and it falls as workers replace machines.

* * *

## The Least-Cost Rule

> Of five mixes that make 100 books, which costs least?

Return to the workshop. Five mixes give 100 books. Which of them costs least? The method has three steps. First, list the mixes on the isoquant. Second, find the total cost of each mix. Third, choose the mix with the smallest total cost.

@ Least-cost combination | The mix of inputs that produces a given output at the lowest total cost.

> The least-cost combination is the cheapest mix for a given output.

The result has a name. The **least-cost combination** is the mix of inputs that produces a given output at the lowest total cost. The words *given output* matter. The firm does not choose how much to make here. It has fixed the output, and it asks only how to make it most cheaply.

> Case file: the cheapest of five mixes is 4 workers and 4 machines at Tk 4,000.

:case Case file, illustrative. For an output of 100 books bound a day, with the wage at Tk 600 and the machine rent at Tk 400, the total costs are: (2, 10) = Tk 5,200; (3, 6) = Tk 4,200; (4, 4) = Tk 4,000; (5, 3) = Tk 4,200; (6, 2) = Tk 4,400. The least cost is (4, 4) at Tk 4,000. The MRTS moves from 2 to 1 around the price ratio 600 / 400 = 1.5.

> The table splits each total cost into a wage bill and a rent bill.

The table shows how each total is built. The wage bill is Tk 600 times the number of workers, and the rent bill is Tk 400 times the number of machines. The last column adds the two.

:table Cost of each mix that gives 100 books a day
| Workers, machines | Wage bill (Tk) | Rent bill (Tk) | Total cost (Tk) |
| 2, 10 | 1,200 | 4,000 | 5,200 |
| 3, 6 | 1,800 | 2,400 | 4,200 |
| 4, 4 | 2,400 | 1,600 | 4,000 |
| 5, 3 | 3,000 | 1,200 | 4,200 |
| 6, 2 | 3,600 | 800 | 4,400 |

> Total cost falls and then rises, and the lowest point is the least-cost combination.

Read the last column from top to bottom. The total falls from 5,200 to 4,000 and then rises to 4,400. The lowest value is the least-cost combination, 4 workers and 4 machines. The cheapest mix is neither the one with most workers nor the one with most machines. The best mix lies in the middle, where the two bills are balanced.

> On the chart, the cheapest isocost line that touches the isoquant shows the best mix.

Now we draw the same facts. On the chart, the horizontal axis shows the number of workers and the vertical axis shows the number of machines. A point is a mix. The curved line is the isoquant for 100 books. The straight lines are isocost lines, and a line farther from the corner means a higher total cost. The firm wants the lowest isocost line that still touches the isoquant. That line touches the curve at one point, without crossing it, which is called a tangent. The point of contact is the least-cost combination.

:fig Isoquant for 100 books with isocost lines, and the least-cost combination | ch12-fig01.svg

> At the point of contact the slope of the isoquant equals the slope of the isocost line.

At the point of contact the two lines have the same slope. The slope of the isoquant is the MRTS, and the slope of the isocost line is the price ratio. So the least-cost rule is: MRTS = wage / machine rent. In the case, 600 / 400 = 1.5. Between (3, 6) and (4, 4) the MRTS is 2, which is above 1.5. Between (4, 4) and (5, 3) it is 1, which is below 1.5. The ratio 1.5 lies between them, at (4, 4).

> If the MRTS is above the price ratio, the firm should hire more workers and fewer machines.

The reason can be shown with numbers. At (3, 6), one more worker saves two machines worth Tk 800 and costs Tk 600, so the firm gains Tk 200. It should move. At (4, 4), one more worker saves one machine worth Tk 400 and costs Tk 600, so the firm loses Tk 200. It should stop. The firm adjusts until the gain from changing the mix falls to zero.

> The rule has a second form: each input must add the same output per taka spent.

The rule has a second form. Divide each marginal product by the price of its input to find the extra output per taka. The least-cost combination has equal marginal product per taka: marginal product of a worker / wage = marginal product of a machine / machine rent. If workers add more output per taka than machines, the firm should hire more workers and rent fewer machines. As it does so, the marginal product of a worker falls and that of a machine rises, until the two ratios are equal.

> A rise in the wage turns the isocost line steeper and moves the best mix toward machines.

Now suppose the wage rises while the machine rent stays the same. The isocost line turns steeper, because a worker now costs as much as more machines. The point of contact moves along the isoquant toward fewer workers and more machines. The firm replaces workers with machines, because machines have become cheaper by comparison. Total cost for the same output still rises, but by less than it would if the firm kept the old mix. The worked examples give numbers.

> Recap: the least-cost rule in two forms and the effect of a wage change.

*Before moving on.* The least-cost combination is found where the lowest isocost line touches the isoquant. There, MRTS equals the price ratio, which is the same as equal marginal product per taka. A rise in the wage steepens the isocost line and moves the best mix toward machines.

* * *

## Using the Rule

> What happens when the firm wants to make more than 100 books?

Suppose the firm wants to make more than 100 books a day. The same method applies at each output. Each output has its own isoquant, and a larger output has an isoquant farther from the corner. For each one, the lowest isocost line that touches it gives a new least-cost combination.

> The expansion path joins the least-cost combinations for every output.

If we join these least-cost points, the line is called the *expansion path*. It shows how the best mix changes as output grows, while the input prices stay the same. Usually the path rises, because a larger output needs more of both inputs. The total cost at each point on the path is the least total cost of that output, which is the total cost schedule used in Chapter 11, 'Costs of Production'.

> Cost-minimising asks how to make a given output; profit-maximising also asks how much to make.

Two questions must be kept apart. A cost-minimising choice asks: for a given output, which mix costs least? A profit-maximising choice asks a larger question: which output should the firm make? A firm that wants the largest profit must answer both. It first finds the cheapest way to make each output, and then it chooses the output that gives the best gap between revenue and total cost. A firm can minimise cost and still lose money if it chooses a poor output. Later chapters deal with that second choice.

> In the short run some inputs are fixed, so the firm may be unable to reach the least-cost combination.

In the short run, some inputs cannot be changed, and in the long run all can. Suppose, as an illustration, that a firm has signed a contract for 6 machines. For 100 books it must use the mix (3, 6), which costs Tk 4,200 in the case. The least cost is Tk 4,000, so the contract adds Tk 200 a day. Only in the long run can the firm move to (4, 4).

> The rule assumes two inputs, steady prices and smooth substitution, and real firms differ.

The rule has limits. It assumes two inputs, steady prices and smooth substitution between them. Some inputs fit together in fixed amounts: a bus needs one driver, however cheap the fuel. Then the isoquant has a sharp corner and only one mix makes sense. Real managers also do not know their isoquants exactly. They estimate them from experience, and the rule shows the direction in which to adjust.

> A worker welcomes a higher wage, yet the rule shows a hidden effect on the number of workers hired.

The viewpoints differ. The manager asks which mix costs least. A worker welcomes a higher wage, and those who keep their jobs gain. The rule, however, shows a hidden effect: after a wage rise, a firm may use fewer workers for the same output. How large the effect is depends on how easily machines replace workers, which is the curvature of the isoquant.

> Recap: the expansion path, the two kinds of choice and the short run.

*Before moving on.* Repeating the method for each output gives the expansion path. Minimising cost for a given output is not the same as maximising profit. In the short run a fixed input can prevent the firm from reaching the least-cost combination.

* * *

## Worked Examples: Finding the Least-Cost Mix

> Two examples apply the rule: the first with small numbers, the second with case data and a wage rise.

We now apply the rule in full, in the order Given, Find, Formula, Steps, Answer and Check. The first example uses small numbers, so that the method is the only new thing to learn. The second uses the case and a change in the wage.

> Example 1: test a mix by comparing output per taka from each input.

*Example 1: output per taka.* *Given.* The wage is Tk 20 per worker per day and the machine rent is Tk 10 per machine per day. At the firm's present mix, the marginal product of a worker is 40 books and that of a machine is 15 books. *Find.* Whether the mix is the least-cost combination and, if not, which way the firm should change it.

> The test divides each marginal product by the price of its input.

*Formula.* In words: the marginal product per taka equals the marginal product divided by the price of the input. The mix is least-cost when the ratio is equal for both inputs. In symbols: MP of a worker / w = MP of a machine / r, where MP means marginal product, w is the wage and r is the machine rent. *Steps.* Workers: 40 / 20 = 2 books per taka. Machines: 15 / 10 = 1.5 books per taka. Compare: 2 is greater than 1.5.

> Workers give more output per taka, so the firm should hire more workers and fewer machines.

*Answer.* The mix is not least-cost. A taka spent on workers adds more output than a taka spent on machines, so the firm should hire more workers and rent fewer machines. *Check.* The MRTS is 40 / 15 = 2.67, which is above the price ratio 20 / 10 = 2. The rule of section 12.2 also says to hire more workers. The two tests agree.

> Example 2: the wage rises from Tk 600 to Tk 900 in the case.

*Example 2: a wage rise.* *Given.* The output is 100 books a day. The machine rent stays at Tk 400. The wage rises from Tk 600 to Tk 900. The mixes on the isoquant are (2, 10), (3, 6), (4, 4), (5, 3) and (6, 2). *Find.* The new least-cost combination and the rise in total cost.

> Total cost is recomputed for each mix at the new wage and the smallest is chosen.

*Formula.* C = w x L + r x M, with w = 900 and r = 400. *Steps.* (2, 10): 900 x 2 + 400 x 10 = 1,800 + 4,000 = Tk 5,800. (3, 6): 2,700 + 2,400 = Tk 5,100. (4, 4): 3,600 + 1,600 = Tk 5,200. (5, 3): 4,500 + 1,200 = Tk 5,700. (6, 2): 5,400 + 800 = Tk 6,200. The smallest is Tk 5,100. The rise is 5,100 - 4,000 = Tk 1,100.

> The best mix moves to 3 workers and 6 machines, and the rise is Tk 1,100.

*Answer.* The new least-cost combination is 3 workers and 6 machines, at Tk 5,100. Total cost rises by Tk 1,100. *Check.* The price ratio is now 900 / 400 = 2.25. The MRTS between (2, 10) and (3, 6) is 4, which is above 2.25, so the firm moves. Between (3, 6) and (4, 4) it is 2, which is below 2.25, so the firm stops at (3, 6). Keeping the old mix (4, 4) would cost Tk 5,200, a rise of Tk 1,200, so changing the mix saves Tk 100.

> Three slips are common: reversed MRTS, mixed periods and comparing different outputs.

Three slips are common. The first is to reverse the MRTS: divide the machines saved by the workers added, not the other way. The second is to mix periods: the wage and the machine rent must both be per day, or both per week. The third is to compare mixes that give different outputs. Total costs can be compared only along one isoquant.

* * *

## Summary

> The main ideas of the chapter in a few lines.

An isoquant shows all mixes of two inputs that give the same output. An isocost line shows all mixes that cost the same total amount, and its slope is the price ratio. The marginal rate of technical substitution is the amount of one input that can be saved when another is added, keeping output the same. The least-cost combination is where the lowest isocost line touches the isoquant, so the marginal rate of technical substitution equals the price ratio. In the case, the least cost for 100 books is Tk 4,000, at 4 workers and 4 machines. A wage rise moves the best mix toward machines.

## Think It Through

:q 12.t1 | The wage rises from Tk 600 to Tk 900 and the machine rent stays at Tk 400. Without calculating, predict how the least-cost mix changes. Then explain why total cost for 100 books rises by less than 4 x Tk 300.
:q 12.t2 | A firm has signed a contract for 6 machines and cannot change it this month. Can it reach the least-cost combination for 100 books in the case? Explain.

## Where People Go Wrong

> A common belief is that the firm should use the input with the lower price; the rule compares output per taka.

A common belief is that a firm should use more of the input with the lower price. Price alone does not decide. The rule compares the output added per taka, so a dear input that adds a great deal of output can still be the better choice.

> A second belief is that least cost means fewest inputs; it means the lowest total bill.

A second belief is that least cost means the fewest inputs. It does not. The mix (3, 6) uses nine inputs in all and costs Tk 4,200, while the mix (4, 4) uses eight and costs Tk 4,000, so counting inputs is a poor guide. Only the total bill, found from the prices, decides.

> A third belief is that the best mix spends the same amount on each input; it does not.

A third belief is that the best mix spends equal amounts on workers and machines. At (4, 4), the wage bill is Tk 2,400 and the rent bill is Tk 1,600. The rule requires equal output per taka, not equal spending.

> A fourth mistake is to read an isoquant like an indifference curve with measurable satisfaction.

A fourth mistake is to treat an isoquant as if it were a consumer's indifference curve. The two have the same shape, but output can be counted in books and satisfaction cannot be counted. A larger output on a higher isoquant is a fact, not an opinion.

## In History

> In 1769 Richard Arkwright patented a spinning machine and ran it first in a horse-powered mill in Nottingham.

In 1769 Richard Arkwright, an English inventor and businessman, patented a spinning machine that later became known as the water frame. He first set up a horse-powered mill in Nottingham, a city in the English Midlands, to run his machines.

> In 1771 he built Cromford Mill in Derbyshire, the first successful water-powered cotton spinning mill.

Horses gave too little power, so in 1771 Arkwright built a mill at Cromford, in Derbyshire, England, driven by a water wheel. Cromford Mill is regarded as the world's first successful water-powered cotton spinning mill. He chose the site because water flowed there all year, from the Bonsall Brook and the Cromford Sough, a drain that carried water out of nearby lead mines.

> The mill moved spinning from workers' homes to machines, and workers needed housing at the new site.

Before such mills, much cotton yarn was spun by hand on wheels in workers' homes. Arkwright gathered the spinning into one building, where a water wheel and machines did work that people had done by hand. In the language of this chapter, the mix moved toward machines and power. He also needed workers at the site, and in 1776 he began building houses for them in Cromford. We do not know what calculations he made, but his question was the one of this chapter: which mix of workers, machines and power makes the yarn at the lowest cost?

## Review Questions

:q 12.1 | Define an isoquant and an isocost line in your own words, and state one difference between an isoquant and an indifference curve.
:q 12.2 | With a wage of Tk 600 and a machine rent of Tk 400, draw the isocost line for a total of Tk 4,800 by finding where it meets each axis. State its slope.
:q 12.3 | A firm must make 10 units. The mixes of (workers, machines) that give this output are (1, 8), (2, 4), (4, 2) and (8, 1). A worker costs Tk 30 a day and a machine costs Tk 10 a day. Find the least-cost combination.
:q 12.4 | Use the case mixes for 100 books and the wage of Tk 600, but let the machine rent fall from Tk 400 to Tk 300. Find the least-cost combination, and compare the MRTS between the cheapest mixes with the new price ratio.
:q 12.5 | In the case, find the wage bill as a percentage of total cost at the least-cost combination. Then find it again after the wage rises to Tk 900 and the firm moves to its new best mix. Explain the change.
:q 12.6 | The marginal product of a worker is 30 books and that of a machine is 10 books. The wage is Tk 600 and the machine rent is Tk 400. Which input adds more output per taka, and how should the firm change its mix?

:read Alfred Marshall, Principles of Economics, 1890
:read Paul Mantoux, The Industrial Revolution in the Eighteenth Century, 1928
