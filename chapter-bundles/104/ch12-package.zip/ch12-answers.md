:answers 12
:a 12.p1 | 4,800 / 600 = 8 workers.
:a 12.t1 | The firm moves toward machines: fewer workers and more machines. At the new wage the least-cost mix is (3, 6) at Tk 5,100. Keeping (4, 4) would cost Tk 5,200, a rise of 4 x 300 = Tk 1,200. Changing the mix limits the rise to Tk 1,100.
:a 12.t2 | No. With 6 machines fixed, the mix for 100 books is (3, 6), which costs Tk 4,200. That is Tk 200 above the least cost of Tk 4,000 at (4, 4). Only workers can be changed in the short run.
:a 12.1 | An isoquant joins all mixes of two inputs that give the same output. An isocost line joins all mixes that cost the same total amount. Output can be counted in units, but the satisfaction shown by an indifference curve cannot be counted.
:a 12.2 | All workers: 4,800 / 600 = 8 workers. All machines: 4,800 / 400 = 12 machines. The slope is the price ratio 600 / 400 = 1.5.
:a 12.3 | Costs: (1, 8) = 30 + 80 = Tk 110; (2, 4) = 60 + 40 = Tk 100; (4, 2) = 120 + 20 = Tk 140; (8, 1) = 240 + 10 = Tk 250. The least-cost combination is (2, 4) at Tk 100.
:a 12.4 | Costs: (2, 10) = 1,200 + 3,000 = Tk 4,200; (3, 6) = 1,800 + 1,800 = Tk 3,600; (4, 4) = 2,400 + 1,200 = Tk 3,600; (5, 3) = 3,000 + 900 = Tk 3,900; (6, 2) = 3,600 + 600 = Tk 4,200. Two mixes tie at Tk 3,600. The MRTS between them is 2, which equals the new price ratio 600 / 300 = 2.
:a 12.5 | At (4, 4): 2,400 / 4,000 = 60%. At (3, 6) with the wage at Tk 900: 2,700 / 5,100 = 52.9%. The share falls because the firm replaces workers with machines.
:a 12.6 | Workers: 30 / 600 = 0.05 books per taka. Machines: 10 / 400 = 0.025 books per taka. Workers add more per taka, so the firm should hire more workers and rent fewer machines.
