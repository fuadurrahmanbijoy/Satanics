:chapter XI | Costs of Production
:mood Why can a shop pay every bill and still lose?
:desc Rent, wages and paper are easy to count. Other costs hide, because nobody sends a bill for them. This chapter sorts costs into kinds, shows how to calculate each one by hand, and explains why the cost curves take the shapes they do.
:plate ch11-plate.svg | A mill clerk's open ledger, with columns for wages, coal and rent

:box YOU WILL NEED
Chapter 10, 'Production Function and Returns', section 10.1, 'Inputs and Output' (the production function, the short run and the long run); Chapter 10, section 10.2, 'The Law of Diminishing Returns'; and Appendix A1, 'Maths You Will Use'.

> Two stalls show the same takings, yet one owner has chosen badly.

Two friends open stalls in the same market. At the end of each day, each friend counts Tk 900 left after paying for goods and stall rent. Asha left a job that paid Tk 1,100 a day. Bina had no other offer of work. The two tills show the same figure. Yet one friend has made a poor choice, and the other has not. Which one, and why?

> The answer depends on counting what the owner gave up, not only what the owner paid.

Most students first say that the two stalls are equal, because the tills agree. Look again at Asha. She could have earned Tk 1,100 by working elsewhere, so her stall leaves her Tk 200 worse off each day. Bina had nothing better to do, so for her the same Tk 900 is a pure gain. The puzzle shows that economists use the word *cost* more widely than a shop's account book does. Paying money is one kind of cost. Giving up a better use of your own time or money is another kind.

> This chapter sorts costs into kinds, measures each kind and shows how cost changes with output.

We do three things in this chapter. First, we separate costs that involve a payment from costs that do not. Next, we study how cost behaves when a firm makes more output in the short run, and we learn to calculate every kind of cost by hand. Last, we see why the cost curves have the shapes they have. Two examples run through the chapter: a small binding workshop, and the shop of Meghna and Sons.

* * *

## Explicit and Implicit Costs

> A household garden shows that a resource can be costly even when nobody is paid for it.
@! Go slowly here.

Think first of a household, not a firm. A family grows vegetables in its own garden. It pays Tk 300 a month for seeds and water. It pays nothing for the land, which it owns, and nothing for the hours its members work. Is the garden free, apart from the Tk 300? Not quite. The land could be rented to a neighbour, and the hours could earn wages elsewhere. These lost gains are real, even though no money changes hands. Economists call the best alternative given up the *opportunity cost* of a choice.^1

^1: The idea of opportunity cost is taught in Chapter 2, 'Scarcity, Choice and Opportunity Cost'. In this chapter you need only the one-line meaning given in the text.

> The first kind of cost is the one that appears in a receipt or a bank record.
@ Cost | Word in use. In daily life, cost often means the price a buyer pays. In economics, cost means the seller's expense of making a good, and it includes costs that nobody pays in money.
@ Explicit cost | A cost that involves a payment of money to outsiders.

The first kind is easy to see. An **explicit cost** is a cost that involves a payment of money to outsiders. The word *explicit* means openly stated. For example, the rent that a shop pays its landlord each month is an explicit cost, because money leaves the shop and reaches another person. Wages, paper, electricity and interest on a bank loan are also explicit costs. Each one appears in a receipt or a bank record, and an accountant writes every one of them down.

> The second kind of cost is the value of what the owner supplies without being paid.
@ Implicit cost | The value of resources the owner supplies, which involve no payment but have an opportunity cost.

The second kind is easy to miss. An **implicit cost** is the value of the resources that the owner supplies to the firm, for which no payment is made. The word *implicit* means present but not openly stated. For example, an owner who works in her own shop without a salary supplies her time. That time has a value, because she could sell it to another firm. In the same way, money the owner has placed in the firm could have earned interest at a bank. Each of these has an opportunity cost, though nobody sends a bill.

> The shop's records show explicit costs openly and implicit costs not at all.

:case Case file, illustrative. Meghna and Sons is a family-run bookshop in Dhanmondi, Dhaka, founded on 4 April 1996 by Nurul Meghna. Record for 2025: sales Tk 14,400,000; profit shown in the accounts Tk 750,000; capital employed Tk 4,100,000; rent Tk 60,000 a month; 7 staff with total wages Tk 2,940,000; bank loan Tk 600,000. Rent, wages and interest on the loan are explicit costs, and each appears in the shop's records. The case file values the owner's time at Tk 600,000 for the year. It also records forgone interest of 7 per cent on the capital employed, which is Tk 287,000. These two amounts are implicit costs. No bank record shows either one.

> To find an implicit cost, ask what the owner's own resource could earn elsewhere.

The test for an implicit cost is one question: what is the best use of this resource outside the firm? The answer gives its value. Nurul Meghna's time could earn a salary elsewhere, and her capital could earn interest. Each answer is the opportunity cost of one of her own resources. Many students find this step confusing, because the owner never feels the sacrifice as a payment. The confusion disappears when you ask the same question about every resource, whoever owns it. A rented room has an explicit cost. An owned room has an implicit cost. Both are costs.

> The accountant counts payments, while the owner counts everything given up.

The viewpoint changes the list. The accountant records explicit costs only. The owner, who must decide whether to carry on, counts both kinds, and economists take the owner's view. There are limits. An implicit cost is an estimate, not a receipt. Also, a resource with no other use has no implicit cost. This answers the puzzle at the start. Bina's time had no better use, so her implicit cost is nil, while Asha's is Tk 1,100 a day. Her stall leaves Tk 900 after paid costs, which is Tk 200 less than her old wage.

> The section closes with a recap and a test of understanding.

*Before moving on.* A cost is either explicit, involving a payment to outsiders, or implicit, the value of what the owner supplies without payment. We find an implicit cost by asking what the resource could earn elsewhere. The accountant records explicit costs only, and the economist counts both kinds. You should now be able to say, in your own words, why an owner's unpaid time is a cost.

:pause 11.p1 | A tailor owns the building of her shop and could rent it to another person for Tk 5,000 a month. She pays rent to nobody. Is there a rent cost, and if so, of which kind?

* * *

## Short-Run Costs

> A tea stall shows how some costs stay put while others grow with every cup.
@! Go slowly here.

Begin with a market tea stall, because the numbers are small. The owner pays Tk 100 a day for the right to use her space. She pays that fee whether she sells no cups or fifty cups. Milk, tea leaves and sugar for each cup cost her Tk 4. If she sells no cups, she owes Tk 100. If she sells 10 cups, she owes Tk 100 plus 10 times Tk 4, which is Tk 140. If she sells 25 cups, she owes Tk 100 plus Tk 100, which is Tk 200. Two kinds of cost are at work: one that does not move, and one that grows with output.

> Costs are studied in the short run, when at least one input cannot be changed.

All the costs in this section belong to the short run. The short run is a period so short that at least one input, such as a machine, cannot be changed.^2 In the short run, therefore, the firm cannot avoid paying for its machine, however little it makes. Inputs that can be changed quickly, such as paper and extra workers, give the firm room to raise or cut its output.

^2: Chapter 10, 'Production Function and Returns', section 10.1 'Inputs and Output', defines the short run and the long run.

> A fixed cost stays the same whatever the output.
@ Fixed cost | A cost that does not change with the quantity produced in the short run, such as rent.

The stall fee is the model. A **fixed cost** is a cost that does not change with the quantity produced in the short run, such as rent. A workshop's machine rent is fixed: it is owed on a day when ten books are bound and on a day when sixty are bound. Fixed cost is the cost of being ready to produce, not of producing. It is still a cost, and it must be paid.

> A variable cost rises and falls with output.
@ Variable cost | A cost that changes with the quantity produced, such as paper and wages for extra output.

The milk, tea leaves and sugar are the model for the other kind. A **variable cost** is a cost that changes with the quantity produced, such as paper and wages for extra output. If the stall sells more cups, it buys more milk. If it sells none, it buys none. In a workshop, paper, thread, glue and the wages of extra workers all rise as more books are bound.

> Total cost joins the two kinds, so it is never smaller than the fixed cost.
@ Total cost | Fixed cost plus variable cost at a given output.

**Total cost** is fixed cost plus variable cost at a given output. In symbols, TC = FC + VC, where TC is total cost, FC is fixed cost and VC is variable cost, all measured in taka for the same period. The tea stall at 10 cups has TC = 100 + 40 = Tk 140. Even at zero output, total cost equals fixed cost, because the fee is still owed.

> The three costs fit together in one short sum.

*Before moving on.* Fixed cost does not move with output. Variable cost moves with output. Total cost is the two added together. You should now be able to say why total cost at zero output is not zero.

> The workshop's records give fixed, variable and total cost at seven levels of output.

:case Case file, illustrative. A binding workshop uses one machine and a small team to bind books. Its fixed cost is Tk 600 a day. At daily outputs of 0, 10, 20, 30, 40, 50 and 60 books, its variable cost is Tk 0, 300, 520, 720, 960, 1,300 and 1,780. Adding the fixed cost to each variable cost gives total cost of Tk 600, 900, 1,120, 1,320, 1,560, 1,900 and 2,380. The table below sets these records in columns.

:table Costs of the binding workshop, in taka a day
| Output (books a day) | Fixed cost | Variable cost | Total cost |
| 0 | 600 | 0 | 600 |
| 10 | 600 | 300 | 900 |
| 20 | 600 | 520 | 1,120 |
| 30 | 600 | 720 | 1,320 |
| 40 | 600 | 960 | 1,560 |
| 50 | 600 | 1,300 | 1,900 |
| 60 | 600 | 1,780 | 2,380 |

> To read a row, add the fixed and variable columns to get the total.

Read each row from left to right. In the row for 20 books, fixed cost 600 plus variable cost 520 gives total cost 1,120. Notice that the fixed column never changes, while the variable column climbs faster and faster. Notice also that the first row shows an output of nothing and a cost of Tk 600. The workshop pays for its machine even when it binds no book.

> Marginal cost asks what one more unit adds to total cost.
@! Go slowly here.
@ Marginal | Word in use. In daily life, marginal means small or barely enough, as in a marginal gain. In economics, marginal means extra: the change caused by one more unit.
@ Marginal cost | The extra cost of producing one more unit of output.

Managers decide one step at a time, so they ask about the next unit. **Marginal cost** is the extra cost of producing one more unit of output. In words, marginal cost equals the change in total cost divided by the change in output. In symbols, MC = (change in TC) ÷ (change in Q), where MC is marginal cost and Q is the quantity of output. The tea stall's total cost rises from Tk 140 at 10 cups to Tk 144 at 11 cups. The change in TC is Tk 4 and the change in Q is 1 cup, so MC = 4 ÷ 1 = Tk 4.

> At the workshop, marginal cost is each rise in total cost divided by the rise in output.

The same rule works when output rises ten books at a time. In the workshop, total cost rises from Tk 900 at 10 books to Tk 1,120 at 20 books. The change in TC is Tk 220, and the change in Q is 10 books. So MC = 220 ÷ 10 = Tk 22 for each of those books. Fixed cost is Tk 600 in both rows, so it cancels in the subtraction. Marginal cost comes from variable cost alone. A fixed cost, however large, never changes marginal cost.

:pause 11.p2 | At the workshop, total cost rises from Tk 1,320 at 30 books to Tk 1,560 at 40 books. What is the marginal cost of each of those books?

> Average total cost spreads total cost over every unit made.
@ Average total cost | Total cost divided by the number of units produced.

An owner who sets a price needs the cost of each unit on average. **Average total cost** is total cost divided by the number of units produced. In symbols, ATC = TC ÷ Q. For the tea stall at 25 cups, ATC = 200 ÷ 25 = Tk 8 a cup. For the workshop at 20 books, ATC = 1,120 ÷ 20 = Tk 56 a book. Average total cost measures the whole cost, fixed and variable, shared among all the units.

> Average total cost is the sum of two smaller averages, one for each kind of cost.

Average total cost splits into two parts. Fixed cost divided by output is the average fixed cost. It falls as output grows, because the same Tk 600 is shared among more books: Tk 60 a book at 10 books, and Tk 10 a book at 60 books. Variable cost divided by output is the average variable cost. At the workshop it is Tk 30, 26, 24, 24, 26 and 29.67 for outputs of 10 to 60 books. Adding the two averages gives ATC. At 10 books, 60 plus 30 gives Tk 90.

> The second table gives the per-unit costs at each output.

:case Case file, illustrative. For the same workshop, the marginal cost of each book in each ten-book step is Tk 30, 22, 20, 24, 34 and 48. Average total cost at outputs of 10 to 60 books is Tk 90, 56, 44, 39, 38 and 39.67. The table lists these figures beside the average variable cost.

:table Per-unit costs of the binding workshop, in taka a book
| Output (books a day) | Marginal cost of the last ten books | Average variable cost | Average total cost |
| 10 | 30 | 30.00 | 90.00 |
| 20 | 22 | 26.00 | 56.00 |
| 30 | 20 | 24.00 | 44.00 |
| 40 | 24 | 24.00 | 39.00 |
| 50 | 34 | 26.00 | 38.00 |
| 60 | 48 | 29.67 | 39.67 |

> In the table, every cost per unit first falls and then rises.

Read down each column. Marginal cost falls from 30 to 20 and then climbs to 48. Average variable cost falls to 24 and then climbs to 29.67. Average total cost falls from 90 to 38 and then rises to 39.67. The lowest average total cost, Tk 38 a book, occurs at 50 books a day. The next section explains why the costs move in this pattern.

:box IN SHORT
Total cost equals fixed cost plus variable cost. Marginal cost is the change in total cost divided by the change in output. Average total cost is total cost divided by output.

> The section ends with a recap and a test of understanding.

*Before moving on.* Fixed cost stays still, variable cost grows, and total cost is their sum. Marginal cost measures the next unit and average total cost measures every unit. You should now be able to say why marginal cost and average total cost are different numbers.

* * *

## The Cost Curves

> A cost curve draws a table as a picture, with one point for each output.
@! Go slowly here.

A curve shows a table at a glance. The first figure below draws the workshop's fixed, variable and total cost. Here is how to read it. The horizontal axis, the line along the bottom, shows output in books a day. The vertical axis, the line up the side, shows cost in taka a day. Each point on a curve tells you the cost at one output. Start at an output on the bottom, move upward until you meet a curve, and read the cost from the side.

:fig Fixed, variable and total cost curves of the binding workshop | ch11-fig01.svg

> Fixed cost is a flat line, and total cost is the variable cost curve lifted by the fixed cost.

The fixed cost line is flat, because fixed cost does not change with output. The variable cost curve starts at zero, because nothing is spent on variable inputs when nothing is made. The total cost curve has exactly the shape of the variable cost curve, but it sits Tk 600 higher at every output. That gap is the fixed cost. At 30 books, for example, variable cost is 720 and total cost is 1,320.

> Variable cost climbs slowly at first and quickly later, because extra workers add less and less to output.

The variable cost curve is gentle at first and steep later. The reason is the law of diminishing returns, which says that adding more of one input to fixed amounts of others will, after a point, add less and less to output.^3 Suppose the workshop adds workers to its one machine. At first, each new worker adds a great deal of output, so each extra book needs little extra wage and paper. Later, each new worker adds little, so each extra book needs much more labour. Marginal cost therefore falls at first and then rises. In the table it falls from 30 to 20 and climbs to 48.

^3: Chapter 10, 'Production Function and Returns', section 10.2 'The Law of Diminishing Returns', explains why the extra output from each new worker rises at first and then falls.

> Average total cost has a U shape because two forces pull on it in opposite directions.

The curve of average total cost is shaped like the letter U. Two forces explain this. The first force pulls the average down: fixed cost is shared among more books as output grows, so average fixed cost falls. The second force pulls the average up: after a point, rising marginal cost makes average variable cost rise. At low output the first force is stronger, and the average falls. At high output the second force is stronger, and the average rises. Near 50 books the forces balance, and average total cost is at its lowest, Tk 38.

:fig Marginal, average variable and average total cost curves of the binding workshop | ch11-fig02.svg

> Marginal cost crosses average total cost at the lowest point of the average.

The second figure draws the three per-unit costs. The vertical axis now shows cost per book, not cost for the whole output. Look at where the marginal cost curve meets the average curves. Think of the average age of a class. A new student who is younger than the average lowers it, and a new student who is older raises it. The new student is the marginal addition. Costs follow the same rule. While the marginal cost of the next book is below average total cost, the average falls. When marginal cost is above it, the average rises. So marginal cost must cross average total cost at the bottom of the U.

> The workshop figures show the crossing between two rows of the table.

The table confirms the rule. For the step from 40 to 50 books, marginal cost is Tk 34, below the average of Tk 39 at 40 books, so the average falls to Tk 38. For the step from 50 to 60 books, marginal cost is Tk 48, above the average of Tk 38, so the average rises to Tk 39.67. The same rule makes marginal cost cross average variable cost at its lowest point. Our table moves in steps of ten books, so the exact crossing lies between two rows.

> In the long run every input can change, so the cost curve changes with it.

So far one input, the machine, has been fixed. In the long run all inputs can be changed, so the firm has no fixed cost at all. It can choose a larger machine or a smaller one. The long-run cost curve shows the lowest average cost at which each output can be made when the firm is free to choose its size. It is usually also U-shaped, but for a different reason: the cause is returns to scale, taught in Chapter 10, and not diminishing returns.

> The section closes with a recap.

*Before moving on.* Cost curves draw the cost tables as pictures. Marginal cost falls and then rises because extra workers add less and less. Average total cost is U-shaped because fixed cost is shared more widely while variable cost per unit rises. Marginal cost cuts average total cost at its lowest point. You should now be able to say why the bottom of the U is where marginal cost equals average total cost.

* * *

## Worked Example: Costs of the Binding Workshop

> Two examples apply the formulas, one small and clean and one realistic.

We now work two examples in the same order each time: Given, Find, Formula, Steps, Answer and Check. The first uses the workshop table at an output of 30 books. The second uses the shop's own records and shows how implicit costs change the picture.

> The first example gives total, marginal and average total cost at 30 books.

*Given.* Fixed cost is Tk 600 a day. Variable cost is Tk 520 at 20 books and Tk 720 at 30 books. *Find.* Total cost at 30 books, marginal cost of each book from 20 to 30 books, and average total cost at 30 books. *Formula.* In words, total cost is fixed cost plus variable cost. In symbols, TC = FC + VC. Marginal cost is MC = (change in TC) ÷ (change in Q), and average total cost is ATC = TC ÷ Q.

> Each line of arithmetic is shown, with its unit, so the method is the only new thing.

*Steps.* Total cost at 30 books: TC = 600 + 720 = Tk 1,320. Total cost at 20 books: TC = 600 + 520 = Tk 1,120. Change in TC = 1,320 − 1,120 = Tk 200. Change in Q = 30 − 20 = 10 books. Marginal cost: MC = 200 ÷ 10 = Tk 20 a book. Average total cost: ATC = 1,320 ÷ 30 = Tk 44 a book.

> The answer is stated in a sentence and tested against the table.

*Answer.* At 30 books a day, total cost is Tk 1,320, the marginal cost of each book from 20 to 30 is Tk 20, and average total cost is Tk 44 a book. *Check.* Multiply back: 44 × 30 = 1,320, which equals total cost. The marginal cost of Tk 20 is below the average of Tk 44, so the average should be falling, and the table shows it falling from Tk 56 to Tk 44. Both figures agree with the table.

> The second example uses the shop's records to count implicit costs.

*Given.* For 2025, the profit shown in the accounts of Meghna and Sons is Tk 750,000.^4 The owner's time is valued at Tk 600,000. Capital employed is Tk 4,100,000, and the interest rate the capital could earn elsewhere is 7 per cent a year. *Find.* The implicit costs, and the result after counting them. *Formula.* Forgone interest = rate × capital employed. Result after implicit costs = profit shown in the accounts − total implicit costs.

^4: Profit has several exact meanings, taught in Chapter 16, 'Interest and Profit'. Here it means only the money left after explicit costs are paid.

> Every step is written out, so that nothing depends on guesswork.

*Steps.* Write 7 per cent as 7 ÷ 100 = 0.07. Forgone interest = 0.07 × 4,100,000 = Tk 287,000. Total implicit costs = 600,000 + 287,000 = Tk 887,000. Result = 750,000 − 887,000 = −Tk 137,000.

> The shop looks successful in its accounts but falls short once its own resources are valued.

*Answer.* The implicit costs are Tk 887,000, and after counting them the shop falls Tk 137,000 short. *Check.* The implicit costs are larger than Tk 750,000, so the result must be negative. Adding back: −137,000 + 887,000 = 750,000, the figure in the accounts. What does the owner learn? Her resources would have earned Tk 137,000 more elsewhere, if other things were equal. She may still choose to carry on, because she may value the shop for other reasons. The calculation tells her the price of that choice.

> Five common slips spoil these calculations, and each has a simple remedy.

Common slips are easy to name. First, forgetting fixed cost when adding up total cost. Second, dividing by the output when you need the change in output, or the reverse. Third, forgetting units, so that a cost for the whole output is mistaken for a cost per book. Fourth, mixing periods, such as a daily fixed cost with a yearly wage. Fifth, a wrong sign, such as subtracting the larger number from the smaller. Name the unit beside every number, and the first four slips are caught early.

* * *

## Summary

> The chapter's main points fit in a few lines.

Costs are explicit, when money is paid to outsiders, or implicit, when the owner supplies the resource. In the short run, total cost is fixed cost plus variable cost. Marginal cost is the change in total cost divided by the change in output, and average total cost is total cost divided by output. Marginal cost falls and then rises, average total cost is U-shaped, and marginal cost crosses average total cost at its lowest point.

* * *

## Think It Through

:q 11.t1 | In the workshop table, variable cost per book rises from Tk 24 at 40 books to Tk 26 at 50 books, yet average total cost falls from Tk 39 to Tk 38. Explain how this can happen.

:q 11.t2 | A bookseller says, "My own time is free, because I pay myself nothing." Reply using the idea of implicit cost, and say what question she should ask.

* * *

## Where People Go Wrong

> A fixed cost is fixed only in the short run, and only as a total.

*Mistake: "A fixed cost never changes."* The cost is fixed only in the short run, and only as a total. In the long run every input can change, so no cost stays fixed. Fixed cost per book also changes, because the same total is shared among more books.

> No bill does not mean no cost.

*Mistake: "If nobody sends a bill, there is no cost."* An implicit cost has no bill, but it has an opportunity cost. The owner's time and money could have been used elsewhere.

> Marginal cost and average total cost answer different questions.

*Mistake: "Marginal cost is total cost divided by output."* That is average total cost. Marginal cost divides the change in total cost by the change in output. At 30 books, marginal cost is Tk 20 and average total cost is Tk 44.

> The two lowest points are at different outputs.

*Mistake: "Average cost is lowest where marginal cost is lowest."* In the workshop, marginal cost is lowest at 30 books (Tk 20), but average total cost is lowest at 50 books (Tk 38). The average stops falling only when marginal cost rises to meet it.

* * *

## In History

> A famous fall in the price of a car shows unit cost falling as output grows.

In 1908, the Ford Motor Company of the United States began to sell the Model T, a car for ordinary families, at about USD 825. By 1925, the basic model cost about USD 260. In 1913, Ford introduced a moving assembly line at its factory in Highland Park, Michigan. The car moved past the workers, and each worker repeated one task, so more cars were built in less time.

> Higher output spread fixed costs and lowered cost per car, as the falling part of the U predicts.

The usual account is that the cost of making each car fell as output rose, and Ford passed much of the saving to buyers as lower prices. The figures above are prices, not costs. The fall in cost per car is the falling part of the average total cost curve, where large fixed costs are shared among very many units.

* * *

## Review Questions

> The questions use a small print stall; the data are given here.

A print stall has a fixed cost of Tk 200 a day. At outputs of 0, 5, 10, 15, 20, 25 and 30 pages of posters a day, its variable cost is Tk 0, 100, 180, 240, 320, 430 and 560. Use these data for questions 11.2 to 11.6.

:q 11.1 | A tailor spends Tk 8,000 on cloth and Tk 3,000 on a helper's wage in a month. She works in her own shop, and her time is worth Tk 12,000 a month elsewhere. The building she owns could be rented for Tk 5,000. Find her explicit costs and her implicit costs.

:q 11.2 | Find the total cost of the print stall at each output from 0 to 30.

:q 11.3 | Find the marginal cost of each page in every step of five pages.

:q 11.4 | Find average total cost at each output from 5 to 30, to two decimal places. At which output is it lowest?

:q 11.5 | The stall works 6 days a week and makes 20 pages every day. What is its total cost for the week?

:q 11.6 | The stall's daily fixed cost rises from Tk 200 to Tk 260. State what happens to total cost at 20 pages, to marginal cost, and to average total cost at 20 pages.

:q 11.7 | A shopkeeper's accounts show a profit of Tk 500,000. Her own time is worth Tk 360,000 a year elsewhere. Her capital of Tk 3,000,000 could earn 8 per cent a year. Find her implicit costs and the result after counting them.

:read Alfred Marshall, Principles of Economics, 1890
:read Henry Ford with Samuel Crowther, My Life and Work, 1922
