:answers 11
:a 11.p1 | Yes. It is an implicit cost, because the building has a best alternative use worth Tk 5,000 a month, although she pays nothing in money.
:a 11.p2 | Total cost rises by 1,560 − 1,320 = Tk 240 for 10 books, so marginal cost is 240 ÷ 10 = Tk 24 a book.
:a 11.t1 | Average variable cost rises by Tk 2, but average fixed cost falls from Tk 15 to Tk 12, a fall of Tk 3. The net change is −Tk 1. Marginal cost of Tk 34 is also below the old average of Tk 39, which pulls the average down.
:a 11.t2 | Her time is an implicit cost, because it could earn a wage elsewhere. She should ask: what is the best use of my time outside the shop, and what is it worth?
:a 11.1 | Explicit costs: 8,000 + 3,000 = Tk 11,000. Implicit costs: her time, Tk 12,000, plus the rent forgone on the building, Tk 5,000, which is Tk 17,000.
:a 11.2 | Total cost = 200 + variable cost: Tk 200, 300, 380, 440, 520, 630 and 760 at outputs of 0, 5, 10, 15, 20, 25 and 30.
:a 11.3 | Marginal cost per page for each step of five pages: Tk 20, 16, 12, 16, 22 and 26. For example, (300 − 200) ÷ 5 = 20.
:a 11.4 | ATC = TC ÷ Q: Tk 60.00, 38.00, 29.33, 26.00, 25.20 and 25.33 at 5 to 30 pages. It is lowest at 25 pages, at Tk 25.20.
:a 11.5 | Total cost for one day at 20 pages is Tk 520, which includes the fixed cost. For 6 days, 520 × 6 = Tk 3,120.
:a 11.6 | Total cost at 20 pages rises by Tk 60, from 520 to 580. Marginal cost does not change, because fixed cost cancels in the subtraction. Average total cost at 20 pages is 580 ÷ 20 = Tk 29.
:a 11.7 | Forgone interest = 0.08 × 3,000,000 = Tk 240,000. Implicit costs = 360,000 + 240,000 = Tk 600,000. Result = 500,000 − 600,000 = −Tk 100,000.
