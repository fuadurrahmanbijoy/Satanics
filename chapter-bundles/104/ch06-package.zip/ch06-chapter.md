:chapter VI | Consumption and Consumers' Surplus
:mood Why does a consumer who pays the full price still leave with more than she paid for?
:desc This chapter explains how people use goods to satisfy their wants and how they spend a limited income. It then shows that a consumer often gains more from a good than the price paid, and teaches you to measure that gain in taka.
:plate ch06-plate.svg | A buyer counts coins beside a stall on market day

:box YOU WILL NEED
Chapter 3 'Utility and Diminishing Marginal Utility', section 3.1 'The Idea of Utility'; Chapter 4 'Demand and the Demand Curve', section 4.1 'Quantity Demanded and the Law of Demand'; Appendix A1 'Maths You Will Use'.

> A woman pays Tk 60 for a water pot that she values at Tk 100.

On a market day in a small town, a woman passes a stall that sells water pots. Her old pot has cracked, so she needs a new one. In her own mind she has fixed a limit: she would pay Tk 100 for a good pot, and not one taka more. The stallholder asks Tk 60. She pays at once, takes the pot and walks home.

> The sale is recorded as Tk 60, yet she feels richer by Tk 40.

Now examine the exchange as an accountant would. The woman handed over Tk 60 and received a pot. The stallholder received Tk 60 and handed over a pot. Each side has a record, and the records agree. Yet the woman feels that she has done well, and she is right. The pot was worth Tk 100 to her, and she paid only Tk 60. Forty taka of satisfaction appears on no receipt, in no ledger and in no bank account.

> The puzzle: how can a gain exist that nobody pays for, and can it be measured?

Here is the puzzle. If trade is a fair exchange, how can one side gain something that nobody pays for? And if she gains, can we measure the gain? Many students find the question strange at first, because we are used to thinking that the price tells us what a good is worth. This chapter shows that the price tells us only part of the story. We begin with what consumers do. Then we measure what they gain.

* * *

## Consumption and Choice

> Everyday acts such as eating or travelling use things that others provide.

Think about your own day. You eat breakfast, travel by bus, read a message on your phone and drink water. Each act uses something that other people made or provided, and each act satisfies a want. Economics gives this ordinary activity a name, and the name lets us study it with care.

@ Consumption | The use of goods and services by people to satisfy their wants.

> Consumption is the use of goods and services to satisfy wants.

The word **consumption** means the use of goods and services by people to satisfy their wants. A student who eats a meal is engaged in consumption. So is a family that uses electricity to light a room. Here a *good* is a physical thing, such as a notebook, and a *service* is work done for a person, such as a haircut.

> Buying is not consuming: the use may come later than the payment.

Two points prevent confusion. First, buying is not the same as consuming. A consumer may buy a notebook on Monday and use it over many weeks, filling one page after another. The consumption happens during the use, not at the moment of payment. A haircut is different, because the service is used as it is given.

> Only the final user consumes; a firm that uses a good to make other goods does not.

Second, consumption is the final purpose of production. A firm that makes cloth does not consume the cloth. A tailor buys it to make shirts, and only the person who wears a shirt consumes it. A good used to make other goods is therefore not consumption in this sense.

> The consumer feels a want satisfied; the owner sees only a sale.

Different people see the same act in different ways. The consumer feels a want satisfied. The owner of a bookshop sees only a sale and counts the money received. The shop records the price, but it never records the satisfaction in the mind of the person who buys. This difference between what a consumer feels and what a firm records is the key to the chapter.

> Income is limited and each taka can be spent only once, so every purchase is a choice.

Every consumer has an income, which is the money received in a period such as a month. Wants are many, but income is limited. A taka spent on one good cannot be spent again on another. So every act of consumption is also a choice: to buy one good is to decide not to buy something else with the same money.

@ Spend | Word in use. In daily life, to pay out money, or to pass time. In economics, to use part of income to buy goods, so that the same money cannot buy anything else.

> Recall: marginal utility, Chapter 3, section 3.1 'The Idea of Utility'.
> A sensible consumer spends each taka where it adds the most utility.

How should a consumer choose? Chapter 3 showed that each extra unit of a good adds less utility than the one before it. This fact guides the choice. Suppose a student has Tk 100 left at the end of a month. The next Tk 20 spent on tea adds more utility than the next Tk 20 spent on a fourth magazine. A sensible student moves money from the magazine to the tea. The student stops when no further move would add utility.

> Real consumers do not calculate every purchase, so the rule is a guide only.

The rule has limits. Real consumers do not calculate every purchase. Habit, advice from friends and the mood of the day all play a part. The idea of a sensible consumer describes the usual case, and it is not a picture of every person. It is still useful, because it explains why the amounts that consumers spend on different goods change when prices change.

> Recap: consumption, limited income and the gap between price and satisfaction.

*Before moving on.* Consumption is the use of goods and services to satisfy wants, and it happens when the good is used. Consumers have limited income, so they spend it where an extra taka adds the most utility. The price a consumer pays does not show the satisfaction received.

* * *

## Consumers' Surplus

> The woman's extra Tk 40 needs a name and a measure.

Return to the woman with the pot. What is the source of her extra Tk 40? To answer, we first need a name for the limit she carried in her mind. Many students find this step confusing, because the limit is not written anywhere. It exists only as a decision that the consumer would make if the price rose.

@ Willingness to pay | The highest price a buyer would pay for one more unit of a good.

> Willingness to pay is the highest price a consumer would pay for one more unit.

**Willingness to pay** means the highest price a buyer would pay for one more unit of a good. For the woman, the willingness to pay for the pot was Tk 100. At any price above Tk 100 she would not buy. At Tk 100 or below she would buy.

> Recall: marginal utility, Chapter 3, section 3.1; the demand curve, Chapter 4, section 4.1.
> Willingness to pay is marginal utility measured in money, and it falls with each extra unit.

Willingness to pay is closely tied to marginal utility, the extra utility from one more unit. The first pot is very useful to the woman. A second pot would add far less utility, so she would pay much less for it. Her willingness to pay therefore falls as she buys more units. This is the reason the demand curve slopes downward: each further unit is worth less to the same consumer.

> Willingness to pay is a limit in the mind, and it differs between consumers.

Two cautions apply. First, willingness to pay is a limit in the mind, not a price on a tag. Nobody pays it unless the price rises to meet it. Second, it differs from person to person. A consumer with a larger income may be willing to pay more for the same good. Two consumers at the same stall can therefore hold different limits for the same pot.

:pause 6.p1 | The price of a pen is Tk 12. A consumer's willingness to pay for one more pen is Tk 9. Will the consumer buy it? Explain.

@ Consumers' surplus | The gap between what buyers are willing to pay for a good and what they actually pay.
@ Surplus | Word in use. In daily life, an amount left over after needs are met. In economics, the gain a consumer keeps when the price paid is below the most the consumer would pay.

> Consumers' surplus is the gap between willingness to pay and the price paid.

Now the puzzle has an answer. **Consumers' surplus** means the gap between what buyers are willing to pay for a good and what they actually pay.^1 The woman's willingness to pay was Tk 100 and she paid Tk 60, so her consumers' surplus on the pot is Tk 100 minus Tk 60, which is Tk 40. The surplus is not money. It is satisfaction measured in taka, and it never appears on a receipt.

^1: The idea is older than its name. The section 'In History', at the end of this chapter, tells how it began.

> Three of five customers buy the notebook at Tk 40, and their surplus totals Tk 30.

:case Case file, illustrative. Five regular customers of Meghna and Sons were recorded with these willingness to pay amounts for the popular 200-page notebook: Tk 60, Tk 50, Tk 40, Tk 30 and Tk 20. The market price is Tk 40. Three customers buy, because the price is at or below their willingness to pay. Consumers' surplus = (60 - 40) + (50 - 40) + (40 - 40) = Tk 30.

> The customer sees a bargain, but the owner sees only a Tk 40 sale.

The same sale looks different from each side. The customer with a willingness to pay of Tk 60 sees a bargain of Tk 20. The owner sees a sale at Tk 40, the same as every other sale of the notebook that day. The owner cannot see the Tk 20, because it exists only in the mind of the customer.

> To measure surplus, subtract the price from willingness to pay for each unit bought, then sum.

The method has three steps. For each unit bought, subtract the price from the willingness to pay. Omit any unit whose willingness to pay is below the price, because the consumer does not buy it. Then sum the differences. The table applies the steps to the five customers of the notebook case. Its columns show the customer, the willingness to pay, whether the customer buys at Tk 40, and the surplus.

:table Notebook case at the price of Tk 40
| Customer | Willingness to pay (Tk) | Buys at Tk 40? | Surplus (Tk) |
| A | 60 | Yes | 20 |
| B | 50 | Yes | 10 |
| C | 40 | Yes | 0 |
| D | 30 | No | 0 |
| E | 20 | No | 0 |
| Total | | | 30 |

> Read the table row by row: the first buyer gains most and the last buyer gains least.

Read the row for Customer A first. A would pay Tk 60 and pays Tk 40, so A keeps Tk 20. Customer C buys but keeps nothing, because the willingness to pay equals the price. Customers D and E do not buy and gain no surplus. The first buyer has the largest surplus and the last buyer the smallest, which follows from a willingness to pay that falls with each unit.

> The surplus depends on the price: a lower price gives the same consumer a larger surplus.

One more point needs care. The surplus belongs to the consumer and the price together, not to the good alone. The same customer who keeps Tk 20 at a price of Tk 40 would keep Tk 30 at a price of Tk 30. A consumer whose willingness to pay equals the price still chooses to buy, but gains nothing. For this reason a surplus of zero does not mean that the good is useless to that consumer.

> With many customers the steps become a smooth line, and the surplus becomes a triangle.

Now suppose the shop has thousands of customers instead of five. The steps in the table become so small that they form a smooth line, and that line is the demand curve. On the chart that follows, the vertical axis shows price in taka and the horizontal axis shows the quantity bought. Each point on the line shows the highest price at which consumers would still buy that quantity. The dashed line is the market price. The consumers' surplus is the hatched triangle under the demand curve and above the price line. The dotted rectangle below it is the money that consumers actually pay.

:fig Consumers' surplus is the triangle under the demand curve and above the price | ch06-fig01.svg

@! Advanced note: a beginner may defer this paragraph.

> For a straight demand curve, the surplus triangle has an area of half base times height.

When the demand curve is a straight line, the triangle has a simple area: half of the base multiplied by the height. The base is the quantity bought. The height is the highest price anyone would pay minus the market price. Suppose the highest price is Tk 100, the market price is Tk 60 and 40 units are bought. The surplus is 1/2 x 40 x (100 - 60) = 1/2 x 40 x 40 = Tk 800.

> Recap: willingness to pay, consumers' surplus and the triangle on the chart.

*Before moving on.* Willingness to pay is the highest price a consumer would pay for one more unit. Consumers' surplus is the gap between that limit and the price actually paid, added over all units bought. On a chart it is the triangle under the demand curve and above the price line.

* * *

## Using the Idea

> Surplus shows the full value of a good to its users, beyond the price they pay.

Why measure a gain that nobody pays for? Because it shows the full value of a good to its users. A government that builds a bridge cannot judge it by the tolls alone, since the users gain more than they pay. A shopkeeper learns something too. Customers with a large surplus would have bought at a slightly higher price, so a price set too low gives away part of what the shop could earn. A price set too high loses the customers whose surplus was small.

> Surplus is measured in taka, and a taka means more to a poor consumer than to a rich one.

The idea has limits, and the first concerns money. A taka means more to a poor consumer than to a rich one. Two consumers with the same surplus in taka may therefore gain different satisfaction. The measure shows the size of a gain in money. It does not show how fair the gain is, and it cannot compare the feelings of two people exactly.

> The surplus can only be estimated, because willingness to pay is hidden.

The second limit is that willingness to pay is hidden. Nobody can read it from the mind of a consumer. Economists estimate the demand curve from the prices and quantities that markets record, so the triangle is an approximation. The estimate is weakest for goods that are needed to live, such as water, because the first units give a very large surplus that no chart can measure sensibly.

> A fall in price is a movement along the demand curve, not a shift, and it raises surplus.

Now consider a change in price. When the price of the notebook falls, consumers move along the demand curve to a larger quantity demanded. This is a movement along the curve. It is not a shift, which needs a change in something other than price, such as income. Our question is what the movement does to the surplus.

> The notebook price falls to Tk 30: four customers buy and surplus rises to Tk 60.

:case Case file, illustrative. The market price of the notebook falls from Tk 40 to Tk 30. Four of the five customers now buy. Consumers' surplus = (60 - 30) + (50 - 30) + (40 - 30) + (30 - 30) = 30 + 20 + 10 + 0 = Tk 60.

> Surplus rises for two reasons: old buyers gain more per unit, and new buyers join.

The surplus rose from Tk 30 to Tk 60, a rise of Tk 30. Two things explain it. First, each of the three old buyers keeps Tk 10 more, because the price fell by Tk 10, and 3 x Tk 10 is Tk 30. Second, a new buyer joins. In this case the new buyer adds nothing, because the willingness to pay of Tk 30 equals the new price. With thousands of customers, new buyers join in a steady stream, and each adds a thin slice to the triangle.

> A firm cannot collect the surplus without raising the price, and a higher price reduces the quantity bought.

A manager must take care here. The surplus is a gain of the consumers, not income of the firm. The firm could collect more of it only by raising the price, and a higher price lowers the quantity demanded. Some consumers would then stop buying. So the surplus is a fact to understand, and it does not tell the manager what price to charge.

> Recap: uses, limits and the effect of a fall in price on surplus.

*Before moving on.* Surplus shows the value of a good beyond its price, and governments and firms can use it. It is measured in money, so it cannot compare the feelings of different people exactly, and it can only be estimated. A fall in price is a movement along the demand curve, and it raises the consumers' surplus.

* * *

## Worked Examples: Measuring Consumers' Surplus

> Two examples apply the method: the first with small numbers, the second with more realistic ones.

We now apply the method in full, in the order Given, Find, Formula, Steps, Answer and Check. The first example uses small numbers, so that the method is the only new thing to learn. The second is a little messier and shows a change in price.

> Example 1: surplus on three cups of tea at Tk 6 a cup.

*Example 1: cups of tea.* *Given.* A consumer is willing to pay Tk 10 for the first cup of tea, Tk 8 for the second, Tk 6 for the third and Tk 4 for a fourth. The price is Tk 6 a cup. *Find.* The consumers' surplus.

> The formula subtracts the price from each willingness to pay and sums the results.

*Formula.* In words: consumers' surplus equals the sum, over the units bought, of the willingness to pay minus the price. In symbols: S = (W1 - P) + (W2 - P) + ..., where S is the consumers' surplus, W is the willingness to pay for each unit bought and P is the price. *Steps.* The fourth cup is not bought, because Tk 4 is below the price of Tk 6. First cup: 10 - 6 = Tk 4. Second cup: 8 - 6 = Tk 2. Third cup: 6 - 6 = Tk 0. Sum: 4 + 2 + 0 = Tk 6.

> The surplus is Tk 6, and the check agrees.

*Answer.* The consumers' surplus is Tk 6. *Check.* The consumer pays 3 x Tk 6 = Tk 18 and would have paid up to 10 + 8 + 6 = Tk 24. The gap is 24 - 18 = Tk 6, which agrees with the answer.

> Example 2: pens at a school stall, with a price fall from Tk 12 to Tk 9.

*Example 2: pens at a school stall.* *Given.* Four consumers are willing to pay Tk 25, Tk 18, Tk 14 and Tk 9 for one pen each. The price is Tk 12, and later it falls to Tk 9. *Find.* The consumers' surplus at each price, and the rise between them.

> The same formula is applied twice, once at each price.

*Formula.* The same as before: S = (W1 - P) + (W2 - P) + ... for every pen bought. *Steps at Tk 12.* The consumer willing to pay Tk 9 does not buy. 25 - 12 = Tk 13. 18 - 12 = Tk 6. 14 - 12 = Tk 2. Sum: 13 + 6 + 2 = Tk 21. *Steps at Tk 9.* All four consumers buy. 25 - 9 = Tk 16. 18 - 9 = Tk 9. 14 - 9 = Tk 5. 9 - 9 = Tk 0. Sum: 16 + 9 + 5 + 0 = Tk 30. Rise: 30 - 21 = Tk 9.

> The surplus is Tk 21 at Tk 12 and Tk 30 at Tk 9, and the rise passes the check.

*Answer.* The surplus is Tk 21 at the price of Tk 12 and Tk 30 at the price of Tk 9, a rise of Tk 9. *Check.* The price fell by Tk 3, so each of the three old buyers gains Tk 3, and 3 x 3 = Tk 9. The new buyer adds Tk 0. The total agrees with the rise.

> Three slips are common: wrong sign, buyers who do not buy, and missing units.

Three slips are common. The first is a wrong sign. Subtract the price from the willingness to pay, not the reverse, or the answer is negative. The second is to include a consumer who does not buy. Omit such a consumer, because the surplus from that unit is zero. The third is to forget the unit. Write Tk beside each figure, and do not mix prices from different dates.

* * *

## Summary

> The main ideas of the chapter in a few lines.

Consumption is the use of goods and services to satisfy wants. Consumers have limited income and spend it where an extra taka adds the most utility. Willingness to pay is the highest price a consumer would pay for one more unit. Consumers' surplus is the gap between willingness to pay and the price actually paid, and on a chart it is the triangle under the demand curve and above the price. A fall in price is a movement along the demand curve and it raises the surplus. In the notebook case, the surplus rose from Tk 30 to Tk 60 when the price fell from Tk 40 to Tk 30.

## Think It Through

:q 6.t1 | In the notebook case the surplus rose from Tk 30 to Tk 60 when the price fell from Tk 40 to Tk 30. Explain in your own words why the surplus rises when the price falls.
:q 6.t2 | A public bridge charges a toll of Tk 20, and 1,000 people cross each day. Many of them would have paid more. Explain why the tolls collected do not measure the benefit of the bridge to its users.

## Where People Go Wrong

> A common belief is that the price shows what a good is worth to the consumer; it does not.

A common belief is that the price shows what a good is worth to the consumer. It does not. The price shows only what the consumer must pay. The worth to the consumer is the willingness to pay, which is usually higher. The difference between the two is the surplus.

> A second belief is that surplus is money received; it is satisfaction counted in taka.

A second belief is that surplus is money that the consumer receives. No money changes hands. Surplus is satisfaction expressed in taka, and it stays in the mind of the consumer.

> A third mistake is to count a consumer who does not buy.

A third mistake is to include a consumer who does not buy. A person whose willingness to pay is below the price gains no surplus and adds nothing to the total. If the subtraction gives a negative number, the unit should not have been counted.

> A fourth mistake is to call a fall in price a shift.

A fourth mistake is to call a fall in price a shift. A fall in the price of a good moves consumers along the same demand curve to a larger quantity demanded. A shift needs a change in something else, such as income.

> A fifth mistake is to confuse the triangle with the rectangle on the chart.

A fifth mistake is to confuse the two parts of the chart. The rectangle shows the money that consumers pay, and the firm receives it. The triangle shows the surplus, and the consumers keep it. A reader who adds the two together has found the total value of the units bought to consumers, which is a different quantity from the surplus.

## In History

> In 1844 Jules Dupuit, a French engineer, showed that people gain more from a bridge than the toll they pay.

In 1844 a French engineer named Jules Dupuit published an article on the utility of public works in a French engineering journal, the *Annales des ponts et chaussées*.^2 He worked on roads and bridges for the state, and he asked how the benefit of such works should be judged. He showed that people gain more from a bridge than the toll they pay.

^2: Dupuit, 'De la mesure de l'utilité des travaux publics', *Annales des ponts et chaussées*, 1844. An English translation appeared in *International Economic Papers* in 1952.

> Dupuit saw that a lower toll brings more crossings and a larger gain; Marshall later named the idea.

Dupuit saw that a lower toll brings more crossings, and that those who cross at a high toll would have paid even more. He called the gain *relative utility*. The British economist Alfred Marshall, who taught at Cambridge, later gave the idea the name used today. He did so in his textbook *Principles of Economics*, first published in 1890.

> Governments still use the idea to compare a project's benefits with its cost to build.

Governments still use the idea. When they compare a bridge, a road or a railway with the cost to build it, they include the surplus of the people who will use it. The cost here is the builder's expense, and the benefit is more than the tolls collected.

## Review Questions

:q 6.1 | Define consumption in your own words and give one example from your own day.
:q 6.2 | Explain the difference between price and willingness to pay, using the notebook case.
:q 6.3 | In the notebook case, compute the consumers' surplus when the price is Tk 50, and again when the price is Tk 20.
:q 6.4 | Four consumers are willing to pay Tk 30, Tk 22, Tk 16 and Tk 10 for one pen each. Compute the consumers' surplus at a price of Tk 16 and at a price of Tk 10, and find the rise between them.
:q 6.5 | Using marginal utility and the demand curve, explain why the surplus on the last unit a consumer buys is close to zero.

:read Jules Dupuit, On the Measurement of the Utility of Public Works, 1844
:read Alfred Marshall, Principles of Economics, 1890
