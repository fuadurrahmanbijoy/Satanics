:answers 06
:a 6.p1 | No. The price of Tk 12 is above the willingness to pay of Tk 9, so the consumer does not buy the pen.
:a 6.t1 | Each old buyer keeps Tk 10 more, because the price fell by Tk 10, and 3 x 10 = Tk 30. A fourth customer joins but adds Tk 0. The total rises by Tk 30, from Tk 30 to Tk 60.
:a 6.t2 | The toll is only what users pay. Many would have paid more, and the gap between what they would pay and the Tk 20 is their surplus. The benefit is the toll plus this surplus, so it is larger than the tolls collected.
:a 6.1 | Consumption is the use of goods and services by people to satisfy their wants. Example: drinking water, or travelling by bus.
:a 6.2 | Price is what the consumer must pay, Tk 40 in the notebook case. Willingness to pay is the most the consumer would pay, for instance Tk 60 for the first customer. The gap, Tk 20, is that customer's surplus.
:a 6.3 | At Tk 50: (60 - 50) + (50 - 50) = Tk 10. At Tk 20: 40 + 30 + 20 + 10 + 0 = Tk 100.
:a 6.4 | At Tk 16: (30 - 16) + (22 - 16) + (16 - 16) = 14 + 6 + 0 = Tk 20. At Tk 10: 20 + 12 + 6 + 0 = Tk 38. The rise is 38 - 20 = Tk 18.
:a 6.5 | Willingness to pay falls with each unit, because marginal utility falls. The last unit bought has a willingness to pay close to the price, so the gap between them is close to zero.
