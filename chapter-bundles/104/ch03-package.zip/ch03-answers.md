:answers 03
:a 3.p1 | Higher. The second cup added some satisfaction, so the total rose, even though the second cup pleased her less than the first.
:a 3.p2 | 2 utils (25 minus 23). The marginal utility column gives it directly.
:a 3.t1 | By the fifth cup her want for tea has been met by the first four cups. She is no longer cold or thirsty, so a further cup adds nothing.
:a 3.t2 | Total utility = 25 + (−3) = 22 utils. She should refuse the sixth cup, because it lowers her total satisfaction.
:a 3.1 | Utility is the satisfaction a person gets from using a good or service. Example: the relief of a cold drink on a hot afternoon.
:a 3.2 | Totals: 50, then 50 + 35 = 85, then 85 + 20 = 105, then 105 + 5 = 110 utils.
:a 3.3 | Marginal utilities: 20, then 36 − 20 = 16, 48 − 36 = 12, 54 − 48 = 6, 56 − 54 = 2 utils.
:a 3.4 | As a person consumes more units of a good, the satisfaction added by each extra unit falls. It holds when the units are alike, tastes stay steady and consumption has no long gaps.
:a 3.5 | The marginal utility of the 5th book is 0 utils. Its opportunity cost is the other good the money could have bought, which would have given some satisfaction, so the student gives up something for nothing.
:a 3.6 | Falling marginal utility means each addition is smaller, not that the total shrinks. The total keeps rising while marginal utility is above zero.
