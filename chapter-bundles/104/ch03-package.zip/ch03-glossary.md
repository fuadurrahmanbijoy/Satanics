:glossary 03
Utility | The satisfaction a person gets from using a good or service. It is a feeling, not a judgement of whether the good is wise or healthy. A cold drink on a hot day gives utility to the person who drinks it.
Total utility | The whole satisfaction a person gets from all the units of a good consumed in a period. It is found by adding the marginal utility of each unit. If three cups gave 10, 8 and 5 utils, total utility is 23 utils.
Marginal utility | The extra satisfaction a person gets from consuming one more unit of a good. It is the height of the last step, not the height of the whole staircase. If the third cup adds 5 utils, its marginal utility is 5 utils.
Util | An imaginary unit used to count satisfaction in economic examples. A util is not a real measurement; it lets us reason exactly about more and less for one person. A cup worth 10 utils pleases more than a cup worth 8 utils.
Law of diminishing marginal utility | As a person consumes more units of a good, the satisfaction added by each extra unit falls. It holds when units are alike, tastes are steady and consumption has no long gaps. Marginal utilities of 10, 8, 5, 2 and 0 show the law.
