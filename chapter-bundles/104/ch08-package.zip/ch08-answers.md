:answers 08
:a 8.p1 | 50 notebooks. A higher price (Tk 50 against Tk 30) brings a larger quantity supplied, which is the law of supply.
:a 8.p2 | A shift to the right, because a subsidy lowers the seller's expense, so more notebooks are offered at every price. The price of notebooks itself did not change.
:a 8.t1 | At a high rate of pay the worker can earn the income needed in fewer hours, and may value rest more. The curve rises, reaches a peak and bends backward.
:a 8.t2 | For the day, the curve is a vertical line at 200 fish, since more cannot be had at any price. Over a week more fish can be brought, so the quantity supplied can rise with the price and the curve slopes upward.
:a 8.1 | The points are (20, Tk 20), (30, Tk 30), (40, Tk 40), (50, Tk 50), (60, Tk 60), with quantity on the horizontal axis. The line slopes upward: each Tk 10 rise in price adds 10 notebooks, so a higher price goes with a larger quantity supplied.
:a 8.2 | The new curve lies 10 notebooks to the left of the old one at every price. An increase of 15 on the old curve gives Qs = P + 15, so the quantity at Tk 40 is 55 (40 + 15).
:a 8.3 | (a) movement; (b) shift, to the right; (c) shift, to the right; (d) movement.
:a 8.4 | At Tk 55, Qs = 55 notebooks. For Qs = 25, P = Tk 25. With Qs = P − 10, at Tk 55 the quantity is 55 − 10 = 45.
:a 8.5 | When the price of a good rises, the quantity supplied rises, if other conditions stay the same. Costs of inputs, technology, taxes and subsidies, or the number of sellers must stay fixed.
:a 8.6 | A backward-bending curve, such as hours of work offered at a very high rate of pay; and a fixed supply, such as the fish caught for one market day.
:a 8.7 | Supply rises, so the curve shifts to the right. The number of sellers has changed, and that is a determinant of supply.
