:answers 13
:a 13.p1 | Its sales fall to nothing. Buyers can obtain an identical good at Tk 40 from other firms and know that price, so no one pays Tk 42.
:a 13.t1 | Other firms see the profit and, since entry is free, they begin to sell the good. Industry supply shifts to the right, the price falls, and the fall stops when no profit above normal remains.
:a 13.t2 | The potato seller faces very many sellers of an identical good, and customers can easily move to the next stall. The pharmacist is the only seller for ten kilometres, so customers have little choice and entry of rivals is unlikely.
:a 13.1 | Extra revenue per step is 5 × 10 = 50. Extra costs are 20, 35, 45, 60, so extra profits are +30, +15, +5, −10. The best output is 15 units, and the steps made add 30 + 15 + 5 = Tk 50.
:a 13.2 | Extra revenue per step is 500; extra costs are 300, 220, 200, 240, 340, 480, so every step adds profit and the best output is 60 units. Total revenue is 60 × 50 = 3,000, total cost is 1,900 + 480 = 2,380, and profit is Tk 620.
:a 13.3 | Each step earns extra revenue of 100 × 20 = 2,000 against extra costs of 1,800, 1,400, 1,600, 2,200, 3,000. Extra profits are +200, +600, +400, −200, −1,000. The best output is 300 kilograms, and the steps made add Tk 1,200.
:a 13.4 | New demand: 100 − price = price, so the price is Tk 50. The workshop's best output is 60 units and its profit is Tk 620, against Tk 100 at Tk 40. Profit above normal attracts new firms, so industry supply shifts right and the price falls in the long run.
:a 13.5 | Monopolistic competition: many sellers, different versions of the good (each tailor has a style) and easy entry.
