:chapter XIII | Market Structure and Perfect Competition
:mood Why must a grain dealer accept a price that the dealer did not choose?
:desc This chapter sorts markets into four kinds by the number of sellers, the sameness of the good and the ease of entry. It then studies the firm in the most competitive kind of market, finds the output that gives that firm the largest profit, and follows the profit through time.
:plate ch13-plate.svg | Dealers in a grain exchange call out prices round the central pit

:box YOU WILL NEED
Chapter 9, 'Elasticity of Supply and Market Equilibrium', section 9.2 'Market Equilibrium'; Chapter 11, 'Costs of Production', section 11.2 'Short-Run Costs'; Chapter 11, 'Costs of Production', section 11.3 'The Cost Curves'; and Appendix A1, 'Maths You Will Use'.

> Two sellers in one town choose their prices in very different ways.

Picture two sellers in one town. The first sells potatoes from a stall in a long row of stalls, and every stall offers the same potatoes at nearly the same price. The second runs the only pharmacy within ten kilometres. Both sellers wish to earn as much money as possible, yet they behave in opposite ways. The potato seller dares not charge one taka more than her neighbours, because her customers would move to the next stall. The pharmacist may raise a price and still keep many customers.

> The difference lies in the surroundings of each seller, not in the seller's character.

Why does the same wish lead to such different behaviour? The cause is not the character of the two sellers. It lies in the surroundings of each one: how many rivals there are, whether the goods are the same, and whether a new seller can arrive next month. When the surroundings change, the behaviour changes with them. Economists describe those surroundings in an exact way, so that they can predict what sellers will do.

> The chapter has three steps: sort markets, study one firm, then follow its profit over time.

This chapter takes three steps. First, we sort markets into kinds, so that we know where the potato seller and the pharmacist belong. Second, we study a firm that cannot choose its price and chooses only its output, and we find the output that gives it the largest profit, using the cost data of the binding workshop. Third, we ask what happens to that profit once other firms notice it. Many students find the second step surprising, because they expect every firm to name its own price.

* * *

## 13.1 Kinds of Market

> A question: which facts about a market would you ask for, to predict how its sellers behave?

Suppose you must predict how the sellers in a market will behave, and you may ask only a few questions. Most people begin with the number of sellers. That is a good first question, but not the only one. Economists have found that the answers to a small group of questions, taken together, explain much of what sellers do. A list of those answers describes the market.

@ Market structure | The set of features of a market, such as number of sellers and ease of entry, that shape how firms behave.

> The list of features that shapes seller behaviour has a name: market structure.

The name for that list is **market structure**. A market structure means the set of features of a market, such as the number of sellers and the ease of entry, that shape how firms behave. The row of potato stalls and the village pharmacy have different structures. Once we know the structure, we can say much about the freedom a seller has over the price.

### Features that distinguish markets

> Four features separate one market from another.

Four features do most of the work. The first is the *number of sellers*: very many, a few, or one. The second is the *kind of good*: identical from every seller, or different in quality, brand or place. The third is *ease of entry*: whether a new firm can begin selling without being blocked by law, by cost or by an existing firm. The fourth is *information*: whether buyers and sellers know the prices and the quality on offer. Each feature changes how much power a seller holds over the price.

@ Competition | Word in use. In daily life, a contest in which each person tries to win, such as a race. In economics, the pressure that sellers place on one another through price and quality when several offer the same good.

> Competition has an everyday meaning and a narrower meaning in economics.

The word *competition* needs care. In daily life it means a contest, and a seller who advertises loudly is said to compete hard. In economics the word is narrower. Economists judge competition by the number of rivals and the ease of entry, and not by the loudness of advertising. A market can contain fierce advertising and weak competition at the same time, for example when only two firms exist and no third firm may enter.

> The table gives four kinds of market, sorted by the features above.

The next table sorts markets into four kinds. Read a row from the left: the first column names the kind, and the other columns give the number of sellers, the kind of good and the ease of entry. The last three kinds are taught in Chapter 14, 'Monopoly and Imperfect Competition'; the section on monopoly is 14.1 'Monopoly'. Here we use the table only to place the first kind among the others.

:table Four kinds of market
| Kind | Sellers | Good | Entry |
| Perfect competition | Very many | Identical | Free |
| Monopolistic competition | Many | Different versions | Easy |
| Oligopoly | A few | Identical or different | Difficult |
| Monopoly | One | One good with no close substitute | Blocked |

@ Industry | All the firms that produce the same kind of good.

> We also need one word for all the firms that make the same good.

Markets and firms need a link word between them. The **industry** means all the firms that produce the same kind of good. All the firms that make notebooks form the notebook industry; all the wheat farmers of a country form the wheat industry. The quantity supplied by the industry is the sum of the quantities supplied by its firms. The difference between one firm and its industry matters greatly in section 13.3, where firms enter and leave.

> Real markets rarely match one row exactly, so the table is a map and not a photograph.

The table has limits. Real markets rarely match one row exactly, and a market with five large firms and fifty small ones belongs partly to two rows. A map leaves out detail so that the main roads are easy to see. Use the table to ask which features a market has.

> Before moving on, recall the three ideas of section 13.1.

*Before moving on.* A market structure is the set of features that shape how firms behave: number of sellers, kind of good, ease of entry and information. There are four kinds of market. An industry is all the firms that produce the same kind of good.

* * *

## 13.2 The Perfectly Competitive Firm

> A hook: in a grain hall, one price is called across the floor and every dealer must accept it.

Imagine a hall in which dozens of dealers trade the same grain. One price is called across the floor. A dealer who asks for more finds no buyer, and a dealer who accepts less loses money for no reason. In History gives a true account of such a hall.

@ Perfect competition | A market with very many buyers and sellers, identical goods, free entry and full information.

> Perfect competition is the market with four strict features.

That kind of market is called **perfect competition**. Perfect competition means a market with very many buyers and sellers, identical goods, free entry and full information. A hall of grain dealers comes near it, because wheat of one grade is the same whoever grew it. No real market meets all four conditions exactly. Perfect competition is therefore a *model*: a simple picture that shows the main forces in their cleanest form.^1

^1: A model leaves out detail on purpose. Its value lies in the forces it shows, and not in an exact match with any one market.

> Each of the four conditions removes one kind of power from the seller.

Each condition removes one kind of power from the seller. With very many sellers, each firm supplies a tiny part of the total. With identical goods, a buyer has no reason to prefer one seller. With free entry, new firms may start at any time. With full information, every buyer knows the price in the next stall and will not pay more.

@ Price taker | A firm that must accept the market price because its own sales are too small to affect it.

> Because of these conditions, each firm must accept the price that the market gives.

The result is a firm of a special kind: a **price taker**. A price taker means a firm that must accept the market price because its own sales are too small to affect it. Suppose the market price of a notebook is Tk 40. A workshop that makes notebooks can sell any quantity it is able to make at Tk 40, and none at Tk 41. It has no reason to sell below Tk 40, since all its output finds a buyer at Tk 40. For this firm the price is a fact, like the weather, and it cannot be changed.

> How to read the first chart: two panels share a price scale but not a quantity scale.

The first chart shows a firm and its industry side by side. In each panel the vertical axis shows the price in taka, and the horizontal axis shows quantity. A point on a line shows one price and the quantity that goes with it. The two panels use the same price scale, so the same height means the same price. Their quantity scales differ, because one firm makes only a tiny part of the industry's total. On the right, the industry faces a falling demand line and a rising supply line, which cross at the market price. On the left, the single firm faces a flat line at that price.

:fig Firm and industry side by side: the market sets the price, and the firm accepts it | ch13-fig01.svg

:pause 13.p1 | The market price is Tk 40. A firm in perfect competition asks Tk 42 for its good. What happens to its sales, and why?

@! Go slowly here.

### Marginal cost equals price

> A price taker has one decision left: how much to make.

Because the market fixes the price, the firm has one decision left: how much to make. The answer uses a measure from Chapter 11.

> Recall: marginal cost, Chapter 11, section 11.2 'Short-Run Costs'.
> Marginal cost is the extra cost of making one more unit of the good.

Marginal cost is the extra cost of making one more unit. Each extra unit adds the market price to the firm's revenue, and it adds the marginal cost to the firm's cost. While the price is larger than the marginal cost, the extra unit adds to profit. Once the marginal cost is larger than the price, the extra unit reduces profit. So the firm raises its output until marginal cost reaches the price. This is the rule *marginal cost equals price*.

> The case file gives the price and the workshop's marginal costs.

:case Case file, illustrative. The market price is Tk 40, taken from the notebook market. Cost data of the binding workshop (Chapter 11): marginal cost for each 10-unit step is 30, 22, 20, 24, 34 and 48, at outputs 10 to 60. Each figure is the extra cost of one unit in that step. A step of 10 units therefore adds 10 times its marginal cost to total cost.

> The table compares the extra revenue and extra cost of each 10-unit step.

The table below applies the rule one step at a time. Read a row from the left: the first column names the step by its last unit, the second gives the extra revenue (10 units at Tk 40), the third gives the extra cost (10 times the marginal cost), and the fourth gives the difference. A positive difference means the step adds to profit.

:table Each 10-unit step at a price of Tk 40
| Step ending at output | Extra revenue | Extra cost | Extra profit |
| 10 | 400 | 300 | +100 |
| 20 | 400 | 220 | +180 |
| 30 | 400 | 200 | +200 |
| 40 | 400 | 240 | +160 |
| 50 | 400 | 340 | +60 |
| 60 | 400 | 480 | -80 |

> How to read the second chart: the price line, the cost points and the best output.

Now read the second chart. The horizontal axis shows the output of the workshop, and the vertical axis shows the price and the cost in taka. The flat line is the price of Tk 40. Each dot shows the marginal cost at the end of one step. The hatched area lies between the price line and the cost line, where each unit adds to profit. The cost line passes above the price line after the fifth step, where each unit would add a loss.

:fig Price taker at marginal cost equal to price: the workshop stops at 50 units | ch13-fig02.svg

> The workshop adds every step whose extra profit is positive and stops at 50 units.

The first five steps all add to profit, and the sixth reduces it by 80. So the workshop makes 50 units. At 50 units, the marginal cost of the last step (34) is below the price (40), and the marginal cost of the next step (48) is above it. The output of 50 is therefore the best whole step.

> The rule has limits: marginal cost must be rising, and the data come in steps.

The rule has two limits. First, the marginal cost must be *rising* where it meets the price. A marginal cost that meets the price while it is still falling does not mark the best output, because the next units cost less and add more profit. The workshop's costs fall over the first three steps and rise afterwards, so only the rising part can give the answer. Second, the data come in steps of 10 units. A smooth curve would cross the price line between 50 and 60 units, but the workshop sells whole steps, and the best full step is 50.

> Before moving on, recall the price taker and the output rule.

*Before moving on.* Perfect competition is a market with very many buyers and sellers, identical goods, free entry and full information. A price taker accepts the market price and chooses only its output. The firm raises output while marginal cost is below the price and stops where marginal cost equals the price.

* * *

## 13.3 Equilibrium of Firm and Industry

> A puzzle: the workshop earns a profit, so would that profit last?

At a price of Tk 40 the binding workshop earns a profit. Other firms can see this, and in perfect competition they are free to enter. Will the profit last for ever? To answer, we first need to be exact about the workshop's best output, and about what the word profit means in this chapter.

@ Equilibrium of the firm | The output at which a firm earns the largest possible profit and has no wish to change.

> The best output of a firm has a name: the equilibrium of the firm.

The **equilibrium of the firm** means the output at which a firm earns the largest possible profit and has no wish to change. The idea is the same as in Chapter 9, where equilibrium meant a balance of forces, but now it describes one firm. At the best output, a larger output gives less profit and a smaller output gives less profit, so the firm stays where it is.

> The case file states the workshop's revenue, cost and profit at its best output.

:case Case file, illustrative. At the market price of Tk 40, the binding workshop produces 50 units. Total revenue is 50 × 40 = 2,000. Total cost is 1,900. Profit is 2,000 − 1,900 = Tk 100.

> A test: at 40 units and at 60 units the profit is lower, so the workshop wishes no change.

We can test the claim. At 40 units, total revenue is 40 × 40 = 1,600. Total cost is the cost at 50 units less the cost of the fifth step: 1,900 − 340 = 1,560. Profit is 1,600 − 1,560 = Tk 40. At 60 units, total revenue is 60 × 40 = 2,400, and total cost is 1,900 + 480 = 2,380, so profit is Tk 20. Both figures are below Tk 100. The workshop has no wish to change, so 50 units is its equilibrium.

@ Profit | Word in use. In daily life, any money gained, or the money left after the bills are paid. In economics, revenue minus all costs, including the value of the owner's own time and money; Chapter 16, 'Interest and Profit', section 16.2 'Profit' explains it fully.

> In this chapter, profit means total revenue minus total cost.

In this chapter, *profit* means total revenue minus total cost. Total revenue is the price times the quantity sold. If total revenue is larger than total cost, the firm earns a profit. If it is smaller, the firm makes a loss. The word has an everyday meaning too, and the two meanings differ in what they count as a cost. The note above gives both.

### Short-run profit and loss

> In the short run, the price decides whether the firm gains or loses.

The short run is a period too short for new firms to enter or for old firms to leave. During it, the market price decides the result for the firm. When the price is high, the firm earns a profit, as the workshop does at Tk 40. When the price is low, the firm still chooses the output where marginal cost equals the price, but its total revenue may fall below its total cost, and it makes a loss. The Worked Examples show a price of Tk 30, where the workshop makes a loss.

> Normal profit is the least payment that keeps the owner in this line of business.

@ Normal profit | The least profit a firm must earn to stay in business, covering the owner's implicit costs.

Now consider what the owner must earn to continue. **Normal profit** means the least profit a firm must earn to stay in business, covering the owner's implicit costs. Implicit costs are the values of things the owner gives up and does not pay for in money, such as the owner's own time. A baker who could earn a good wage in a factory must earn at least that much from her own bakery, or she will close it.

> In this chapter normal profit counts as a cost, so a profit means a profit above normal.

In this chapter we count normal profit as part of total cost. A profit of Tk 100 is therefore a profit above normal. Chapter 16, 'Interest and Profit', section 16.2 'Profit' gives such a profit its own name and explains where it comes from. Here it is enough to say that a profit above normal attracts new firms, and that a loss drives firms away.

### Long-run equilibrium

> In the long run, free entry removes profit above normal, and exit removes losses.

The long run is a period long enough for firms to enter and to leave the industry. Follow the workshop's profit through time in four steps. First, at Tk 40 the workshop earns Tk 100 above normal, and other firms notice it. Second, because entry is free, new firms begin to make notebooks, and the supply of the industry shifts to the right. Third, with more notebooks offered, the market price falls. Fourth, the fall continues until the profit above normal is gone and no new firm has a reason to enter.

> Recall: equilibrium price, Chapter 9, section 9.2 'Market Equilibrium'.
> The same process runs in reverse when firms make losses.

The process also runs in reverse. If the price is so low that firms make losses, some firms leave. The supply of the industry shifts to the left, and the market price rises. The rise continues until the remaining firms earn normal profit. In both directions the price moves to the level where no firm earns more than normal profit, and no firm earns less.

> The resting point is long-run equilibrium: normal profit, and a price equal to the lowest cost per unit.

The resting point is called *long-run equilibrium*. In it, every firm earns normal profit only, the price equals the lowest cost per unit at which a firm can produce, and no firm wishes to enter or to leave. The consumer gains, because the good sells at the lowest cost at which it can be made. The owner gains nothing above normal, and that is why owners prefer markets where entry is blocked.

> The result holds under conditions: free entry, equal costs and enough time.

The result has limits. It needs free entry, so a blocked market keeps its profit. It assumes that all firms have the same costs, which real firms seldom do. And it takes time: new firms must find money and build workshops, so a profit above normal can last for months. The result gives the direction of the change, and not its speed.

> Before moving on, recall the short run, the long run and normal profit.

*Before moving on.* The equilibrium of the firm is the output with the largest profit, where marginal cost equals the price. In the short run a firm may earn a profit above normal or make a loss. In the long run, entry and exit leave every firm with normal profit, at a price equal to the lowest cost per unit.

* * *

## Worked Examples

> Worked example 1 finds the best output and the result at a lower price of Tk 30.

The first example uses the workshop's cost data at a lower market price, where the result is a loss.

> The steps of worked example 1, from the data to the check.

*Given.* The market price is Tk 30. The marginal cost of each 10-unit step is 30, 22, 20, 24, 34 and 48, at outputs 10 to 60. Total cost at 50 units is 1,900.
*Find.* The best output, and the profit or loss at that output.
*Formula.* In words: raise output while each step adds to profit, and stop before the first step that reduces it. Profit equals total revenue minus total cost, and the extra cost of a step equals 10 times its marginal cost.
*Steps.* (1) Extra revenue of each step: 10 × 30 = 300. (2) Extra cost of the steps: 300, 220, 200, 240, 340, 480. (3) Extra profit of the steps: 0, +80, +100, +60, −40, −180. (4) The fifth step reduces profit, so the best output is 40 units. (5) Total revenue: 40 × 30 = 1,200. (6) Total cost at 40 units: 1,900 − 340 = 1,560. (7) Profit: 1,200 − 1,560 = −360.
*Answer.* The workshop makes 40 units and a loss of Tk 360.
*Check.* At 30 units the loss would be (1,560 − 240) − 900 = 420, and at 50 units it would be 1,900 − 1,500 = 400. Both are larger than 360, so 40 units gives the smallest loss.

> Recall: cost curves, Chapter 11, section 11.3 'The Cost Curves'.
> Worked example 2 finds the price at which the profit above normal disappears.

The second example joins this chapter to the cost ideas of Chapter 11. It supposes that other firms have the same costs as the workshop, and that entry is free.

> The steps of worked example 2, from the data to the check.

*Given.* Total cost is 1,560 at 40 units, 1,900 at 50 units and 2,380 at 60 units. The market price is Tk 40, and the workshop earns Tk 100 above normal.
*Find.* The price at which the profit above normal disappears.
*Formula.* In words: cost per unit equals total cost divided by quantity. In the long run, the price equals the lowest cost per unit.
*Steps.* (1) At 40 units: 1,560 ÷ 40 = 39. (2) At 50 units: 1,900 ÷ 50 = 38. (3) At 60 units: 2,380 ÷ 60 = 39.67, to two decimal places. (4) The lowest cost per unit is Tk 38, at 50 units. (5) At Tk 38 the best output is still 50 units, since the marginal cost of the fifth step (34) is below 38 and that of the sixth (48) is above it. (6) Total revenue: 50 × 38 = 1,900, which equals total cost.
*Answer.* The long-run price is Tk 38. The workshop makes 50 units and earns normal profit only.
*Check.* A fall of Tk 2 in the price takes 2 × 50 = Tk 100 from the revenue. That equals the profit above normal at Tk 40, so no profit above normal remains.

> Common slips: step costs, falling marginal cost and mixing totals with unit figures.

Three slips cause most wrong answers. First, forgetting that the extra cost of a 10-unit step is 10 times its marginal cost. Second, stopping at the first output where the price equals the marginal cost, when the marginal cost is still falling. Third, comparing the price with total cost, when it should be compared with marginal cost.

* * *

## Summary

> The chapter in a few lines.

A market structure is the set of features of a market that shape how firms behave. Perfect competition has very many buyers and sellers, identical goods, free entry and full information. In it, each firm is a price taker, which accepts the market price and chooses only its output. The firm raises output until marginal cost equals the price, and that output is the equilibrium of the firm. In the short run the firm may earn a profit above normal or make a loss. In the long run, free entry and exit leave every firm with normal profit, at a price equal to the lowest cost per unit.

## Think It Through

> Two short problems apply the chapter to the potato seller and the pharmacist.

Use section 13.3 for the first problem and section 13.1 for the second.

:q 13.t1 | A firm in perfect competition earns a profit above normal this year. Explain why this profit is unlikely to last, using free entry and the shift of the industry's supply.
:q 13.t2 | The potato seller must accept the market price, but the only pharmacist for ten kilometres can raise a price and still keep customers. Name two features of their markets that explain the difference.

## Where People Go Wrong

> Mistake one: believing that the largest output gives the largest profit.

*Mistake: "To earn the most, the workshop should make as many units as it can."* The sixth step of the workshop adds Tk 480 to cost and only Tk 400 to revenue, so it reduces profit. The corrected rule: raise output only while each step adds to profit, and stop where marginal cost reaches the price.

> Mistake two: believing that a price taker is always a small firm in a small town.

*Mistake: "A price taker is any firm that is small."* A price taker is a firm whose sales are too small *relative to the market* to affect the price. A very large firm in a very large market can be a price taker, while a small firm that is the only seller in a village is not. The corrected rule: judge the firm against its market.

> Mistake three: believing that zero profit in the long run means the owner earns nothing.

*Mistake: "In the long run the owner earns nothing."* The owner earns normal profit, which pays for the owner's time and money. What vanishes is the profit above normal. The corrected rule: zero profit above normal means that the owner is paid exactly as much as the next best use of the owner's effort.

## In History

> In 1848 grain dealers in Chicago founded an exchange to bring order to a chaotic market.

In 1848, a group of businessmen in Chicago, in the United States, founded the Chicago Board of Trade. Their aim was to bring order to the grain market of the American Midwest, which had been disorderly. The exchange gave dealers one place to meet, and its trading produced prices that every member could see.^2 For much of its history, traders there called out their bids and offers face to face in trading rooms known as pits.

^2: The exchange later added futures contracts and other products. Those later developments lie outside this chapter.

> Such an exchange comes close to perfect competition but meets not every condition.

Economists use a grain exchange as an example because it comes close to the model of this chapter: many dealers traded the same kind of grain, and each price was called for all to hear. The match was not perfect. Trading on the floor was open to members, so entry was not entirely free, and no real market meets all four conditions.

## Review Questions

> Five questions follow the ladder from a clean example to a combined problem.

:q 13.1 | A firm in perfect competition sells its good at Tk 10. Its marginal cost for each 5-unit step is 4, 7, 9 and 12, at outputs 5 to 20. Find the best output and the extra profit of the steps that it makes.
:q 13.2 | The market price of a notebook rises to Tk 50. Using the binding workshop's marginal costs (30, 22, 20, 24, 34 and 48 for each 10-unit step, with total cost 1,900 at 50 units), find the best output and the profit.
:q 13.3 | A rice farmer sells rice at Tk 20 a kilogram. Her marginal cost for each 100-kilogram step is Tk 18, 14, 16, 22 and 30 a kilogram, at outputs 100 to 500 kilograms. Find the best output and the extra profit of the steps she makes.
:q 13.4 | In the notebook market, the quantity demanded is 80 minus the price and the quantity supplied equals the price. Demand then shifts to 100 minus the price. Find the new market price, then find the workshop's best output and profit at that price, and say what you expect to happen in the long run.
:q 13.5 | A town has thirty tailors. Each offers clothes in a different style, and anyone may open a new shop. Using the table in section 13.1, name the kind of market and give the features that support your answer.

:read Alfred Marshall, Principles of Economics, 1890
